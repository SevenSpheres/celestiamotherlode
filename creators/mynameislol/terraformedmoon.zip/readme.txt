I made this for personal use, but i'm going to give it to all the people of celestia :) You can do whatever you want with it, i made this rather quickly, but don't claim it's yours!
Also, i have a higher quality image, but the motherload "insisted" that i use lowerres jpg's instead of pngs.




Put it in your celestia's extra foldier. Mine is E:\Program Files\Celestia\extras