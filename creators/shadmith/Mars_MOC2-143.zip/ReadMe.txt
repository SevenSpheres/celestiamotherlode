This is a texture of Mars based on the Mars Global Surveyor image catalog MOC2-143, I specifically enjoyed working with this image because of its balance of light,color and resolution, making it one of the most profound renditions of Mars up till today.

To install in Celestia-just unzip in to whatever driver you have Celestia Installed to and go to the "hires" folder, for windows operating system this is generally  'C:\Program Files\Celestia\textures\hires' and keep in mind that you have to activate in Celestia the high resolution textures by clicking "Shift-R" keys. 
Enjoy.
Shadmith Manzo
shadmithreal@yahoo.com.mx