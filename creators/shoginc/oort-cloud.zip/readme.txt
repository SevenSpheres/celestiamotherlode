Oort cloud add-on for Celestia v1.0

Installation guide:
	Just extract the 'Oort Cloud' folder to Celestia's 'extras' folder.
	
This addon adds the Oort cloud as a nebula for celestia.
The Oort cloud is a hypothesized spherical cloud of comets which may lie roughly nearly a light-year, from the Sun. This places the cloud at nearly a quarter of the distance to Proxima Centauri, the nearest star to the Sun. The Kuiper belt and scattered disc, the other two reservoirs of trans-Neptunian objects, are less than one thousandth of the Oort cloud's distance. The outer limit of the Oort cloud defines the cosmographical boundary of the Solar System and the region of the Sun's gravitational dominance.

Created by Bence J�rd�n /shoginc/ - 04. 03. 2012