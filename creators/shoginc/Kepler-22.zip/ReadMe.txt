Kepler-22 v1.1 Add-on for Celestia.

Updates in v1.1:
-some corrected data about Kepler-22 and 'b' planet
-now, the 'b' planet makes transit as seen from Earth

This addon adds the Kepler-22 star and its probably habitable planet 'b' to Celestia. Recommended to use Celestia 1.6 or newer. All informations about this system is valid. The surface of the b planet is fictionally, because currently we haven't any information about this.

Installation: Just copy the Kepler-22 folder to your 'extras' folder, open Celetia and type 'Kepler-22'.

Created by: Bence J�rd�n (shoginc).