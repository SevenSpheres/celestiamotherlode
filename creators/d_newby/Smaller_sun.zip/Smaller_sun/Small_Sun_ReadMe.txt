This is a much smaller version of the Runar Thorvaldsen version for those who have a slow internet connection and/or a low performance computer.

If your computer can handle Virtual Textures and you have about 140 Mb of space available then it is highly recommended that you download the full version.

Please read the "Original_Sun_Readme.txt" for copyright and info on the large version



INSTALLATION:
--------------------------------------------------
Drop the folder "small_th_sun" into
/CelestiaResources/extras/addons/
(If the Addons folder does not exist, create it).



NOTE ABOUT A PORTRAIT OF OR SUN:
--------------------------------------------------
This is a semi-real G-star model. It is based on
real imagery.

Important: if you have a modest computer setup,
you should delete the "th_suncover.png" file
from the  textures/hires/ folder; else, the haze
it provides will not be drawn.



SIGHTS TO SEE:
--------------------------------------------------
To see the flares, make sure cloud rendering
is ON.



CREDITS
--------------------------------------------------
Thanks to Frank Gregorio for permission to use
his own Sun Solar System Catalog data for this
add-on.

Thanks also to Cham, for his contribution to
the solar flare animation; basically, he wrote
it, and i messed it up afterwards.

Smaller version by David Newby

COPYRIGHT
--------------------------------------------------
Included material produced by Runar Thorvaldsen
may be used in any way you like, exept for
commercial purposes.

Included material produced by other authors /
are only distributable to the extent they give
permission.

If you want to re-distribute this Ran Add-On,
you are free to do so, provided that you:
- do not charge money for it in any way, neither
  for the files themselves, or for access to them.
- keep it complete and unmodified, including
  this ReadMe.
- If you want to distribute it for/with software
  other than Celestia, send me a note.



ADDRESSES
--------------------------------------------------
Smaller version 
Mail: davidljnewby@hotmail.com

--------------------------------------------------
�rthorvald [Runar Thorvaldsen],
Oslo, 02. january 2005

Smaller version � David Newby
England January 2005


