------Deepwatcher's add-on!------

Just drop the add-on's folder into the extras folder in your Celestia's program files!

Everything that there is to know about the add-on is written into the two files. Sources, methods, calculations are precisely depicted there.

This add-on is released under totally free license, you can use anything in it for yourselves add-ons, only two conditions:

1) Mention it if you take inspiration from this!
2) Work done from this must be totally free as this is!

Enjoy! I wish you all Clear Skies, thanks for choosing this work, it took a while to make everything work.

Version: 	1.1
Latest Update:	27-02-2012

If you need to contact me for any questions, mistakes, fixes or problems please write on the add-on's page or to this e-mail:

emc2deepwatcher@gmail.com