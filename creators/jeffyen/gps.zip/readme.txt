NAVSTAR GPS Constellation for Celestia
Version 1.2


Installation Instructions
=========================
Copy the files from the 'extras', 'models' and 'textures' folder into the existing folders of your Celestia installation. (Create a new 'extras' folder if one doesn't already exist.) Then start Celestia.


Background and acknowledgement
================
This file contains the orbital elements for the 30 satellites of the NAVSTAR GPS (Global Positioning System) constellation orbiting around the Earth at an altitude of 20,200 km.

Steps I took to obtain data:

1) Installed GPS program from http://www.movingsatellites.com

2) Used GPS program to retrieve information from http://celestrak.com/NORAD/elements/gps-ops.txt .

3) Used Datas>satellitedatas to view numbers from fields.

4.1) Period = 1/revolutions per day
4.2) Period = 2 (pi) x square root (a^3/mu) [Formula to find SemiMajorAxis]

Period is in seconds. mu = 398,601, a=SemiMajorAxis

Source: http://www.j-bradford-delong.net/movable_type/2004-2_archives/000086.html

4.3) ArgOfPericenter = Argument of Perigee

4.4) Epoch: Julian Date calculations from http://quasar.as.utexas.edu/BillInfo/JulianDateCalc.html and http://www.fourmilab.ch/documents/calendar/ .

References:
Data Field Guides from http://www.celestiamotherlode.net/catalog/documentation.html .
CelesTrak Two-Line Element FAQ http://celestrak.com/columns/v04n03/#FAQ02
US Naval Observatory (USNO) at http://tycho.usno.navy.mil/gpscurr.html .

The objects of this file are considered as "moons" in order to be able to see their orbits into Celestia (press "o" to see their orbits and "m" for their names). The PRN numbers are the ones shown on handheld GPS systems.

My thanks to Thomas Guilpain (http://members.fortunecity.com/guilpain/) for permission to use his nice 'imaginary' 3D satellite model in this package.

Latest Epoch: 14 December, 2006


Jeffrey Yen
jeffreyyen@gmail.com

