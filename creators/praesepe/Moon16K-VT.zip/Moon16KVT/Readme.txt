This file contains a virtual texture of the moon at 16K resolution for use in Celestia.

Installation:

Uncompress the contents of this file to the "extras" subfolder in yor Celestia
installation.

The folder structure should look this way:

-Celestia install folder
  |
  |-----extras
		  |Moon16KVT.ssc
		  |-----Moon16KVT
  			  |-----textures
				 |-----medres
					|-----Moon16KVT
						|-----level0
						|-----level1
						|-----level2
						|-----level3
						|-----level4
						|Moon16KVT.ctx
						
30/04/09 praesepe (Celestia forums, http://www.shatters.net/forum)