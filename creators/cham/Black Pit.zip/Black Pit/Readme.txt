I hate readmes, so this one will be brief.

This addon is yet another black hole representation made for Celestia.  It's the fourth black hole I've made.  The three other black holes are "Ogre", "Black EGO" and "Black Widow", which may be found at the Motherlode.

"Black Pit" is a generic black hole without any companion which may be placed anywhere in the Celestia universe.

You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  You can find the black hole at the location of the "Black Pit" barycenter.  In Celestia, type the name "Black pit", then go.  The proportions of the accretion disks and the jets, and the colors used, are not supposed to be realistic.  This is only an "artistic" interpretation of a black hole.

This addon is completely free and can be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my textures for any commercial purposes.

Many thanks to Jestr, which made the 3ds modeling for me.

I'll be glad to hear any opinion or critics about this addon, on the Celestia forum.

I apologise for the Bad English.

  Martin Charest (known as Cham, in the Celestia forum)
  12 january 2005