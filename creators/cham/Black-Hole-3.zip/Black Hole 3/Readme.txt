This is version 2 of another personal interpretation of a black hole, with a pulsar companion.

You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  You can find the system around the location of the "Black Widow" barycenter.  In Celestia, type the name "Black Hole", or "Black Widow/Black Hole", then go.  The proportions and colors are grossely exagerated, for aesthetical reasons.

This addon is completely free and can be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my textures for any commercial purposes.

Thanks to Jestr, which made the jets models for me.

I'll be glad to hear any opinion or critics about this addon, on the Celestia forum.

I apologise for the Bad English.

  Martin Charest (known as Cham, in the Celestia forum)
  10 january 2005