
1. INTRODUCTION
This addon is a field lines representation of Earth's dipolar magnetic field.  It also shows some typical trajectories followed by the charged particles trapped in our magnetic field (mostly protons and helium nucleus), which forms the basis of the Van Allen radiation belts.  Moreover, some aurora storms have been included in the addon.  Take note that the magnetic field lines depicted don't take into account any solar wind effect.  It's a pure dipolar field only, so it's not an accurate description of the real magnetic field around our planet.

The particles trajectories have been calculated using Mathematica.  For those of you that are curious about the calculations made, I'm giving a Mathematica notebook with this addon (see the "Documentation" directory).  Of course, you must own a copy of Mathematica to be able to use this file.

Take note that I've disactivated a seventh path in the Magnetic-Paths.ssc file.  You may be interested in seeing it by removing the # in front of each line.

2. HOW TO USE
You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  In Celestia, just type in the name "Magnetic Earth", then go.  

3. LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.  I apologize for the bad English.

  Martin Charest, martin465@sympatico.ca (known as "Cham", on the Celestia forum)
  September 2006