
� INTRODUCTION
This addon is a rough schematic representation of Europa's interior.  I made it as
a live illustration for my astronomy courses with Celestia.  I've created a fake star
called "Sol 2", located at 1000 LY from the real Sol, so we can show some stuff
without interfering with our real star.


� HOW TO USE
You must have Celestia 1.4.1 or later to be able to use properly this addon.  To use it,
just drop this directory into your "extras" folder.  In Celestia, just type in the name
"Sol 2/Europa - Internal structure" (English version) or "Sol 2/Europe - Structure interne"
(French version), then go.  The three billboards shown on the model are defined with a
separate model, so you can remove them easily if you wish to see Europa's interior without
the billboards.  You can also use the billboards on another moon or planet if you want to
(of course, you'll have to change the pictures accordingly, and beware to the textures
proportions).  I've  also placed a fake asteroid belt around Sol 2, which could be handy.
The asteroid belt model was made using the Mathematica software.

Take note that I'm using two 2048x2048 pixels jpeg textures on the surface of Europa,
so your video card may have some problems displaying them.  Downsampling the textures
to 1024x1024 may help, or try to convert them to DDS and edit accordingly the europa.3ds
file using a text editor.


� LICENCE AND CREDITS
This addon is free and may be edited as you wish, but only if it's related to Celestia
and education.  No commercial activities are allowed.  If you distribute this addon,
this readme.txt must imperatively accompany the addon.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

  Martin Charest, martin465@sympatico.ca (known as "Cham", on the Celestia forum)
  May 2007