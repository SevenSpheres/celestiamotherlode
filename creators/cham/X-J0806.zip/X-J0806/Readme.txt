
� INTRODUCTION
This small addon is a representation of two white dwarfs located at about 1600 LY from our sun and rotating at a fast rate (5 min 30 sec) around their common barycenter.  They are called RX J0806.3+1527.  Their accretion disk is the source of some intense x-rays radiation.  I made this addon from the information found on this web page (seek out the nice animation there, which is showing the gravitationnal waves emmited by the system) :

http://chandra.harvard.edu/photo/2005/j0806/index.html


� HOW TO USE
You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  You can find the white dwarfs at the location of the "J0806" barycenter.  In Celestia, type the name "J0806", then go.  I suggest to use a 10x or 100x time scale, to reveal the rotation in a more spectacular way.  Take note : The proportions of the accretion disk, and the colors used, may not be accurate.  This is only an "artistic" interpretation of the white dwarfs binary.


� LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my texture or the model for any commercial purposes.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.  I apologise for the Bad English.

  Martin Charest (known as Cham, on the Celestia forum)
  June 2005