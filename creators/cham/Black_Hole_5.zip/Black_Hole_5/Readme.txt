
� INTRODUCTION
"Black�Naught" is yet another black hole.  This addon is very much alike the fourth black hole addon I made for Celestia ("Black�Pit"), but is more sophisticated.  The other black holes ("Ogre", "Black�EGO", "Black�Widow" and "Black�Pit") may be found on the Motherlode at this web page :

http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=71


� HOW TO USE
You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  You can find the black hole at the location of the "Black�Naught" barycenter.  In Celestia, type the name "Black�Naught", then go.  The proportions of the accretion disks and the jets, and the colors used, are not supposed to be realistic.  This is only an "artistic" interpretation of a black hole.


� KNOWN PROBLEMS
This addon is graphics intensive and may slow down Celestia pretty much.  Depending on your video card, animation could be choppy.

I had to do a lot of compromises with this addon, because of Celestia's inability to draw models properly if they're using many transparencies effects.  At first, I placed a dying star with a nice mesh and lots of solar flares moving on it, near the black hole.  The scene was pretty spectacular.  However, while moving around the black hole and its companion, I was experiencing some intermittent disparitions of objects in front of others.  Also, the solar flares weren't properly showing, depending of my view point.  Those problems are related to the fact that Celestia 1.4 currently does not depth sort models very well, especially if the models are using many transparent surfaces.  I implore Chris Laurel to address this issue somewhere in the near future.  So I removed the star and made another lonely black hole with its accretion disk, which may be interpreted as the star cadaver.  O well ...


� LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my textures or the models for any commercial purposes.

Many thanks to ElChristou, which made one of the 3ds models for me.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

I apologise for the Bad English.

  Martin Charest (known as Cham, on the Celestia forum)
  March 2005