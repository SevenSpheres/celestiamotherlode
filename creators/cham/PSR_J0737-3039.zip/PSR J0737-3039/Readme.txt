
� INTRODUCTION
This small addon is a representation of two real pulsars located at about 1800 LY from our sun and moving at a fast rate around their common barycenter (2 hours 27 min).  They are called PSR 0737-3039.  Since their discovery in 2004, they became famous among the astronomers and the astrophysicists, because of their ultra-relativistic behavior.  I made this addon from the recent data given to me by one of the discoverers (Micheal Kramer).  If you are interested in pulsars, I suggest that you read the documentation given with this addon.

� HOW TO USE
You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  In Celestia, just type in the name "PSR J0737-3039 AB", then go.  You will notice that some magnetic field lines are shown around both pulsars.


� LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my texture or the models for any commercial purposes.  Many thanks to Selden Ball who helped me to make the magnetic field model into a CMOD version.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.  I apologise for the bad English.

  Martin Charest, martin465@sympatico.ca (known as "Cham", on the Celestia forum)
  September 2006