
� INTRODUCTION
This small addon adds a fictious nebulae around 6 pulsars :

PSR J0006+1834PSR J0609+2130PSR J1932+1059PSR J0835-4510PSR J2144-3933PSR J0040+5716

You need to install the pulsars addon first, located on this page :

http://www.shatters.net/forum/viewtopic.php?t=11372

� HOW TO USE
just drop the pulsars_nebulae directory into your "Extras" folder.  If you wish, you can edit the ssc files to place the nebulae where you want them to be, but you must know how to do it properly.

� KNOWN PROBLEMS
There are two ways to define nebulae in Celestia.  Normally, they should be declared in some .dsc file.  But then, with tons of nebulae everywhere in space, it can slow down Celestia to a crawl and I hate that.  So I defined all the nebulae as ssc objects instead.  The FPS is much faster this way.  However, if you try to click on a background star to leave the system where's the nebula is located, you will select the nebula instead.  This is a small annoying problem and there's nothing I can do about it.  All the nebulae should be looking fine from the INSIDE only.  If you place yourself outside a nebula, you'll see it as a dull spherical bubble with an hard edge.


� LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my textures or the models for any commercial purposes.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

I apologise for the Bad English.

  Martin Charest (known as Cham, on the Celestia forum)
  December 2007