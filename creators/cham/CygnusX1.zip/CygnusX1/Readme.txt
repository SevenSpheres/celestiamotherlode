
� INTRODUCTION
"Black�Abyss" and "Cygnus X1" are yet two other black holes made exclusively for Celestia.  Cygnus X1 is a real black hole of about 8 solar masses orbiting around HD 226868.  "Black Abyss" is a fictious black hole.  This addon is very much alike the fifth black hole addon I made for Celestia ("Black�Naught").  The other black holes ("Ogre", "Black�EGO", "Black�Widow", "Black�Pit" and "Black�Naught") may be found on the Motherlode at this location :

http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=71

Take note : there are two "easter eggs" in the Cygnus X1 system.  I hope you'll like them.

� HOW TO USE
You must have Celestia 1.4.x to be able to use properly this addon.  To use it, just drop this directory into your "Extras" folder.  You can find one black hole at the location of the "Black�Abyss" barycenter, and "Cygnus X1" near the star HD 226868, which is in the Celestia database.  In Celestia, type the name "Black�Abyss", or "HD 226868", then go.  The proportions of the accretion disks and the jets, and the colors used, are not supposed to be realistic.  This is only an "artistic" interpretation of a black hole.


� KNOWN PROBLEMS
This addon is graphics intensive and may slow down Celestia pretty much.  Depending on your video card, animation could be choppy.


� LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my textures or the models for any commercial purposes.  I used three textures made by Rassilon for his Mira system.  I didn't changed their file name so they are easy to identify in the textures folder.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

I apologise for the Bad English.

  Martin Charest (known as Cham, on the Celestia forum)
  March 2005