
� INTRODUCTION
This addon places two futuristic space stations around Mars.  They are SF stuff only, and aren't supposed to be very realistic.  The first one, called "Mars Relay Station", is supposed to represent a future "plausible" relay station for future Mars explorers.  I've tried to add some solar pannels on it, but the result wasn't aesthetically pleasing, so I decided to remove them.  The second space station is a variation of the first, without any logos or flags, and is more SF like.  Use it as you wish, for Celestia only.


� HOW TO USE
You must have Celestia 1.4.x or later to use properly this addon.  Just drop this directory into your "Extras" folder.  You can find both space stations around Mars.  The ssc was only made to show off the models.  Edit as you wish.

� LICENCE AND CREDITS
This addon is completely free of charges and may be used as you wish, but only if it's related to Celestia and education.  You may NOT use the textures or the models for any commercial purposes.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

I apologise for the Bad English.

  Cham
  November 2005