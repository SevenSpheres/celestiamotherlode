
� INTRODUCTION
In my personal opinion, Kubrick's 2001 A Space Odyssey is probably the best movie ever made.  I don't even think someone could do better in the future !  While there are some great models already available on the internet, I wasn't satisfied with the Discovery model and its service pod.  So I decided to build my own Discovery for Celestia, based on the one available and located there :

http://www.celestiamotherlode.net/catalog/fic_2001.php

At first, I just wanted to add some details here and there.  However, I ended rebuilding all the thing from scratch, using few parts of the models found there :

http://www.strafe.com/2001/

The service pod was converted from LightWave format to 3ds by Jestr.  The original model comes from that web site :

http://www.lwg3d.org

That model had tons of defects and holes, probably caused by the conversion process.  So I had to do a lot of works in order to repair the mesh.


� HOW TO USE
Just drop this directory into your "Extras" folder.  IMPORTANT�: If you already have another version of the Discovery and its pod installed, you should remove them before starting Celestia.  I'm using the same ssc files as for the older models.

� KNOWN PROBLEMS
The models contain a lot of details and they may reduce your FPS pretty much.  Depending on your video card, animation may be very choppy.  Also, I don't recommend using those models if you don't have FSAA enabled (Full Scene AntiAliasing).  The Discovery looks horrible without antialiasing.


� LICENCE
This addon is completely free of charges.  However, it CANNOT be used for any commercial activities.


I'll be glad to hear any opinion or critics about the models on the Celestia forum :

http://shatters.net/forum/

I apologise for the Bad English.

  Martin Charest (known as Cham, on the Celestia forum)
  September 2005