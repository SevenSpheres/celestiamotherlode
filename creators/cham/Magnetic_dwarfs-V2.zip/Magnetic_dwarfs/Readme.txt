
� INTRODUCTION
This addon shows several fictious tide locked white dwarfs binaries located at about 1500 LY from our sun and rotating at a fast rate around their common barycenter (rotation periods of 8.6 min and 13 min).  I made this addon to illustrate the superposition principle of magnetic fields, for the case of two simple dipolar magnetic fields.  I was also inspired by the real white dwarfs binary RX J0806.3+1527.

The orbital motion obeys Kepler's third law, and the white dwarfs have a mass below the Chandrasekhar limit (M_chandra = 1.44 Sol).  Read the STC and SSC files for more details.  White dwarfs are dying stars which may have a very strong magnetic field with a dominant dipolar component.  The magnetic field models used for this addon may not be very accurate (they should include some quadrupole components, since the stars are oblate), but they are nonetheless a good "first order" representation of reality.  Since the field is time-dependent (rotating sources), some electromagnetic radiation should be produced.  However, the rotation rate is low enough for the radiation to be negligible and I'm only showing the dominant "near zone" magnetic field, close to the sources.

In the case of two binaries, I'm showing the typical helicoidal trajectory of some charged particles moving in the magnetic field, as defined by the NON-INERTIAL observer rotating with the white dwarfs (thus the trajectory of the particles is steadily moving with the binary).  Gravity, non-inertial "pseudo-forces" effects (Coriolis and centrifugal forces) and special relativity theory were taken into account to find the trajectories.  For the needs of the numerical computation, I used a Carbon 12 nucleus moving at 80% light speed and an isotope moving at 10% light speed.  The magnetic field strength was set to about 120 gauss (0.012 tesla) on a star surface.  On a real white dwarf, the field may actually be much stronger.  However, this leads to much smaller, barely visible loops on a particle's trajectory unless its velocity is very close to the light speed.  The first particle is taking less than 50 sec to move along the purple curve while the second one (slower) is taking 171 sec (2 min 51 sec).  In the case of the fifth binary, the particle is taking 21 sec to travel on the path shown, with a velocity of 80% light speed.

Take note that an optional trajectory file for a charged particle is included in the "extras" folder ("chargedParticle4c.cmod").


� HOW TO USE
You must have Celestia 1.4.x or later to be able to use properly this addon.  To use it, just drop this directory into your "extras" folder.  You can find the white dwarfs near the location of the "Magnetic Dwarfs" barycenters.  In Celestia, type the name "Magnetic Dwarfs" and select the one you want to see (there are five magnetic dwarfs binaries that should be presented at the bottom of your screen), then go.  I suggest to use a 10x or 100x time scale, to reveal the rotation in a more spectacular way.


� LICENCE AND CREDITS
This addon is free and may be edited as you wish, but only if it's related to Celestia.  No commercial activities are allowed.  The CMOD magnetic field models were done with the Mathematica software.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

  Martin Charest (known as Cham, on the Celestia forum)
  February 2007
