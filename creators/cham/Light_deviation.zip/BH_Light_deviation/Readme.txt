
� INTRODUCTION
This addon illustrates the deflection of light close to a black hole.  The yellow, orange and purple curves shown in Celestia are some true trajectories followed by light moving close to a Schwarzschild black hole.  For the needs of the numerical resolution, I chose a black hole of 1.4 solar mass.  However, this can easily be changed by a simple radius scaling in the SSC files, if you want to set a bigger black hole.  In the case of "Black Hole 2", there's a punctual source of purple light placed at 12 km from the black hole (see below) and a massive particle was pitched at 100 km with an initial velocity of 10% light speed (measured by a locally stationary observer).  In a way similar to the planet Mercury, the particle follows a rosette-like trajectory.

The red transparent ball around both black holes represents their "photosphere" (critical zone of photon capture).  The small black sphere is the "event horizon" of the black hole.

Take note that we can't actually define the distance, in an absolute manner, between an object and the singularity located at the center of the black hole.  The 12 km and 100 km given above are really just radial coordinate values and should NOT be interpreted as the distance to the center of the small black sphere (likewise, the famous "Schwarzschild radius" R = 2GM/c^2 isn't even the "size" of the black hole!  It's just a parameter).  Celestia is using the "cartesian isotropic coordinates" to place an object in space and Euclidean geometry to evaluate a distance, and supposes that it is independent of the observer's motion.  In relativity theory, geometry of space isn't Euclidean near the black hole and the distance to the "event horizon", measured by some stationary observers, is actually 16.98 km for the purple light source and 109.4 km for the initial position of the particle.

The paths models (photon and massive particle trajectories) were built using the Mathematica software.  For more information about Schwarzschild black holes and some of the maths used, see this web page :

http://www.astro.ku.dk/~cramer/RelViz/text/geom_web/node3.html


� HOW TO USE
You must have Celestia 1.4.x (or later) to be able to use properly this addon.  To use it, just drop this directory into your "extras" folder.  You can find the black holes on a stationary location close to the star "HD 217224".  In Celestia, type "HD 217224/Black Hole 1" (or "HD 217224/Black Hole 2" for an alternate model), then go.  Take note that there are no real black holes around this star.  I chose it only as an arbitrary place to show the models.


� LICENCE AND CREDITS
This addon is free and may be edited as you wish, but only if it's related to Celestia.  No commercial activities are allowed.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

  Martin Charest (known as Cham, on the Celestia forum)
  January 2007