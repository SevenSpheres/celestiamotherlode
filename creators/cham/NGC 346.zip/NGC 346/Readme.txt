This addon place a billboard in space to show the nice nebula located in NGC 346, near the Small Magellanic Cloud.  The picture was taken by the Hubble space telescope.  More info can be found at this web site :

http://hubblesite.org/newscenter/newsdesk/archive/releases/2005/04/fastfacts/

Just drop this directory inside your Extras folder, and launch Celestia.  Type "NGC 346" and Go.


  - Martin Charest (known as Cham, in the Celestia forum)
    23 january 2005