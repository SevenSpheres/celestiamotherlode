
� INTRODUCTION
This addon shows the approximate internal structure of our planet.  I made this model specifically
for my astronomy courses.  There's a French, English and Italian version of the same model.

� HOW TO USE
You must have Celestia 1.4.x or later to be able to use properly this addon.  To use it, just drop
this directory into your "extras" folder.  In Celestia, find the truncated Earth at the location
of "Structure de la Terre" (French version), "Earth's interior" (English version) and "Struttura
della Terra" (Italian version).  You can modify the SSC file to adapt it to your needs, if you wish.

� LICENCE AND CREDITS
This addon is free and may be edited as you wish, but only if it's related to Celestia.  No commercial
activities are allowed with this addon.  Thanks to Fenerit, who motivated me to do this addon after he
made his own English version.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

  Martin Charest (known as Cham, on the Celestia forum)
  February 2007
