SALVATORE MULLIRI - TOR � 2007 by SALVATORE MULLIRI. All Rights reserved.

TOR - TOROIDAL ALIEN HABITAT, STARSHIP + SPACESHIP MAGELLANO + E.V.A. ASTRONAUT

Name:

tor2026.zip

Description:

Fictional rendez-vous between a giant alien starship and the ship Magellano near the  asteroids belt, from the blog-novel TOR (http://www.tor.splinder.com), simulated for Celestia.

Requirements:

Celestia version 1.3.2 or higher.

Installation:

Unzip the files and place the "tor" folder in your Celestia "extra" folder.
Start Celestia, set the time to "03 november 2026", go to the star browser and select TOR (or Magellano) to view the close encounter.

Note: 

These files are fictional, and do not represent e real event.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Author:

Salvatore Mulliri (3D and web designer)

Nick:

aquatarkus

E-mail:

info@salvatoremulliri.it

Homepage:

http://wwww.