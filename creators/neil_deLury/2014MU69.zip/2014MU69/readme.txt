2014 MU69

Compiled By: Neil DeLury (neil.delury@gmail.com)
v1.0 - 17 Sep 2016

Based on data from: 
http://www.minorplanetcenter.net/db_search/show_object?object_id=2014+MU69

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

2014 MU69 (aka PT1,1110113Y) is a Trans-Neptunian Object and a Classical KBO. It is the target for a flyby by the New Horizons probe on 01 Jan 2019.

This package is free to redistribute or re-use elsewhere.

To install, unzip this folder to your Celesta addons folder.