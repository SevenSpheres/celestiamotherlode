This is a flat nebula image which represents the Milky Way galaxy;
 it is a composite of several images cut and pased and merged together, mostly derived from the M51 galaxy,
 placed over a diagram of the Milky Way galaxy by R Powell
Original here
http://anzwers.org/free/universe/milkyway.html

to display it unzip the file into the extras folder in the Celestia program and run Celestia, 
enabling galaxies to be visible. It is best viewed from about 100,000 light years away.

this nebula is displayed on the billboard created by Selden Ball for his graticule addon.
Free for non commercial use
steve bowers