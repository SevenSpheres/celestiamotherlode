This ship was designed by Juan C Ochoa for the Orion's Arm Scenario
 http://www.orionsarm.com

The Halo Drive consists of milliions of tiny warp bubbles coupled by gravity to the ship; the warp bubbles attempt to move off into space and drag the ship in real space after them, at a speed which can approach that of light.



This add-on is intended to be used with other Orions Arm Universe add-ons.  However, general non-commercial use is granted.

Additional lights for this model have been added by Steve Bowers.