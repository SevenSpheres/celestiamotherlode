This is a new asteroid habitat model designed to go with the
Orion's Arm universe;
http://www.orionsarm.com

 once installed you will find these habitats by searching the solar systems of the stars Tau Ceti and Gamma Pavonis.

Free for non-commercial use;
made by steve bowers