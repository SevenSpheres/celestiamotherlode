Alternative brown dwarf texture

To install: simply extract image files into Clestia's texture folders hires, medres, lores and replace the browndwarf textures already there. 

Hope you enjoy

Dustin

