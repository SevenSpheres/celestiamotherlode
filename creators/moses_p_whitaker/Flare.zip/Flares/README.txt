In this package are five gradient flares made with Gimp(an open-source image editing program).

Installation: (Windows)

Copy the desired flare into the medres folder in the Celestia directory, and then take away the number in the filename.

Enjoy!

Moses P. Whitaker

