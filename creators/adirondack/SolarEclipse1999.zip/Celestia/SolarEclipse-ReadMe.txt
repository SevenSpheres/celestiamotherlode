SOLARECLIPSE1999.CEL
====================

This script displays the ground-track of the core shadow of the
solar eclipse (Aug 11, 1999) in Europe.
by Ulrich "Adirondack" Dickmann, 2004 - www.celestia.de.vu/

Runs with Celestia 1.3.1+



Installation
============

Extract the file SolarEclipse1999.cel to the Celestia directory
(...\Celestia\) or any other directory you want.

