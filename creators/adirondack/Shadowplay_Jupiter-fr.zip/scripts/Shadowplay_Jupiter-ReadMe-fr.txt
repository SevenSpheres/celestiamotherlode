*************************************************************************************
*                                                                                   *
*                   Shadowplay_Jupiter-fr.celx V1.0 - 09/04/2005                    *
*                                                                                   *
*               Script original par Ulrich Dickmann (aka Adirondack)                *
*                                                                                   *
*                               pour Celestia v1.3.2                                *
*                                                                                   *
*                                                                                   *
*************************************************************************************
* Adaptation en Fran�ais : Jeam Tag, Mai 2005                                       *
*************************************************************************************
*                                                                                   *
* Aucunes textures additionnelles ni autres fichiers ne sont requis pour ce script. *
* Lancez simplement le d�marrage du sc�nario depuis votre installation de base      *
* Celestia 1.3.2.                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Installation:                                                                     *
* Extraire le fichier 'Shadowplay_Jupiter-fr.celx' dans le r�pertoire principal de  *
* Celestia ou dans le sous-dossier '...\Celestia\scripts\', si vous en avez un.     *
* Je recommande chaudement cette derni�re option, pour simplifier le rangement et   *
* l'extraction de tous les sc�narios dans un m�me dossier \scripts\                 *
*                                                                                   *
* Lorsque vous d�compressez ce pack avec votre programme (par ex. WinZip), cliquez  *
* sur "Extraire" et s�lectionnez le r�pertoire principal de Celestia (...\Celestia\)*
* comme destination.                                                                *
* Assurez-vous d'avoir coch� l'option "Extraire les fichiers avec le chemin complet"*
* (ou similaire) pour la d�compression. Tous les fichiers (ou ceux s�lectionn�s)    *
* seront install�s directement dans le(s) sous-dossier(s) appropri�(s) de Celestia. *
* Pour faciliter les choses, le dossier \scripts\ se cr�� automatiquement lors de   *
* la d�compression du pack d�crite ci-dessus, s'il n'�xiste pas encore.             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Apr�s avoir lanc� le script, d�marrez la visite en tapant juste la touche [s].   *
* Avec la touche [Esc] vous pouvez stopper le script � tout moment.                 *
*                                                                                   *
* Quand la touche [Esc] arr�te et quitte la visite, le script essaie de r�ajuster   *
* la configuration de Celestia (i.e. - clouds, eclipse shadows, galaxies, etc.)     *
* telle qu'elle �tait avant l'ex�cution de ce sc�nario.                             *
* En quittant le script avec la touche [Esc], vous ne devriez PAS avoir a restaurer *
* vos pr�f�rences.                                                                  *
* En revanche, cette restauration ne fonctionnera pas si vous quittez le programme  *
* sans avoir d'abord utilis� cette touche [Esc] pour arr�ter le script.             *
*                                                                                   *
* Exemple:                                                                          *
* En principe vous avez les galaxies affich�es. Pour augmenter les ressources du    *
* syst�me, puisque les galaxies ne sont pas utiles � cette excursion, le script     *
* d�coche cette fonction. En fin de parcours, le script est con�u pour la           *
* restituer. (comme pour tous les param�tres qu'il a pu d�sactiver)                 *
* De sorte que vous retrouvez votre propre configuration inchang�e.                 *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* NOTE:   Ce pack avec tout son contenu est propos� pour votre SEUL USAGE PRIVE!    *
*         Toute utilisation ou distribution publique en est strictement prohib�e    *
*         sans l'approbation ECRITE de l'auteur!                                    *
*                                                                                   *
*         TOUT usage commercial est interdit!                                       *
*                                                                                   *
* Contenu (C)opyright 2005 par Ulrich Dickmann a.k.a. "Adirondack"                  *
*                                                                                   *
* Respectez ce copyright: informez-moi si vous avez l'intention d'user de ce script *
* dans une pr�sentation publique ou le distribuer. C'est tout ce que je demande.    *
* Merci! --> http://www.celestia.de.vu/                                             *
*                                                                                   *
*************************************************************************************

