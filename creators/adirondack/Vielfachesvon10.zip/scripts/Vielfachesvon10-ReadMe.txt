VIELFACHESVON10.CEL
===================

Script zum Entfernungsvergleich mit Potenzen von 10.

Lauff�hig ab Celestia 1.3.1
(erst ab 1.3.2 werden jedoch mathematischen Zeichen (= / ~ usw.)
im Text dargestellt, unter 1.3.1 fehlen diese Zeichen im Text)


Installation
============

Wenn Sie mein deutschsprachiges Upgrade installiert haben,
entpacken Sie die Datei Vielfaches von10.cel in den Ordner ...\Celestia\Scripts\

Andernfalls k�nnen Sie Datei auch z.B. in das Hauptverzeichnis von
Celestia (...\Celestia\) oder sonstwohin entpacken; Hauptsache, Sie finden
das Script sp�ter zum Aufrufen wieder! ;-)

Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf
"Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)
als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren
(in anderen Entpackprogrammen hei�t diese Option �hnlich).
Die Datei wird dann in das richtige Celestia-Unterverzeichnis
(hier: ...\Celestia\Scripts\) entpackt.