*************************************************************************************
* JupiterTour-de.cel - Version 1.05                                                 *
* F�r Celestia 1.3.2 oder h�her (eingeschr�nkt auch lauff�hig unter 1.3.1)          *
*                                                                                   *
* Dieses Script erfordert die Dateien "jupmoons2.ssc" und "Gipul.ssc" im Celestia-  *
* verzeichnis ..\Celestia\extras\ . Diese beiden Dateien sind in diesem Paket ent-  *
* halten.                                                                           *
*                                                                                   *
* Entpacken Sie die Datei JupiterTour-de.cel in das Hauptverzeichnis von Celestia   *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien jupmoons2.ssc und Gipul.ssc entpacken Sie             *
* in das Verzeichnis ...\Celestia\extras\.                                          *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* HINWEIS: Falls sich die Datei jupmoons.ssc in Ihrem Celestia\extras Ordner        *
*          befindet, m�ssen Sie diese Datei l�schen, damit das Script die Orte      *
*          aus der Datei jupmoons2.ssc in Celestia 1.3.2 korrekt anzeigen kann.     *
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf den Jupiter-Monden sehen     *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Bezugspunkte/Orte" bzw.       *
*          "Locations" den Punkt "Beschriftungen der Merkmale anzeigen" bzw.        *
*          "Label Features" aus.                                                    *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
*  Dieses Script wurde f�r Celestia 1.3.2 Pre1 und sp�tere Versionen geschrieben.   *
*          Es ist jedoch auch eingeschr�nkt lauff�hig unter 1.3.1                   *
*                                                                                   *
*                                                                                   *
* Dies ist das Minimal-JupiterTour-Paket. Wenn Sie lieber das XXL-Paket benutzen    *
* m�chten (es enth�lt verschiedene in diesem Script gebr�uchliche Texturen), laden  *
* Sie sich das JupiterTourXXL-Paket von meiner Website herunter.                    *
*                                                                                   *
*___________________________________________________________________________________*
* Credits:                                                                          *
*                                                                                   *
* jupmoons2.ssc      - Author: Grant Hutchison                                      *
*                      Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/ *
* Gipul.ssc          - Author: Bob Hegwood                                          *
* JupiterTour1.cel   - Author: Bob Hegwood                                          *
*                      Website: http://home.earthlink.net/~bobhegwood               *
* JupiterTour-de.cel - �bersetzung: Ulrich "Adirondack" Dickmann                    *
*                      Website: http://www.celestia.de.vu/                          *
*                                                                                   *
*___________________________________________________________________________________*
*                                                                                   *
*                                                                                   *
* Ich hoffe, Ihnen gef�llt dieses Script. Bob Hegwood hat �ber einen Monat f�r die  *
* Informationsrecherche und die Codierung aufgebracht! Thanks Bob!                  *                                           *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************