*************************************************************************************
*                                                                                   *
*                 SaturnTour-de.cel V1.06 - Last Revision 9-19-04                   *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                    (eingeschr�nkt auch lauff�hig unter 1.3.1)                     *
*                                                                                   *
* Last revised on 19 Sept. 04: Translation of the script (V1.05), and added info    *
*                              about two new moons. By Adirondack.                  * 
*                                                                                   *
* Dieses Script erfordert die Dateien ring_locs.ssc und satmoons2.ssc im Celestia-  *
* verzeichnis ...\Celestia\extras\ Diese beiden Dateien sind in diesem Paket ent-   *
* halten.                                                                           *
*                                                                                   *
* Entpacken Sie die Datei SaturnTour-de.cel in das Hauptverzeichnis von Celestia    *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien ring_locs.ssc and satmoons2.ssc entpacken Sie         *
* in das Verzeichnis ...\Celestia\extras\.                                          *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
* Lesen Sie jedoch weiter unten zuvor auch die Hinweise zu den Texturen!            *
*                                                                                   *
* HINWEIS: Falls sich die Datei satmoons2.ssc von Mr. Hutchison bereits in Ihrem    *
*          Celestia\extras Ordner befindet, m�ssen Sie diese Datei ersetzen, weil   *
           in der Datei in diesem Paket eine Korrektur vorgenommen wurde.           *
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf den Saturn-Monden sehen      *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
*                                                                                   *
* In diesem XXL-Paket sind �berarbeitete Texturen f�r Tethys, Mimas sowie f�r den   *
* Saturn und seine Ringe enthalten.                                                 *
* Bitte beachten Sie, dass Bob die Originaltexturen in das kleinere Format          *
* 1024 x 512 umgewandelt hat, damit diese auch auf schw�cheren PCs funktionieren.   *
* Wenn Sie h�heraufgel�ste Texturen verwenden m�chten, laden Sie sich diese von den *
* entspr. Websites (siehe Credits) herunter.                                        *
*                                                                                   *
*                                                                                   *
* Um die neuen Texturen in Celestia einzubinden, gehen Sie wie folgt vor:           *
*                                                                                   *
* 1. Entpacken Sie die Dateien Tethysc.jpg, Mimasc.jpg, Saturn.jpg und              *
*    SaturnRings.png in das Verzeichnis ..\Celestia\textures\medres .               *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, werden  *
*    die Textur-Dateien automatisch in das richtige Verzeichnis entpackt.           *
*                                                                                   *
* 2. Anschl. m�ssen Sie die Datei solarsys.ssc modifizieren, damit die neuen        *
*    Texturen von Celestia benutzt werden. Sie finden die Datei solarsys.ssc im     *
*    Ordner ..\Celestia\data\ .                                                     *
*    Beachten Sie, dass diese Datei nach dem Abspeichern weiterhin die Dateiendung  *
*    .SSC tragen muss! Wenn Sie sie als solarsys.ssc.txt abspeichern, funktioniert  *
*    sie nicht mehr.                                                                *
*    �ffnen Sie die Datei mit einem Texteditor (z.B. Notepad) und nehmen folgende   *
*    �nderungen darin vor:      				                    *
*                                                                                   *
*    A. Unter dem Datensatz "Saturn" "Sol" �ndern Sie die Textur-Definition wie     *
*       folgt: Texture - "Saturn.jpg" - Beachten Sie die Gro�schreibung von 'S'     *
*                                                                                   *
*    Anmerkung von Ulrich: Meines Erachtens m�ssen Sie diese Modifikation nicht     *
*    zwingend vornehmen, weil die Texturen identisch sind und Windows nicht         *
*    zwischen Saturn.jpg und saturn.jpg unterscheiden kann.                         *
*                                                                                   *
*    B. Unter dem Datensatz "Tethys" "Sol/Saturn" �ndern Sie die Textur-Definition  *
*       wie folgt: Texture - "Tethysc.jpg"                                          *
*                                                                                   *
*    C. Unter dem Datensatz "Mimas" "Sol/Saturn" �ndern Sie die Textur-Definition   *
*       wie folgt: Texture - "Mimasc.jpg"                                           *
*                                                                                   *
*    ALTERNATIVE:                                                                   *
*    Wenn Sie m�chten, k�nnen Sie die neuen Texturen auch im Bedarfsfall "nur"      *
*    zuschalten. Dann brauchen Sie die Datei solarsys.ssc NICHT modifizieren.       *
*    Sie klicken dann bei Bedarf einfach mit einem Rechtsklick auf den Saturn und   *
*    w�hlen im erscheinenden Kontextmen� "SaturnTour" aus! Daraufhin werden die     *
*    neuen Texturen von Celestia angezeigt (sofern Sie diese wie unter 1. be-       *
*    schrieben in das Verzeichnis ..\Celestia\textures\medres eingef�gt haben).     *
*    Damit Sie eine Auswahl der Texturen �ber das Kontextmen� von Saturn vornehmen  *
*    k�nnen, hat Bob die gesonderte Datei SaturnTour.ssc geschrieben, die Sie in    *
*    das Verzeichnis ..\Celestia\extras\ entpacken m�ssen.                          *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, wird    *
*    die Datei SaturnTour.ssc automatisch in das richtige Verzeichnis entpackt.     *
*    Sie k�nnen anschl. die neuen Texturen einschalten, ohne das Script ausf�hren   *
*    zu m�ssen. Wenn Sie wieder Ihre alten Texturen angezeigt haben m�chten,        *
*    w�hlen Sie einfach im Kontextmen� von Saturn die Option "Normal" aus.          *
*                                                                                   *
* 3. Wenn auch die Saturn-Ringe angezeigt werden sollen, m�ssen Sie nun noch        *
*    folgende Modifikaton in der Datei solarsys.ssc vornehmen:                      *
*                                                                                   *
*    A. Unter dem Datensatz "Saturn" "Sol" f�gen Sie folgende Zeilen                *
*    hinzu oder �ndern die ggf. bereits bestehenden Zeilen wie folgt:               *
*                                                                                   *
*               Rings {                                                             *
*               Inner   74660                                                       *
*               Outer  140220                                                       *
*               Texture "SaturnRings.png"                                           *
*               Color  [ 1.0 0.88 0.82 ]                                            *
*                     }                                                             *
*                                                                                   *
*    Beachten Sie, dass Sie diese Modifikation auch dann vornehmen m�ssen, wenn Sie *
*    die alternative Kontextmen�-Variante benutzen wollen!                          *
*                                                                                   *
* HINWEIS von Ulrich:                                                               *
* Sie k�nnen die in der solarsys.ssc bereits vorhandenen Zeilen f�r die Ringe auch  *
* so belassen, wie sie sind. Bob's o.g. Definition der Ringe macht die Ringe        *
* jedoch deutlicher erkennbar. Meines Erachtens ist es eine Frage des pers�nlichen  *
* Geschmacks, ob Sie die solarsys.ssc in Bezug auf die Ringe �ndern oder nicht.     *
* Im Zweifel nehmen Sie die von Bob vorgeschlagene �nderung nicht vor.              *
*                                                                                   *
* __________________________________________________________________________________*                                                                               
* Credits:                                                                          *
*                                                                                   *
* Mimasc.jpg     - Author: Original USGS map revised by Grant Hutchison.            *
*                  Revisions: Bob Hegwood - Recolored.                              *
* ring_locs.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
* satmoons2.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
*                  Revisions: Bob Hegwood - Corrected location of Latium Chasma     *
*                                           with blessings from Jennifer Blue at    *
*                                           USGS and Grant Hutchison.               *
* Saturn.jpg     - Author: Bjorn Jonnson                                            *
*                  Website: http://www.mmedia.is/~bjj/                              *
*                  Revisions: Bob Hegwood - Resized to 1024 x 512.                  *
* SaturnRings.png- Author:  Jens (Jim) Meyer                                        *
*                  Website: http://home.arcor.de/jimpage                            *
*                  Revisions: Bob Hegwood - Resized to 1024 x 2.                    *
* SaturnTour.ssc - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
* SaturnTour.cel - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
* Tethysc.jpg    - Author: Original USGS map revised by Grant Hutchison.            *
*                  Revisions: Bob Hegwood - Recolored.                              *
* SaturnTour-de.cel - �bersetzung: Ulrich "Adirondack" Dickmann                     *
*                     Website: http://www.celestia.de.vu/                           *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************