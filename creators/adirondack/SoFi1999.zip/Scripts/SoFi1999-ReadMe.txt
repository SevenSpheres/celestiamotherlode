SOFI1999.CEL
============

Script zum Kernschattenverlauf der Sonnenfinsternis am 11.08.1999
von Ulrich "Adirondack" Dickmann, 2004 - www.celestia.de.vu/

Lauff�hig ab Celestia 1.3.1



Installation
============

Wenn Sie mein deutschsprachiges Upgrade installiert haben,
entpacken Sie die Datei SoFi1999.cel in den Ordner ...\Celestia\Scripts\

Andernfalls k�nnen Sie Datei auch z.B. in das Hauptverzeichnis von
Celestia (...\Celestia\) oder sonstwohin entpacken; Hauptsache, Sie finden
das Script sp�ter zum Aufrufen wieder! ;-)

Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf
"Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)
als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren
(in anderen Entpackprogrammen hei�t diese Option �hnlich).
Die Datei wird dann in das richtige Celestia-Unterverzeichnis
(hier: ...\Celestia\Scripts\) entpackt.