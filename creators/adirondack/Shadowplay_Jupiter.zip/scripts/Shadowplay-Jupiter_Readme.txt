*************************************************************************************
*                                                                                   *
*                     Shadowplay-Jupiter.celx V1.0 - 04/09/2005                     *
*                                                                                   *
*           Original Celestia script by Ulrich Dickmann (aka Adirondack)            *
*                                                                                   *
*                                for Celestia 1.3.2                                 *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* You don't need additional textures or other files to run this script.             *
* Simply run this shadowplay on Jupiter with your basic installation of             *
* Celestia 1.3.2.                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Extract the file 'Shadowplay-Jupiter.celx' into the main folder of Celestia or    *
* into the subfolder '...\Celestia\scripts\', if you have such a folder. I would    *
* recommend that you store your scripts in a folder like \scripts\ just so they're  *
* easier to keep track of.                                                          *
*                                                                                   *
* When you unzip this package using your zip program (e.g. WinZip), click on        *
* "Extract" and select the main folder of Celestia (...\Celestia\) as the target    *
* directory.                                                                        *
* Make sure that you activate the option to "Use subfolders" (or similar option)    *
* while un-packing. All (or the selected files) will be copied into the correct     *
* Celestia subfolder(s).                                                            *
* For your convenience, the \scripts\ folder is built automatically when you unzip  *
* the package as described above.                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* After you have started the script, just start the tour by pressing the key [ s ]. *
* With the key [ Esc ] you can cancel the tour at any time.                         *
*                                                                                   *
* After you have pressed [Esc] to cancel and exit the tour, the script will try to  *
* re-adjust your display preferences (i.e. - clouds, eclipse shadows, galaxies,     *
* etc.) so that they are set as they were before the execution of the script.       *
* When you exit the script by pressing [Esc], you should NOT have to reset your     *
* preferences.                                                                      *
* This re-adjustment will not work, when you exit Celestia without pressing [Esc]   *
* at first to exit the script.                                                      *
*                                                                                   *
* Example:                                                                          *
* In principle you have switched ON the galaxies. The script however switches the   *
* galaxies OFF, since galaxies are not needed during the tour and unnecessarily the *
* system performance would increase. With terminating the tour now the script tries *
* to switch ON the galaxies again (and reset all further settings the script maybe  *
* has changed). And all settings will be like they were before.                     *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* NOTICE: This package and all contents are provided for your PRIVATE USE ONLY!     *
*         Any Public performance or distribution of this script is strictly         *
*         prohibited without the WRITTEN permission of the author!                  *
*                                                                                   *
*         ANY Commercial use is prohibited!                                         *
*                                                                                   *
* All contents (C)opyright 2004 by Ulrich Dickmann a.k.a. "Adirondack"              *
*                                                                                   *
* Please respect this copyright and inform me if you wish to show this script in    *
* a planned public performance or if you wish to distribute it. That's all I want.  *
* Thank you! --> http://www.celestia.de.vu/                                         *
*                                                                                   *
*************************************************************************************