*************************************************************************************
*                                                                                   *
*                               NeptunTour-de.cel V1.03                             *
*                                                                                   *
*                     Original Celestia script von Bob Hegwood                      *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
*                     Translation of the script by Adirondack.                      *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* In diesem XXL-NeptunTour-Paket sind �berarbeitete Texturen f�r Neptun, Triton und *
* Proteus enthalten (neptune-correct.jpg, triton.jpg und proteus.jpg).              *
* Bei diesen �berarbeitetn Texturen handelt es sich um 2K-Texturen f�r Neptun und   *
* Triton sowie um eine 1K-Textur f�r Proteus.                                       *
*                                                                                   *
* ACHTUNG: Die bereits in Celestia vorhandenen Mond-Texturen werden beim Ent-       *
* packen des ZIP-Archives �berschrieben!                                            *
* Sie sollten die vorhandenen Dateien daher ggf. zuvor umbenennen oder sichern.     *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Dieses Script erfordert die Dateien nepmoons2.ssc und ring_locs.ssc im Celestia-  *
* verzeichnis ...\Celestia\extras\ Diese beiden Dateien sind in diesem Paket ent-   *
* halten.                                                                           *
*                                                                                   *
* Dar�ber hinaus befindet sich in diesem Paket eine �berarbeitete Textur f�r die    *
* Neptun-Ringe (neptune-rings.png).                                                 *
* Beachten Sie, dass andere Neptun-Ringe (mit Ausnahme der in der Basis-Version     *
* von Celestia enthaltenen Ringe) mit diesem Script NICHT funktionieren!            *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei NeptunTour-de.cel in das Hauptverzeichnis von Celestia    *
* oder in das Verzeichnis ...\Celestia\scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien ring_locs.ssc und nepmoons2.ssc entpacken Sie in das  *
* Verzeichnis ...\Celestia\extras\.                                                 *
* Die Neptun-Ringe (neptune-rings.png) entpacken Sie in das Verzeichnis             *
* ...\Celestia\textures\medres\.                                                    *
* Auch die neuen Texturen neptune-correct.jpg, triton.jpg und proteus.jpg kommen in *
* das Verzeichnis ...\Celestia\textures\medres\.                                    *
*                                                                                   *
* ACHTUNG: Die Dateien f�r Triton, Proteus und die Neptun-Ringe hei�en genauso wie  *
*          die entspr. Dateien der Celestia-Basis-Installation. Sie k�nnen diese    *
*          Dateien einfach �berschreiben, denn die in diesem Paket enthaltene       *
*          Triton-Textur ist h�her aufgel�st, die Proteus-Textur ist detailreicher  *
*          und die Neptun-Ringe sind h�her aufgel�st.                               *
*          Wenn Sie Zweifel daran haben, legen Sie sich vorher Sicherungskopien der *
*          Dateien triton.jpg und proteus.jpg an.                                   *
*          Die Datei neptune-rings.png im Verzeichnis textures\lores\ brauchen Sie  *
*          nicht zu sichern, da die Datei neptune-rings.png aus diesem Paket in     *
*          das Verzeichnis textures\medres\ entpackt wird.                          *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Um die neue Textur f�r Neptun korrekt anzeigen zulassen, haben Sie zwei M�glich-  *
* keiten: Entweder Sie �ndern einen Eintrag in der Datei solarsys.ssc oder Sie      *
* schalten die neue Textur nur im Bedarfsfall zu (empfohlen).                       *
*                                                                                   *
*    �ndern der Datei solarsys.ssc:                                                 *
*                                                                                   *
*    Sie finden die Datei solarsys.ssc im Ordner ..\Celestia\data\.                 *
*    Beachten Sie, dass diese Datei nach dem Abspeichern weiterhin die Dateiendung  *
*    .SSC tragen muss! Wenn Sie sie als solarsys.ssc.txt abspeichern, funktioniert  *
*    sie nicht mehr.                                                                *
*    �ffnen Sie die Datei mit einem Texteditor (z.B. Notepad) und nehmen folgende   *
*    �nderungen darin vor:      				                    *
*                                                                                   *
*    Unter dem Datensatz "Neptune" "Sol" �ndern Sie die Textur-Definition wie       *
*    folgt: Texture - "neptune-correct.jpg"                                         *  
*                                                                                   *
*    Empfohlene ALTERNATIVE:                                                        *
*    Wenn Sie m�chten, k�nnen Sie die neue Textur auch im Bedarfsfall "nur"         *
*    zuschalten. Dann brauchen Sie die Datei solarsys.ssc NICHT modifizieren.       *
*    Sie klicken dann bei Bedarf einfach mit einem Rechtsklick auf Neptun und       *
*    w�hlen im erscheinenden Kontextmen� "NeptuneTour" aus! Daraufhin wird die      *
*    neue Textur von Celestia angezeigt (sofern Sie diese wie weiter oben be-       *
*    schrieben in das Verzeichnis ..\Celestia\textures\medres eingef�gt haben.      *
*    Damit Sie eine Auswahl der Texturen �ber das Kontextmen� von Neptun vornehmen  *
*    k�nnen, hat Bob die gesonderte Datei NeptuneTour.ssc geschrieben, die Sie in   *
*    das Verzeichnis ..\Celestia\extras\ entpacken m�ssen.                          *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, wird    *
*    diese Datei automatisch in das richtige Verzeichnis entpackt.                  *
*                                                                                   *
*    Sie k�nnen anschl. die neue Textur einschalten, ohne das Script ausf�hren      *
*    zu m�ssen. Wenn Sie wieder Ihre alte Neptun-Textur angezeigt haben m�chten,    *
*    w�hlen Sie einfach im Kontextmen� von Neptun die Option "Normal" aus.          *
*                                                                                   *
*    HINWEIS: Beachten Sie bitte, dass die neue Neptun-Textur nicht mehr den sog.   *
*             'Gro�en Dunklen Fleck' in der Atmosph�re enth�lt (denn dieser Fleck   *
*             existiert heute nicht mehr).                                          *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Wie bereits oben erw�hnt, muss die Datei neptune-rings.png vorhanden sein. Bei    *
* Celestia 1.3.2 sollte sich diese Datei bereits im Verzeichnis \textures\lores\    *
* befinden. Es wird jedoch empfohlen, die in diesem Paket enthaltenen Ringe in das  *
* Verzeichnis \textures\medres\ zu entpacken.                                        *
*                                                                                   *
* Stellen Sie dabei ebenfalls sicher, dass sich in der Datei solarsys.ssc (sie      *
* finden diese Datei im Ordner ...\Celestia\data\) die nachfolgenden Eintr�ge in    *
* der Sektion "Neptune" "Sol" befinden:                                             *
*                                                                                   *
*    Rings      {                                                                   *
*               Inner 53150                                                         *
*               Outer 62947                                                         *
*               Texture "neptune-rings.png"                                         *
*               }                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf dem Planeten Neptun sehen    *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
* __________________________________________________________________________________*
* Credits:                                                                          *
*                                                                                   *
* neptune-correct.jpg - Dave McDonald - Thanks VERY much, Dave!                     *
*                       Email: dmgt350@aol.com                                      *
*                       Revisions: Bob Hegwood - Renamed the file. <grin>           *
* ring_locs.ssc       - Author: Grant Hutchison                                     *
*                       Website: http://www.lns.cornell.edu/~seb/celestia/hutchison *
* nepmoons2.ssc       - Author: Grant Hutchison                                     *
* neptune-rings.png   - Author: Grant Hutchison                                     *
* NeptuneTour.cel     - Author: Bob Hegwood                                         *
*                       Website: http://home.earthlink.net/~bobhegwood              *
* NeptuneTour.ssc     - Author: Bob Hegwood                                         *
* proteus.jpg         - Author: Jens Meyer                                          *
*                       Website: http://home.arcor.de/jimpage/                      *
* triton.jpg          - Author: Sorry... Unknown.                                   *
*                       Revisions: Bob Hegwood - Mirrored, flipped and converted a  *
*                                  large bitmap (.bmp) file for use with script.    *
* NeptunTour-de.cel    - �bersetzung: Ulrich "Adirondack" Dickmann                  *
*                       Website: http://www.celestia.de.vu/                         *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************