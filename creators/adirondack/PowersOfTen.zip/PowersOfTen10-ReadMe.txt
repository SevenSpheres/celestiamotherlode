PowersOfTen.celx 
Translation by Zarius, script by Ulrich Dickmann
================================================ 

Script to show the distance from Earth in powers of 10 km (eg. 10^2 = 100km,
10^4 = 10000km) away - all the way out to the Milky Way and other Galaxies (10^20). 

Requires Celestia version 1.3.2 or higher.

Installation 
============ 
 
Unpack the file PowersOfTen.celx into the directory of your choosing,
probably Celestia\Extras\Scripts\ and either double-click the file
(if Celestia is set up to handle celx files) or run Celestia and select
'Open Script' from the 'File' menu.  Load up the script and enjoy.