-- German translation of Slideshow by Ulrich Dickmann (Adirondack)
--

slideshow_loc_str =
{
	Slideshow = "Diaschau";
	["slide #"] = "Dia Nr.";
	["Missing image: "] = "Fehlendes Image: ";
	["NO SLIDE IN SLIDESHOW"] = "DIA-KATALOG IST LEER";
	["This is the last slide..."] = "Dies ist das letzte Dia...";
	["Slideshow catalog not open"] = "Unerwarteter Fehler beim Öffnen des Katalogs";
	["Image"] = "Image";
	["Text"] = "Text";
	["Background"] = "Hintergrund";
	["Border"] = "Rahmen";
	["Auto feed ON"] = "Auto-Schau EIN";
	["Auto feed OFF"] = "Auto-Schau AUS";
	["default"] = "Standard";
	["Slide duration = "] = "Dia-Dauer = ";
	["Default slides duration = "] = "Standarddauer Dia = ";
	["Slideshow ON: "] = "Aktive Diaschau: ";
	["Slideshow OFF"] = "Diaschau AUS";
	["Stealth mode"] = "Verdeckter Betrieb";
	["Stealth mode OFF"] = "Verdeckter Betrieb AUS";
	["Stealth mode ON"]  = "Verdeckter Betrieb EIN";
	["Celestia is paused"] = "Celestia pausiert";
	["Delay = "] = "Verzögerung = ";
	["Command tool hidden"] = "Das Kommandowerkzeug ist versteckt";
	["press "] = "Drücke ";
	[" to recover"] = " zum Wiederherstellen";
	["Time is paused"] = "Zeitablauf pausiert";
	["Resume"] = "Fortsetzen";
	["No slide to paste"] = "Kein Dia zum Verschieben";
	["Slideshow catalog"] = "Diaschau-Katalog";
	["New"] = "Neu";
	["Copy"] = "Kopieren";
	["Cut"] = "Ausschneiden";
	["Paste"] = "Verschieben";
	["Edit"] = "Editieren";
	["Cat."] = "Cat.";
	["OK"] = "OK";
	["Error in slide description"] = "Fehler in der Diabeschreibung";
	["(No slide defined)"] = "(Kein Dia definiert)";
	["(More than one slide)"] = "(Mehr als ein Dia)";
	["Slide is copied"] = "Dia wurde kopiert";
	["Fail to create "] = "Herstellung fehlgeschlagen ";
}
