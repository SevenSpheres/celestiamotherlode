*************************************************************************************
*                                                                                   *
*                           Venustransit2004-en.celx V1.0                           *
*                                   September 2008                                  *
*                                                                                   *
*                         Celestia-Script by Ulrich Dickmann                        *
*                                                                                   *
*                            for Celestia 1.5.1 or later                            *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* This presentation will show you the Venus transit of June 8, 2004 and explains    *
* why Venus transits occur at all.                                                  *
* The presentation lasts approximately 7 minutes.                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Extract the file 'Venustransit2004-en.celx' into Celestia's subfolder             *
* '...\Celestia\scripts\'                                                           *
*                                                                                   *
* When you unzip this package using your zip program (e.g. WinZip), click on        *
* "Extract" and select the main folder of Celestia (...\Celestia\) as the target    *
* directory.                                                                        *
* Make sure that you activate the option to "Use subfolders" (or similar option)    *
* while un-packing. The file will be copied into the correct Celestia subfolder.    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* If you did install the script correctly, you can call the presentation via        *
* File -> Scripts > -> Venus transit 2004 (EN).                                     *
*                                                                                   *
* With the key [s] you can start the presentation.                                  *
* With the key [Esc] you can cancel and exit the presentation at any time.          *
*                                                                                   *
* After you have pressed [Esc] to cancel and exit the tour, the script will         *
* re-adjust your display preferences (i.e. - clouds, eclipse shadows, galaxies,     *
* etc.) so that they are set as they were before the execution of the script.       *
* When you exit the script by pressing [Esc], you should not have to reset your     *
* preferences.                                                                      *
* This re-adjustment will not work, when you exit Celestia without pressing [Esc]   *
* at first to exit the script.                                                      *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* This script and all its contents are provided for your PRIVATE USE ONLY!          *
* Any commercial public performance or distribution of this script is strictly      *
* prohibited without the written permission of the author!                          *
*                                                                                   *
* A distribution of the script is allowable only in unchanged condition and only    *
* together with this ReadMe file.                                                   *
*                                                                                   *
* All contents � 2008 by Ulrich Dickmann (Adirondack)                               *
*                                                                                   *
* This Addon is licensed under the following Creative Commons license:              *
* Brief information: http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US    *
* Full license: http://creativecommons.org/licenses/by-nc-nd/3.0/legalcode          *
*                                                                                   *
* Please respect this copyright and inform me if you wish to show this script in    *
* a planned public performance or if you wish to distribute it. That's all I want.  *
* Thank you! --> http://www.celestia.info/                                          *
*                                                                                   *
*************************************************************************************