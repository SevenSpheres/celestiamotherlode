*************************************************************************************
*                                                                                   *
*                    MarsTour-de.cel V2.0 - Last Revision: July-8-04                *
*                 inklusive neuer Texturen f�r den Mars und seine Monde             *
*                                                                                   *
*                                                                                   *
* Das Mars Script erfordert die Dateien mars_locs2.ssc und marsmoons2.ssc in Ihrem  *
* ...\Celestia\extras\ Verzeichnis.                                                 *
* Diese beiden Dateien sind auch in diesem Package enthalten.                       *
* Entpacken Sie die Datei MarsTour-de.cel in das Hauptverzeichnis von Celestia      *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie mein deutsches Upgrade    *
* installiert haben. Die Dateien mars_locs2.ssc und marsmoons2.ssc entpacken Sie    *
* in das Verzeichnis ...\Celestia\extras\.                                          *
* Wenn Sie die Dateien mars_locs2.ssc und marsmoons2.ssc von Grant Hutchison schon  *
* besitzen, brauchen Sie die in diesem Package enthaltenen .SSC-Dateien nicht zu    *
* entpacken!                                                                        *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
*                                                                                   *
*     Dieses Script wurde zum Gebrauch mit Celestia 1.3.2 Pre8 geschrieben          *
*               Es funktioniert aber auch in der Version 1.3.1 !                    *
*                                                                                   *
*                                                                                   *                                                                                   
* In diesem XXL-Paket der Mars-Tour sind neue Texturen f�r den Mars und seine       *
* beiden Monde Phobos und Deimos sowie eine verbesserte Textur f�r die Mars-Wolken  *
* enthalten.                                                                        *
* Diese m�ssen Sie nicht zwingend installieren, um die Mars-Tour anzuschauen. Aber  *
* seien Sie versichert, dass die neuen Texturen den Mehraufwand Wert sind!          *
*                                                                                   *
* Um die neuen Texturen in Celestia einzubinden, gehen Sie wie folgt vor:           *
*                                                                                   *
* 1. Entpacken Sie zun�chst einfach die Dateien mars.jpg, phobos.jpg, deimos.jpg    *
*    und MarsClouds.png in das Verzeichnis ...\Celestia\textures\medres\.           *
*    BITTE BEACHTEN: Damit ersetzen Sie die bereits vorhandenen gleichnamigen       *
*    Dateien in diesem Verzeichnis. Fertigen Sie daher ggf. Backups dieser schon    *
*    vorhandenen Dateien an, falls Sie sie sp�ter lieber wieder benutzen m�chten.   *
*    Das wage ich zwar zu bezweifeln, aber man wei� ja nie...                       *
*                                                                                   *
* 2. Nun m�ssen Sie noch einen Abschnitt in der Datei solarsys.ssc anpassen,        *
*    damit die neuen Mars-Wolken angezeigt werden k�nnen.                           *
*    Dazu �ffnen Sie diese Datei (Sie finden diese im Ordner ...\Celestia\data\)    *
*    mit Notepad (oder einem sonstigen Text-Editor) und �ndern sie wie folgt:       *
*                                                                                   *
*    Suchen Sie den Abschnitt "Mars" "Sol". Innerhalb der Sektion "Atmosphere"      *
*    erg�nzen (oder ersetzen) Sie die folgenden Zeilen:                             *
*                                                                                   *
*               CloudHeight 10                                                      *
*               CloudSpeed 70                                                       *
*               CloudMap "MarsClouds.png"                                           *
*                                                                                   *
*    L�schen Sie dabei jedoch keinesfalls die anderen Zeilen in dieser Sektion!     *
*                                                                                   *
*    HINWEIS: Ab Celestia 1.3.2 (zum Zeitpunkt der Erstellung dieser Info-Datei in  *
*    der Entwicklung) wird es die Datei solarsys.scc ggf. nicht mehr geben.         *
*    Sollte die Datei solarsys.ssc in 1.3.2 nicht auffindbar sein, m�ssen Sie die   *
*    dann neuen SSC-Dateien nach dem Mars-Abschnitt durchsuchen.                    *
*                                                                                   *
* 3. Speichern Sie die Datei anschliessend ab (Dateierweiterung .ssc beibehalten!)  *
*                                                                                   *
* 4. Falls noch nicht geschehen, entpacken Sie die ganz oben erw�hnten Dateien      *
*    in die entsprechenden Verzeichnisse. Nun ist das Script einsatzbereit.         *  
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Credits: ________________________________________________________________________ *
*                                                                                   *
* mars.jpg          - Author: Praesepe                                              *
*	              Website:                                                      *
*                     www.la-guarida.com/Celestia/index_archivos/slide0001.htm      *
* phobos.jpg        - Author:  Jens (Jim) Meyer                                     *
*                     Website: http://home.arcor.de/jimpage/mars.html               *
*                     Revisions: Bob Hegwood - Resized to 1024 x 512.               *
* deimos.jpg        - Author:  Jens (Jim) Meyer                                     *
*                     Website: http://home.arcor.de/jimpage/mars.html               *
*                     Revisions: Bob Hegwood - Resized to 1024 x 512.               *
* MarsClouds.png    - Author:  Jens (Jim) Meyer                                     *
*                     Website: http://home.arcor.de/jimpage/mars.html               *
*                     Revisions: Bob Hegwood-Converted from DDS and then resized to *
*                                            1024 x 512.                            *
* mars_locs2.ssc    - Author: Grant Hutchison                                       *
*                     Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/  *
* marsmoons2.ssc    - Author: Grant Hutchison                                       *
* MarsTour.cel      - Author: Bob Hegwood                                           *
*                     Website: http://home.earthlink.net/~bobhegwood                *
* MarsTour-de.cel   - �bersetzung: Ulrich "Adirondack" Dickmann                     *
*                     Website: http://www.celestia.de.vu/                           * 
*                                                                                   *                                                                                 
*          ________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
*************************************************************************************