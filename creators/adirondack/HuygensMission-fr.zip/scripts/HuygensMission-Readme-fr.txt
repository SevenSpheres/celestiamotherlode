*************************************************************************************
*                                                                                   *
*                      HuygensMissionTour.cel V1.0 - 20.12.2004                     *
*                                                                                   *
*           Script original Celestia de Ulrich Dickmann (aka Adirondack)            *
*                                                                                   *
*                      Traduction en fran�ais: Pascal Buch                          *
*                                                                                   *
*                                pour Celestia 1.3.2                                *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Vous n'avez pas besoin de textures suppl�mentaires ni d'autres fichiers pour      *
* ex�cuter ce script. Simplement ex�cutez ce voyage de ma mission Huygens-Mission   *
* avec votre installation de base de Celestia 1.3.2.  mais attention ce script ne   *
* fonctionnera pas avec Celestia 1.3.1.                                             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* D�zippez le fichier 'HuygensMissionTour.cel' dans le dossier principale deCelestia*
* ou dans un sous-r�pertoire '...\Celestia\scripts\', si vous avez un tel dossier.  *
* Je vous recommanderai de stocker vos script dans un dossier genre \scripts\ il    *
* vous sera plus facile de garder la trace de vos scripts.                          *
*                                                                                   *
* Lorsque vous d�zippez ce paquetage en utilisant votre programme zip (ex. WinZip), *
* cliquez sur "Extraire" et s�lectionnez le dossier principal de Celestia           *
* (...\Celestia\) comme cible                                                       *
*                                                                                   *
* V�rifiez que vous avez activ� l'option "Utiliser les sous-dossiers" (ou une       *
* option similaire) lors de la d�compression. Tous (ou les fichiers s�lectionn�s)   *
* seront copi�s dans le(s) sous-r�pertoire(s) correct(s).                           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* NOTE : Ce paquetage et tout son contenu sont fournis pour SEULEMENT VOTRE USAGE   *
*         PRIVE ! Toute pr�sentation publique ou distribution de ce script est      *
*         strictement interdit dans l'autorisation ECRITE de l'auteur !             *
*                                                                                   *
*         TOUT usage commercial est interdit !                                      *
*                                                                                   *
* Tout contenu (C)opyright 2004 de Ulrich Dickmann a.k.a. "Adirondack"              *
*                                                                                   *
* SVP respectez ce copyright et informez-moi si vous souhaitez montrer ce script au *
* cours d'une repr�sentation publique programm�e ou si vous souhaitez le distribuer.*
* C'est tout ce que je veux ! Merci! --> http://www.celestia.de.vu/                 *
*                                                                                   *
*************************************************************************************
