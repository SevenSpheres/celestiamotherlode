*************************************************************************************
*                                                                                   *
*                       +------------------------------------+                      *
*                       |        Orbitaldaten des HST        |                      *
*                       |         Epoche: 08.02.2006         |                      *
*                       |------------------------------------|                      *
*                       |      Keplerian elements of HST     |                      *
*                       |         Epoch: 02/08/2006          |                      *
*                       +------------------------------------+                      *
*                                                                                   *
*                                   by Adirondack                                   *
*                                                                                   *
*                                                                                   *
*                         English description follows below!                        *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Leider sind die Bahndaten des HST selbst in Celestia 1.4.x v�llig veraltet, denn  *
* sie stammen noch vom 28.04.2001.                                                  *
* Dies hat zur Folge, dass das HST in Celestia an einer inzwischen v�llig falschen  *
* Position oberhalb der Erde dargestellt wird.                                      *
* Dies hat schon h�ufig zu "Reklamationen" seitens der Anwender gef�hrt.            *
*                                                                                   *
* In der Datei hst.ssc habe ich daher aktuellere Bahnelemente des HST eingebunden,  *
* so dass die Position des HST in Celestia zur angegebenen Epoche (s.o.) ann�hernd  *
* korrekt ist.                                                                      *
*                                                                                   *
* Eine absolut korrekte Positionierung in Celestia ist indes nicht m�glich, da die  *
* Beschaffenheit der Erde wesentlich komplizierter ist, als dies mit Celestia       *
* simuliert werden kann.                                                            *
* Insofern kann eine Sichtbarkeit des HST mit Celestia nicht korrekt vorhergesagt   *
* werden (mal davon abgesehen, dass das HST in Deutschland aufgrund seiner Bahn-    *
* neigung (Inklination) von rd. 28,5� sowieso nicht gesehen werden kann).           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei hst.ssc einfach in den Unterordner \extras\.              *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* Es schadet �brigens nicht, wenn Sie auch diese ReadMe mit �bernehmen, so stehen   *
* Ihnen auch sp�ter die hier enthalteten Informationen zur Verf�gung.               *
*                                                                                   *
* Ver�nderungen an bestehenden .SSC-Dateien sind NICHT erforderlich! Wenn Sie die   *
* Datei hst.ssc entpackt haben und Celestia anschl. neu starten, werden die neuen   *
* Bahndaten des HST sofort von Celestia benutzt.                                    *
* Beachten Sie jedoch, dass die Datei hst.ssc nur mit Celestia 1.3.2 oder h�her     *
* funktioniert. In Celestia 1.3.1 k�nnen Sie sie nicht verwenden!                   *
*                                                                                   *
* Ich werde gelegentlich weitere aktualisierte Bahndaten bereitstellen. Wenn Sie    *
* ein aktuelleres Zip-Archiv entpacken, wird die darin enthaltene Datei hst.ssc die *
* vorhandene hst.ssc beim Entpacken �berschreiben und Celestia ist wieder auf dem   *
* neuesten Stand.                                                                   *
*                                                                                   *
*************************************************************************************
*************************************************************************************
*                                                                                   *
* Unfortunately the keplerian elements (orbital data) of the HST are absolutely     *
* out of date even within Celestia 1.4.x, because the data are from 04/28/2001.     *
* Because of the obsolete data, nowadays the position of the HST is wrong in        *
* Celestia. A lot of users often complained this inaccuracy.                        *
*                                                                                   *
* So now I provide updated orbital data with this hst.ssc to set the HST to an      *
* approximate position for the given epoch.                                         *
*                                                                                   *
* Please note, that Celestia models the shape of the Earth using a spheroid. The    *
* actual shape of our planet is much more complicated. As a result, a view from     *
* the Earth's surface in Celestia is not accurate enough to show the correct path   *
* across the sky of satellites in low Earth orbits (like the HST). In other words,  *
* you can't use Celestia to find out where to look in the sky to see the HST!       *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Extract the file hst.ssc into your \extras\ subfolder.                            *
*                                                                                   *
* When you unzip this package using your zip program (e.g. WinZip), click on        *
* "Extract" and select the main folder of Celestia (...\Celestia\) as the target    *
* directory.                                                                        *
* Make sure that you activate the option to "Use subfolders" (or similar option)    *
* while un-packing. All (or the selected files) will be copied into the correct     *
* Celestia subfolder.                                                               *
*                                                                                   *
* BTW: It's a good idea to extract this ReadMe too. Sooner or later you maybe want  *
* to read this information once again.                                              *
*                                                                                   *
* You DO NOT have to modify any existing .SSC files! After you have extract the     *
* file hst.ssc, just restart Celestia and the new keplerian elements are active.    *
* But note, that this hst.ssc only works with Celestia 1.3.2 or higher. You can't   *
* use it with Celestia 1.3.1.                                                       *
*                                                                                   *
* Now and then I will provide new updated orbital data. When you un-pack an updated *
* zip-package, the contained hst.ssc will overwrite the existing older one and      *
* Celestia is up to date again.                                                     *
*                                                                                   *
*************************************************************************************