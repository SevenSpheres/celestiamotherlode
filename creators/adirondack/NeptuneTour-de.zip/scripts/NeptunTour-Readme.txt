*************************************************************************************
*                                                                                   *
*                               NeptunTour-de.cel V1.03                             *
*                                                                                   *
*                     Original Celestia script von Bob Hegwood                      *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
*                     Translation of the script by Adirondack.                      *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Dies ist das Minimal-NeptunTour-Paket. Wenn Sie lieber das XXL-Paket benutzen     *
* m�chten (es enth�lt �berarbeitete Texturen f�r Neptun, Triton und Proteus), laden *
* Sie sich das NeptunTourXXL-Paket von meiner Website herunter:                     *
* (http://www.celestia.de.vu/).                                                     *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Dieses Script erfordert die Dateien nepmoons2.ssc und ring_locs.ssc im Celestia-  *
* verzeichnis ...\Celestia\extras\ Diese beiden Dateien sind in diesem Paket ent-   *
* halten.                                                                           *
*                                                                                   *
* Dar�ber hinaus befindet sich in diesem Paket eine �berarbeitete Textur f�r die    *
* Neptun-Ringe (neptune-rings.png).                                                 *
* Beachten Sie, dass andere Neptun-Ringe (mit Ausnahme der in der Basis-Version     *
* von Celestia enthaltenen Ringe) mit diesem Script NICHT funktionieren!            *
*                                                                                   *
* Wenn Sie hochaufl�sendere Texturen f�r Neptun und Triton verwenden m�chten (damit *
* sind Details, insbesondere auf Triton, besser erkennbar), laden Sie sich das      *
* XXL-Paket von meiner Website herunter.                                            *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei NeptunTour-de.cel in das Hauptverzeichnis von Celestia    *
* oder in das Verzeichnis ...\Celestia\scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien ring_locs.ssc und nepmoons2.ssc entpacken Sie in das  *
* Verzeichnis ...\Celestia\extras\.                                                 *
* Die Neptun-Ringe (neptune-rings.png) entpacken Sie in das Verzeichnis             *
* ...\Celestia\textures\medres\.                                                    *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Wie bereits oben erw�hnt, muss die Datei neptune-rings.png vorhanden sein. Bei    *
* Celestia 1.3.2 sollte sich diese Datei bereits im Verzeichnis \textures\lores\    *
* befinden. Es wird jedoch empfohlen, die in diesem Paket enthaltenen Ringe in das  *
* Verzeichnis \textures\medres\ zu entpacken.                                       *
*                                                                                   *
* Stellen Sie dabei ebenfalls sicher, dass sich in der Datei solarsys.ssc (sie      *
* finden diese Datei im Ordner ...\Celestia\data\) die nachfolgenden Eintr�ge in    *
* der Sektion "Neptune" "Sol" befinden:                                             *
*                                                                                   *
*    Rings      {                                                                   *
*               Inner 53150                                                         *
*               Outer 62947                                                         *
*               Texture "neptune-rings.png"                                         *
*               }                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf dem Planeten Neptun sehen    *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
* __________________________________________________________________________________*
* Credits:                                                                          *
*                                                                                   *
* ring_locs.ssc       - Author: Grant Hutchison                                     *
*                       Website: http://www.lns.cornell.edu/~seb/celestia/hutchison *
* nepmoons2.ssc       - Author: Grant Hutchison                                     *
* neptune-rings.png   - Author: Grant Hutchison                                     *
* NeptuneTour.cel     - Author: Bob Hegwood                                         *
*                       Website: http://home.earthlink.net/~bobhegwood              *
* NeptunTour-de.cel    - �bersetzung: Ulrich "Adirondack" Dickmann                  *
*                       Website: http://www.celestia.de.vu/                         *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************