*************************************************************************************
*                                                                                   *
*                VenusTour.celx V3.01 - Letzte Revision 23.08.2008                  *
*                                                                                   *
*                     Original Celestia script by Bob Hegwood                       *
*                                                                                   *
*                                F�r Celestia 1.5.1                                 *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Venus-Tour (DE) - Tour zur Venus (Deutsche Fassung)                               *
* Lauff�hig mit Celestia 1.5.1                                                      *
* Laufzeit: ca. 16 Min.                                                             *
* Original cel script von Bob Hegwood, 18. Juli 2008                                *
* Deutsche �bersetzung & Modifikationen von Ulrich Dickmann, 22./23. August 2008    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! Kommerzielle �ffentliche Auff�hrung oder Vetrieb   *
* des Addons auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung der     *
* Urheber zul�ssig!                                                                 *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs-/Vetriebsabsichten: http://www.celestia.info/     *
*                                                                                   *
* Dieses Addon ist im �brigen unter folgender Creative Commons Lizenz lizensiert:   *
*         http://creativecommons.org/licenses/by-nc-nd/3.0/de/deed.de               *
* Vollst�ndigee Lizenz-Text:                                                        *
*         http://creativecommons.org/licenses/by-nc-nd/3.0/de/legalcode             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei 'VenusTour-de.celx' in den Ordner ...\Celestia\scripts\   *
* Die �brigen Unterordner des ZIP-Archives entpacken Sie bitte in das Verzeichnis   *
* ...\Celestia\extras\.                                                             *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Dieses VenusTour-Paket enth�lt neben der eigentlichen Tour ('VenusTour-de.celx')  *
* auch neue Texturen f�r die Venus sowie ein Modell der Sonde "Venus Express".      *
* Falls Sie die neuen Venus-Texturen nicht verwenden m�chten, l�schen Sie einfach   *
* die Datei 'venus_tour.ssc' im Ordner '...\extras\venus_tour\'.                    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Wenn Sie diese Tour wieder von Ihrem Computer entfernen m�chten, l�schen Sie      *
* einfach die Datei 'VenusTour-de.celx' im Verzeichnis ...\Celestia\scripts\        *
* und l�schen zudem den Ordner '\venus_tour\' im Verzeichnis ...\Celestia\extras\.  *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Credits:                                                                          *
*                                                                                   *
* Neue Venus-Texturen   - John Van Vliet                                            *
*                         Website: N.N.                                             *
* Venus Express Modell  - Jestr                                                     *
*                         Website: N.N.                                             *
* venustour.cel         - Author: Bob Hegwood                                       *
*                         Website: http://home.woh.rr.com/bhegwood/                 *
* VenusTour-de.celx     - �bersetzung: Ulrich "Adirondack" Dickmann                 *
*                         Website: http://www.celestia.info/                        *
*                                                                                   *
*************************************************************************************