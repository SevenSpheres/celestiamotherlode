*************************************************************************************
*                                                                                   *
*                     HuygensMissionTour-de.cel V1.0 - 20.12.2004                   *
*                                                                                   *
*                     Original Celestia script by Ulrich Dickmann                   *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* F�r diese Huygens-Mission Tour sind keine zus�tzlichen Texturen oder weitere      *
* Dateien erforderlich. Sie k�nnen diese Tour mit der Basis-Installation von        *
* Celestia 1.3.2 ansehen. Mit Celestia 1.3.1 ist dies jedoch NICHT m�glich!         *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei HuygensMissionTour-de.cel in das Hauptverzeichnis von     *
* Celestia oder in das Verzeichnis ...\Celestia\scripts\, wenn Sie ein solches      *
* Verzeichnis angelegt haben.                                                       *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Die Datei wird dann in das richtige Celestia-Unterverzeichnis (hier: \scripts\)   *
* entpackt.                                                                         *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf Saturn und Titan sehen       *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! �ffentliche Auff�hrung oder Vetrieb des Scriptes   *
* auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung des Urhebers       *
* zul�ssig!                                                                         *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs- oder Vetriebsabsichten!                          *
* --> http://www.celestia.de.vu/                                                    *
*                                                                                   *
*************************************************************************************