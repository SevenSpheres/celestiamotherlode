NEUNPLANETEN_v1.0.CELX
======================

Script zur Darstellung der unterschiedlichen Rotaionsgeschwindigkeiten
der neun Planeten in unserem Sonnensystem.

Lauff�hig ab Celestia 1.3.2

Originalscript: Harald Schmidt (nineplanets_v1.0.celx)
Deutsche Fassung: Ulrich "Adirondack" Dickmann



Installation
============

Entpacken Sie die Datei NeunPlaneten.celx z.B. in einen Unterordner wie
...\Celestia\Scripts\
In einem speziellen Unterordner haben Sie alle Scripts gesammelt vorliegen
und k�nnen sie so ohne gro�e Suche dort wiederfinden.

Sie k�nnen die Datei auch z.B. in das Hauptverzeichnis von
Celestia (...\Celestia\) oder sonstwohin entpacken; Hauptsache, Sie finden
das Script sp�ter zum Aufrufen wieder! ;-)

Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf
"Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)
als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren
(in anderen Entpackprogrammen hei�t diese Option �hnlich).
Die Datei wird dann in das richtige Celestia-Unterverzeichnis
(hier: ...\Celestia\Scripts\) entpackt.