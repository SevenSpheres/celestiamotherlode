*************************************************************************************
*                                                                                   *
*                                PlutoTour-de.cel V2.02                             *
*                                                                                   *
*                     Original Celestia script von Bob Hegwood                      *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
*                     Translation of the script by Adirondack.                      *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Sie ben�tigen f�r diese Tour keine weiteren Texturen. Es funktioniert einwandfrei *
* mit der Basis-Installation von Celestia 1.3.2 und nutzt die vorhanden Texturen.   *
* Bob Hegwood bietet zwar auch eine erweiterte Version der Pluto-Tour an, darin     *
* sind jedoch nur Texturen enthalten, die bereits in der Basisversion 1.3.2 ent-    *
* halten sind und nur f�r den Fall mitgeliefert werden, falls jemand nachtr�glich   *
* falsche Texturen nachinstalliert hatte (was wohl schon vorgekommen sein soll).    *
* Wenn Sie also an den Limit-Of-Knowledge-Texturen f�r Pluto und Charon nichts ver- *
* �ndert haben, bringt ihnen die erweiterte Tourversion nichts!                     *
* Ich biete aus diesem Grund zur Pluto-Tour keine XXL-Version an. Sollten Sie       *
* falsche Texturen nachinstalliert haben, laden Sie sich das "Enhanced package" der *
* Pluto-Tour von http://www.celestiamotherlode.net/catalog/scripts.php herunter und *
* binden die darin enthaltenen Texturen ein (...\textures\medres\).                 *
*                                                                                   *
* HINWEIS:                                                                          *
* Stellen Sie vor der Ausf�hrung des Scripts sicher, dass Sie in Celestia das An-   *
* zeigen von Planeten-Orbits erm�glichen. Dazu muss diese Option im Men� unter      *
* 'Darstellung' -> 'Anzeige-Optionen' im Feld 'Orbits/Bezeichnungen anzeigen' mit   *
* einem H�kchen in der Checkbox 'Orbit' f�r Planeten aktiviert sein.                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei PlutoTour-de.cel in das Hauptverzeichnis von Celestia     *
* oder in das Verzeichnis ...\Celestia\scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben oder meine deutsche Programmversion benutzen.                      *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* Es schadet �brigens nicht, wenn Sie auch diese ReadMe mit �bernehmen, so stehen   *
* Ihnen auch sp�ter die hier enthalteten Informationen zur Verf�gung.               *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* __________________________________________________________________________________*
* Credits:                                                                          *
*                                                                                   *
* PlutoTour.cel        - Author: Bob Hegwood                                        *
*                        Website: http://www.bobhegwood.com                         *
* PlutoTour-de.cel     - �bersetzung: Ulrich "Adirondack" Dickmann                  *
*                        Website: http://www.celestia.de.vu/                        *
* _________________________________________________________________________________ *
*                                                                                   *
*************************************************************************************