*************************************************************************************
*                                                                                   *
*                     Schattenspiel-Jupiter.celx V1.0 - 09.04.2005                  *
*                                                                                   *
*               Original Celestia script by Ulrich "Adirondack" Dickmann            *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* F�r das Schattenspiel auf Jupiter sind keine zus�tzlichen Texturen oder weitere   *
* Dateien erforderlich. Sie k�nnen diese Tour mit der Basis-Installation von        *
* Celestia 1.3.2 ansehen.                                                           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei Schattenspiel-Jupiter.celx in das Hauptverzeichnis von    *
* Celestia oder in das Verzeichnis ...\Celestia\scripts\, wenn Sie ein solches      *
* Verzeichnis angelegt haben.                                                       *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Die Datei wird dann in das richtige Celestia-Unterverzeichnis (hier: \scripts\)   *
* entpackt.                                                                         *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nach dem Start des Scripts, k�nnen Sie durch Dr�cken der Taste [s] die Tour       *
* starten. Mit [Esc] k�nnen Sie jederzeit die Tour abbrechen.                       *
*                                                                                   *
* Das Script wird nach Beendigung oder einem Abbruch der Tour versuchen, die        *
* Einstellungen der Darstellung (wie Wolken, Finsternisse, Galaxien usw.) wieder so *
* einzustellen, wie sie vor der Ausf�hrung des Scripts von Ihnen definiert waren.   *
* Sie m�ssen also nach der Ausf�hrung des Scripts Ihre Einstellungen nicht selbst   *
* wieder anpassen, sofern diese Einstellungen vom Scripts umgestellt worden sein    *
* sollten.                                                                          *
* Das Zur�cksetzen der Einstellungen funktioniert nicht, wenn Sie Celestia beenden, *
* ohne vorher mit [Esc] das Script beendet zu haben.                                *
*                                                                                   *
* Beispiel:                                                                         *
* Sie haben grunds�tzlich die Galaxien eingeschaltet. Das Script schaltet die       *
* Galaxien jedoch ab, da diese w�hrend der Tour nicht ben�tigt werden und nur       *
* unn�tig Rechenleistung in Anspruch nehmen w�rden. Beim Beenden des Scripts wird   *
* nun versucht, die Galaxien (und alle weiteren ver�nderten Einstellungen) wieder   *
* einzurichten. Alles sollte also wieder so eingestellt sein, wie es vorher war.    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! �ffentliche Auff�hrung oder Vetrieb des Scriptes   *
* auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung des Urhebers       *
* zul�ssig!                                                                         *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs- oder Vetriebsabsichten!                          *
* --> http://www.celestia.de.vu/                                                    *
*                                                                                   *
*************************************************************************************