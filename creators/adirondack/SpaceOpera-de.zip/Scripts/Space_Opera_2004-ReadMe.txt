*************************************************************************************
* Space_Opera_2004-de.cel - F�r Celestia 1.3.1 oder h�her.                          *
*                                                                                   *
* Mit Hilfe dieses Scripts fliegen Sie aus dem tiefen Raum in die Milchstrasse,     *
* in unser Sonnensystem und besuchen die neun klassischen Planeten.                 *
*                                                                                   *
* Einzelne, detaillierte und eingehendere "Planetenbesuche" finden Sie auf meiner   *
* Website! Dort stehen verschiedene Touring-Scripts in minimalen und erweiterten    *
* Versionen zum Domnload bereit. --> http://www.celestia.de.vu/                     *
*                                                                                   *
*                                                                                   *
* Entpacken Sie die Datei Space_Opera_2004-de.cel in das Hauptverzeichnis von       *
* Celestia oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches      *
* Verzeichnis angelegt haben.                                                       *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Die Datei wird dann in das richtigen Celestia-Unterverzeichniss entpackt.         *
*                                                                                   *
* HINWEIS:                                                                          *
* Damit w�hrend der Tour die Umlaufbahnen zeitweise angezeigt werden k�nnen, m�ssen *
* Sie in den "Anzeige-Optionen" (im Men� "Darstellung" bzw. "Render") im Anzeige-   *
* feld "Orbits/Bezeichnungen" einen Haken im Orbit-K�stchen der Planeten setzen!    *
*                                                                                   *
* __________________________________________________________________________________*                                                                                   *
* Credits:                                                                          *
*                                                                                   *
* so.cel (Original script)	- Author: Paul Swennenhuis, Jan 2004                *
*                      		  p.a.m.swennenhuis@eccoo.rug.nl                    *
* SpaceOpera-de.cel		- �bersetzung: Ulrich "Adirondack" Dickmann         *
*                      		  Website: http://www.celestia.de.vu/               *
*                                                                                   *
* __________________________________________________________________________________*
*                                                                                   *
*************************************************************************************