*************************************************************************************
*                                                                                   *
*                       +------------------------------------+                      *
*                       |        Orbitaldaten der ISS        |                      *
*                       |         Epoche: 08.02.2006         |                      *
*                       |------------------------------------|                      *
*                       |      Keplerian elements of ISS     |                      *
*                       |         Epoch: 02/08/2006          |                      *
*                       +------------------------------------+                      *
*                                                                                   *
*                                   by Adirondack                                   *
*                                                                                   *
*                                                                                   *
*                         English description follows below!                        *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Leider sind die Bahndaten der ISS selbst in Celestia 1.4.x v�llig veraltet, denn  *
* sie stammen noch vom 28.04.2001.                                                  *
* Dies hat zur Folge, dass die ISS in Celestia an einer inzwischen v�llig falschen  *
* Position oberhalb der Erde dargestellt wird.                                      *
* Dies hat schon h�ufig zu "Reklamationen" seitens der Anwender gef�hrt.            *
*                                                                                   *
* In der Datei iss.ssc habe ich daher aktuellere Bahnelemente der ISS eingebunden,  *
* so dass die Position der ISS in Celestia zur angegebenen Epoche (s.o.) ann�hernd  *
* korrekt ist.                                                                      *
*                                                                                   *
* Eine absolut korrekte Positionierung in Celestia ist indes nicht m�glich, da sich *
* die Bahndaten der ISS aufgrund div. Umst�nde (z.B. Gewicht [Treibstoffverbrauch,  *
* Nutzlast usw.], Anhebung des Orbits, Reibungswiderst�nde u.a.) stetig ver�ndern   *
* und die Beschaffenheit sowie die auf die ISS einwirkenden Kr�fte der Erde         *
* wesentlich komplizierter sind als dies mit Celestia simuliert werden kann.        *
* Insofern kann eine Sichtbarkeit der ISS mit Celestia nicht korrekt vorhergesagt   *
* werden.                                                                           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei iss.ssc einfach in den Unterordner \extras\.              *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* Es schadet �brigens nicht, wenn Sie auch diese ReadMe mit �bernehmen, so stehen   *
* Ihnen auch sp�ter die hier enthalteten Informationen zur Verf�gung.               *
*                                                                                   *
* Ver�nderungen an bestehenden .SSC-Dateien sind NICHT erforderlich! Wenn Sie die   *
* Datei iss.ssc entpackt haben und Celestia anschl. neu starten, werden die neuen   *
* Bahndaten der ISS sofort von Celestia benutzt.                                    *
* Beachten Sie jedoch, dass die Datei iss.ssc nur mit Celestia 1.3.2 oder h�her     *
* funktioniert. In Celestia 1.3.1 k�nnen Sie sie nicht verwenden!                   *
*                                                                                   *
* HINWEIS:                                                                          *
* Sie m�ssen die "orientation" �ndern, wenn Sie ein anderes Modell der ISS be-      *
* nutzen (statt dem Standard-Modell aus der Basis-Version 1.4.x) oder wenn Sie die  *
* ISS NICHT am gegebenen Epochen-Datum betrachten. Sonst ist die Ausrichtung der    *
* ISS nicht korrekt.                                                                *
* In diesem Fall �ffnen Sie die Datei iss.ssc und �ndern die Einstellung f�r die    *
* Ausrichtung (orientation) der ISS --> siehe iss-orientation.txt.                  *
*                                                                                   *
* Ich werde gelegentlich weitere aktualisierte Bahndaten bereitstellen. Wenn Sie    *
* ein aktuelleres Zip-Archiv entpacken, wird die darin enthaltene Datei iss.ssc die *
* vorhandene iss.ssc beim Entpacken �berschreiben und Celestia ist wieder auf dem   *
* neuesten Stand.                                                                   *
*                                                                                   *
*************************************************************************************
*************************************************************************************
*                                                                                   *
* Unfortunately the keplerian elements (orbital data) of the ISS are absolutely     *
* out of date even within Celestia 1.4.x, because the data are from 04/28/2001.     *
* Because of the obsolete data, nowadays the position of the ISS is wrong in        *
* Celestia. A lot of users often complained this inaccuracy.                        *
*                                                                                   *
* So now I provide updated orbital data with this iss.ssc to set the ISS to an      *
* approximate position for the given epoch.                                         *
*                                                                                   *
* Please note, that Celestia models the shape of the Earth using a spheroid. The    *
* actual shape of our planet is much more complicated. As a result, a view from     *
* the Earth's surface in Celestia is not accurate enough to show the correct path   *
* across the sky of satellites in low Earth orbits (like the ISS). In other words,  *
* you can't use Celestia to find out where to look in the sky to see the ISS!       *
* Also the orbit of the ISS changes continuously in ways that are almost impossible *
* to predict due to things like atmospheric drag, light pressure, payload, weight   *
* of propellant etc.                                                                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Extract the file iss.ssc into your \extras\ subfolder.                            *
*                                                                                   *
* When you unzip this package using your zip program (e.g. WinZip), click on        *
* "Extract" and select the main folder of Celestia (...\Celestia\) as the target    *
* directory.                                                                        *
* Make sure that you activate the option to "Use subfolders" (or similar option)    *
* while un-packing. All (or the selected files) will be copied into the correct     *
* Celestia subfolder.                                                               *
*                                                                                   *
* BTW: It's a good idea to extract this ReadMe too. Sooner or later you maybe want  *
* to read this information once again.                                              *
*                                                                                   *
* You DO NOT have to modify any existing .SSC files! After you have extract the     *
* file iss.ssc, just restart Celestia and the new keplerian elements are active.    *
* But note, that this iss.ssc only works with Celestia 1.3.2 or higher. You can't   *
* use it with Celestia 1.3.1.                                                       *
*                                                                                   *
* NOTE:                                                                             *
* You have to modify the orientation if you use an other ISS model instead of the   *
* basic model that comes with Celestia 1.4.x or if you view the ISS NOT at the      *
* given epoch-date! Otherwise the orientation of the ISS is wrong.                  *
* In this case just open the file iss.ssc and modify the setting of orientation.    *
* --> see iss-orientation.txt.                                                      * 
*                                                                                   *
* Now and then I will provide new updated orbital data. When you un-pack an updated *
* zip-package, the contained iss.ssc will overwrite the existing older one and      *
* Celestia is up to date again.                                                     *
*                                                                                   *
*************************************************************************************