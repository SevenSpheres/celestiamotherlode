*************************************************************************************
*                                                                                   *
*                   VenusTour-de.cel V1.02 - Last Revision 12-27-04                 *
*                                                                                   *
*                     Original Celestia script by Bob Hegwood                       *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
* Last revised on Dec. 27 2004: Translation of the script (V1.02) by Adirondack.    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* In diesem XXL-VenusTour-Paket sind zwei �berarbeitete Texturen f�r die Venus      *
* enthalten (venus.jpg und venussurface.jpg).                                       *
* Bei diesen �berarbeitetn Texturen handelt es sich um eine 2K-Textur der Venus-    *
* oberfl�che und eine 1K-Textur f�r die Venuswolken.                                *
*                                                                                   *
* ACHTUNG: Die beiden bereits in Celestia vorhandenen Texturen werden beim Ent-     *
* packen des ZIP-Archives �berschrieben!                                            *
* Sie sollten die vorhandenen Dateien daher ggf. zuvor umbenennen oder sichern.     *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei VenusTour-de.cel in das Hauptverzeichnis von Celestia     *
* oder in das Verzeichnis ...\Celestia\scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Datei venus_locs2.ssc entpacken Sie in das Verzeichnis        *
* ...\Celestia\extras\.                                                             *
*                                                                                   *
* Die Venus-Texturen (venus.jpg und venussurface.jpg) entpacken Sie in das          *
* Verzeichnis ...\Celestia\textures\medres\                                         *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf der Venus sehen              *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
* __________________________________________________________________________________*
* Credits:                                                                          *
*                                                                                   *
* venus_locs2.ssc  - Author: Grant Hutchison                                        *
*                    Website: http://www.lns.cornell.edu/~seb/celestia/hutchison    *
* venus.jpg        - Author: NASA\JPL\Seal Copyright-free image.                    *
*                    Website: http://solarviews.com/cap/venus/venuscyl4.htm         *
* venussurface.jpg - Author: Praesepe                                               *
*                    Website:                                                       *
*                    http://www.la-guarida.com/Celestia/index_archivos/slide0001.htm*
*                    Revised by Bob Hegwood to correct Central Meridian.            *
* VenusTour.cel    - Author: Bob Hegwood                                            *
*                    Website: http://home.earthlink.net/~bobhegwood                 *
* VenusTour-de.cel - �bersetzung: Ulrich "Adirondack" Dickmann                      *
*                    Website: http://www.celestia.de.vu/                            *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************