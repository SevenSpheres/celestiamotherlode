*************************************************************************************
*                                                                                   *
*                   HuygensMissionTour-de.celx V1.0 (Gro�e Tour)                    *
*              Komplettpaket mit neuen Modellen von Cassini & Huygens               *
*            Original Celestia script von Ulrich "Adirondack" Dickmann              *
*                                                                                   *
*                                f�r Celestia 1.3.2                                 *
*                                                                                   *
*************************************************************************************
* Bitte beachten Sie, dass diese Tour mit Celestia 1.3.1. nicht funktioniert!       *
*************************************************************************************
*                                                                                   *
* Wenn Sie bereits meine HuygensMissionTour-de.cel (V1.0 - 20.12.2004) installiert  *
* haben, k�nnen Sie diese l�schen. Sie w�rde mit den Modellen, die Sie mit diesem   *
* Paket installieren nicht mehr einwandfrei funktionieren.                          *
* Keine Angst, der Inhalt der bisherige HuygensMissionTour-de.cel ist in der nun    *
* vorliegenden Tour enthalten.                                                      *
*                                                                                   *
* Diese Tour enth�lt viel mehr Informationen �ber die Cassini-Huygens-Mission,      *
* einschlie�lich des Abstiegs von Huygens auf Titan. Jestr's beeindruckende Modelle *
* des Orbiters und der (landenden) Sonde sind in diesem Komplettpaket enthalten.    *
* Falls Sie bereits Jestr's Modelle installiert haben, brauchen Sie diese Modelle   *
* nat�rlich nicht nochmal installieren.                                             *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* INSTALLATION                                                                      *
* ============                                                                      *
*                                                                                   *
* Klicken Sie in Ihrem Entpackprogramm (z.B. WinZip) auf "Extrahiere" und w�hlen    *
* das Hauptverzeichnis von Celestia (...\Celestia\) als Ziel aus. Aktivieren Sie    *
* die Option "Pfadangaben verwenden" (in anderen Entpackprogrammen hei�t diese      *
* Option �hnlich) und starten den Entpackvorgang.                                   *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* Sie finden das Touring-Script in dem Ordner mit dem Namen \scripts\.              *
* Dieser \scripts\ Ordner wird automatisch angelegt, wenn Sie das Paket wie oben    *
* beschrieben entpacken.                                                            *
* Wenn Sie meine deutsche Programmversion von Celestia installiert haben, ist Ihnen *
* dieser Ordner ja bereits gel�ufig.                                                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* BENUTZUNG DES SCRIPTS                                                             *
* =====================                                                             *
*                                                                                   *
* Die gesamte Tour besteht aus 4 Teilen in einer interaktiv kontrollierbaren        *
* CELX-Datei:                                                                       *
*                                                                                   *
* Teil 1 = Missionsvorschau (dies ist die fr�her ver�ffentlichte Tour, aktualisiert *
*          und angepasst an Jestr's Cassini-Modell),                                *
* Teil 2 = Der Abstieg von Huygens (mit Hauptfallschirm, Abstiegsphase 1),          *
* Teil 3 = Huygens' wissenschaftliche Nutzlast (Beschreibung der Experimente, mit   *
*          Fallschirmphase 2),                                                      *
* Teil 4 = Erforschung des Cassini-Orbiter und einige seiner Vorrichtungen.         *
*                                                                                   *
* Gesamtlaufzeit dieser Pr�sentation (alle Teile): etwa 62 Minuten.                 *
*                                                                                   *
* Sie k�nnen w�hlen, welchen Teil der Tour Sie laufen lassen m�chten (wenn das      *
* Script gestartet wurde und nachdem jeweils ein Teilabschnitt beendet ist)!        *
*                                                                                   *
* Nach dem Start des Scripts (und nachdem jeweils ein Teil der Tour abgeschlossen   *
* ist), k�nnen Sie durch Dr�cken der Tasten [1] bis [4] oberhalb der Tastatur       *
* (NICHT im Ziffernblock!) den gew�nschten Teil der Tour starten.                   *
* Mit der Taste [c] k�nnen Sie den n�chsten Teil der Tour beginnen.                 *
* Mit [Esc] k�nnen Sie jederzeit die Tour abbrechen und beenden.                    *
*                                                                                   *
* Das Script wird nach Beendigung oder einem Abbruch der Tour versuchen, die        *
* Einstellungen der Darstellung (wie Wolken, Finsternisse, Galaxien usw.) wieder so *
* einzustellen, wie sie vor der Ausf�hrung des Scripts von Ihnen definiert waren.   *
* Sie m�ssen also nach der Ausf�hrung des Scripts Ihre Einstellungen nicht selbst   *
* wieder anpassen, sofern diese Einstellungen vom Scripts umgestellt worden sein    *
* sollten.                                                                          *
* Das Zur�cksetzen der Einstellungen funktioniert nicht, wenn Sie Celestia beenden, *
* ohne vorher mit [Esc] das Script beendet zu haben.                                *
*                                                                                   *
* Beispiel:                                                                         *
* Sie haben grunds�tzlich die Galaxien eingeschaltet. Das Script schaltet die       *
* Galaxien jedoch ab, da diese w�hrend der Tour nicht ben�tigt werden und nur       *
* unn�tig Rechenleistung in Anspruch nehmen w�rden. Beim Beenden des Scripts wird   *
* nun versucht, die Galaxien (und alle weiteren ver�nderten Einstellungen) wieder   *
* einzurichten. Alles sollte also wieder so eingestellt sein, wie es vorher war.    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Hinweis (betrifft die kommende Celestia-Version 1.4.0)                            *
* ======================================================                            *
*                                                                                   *
* Wenn Sie dieses Script sp�ter mit Celestia 1.4.0 ausf�hren, beachten Sie bitte    *
* folgendes:                                                                        *
*                                                                                   *
* In Teil 1 dieser Tour werfen wir einen Blick auf Titan's Oberfl�che, um zu sehen, *
* was wir �ber die Oberfl�chenbeschaffenheit wissen, BEVOR Huygens und Cassini dort *
* waren.                                                                            *
* In Celestia 1.4.0 wird wahrscheinlich eine neue Textur der Oberfl�che enthalten   *
* sein, so dass Sie in Celestia 1.4.0 auf eine Titan Oberfl�che blicken, NACHDEM    *
* Huygens und Cassini dort waren.                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! �ffentliche Auff�hrung oder Vetrieb des Scriptes   *
* auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung des Urhebers       *
* zul�ssig!                                                                         *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs- oder Vetriebsabsichten!                          *
* --> http://www.celestia.de.vu/                                                    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Vielen Dank an Jestr f�r die beeindruckenden Modelle, an Harald Schmidt, der mir  *
* zeigte, wie man das interaktive Auswahlmen� kodiert und (zu guter Letzt) an Bob   *
* Hegwood und Don Goyette (diese pr�chtigen Greise haben mich dazu angestiftet, mit *
* dem Scripting anzufangen).                                                        *
*                                                                                   *
* HuygensMissionTour.celx von Ulrich Dickmann (aka Adirondack)                      *
* Website: http://www.celestia.de.vu/                                               *
*                                                                                   *
*************************************************************************************