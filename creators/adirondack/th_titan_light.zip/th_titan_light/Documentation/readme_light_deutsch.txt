*************************************************************************************
*                                                                                   *
*                 th_titan_light - "Postcards from Titan Light"                     *
*                                                                                   *
*                                                                                   *
* Detailierte Infos f�r "Postcards From Titan" finden Sie auch unter der folgenden  *
* URL: http://runar.thorvaldsen.net/celestia/gallery/xanadu.html                    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die in diesem Paket enthaltenen Dateien gem�� der Ordnerstruktur im *
* ZIP-Archiv in Ihr Celestia-Verzeichnis \extras\ oder falls Sie die Linux-Version  *
* verwenden in CelestiaResources/extras/addons/.                                    *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Verzeichnis von Celestia (...\Celestia\extras\)      *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* Wenn Sie eines der nachfolgenden Add-Ons bereits installiert haben, entfernen Sie *
* diese bitte aus Ihrer Celestia-Installation, weil es sonst zu einem merkw�rdigen  *
* Verhalten kommt:                                                                  *
*                                                                                   *
* - "Cassini_Huygens descent and landing" von Jestr                                 *
* - das Script "Cassini-Huygens Mission GT" von Adirondack                          *
*                                                                                   *
*                                                                                   *
* Sehensw�rdigkeiten in diesem Add-On:                                              *
* - Cassini-Huygens mit Cassini, im freien Flug und gelandet (am: 14.01.2005)       *
* - Die Huygens Landestelle                                                         *
* - Cassini-Huygens-Tour (huygensmission_xt-de.celx)                                *
*                                                                                   *
* Beachten Sie hierzu die enthaltene postcards_celurls.html, die entspr. Links zu   *
* diesen Sehensw�rdigkeiten enth�lt bzw. die enthaltene Cassini-Huygens-Tour.       *
*                                                                                   *
* _________________________________________________________________________________ *
*                                                                                   *
* Alle Texturen, Modelle und Grafiken sind Originalarbeiten von Runar Thorvaldsen,  *
* au�er den folgenden:                                                              *
*                                                                                   *
* - Die Cassini und Huygens Modelle sowie die Cassini XYZ-Bahndaten sind von Jestr  *
* - Die XYZ-Bahndaten f�r Huygens stammen ebenfalls von Jestr, wurden jedoch von    *
*   mir etwas ver�ndert                                                             *
* - Die 2k Titan Oberfl�che, die specular- und bump-maps der "Light Version" sind   *
*   von Dr. Fridger Schrempp                                                        *
* - Das Huygens-Mission-Script wurde von Ulrich "Adirondack" Dickmann geschrieben.  *
*   Das hier enthaltene Script ist eine von Ulrich extra f�r "Postcards From Titan" *
*   erweiterte Fassung, das Original "Cassini-Huygens Mission GT" finden Sie auf    *
*   Celestia Motherlode (www.celestiamotherlode.net/scripts/) und auf seiner        *
*   Website: http://www.celestia.de.vu/                                             *
*   Hinweis: Das Original-Script funktioniert nicht mit "Postcards From Titan"!     *
*                                                                                   *
* Die Inhalte von "Postcards From Titan" k�nnen frei benutzt werden, au�er f�r      *
* kommerzielle Zwecke!                                                              *
* Enthaltenes Material von anderen Autoren / Designer als Runar Thorvaldsen d�rfen  *
* nur in dem Umfang vertrieben werden, wie dies die Urheber gestatten.              *
* Wenn Sie "Postcards From Titan" weiter verteilen m�chten, d�rfen Sie dies machen, *
* solange Sie kein Geld daf�r erhalten und Sie die enthaltenen Dateien vollst�ndig  *
* weitergeben (auch diese ReadMe) und die Dateien nicht ver�ndern.                  *
* _________________________________________________________________________________ *
*                                                                                   *
* Mail: thpost@thorvaldsen.net                                                      *
* Web: http://runar.thorvaldsen.net/celestia/                                       *
* The Postcards Guide: http://runar.thorvaldsen.net/celestia/gallery/xanadu.html    *
* The Motherlode: http://www.celestiamotherlode.net                                 *
*                                                                                   *
* Runar Thorvaldsen (rthorvald), Oslo, 29. Juni 2005                                *
* Deutsche Fassung dieser Info: Ulrich Dickmann, 6. Juli 2005                       *
*                                                                                   *
*************************************************************************************