
README
th_titan - "Postcards from Titan Light"
--------------------------------------------------
NOTE ABOUT THIS PACKAGE:
--------------------------------------------------
This ReadMe covers the supplied Celestia AddOn "Postcards From Titan Light".

NOTE: Detailed Guide for Postcards From Titan can be found at this address:
http://runar.thorvaldsen.net/celestia/gallery/xanadu.html




INSTALLATION:
--------------------------------------------------
Drop the folder "th_titan" into CelestiaResources/extras/addons/.

Important: if you have any of the following AddOns installed, remove or disable  them first:
- Cassini_Huygens descent and landing, by jestr
- the script "Cassini-Hygens Mission GT" by Adirondack
- th_titan (full version), by rthorvald
... These are incompatible with the "Postcards from Titan" AddOn, and will cause weird behaviour in Celestia if used together.




NOTES:
--------------------------------------------------
This is the LIGHT version. Full version may be downloaded separately from the Motherlode, or from my website (addresses at the end of this document).




SIGHTS TO SEE:
--------------------------------------------------
- Cassini
- Huygens with Cassini, in free flight, and landed (GoTo january 14, 2005)
- The Huygens landing site (You must decrease FOV to get close to the probe)
- Cassini-Huygens-script (huygensmission_xt.celx)

See the included postcards_celurls.html document for links, and the Cassini-Huygens script for a tour.




COPYRIGHT
--------------------------------------------------
All textures, models and graphics are original works created by Runar Thorvaldsen, with the following exeptions:

- The Cassini and Huygens models are included courtesy of jestr at the Celestia forums.
- The XYZ trajectory for Cassini are included courtesy of jestr
- The XYZ trajectory for Huygens are included courtesy of jestr, with some modifications by myself
- the 2k Titan surface, specular and bump maps used in this Light Version are included courtesy of Dr. Fridger Schrempp

- The Huygens Mission script were created by Ulrich "Adirondack" Dickmann. This is an extended version expecially written for "Postcards From Titan" by Ulrich, and the original - the Cassini-Huygens Mission GT script - may be found on the Celestia Motherlode at www.celestiamotherlode.net/scripts/. Notice: The original script doesn't work correctly with "Postcards From Titan"!

Contents of "Postcards From Titan Light" may be used in any way you like, EXEPT for commercial purposes. Included material produced by other authors / designers than Runar Thorvaldsen are only distributable to the extent they give permission.

If you want to re-distribute "Postcards From Titan Light" you are free to do so, provided that you:
- do not charge money for it in any way, neither for the files themselves, or for access to them
- keep it complete and unmodified, including this ReadMe




ADDRESSES
--------------------------------------------------
Mail: thpost@thorvaldsen.net
web: http://runar.thorvaldsen.net/celestia/
The Postcards Guide: http://runar.thorvaldsen.net/celestia/gallery/xanadu.html
The Motherlode: http://www.celestiamotherlode.net
--------------------------------------------------
Runar Thorvaldsen (rthorvald),
Oslo, 29. june 2005



