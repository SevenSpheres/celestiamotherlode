*************************************************************************************
*                                                                                   *
*                 SaturnTour-de.cel V1.06 - Last Revision 9-21-04                   *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                    (eingeschr�nkt auch lauff�hig unter 1.3.1)                     *
*                                                                                   *
* Last revised on 21. Sept 04: Translation of the script (V1.05), and added info    *
*                            about two new moons. By Adirondack.                    * 
*                                                                                   *
* Dieses Script erfordert die Dateien ring_locs.ssc und satmoons2.ssc im Celestia-  *
* verzeichnis ...\Celestia\extras\ Diese beiden Dateien sind in diesem Paket ent-   *
* halten.                                                                           *
*                                                                                   *
* Entpacken Sie die Datei SaturnTour-de.cel in das Hauptverzeichnis von Celestia    *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien ring_locs.ssc and satmoons2.ssc entpacken Sie         *
* in das Verzeichnis ...\Celestia\extras\.                                          *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* HINWEIS: Falls sich die Datei satmoons2.ssc von Mr. Hutchison bereits in Ihrem    *
*          Celestia\extras Ordner befindet, m�ssen Sie diese Datei ersetzen, weil   *
           in der Datei in diesem Paket eine Korrektur vorgenommen wurde.           *
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf den Jupiter-Monden sehen     *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
*                                                                                   *
* Dies ist das Minimal-SaturnTour-Paket. Wenn Sie lieber das XXL-Paket benutzen     *
* m�chten (es enth�lt neue Texturen f�r Saturn, Tethys, Mimas und die Saturn-Ringe),*
* laden Sie sich das SaturnTourXXL-Paket von meiner Website herunter.               *
*                                                                                   *
*                                                                                   *
* _________________________________________________________________________________ *
* Credits:                                                                          *
*                                                                                   *
* ring_locs.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
* satmoons2.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
*                  Revisions: Bob Hegwood - Corrected the location for the Latium   *
*                                           Chasma on Dione.                        *
* SaturnTour.cel - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
* SaturnTour-de.cel - �bersetzung: Ulrich "Adirondack" Dickmann                     *
*                     Website: http://www.celestia.de.vu/                           *
*                                                                                   *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************