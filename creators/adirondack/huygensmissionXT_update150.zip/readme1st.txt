Patch-Version of the touring script 'Huygens Mission XT' for Celestia 1.5.0 or higher
-------------------------------------------------------------------------------------

The script of the originally add-on 'Huygens Mission XT' of the year 2005 does not work
properly with Celestia 1.5.0 or higher since the barycenter of the solar system in
Celestia 1.5.0 has been changed.
Therefore the "orbital tour" of Cassini in part 5 works only with Celestia 1.3.2 to 1.4.1
and does not work at all with Celestia 1.5.0 or higher.

For this reason, the script in this ZIP archive has been adapted for the use with Celestia
1.5.0 or higher, so you will be able to observe the orbital tour of Cassini with Celestia
1.5.0 or higher too.


===========================================================================================
Please note:
This ZIP archive only contains the modified script!
In order to run it with Celestia 1.5.0, make sure that the originally add-on ('Light Version'
or 'Full Version') is already installed BEFORE you unzip the script of this ZIP archive.
If you do not have the originally add-on yet, download it from here:
http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=806
===========================================================================================


After you have unzipped the originally add-on to your hard drive, just unzip the file
'huygensmission_xt.celx' from this ZIP archive to the folder where the originally CELX script
resides (this will replace the originally CELX script).
As an alternative you can unpack the script to the folder \scripts\, so you can easily start
it via the menu "File" -> "Scripts >" with Celestia 1.5.0.


Thanks to Marco Klunder who has offered the necessary modifications to set the positions
of the objects in part 5 of the script to the right place in Celestia 1.5.0.
Dank U well, Marco!


Ulrich 'Adirondack' Dickmann, March 2008.
www.celestia.info/


