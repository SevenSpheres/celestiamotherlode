*************************************************************************************
*                                                                                   *
*                    MarsTour-de.cel V2.0 - Last Revision: July-8-04                *
*                                                                                   *
*                                                                                   *
* Das Mars Script erfordert die Dateien mars_locs2.ssc und marsmoons2.ssc in Ihrem  *
* ...\Celestia\extras\ Verzeichnis.                                                 *
* Diese beiden Dateien sind auch in diesem Package enthalten.                       *
* Entpacken Sie die Datei MarsTour-de.cel in das Hauptverzeichnis von Celestia      *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie mein deutsches Upgrade    *
* installiert haben. Die Dateien mars_locs2.ssc und marsmoons2.ssc entpacken Sie    *
* in das Verzeichnis ...\Celestia\extras\.                                          *
* Wenn Sie die Dateien mars_locs2.ssc und marsmoons2.ssc von Grant Hutchison schon  *
* besitzen, brauchen Sie die in diesem Package enthaltenen .SSC-Dateien nicht zu    *
* entpacken!                                                                        *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
*                                                                                   *
*     Dieses Script wurde zum Gebrauch mit Celestia 1.3.2 Pre8 geschrieben          *
*               Es funktioniert aber auch in der Version 1.3.1 !                    *
*                                                                                   *
*                                                                                   *
* Diese Mars-Tour gibt es auch inklusive spektakul�rer Oberfl�chenstrukturen        *
* f�r Mars und seine Wolken sowie seiner Monde Phobos und Deimos.                   *
* Diese detaillierteren Texturen sind in dem vorliegenden Package NICHT ent-        *
* halten. Das vorliegende Script greift auf die in Ihrer Celestia-Installation      *
* vorhanden Texturen zur�ck.                                                        *
*                                                                                   *
* Wenn Sie das KOMPLETTE Mars-Tour Package mit den daf�r neu entworfenen Texturen   *
* benutzen m�chten, finden Sie dieses Komplett-Paket ebenfalls auf meiner Website   *
* www.celestia.de.vu/ in der Rubrik "Skripte".                                      *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Credits: ________________________________________________________________________ *
*                                                                                   *
* mars_locs2.ssc    - Author: Grant Hutchison                                       *
*                     Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/  *
* marsmoons2.ssc    - Author: Grant Hutchison                                       *
* Original script   - Author: Alan Federman, Revisions: Selden E. Ball, Jr.         *
* Org. MarsTour.cel - Author: Bob Hegwood                                           *
*                     Website: http://home.earthlink.net/~bobhegwood                *
* MarsTour-de.cel   - �bersetzung: Ulrich "Adirondack" Dickmann                     *
*                     Website: http://www.celestia.de.vu/                           *
*                                                                                   *
*          ________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
*************************************************************************************