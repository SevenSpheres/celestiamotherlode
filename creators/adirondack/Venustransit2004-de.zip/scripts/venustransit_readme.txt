*************************************************************************************
*                                                                                   *
*                           Venustransit2004-de.celx V1.0                           *
*                                   September 2008                                  *
*                                                                                   *
*                         Celestia-Skript von Ulrich Dickmann                       *
*                                                                                   *
*                            F�r Celestia 1.5.1 oder h�her                          *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Diese Pr�sentation zeigt Ihnen den Venustransit vom 8. Juni 2004 und erkl�rt,     *
* wann und warum Venustransits �berhaupt stattfinden.                               *
* Die Pr�sentation dauert etwa 7 Minuten.                                           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei Venustransit2004-de.celx einfach in das Verzeichnis       *
* ...\Celestia\scripts\                                                             *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren (in anderen  *
* Entpackprogrammen hei�t diese Option �hnlich).                                    *
* Die Datei wird dann in das richtige Celestia-Unterverzeichnisse entpackt.         *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nach der korrekten Installation des Skriptes k�nnen Sie die Pr�sentation �ber das *
* Men� Datei -> Skripte > -> Venustransit 2004 (DE) aufrufen.                       *
*                                                                                   *
* Nach dem Aufruf des Skripts, starten Sie durch Dr�cken der Taste [s] die Tour.    *
* Mit [Esc] k�nnen Sie jederzeit die Pr�sentation beenden.                          *
*                                                                                   *
* Das Skript wird nach Beendigung oder einem Abbruch der Tour mit [Esc] die Ein-    *
* stellungen der Darstellung (wie Wolken, Finsternisse, Galaxien usw.) wieder so    *
* einstellen, wie sie vor der Ausf�hrung des Scripts von Ihnen definiert waren.     *
* Sie m�ssen also nach der Ausf�hrung des Skripts Ihre Einstellungen nicht selbst   *
* wieder anpassen, sofern diese Einstellungen vom Skripts umgestellt worden sein    *
* sollten.                                                                          *
* Das Zur�cksetzen der Einstellungen funktioniert nicht, wenn Sie Celestia beenden, *
* ohne vorher mit [Esc] das Skript beendet zu haben! Beenden Sie die Pr�sentation   *
* also stets mit der Taste [Esc].                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! Kommerzielle �ffentliche Auff�hrung oder Vetrieb   *
* des Skriptes auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung des   *
* Urhebers zul�ssig!                                                                *
*                                                                                   *
* Die Weitergabe des Skripts ist nur in unver�ndertem Zustand und nur zusammen mit  *
* dieser ReadMe-Datei zul�ssig.                                                     *
*                                                                                   *
* All contents � 2008 by Ulrich Dickmann (Adirondack)                               *
*                                                                                   *
* Dieses Addon ist unter folgender Creative Commons Lizenz lizensiert:              *
* Kurzinfo: http://creativecommons.org/licenses/by-nc-nd/3.0/de/deed.de             *
* Lizenz-Text: http://creativecommons.org/licenses/by-nc-nd/3.0/de/legalcode        *
*                                                                                   *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs- oder Vetriebsabsichten!                          *
* --> http://www.celestia.info/                                                     *
*                                                                                   *
*************************************************************************************