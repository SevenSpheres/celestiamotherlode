*************************************************************************************
* JupiterTour-de.cel - Version 1.05                                                 *
* F�r Celestia 1.3.2 oder h�her (eingeschr�nkt auch lauff�hig unter 1.3.1)          *
*                                                                                   *
*                                                                                   *
*  Dieses Script wurde f�r Celestia 1.3.2 Pre1 und sp�tere Versionen geschrieben.   *
*          Es ist jedoch auch eingeschr�nkt lauff�hig unter 1.3.1                   *
*                                                                                   *
*                                                                                   *
* Dieses Script erfordert die Dateien "jupmoons2.ssc" und "Gipul.ssc" im Celestia-  *
* verzeichnis ..\Celestia\extras\ . Diese beiden Dateien sind in diesem Paket ent-  *
* halten.                                                                           *
*                                                                                   *
* Entpacken Sie die Datei JupiterTour-de.cel in das Hauptverzeichnis von Celestia   *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien jupmoons2.ssc und Gipul.ssc entpacken Sie             *
* in das Verzeichnis ...\Celestia\extras\.                                          *
*                                                                                   *
* HINWEIS: Falls sich die Datei jupmoons.ssc in Ihrem Celestia\extras Ordner        *
*          befindet, m�ssen Sie diese Datei l�schen, damit das Script die Orte      *
*          aus der Datei jupmoons2.ssc in Celestia 1.3.2 korrekt anzeigen kann.     *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
* Lesen Sie jedoch weiter unten zuvor auch die Hinweise zu den Texturen!            *
*                                                                                   *
*                                                                                   *
* Dies ist das KOMPLETTE JupiterTour Paket (XXL). Es enth�lt alle Texturen, die     *
* sich von den Texturen der Celestia-Basisversion unterscheiden oder dort nicht     *
* enthalten sind (z.B. Jupiter-Ringe).                                              *
*                                                                                   *
* Im XXL-Paket sind neue Texturen f�r Jupiter, seine Ringe, Callisto und Ganymed    *
* enthalten. Diese Texturen sind gegen�ber den Texturen der Basisversion wesentlich *
* verbessert worden!                                                                *
* Au�erdem finden Sie in diesem XXL-Paket ein neues Modell des Jupiter-Mondes       *
* "Amalthea", welches von Jestr hergestellt wurde.                                  *
*                                                                                   *
*                                                                                   *
* Um die neuen Texturen in Celestia einzubinden, gehen Sie wie folgt vor:           *
*                                                                                   *
* 1. Entpacken Sie die Dateien Jupiter.jpg, JupiterRings.png, Callisto.jpg und      *
*    Ganymede.jpg in das Verzeichnis ..\Celestia\textures\medres .                  *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, werden  *
*    die Textur-Dateien automatisch in das richtige Verzeichnis entpackt.           *
*                                                                                   *
* 2. Anschl. m�ssen Sie die Datei solarsys.ssc modifizieren, damit die neuen        *
*    Texturen von Celestia benutzt werden. Sie finden die Datei solarsys.ssc im     *
*    Ordner ..\Celestia\data\ .                                                     *
*    Beachten Sie, dass diese Datei nach dem Abspeichern weiterhin die Dateiendung  *
*    .SSC tragen muss! Wenn Sie sie als solarsys.ssc.txt abspeichern, funktioniert  *
*    sie nicht mehr.                                                                *
*    �ffnen Sie die Datei mit einem Texteditor (z.B. Notepad) und nehmen folgende   *
*    �nderungen darin vor:      				                    *
*                                                                                   *
*    A. Unter dem Datensatz "Jupiter" "Sol" �ndern Sie die Textur-Definition wie    *
*       folgt: Texture - "Jupiter.jpg" - Beachten Sie die Gro�schreibung von "J"    *
*                                                                                   *
*    B. Unter dem Datensatz "Ganymede" "Sol/Jupiter" �ndern Sie die Definition wie  *
*       folgt: Texture - "Ganymede.jpg" - Beachten Sie die Gro�schreibung von "G"   *
*                                                                                   *
*    C. Unter dem Datensatz "Callisto" "Sol/Jupiter" �ndern Sie die Definition wie  *
*       folgt: Texture - "Callisto.jpg" - Beachten Sie die Gro�schreibung von "C"   *
*                                                                                   *
*    ALTERNATIVE:                                                                   *
*    Wenn Sie m�chten, k�nnen Sie die neuen Texturen auch im Bedarfsfall "nur"      *
*    zuschalten. Dann brauchen Sie die Datei solarsys.ssc NICHT modifizieren.       *
*    Sie klicken dann bei Bedarf einfach mit einem Rechtsklick auf den Jupiter und  *
*    w�hlen im erscheinenden Kontextmen� "JupiterTour" aus! Daraufhin werden die    *
*    neuen Texturen von Celestia angezeigt (sofern Sie diese wie unter 1. be-       *
*    schrieben in das Verzeichnis ..\Celestia\textures\medres eingef�gt haben.      *
*    Damit Sie eine Auswahl der Texturen �ber das Kontextmen� von Jupiter vornehmen *
*    k�nnen, hat Bob die gesonderte Datei JupiterTour.ssc geschrieben, die Sie in   *
*    das Verzeichnis ..\Celestia\extras\ entpacken m�ssen.                          *
*    Sie k�nnen anschl. die neuen Texturen einschalten, ohne das Script ausf�hren   *
*    zu m�ssen. Wenn Sie wieder Ihre alten Texturen angezeigt haben m�chten,        *
*    w�hlen Sie einfach im Kontextmen� von Jupiter die Option "Normal" aus.         *
*                                                                                   *
* 3. Wenn auch die Jupiter-Ringe angezeigt werden sollen, m�ssen Sie nun noch       *
*    folgende Modifikaton in der Datei solarsys.ssc vornehemen:                     *
*                                                                                   *
*    Unter dem Datensatz "Jupiter" "Sol" f�gen Sie folgende Zeilen hinzu oder       *
*    �ndern die ggf. bereits bestehenden Zeilen wie folgt:                          *
*                                                                                   *
*       Rings { Inner 92000                                                         *
*               Outer 221000                                                        *
*               Texture "JupiterRings.png"                                          *
*             }                                                                     *
*                                                                                   *
*    Beachten Sie, dass Sie diese Modifikation auch dann vornehmen m�ssen, wenn Sie *
*    die alternative Kontextmen�-Variante benutzen wollen!                          *
*                                                                                   *
* 4. Nun m�ssen Sie nur noch das neue Modell f�r Amalthea einbinden, in dem Sie die *
*    Datei amalthea.3ds in Ihr Verzeichnis ..\Celestia\models\ entpacken und damit  *
*    die dort bereits vorhandene Datei amalthea.3ds �berschreiben.                  *
*    Jestr's Amalthea-Modell ist dem Basismodell bei weitem �berlegen, so dass Sie  *
*    kein Backup der vorhandenen Datei vornehmen brauchen (denn Sie werden es nie   *
*    mehr benutzen wollen). :-)                                                     *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, wird    *
*    das Amalthea-Modell automatisch in das richtige Verzeichnis entpackt.          *
*                                                                                   *
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf den Jupiter-Monden sehen     *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Bezugspunkte/Orte" bzw.       *
*          "Locations" den Punkt "Beschriftungen der Merkmale anzeigen" bzw.        *
*          "Label Features" aus.                                                    *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
* __________________________________________________________________________________*                                                                                   *
* Credits:                                                                          *
*                                                                                   *
* amalthea.3ds       - Author: Jestr                                                *
*                      Website: http://www.geocities.com/jestrjestr/                *
* Ganymede.jpg       - Author: Bjorn Jonnson                                        *
*                      Website: http://www.mmedia.is/~bjj/                          *
*                      Revisions: Bob Hegwood - Resized to 1024 x 512 and corrected *
*                                               the Central Meridian.               *
* Callisto.jpg       - Author: Bjorn Jonnson                                        *
*                      Website: http://www.mmedia.is/~bjj/                          *
*                      Revisions: Bob Hegwood - Resized to 1024 x 512 and corrected *
*                                               the Central Meridian.               *
* Jupiter.jpg (2K)   - Author: speedyspacebike                                      *
* JupiterRings.png   - Author: Praesepe                                             *
*                      Website: http://www.la-guarida.com/Celestia/                 *
*                      Revisions: Bob Hegwood - Resized to 1024 x 32.               *
* jupmoons2.ssc      - Author: Grant Hutchison                                      *
*                      Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/ *
* Gipul.ssc          - Author: Bob Hegwood                                          *
* JupiterTour.ssc    - Author: Bob Hegwood                                          *
* JupiterTour.cel    - Author: Bob Hegwood                                          *
*                      Website: http://home.earthlink.net/~bobhegwood               *
* JupiterTour-de.cel - �bersetzung: Ulrich "Adirondack" Dickmann                    *
*                      Website: http://www.celestia.de.vu/                          *
*                                                                                   *
* __________________________________________________________________________________*
*                                                                                   *
* Bitte beachten Sie, dass Bob die Originaltexturen in das kleinere Format          *
* 1024 x 512 umgewandelt hat, damit diese auch auf schw�cheren PCs funktionieren.   *
* Wenn Sie h�heraufgel�ste Texturen verwenden m�chten, laden Sie sich diese von den *
* Websites der Autoren (siehe Credits) herunter.                                    *
*                                                                                   *
*                                                                                   *
* Ich hoffe, Ihnen gef�llt dieses Script. Bob Hegwood hat �ber einen Monat f�r die  *
* Informationsrecherche und die Codierung aufgebracht! Thanks Bob!                  *                                           *
*                                                                                   *
* Package modifiziert im Juni 2007: Textur f�r Jupiter ausgetauscht.                *
*                                                                                   *
*************************************************************************************