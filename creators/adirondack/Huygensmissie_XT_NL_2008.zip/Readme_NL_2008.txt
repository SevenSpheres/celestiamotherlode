README

th_titan - "Postcards from Titan"
--------------------------------------------------




NOTE ABOUT THIS PACKAGE:
--------------------------------------------------
This ReadMe covers the supplied Celestia Add-on "Postcards From Titan", including the Dutch version.
NOTE: Detailed Guide for Postcards From Titan can be found at this address:
      http://runar.thorvaldsen.net/celestia/gallery/xanadu.html




INSTALLATION "Postcards From Titan":
--------------------------------------------------
You have already downloaded the "th_titan.zip" file (eg. Celestia motherlode).
Copy/Unzip the file "th_titan.zip" in the subdirectory: ..\extras\ 
within the Celestia main directorty (common: c:\Program Files\Celestia\).

IMPORTANT: if you have any of the following Add-ons installed,
           remove or disable them first:

- Cassini_Huygens descent and landing      by jestr
- the script "Cassini-Hygens Mission GT"   by Adirondack
- th_titan_light (light-realistic version) by rthorvald

... These are incompatible with the "Postcards from Titan" Add-on,
    and will cause weird behaviour in Celestia if used together.





INSTALLATION of the "Dutch version" of the Add-on:
--------------------------------------------------
Copy/Unzip the file "Huygensmissie_XT_NL_2008.celx" in the subdirectory: ..\scripts
within the Celestia main directorty (common: c:\Program Files\Celestia\)

As an alternative, you can copy the Dutch script in the same folder as the other
files of "Postcards From Titan" within the subdirectory: ..\extras\th_titan.

The original script is working compatible with Celestia 1.3.2 through Celestia 1.4.1.
It can work with Celestia 1.5.0, but there are some limitations in part 4 and 5.
The Dutch script is ALSO full compatible with Celestia 1.5.0 !!!!




NOTES:
--------------------------------------------------
This Add-on is split into three parts:
- The actual Add-on.
- The HiRes folder.
- The Dutch version script.

You do not need the HiRes folder to use "Postcards from Titan", but installing
it will give you considerably higher resolution:
- it will replace the 512x512 tile JPG Virtual Texture with a 1024x1024 PNG one.
- The HiRes folder may be downloaded separately from the Motherlode,
  or from my website (addresses at the end of this document).




SIGHTS TO SEE:
--------------------------------------------------
- Cassini
- Huygens with Cassini, in free flight, and landed (GoTo january 14, 2005)
- The Huygens landing site (You must decrease FOV to get close to the probe)
- Cassini-Huygens-script (huygensmission_xt.celx)
- Titan Organics Explorer (GoTo june 22, 2018 to see it)
- Xanadu Lake
- The Bonestell Rock

See the included postcards_celurls.html document for links,
and the Cassini-Huygens_NL_2008 script for a tour.




COPYRIGHT
--------------------------------------------------
All textures, models and graphics are original works
created by Runar Thorvaldsen, with the following exeptions:

- The Cassini and Huygens models are included courtesy of jestr at the Celestia forums.
- The XYZ trajectory for Cassini are included courtesy of jestr
- The XYZ trajectory for Huygens are included courtesy of jestr, with some modifications by myself

- The Huygens Mission script were created by Ulrich "Adirondack" Dickmann.
  This is an extended version expecially written for "Postcards From Titan" by Ulrich, 
  and the original - the Cassini-Huygens Mission GT script - may be found on the 
  Celestia Motherlode at www.celestiamotherlode.net/scripts/.
  Notice: The original script doesn't work correctly with "Postcards From Titan"!

Contents of "Postcards From Titan" may be used in any way you like, EXEPT for
commercial purposes. Included material produced by other authors / designers 
than Runar Thorvaldsen are only distributable to the extent they give permission.

If you want to re-distribute "Postcards From Titan" you are free to do so, provided that you:
- do not charge money for it in any way, neither for the files themselves, or for access to them
- keep it complete and unmodified, including this ReadMe



ADDRESSES
--------------------------------------------------
Mail: thpost@thorvaldsen.net
web: http://runar.thorvaldsen.net/celestia/
The Postcards Guide: http://runar.thorvaldsen.net/celestia/gallery/xanadu.html
The Motherlode: http://www.celestiamotherlode.net
--------------------------------------------------
Runar Thorvaldsen (rthorvald),
Oslo, 29. june 2005



COPYRIGHT DUTCH VERSION
--------------------------------------------------
Translated to a Dutch version by: Marco Klunder, april 2008.
Contact: marco.klunder@hccnet.nl

NOTE: To use the Dutch script, the same conditions applies as those for
      the orginal Add-on, indicated in the above COPYRIGHT paragraph.
