*************************************************************************************
*                                                                                   *
*                   UranusTour-de.cel V1.05 - Last Revision 09-18-04                *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                    (eingeschr�nkt auch lauff�hig unter 1.3.1)                     *
*                                                                                   *
* Last revised on 18. Sept. 04: Translation of the script (V1.05) by Adirondack.    *                   
*                                                                                   *                                                                               
* Dieses Script erfordert die Dateien ring_locs.ssc und uranmoons.ssc im Celestia-  *
* verzeichnis ...\Celestia\extras\ Diese beiden Dateien sind in diesem Paket ent-   *
* halten.                                                                           *
*                                                                                   *
* Entpacken Sie die Datei UranusTour-de.cel in das Hauptverzeichnis von Celestia    *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien ring_locs.ssc und uranmoons.ssc entpacken Sie         *
* in das Verzeichnis ...\Celestia\extras\.                                          *
*                                                                                   *
* In diesem XXL-Paket ist eine 1024 x 512 grosse Textur f�r Titania enthalten.      *
* Diese Textur (titania.jpg) stellt die Oberfl�che des Mondes mit einer besseren    *
* Aufl�sung dar, als die vorhandene Textur im Ordner ...\textures\lores es kann.    *
* Entpacken Sie die Datei titania.jpg in den Ordner ...\textures\medres             *
* Die Datei im Ordner Celestia\textures\lores k�nnen Sie dann l�schen oder aber     *
* auch dort belassen.                                                               *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* HINWEIS: Falls sich die Datei uranmoons.ssc von Mr. Hutchison bereits in Ihrem    *
*          Celestia\extras Ordner befindet, m�ssen Sie diese Datei ersetzen, weil   *
*          in der Datei in diesem Paket notwendige Korrekturen vorgenommen wurden.  *
*                                                                                   *
*          Sofern sich die Datei ring_locs.ssc bereits in Ihrem Celestia\extras     *
*          Ordner befindet (z.B. weil Sie schon die Saturn-Tour eingebunden haben,  *
*          m�ssen Sie diese Datei NICHT noch einmal installieren.                   *
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf Uranus sehen                 *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
* In diesem Paket ist auch die Datei uranus-rings.png (Uranus-Ringe) enthalten,     *
* welche Sie bei Bedarf in den Ordner ...\Celestia\textures\lores entpacken         *
* k�nnen, falls sich diese nicht bereits dort befinden sollte (bei Celestia 1.3.2   *
* ist diese Datei bereits vorhanden).                                               *
* Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, wird die   *
* Datei uranus-rings.png automatisch in das richtige Verzeichnis entpackt, auch     *
* wenn die Datei dort schon vorhanden ist. Sie kann getrost �berschrieben werden.   *
*                                                                                   *
* Wenn Sie die Uranus-Ringe noch nicht installiert haben sollten und daher die o.g. *
* Datei aus diesem Paket in den Ordner ...\Celestia\textures\lores entpackt haben,  *
* m�ssen Sie noch die Datei solarsys.ssc wie folgt modifizieren, damit die Ringe    *
* in Celestia auch dargestellt werden (bei Celestia 1.3.2 nicht erforderlich!):     *
*                                                                                   *
* Im Abschnitt "Uranus" "Sol" f�gen Sie nach dem Eintrag "Albedo" folgende Zeilen   *
* ein oder �ndern den ggf. vorhandenen "Rings"-Eintrag entsprechend:                *
*                                                                                   *
*                                    	Rings {                                     *
*	                                       Inner  41837                         *
*		                               Outer  51179                         *
*		                               Texture "uranus-rings.png"           *
*	                                      }                                     *
*                                                                                   *
* _________________________________________________________________________________ *
* Credits:                                                                          *
*                                                                                   *
* ring_locs.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
* uranmoons.ssc  - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
*                  Revisions: Bob Hegwood - Corrected locations for the Alonso      *
*                                           Crater on Miranda, and the Wunda Crater *
*                                           on Umbriel.                             *
* titania.jpg    - Author: Bruckner? Managed to download from Star Lion's site.     *
*                  Website: http://www.starlionfiles.50megs.com/                    *
*                  Revisions: Bob Hegwood - Resized to 1024x512, then mirrored and  *
*                                           flipped the image to match Celestia's   *
*                                           current location methodology.           *
* UranusTour.cel - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
* UranusTour-de.cel - �bersetzung: Ulrich "Adirondack" Dickmann                     *
*                     Website: http://www.celestia.de.vu/                           *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************