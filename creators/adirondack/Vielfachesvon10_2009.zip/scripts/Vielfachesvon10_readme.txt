*************************************************************************************
*                                                                                   *
*                          Vielfachesvon10-2009.celx V1.3a                          *
*                                  8. November 2009                                 *
*                                                                                   *
*                Celestia-Skript von Marco Klunder & Ulrich Dickmann                *
*                                                                                   *
*                            F�r Celestia 1.6.0 oder h�her                          *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Diese Pr�sentation zeigt Ihnen einen Entfernungsvergleich mit Potenzen von 10.    *
* Die Pr�sentation dauert etwa 6 Minuten.                                           *
*                                                                                   *
* Dieses Skript ersetzt Ulrich Dickmanns Ursprungsskript vom 18. August 2004.       *
* Die Version 1.3a enth�lt Modifikationen von Marco Klunder.                        *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei Vielfachesvon10_2009.celx einfach in das Verzeichnis      *
* ...\Celestia\scripts\                                                             *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren (in anderen  *
* Entpackprogrammen hei�t diese Option �hnlich).                                    *
* Die Datei wird dann in das richtige Celestia-Unterverzeichnisse entpackt.         *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nach der korrekten Installation des Skriptes k�nnen Sie die Pr�sentation �ber das *
* Men� Datei -> Skripte > -> "Das Vielfache von 10 (2009)" aufrufen.                *
*                                                                                   *
* Mit [Esc] k�nnen Sie jederzeit die Pr�sentation beenden.                          *
*                                                                                   *
* Das Skript wird nach Beendigung oder einem Abbruch der Tour mit [Esc] die Ein-    *
* stellungen der Darstellung (wie Wolken, Finsternisse, Galaxien usw.) wieder so    *
* einstellen, wie sie vor der Ausf�hrung des Scripts von Ihnen definiert waren.     *
* Sie m�ssen also nach der Ausf�hrung des Skripts Ihre Einstellungen nicht selbst   *
* wieder anpassen, sofern diese Einstellungen vom Skripts umgestellt worden sein    *
* sollten.                                                                          *
* Das Zur�cksetzen der Einstellungen funktioniert nicht, wenn Sie Celestia beenden, *
* ohne vorher mit [Esc] das Skript beendet zu haben! Beenden Sie die Pr�sentation   *
* also stets mit der Taste [Esc].                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! Kommerzielle �ffentliche Auff�hrung oder Vetrieb   *
* des Skriptes auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung des   *
* Urhebers zul�ssig!                                                                *
*                                                                                   *
* Die Weitergabe des Skripts ist nur in unver�ndertem Zustand und nur zusammen mit  *
* dieser ReadMe-Datei zul�ssig.                                                     *
*                                                                                   *
* All contents � 2004/2009 by Marco Klunder & Ulrich Dickmann (Adirondack)          *
*                                                                                   *
* Dieses Addon ist unter folgender Creative Commons Lizenz lizensiert:              *
* Kurzinfo: http://creativecommons.org/licenses/by-nc-nd/3.0/de/deed.de             *
* Lizenz-Text: http://creativecommons.org/licenses/by-nc-nd/3.0/de/legalcode        *
*                                                                                   *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs- oder Vetriebsabsichten!                          *
* --> http://www.celestia.info/                                                     *
*                                                                                   *
*************************************************************************************