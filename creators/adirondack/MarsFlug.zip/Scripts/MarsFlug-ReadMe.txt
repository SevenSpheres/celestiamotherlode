**************************************************************************************
*                                                                                    *
* MarsFlug.celx - Version 1.0                                                        *
* F�r Celestia 1.3.2 oder h�her                                                      *
*                                                                                    *
**************************************************************************************
*                                                                                    *
* Entpacken Sie die Datei MarsFlug.celx in das Hauptverzeichnis von Celestia         *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis    *
* angelegt haben.                                                                    *
*                                                                                    *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf         *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)         *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren               *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                         *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen        *
* Celestia-Unterverzeichnisse entpackt.                                              *
* Lesen Sie jedoch trotzdem auch den Rest dieser Informationsdatei durch!            *
*                                                                                    *
*                                                                                    *
* In diesem Paket sind neue Texturen f�r den Mars und seine Wolken sowie ein Modell  *
* f�r den Vulkan "Olympus Mons" enthalten.                                           *
* Diese m�ssen Sie nicht zwingend installieren, um den Mars�berflug anzuschauen.     *
* Aber seien Sie versichert, dass die neuen Texturen den Mehraufwand Wert sind!      *
* Lesen Sie jedoch unbedingt nachfolgend auch "WICHTIGE HEINWEISE BEI SCHWACHEM PC"! *
*                                                                                    *
* Falls Sie bereits die "MarsTourXXL" installiert haben oder bereits eine            *
* verbesserte Mars-Textur und Marswolken eingebunden haben, k�nnen Sie sich das      *
* Entpacken dieser Dateien (mars.jpg und MarsClouds.png) sparen.                     * 
*                                                                                    *
* ================================================================================== *
*                                                                                    *
* WICHTIGE HINWEISE BEI SCHWACHEM PC:                                                *
* -----------------------------------                                                *
*                                                                                    *
* Sie sollten die in diesem Paket enthaltenen neue Texturen f�r den Mars (mars.jpg)  *
* und die Marswolken (MarsClouds.png) sowie f�r "Olympus Mons" (mons.3ds) nicht      *
* installieren, wenn Celestia bei Ihnen auf einem schw�cheren PC l�uft, denn der     *
* �berflug verl�uft dann ziemlich ruckelig.                                          *
* Dieser Ruckel-Effekt tritt �brigens auch auf relativ gut ausgestatteten Systemen   *
* (z.B. Pentium 4/2.0 GHz und 256 MB RAM sowie 64 MB Grafik) auf, wenn Sie bereits   *
* andere hochaufgel�ste Texturen eingebunden haben.                                  *
* Hilfreich ist hier das Abschalten der Galaxien, damit kann ich auf meinem Rechner  *
* die Framerate fast verdoppeln!                                                     *
*                                                                                    *
* Sie haben also bei einem schwachen PC folgende Wahl:                               *
*                                                                                    *
* 1. Sie installieren die o.g. Texturen nicht und erleben einen ruhigen �berflug     *
*    �ber den Mars, sehen allerdings keine Details auf der Marsoberfl�che und Ihnen  *
*    entgeht ein beeindruckender Anblick des Vulkans "Olympus Mons".                 *
*    Markieren Sie in diesem Fall NUR folgende Dateien f�r den Entpackvorgang:       *
*                                                                                    *
*    -> MarsFlug.celx                                                                *
*    -> MarsFlug-ReadMe.txt (diese Datei, ggf. zum sp�teren Nachlesen)               *
*                                                                                    *
* 2. Sie installieren die o.g. Texturen trotzdem und erleben einen ruckeligen        *
*    �berflug �ber den Mars, erkennen daf�r aber mehr Details auf der Marsoberfl�che *
*    und sehen "Olympus Mons" in voller Pracht.                                      *
*    Markieren Sie in diesem Fall ALLE Dateien f�r den Entpackvorgang und nehmen     *
*    anschl. die weiter unten beschriebenen Modifikationen in der Datei solarsys.ssc *
*    vor.                                                                            *
*    Vor dem Start des Scripts schalten Sie unter dem Men� "Darstellung" bzw. in der *
*    englischen Version "Render" bei den "Anzeige-Optionen" ("View options") einfach *
*    f�r das Script unn�tige Darstellungen ab (Galaxien, Ring-Schatten,              *
*    Finsternis-Schatten usw.).                                                      *
*                                                                                    *
* Es ist Ihre Entscheidung, aber ich w�rde auch bei einem schw�cheren PC             *
* alle Texturen einbinden... ;-)                                                     *
*                                                                                    *
* ================================================================================== *
*                                                                                    *
*                                                                                    *
* Um die neuen Texturen in Celestia einzubinden, gehen Sie wie folgt vor:            *
*                                                                                    *
* 1. Entpacken Sie zun�chst einfach die Dateien mars.jpg, MarsClouds.png sowie       *
*    mons.jpg in das Verzeichnis ...\Celestia\textures\medres\                       *
*    BITTE BEACHTEN: Damit ersetzen Sie die bereits vorhandene gleichnamige Datei    *
*    f�r die Marstextur (mars.jpg) in diesem Verzeichnis. Fertigen Sie daher ggf.    *
*    ein Backup dieser schon vorhandenen Datei an, falls Sie sie sp�ter lieber       *
*    wieder benutzen m�chten.                                                        *
*    Das wage ich zwar zu bezweifeln, aber man wei� ja nie ...                       *
*    ... vielleicht haben Sie ja auch selbst schon eine bessere Textur eingebunden.  *
*                                                                                    *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, werden   *
*    die Textur-Dateien automatisch in das richtige Verzeichnis entpackt.            *
*                                                                                    *
* 2. Entpacken Sie anschlie�end die Datei mons.3ds in das Verzeichnis                *
*    ...\Celestia\models\                                                            *
*    und die Datei olympusmons.ssc in das Verzeichnis ...\Celestia\extras\           *
*                                                                                    *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, werden   *
*    die Dateien automatisch in die richtigen Verzeichnisse entpackt.                *
*                                                                                    *
* 3. Nun m�ssen Sie noch einen Abschnitt in der Datei solarsys.ssc anpassen,         *
*    damit die neuen Mars-Wolken angezeigt werden k�nnen.                            *
*    Dazu �ffnen Sie diese Datei (Sie finden diese im Ordner ...\Celestia\data\)     *
*    mit Notepad (oder einem sonstigen Text-Editor) und �ndern sie wie folgt:        *
*                                                                                    *
*    Suchen Sie den Abschnitt "Mars" "Sol". Innerhalb der Sektion "Atmosphere"       *
*    erg�nzen (oder ersetzen) Sie die folgenden Zeilen:                              *
*                                                                                    *
*               CloudHeight 10                                                       *
*               CloudSpeed 70                                                        *
*               CloudMap "MarsClouds.png"                                            *
*                                                                                    *
*    L�schen Sie dabei jedoch keinesfalls die anderen Zeilen in dieser Sektion!      *
*                                                                                    *
*    Speichern Sie die Datei anschliessend ab (Dateierweiterung .ssc beibehalten!)   *
*                                                                                    *
* Nun ist das Script einsatzbereit!                                                  *
*                                                                                    *
* __________________________________________________________________________________ *                                                                                   *
* Credits:                                                                           *
*                                                                                    *
* Originalscript    - Author: Toti                                                   *
* MarsFlug.celx     - �bersetzung: Ulrich "Adirondack" Dickmann                      *
*                     Website: http://www.celestia.de.vu/                            *
* mars.jpg          - Author: Praesepe                                               *
*	              Website:                                                       *
*                     www.la-guarida.com/Celestia/index_archivos/slide0001.htm       *
* MarsClouds.png    - Author:  Jens (Jim) Meyer                                      *
*                     Website: http://home.arcor.de/jimpage/mars.html                *
*                     Revisions: Bob Hegwood-Converted from DDS and then resized to  *
*                                1024 x 512.                                         *
* mons.3ds          _ Creator: Jestr                                                 *
* olympusmons.ssc   _ Author: Jestr                                                  *
*                                                                                    *
* __________________________________________________________________________________ *
*                                                                                    *
**************************************************************************************


