*************************************************************************************
*                                                                                   *
*                              DeepImpact-de.celx V1.0                              *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
*                Original Script V1.2 by Vincent Giangiulio, March 2005             *
* German revised & modified CELX-version by Ulrich "Adirondack" Dickmann, July 2005 *
*                                                                                   *
* Laufzeit: ca. 13 Minuten (Teil 1 und 2)                                           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Dieses Script erfordert das "Deep Impact"-Addon von Jestr, welches in diesem      *
* Paket nicht enthalten ist.                                                        *
* Falls Sie es nicht bereits installiert haben, k�nnen Sie es hier downloaden:      *
* http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=639     *
*                                                                                   *
* Beachten Sie bitte, dass das "Deep Impact"-Addon vor der Installation dieses      *
* Script-Paketes bereits installiert sein muss, da mit der Script-Installation eine *
* fehlerhafte Datei des "Deep Impact"-Addons (Temple1.xyz) ersetzt wird!            *
* Diese korrigierte Datei ist deshalb in diesem Skript-Paket ebenfalls enthalten.   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* INSTALLATION                                                                      *
* ============                                                                      *
*                                                                                   *
* Entpacken Sie die in diesem Paket enthaltenen Dateien gem�� der Ordnerstruktur    *
* im ZIP-Archiv in Ihr Celestia-Verzeichnis.                                        *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
*                                                                                   *
* Sie finden das Touring-Script in dem Ordner mit dem Namen \scripts\.              *
* Dieser \scripts\ Ordner wird automatisch angelegt, wenn Sie das Paket wie oben    *
* beschrieben entpacken.                                                            *
* Wenn Sie meine deutsche Programmversion von Celestia installiert haben, ist Ihnen *
* dieser Ordner ja bereits gel�ufig.                                                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* WICHTIGE HINWEISE:                                                                *
* ==================                                                                *
*                                                                                   *
* Damit das Skript wie vorgesehen funktioniert, stellen Sie bitte folgendes sicher: *
*                                                                                   *
* 1. Aktivieren Sie im Celestia-Men� "Darstellung" -> "Anzeige-Optionen..."         *
*    folgende Auswahl-Box:                                                          *
*                                                                                   *
*	"Orbits Planeten" (siehe auch Image 'deep-impact_einstellungen.gif'         *
*                                                                                   *
*    Leider kann dies nicht durch das Script selbst vorgenommen werden. :-(         *
*                                                                                   *
* 2. Deaktivieren Sie unbedingt evtl. in Ihrer Celestia-Installation bereits ent-   *
*    haltene SSC-Dateien, die Tempel 1 betreffen (z.B. DIRL_comets.ssc).            *
*    Benennen Sie eine solche Datei einfach um in z.B. "DIRL_comets.ssc.OFF".       *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* BENUTZUNG DES SCRIPTS                                                             *
* =====================                                                             *
*                                                                                   *
* Die gesamte Tour besteht aus 2 Teilen in einer interaktiv kontrollierbaren        *
* CELX-Datei:                                                                       *
*                                                                                   *
* Teil 1 = Tempel 1                                                                 *
* Teil 2 = Deep Impact (inkl. Einschlag-Sequenz)                                    *
*                                                                                   *
* Sie k�nnen w�hlen, welchen Teil der Tour Sie laufen lassen m�chten (wenn das      *
* Script gestartet wurde und nachdem jeweils ein Teilabschnitt beendet ist)!        *
*                                                                                   *
* Nach dem Start des Scripts (und nachdem jeweils ein Teil der Tour abgeschlossen   *
* ist), k�nnen Sie durch Dr�cken der Tasten [1] und [2] oberhalb der Tastatur       *
* (NICHT im Ziffernblock!) den gew�nschten Teil der Tour starten.                   *
* Mit der Taste [c] k�nnen Sie den n�chsten Teil der Tour beginnen.                 *
* Mit [Esc] k�nnen Sie jederzeit die Tour abbrechen und beenden.                    *
*                                                                                   *
* Nach dem Dr�cken der Tasten [1], [2] oder [c] kann es einige Sekunden dauern, bis *
* der Teil zu laufen beginnt, weil zun�chst die Modelle geladen werden.             *
*                                                                                   *
* Das Script wird nach Beendigung oder einem Abbruch der Tour die Einstellungen     *
* der Darstellung (wie Wolken, Finsternisse, Galaxien usw.) wieder so einzustellen, *
* wie sie vor der Ausf�hrung des Scripts von Ihnen definiert waren.                 *
* Sie m�ssen also nach der Ausf�hrung des Scripts Ihre Einstellungen nicht selbst   *
* wieder anpassen, sofern diese Einstellungen vom Scripts umgestellt worden sein    *
* sollten.                                                                          *
*                                                                                   *
* Beispiel:                                                                         *
* Sie haben grunds�tzlich die Galaxien eingeschaltet. Das Script schaltet die       *
* Galaxien jedoch ab, da diese w�hrend der Tour nicht ben�tigt werden und nur       *
* unn�tig Rechenleistung in Anspruch nehmen w�rden. Beim Beenden des Scripts durch  *
* [ESC] werden die Galaxien (und alle weiteren ver�nderten Einstellungen) wieder    *
* eingerichtet. Alles sollte also wieder so eingestellt sein, wie es vorher war.    *
*                                                                                   *
* DAS ZUR�CKSETZEN DER EINSTELLUNGEN FUNKTIONIERT NICHT, WENN SIE CELESTIA BEENDEN, *
* OHNE VORHER MIT [ESC] DAS SCRIPT BEENDET ZU HABEN.                                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Nur f�r den privaten Gebrauch! �ffentliche Auff�hrung oder Vetrieb des Scriptes   *
* auf Datentr�ger jedweder Art nur mit schriftlicher Genehmigung des Urhebers       *
* zul�ssig!                                                                         *
* Bitte respektieren Sie die Copyright- und Lizenzbestimmungen und informieren mich *
* �ber Ihre geplanten Auff�hrungs- oder Vetriebsabsichten!                          *
* --> http://www.celestia.de.vu/                                                    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* CREDITS:                                                                          *
* ========                                                                          *
*                                                                                   *
* Original CEL-Script:	Vincent Giangiulio                                          *
*			eMail: vince.gian@free.fr                                   *
* Deep Impact Addon:	Jestr                                                       *
*			eMail: jestr@ntlworld.com                                   *
* Impactor model:	Jack Higgins                                                *
			Website: http://homepage.eircom.net/~jackcelestia/          *
* DeepImpact-de.celx:	Ulrich "Adirondack" Dickmann                                *
*                     	Website: http://www.celestia.de.vu/                         *
* _________________________________________________________________________________ *
* Informationen zur Deep Impact Mission: http://deepimpact.umd.edu/                 *
*                                                                                   *
*************************************************************************************