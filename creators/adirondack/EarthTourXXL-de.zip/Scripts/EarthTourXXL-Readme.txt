*************************************************************************************
*                                                                                   *
*                   EarthTour-de.cel V1.01 - Last Revision 11-08-04                 *
*                                                                                   *
*                                F�r Celestia 1.3.2                                 *
*                                                                                   *
* Last revised on 8 Nov. 04: Translation of the script (V1.01) by Adirondack.       *
*                                                                                   *
* Diese Earth-Tour erfordert alle Dateien, die in diesem Paket enthalten sind.      *
* Wenn Sie nicht ALLE Dateien in die entsprechenden Ordner entpacken, k�nnen Sie    *
* die Tour nicht wie vorgesehen durchf�hren.                                        *
* Falls Sie bereits Jestr's Station-V Add-On installiert haben sollten, brauchen    *
* Sie diese Add-On-Dateien jedoch nicht erneut installieren.                        *
*                                                                                   *
* Eine "abgespeckte" Minimal-Version dieser Tour wird von mir nicht angeboten, da   *
* die Earth-Tour ohne die erforderlichen Texturen m.E. keinen Sinn machen w�rde.    *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Entpacken Sie die Datei EarthTour-de.cel in das Hauptverzeichnis von Celestia     *
* oder in das Verzeichnis ...\Celestia\Scripts\, wenn Sie ein solches Verzeichnis   *
* angelegt haben. Die Dateien EarthTour.ssc, EarthTourLocs.ssc und moon_locs2.ssc   *
* entpacken Sie in das Verzeichnis ...\Celestia\extras\.                            *
*                                                                                   *
* Noch bequemer geht es, wenn Sie in Ihrem Entpackprogramm (z.B. WinZip) auf        *
* "Extrahiere" klicken und das Hauptverzeichnis von Celestia (...\Celestia\)        *
* als Ziel ausw�hlen und die Option "Pfadangaben verwenden" aktivieren              *
* (in anderen Entpackprogrammen hei�t diese Option �hnlich).                        *
* Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen       *
* Celestia-Unterverzeichnisse entpackt.                                             *
* Lesen Sie jedoch zun�chst auch die nachfolgenden Hinweise!                        *
*                                                                                   *
*                                                                                   *
* Um die neuen Texturen in Celestia einzubinden, gehen Sie wie folgt vor:           *
*                                                                                   *
* 1. Entpacken Sie die Dateien Earth2k.jpg, EarthNight2k.jpg, EarthClouds.png und   *
*    Moon2k.jpg in das Verzeichnis ..\Celestia\textures\medres .                    *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, werden  *
*    die Textur-Dateien automatisch in das richtige Verzeichnis entpackt.           *
*                                                                                   *
* 2. Falls Sie das Add-On "Station V" von Jestr noch nicht installiert haben,       *
*    m�ssen Sie auch die nachfolgenden Dateien in die richtigen Verzeichnisse ent-  *
*    packen, wobei die Verzeichnisse ...\StationV\ usw. anzulegen sind.             *
*    Wenn Sie den Entpackvorgang wie oben beschrieben mit WinZip vornehmen, werden  *
*    die Dateien automatisch in das richtige Verzeichnis entpackt, wobei auch die   *
*    noch zu erstellenden Verzeichnisse automatisch angelegt werden.                *
*                                                                                   *
*    Entpacken Sie die Datei "Space Station V.ssc" in das Verzeichnis               *
*    ...\extras\StationV\                                                           *
*    Entpacken Sie die Datei "stationV_new.3ds" in das Verzeichnis                  *
*    ...\extras\StationV\models\                                                    *
*    Entpacken Sie die nachfolgenden Textur-Dateien in das Verzeichnis              *
*    ...\extras\StationV\textures\medres\                                           *
*                                                                                   *
*       Rim.jpg                   BayS.jpg                Spoke.jpg                 *
*       Spindle.jpg               Block.jpg               BayT.jpg                  *
*       Hub.jpg                                                                     *
*                                                                                   *
*    Wenn Sie das Add-On "Space Station V" sp�ter nicht mehr benutzen m�chten,      *
*    l�schen Sie einfach den Ordner ...\StationV\ im ...\extras\-Verzeichnis.       *
*    Beachten Sie jedoch, dass dann die letzten Minuten der Earth-Tour witzlos      *
*    werden.                                                                        *
*                                                                                   *
*************************************************************************************
*                                                                                   *
*    Damit die neuen Texturen f�r die Erde und den Mond angezeigt werden, k�nnen    *
*    Sie entweder die Datei solarsys.ssc modifizieren oder die weiter unten         *
*    beschriebene Alternative anwenden (empfohlen).                                 *
*                                                                                   *
*    Wenn Sie die Datei solarsys.ssc (im Ordner ..\Celestia\data\) �ndern m�chten,  *
*    gehen Sie wie folgt vor:                                                       *
*                                                                                   *
*    A. Unter dem Datensatz "Earth" "Sol" �ndern Sie die Textur-Definitionen        *
*       wie folgt:                                                                  *
*                                                                                   *
*	Texture "Earth2k.jpg"                                                       *
*	NightTexture "EarthNight2k.jpg"                                             *
*       CloudMap "EarthClouds.png"                                                  *
*                                                                                   *
*    B. Unter dem Datensatz "Moon" "Sol/Earth" �ndern Sie die Textur-Definition     *
*       wie folgt:  Texture "Moon2k.jpg"                                            *
*                                                                                   *
*                                                                                   *
*    ALTERNATIVE:                                                                   *
*    Wenn Sie m�chten, k�nnen Sie die neuen Texturen auch im Bedarfsfall "nur"      *
*    zuschalten. Dann brauchen Sie die Datei solarsys.ssc NICHT modifizieren.       *
*    Sie klicken dann bei Bedarf einfach mit einem Rechtsklick auf die Erde und     *
*    w�hlen im erscheinenden Kontextmen� "EarthTour" aus! Daraufhin werden die      *
*    neuen Texturen von Celestia angezeigt (sofern Sie diese wie unter 1. be-       *
*    schrieben in das Verzeichnis ..\Celestia\textures\medres eingef�gt haben.      *
*    Damit Sie eine Auswahl der Texturen �ber das Kontextmen� der Erde vornehmen    *
*    k�nnen, hat Bob die gesonderte Datei EarthTour.ssc geschrieben, die Sie in     *
*    das Verzeichnis ..\Celestia\extras\ entpacken m�ssen (s.o.).                   *
*    Sie k�nnen die neuen Texturen einschalten, ohne das Script ausf�hren           *
*    zu m�ssen. Wenn Sie wieder Ihre alten Texturen angezeigt haben m�chten,        *
*    w�hlen Sie einfach im Kontextmen� der Erde die Option "Normal" aus.            *
*                                                                                   *
*    Bitte w�hlen Sie die alternativen Texturen wie oben beschrieben vor dem Start  *
*    des Scripts aus und nicht erst, wenn das Script bereits l�uft!                 *
*                                                                                   *
*    Wenn Sie die neuen Wolkenstrukturen f�r die Erde nutzen m�chten, m�ssen Sie    *
*    aber auf jeden Fall die Datei solarsys.ssc modifizieren!                       *
*    Sie finden die Datei solarsys.ssc im Ordner ..\Celestia\data\ .                *
*                                                                                   *
*    Unter dem Datensatz "Earth" "Sol" �ndern Sie die Textur-Definition wie         *
*    folgt:                                                                         *
*              CloudMap "EarthClouds.png"                                           *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* HINWEIS: Falls Sie nicht s�mtliche Orte/Merkmale auf der Erde usw. sehen          *
*          m�chten, w�hrend das Script l�uft, schalten Sie �ber den Men�punkt       *
*          "Darstellung" bzw. "Render" und dort �ber "Orte/Merkmale" bzw.           *
*          "Locations" den Punkt "Merkmale anzeigen" bzw. "Label Features" aus.     *
*          Noch einfacher geht's mit dem Tastaturk�rzel SHIFT + "&".                *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Zus�tzlicher TIPP von Adirondack:                                                 *
* Falls die das "Blue Marble DDS"-Add-On der NASA installiert haben, sollten Sie    *
* die Earth-Tour alternativ auch einmal mit dieser Textur abspielen. Dazu w�hlen    *
* Sie im Kontext-Men� der Erde "Blue Marble DDS" (statt "Earth Tour") aus und       *
* starten anschliessend das Script.                                                 *
*                                                                                   *
* __________________________________________________________________________________*
* Credits:                                                                          *
*                                                                                   *
* Earth2k.jpg        - Author: Don Edwards                                          *
* EarthNight2k.jpg   - Author: Don Edwards                                          *
* EarthClouds.png    - Author: Don Edwards                                          *
*                                                                                   *
* Don's Website: http://www.shatters.net/~impulse/Earth_Central/Earth_Central.html  *
* Don's E-Mail:  donald_edwards_38@msn.com                                          *
*                                                                                   *
* Moon2k.jpg         - Author: Jens Meyer                                           *
*                                                                                   *
* Jens' Website: http://home.arcor.de/jimpage/                                      *
* Jens' E-Mail:  jimpage@arcor.de                                                   *
*                                                                                   *
* Space Station V add-on - Author: Jestr                                            *
* Jestr's E-Mail: jestr@ntlworld.com                                                *
*                                                                                   *
* EarthTour.cel      - Author: Bob Hegwood                                          *
* EarthTourLocs.ssc  - Author: Bob Hegwood                                          *
* EarthTour.ssc      - Author: Bob Hegwood                                          *
* EarthTour-de.cel   - �bersetzung: Ulrich "Adirondack" Dickmann                    *
*                      Website: http://www.celestia.de.vu/                          *
* _________________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Besuchen Sie auch Bob's neue Website unter http://www.bobhegwood.com              *
*                                                                                   *
*************************************************************************************