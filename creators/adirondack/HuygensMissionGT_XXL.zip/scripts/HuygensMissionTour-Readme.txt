*************************************************************************************
*                                                                                   *
*                    HuygensMissionTour.celx V1.0 (Grand Tour)                      *
*             Enhanced version with new models of Cassini and Huygens               *
*           Original Celestia script by Ulrich Dickmann (aka Adirondack)            *
*                                                                                   *
*                          for Celestia 1.3.2 (or later)                            *
*                                                                                   *
*************************************************************************************
* Please note that this tour doesn't work with Celestia 1.3.1.                      *
*************************************************************************************
*                                                                                   *
* If you have already installed my HuygensMissionTour.cel (V1.0 - 12/20/2004), you  *
* can delete it. It will not run correctly with the models you're going to install  *
* with this Grand Tour. Don't worry though, the HuygensMissionTour.cel has become a *
* part of the new HuygensMissionTour.celx.                                          *
*                                                                                   *
* This tour contains much more information about the Cassini-Huygens-Mission,       *
* including the descent of Huygens onto Titan. Jestr's impressive models of the     *
* orbiter and (landing) probe are also included within this enhanced package.       *
* If you already have Jestr's models, you don't have to install these models again. *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* INSTALLATION                                                                      *
* ============                                                                      *
*                                                                                   *
* When you unzip this package using your zip program (e.g. WinZip), click on        *
* "Extract" and select the main folder of Celestia (...\Celestia\) as the target    *
* directory.                                                                        *
* Make sure that you activate the option to "Use subfolders" (or similar option)    *
* while un-packing. All (or the selected files) will be copied into the correct     *
* Celestia subfolder(s).                                                            *
*                                                                                   *
* You will find the touring script in a folder named \scripts\.                     *
* I would recommend that you store your scripts in a folder like \scripts\ just so  *
* they're easier to keep track of.                                                  *
* For your convenience, the \scripts\ folder is built automatically when you unzip  *
* the package as described above.                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* HOW TO CONTROL THE SCRIPT                                                         *
* =========================                                                         *
*                                                                                   *
* The entire tour consists of 4 parts within an interactively controlled CELX-file: *
*                                                                                   *
* Part 1 = Mission preview (this is the earlier provided mission tour, updated and  *
*          configured to display Jestr's Cassini model correctly).                  *
* Part 2 = The descent of Huygens (with the main parachute descent, stage 1).       *
* Part 3 = Huygens' scientific payload (with a description of the instruments, and  *
*          stage 2 of the parachute descent).                                       *
* Part 4 = Exploration of the Cassini orbiter and some of its devices.              *
*                                                                                   *
* The entire duration of this presentation (all parts) is approximately 62 minutes. *
*                                                                                   *
* You can choose which part of the tour you wish to view. This can be done when the *
* script is first started, and again after each section of the tour has finished.   *
*                                                                                   *
* After you've started the script - and again after each part of the tour has run - *
* you can start (or restart) the desired section of the tour by pressing the number *
* keys from 1 to 4 at the top of your keyboard. NOTE: Use of the numeric keypad     *
* will NOT work! In other words, use the following keys (without pressing the shift *
* key) to select and view parts 1 through 4 of this extended script.                *
*                                                                                   *
* For part 1, press the key with the number 1 on it.                                *
* For part 2, press the key with the number 2.                                      *
* For part 3, press the key with the number 3.                                      *
* For part 4, press the key with the number 4.                                      *
*                                                                                   *
* With the key [ c ] you can continue the tour (advance to the next part).          *
* With the key [ Esc ] you can cancel and exit the tour at any time.                *
*                                                                                   *
* After you have pressed [Esc] to cancel and exit the tour, the script will try to  *
* re-adjust your display preferences (i.e. - clouds, eclipse shadows, galaxies,     *
* etc.) so that they are set as they were before the execution of the script.       *
* When you exit the script by pressing [Esc], you should NOT have to reset your     *
* preferences.                                                                      *
* This re-adjustment will not work, when you exit Celestia without pressing [Esc]   *
* at first to exit the script.                                                      *
*                                                                                   *
* Example:                                                                          *
* If you have switched ON galaxy rendering, the script will switch this function    *
* OFF. Galaxies are not needed during the tour and will unnecessarily degrade your  *
* system's performance. When the tour terminates, the script will try to switch ON  *
* galaxy rendering again. It will also try to reset all other settings which the    *
* script might have changed. The end result is that all of your display settings    *
* should be reset to the state at which they were BEFORE you ran the script.        *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Notice (concerning the coming Celestia 1.4.0)                                     *
* =============================================                                     *
*                                                                                   *
* If you will run this script later on with Celestia version 1.4.0, please be aware *
* of the following:                                                                 *
*                                                                                   *
* In part 1 of the tour we're looking at Titan's surface (clouds off) to see what   *
* we know about the surface BEFORE Huygens and Cassini visited there.               *
* Celestia 1.4.0 will probably provide a new texture for Titan's surface, so with   *
* Celestia 1.4.0 you will be looking at the surface AFTER Huygens and Cassini       *
* have revealed more details of the surface.                                        *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* NOTICE: This script and all its contents are provided for your PRIVATE USE ONLY!  *
*         Any Public performance or distribution of this script is strictly         *
*         prohibited without the WRITTEN permission of the author!                  *
*                                                                                   *
*         ANY Commercial use is prohibited!                                         *
*                                                                                   *
* All contents (C)opyright 2005 by Ulrich Dickmann a.k.a. "Adirondack"              *
*                                                                                   *
* Please respect this copyright and inform me if you wish to show this script in    *
* a planned public performance or if you wish to distribute it. That's all I want.  *
* Thank you! --> http://www.celestia.de.vu/                                         *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Many thanks to Jestr for the impressive models, to Harald Schmidt for showing me  *
* how to code the interactive control panel and (last but not least) to Bob Hegwood *
* and Don Goyette. These two old geezers instigated me to start scripting.          *
* Bob also perused and inspected the english words and grammar for this english     *
* version of the script. Thanx, good ol' Bob! <grin>                                *
*                                                                                   *
* HuygensMissionTour.celx by Ulrich Dickmann (aka Adirondack)                       *
* Website: http://www.celestia.de.vu/                                               *
*                                                                                   *
*************************************************************************************