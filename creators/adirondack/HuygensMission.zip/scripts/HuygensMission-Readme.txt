*************************************************************************************
*                                                                                   *
*                      HuygensMissionTour.cel V1.0 - 20.12.2004                     *
*                                                                                   *
*           Original Celestia script by Ulrich Dickmann (aka Adirondack)            *
*                                                                                   *
*                                for Celestia 1.3.2                                 *
*                                                                                   *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* You don't need additional textures or other files to run this script.             *
* Simply run this Huygens-Mission tour with your basic installation of              *
* Celestia 1.3.2. But be aware that this tour doesn't work with Celestia 1.3.1.     *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* Extract the file 'HuygensMissionTour.cel' into the main folder of Celestia or     *
* into the subfolder '...\Celestia\scripts\', if you have such a folder. I would    *
* recommend that you store your scripts in a folder like \scripts\ just so they're  *
* easier to keep track of.                                                          *
*                                                                                   *
* When you unzip this package using your zip program (e.g. WinZip), click on        *
* "Extract" and select the main folder of Celestia (...\Celestia\) as the target    *
* directory.                                                                        *
* Make sure that you activate the option to "Use subfolders" (or similar option)    *
* while un-packing. All (or the selected files) will be copied into the correct     *
* Celestia subfolder(s).                                                            *
*                                                                                   *
*************************************************************************************
*                                                                                   *
* NOTICE: This package and all contents are provided for your PRIVATE USE ONLY!     *
*         Any Public performance or distribution of this script is strictly         *
*         prohibited without the WRITTEN permission of the author!                  *
*                                                                                   *
*         ANY Commercial use is prohibited!                                         *
*                                                                                   *
* All contents (C)opyright 2004 by Ulrich Dickmann a.k.a. "Adirondack"              *
*                                                                                   *
* Please respect this copyright and inform me if you wish to show this script in    *
* a planned public performance or if you wish to distribute it. That's all I want.  *
* Thank you! --> http://www.celestia.de.vu/                                         *
*                                                                                   *
*************************************************************************************