This texture was created originally by Steve Albers. See http://laps.fsl.noaa.gov/albers/sos/sos.html
for further information or updates. I only adapted it to celestia and did some cosmetics.

Simply put the whole unzipped package to the celestia/extras directory.

Have fun (June 6th 2006)

 J�rg
(guest jo)
