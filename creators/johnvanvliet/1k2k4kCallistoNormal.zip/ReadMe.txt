hi this is John Van Vliet please enjoy the maps 
-------------------------------------WARNING-------------------------------------------------------
---If you have my CallistoNormalLevel012.zip maps installed from http://celestiamotherlode.net/ ---
---      rename /extras/JohnVV/CallistoNormal.ssc to CallistoNormal.ssc.off OR delete it        ---
---------------------------------------------------------------------------------------------------
----------------------Vista Warning --------------------
--- you may need to edit the callisto.ssc in /extras ---
--- by adding  NormalMap " CallistoNormal.png"       ---
--------------------------------------------------------

Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras 
|   `-- CallistoNormal.ssc
`-- textures
    |-- hires
    |   `-- CallistoNormal.png
    |-- lores
    |   `-- CallistoNormal.png
    `-- medres
        `-- CallistoNormal.png

5 directories, 5 files

The orig. map data was from 
Artist's Concept 
And the 16 bit Height map ( 8kcallistoHeight.fits.zip ) image i used to make the Normal Map
http://www.zshare.net/download/10658352403aa7b9/

-----Callisto.ssc --- foe MS Vista -------------------
Modify "Callisto" "Sol/Jupiter"
{
	Texture "Callisto.png"
        NormalMap "CallistoNormal.png"
        SpecularColor [ 0.07 0.06 0.05 ]
	SpecularPower 0.2
}



