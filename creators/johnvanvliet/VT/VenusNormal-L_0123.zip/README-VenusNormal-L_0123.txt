
Venus Normal levels 0 , 1 , 2, and 3


To install:

for ALL operating systems 
If you installed the venus vt also you do not need the VenusNormal.ssc 
just uncomment the line
[
   # NormalMap "VenusNormal.ctx"
   ]
in the Venuc.ssc or Venus-SPICE.ssc 


Linux and generic 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"

Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 
and install as Administrator 
----------------------------------
Mac 
extract to or "copy/paste" 
/Users/<username>/Library/Application Support/CelestiaResources
or 
/Applications/Celestia.app/Contents/Resources/CelestiaResources/

----------------------------------

the zip archive extracts to this 

.
|-- extras
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- VenusNormal
|                   |-- level0
|                   |   |-- tx_0_0.png
|                   |   `-- tx_1_0.png
|                   |-- level1
|                   |   |-- tx_0_0.png
|                   |   |-- tx_0_1.png
                              to 
|                   |   |-- tx_3_0.png
|                   |   `-- tx_3_1.png
|                   |-- level2
|                   |   |-- tx_0_0.png
|                   |   |-- tx_0_1.png
                               to 
|                   |   |-- tx_7_2.png
|                   |   `-- tx_7_3.png
|                   `-- level3
|                       |-- tx_0_0.png
|                       |-- tx_0_1.png
                              to
|                       |-- tx_15_6.png
                        `-- tx_15_7.png

|-- README-VenusNormal-L_0123.txt



####### The data is from PDS #########

-- see the readme for the level 0 to 7 of the Texture 
for the processing of the radar data 


the NormalMap was created from the "footprint " Topographic data 
http://pds-imaging.jpl.nasa.gov/data/mgn-v-rdrs-5-gdr-topographic-v1.0/mg_3002/gtdr/

and from "Shape from Shade"  information created from the radar reflection data used for the texture 

the C1-MIDR compressed data 

http://pds-imaging.jpl.nasa.gov/data/mgn-v-rdrs-5-midr-c1-v1.0/



















