

to install:
unzip into your celestia root folder

OR

copy/paste the folder "JohnVV" in the alt extra folder you set up in the "celestia.cfg" file

Linux and genaric 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"


Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 

Windows 8 or 8.1 ????
this is unknown
----------------------------------
Apple Mac
extract to CelestiaResources/extras-standard
might be in 
/Users/<your username>/Library/Application Support/ 



the zip archive extracts to this 
.
|-- extras
|   `-- JohnVV
|       |-- EarthNight.ssc
|       `-- textures
|           `-- hires
|               |-- EarthNight
|               |   |-- level0
|               |   |   |-- tx_0_0.png
|               |   |   `-- tx_1_0.png
|               |   |-- level1
|               |   |   |-- tx_0_0.png
|               |   |   |-- tx_0_1.png
                           -- to --
|               |   |   |-- tx_3_0.png
|               |   |   `-- tx_3_1.png
|               |   `-- level2
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                            -- to --
|               |       |-- tx_7_2.png
|               |       `-- tx_7_3.png
|               |   `-- level3
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                         -- to ---
|               |       |-- tx_15_6.png
|               |       |-- tx_15_7.png
|               |   `-- level4
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                        --- to ---
|               |       |-- tx_31_14.png
|               |       |-- tx_31_15.png
|               `-- EarthNight.ctx

original data from 
http://ngdc.noaa.gov/eog/viirs/download_viirs_ntl.html
reprocessed using Gmic to remove noise and Cinepaint to clean up the Moonlite ground
Yes the moon lite up a LOT of the ground



added in a small percentage of  the
"2000_fires_version1_TIF.tar"
for the forest fires
ftp.ngdc.noaa.gov/DMSP/web_data/2000_change_pair

then colorized using "the Gimp" and the ISS astronaut photos on citylights
http://eol.jsc.nasa.gov/sseop/clickmap/









