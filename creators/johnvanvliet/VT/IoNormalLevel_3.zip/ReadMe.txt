hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING-------------------------------------------
---If you have my 1k,2k,4k, maps installed from http://celestiamotherlode.net/ ---
---rename /extras/(planet,moon name).ssc to (planet,moon name).ssc.off         ---
---examlpe /extras/IoNormal.ssc to /extras/IoNormal.ssc.off OR delete it       ---
----------------------------- Vista WARNING --------------------------------------
--- Vista users may need to edit /celestia/extras/JohnVV/textures/hires/Io.ssc ---
--- to get the Normal map to work by adding NormalMap "IoNormal.ctx" to it     ---
------------------------------END WARNING-----------------------------------------
----  You must FIRST install IoNormalLevel_012.zip
----  then IoNormalLevel_3.zip


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- IoNormal
|                   `-- level3
|                       |-- tx_0_0.png
|                       |-- tx_0_1.png
|                       |-- tx_0_2.png
|                       |-- tx_0_3.png
|                       |-- tx_0_4.png
|                       |-- tx_0_5.png
|                       |-- tx_0_6.png
|                       |-- tx_0_7.png
                               to
|                       |-- tx_15_0.png
|                       |-- tx_15_1.png
|                       |-- tx_15_2.png
|                       |-- tx_15_3.png
|                       |-- tx_15_4.png
|                       |-- tx_15_5.png
|                       |-- tx_15_6.png
|                       |-- tx_15_7.png






The orig. map data was from 
Artist's Concept 
And the 16 bit Height map ( 8kIoHeightMap16bitUnsignedMSB.fits ) image i used to make the Normal Map
http://www.zshare.net/download/95289844d0c308/

