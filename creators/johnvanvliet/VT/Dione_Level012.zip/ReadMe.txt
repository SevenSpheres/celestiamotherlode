hi this is John Van Vliet please enjoy the maps 
this is the level 0,1 and 2 tiles for the virtual texture map of Dione 
--------------------------------WARNING---------------------------------------------------
---   If you have my 1k,2k,and 4k maps installed from http://celestiamotherlode.net/   ---
---              rename /extras/Doine.ssc to Dione.ssc.off OR delete it                ---
----------------------------- End WARNING ------------------------------------------------
Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaSVN
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
------- mine is in ( Fedora 8 Linux )------- 
3) /usr/opt/CelestiaSVN
4) /usr/opt/share/celestia
------ or ------ 
5) /usr/share/celestia
6) /usr/local/share/celestia

   -----------------
this file unzips to 
.
|-- JVV_DioneL4ins.jpg
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       |-- Dione.ssc
|       `-- textures
|           `-- hires
|               |-- Dione
|               |   |-- level0
|               |   |   |-- tx_0_0.png
|               |   |   `-- tx_1_0.png
|               |   |-- level1
|               |   |   |-- tx_0_0.png
|               |   |   |-- tx_0_1.png
                               To
|               |   |   |-- tx_3_0.png
|               |   |   `-- tx_3_1.png
|               |   `-- level2
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                              To
|               |       |-- tx_7_2.png
|               |       `-- tx_7_3.png
|               `-- Dione.ctx

8 directories, 46 files
------------------------------
The orig. map data was from 
PDS
http://pdsimg.jpl.nasa.gov/data/cassini/cassini_orbiter/coiss_3003/data/images/  SD_1M_0_0_SIMP.IMG


