hi this is John Van Vliet please enjoy the maps 
-------------------------------------WARNING-------------------------------------------------
---If you have my 1k2k4kCallistoNormal maps installed from http://celestiamotherlode.net/ ---
---      rename /extras/CallistoNormal.ssc to CallistoNormal.ssc.off OR delete it         ---
---------------------------------- Vista WARNING --------------------------------------------
---       Vista users may need to edit /celestia/extras/JohnVV/Callisto.ssc               ---
---     to get the Normal map to work by adding NormalMap "CallistoNormal.ctx" to it      ---
------------------------------END WARNING----------------------------------------------------
----  You must FIRST install CallistoNormalLevel_012.zip
----  then CallistoNormalLevel_3.zip


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras 
|   `-- JohnVV
|       |-- CallistoNormal.ssc
|       `-- textures
|           `-- hires
|               |-- CallistoNormal
|               |   |-- level0
|               |   |   |-- tx_0_0.png
|               |   |   `-- tx_1_0.png
|               |   |-- level1
|               |   |   |-- tx_0_0.png
                               to
|               |   |   `-- tx_3_1.png
|               |   `-- level2
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                               to
|               |       |-- tx_7_2.png
|               |       `-- tx_7_3.png
|               `-- CallistoNormal.ctx

8 directories, 45 files


The orig. map data was from 
Artist's Concept 
And the 16 bit Height map ( 8kcallistoHeight.fits.zip ) image i used to make the Normal Map
http://www.zshare.net/download/10658352403aa7b9/

--- Callisto.ssc ---------- For MS Vista --------------
Modify "Callisto" "Sol/Jupiter"
{
	Texture "Callisto.ctx"
        NormalMap "CallistoNormal.ctx"
        SpecularColor [ 0.07 0.06 0.05 ]
	SpecularPower 0.2
}

