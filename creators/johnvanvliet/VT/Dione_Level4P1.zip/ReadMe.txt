hi this is John Van Vliet please enjoy the maps 
this is the level 4 Part 1 tiles for the virtual texture map of Dione 

------ Level 0,1 2,3 MUST BE INSTALLED FIRST ------
----------
Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaSVN
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
------- mine is in ( Fedora 8 Linux )------- 
3) /usr/opt/CelestiaSVN
4) /usr/opt/share/celestia
------ or ------ 
5) /usr/share/celestia
6) /usr/local/share/celestia

   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- Dione
|                   `-- level4
|                       |-- tx_0_0.png
|                       |-- tx_0_1.png
                              To
|                       |-- tx_15_14.png
|                       |-- tx_15_15.png

6 directories, 257 files
------------------------------
The orig. map data was from 
PDS
http://pdsimg.jpl.nasa.gov/data/cassini/cassini_orbiter/coiss_3003/data/images/  SD_1M_0_0_SIMP.IMG


