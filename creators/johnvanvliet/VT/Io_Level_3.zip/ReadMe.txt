hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING-------------------------------------------
---If you have my 1k,2k,4k, maps installed from http://celestiamotherlode.net/ ---
---rename /extras/(planet,moon name).ssc to (planet,moon name).ssc.off         ---
---examlpe /extras/Io.ssc to /extras/Io.ssc.off OR delete it     ---
------------------------------END WARNING-----------------------------------------

Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- Io
|                   `-- level3
|                       |-- tx_0_0.png
|                              to
|                       |-- tx_15_7.png
|                      
---------------------
The orig. map data was from 
http://pds-imaging.jpl.nasa.gov/resources/onlineData.html
http://pdsimg.jpl.nasa.gov/data/cassini/cassini_orbiter/coiss_3002/data/images/SE_500K_0_0_SIMP.IMG 
