-- Artists Concept - based on real imaging data -- 


to install:
Linux and generic 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"

Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 
and install as Administrator 
----------------------------------
Mac 
extract to or "copy/paste" 
/Users/<username>/Library/Application Support/CelestiaResources
or 
/Applications/Celestia.app/Contents/Resources/CelestiaResources/

----------------------------------

the zip archive extracts to this 

.
|-- extras
|   `-- JohnVV
|       |-- textures
|       |   |-- hires
|       |   |   |-- Venus
|       |   |   |   |-- level0
|       |   |   |   |   |-- tx_0_0.png
|       |   |   |   |   `-- tx_1_0.png
|       |   |   |   |-- level1
|       |   |   |   |   |-- tx_0_0.png
|       |   |   |   |   |-- tx_0_1.png
                           -- to --
|       |   |   |   |   |-- tx_3_0.png
|       |   |   |   |   `-- tx_3_1.png
|       |   |   |   |-- level2
|       |   |   |   |   |-- tx_0_0.png
|       |   |   |   |   |-- tx_0_1.png
                           -- to --
|       |   |   |   |   |-- tx_7_2.png
|       |   |   |   |   `-- tx_7_3.png
|       |   |   |   `-- level3
|       |   |   |       |-- tx_0_0.png
|       |   |   |       |-- tx_0_1.png
                            -- to --
|       |   |   |       |-- tx_15_6.png
|       |   |   |       |-- tx_15_7.png
|       |   |   |-- Venus.ctx
|       |   |   `-- VenusType.png
|       |   `-- medres
|       |       `-- VenusType.png
|       |-- Venus.SPICE.ssc.off
|       |-- Venus.ssc

There are TWO *.ssc files one is a disabled SPICE file  
if you are using SPICE ,edit & rename and use "Venus.SPICE.ssc.off"



####### The data is from PDS #########


This is the C1-MIDR compressed data 
 Global Reflectivity Data Record (GREDR)
see the C1 file list included 

http://pds-imaging.jpl.nasa.gov/volumes/magellan.html#mgnFMAP
or
http://pds-imaging.jpl.nasa.gov/data/mgn-v-rdrs-5-midr-c1-v1.0/
http://pds-geosciences.wustl.edu/geodata/mgn-v-rdrs-5-midr-full-res-v1/

#

the PDS data was then processed in ISIS3 using the "destripe" tool in isis3.3.0.3800
to remove the vertical stripes from the radar data 
SEE: example
http://pds-imaging.jpl.nasa.gov/data/mgn-v-rdrs-5-midr-c1-v1.0/mg_0002/extras/browse/c115n335/browse.img.jpeg
http://pds-imaging.jpl.nasa.gov/data/mgn-v-rdrs-5-midr-c1-v1.0/mg_0002/extras/browse/c115n335/c1f04.img.jpeg

#

Also "inpainted" to remove the "NO-DATA" areas 
With the Gimp tool "Resynthesizer"
http://registry.gimp.org/node/25219
based on thesis : http://www.logarithmic.net/pfh/thesis

#

Then ran through a meancurvature_flow PDE in G'mic to remove some of the inherent noise in radar data 
(formally GREYCstoration - https://www.greyc.fr/)
http://gmic.sourceforge.net/index.shtml

#

" VenusType.png" is a 100% synthetic venus cloud image 
( The clouds change so fast that any close approximation  will do )
see:
http://www.shatters.net/forum/viewtopic.php?f=5&t=16019&p=123619&hilit=venus#p123619
with the tools presented in the tutorial "making a planet using "The Gimp-continued- Gas Giant ""
http://www.shatters.net/forum/viewtopic.php?f=21&t=16128
