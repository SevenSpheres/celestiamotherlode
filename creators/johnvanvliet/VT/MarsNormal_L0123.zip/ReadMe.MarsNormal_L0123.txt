
to install:
Linux and generic 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"

Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 
and install as Administrator 
----------------------------------
Mac 
extract to or "copy/paste" 
/Users/<username>/Library/Application Support/CelestiaResources
or 
/Applications/Celestia.app/Contents/Resources/CelestiaResources/

this file unzips to 
.
|-- extras
|   `-- JohnVV
|       |-- MarsNormal.ssc
|       `-- textures
|           `-- hires
|               |-- MarsNormal
|               |   |-- level0
|               |   |   |-- tx_0_0.png
|               |   |   `-- tx_1_0.png
|               |   |-- level1
|               |   |   |-- tx_0_0.png
|               |   |   |-- tx_0_1.png
                          -- to --
|               |   |   |-- tx_3_0.png
|               |   |   `-- tx_3_1.png
|               |   |-- level2
|               |   |   |-- tx_0_0.png
|               |   |   |-- tx_0_1.png
                           -- to --
|               |   |   |-- tx_7_2.png
|               |   |   `-- tx_7_3.png
|               |   `-- level3
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                          -- to --
|               |       |-- tx_15_6.png
|               |       |-- tx_15_7.png

|               `-- MarsNormal.ctx
`-- ReadMe.MarsNormal_L0123.txt


the original data is from 
http://pds-geosciences.wustl.edu/missions/mgs/megdr.html
the 128 ppd megt
http://pds-geosciences.wustl.edu/geo/mgs-m-mola-5-megdr-l3-v1/mgsl_300x/meg128/









