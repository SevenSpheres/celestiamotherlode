hi this is John Van Vliet please enjoy the maps 

Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in C:\\Celestia
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 6 Linux )-------
5)  /opt/Celestia  and
6)  /opt/CelestiaCVS
   -----------------
The level 0,1,2 zip files will unzip to 
/textures/hires/(file name)/level0,level1,level2...
/textures/hires/FileName.ctx
   and
/extras/FileName.ssc
   -----------------
The level3 zip file will unzip to 
/textures/hires/(file name)/level3
   -----------------
The level4P1 zip file will unzip to 
/textures/hires/(file name)/level4
   -----------------
The level4P2 zip file will unzip to 
/textures/hires/(file name)/level4
   -----------------
The level5P1 zip file will... you get the idea 

start Celestia and have fun 
