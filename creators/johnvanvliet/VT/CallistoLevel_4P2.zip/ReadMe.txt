hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING----------------------------------------------
---If you have installed 2k4k8k_Callisto.zip from http://celestiamotherlode.net/  ---
---rename /celestia/extras/Callisto.ssc to Calloisto.ssc.off  OR delete it        ---
----------------------------- end WARNING -------------------------------------------
----  You must FIRST install CallistoLevel_012.zip
----  then install CallistoLevel_3.zip ,
                ---CallistoLevel_4P1.zip , 
                ---CallistoLevel_4P2.zip , 
                ---CallistoLevel_4P3.zip ,
                ---CallistoLevel_4P4.zip  


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- Callisto
|                   `-- level4
|                       |-- tx_8_0.png
                              to
|                       `-- tx_15_9.png


The orig. map data was from 
http://pds-imaging.jpl.nasa.gov/Missions/Galileo_mission.html
http://pds-imaging.jpl.nasa.gov/Missions/Voyager_mission.html
http://www.mapaplanet.org/


