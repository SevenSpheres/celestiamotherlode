hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING---------------------------------------------
---If you have installed Europa_2k_4k_8k.zip from http://celestiamotherlode.net/ ---
---    rename /celestia/extras/Europa.ssc to Europa.ssc.off  OR delete it        ---
----------------------------- End WARNING ------------------------------------------
----  You must FIRST install EuropaLevel_012.zip
----  then EuropaLevel_3.zip
----  then EuropaLevel_4P1.zip
----  then EuropaLevel_4P2.zip


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaSVN
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
------- mine is in ( Fedora 8 Linux )------- 
3) /usr/opt/CelestiaSVN
4) /usr/opt/Celestia 
------ or ------ 
5) /usr/share/celestia
6) /usr/local/share/celestia

   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       |-- Europa.ssc
|       `-- textures
|           `-- hires
|               |-- Europa
|               |   |-- level0
|               |   |   |-- tx_0_0.png
|               |   |   `-- tx_1_0.png
|               |   |-- level1
|               |   |   |-- tx_0_0.png
                              to
|               |   |   `-- tx_3_1.png
|               |   `-- level2
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                               to
|               |       |-- tx_7_2.png
|               |       `-- tx_7_3.png
|               `-- Europa.ctx

8 directories, 45 files
------------------------------
The orig. map data was from 
PDS
http://www.mapaplanet.org/


