hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING---------------------------------------------
---If you have installed Europa_2k_4k_8k.zip from http://celestiamotherlode.net/ ---
---    rename /celestia/extras/Europa.ssc to Europa.ssc.off  OR delete it        ---
----------------------------- End WARNING ------------------------------------------
----  You must FIRST install EuropaLevel_012.zip
----  then EuropaLevel_3.zip
----  then EuropaLevel_4P1.zip
----  then EuropaLevel_4P2.zip


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaSVN
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
------- mine is in ( Fedora 8 Linux )------- 
3) /usr/opt/CelestiaSVN
4) /usr/opt/Celestia 
------ or ------ 
5) /usr/share/celestia
6) /usr/local/share/celestia

   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- Europa
|                   `-- level3
|                       |-- tx_0_0.png
|                       |-- tx_0_1.png
|                       |-- tx_0_2.png
|                       |-- tx_0_3.png
|                       |-- tx_0_4.png
|                       |-- tx_0_5.png
|                       |-- tx_0_6.png
|                       |-- tx_0_7.png
                              to
|                       |-- tx_15_0.png
|                       |-- tx_15_1.png
|                       |-- tx_15_2.png
|                       |-- tx_15_3.png
|                       |-- tx_15_4.png
|                       |-- tx_15_5.png
|                       |-- tx_15_6.png
|                       |-- tx_15_7.png


6 directories, 129 files
------------------------------
The orig. map data was from 
PDS
http://www.mapaplanet.org/


