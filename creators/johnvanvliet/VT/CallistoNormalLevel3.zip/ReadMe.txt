hi this is John Van Vliet please enjoy the maps 
-------------------------------------WARNING-------------------------------------------------
---If you have my 1k2k4kCallistoNormal maps installed from http://celestiamotherlode.net/ ---
---      rename /extras/CallistoNormal.ssc to CallistoNormal.ssc.off OR delete it         ---
---------------------------------------------------------------------------------------------
----  You must FIRST install CallistoNormalLevel_012.zip
----  then CallistoNormalLevel_3.zip


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras 
|   `-- JohnVV
|       `-- textures
|           `-- hires
|               `-- CallistoNormal
|                   `-- level3
|                       |-- tx_0_0.png
|                       |-- tx_0_1.png
|                       |-- tx_0_2.png
                              to
|                       |-- tx_15_5.png
|                       |-- tx_15_6.png
|                       |-- tx_15_7.png


6 directories, 129 files


The orig. map data was from 
Artist's Concept 
And the 16 bit Height map ( 8kcallistoHeight.fits.zip ) image i used to make the Normal Map
http://www.zshare.net/download/10658352403aa7b9/


