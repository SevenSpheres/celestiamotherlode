
to install:
Linux and generic 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"

Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 
and install as Administrator 
----------------------------------
Mac 
extract to or "copy/paste" 
/Users/<username>/Library/Application Support/CelestiaResources
or 
/Applications/Celestia.app/Contents/Resources/CelestiaResources/

this file unzips to 
.
|-- extras
|   `-- JohnVV
|       |-- Mars.ssc
|       `-- textures
|           `-- hires
|               |-- Mars
|               |   |-- level0
|               |   |   |-- tx_0_0.png
|               |   |   `-- tx_1_0.png
|               |   |-- level1
|               |   |   |-- tx_0_0.png
|               |   |   |-- tx_0_1.png
                          -- to --
|               |   |   |-- tx_3_0.png
|               |   |   `-- tx_3_1.png
|               |   |-- level2
|               |   |   |-- tx_0_0.png
|               |   |   |-- tx_0_1.png
                          -- to --
|               |   |   |-- tx_7_2.png
|               |   |   `-- tx_7_3.png
|               |   `-- level3
|               |       |-- tx_0_0.png
|               |       |-- tx_0_1.png
                          -- to -- 
|               |       |-- tx_15_6.png
|               |       |-- tx_15_7.png
|               `-- Mars.ctx
`-- ReadMe.Mars_L0123.txt


the orig. images are from 
"Malin Space Science Systems"
http://www.msss.com/mgcwg/mgm/
the B&W images were "flattened" ( highlight and shadow removal ) and colorized by me 
the B&W image is also available at 
http://www.mapaplanet.org/explorer/mars.html

-- yes this is the OLD "Mars Orbital Camera " wide angle images 
-- and NOT the MRO data 



