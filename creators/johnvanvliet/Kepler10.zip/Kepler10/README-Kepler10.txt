

to install:
unzip into your celestia extra folder

OR

copy/paste the folder "Kepler10" into the alt extra folder you set up in the "celestia.cfg" file

Linux and generic
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"


Windows ( Vista,Windows 7 ,8 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 

Windows 8 or 8.1 ????
this is unknown
----------------------------------
Apple Mac
extract to CelestiaResources/extras-standard
might be in 
/Users/<your username>/Library/Application Support/ 



the zip archive extracts to this 
.
├── cc-by-sa.odt
├── Kepler-10.ssc
├── README-Kepler10.txt
└── textures
    └── medres
        ├── 10b.Night.png
        ├── 10b.Normal.png
        ├── 10b.png
        ├── 10c.Cloud.png
        ├── 10c.Night.png
        ├── 10c.Normal.png
        └── 10c.png


Kepler 10 B is tidally locked and so close to the parent star that the day side is about 2400 K

Kepler 10 C should not exist
it is a rocky body and not a small gas planet






