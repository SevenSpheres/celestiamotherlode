
to install:
Linux and generic 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"

Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 
and install as Administrator 
----------------------------------
Mac 
extract to or "copy/paste" 
/Users/<username>/Library/Application Support/CelestiaResources
or 
/Applications/Celestia.app/Contents/Resources/CelestiaResources/

this archive extracts to 
.
|-- extras
|   `-- JohnVV
|       |-- Jupiter.ssc
|       `-- textures
|           |-- hires
|           |   `-- Jupiter.png
|           |-- lores
|           |   `-- Jupiter.png
|           `-- medres
|               |-- JupiterNight.png
|               |-- Jupiter.png
|               `-- JupiterRings.png
`-- ReadMe.Jupiter.txt



The original data is from ...
Jupiter map  is from 
http://photojournal.jpl.nasa.gov/tiff/PIA07782.tif

the NightMap is based on 
http://www.solarviews.com/cap/jup/jupaur2.htm
http://www.solarviews.com/cap/jup/jupaur.htm

the rings are based on
http://pds-rings.seti.org/jupiter/artwork/PIA01627.html
http://pds-rings.seti.org/jupiter/galileo/PIA01623.html







