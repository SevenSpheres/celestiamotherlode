hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING-------------------------------------------
---If you have my VT Io map installed from http://celestiamotherlode.net/      ---
---rename /extras/JohnVV(planet,moon name).ssc to (planet,moon name).ssc.off   ---
---examlpe /extras/JohnVV/Io.ssc to /extras/JohnVV/Io.ssc.off OR delete it     ---
------------------------------END WARNING-----------------------------------------
Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
`-- textures
    `-- hires
        `-- Io.png
    `--medres 
        `-- Io.png
    `--lores 
        `-- Io.png
`-- extras
     `-- Io.ssc
---------------------
The orig. map data was from 
http://astrogeology.usgs.gov/Projects/JupiterSatellites/io.html
http://astrogeology.usgs.gov/Projects/JupiterSatellites/io/Io_SSI_VGR_color_merge_SIMP0.cub.gz
