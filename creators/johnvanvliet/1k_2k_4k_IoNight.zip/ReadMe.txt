hi this is John Van Vliet please enjoy the maps 

Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- IoNight.ssc
`-- textures
    |-- hires
    |   `-- IoNight.png
    |-- lores
    |   `-- IoNight.png
    `-- medres
        `-- IoNight.png
The orig data is from here 
Artists concept based on 
http://photojournal.jpl.nasa.gov/tiff/PIA10100.tif
http://photojournal.jpl.nasa.gov/tiff/PIA09354.tif
http://photojournal.jpl.nasa.gov/tiff/PIA01637.tif 
