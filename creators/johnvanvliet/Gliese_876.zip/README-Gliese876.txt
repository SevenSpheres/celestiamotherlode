
4k maps for this "exoplanet" solar system 

to install:
Linux and generic 
just extract the archive into "/usr/share/celestia " or "/usr/local/share/celestia"
or copy ( extras)it to where you installed celestia "/usr/share/celestia " or "/usr/local/share/celestia"

Windows ( XP,Vista,Windows 7 )--
-----------------------------------
 same as above but C:\\Program Files\celestia  or C:\\Celestia 
for vista and windows 7 I would suggest installing Celestia in " C:\\Celestia 


----------------------------------
Mac 
extract to or "copy/paste" 
/Users/<username>/Library/Application Support/CelestiaResources
or 
/Applications/Celestia.app/Contents/Resources/CelestiaResources/


the zip archive extracts to this 
.
|-- extras
|   `-- JohnVV
|       `-- Gliese876
|           |-- Gliese876.ssc
|           `-- textures
|               `-- medres
|                   |-- b_Gliese876.png
|                   |-- c_Gliese876.png
|                   |-- c_RingGliese876.png
|                   |-- d_CloudsGliese876.png
|                   |-- d_Gliese876.png
|                   |-- d.night_Gliese876.png
|                   |-- d_NormalGliese876.png
|                   `-- e_Gliese876.png
`-- README-Gliese876

all maps are created by me 
using the tools outlined in the Tutorials i posted on 
Board index » Celestia Help » Tutorials
http://www.shatters.net/forum/viewforum.php?f=21

and based on the VERY ( and i do mean VERY little information ) small amount of information that is available 
http://en.wikipedia.org/wiki/Gliese_876
and the reference links no that page like
http://simbad.u-strasbg.fr/simbad/sim-id?Ident=Gliese+876










