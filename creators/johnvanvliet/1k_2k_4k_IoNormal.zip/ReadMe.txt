hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING-------------------------------------------
---If you have installed IoNormalLevel_012.zip from http://celestiamotherlode.net/ ---
---rename /celestia/extras/JohnVV/IoNormal.ssc to IoNormal.ssc.off  OR delete it   ---
----------------------------- Vista WARNING --------------------------------------
--- Vista users may need to edit /celestia/extras/Io.ssc ---
--- to get the Normal map to work by adding NormalMap "IoNormal.png" to it     ---
------------------------------END WARNING-----------------------------------------



Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 

.
|-- ReadMe.txt
|-- extras
|   `-- IoNormal.ssc
|-- list
`-- textures
    |-- hires
    |   `-- IoNormal.png
    |-- lores
    |   `-- IoNormal.png
    `-- medres
        `-- IoNormal.png

5 directories, 6 files

The orig. map data was from 
Artist's Concept 
And the 16 bit Height map ( 8kIoHeightMap16bitUnsignedMSB.fits ) image i used to make the Normal Map
http://www.zshare.net/download/95289844d0c308/

-------For Windows Vista ------
-----------Io.ssc -------------
Modify "Io" "Sol/Jupiter"
{
	Texture "Io.png"
        NormalMap "IoNormal.png"
	   	
}

-------------------------------

