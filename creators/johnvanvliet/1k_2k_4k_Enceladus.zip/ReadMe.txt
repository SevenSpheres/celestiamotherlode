hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING-----------------------------------------------
---If you have my VT Enceladus map installed from http://celestiamotherlode.net/   ---
---rename /extras/JohnVV/(planet,moon name).ssc to (planet,moon name).ssc.off      ---
---examlpe /extras/JohnVV/Enceladus.ssc to /extras/Enceladus.ssc.off OR delete it  ---
------------------------------END WARNING---------------------------------------------
Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
`-- textures
    `-- hires
        `-- Enceladus.png
    `--medres 
        `-- Enceladus.png
    `--lores 
        `-- Enceladus.png
`-- extras
     `-- Enceladus.ssc
---------------------
The orig. map data was from 
http://pds-imaging.jpl.nasa.gov/resources/onlineData.html
http://pdsimg.jpl.nasa.gov/data/cassini/cassini_orbiter/coiss_3002/data/images/SE_500K_0_0_SIMP.IMG 
