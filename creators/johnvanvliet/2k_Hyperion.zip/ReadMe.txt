hi this is John Van Vliet please enjoy the maps 


Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaSVN
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
------- mine is in ( Fedora 8 Linux )------- 
3) /usr/opt/CelestiaSVN
4) /usr/opt/Celestia 
------ or ------ 
5) /usr/share/celestia
6) /usr/local/share/celestia

   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- Hyperion.ssc
`-- textures
    `-- medres
        |-- JVV_Hyperion.png
        `-- JVV_HyperionLOK.png

3 directories, 4 files
------------------------------
The orig. map data was from 
PDS
http://pds-imaging.jpl.nasa.gov/Missions/Cassini_mission.html
or
http://pdsimg.jpl.nasa.gov/search/index.jsp


