hi this is John Van Vliet please enjoy the maps 
--------------------------------WARNING------------------------------------------------
---If you have installed CallistoLevel_012.zip from http://celestiamotherlode.net/  ---
---rename /celestia/extras/JohnVV/Callisto.ssc to Calloisto.ssc.off  OR delete it   ---
----------------------------- end WARNING ---------------------------------------------



Unzip into your Celestia root directory  ie.
mine ( on Windows ) is in
 C:\\Celestia  and
 C:\\CelestiaCVS
-----OR-----
1)  C:\\program files\celestia
2)  E:\\program files\celestia
3)  /usr/share/celestia
4)  /usr/local/share/celestia
------- mine is in ( Fedora 8 Linux )-------
5)  /usr/opt/Celestia  and
6)  /usr/opt/CelestiaCVS
   -----------------
this file unzips to 
.
|-- ReadMe.txt
|-- extras
|   `-- Callisto.ssc
`-- textures
    |-- hires
    |   `-- Callisto.png
    |-- lores
    |   `-- Callisto.png
    `-- medres
        `-- Callisto.png


The orig. map data was from 
http://pds-imaging.jpl.nasa.gov/Missions/Galileo_mission.html
http://pds-imaging.jpl.nasa.gov/Missions/Voyager_mission.html
http://www.mapaplanet.org/


