  The Eight Planets 
 The Solar System Mercury to Neptune 
 
 
###############
# Linux users #
###############
except fort one experimental ODB SUSE build YOU MUST rebuild celestia WITH SPICE ENABLED !!! 

install spice from 
http://naif.jpl.nasa.gov/naif/index.html
-- download binary -
http://naif.jpl.nasa.gov/naif/toolkit_C.html

-- READ THE INSTALL INSTRUCTIONS ---
and install to say /opt/cspice 
add the required paths to the system $PATH 

and rebuild celestia from the current SVN source !!! 

  svn co https://celestia.svn.sourceforge.net/svnroot/celestia celestia 
  
see the celestia forum at "shatters dot net "
-- READ the help page---
./configure --help 

 --- THE RECOMMENDED BUILD IS QT4  --- 
 
QT4 -- spice installed to /opt/cspice 
  $ ./configure --prefix=/opt/QT_Celestia --with-lua --with-qt -with-cspice-dir=/opt/cspice -program-prefix=QT

--- A Gnome2 build line -- spice installed to /opt/cspice --
./configure --prefix=/opt/GTK_Celestia --with-lua --with-gnome -with-cspice-dir=/opt/cspice -program-prefix=GTK

Gnome 3 ??? as of the writing it is unknown but i would recomend the QT build 

###################
# Apple Mac users #
###################

I do not know .I do not own a mac 

####################
# MS Windows users #
####################
spice should be built in to the celestia.exe so there should no need to rebuild the source code 
or install "cspice"


################ REQUIRED TO INSTALL !!!! #############################


1)
download the files in the "Files_to_download" text file and place in the /data folder 
It is a lot of data 19 files BUT it is 2.2 Gig in size 


2)
the ssc files have been edited to use the DEFAULT celestia 1.6.1 textures 
however i left in ( but commented out) the names for the textures in my add on section on the Motherload 
feel free to use what ever ones you wish to use .


3) to install copy the Folder " JohnVV" to your extras folder 
this is the location for ALL of my addons 


This is based on the excellent addon by "volcanopele "
http://www.shatters.net/forum/viewtopic.php?f=6&t=13540


