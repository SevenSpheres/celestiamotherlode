Paleographic maps

This set contains from 600 million of years to present paleographic maps in steps of 25 mill of years.

Ere Geologiche (http://jan.ucc.nau.edu/)

1# Late Precambrian		600.jpg
2# Latest Precambrian	560.jpg
3# Early Cambrian		540.jpg
4# Late Cambrian		500.jpg
5# Middle Ordovician	470.jpg
6# Late Ordovician		450.jpg
7# Silurian		430.jpg
8# Early Devonian		400.jpg
9# Middle Devonian		370.jpg
10# Mississippian		340.jpg
11# Pennsylvanian		300.jpg
12# Early Permian		280.jpg
13# Late Permian		260.jpg
14# Middle Triassic		240.jpg
15# Late Triassic		220.jpg
16# Early Jurassic		200.jpg
17# Middle Jurassic		170.jpg
18# Late Jurassic		150.jpg
19# Early Cretaceous	120.jpg
20# Middle Cretaceous	105.jpg
21# Late Cretaceous		090.jpg
22#Tertiary-Cretaceous	065.jpg
23# Eocene		050.jpg
24# Oligocene		035.jpg
25# Miocene		020.jpg
26# Present		000.jpg

Unzip file and place :

DerivaContinenti.cel into the main directory of Celestia (The same of demo.cel)
DerivaContinenti.ssc into DerivaContinenti directory
All *.jpg into ...\DerivaContinenti\textures\medres directory

Start DerivaContinenti.cel and enjoy !

Thanks :

Ton Lindemann
Scot Scotese