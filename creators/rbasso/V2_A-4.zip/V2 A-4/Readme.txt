Explications by Sitting Duck .

Extract the model to "models" folder and texture to "textures/medres". But I think you should leave a copy of the texture folder here. (this is odd on my PC) The .SSC can stay here.

This model is created and textured by Sitting Duck, and Masermind cleaned it up and made sure everything was in order, and made alot of effort to texture it too.

Enjoy this harmless V-2 rocket, used by germany in WW2.

#------------------------------------

Explications by Robybasso .

Use V2_celurls_it.html file to go directly at sites of London & Peenemunde . All files could be jointed to Sitting Duck's folder .

Enjoy to look this V-2 rocket, and remember ... Never Again Another War It's Up To Us ! (?) - Mai pi� un'altra guerra , dipende solo da noi !

Bye .

# ---------------------------------------------
# V2's Technical Data 
# ---------------------------------------------
# h=14 mt 
# Diam=1.68 mt 
# Weight=12870 kg 
# larg impenn=3.57 mt 
# Speed max 1585 m/s
# Apogeo=96 Km
# Gittata=306-320 Km