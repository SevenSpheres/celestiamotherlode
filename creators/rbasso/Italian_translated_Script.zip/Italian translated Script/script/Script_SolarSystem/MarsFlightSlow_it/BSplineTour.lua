--***************************************************************************
--***************************************************************************
--          An open non-uniform B-Spline approximation algorithm
--                    Applied to space touring
-- 
--                     Coded by Toti
--                 For Celestia 1.3.2 and later
--            
--***************************************************************************
--***************************************************************************

--***************************************************************************
--                    File->Table functions
--***************************************************************************
function parseFile(fileName)
-- reads the tour file and outputs two tables: one with UCS path points and other with screen text and related data:
-- (this is a too simplistic implementation of a parser: no error management, etc.):

    local pathTBL    = {}
    local textTBL    = {}

    local textREC    = {}
    local pathREC    = {}

    local bodyNm 
    local xOff, yOff
    local tm, amb
    local posX,    posY,    posZ
    local lookAtX, lookAtY, lookAyZ
    local upX,     upY,     upZ

    -- ask the user to open an external file:
    celestia:requestsystemaccess() wait()

    for line in io.lines(fileName) do
        -- for now, I'll assume 1 entry per line
        local _, _, tag, command, clstag    = string.find(line, "(<%a+>)(.+)(<%/%a+>)")

            if tag == "<body>" then                                   -- body tag found
                bodyNm    = command

            elseif tag == "<xOffset>" then                            -- Xoffset tag found
                xOff      = command

            elseif tag == "<yOffset>" then                            -- Yoffset tag found
                yOff      = command

            elseif tag == "<text>" then                               -- text tag found
                textREC.body    = bodyNm
                textREC.xOff    = xOff
                textREC.yOff    = yOff
                textREC.text    = command

                -- [textREC] is complete. Add it to [textTBL]:
                table.insert(textTBL, textREC)
                textREC    = {}

            elseif tag == "<time>" then                                -- local time tag found

                tm                        = command

            elseif tag == "<ambient>" then                             -- ambient light tag found

                amb                       = command

            elseif tag == "<position>" then                            -- obs position tag found

                 _, _, posX, posY, posZ          = string.find(command, "([%d%.%-%e]+)%s+([%d%.%-%e]+)%s+([%d%.%-%e]+)")

            elseif tag == "<lookAt>" then                              -- obs lookAt tag found

                _, _, lookAtX, lookAtY, lookAtZ  = string.find(command, "([%d%.%-%e]+)%s+([%d%.%-%e]+)%s+([%d%.%-%e]+)")

            elseif tag == "<up>" then                                  -- obs up tag found

                _, _, upX, upY, upZ              = string.find(command, "([%d%.%-%e]+)%s+([%d%.%-%e]+)%s+([%d%.%-%e]+)")

                pathREC.time       = tm
                pathREC.ambient    = amb
                pathREC.posX,    pathREC.posY,    pathREC.posZ       = posX,    posY,    posZ
                pathREC.lookAtX, pathREC.lookAtY, pathREC.lookAtZ    = lookAtX, lookAtY, lookAtZ
                pathREC.upX,     pathREC.upY,     pathREC.upZ        = upX,     upY,     upZ

                -- [pathREC] set is complete. Add it to [pathTBL]:
                table.insert(pathTBL, pathREC)
                pathREC    = {}

            end
    end
    return pathTBL, textTBL
end

function buildTourTables(pathTBL, textTBL)
-- performs various hacks in [pathTBL] and [textTBL]:
    local ROUNDOFFSET   = 0.5
    local size          = table.getn(pathTBL)

    --let's include a spline-able index field:
    for i, t in pairs(pathTBL) do
        -- add index field (add an offset in order to avoid FP errors):
        t.index    = i + ROUNDOFFSET
    end
    
    -- add a dummy point so there is room at the end of the fitting scheme (so next-to-last point shows up):
    table.insert(textTBL, textTBL[size])
    table.insert(pathTBL, pathTBL[size])

    --ensure that the ambient light setting starts and ends with user's system default values:
    pathTBL[1].ambient         = gOLD_AMBIENT
    pathTBL[size+1].ambient    = gOLD_AMBIENT

    return pathTBL, textTBL
end

--***************************************************************************
--                    Other functions
--***************************************************************************
function getDuration(textTBL, secsPerLetter)
-- computes total duration of tour (in characters * secsPerLetter):
    local totLength   = 0
    for i, t in pairs(textTBL) do
        totLength     = totLength + string.len(t.text)
    end
    return totLength * secsPerLetter
end

function splitString(str, lineWidth)
-- very basic string splitting at the screen limits:
    local str2, thisChar  = ""
    local strLng          = string.len(str)
    local j               = 1
    for i= 1, strLng do
        thisChar    = string.sub(str,i, i)
        str2        = str2 .. thisChar
        if j >= lineWidth and thisChar == " " then
            str2    = str2 .. "\n"
            j       = 1
        else
            j       = j + 1
        end
    end
    return str2
end

--***************************************************************************
--                    Callbacks
--***************************************************************************
function celestia_cleanup_callback()
-- restores user's preferred settings
    celestia:settimescale(gOLD_TIME_SCALE)        
    celestia:setambient  (gOLD_AMBIENT)
end

--***************************************************************************
--                    Main function
--***************************************************************************
function DoBSplineTour(tourFile, secsPerLetter, curveOrder)

    local LAST_PHRASE_DELAY     = 5
    local PIXELS_PER_LETTER     = 15
    local WAIT_DELAY            = 0

    local OBS         = celestia:getobserver()

    gOLD_TIME_SCALE   = celestia:gettimescale()        
    gOLD_TIME         = celestia:gettime()
    gOLD_AMBIENT      = celestia:getambient()

    -- we will handle time progress:
    celestia:settimescale(0)

    -- build the main structures:
    local pathTBL, textTBL     = buildTourTables(parseFile(tourFile))
    local duration             = getDuration    (textTBL, secsPerLetter)


    local knotsLST        = buildNonUniformKnotsList(function(i)
                                                        return string.len(textTBL[i-curveOrder].text) * secsPerLetter
                                                     end,
                                                     duration, table.getn(textTBL), curveOrder)

    local t0     = celestia:getscripttime()
    local t1     = 0

    repeat

        -- get the result of B-Spline applied to [pathTBL] for time [t1]:
        local splinedREC        = getSpline(knotsLST, pathTBL, t1, curveOrder)
    
        -- get the appropriate text lines, etc. in [textTBL]:
        local currTextREC       = textTBL[math.floor(splinedREC.index)]

        -- use the obtained data to change Celestia's state:
        celestia:select      (celestia:find(currTextREC.body))
        celestia:setambient  (splinedREC.ambient)
        celestia:settime     (splinedREC.time)

            local obsPos      = celestia:newposition   (splinedREC.posX,       splinedREC.posY,      splinedREC.posZ     )
            local lookAtPos   = celestia:newposition   (splinedREC.lookAtX,    splinedREC.lookAtY,   splinedREC.lookAtZ  )
            local upVect      = celestia:newvector     (splinedREC.upX,        splinedREC.upY,       splinedREC.upZ      ) 

        OBS:setposition(obsPos)
        OBS:lookat     (lookAtPos, upVect)

        --the user might be resizing the program's window:
        local lineWidth    = 0.5*(1-currTextREC.xOff)*celestia:getscreendimension()/PIXELS_PER_LETTER    
    
        celestia:print(splitString(currTextREC.text, lineWidth), LAST_PHRASE_DELAY, currTextREC.xOff, currTextREC.yOff)

        wait(WAIT_DELAY)

        t1        = celestia:getscripttime() - t0    -- put this here so old computers (like mine) 
                                                     -- can run the code fine
    
    until t1 > duration

end
