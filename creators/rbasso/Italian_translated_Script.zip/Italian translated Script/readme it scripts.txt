Copy the next files into the scripts folder . 
All scripts are translated in italian language .

Thanks to :Toti , Harald Schmidt , "Maine " aka Walter Allan , Ulrich "Adirondack" Dickmann , Juan Marino Oyervides Salvatori , Tim McMahon , Zarius , Paul Swennenhuis , Frank Gregorio , Don Goyette , Paolo Amoroso , Christoria , Andr? Smith and me ...

RobyBASSO
Italy
