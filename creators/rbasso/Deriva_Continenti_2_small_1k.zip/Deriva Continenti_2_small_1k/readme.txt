Unzip file and place :

Deriva Continenti_2_small_1k.cel into the main directory of Celestia (The same of demo.cel)
Deriva Continenti_2_small_1k.ssc into paleo earth draft directory
All images into ...\Deriva Continenti_2_small_1k\textures\medres directory

Start Deriva Continenti_2_small_1k.cel and enjoy !

Thanks :

Ton Lindemann - Scot Scotese -maxim
-------------------------------------------------------------------------
<<This is a collection of paleo earth maps, only intended to be used as drafts for creating addons for celestia. The low resolution maps did not receive any correctional work since collected from the sources on the net, except of being reprojected from mollweide to simple cylindrical projection and being resized for instant usablility with celestia. The reprojection process was done with iris software (see 'http://www.astrosurf.com/buil') as best as possible. Existing artifacts are due to varying quality of the originals.

For more information and the original data, please refer to the source of the originals at 'http://www.scotese.com'

maxim>> .