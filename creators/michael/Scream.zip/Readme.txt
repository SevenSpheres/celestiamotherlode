This addon places a billboard in space to show the strange object known as the Scream* located near NGC 3773.  The picture was taken by the Galaxy Zoo project.  

Just drop this directory inside your Extras folder, and launch Celestia.  Type "The Scream" and Go.


  - Michael   September 27 2009

*The Scream is only the nickname given to it by the Galaxy Zoo Project.