This addon places a billboard in space to show the recently discovered object known as Hanny's Voorwerp located near IC 2497.  The picture was taken by the Galaxy Zoo project.  

Just drop this directory inside your Extras folder, and launch Celestia.  Type "Hanny's Voorwerp" and Go.


  - Michael   February 07 2009