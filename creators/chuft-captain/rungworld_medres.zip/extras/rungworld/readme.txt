"Did you laugh at RINGWORLD? Damn right you did!
The weekly fan magazine APA-L printed, as back covers,
a string of cartoons showing huge structures of peculiar 
shape, usually with a sun hovering somewhere near the 
center. There was Wringworld and Wrongworld and Rinkworld 
and Rungworld (a tremendous stepladder, terraformed landscapes
on the steps)...." 
- quote by Larry Niven from N-SPACE



Rungworld for Celestia v1.4.0 by Phil Batchelor 
This is my interpretation of the Rungworld described above.

Derived from :
Larry Niven's Ringworld for Celestia v1.3 by Marc Griffith
The SSC's were derived from Marc's original versions, and I have 
also used modified versions of his textures.

Just unzip into your celestia directory, it will not overwrite any files.
Then travel to Rigel Kentaurus A to have a look.

The ladder does not orbit the sun, but is stationary in space.
Goto one of the rungs and increase time-rate to 10000x. 
As you will see, each rung has 12 hours of day followed by 
12 hours of night, so there is no need for shadow-squares,
