Installation Requirements
=========================

This Addon is designed for use with Celestia v1.5.1 or later. 
It will work with 1.4.x versions of Celestia, however it is highly recommended that you install Celestia v1.5.1 or later before installing this addon.

Copyright
=========

This Addon, and accompanying documents were created
by Phil Batchelor for use with Celestia and are
copyright � 2008. All rights reserved.

License
=======

This Addon may be freely redistributed for educational purposes 
so long as all of the provided files are included.

This Addon may not be used for any commercial or pecuniary benefit 
without explicit written permission from the author.

Phil Batchelor
Email: traitorsclaw@yahoo.com


Installation Procedure
================

If you restore from this Zip file into the main Celestia directory, it will
create all of the directories and files necessary for this Addon to function.

Note:
This installation procedure assumes a Windows operationg system using WinZIP.
The contents of the ZIP file however should be able to be extracted by other compression utilities. The 
procedure will differ slightly, but as long as you extract to the correct location the result should
be the same.


1. Right click on the ZIP file and select "Extract All...", then click NEXT:
 

2. Specify the Celestia install directory (C:\Program Files\Celestia) as the extract location and click NEXT 
 

3. Click FINISH
 

The addon is now installed and ready to use with Celestia.

The installation procedure described above creates the following files:
A folder named "cc_Stars" in C:\Program Files\Celestia\extras
A file named "castor.cel" in C:\Program Files\Celestia\scripts 


Please read the accompanying CastorREADME.txt for instructions on using the Addon.
