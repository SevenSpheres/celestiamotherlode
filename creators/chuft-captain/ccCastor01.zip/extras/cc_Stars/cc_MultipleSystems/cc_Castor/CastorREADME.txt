The six stars of Castor for Celestia
v1.0

by Phil Batchelor � 2008
All rights reserved.
================================

This Addon is designed for use with Celestia v1.5.1 or later. 
It will work with 1.4.x versions of Celestia, however it is highly recommended that you install Celestia v1.5.1 or later before installing this addon.  
http://www.shatters.net/celestia/



Description
===========

In standard Celestia, Castor is only represented as a single star.
In fact Castor is a sextuple star system made of three binaries.

The addon provides the six stars (3 binary pairs) of Castor in their orbits. (as far as they are known).
(Some assumptions have been made where information was unavailable or unknown, for example: mass-ratios )

It also provides a script which will take a novice user of Celestia on a short guided tour of the Castor system.


Operation
=========

Manual Navigation:
If you are familiar with the Celestia interface, you can use the ENTER menu to navigate your own way to the Castor System and any of it's six stars or it's barycenters. (Best viewed with the timerate set at speeds between 100,000 x and 100,000,000 x faster.)
The Barycenters:
	Castor, CASTOR AB, Castor A, Castor B, Castor C (YY Gem)
The Stars:
	Castor-Aa, Castor-Ab, Castor-Ba, Castor-Bb, Castor-Ca, Castor-Cb


Automated Tour:
I recommend that first time users of Celestia (or of this addon) begin with the scripted tour of Castor.
The tour can be executed by selecting the "Hitchhikers Guide to Castor" option in the File->Scripts menu. 
( Script execution can be canceled at any time by pressing the ESC key. )

NOTE: If you are using an older version of Celestia this menu item will not be available. 
In this case, either upgrade to the latest version of Celestia, or use "File -> Open Script" to browse to the scripts folder, then open the file named "castor.cel".



Installation Procedure
================
Please follow the instructions in the accompanying "InstallREADME.txt".


Copyright
=======

This Addon, and accompanying documents were created
by Phil Batchelor for use with Celestia and are
copyright � 2008. All rights reserved.


License
=======

This Addon may be freely redistributed for educational purposes 
so long as all of the provided files are included.

This Addon may not be used for any commercial or pecuniary benefit 
without explicit written permission from the author.

Phil Batchelor
Email: traitorsclaw@yahoo.com


Credits
=======

Of course, none of this would work without Celestia :)
http://www.shatters.net/celestia/

The design of the system is based on the information provided
at: http://www.solstation.com/stars2/castor6.htm



