
README
th_journey_tps_light - "A Journey Through Planetary Space" Light Version v.2.0.
------------------------------------------------------------------------------
NOTE ABOUT THIS PACKAGE:
------------------------------------------------------------------------------
This ReadMe covers the supplied Celestia AddOn "A Journey Through
Planetary Space", Light Version.

A JOURNEY THROUGH PLANETARY SPACE is version 2.0, and a major upgrade.
Version 1 is named "Off on a Comet", and was released early in 2004.
CelUrls from Version 1 are NOT compatible with Version 2.

NOTE: Detailed Guide for JTPS can be found at this address:
http://runar.thorvaldsen.net/celestia/gallery/journey_tps.html



INSTALLATION:
------------------------------------------------------------------------------
Drop the folder "th_journey_tps_light" into /CelestiaResources/extras/addons/.
If you have previously installed the Full Version, or Version 1
(Off on a Comet), disable it or remove it from the Celestia Addons
directory.

Important: apparently, there is a real asteroid named "Gallia" out there.
It is declared in some of the extra "smaller bodies" catalog files one can
download from the Motherlode. If you experience a problem going to Gallia,
you need to locate and disable that entry. It will typically reside in a
SSC file in your Extras folder.



NOTES:
------------------------------------------------------------------------------
This Light Version lacks several features included in the Full Version: there
are fewer surface locations, lower resolution graphics, and, there are no 
seasons (the Full Version has summer and winter seasons for Gallia).

The Full Version may be downloaded from the Motherlode, or from my website
(addresses at the end of this document).



SIGHTS TO SEE:
------------------------------------------------------------------------------
- The comet Gallia entering our solar system, and passing (in this order):
  Neptune, Earth, Venus, Jupiter, Saturn, Mars, Earth again
- The Island of Gibraltar in freefall also passes close to Earth�s Moon
- Locations on Gallia: The Island of Gibraltar, The Dobryna, Nina�s Hive,
  Servadac�s Balloon

See the included jtps_celurls.html document for links that will take you to
some of these places



COPYRIGHT
------------------------------------------------------------------------------
All textures, models and graphics are original works created by Runar
Thorvaldsen, with the following exeptions:

- The Dobryna model, and the house and furniture models placed on the Gibraltar
  island: these i found on various free archives on the internet. I have just
  edited and re-textured them. As far as i know, these models are in the public
  domain. If you should discover otherwise, please notify me about it.

- The Verne photograph is courtesy of Andrew Nash (http://www.julesverne.ca/)

Contents of "A Journey Through Planetary Space" Light may be used in any way
you like, EXEPT for commercial purposes. Included material produced by other
authors / designers than Runar Thorvaldsen are only distributable to the extent
they give permission.

If you want to re-distribute "A Journey Through Planetary Space" Light you are
free to do so, provided that you:

- do not charge money for it in any way, neither for the files themselves, or
  for access to them
- keep it complete and unmodified, including this ReadMe




CREDITS
------------------------------------------------------------------------------
- Jestr, for writing the Gallia trajectory (jestr_gallia.xyz)
- Andrew Nash, for the Jules Verne photograph



ADDRESSES
------------------------------------------------------------------------------
Mail: thpost@thorvaldsen.net
web: http://runar.thorvaldsen.net/celestia/
The JTPS Guide: http://runar.thorvaldsen.net/celestia/gallery/journey_tps.html
The Motherlode: http://www.celestiamotherlode.net
------------------------------------------------------------------------------
Runar Thorvaldsen (rthorvald),
Oslo, 31. July 2005



