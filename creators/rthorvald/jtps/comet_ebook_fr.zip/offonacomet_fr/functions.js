function selectSIDE(form) {
var myindex=form.formid.selectedIndex
location.href=(form.formid.options[myindex].value);
}

function linkout(out) {
opp=window.open(out,"out","toolbar=no,location=no,status=no,menubar=no,scrollbars=auto,resizable=no,width=600,height=600")
window.opp.moveTo(10,10)
}



var adr=".html"
var dir = location.href.substring(0,location.href.lastIndexOf('/')+1);
var url = location.href.substring(dir.length,location.href.length-5);
var thisurl = location.href.substring(dir.length,location.href.length-5);
count = 1
while (count <= (url)) {
count ++
}
count2 = 1
while (count2 <= (url-2)) {
count2 ++
}



//thisurl2=(thisurl-999)



if ((thisurl)=="0999")
thisurl2='',page=("") ; else

if ((thisurl)=="0998")
thisurl2='',page=("") ; else

if ((thisurl)=="0997")
thisurl2='',page=("") ; else

thisurl2=(thisurl-999),page=(" - page "+thisurl2)



book=("Hector Servadac[1], ")
book2=("Hector Servadac[2], ")





chaptertxt=("Chapitre ")
chapterdv=(": ")
pagename = (book+chapterno+chapterdv+chaptername+page)
function settitle() {
document.title = (pagename);
 }

pagename2 = (book2+chapterno+chapterdv+chaptername+page)
function settitle2() {
document.title = (pagename2);
 }



chaplink=(chaptertxt+chapterno+chapterdv+chaptername)

home='<a class="topnav" href="0997.html">Page Couverture.</a> | <a class="topnav" href="0998.html">Introduction</a> | '
up='<a class="topnav" href="#top">Haut de page</a> | '
contents='<a class="topnav"  href="0999.html">Sommaire</a> | '
cfiles='<br><a style="color:#000000;" href="http://runar.thorvaldsen.net/celestia/index.html">The Celestia Files</a> &copy;Runar Thorvaldsen, 2005'

menustart='<form><table border=0 cellspacing=0 cellpadding=0 class="menutable"><tr><td align=right valign=middle class="menucell" nowrap>'
previous=('<a class="topnav"  href="'+count2+adr+'">Pr&eacute;c&eacute;dente</a> | ')
next=('<a class="topnav"  href="'+count+adr+'">Suivante</a> ')
gohere=' | Page:&nbsp;</td><td align=right valign=middle class="menucell"><select SIZE=1 CLASS="gobox" NAME="formid" onChange="selectSIDE(this.form)"><option SELECTED VALUE="'+(thisurl)+'">'+(thisurl2)+'</option>'
menuend='</select></td><td align=right valign=middle class="menucell"> &nbsp;| <a class="topnav" href="http://runar.thorvaldsen.net/celestia/index.html">Home</a></td></tr></table></form>'

menustart2='<div class="menucell">'
menuend2='<br><br><br></div>'

go0='<option VALUE="1000.html">1</option>'
go1='<option VALUE="1001.html">2</option>'
go2='<option VALUE="1002.html">3</option>'
go3='<option VALUE="1003.html">4</option>'
go4='<option VALUE="1004.html">5</option>'
go5='<option VALUE="1005.html">6</option>'
go6='<option VALUE="1006.html">7</option>'
go7='<option VALUE="1007.html">8</option>'
go8='<option VALUE="1008.html">9</option>'
go9='<option VALUE="1009.html">10</option>'
go10='<option VALUE="1010.html">11</option>'
go11='<option VALUE="1011.html">12</option>'
go12='<option VALUE="1012.html">13</option>'
go13='<option VALUE="1013.html">14</option>'
go14='<option VALUE="1014.html">15</option>'
go15='<option VALUE="1015.html">16</option>'
go16='<option VALUE="1016.html">17</option>'
go17='<option VALUE="1017.html">18</option>'
go18='<option VALUE="1018.html">19</option>'
go19='<option VALUE="1019.html">20</option>'
go20='<option VALUE="1020.html">21</option>'
go21='<option VALUE="1021.html">22</option>'
go22='<option VALUE="1022.html">23</option>'
go23='<option VALUE="1023.html">24</option>'
go24='<option VALUE="1024.html">25</option>'
go25='<option VALUE="1025.html">26</option>'
go26='<option VALUE="1026.html">27</option>'
go27='<option VALUE="1027.html">28</option>'
go28='<option VALUE="1028.html">29</option>'
go29='<option VALUE="1029.html">30</option>'
go30='<option VALUE="1030.html">31</option>'
go31='<option VALUE="1031.html">32</option>'
go32='<option VALUE="1032.html">33</option>'
go33='<option VALUE="1033.html">34</option>'
go34='<option VALUE="1034.html">35</option>'
go35='<option VALUE="1035.html">36</option>'
go36='<option VALUE="1036.html">37</option>'
go37='<option VALUE="1037.html">38</option>'
go38='<option VALUE="1038.html">39</option>'
go39='<option VALUE="1039.html">40</option>'
go40='<option VALUE="1040.html">41</option>'
go41='<option VALUE="1041.html">42</option>'
go42='<option VALUE="1042.html">43</option>'
go43='<option VALUE="1043.html">44</option>'
go44='<option VALUE="1044.html">45</option>'
go45='<option VALUE="1045.html">46</option>'
go46='<option VALUE="1046.html">47</option>'
go47='<option VALUE="1047.html">48</option>'
go48='<option VALUE="1048.html">49</option>'
go49='<option VALUE="1049.html">50</option>'
go50='<option VALUE="1050.html">51</option>'
go51='<option VALUE="1051.html">52</option>'
go52='<option VALUE="1052.html">53</option>'
go53='<option VALUE="1053.html">54</option>'
go54='<option VALUE="1054.html">55</option>'
go55='<option VALUE="1055.html">56</option>'
go56='<option VALUE="1056.html">57</option>'
go57='<option VALUE="1057.html">58</option>'
go58='<option VALUE="1058.html">59</option>'
go59='<option VALUE="1059.html">60</option>'
go60='<option VALUE="1060.html">61</option>'
go61='<option VALUE="1061.html">62</option>'
go62='<option VALUE="1062.html">63</option>'
go63='<option VALUE="1063.html">64</option>'
go64='<option VALUE="1064.html">65</option>'
go65='<option VALUE="1065.html">66</option>'
go66='<option VALUE="1066.html">67</option>'
go67='<option VALUE="1067.html">68</option>'







gothese=(go0+go1+go2+go3+go4+go5+go6+go7+go8+go9+go10+go11+go12+go13+go14+go15+go16+go17+go18+go19+go20+go21+go22+go23+go24+go25+go26+go27+go28+go29+go30+go31+go32+go33+go34+go35+go36+go37+go38+go39+go40+go41+go42+go43+go44+go45+go46+go47+go48+go49+go50+go51+go52+go53+go54+go55+go56+go57+go58+go59+go60+go61+go62+go63+go64+go65+go66+go67)




menu=(menustart+home+contents+previous+next+gohere+gothese+menuend)
menu2=(menustart2+up+home+contents+previous+next+cfiles+menuend2)
nextbtn=("<input TYPE='button' VALUE=' Page suivante ' onClick=\"window.location='"+count+".html'; return true;\"  CLASS='gobtn'>")



menub=(menustart+home+contents+'<a class="topnav" href="1000.html">Page 1</a>'+gohere+gothese+menuend)
menu2b=(menustart2+up+home+contents+'<a class="topnav" href="1000.html">Page 1</a>'+cfiles+menuend2)
nextbtnb=("<input TYPE='button' VALUE=' retour page 1 ' onClick=\"window.location='1000.html'; return true;\"  CLASS='gobtn'>")



menuc=(menustart+home+contents+next+gohere+gothese+menuend)
menu2c=(menustart2+up+home+contents+next+cfiles+menuend2)


menud=(menustart+home+contents+previous+'<a class="topnav" href="1000.html">Page 1</a>'+gohere+gothese+menuend)
menu2d=(menustart2+up+home+contents+previous+'<a class="topnav" href="1000.html">Page 1</a>'+cfiles+menuend2)
















