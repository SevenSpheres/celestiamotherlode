
THE RINGWORLD, LOW-RESOLUTION VERSION
---------------------------------------------------------
This is a Celestia scenario based on Larry Niven´s 1970 novel "Ringworld".


SYSTEM REQUIREMENTS
---------------------------------------------------------
- Celestia 1.5.1 or newer for Linux, OSX or Windows.
- 29,5 MB free disk space
- 512 MB RAM or more recommended
- 64 MB Video memory or more recommended


INSTALLATION
---------------------------------------------------------
- Locate the Celestia Extras folder, and unzip your Ringworld into it
- Makes sure only ONE Ringworld version is present
- Launch Celestia, and GoTo Ringworld's Star. Alternately, use this CelUrl:

cel://Follow/Ringworld's%20Star/2009-01-17T15:34:19.67135?x=AAA0+qaoEtcj&y=AKCUZGV2Tsf9/////////w&z=AADAiuj+SQQW&ow=0.194274&ox=0.468614&oy=-0.138023&oz=0.850652&select=Ringworld's%20Star&fov=29.4272&ts=1&ltd=0&p=0&rf=51095&lm=0&tsrc=0&ver=3


COPYRIGHT
------------------------------------------

This package is released to you "as is", under a non-commercial share-and-share-alike Creative Commons licence.

You can see this licence in its entirety here:
http://creativecommons.org/licenses/by-nc-sa/3.0/

... What it means in practice, is that you are free to:
- Use and re-distribute this work for any non-commercial purpose
- Modify it, or any part of it, and re-distribute the result, provided that:
1) you do not charge money for it in any way
2) you distribute it under the SAME licence as this one, with the same provisions and permissions.


Some rights reserved. Copyright belongs to:
- Runar Thorvaldsen, january 21. 2009.

Contact:
rthorvald@celestialmatters.org
www.celestialmatters.org





