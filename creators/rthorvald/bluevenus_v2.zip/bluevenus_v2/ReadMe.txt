
README
rthorvalds_venus [Version 2]


INSTALLATION
-------------------------------------------------------
Simply drop the rthorvalds_venus folder into your
Celestia AddOns directory. No SSC editing needed;
it will automatically replace Celestia�s real Venus


CHANGES SINCE V1
-------------------------------------------------------
- Added bumpmaps and specular maps
- Re-saved the virtual textures as 1024x1024 PNG;
  considerably better quality than the previously
  released 512x512 JPG set
- Structured the maps as a proper AddOn, and added
  HiRes, MedRes and LoRes directories


THANKS AND CREDITS
-------------------------------------------------------
Special thanks to Don. Edwards for permission to use
his beautiful 4k Earth cloudmap as a base for developing
my Venus cloudmap


COPYRIGHT
-------------------------------------------------------
The included material may be used in any way you like,
exept for commercial purposes. You may not charge
money for access to, or distribution of, anything
contained in this package. �Runar Thorvaldsen, 2004
and 2005.


ADDRESSES
-------------------------------------------------------
Mail: thpost@thorvaldsen.net
web: http://runar.thorvaldsen.net/celestia/


-------------------------------------------------------
rthorvald,
Oslo, 1. December 2005









