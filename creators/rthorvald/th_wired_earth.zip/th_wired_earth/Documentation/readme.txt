
README
th_wired_earth v.1.0
--------------------------------------------------------------------------
NOTE ABOUT THIS PACKAGE:
--------------------------------------------------------------------------
This ReadMe covers the supplied Celestia Add-On "The Wired Earth".


INSTALLATION:
--------------------------------------------------------------------------
Drop the folder "th_wired_earth" into /CelestiaResources/extras/addons/.


NOTES:
--------------------------------------------------------------------------
To get anything useful out of this Add-On, goto the Earth at midnight,
august 14. 2003. Alternately you can just open the enclosed "th_wired_earth.cel" script, which will take you there and re-run this
day a great number of times automatically.

The Add-On combines two different kinds of data:
Population density V.S. number and originating location of queries
submitted to Google on one particular day - 08.14.2003. One can see the
queries pop up at different times, and follow the traffic around the
globe. It gets really interesting when one compares this to the
population density on different locations on Earth.

You can view this in four different modes:

1) The LoRes setting: Shows the globe with a colored Surface map for 
   population density

2) The MedRes setting: population density shows only through the bumpmap
   (i.e. as a height map: the higher the shadows, the more people)

3) The HiRes setting: a subtle mix of 1) and 2)

4) The AltSurface map shows _everything_ as a single, _static_ map.

In general: 
- The deeper the blue color, and the deeper the shadows, the MORE people
- The denser the yellow dots, the MORE googling.

To make viewing more practical, load the "th_wired_earth.cel" script
supplied with this package. It isn�t much, but it at least auto-
repeats the 14. August 2003 so that one may examine the maps without
settting the date over and over manually.



COPYRIGHT
--------------------------------------------------------------------------
All textures are original works created by Runar Thorvaldsen, with the
following exeptions:

- The population density data is acquired from this map, published by
  the U.S. Department ofAgriculture, 1994:
  http://upload.wikimedia.org/wikipedia/en/7/76/World_population_density.gif
  This map is in the public domain

- The Google search query dataset for the 24 hours is copyright
  Google.Inc, 2004. This data is used here with permission from
  Google.Inc, explicitly for this particular purpose. This information
  may NOT be used or re-distributed for ANY purpose without a separate
  agreement with Google.Inc.

- The Earthmap is my 2k version of the NASA BlueMarble Mark 1. From this,
  i constructed the bumpmap, specular map, nightmaps and surface maps.
  The additional data came from the sources listed above.

In short, this means that you can use this Add-On for personal purposes,
but any re-distribution of any or all parts in any form or shape is
strictly prohibited.

The Google query data = copyright � Google.Inc, 2004.


EXEPTION 1
[Copyright vs distribution]
--------------------------------------------------------------------------
This Add-On - The Wired Earth by rthorvald - may be distributed for free
by the Celestia Motherlode in it�s entirety, as long as it is unmodified
and complete, including all documentation. No other parties may distribute
this Add-On without written consent from the author.


EXEPTION 2
[Copyright vs distribution]
--------------------------------------------------------------------------
The following 3 documents (by Runar Thorvaldsen) are released into the
public domain, and can be used in any way you like:

- th_bluemarble_earth.png (The generic surface map)
- th_espec.jpg (The specular map)
- th_populationbump.png (The bumpmap)

There are NO other exeptions.



CREDITS
--------------------------------------------------------------------------
(The Google query data):
Rob Pike et al., "Interpreting the Data: Parallel Analysis with Sawzall",
Google.Inc: http://labs.google.com/papers/sawzall.html
... A two-dimensional version of the information i used can be found here:
http://labs.google.com/papers/sawzall-20030814.gif



ADDRESSES
--------------------------------------------------------------------------
Mail: thpost@thorvaldsen.net
web: http://runar.thorvaldsen.net/celestia/
The Motherlode: http://www.celestiamotherlode.net
--------------------------------------------------------------------------
Runar Thorvaldsen (rthorvald),
Oslo, 28. March 2006



