Unzip and place in your 'extras' folder.This  model was made by Paul George and the dunev texture by fungun@yahoo.com.
To get there in Celestia
1.press 'enter/return' key
2.Type in   catastrofic_dunev_moon 
3.press 'enter' again
4.press 'G' for Goto

this moon is around the earth change the orbite if you whant sory if not all OK but im new in celestia
arraialp@yahoo.com.br