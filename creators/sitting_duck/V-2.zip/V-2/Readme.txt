Extract the model to "models" folder and texture to "textures/medres". But I think you should leave a copy of the texture folder here. (this is odd on my PC) The .SSC can stay here.

This model is created and textured by Sitting Duck, and Masermind cleaned it up and made sure everything was in order, and made alot of effort to texture it too.

Enjoy this harmless V-2 rocket, used by germany in WW2.