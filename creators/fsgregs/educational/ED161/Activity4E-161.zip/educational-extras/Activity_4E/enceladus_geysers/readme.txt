Enceladus' geysers. For Celestia 1.6 or above only.

Extract in ..\extras\ folder

Start Celestia
hit: enter 
type: Enceladus

Thanks to Chris Laurel for its animationlib.lua engine
on which this add-on is based.


Changes:

- Add animate (slowest motion) plume/tail;
- Retouched geysers' colors and opacities; 
