This addon was created to show the approximate plume location and size for various volcano plumes on the surface of Io.  Four volcano plumes are modeled, Tvashtar, Masubi, Prometheus and Pele.  The first three were imaged to be erupting at the same time by the New Horizons probe on its way to Pluto.  You can delete or rename the file extensions to disable individual plumes.

I. INSTALLATION AND USE
	A. You must have at least Celestia 1.4.x to be able to use properly this addon.  
		1. Put all files in your extras directory
			example folder structure
			Celestia
			   |---Extras
			            |---Io Volcanoes
						 |---models
			                   |      ejecta.cmod
						 |---textures
			                   |      |---medres
			                   |            ejecta.png
			                   tvashtar.ssc
			                   musabi.ssc
			                   pele.ssc
			                   prometheus.ssc

II. MORE INFORMATION
	A. On Io Vucanism
		1. http://www.planetaryexploration.net/jupiter/io/index.html
	B. Io Mountain Database
		1. http://planetologia.elte.hu/io/
	C. Volcano eruption locations
		1. http://planetarynames.wr.usgs.gov/

III. COPYRIGHT
	A. All work is licensed under a Creative Commons Attribution-Noncommercial-Share Alike 3.0 Unported License.  That means you can use it, you can share it, you can change it, but you must give me credit and you can never use it commercially...


Christopher (Buggs) Moran
December 2007