MILKY WAY

This Celestia add-on provides a realistic rendering of the Milky Way as seen from the vicinity of the solar system. 

INSTALLATION

Extract the whole MilkyWay folder into Celestia's Extras folder. The model will be loaded automatically. Nebula rendering needs to be ON to display de model. Nebula rendering is toggled by the key ^ (note that if you are using a keyboard layout with deadkeys, you may need to press an additional SPACE after ^). Standard galaxy rendering is toggled by the key u.

DETAILS

The effect is achieved by a simple spherical model. The ASCII mw.cmod is used by default. Additionaly you will find mw.3ds and mw-bin.cmod. All of them are geodesic spheres, the 3ds made with Anim8or, the cmods converted with Chris' tools. Use the one you like best.

The sphere is centered at the solar system barycenter and has 10 light years in diameter. The effect only makes sense in the neighborhood of the solar system, so there is no point in making it bigger. Besides, with such a small model, one can still enjoy the standard "blobs" rendering of the Milky Way when the viewpoint is far away. 

The texture is based on a panoramic view of the whole sky credited to ESO/S. Brunier (http://www.eso.org/public/images/eso0932a/). I removed the brightest stars and the planets mostly automatically, a few by hand. I reduced brightness and saturation to make it more closely resemble a visual appearance instead of a long exposure. By the way, the panorama is magnificent, go have a look at it.

I oriented the model by hand as best as I could, so the alignement is approximate. I tried the settings of other whole sky models (such as WMAP), but it wasn't quite right, and I don't know why. It may be a misalignement in the ESO panorama I used. So I fixed it by hand by aligning stars (which were then removed from the texture). You are free to make it better if you please.

To change the alignement (tricky!), edit mw.dsc and comment out (with #) the command "Clickable False". Then start Celestia in verbose mode:
> celestia --verbose > align.log
Enter edit mode with @
Select the model with <enter> mw <enter>
Rotate around X and Y with ctrl+shift+left button+drag
Rotate around Z with ctrl+shift+right button+drag
Save with !
Exit Celestia
Read orientation and rotation in align.log
Beware that the format of the vector in the dsc is different from the one saved by the edit mode (it made me mad).

ISSUES

There are a number of depth sorting problems that I couldn't solve to full satisfaction. Currently I get the model in front of the standard Milky Way (which is good), behind the Small Magellanic Cloud (which is bad) but in front of the Large one (which is good). Also, the Sag dSph gets in front (which is weird). Off-disk galaxies have behave strangely, and for that reason I have kept the 3 models and 2 textures: a jpg with pitch black background, and a png with transparency. Check the behavior in your system and use the one that pleases you best.

AUTHOR

Guillermo Abramson
g.abramson@gmail.com
My blog: guillermoabramson.blogspot.com
My Celestia stuff: fisica.cab.cnea.gov.ar/estadistica/abramson/celestia

Distributed with a Creative Commons License: Attribution - Noncommercial - Share alike
http://creativecommons.org/licenses/by-nc-sa/3.0/