function animationpath_eg(t)
   -- Create a new table
   local orbit = {};

   orbit.timebase = t.TimeBase or 2451545.0
   orbit.loop = t.Loop

   -- Utility function to split a string into an array of
   -- words. Each word is separated by one or more whitespace
   -- characters.
   local split = 
      function (s)
	 local t = {}
	 local index = 1
	 for w in string.gmatch(s, "[^%s]+") do
	    t[index] = w
	    index = index + 1
	 end

	 return t
      end

   local done = false
   local parseerror = false
   local index = 1

   orbit.positionKeys = {}

   -- Parse the positions key
   while not done and not parseerror do
      local key = "Pos" .. index
      local s = t[key]
      if s then
	 local values = split(s)
	 if #values == 4 then
	    -- Force conversion of the values to numbers
	    -- by adding 0
	    orbit.positionKeys[index] = {
	       0.0 + values[1],
	       0.0 + values[2],
	       0.0 + values[3],
	       0.0 + values[4]
	    }
	 else
	    parseerror = true
	 end
      else
	 done = true
      end

      index = index + 1
   end

   -- Clear the position key array if we encountered a parse
   -- error.
   if parseerror then
      orbit.positionKeys = {}
   end

   local nkeys = #orbit.positionKeys
   if nkeys > 0 then
      orbit.duration = orbit.positionKeys[nkeys][1]
   else
      orbit.duration = 1
   end

   -- Set the required fields boundingRadius and position; note
   -- that position is actually a function.
   orbit.boundingRadius = 1000
   
   function orbit:position(tjd)
      local t = (tjd - self.timebase) * 86400
      local nkeys = #self.positionKeys

      if self.duration ~= 0 and self.loop then
	 t = t % self.duration
      end

      local x = self.positionKeys[nkeys][2]
      local y = self.positionKeys[nkeys][3]
      local z = self.positionKeys[nkeys][4]

      if nkeys > 1 then

	 for i = 1, nkeys, 1 do
	    if t <= self.positionKeys[i][1] then
	       if i == 1 then
		  -- Use the first position key
		  x = self.positionKeys[1][2]
		  y = self.positionKeys[1][3]
		  z = self.positionKeys[1][4]
	       else
		  -- Linearly interpolate between position keys
		  local r1 = self.positionKeys[i - 1]
		  local r2 = self.positionKeys[i]
		  local alpha = (t - r1[1]) / (r2[1] - r1[1])
		  x = r1[2] + alpha * (r2[2] - r1[2])
		  y = r1[3] + alpha * (r2[3] - r1[3])
		  z = r1[4] + alpha * (r2[4] - r1[4])
	       end
	       break
	    end
	 end

      elseif nkeys == 1 then
	 local pos = self.positionKeys[1]
	 x = pos[2]
	 y = pos[3]
	 z = pos[4]
      end

      return x, y, z
   end

   return orbit
end