A new model of the Spitzer space telescope for Celestia.  The original 3ds model comes from this web site :

http://coolcosmos.ipac.caltech.edu/resources/informal_education/3Dmodel.html

The mesh as been heavily edited to repair some pieces, rise up the resolution of the model and to add some colors and textures.  Many thanks to ElChristou who helped me to optimise some meshes.

The SSC and data files are from Jack Higgins Spitzer addon.

Enjoy,

Cham, december 2007