# Planck Mission Timeline
# 
# Launch May 14, 2009 
# Nominal end of mission August, 2012 

INSTALLATION
To install this add-on, simply extract the package to your Celestia\extras folder. To view the spacecraft, just use Celestia's ENTER-TYPE NAME-ENTER method to locate Planck.

ADD-ON INFO
Planck uses a "lissajous" orbit around the Sun-Earth L2 point. The .xyz trajectory file used in this add-on was extracted from JPL Horizons data, in an Earth-centered reference frame. Sample rate is every 3 hours. the .ssc file included will maintain Planck's solar panel pointed toward the Sun, while the spacecraft rotates at 1rpm as it scans the sky.

MISSION INFO
More information about the mission can be found here:
http://www.esa.int/SPECIALS/Planck/index.html
http://sci.esa.int/science-e/www/area/index.cfm?fareaid=17
http://www.rssd.esa.int/index.php?project=planck

This add-on was created by BrianJ , May 16th 2009
You can contact me via the Celestia forum at http://www.shatters.net/forum/

With thanks to Selden, BrainDeadBob and ElChristou

The files in this add-on may be used and redistributed for non-commercial purposes only.