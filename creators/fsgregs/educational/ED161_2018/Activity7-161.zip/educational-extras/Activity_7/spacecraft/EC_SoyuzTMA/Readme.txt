MEDRES model of a Soyuz TMA for Celestia (v.1.0)

This a prerelease model.

Place the entire EC_SoyuzTMA folder in your "Extras" folder.

Enjoy.



________
Model under Creative Common license. Author: ElChristou, november 2007.

You are free to copy, distribute and perform the work under the following conditions:

- You must attribute the work in the manner specified by the author or licensor (presence of this Readme file).
- You may not use this work for commercial purposes.
- You may not alter, transform or build upon this work.

To read the full license:
http://creativecommons.org/licenses/by-nc-nd/2.5/legalcode