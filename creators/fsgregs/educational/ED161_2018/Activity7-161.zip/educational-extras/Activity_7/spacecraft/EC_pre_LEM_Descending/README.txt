Pre-release of one of the many models of the Apollo 11 mission reconstruction.
This is the LEM ready for touch down, ground sensors open.

More info: http://forum.celestialmatters.org/viewtopic.php?t=27

Many Tx to Andrea for his hard work on documentation.




Place the entire "EC_pre_LEM_Descending" folder in your "Extras" folder.





Enjoy,




******************************************************************

Model under Creative Common license, Author: ElChristou, july 2008


You are free to copy, distribute, display and perform the work under the following conditions:

- You must attribute the work in the manner specified by the author or licensor (presence of this Readme file).
- You may not use this work for commercial purposes.
- You may not alter, transform, or build upon this work.


To read the full license:
http://creativecommons.org/licenses/by-nc-nd/2.5/legalcode