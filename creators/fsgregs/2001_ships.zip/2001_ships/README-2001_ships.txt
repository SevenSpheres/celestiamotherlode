2001 ships updated - January 2006
--------------------

This add-on is an updated version of the 2001 Space Odyssey ships add-on.  It changes the dates that the add-on first appears from 2020 to 2001, to be accurate with the movie.  This will result in two large space stations and the Orion space plane appearing in orbit around Earth whenever you launch Celestia.  The Discovery Jupiter mission ship, its pod and the moon shuttle will also be present in 2001.

Should you wish to change those dates to sometime in the future, simply open the ssc files for each ship that you find in these folders, and change the beginning date from 2001 to sometime in the future (e.g. - 2020 or 2200 or something else).


Note:  The Eagle moon shuttle is not technically from the Movie, 2001, but from a TV show which aired in the 1970's.  It looks neat so I've included it with the add-on.  Discard it if you don't wish to view it.

INSTALLATION:
=============

Upzip this add-on directly into the "extras" folder inside your Celestia main folder.  It will install the add-on in its own folder named "2001_ships".  If you keep your extras in another folder, install the add-on there instead.

Please note that this add-on is already included with Celestia Educational Activity 8, the Spacecraft of Celestia Part 2.  If you download and install Activity 8 from our educational webpages, or if you have installed the Educational Activity CD, do NOT install this add-on on your system.  Otherwise, there will be two copies of it running at the same time.  That would not be good.

Thanks to Chuft-Captain (Phil Batchelor) for assistance in updating the add-on dates and other changes.

Enjoy

Frank Gregorio
January 2006




