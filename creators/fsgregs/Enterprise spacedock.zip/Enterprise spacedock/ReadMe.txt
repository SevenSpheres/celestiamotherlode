The DVD version has The Enterprise addon.  The CD set cannot fit it.  Drag the entire folder out of extras when making a CD.
