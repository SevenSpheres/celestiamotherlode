-- The table can include the following values:
--	>	objects = { string:object1path, string:object2path, ... }
--	Defines the list of objects whose visibility will be enabled/disabled.
--	>	labelcolor = {number:red, number:green, number:blue, number:alpha}
--	Defines the color of the addon labels. The name of the addon will be then displayed using
--	this same color in the 'Addon Visibility' window.
--	>	locationtype = string:locationtype
--	Defines the type of location that will be enabled/disabled simultaneously with the objects visibility.
--	List of all location types: http://en.wikibooks.org/wiki/Celestia/SSC_File#Type_.22string.22

Magnetic_Field =
{
		labelcolor = {0.2, 0.5, 1.0, 0.9},

		objects =
		{
			"Sol/Earth/1",	
			"Sol/Earth/2",	
			"Sol/Earth/3",	
			"Sol/Earth/4",	
			"Sol/Earth/5",	
			"Sol/Earth/6",	
			"Sol/Earth/7",	
			"Sol/Earth/8",	
			"Sol/Earth/9",	
			"Sol/Earth/10",	
			"Sol/Earth/11",	
			"Sol/Earth/12",	
			"Sol/Earth/Aurora",	
		}

}


