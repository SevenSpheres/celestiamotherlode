
Earth_Cities =
{
		labelcolor = {0.8, 0.9, 0.2, 0.7},
		locationtypes = {"city"},
}
