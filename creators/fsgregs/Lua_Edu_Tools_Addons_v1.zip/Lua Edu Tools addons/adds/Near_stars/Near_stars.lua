Near_stars =
{
labelcolor = {1.00, 1.00, 1.000, 0.8},
objects =
{
"Near Stars 1",
"Near Stars  2",
"Polar Grid 1",
"Polar Grid 2",
},
script = "Near_stars-fg.celx"
}

