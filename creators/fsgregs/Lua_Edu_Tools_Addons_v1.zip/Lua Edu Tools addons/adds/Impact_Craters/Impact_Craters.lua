-- The table can include the following values:
--    >    objects = { string:object1path, string:object2path, ... }
--    Defines the list of objects whose visibility will be enabled/disabled.
--    >    labelcolor = {number:red, number:green, number:blue, number:alpha}
--    Defines the color of the addon labels. The name of the addon will be then displayed using
--    this same color in the 'Addon Visibility' window.
--    >    locationtype = string:locationtype
--    Defines the type of location that will be enabled/disabled simultaneously with the objects visibility.
--    List of all location types: http://en.wikibooks.org/wiki/Celestia/SSC_File#Type_.22string.22
--    >    script = string:scriptfilename
--    Defines the filename of the script that is run whenever the addon is enabled via the checkbox.
--    The script path is relative to the addon's directory.

Impact_Craters =
{
    labelcolor = {0.4, 0.6, 0.9, 0.8},
    locationtypes = {"crater"},
    objects = 
{
"Sol/Earth/Tunguska Impact",
"Sol/Earth/Barringer-Meteor", 
"Sol/Earth/Arkenu 2",
"Sol/Earth/Flaxman", 
"Sol/Earth/Paasselk�", 
"Sol/Earth/Upheaval Dome", 
"Sol/Earth/Eagle Butte",
"Sol/Earth/Karla",
"Sol/Earth/Kelly West", 
"Sol/Earth/Bosumtwi", 
"Sol/Earth/Ternovka", 
"Sol/Earth/Wells Creek", 
"Sol/Earth/Avak", 
"Sol/Earth/Serra da Cangalha", 
"Sol/Earth/Vargeao Dome", 
"Sol/Earth/Nicholson", 
"Sol/Earth/Aorounga", 
"Sol/Earth/Marquez", 
"Sol/Earth/Kentland", 
"Sol/Earth/Deep Bay", 
"Sol/Earth/Sierra Madera", 
"Sol/Earth/Spider", 
"Sol/Earth/Gweni-Fada", 
"Sol/Earth/Zhamanshin", 
"Sol/Earth/Logoisk", 
"Sol/Earth/Kaluga", 
"Sol/Earth/Ames", 
"Sol/Earth/Oasis", 
"Sol/Earth/Lawn Hill", 
"Sol/Earth/Elgygytgyn", 
"Sol/Earth/Dellen", 
"Sol/Earth/Obolon", 
"Sol/Earth/Logancha", 
"Sol/Earth/Gosses Bluff", 
"Sol/Earth/Rochechouart", 
"Sol/Earth/Ries", 
"Sol/Earth/Boltysh", 
"Sol/Earth/Haughton", 
"Sol/Earth/Kamensk", 
"Sol/Earth/Strangways", 
"Sol/Earth/Steen River", 
"Sol/Earth/Clearwater East", 
"Sol/Earth/Mistastin", 
"Sol/Earth/Keurusselk�", 
"Sol/Earth/Shoemaker (Teague)", 
"Sol/Earth/Slate Islands", 
"Sol/Earth/Yarrabubba", 
"Sol/Earth/Manson", 
"Sol/Earth/Clearwater West", 
"Sol/Earth/Carswell", 
"Sol/Earth/Saint Martin", 
"Sol/Earth/Woodleigh", 
"Sol/Earth/Araguainha", 
"Sol/Earth/Montagnais", 
"Sol/Earth/Kara-Kul", 
"Sol/Earth/Siljan", 
"Sol/Earth/Charlevoix", 
"Sol/Earth/Tookoonooka", 
"Sol/Earth/Beaverhead", 
"Sol/Earth/Kara", 
"Sol/Earth/Morokweng", 
"Sol/Earth/Puchezh-Katunki", 
"Sol/Earth/Chesapeake Bay", 
"Sol/Earth/Acraman", 
"Sol/Earth/Manicouagan", 
"Sol/Earth/Popigai", 
"Sol/Earth/Chicxulub", 
"Sol/Earth/Sudbury", 
"Sol/Earth/Vredefort", 
} 

}

