
Earth_Features =
{
		labelcolor = {0.6, 0.9, 1.000, 0.7},
		locationtypes = {"mons", "vallis"},
}
