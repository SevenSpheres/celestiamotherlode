Extract in ..\extras folder.

Note for LUA EDU TOOLS 1.2 insert:

1) Extract in lua_edu_tools\adds folder:
2) See instructions.jpg
3) start Celestia

Note:
label size must be set lesser than 20