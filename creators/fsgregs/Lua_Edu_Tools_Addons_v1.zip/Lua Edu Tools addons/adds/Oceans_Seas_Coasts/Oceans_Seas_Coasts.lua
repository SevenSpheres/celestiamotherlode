
Oceans_Seas_Coasts=
{
		labelcolor = {0.3, 0.9, 1.000, 0.7},
		locationtypes = {"terra", "mare"},
		objects =  { "Sol/Earth/Oceans Seas Coasts",} 
}
