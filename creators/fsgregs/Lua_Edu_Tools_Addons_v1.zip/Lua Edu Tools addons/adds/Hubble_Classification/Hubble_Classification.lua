
Hubble_Classification =
{
	labelcolor = {0.064, 0.932, 0.200, 0.8},
    script= "Hubble_Classification.celx",
    objects =
        {
            "Irr",
            "E0",
            "E2",
            "E4",
            "E6",
            "S0",
            "Sa",
            "Sb",
            "Sc",
            "SBa",
            "SBb",
            "SBc",

            "Irr_label",
            "E0_label",
            "E2_label",
            "E4_label",
            "E6_label",
            "S0_label",
            "Sa_label",
            "Sb_label",
            "Sc_label",
            "SBa_label",
            "SBb_label",
            "SBc_label",

            "Irr_frame",
            "E0_frame",
            "E2_frame",
            "E4_frame",
            "E6_frame",
            "S0_frame",
            "Sa_frame",
            "Sb_frame",
            "Sc_frame",
            "SBa_frame",
            "SBb_frame",
            "SBc_frame"
        }

}
