Original addon: 'Millenium Simulation' by Cham
Edited by F. Gregorio

Source of data and references :

http://www.mpa-garching.mpg.de/millennium/
http://www.mpa-garching.mpg.de/galform/virgo/millennium/

Wikipedia description :
http://en.wikipedia.org/wiki/Millennium_simulation

Data query :
http://www.g-vo.org/Millennium/MyDB

The cube's size is 62.5 Mpc/h.  Comoving cube means that at present the size is 62.5 Mpc/h.
At earlier times the physical size would be 62.5/h/(1 + redshift).
The factor h (== Hubble constant/100km/s/Mpc) indicates that if you believe the Hubble constant
is 73 km/s/Mpc, then the actual physical size is 62.5/0.73 Mpc at present.
