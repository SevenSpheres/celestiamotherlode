require "locale";

---------------------------------------------- 
-- Set up and Draw the boxes 
---------------------------------------------- 
cockpitBox = CXBox:new() 
:init(0, 0, 0, 0) 
:movable(false) 
:attach(screenBox, width, height, 0, 0); 

cockpitBox.Customdraw = 
function(this) 
textlayout:setfont(normalfont); 
textlayout:setfontcolor(ctext); 
textlayout:setpos(this.lb+25, this.tb-14); 
textlayout:println(_("Cockpit")); 
end;

cockpitCheck = CXBox:new() 
:init(0, 0, 0, 0) 
:bordercolor(cbubordoff) 
:textfont(normalfont) 
:textcolor(cbutextoff) 
:textpos("center") 
:movetext(0, 9) 
:text("") 
:movable(false) 
:active(true) 
--:attach(cockpitBox, 100, 4, 35, 5) 
  :attach(cockpitBox, boxWidth - 40, 4, 29, 5)


cockpitCheck.Action = (function() 
return 
function() 
keymap["C"] = cockpitCheck.Action;
cockpitFrame.Visible = not(cockpitFrame.Visible); 
if cockpitFrame.Visible then 
cockpitCheck.Text = "x"; 
else 
cockpitCheck.Text = ""; 
end 
end 
end) ();

cockpitFrame = CXBox:new() 
:init(0, 0, 0, 0) 
:fillimage(celestia:loadtexture(cockpitTexture)) 
:movable(false) 
:active(false) 
:clickable(true) -- <== Line to add
:visible(false) 
:attach(screenBox, 0, 0, 0, 0)
