Simply unzip this WinZip file into your extras directory.  

This is the planet nicknamed 'Gunsmoke' orbiting a close binary star system in Trigun comics of Yasuhiro Nightow. The comics author has not specified around which star(s) the planet does orbit, nonetheless it is likely the system may coincide with Delta Trianguli, since it is the nearest Solar-type close binary to Sun (roughly 30 Light Years). 

Gunsmoke has got three natural satellites, nearly similar to our Moon (I have tentatively scaled their masses in following way, 0.3-0.935-0.62 Lunar masses, placing the least massive one in the innermost orbit and those with similar mass in the outer ones). No name has been provided in the fiction for these moons, since the denizens of Gunsmoke use to call them "first moon, second moon and third moon". The 3rd one shows a wide crater due to an accident of Vash the Stampede and Knives Million.

The planet is entirely desert, with widespread dune fields and several rocky (hamada) and stony (serir) deserts. Water is likely to be locked in the underground within a wide and complex subterranean karst system.

Gunsmoke North Polar star is Eta Cephei whereas Southern one is Eta Columbae.

For more informations about Trigun comics, characters and story take a look at this wiki:

http://en.wikipedia.org/wiki/Trigun

Best regards.
Edasich

Contact: tyrogthekreeper@gmail.com
 

