Simply unzip this WinZip file into your extras directory.  

This add-on contains some fictional bizzarre worlds from Lovecraft and other writers' Chtulhu Mythos. Awkward planets orbiting the most exotic kinds of stellar systems, including multiple Suns, dark stars, stellar degenerates, red giants and much more.

For more infos about Chtulhu Mythos celestial bodies take a look at this Wiki:

http://en.wikipedia.org/wiki/Cthulhu_Mythos_celestial_bodies

Best regards.
Edasich

Contact: tyrogthekreeper@gmail.com
 

