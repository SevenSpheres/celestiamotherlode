Simply unzip this WinZip file into your extras directory.  

This add-on includes several kind of stellar degenerates: white dwarf, B-type subdwarfs, cataclysmic variables, dwarf novas, neutron stars and some black hole system as well as binary systems containing a white dwarf or a pulsar. 

Recently discovered transiting white dwarfs KOI-74 and KOI-81 (Kepler Survey) have been also added, with accurate parameters.

Some exoplanet host white dwarfs are marked in stc file as "exoplanet host". If they already have a stc file in independent add-on (for example QS Vir or DP Leo), simply erase "QS Vir.stc" file from QS Vir cartel.

Most of white dwarfs radii and luminosities have been provided, whereas few others' parameters have been indirectly found. Where distance estimate has not been yet provided, stellar distances have been marked with "putative" or "inferred" tag, since their value is based from VMag or stellar mass/radius estimates.

Moreover, following giant stars have been found to be spectroscopic binaries, with secondary masses below 0.7 Solar masses, likely to be either late type K dwarfs or white dwarfs. No spectral type has been provided, so their spectral type is unknown and marked with "?":

18 Mon
ALF Tuc
DEL Mus
GAM CMi
IOT Gru
LAM Hya
V455 Sco
XI Pav
ZET Sct

I'm aware it is an ambitious add-on, to be updated and eventually edited where wrong. But someone had to do it, sooner or later ;-)

Best regards.
Edasich

Contact: tyrogthekreeper@gmail.com
 
