english
................

ALARAPH 
Imaginary solar system around Alaraph
By Shcuf. Santiago, Chile. November 2007.
shcuff@gmail.com


This addon is only a fantastic creation, and it doesn't seek to be scientifically realistic.

The clouds of "Laudomia" belong to the addon "Zeta Reticuli" created by Cham. To make the surface map of "Aglaura", I've edited and used textures of the addon "Titan Light" created by Runar Thorvaldsen. 

This work can be used freely, except for commercial purposes. Anyone who wishes to use textures contained here to create other addons, please provide information about the name of this addon and their creator, just as it is made in this readme.

Please send me your comments.






espa�ol
................

ALARAPH 
Sistema solar imaginario alrededor de Alaraph
Por Shcuf. Santiago, Chile. Noviembre 2007.
shcuff@gmail.com


Este addon es s�lo una creaci�n fant�stica y no pretende ser realista desde un punto de vista cient�fico.

Las nubes de "Laudomia" pertenecen al addon "Zeta Reticuli" creado por Cham. Para realizar el mapa de superficie de "Aglaura" edit� y us� texturas del addon "Titan Light" de Runar Thorvaldsen. 

Este trabajo puede usarse libremente, excepto para fines comerciales. Quien desee utilizar las texturas que aqu� aparecen para crear otros addons, por favor, proporcione informaci�n sobre el nombre de este addon y su autor, tal como se hace en este "l�eme".

Agradecer� vuestros comentarios.
