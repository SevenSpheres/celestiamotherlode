THE MU HERCULIS OR ANTHROPOS SYSTEM.

By Ivo Beckers

ivobeckers@hotmail.com

Extract the files to your celestia/extras folder.
To find the system, type "mu hercules" in Celestia.

Have fun!


Thanks to rsanders and jmdollan for some of their textures 
(next system i will do the textures myself).