Portal 2 Cores addon
---------------------
This addon places the Space Core and Wheatley (both from Portal 2) in orbit around the moon. Rick and the Fact Core are in their own orbits around Earth. No textures or models were ripped from the game files, all textures were made in GIMP and all four models were made with Anim8or. Yes, I know the models aren't very good.

Installation
-----------
To install this addon, extract it to your extras folder (on Windows, it's usually C:\Program Files\Celestia\extras). 

Credits
-------
Portal 2 (C) Valve
Models, textures (C) w0rldbuilder (aka TBH-1138, TheBlackHole)


So much space, need to see it all...