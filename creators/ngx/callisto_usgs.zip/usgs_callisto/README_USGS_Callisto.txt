USGS Callisto

Celestia Addon, tested on version 1.6.1. 
To install, unzip the file (extract folder "usgs_callisto") into Celestia's "extras" folder.

Alternate grayscale surface of Jupiter's moon Callisto, originating from USGS Astrogeology Research Program.
Simple cylindrical mosaic of images from Galileo and both Voyager missions.

Right click on the moon and select "Alternate Surface" item.

For Celestia prepared by ngx.
ngx@zoznam.sk

Source images and detailed information:
http://astrogeology.usgs.gov/Projects/JupiterSatellites/callisto.html

Images Copyright:
USGS Astrogeology Science Center
http://astrogeology.usgs.gov