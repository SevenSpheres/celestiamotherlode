USGS Ganymede

Celestia Addon, tested on version 1.6.1. 
To install, unzip the file (extract folder "usgs_ganymede") into Celestia's "extras" folder.

Alternate surface of Jupiter's moon Ganymede, originating from USGS Astrogeology Research Program.
Simple cylindrical mosaic of high resolution images from Galileo and both Voyager missions.

The image is prepared to be used with John Van Vliet's 8kGanymedeNormal.png normal map. If you don't use it already, just copy the file into usgs_ganymede\textures\hires\ subdirectory.
You can download it here:
http://celestiamotherlode.net/creators/johnvanvliet/8kGanymedeNormal.zip

For Celestia prepared by ngx.
ngx@zoznam.sk

Source images and detailed information:
http://astrogeology.usgs.gov/Projects/JupiterSatellites/gany.html

Images Copyright:
USGS Astrogeology Science Center
http://astrogeology.usgs.gov