JPL Tethys

Celestia Addon, tested on version 1.6.1. 
To install, unzip file (extract folder "jpl_tethys") into Celestia's "extras" folder.

Alternate surface map of Saturn's moon Tethys (available by right click), originating from Cassini Solstice Mission, Jet Propulsion Laboratory, California Institute of Technology. This global map of Saturn's moon Tethys was created using images taken during flybys by NASA's Cassini spacecraft.

The package contains three types of textures:

- 8k grayscale (B&W) texture of moon's surface taken during misions.
- 2k original surface color map.
- Overlay texture adding colors to grayscale texture. It is far from exact match, more like "artist's concept". Colorizing texture was made form original mission color map. 

NOTE: ATI Radeon users (tested on Catalyst version 11.10), if you experience Celestia crash while loading the texture, adjust CCC 3D Application settings as follows (perform each step only if previous steps don't help):

1. Disable Catalyst AI (or set it for best performance)
2. Set Mipmap for best performance instead of quality
3. Disable antialiasing
4. Disable vertical refresh


For Celestia prepared by ngx.
ngx@zoznam.sk

Source images and detailed information:
http://saturn.jpl.nasa.gov/photos/imagedetails/index.cfm?imageId=4181
http://photojournal.jpl.nasa.gov/catalog/PIA13423

Images Copyright:
NASA/JPL/Space Science Institute 
http://saturn.jpl.nasa.gov/