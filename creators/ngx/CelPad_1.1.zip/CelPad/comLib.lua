-- comLib.lua

celestia:log("CelPad: loading common library")

function CPlog(text,llevel,slTable,static)
	local tab_ins = table.insert
	if not llevel or llevel==0 then
		llevel = 5;
	end
	if not slTable and llevel <= 5 then
		celestia:log(text)
	end
	if not slTable then
		slTable = tCelPad.sysLog;
	end;
	if  not time_str then
		time_str = "no time yet"
	end;
	if #slTable > ms170maxSysLog then
		for i=1,ms180rotLog  do
			syslogRmItem(slTable,1)
		end;
		CPlog("CelPad: rotating syslog "..tostring(slTable).." after "..ms170maxSysLog.." lines, first "..ms180rotLog.." removed.")
	end;
	if llevel<10 or DebugLog then
		numstamp = slTable.logNum[#(slTable.logNum)]+1;
		if static then
			slTable[static]=text;
			slTable.logLevel[static]=llevel;
			slTable.timestamp[static]=time_str;
			slTable.logNum[static]=numstamp;
		else
			tab_ins(slTable,text);
			tab_ins(slTable.logLevel,llevel);
			tab_ins(slTable.timestamp,time_str);
			tab_ins(slTable.logNum,numstamp);
		end;
	end
end;
function syslogInit(slTable)
	local inittext = "syslog initialized; "..tostring(slTable)
	local tab_ins = table.insert
	slTable.logLevel = slTable.logLevel or {}
	slTable.timestamp = slTable.timestamp or {}
	slTable.logNum = slTable.logNum or {}
	tab_ins(slTable,inittext.."; no messages");
	tab_ins(slTable.logLevel,1);
	tab_ins(slTable.timestamp,"no time");
	tab_ins(slTable.logNum,0);
end;
function syslogRmItem(slTable,slIndex)
	local tab_rmv = table.remove
	tab_rmv(slTable.logNum,slIndex)
	tab_rmv(slTable.timestamp,slIndex)
	tab_rmv(slTable.logLevel,slIndex)
	tab_rmv(slTable,slIndex)
end;
function syslogNil(slTable)
	for si,sv in ipairs(slTable) do
		slTable[si] = nil
		slTable.logLevel[si] = nil
		slTable.timestamp[si] = nil
		slTable.logNum[si] = nil
	end
end;
function maxmin(t)
	local max = -math.huge;
	local min = math.huge;
	for k,v in pairs( t ) do
		if type(v) == "number" then
			max = math.max( max, v )
			min = math.min( min, v )
		end
	end
	return max, min
end;
function math_dround(n,d)
	if (d) then
		return math.floor((n*10^d)+0.5)/(10^d)
	else
		return (n)
	end;
end;
function table_num(t)
	num = 0;
	for i,v in pairs(t) do
		num= num + 1;
	end;
	return num;
end;
function tabindx(o,t)
	local tindex
	for i,v in ipairs(t) do
		if v == o then
			tindex = i
		end
	end
	return tindex
end;
function getTxtChars(text,frw,margin)
	local getwidth = getwidth
	local txtww = cpfntmainw:getwidth(text);
	local sln = string.len(text);
	if txtww <= (frw - margin ) then
		return sln;
	else
		local ll=1;
		repeat
			ll = ll + 1;
			txtsplit = string.sub(text, 1, ll);
			txtwx = cpfntmainw:getwidth(txtsplit);
		until txtwx > (frw - margin);
		return ll;
	end
end;
function cpgetwidth(font,text)
	local getwidth = getwidth
	local m_ceil = math.ceil
	local width = 0;
	local lcButtonsize,lcButtonspace = gButtonsize,gButtonspace
	width = m_ceil(font:getwidth(text)+lcButtonsize)
	return width;
end;
function getmvalinc(prop,metatab)
	if metatab[prop] then
		incrmnt = metatab[prop][2];
	else
		incrmnt = 1;
	end;
	return incrmnt;
end;
function getmvalminmax(prop,metatab)
	local minval,maxval = -math.huge,math.huge;
	if metatab[prop] then
		minval = metatab[prop][3] or minval;
		maxval = metatab[prop][4] or maxval;
		minval2 = metatab[prop][5] or minval;
		maxval2 = metatab[prop][6] or maxval;
	end;
	return minval,maxval,minval2,maxval2;
end;
function getsetuphi(prop,metatab)
	if metatab[prop] then
		hiname = metatab[prop][1];
	else
		hiname = "";
	end;
	if hiname == "" then
		hiname = tostring(prop);
	end;
	return hiname;
end;
function stretchmenu(mnitem,c)
	local szx, szy
	szx, szy = mnitem:size()
	local cpgetwidth = cpgetwidth
	local dedit = math.ceil(cpfntmenu:getwidth(" ") + cpfntmenu:getwidth(" ")/6);
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local finalize = function()
		for i, v in ipairs(mnitem.wobj.panebuttons) do
			v.la = mnitem.wobj.menupane.pw - i*(lcButtonsize + lcButtonspace);
		end;
		if mnitem.wobj.menupane.btnself then
			mnitem.wobj.menupane.btnself.la = mnitem.wobj.menupane.btnself.la + dedit/2
			mnitem.wobj.menupane.btnself.ra = mnitem.wobj.menupane.btnself.ra + dedit/2
		elseif mnitem.wobj.menupane.btnselfAPL then
			mnitem.wobj.menupane.btnselfAPL.la = mnitem.wobj.menupane.btnselfAPL.la + dedit/2
			mnitem.wobj.menupane.btnselfAPL.ra = mnitem.wobj.menupane.btnselfAPL.ra + dedit/2
			mnitem.wobj.menupane.btnselfOK.la = mnitem.wobj.menupane.btnselfOK.la + dedit/2
			mnitem.wobj.menupane.btnselfOK.ra = mnitem.wobj.menupane.btnselfOK.ra + dedit/2
		end;
		local extbtn = mnitem.wobj.menupane.savldbtn or mnitem.wobj.menupane.edminmax
		if extbtn then
			extbtn.ra = extbtn.ra + dedit
		end;
		mnitem.wobj.menupane.ra = mnitem.wobj.menupane.ra - 2*lcButtonspace
		mnitem.wobj:makePopShadow(mnitem.wobj.menupane)
	end;
	if cpgetwidth(cpfntmenu,tostring(mnitem.Text)) > (szx + lcButtonspace) then
		if c then
			mnitem.wobj.menupane.pw = mnitem.wobj.menupane.pw + dedit
			for q,w in ipairs(mnitem.wobj.tmultimenu) do
				for k,l in ipairs(w) do
					if (k-4) == c*2 then
						if l.left then
							l.left.ra = l.left.ra + dedit
							l.right.la = l.right.la + dedit
						end
					elseif (k-4) > c*2 then
						l.la = l.la + dedit
						if l.left then
							l.left.la = l.left.la + dedit
							l.right.la = l.right.la + dedit
						end
					else
						l.ra = l.ra + dedit
						if l.left then
							l.left.ra = l.left.ra + dedit
							l.right.ra = l.right.ra + dedit
						end
					end
				end;
			end;
			finalize()
		else
			mnitem.wobj.menupane.pw = mnitem.wobj.menupane.pw + dedit
			mnitem.wobj.maxitemv = mnitem.wobj.maxitemv + dedit
			for q,w in ipairs(mnitem.wobj.setitem) do
				w.menuline.ra = w.menuline.ra + dedit
				if w.scanbox then
					w.scanbox.ra = w.scanbox.ra + dedit
				end;
				if w.negatebox then
					w.negatebox.ra = w.negatebox.ra + dedit
				end;
				if w.editbox and w.editbox.left then
					w.editbox.left.ra = w.editbox.left.ra + dedit
					w.editbox.right.la = w.editbox.right.la + dedit
				end;
				if w.editboxMin then
					w.editboxMin.ra = w.editboxMin.ra + dedit/2
					w.editboxMax.la = w.editboxMax.la + dedit/2
					w.editboxMin.left.ra = w.editboxMin.left.ra + dedit
					w.editboxMin.right.la = w.editboxMin.right.la + dedit/2
					w.editboxMin.right.ra = w.editboxMin.right.ra + dedit/2
					w.editboxMax.left.ra = w.editboxMax.left.ra + dedit/2
					w.editboxMax.left.la = w.editboxMax.left.la + dedit/2
					w.editboxMax.right.la = w.editboxMax.right.la + dedit
				end;
			end;
			finalize()
		end;
		if mnitem.wobj.clrbtn then
			mnitem.wobj.clrbtn.ra = mnitem.wobj.clrbtn.ra + dedit
		end;
		if mnitem.wobj.vallist then
			mnitem.wobj.vallist.ra = mnitem.wobj.vallist.ra - dedit
			for k,v in ipairs(mnitem.wobj.valitem) do
				v.right.la = v.right.la + dedit
				v.left.ra = v.left.ra + dedit
			end
			mnitem.wobj.vallist = nil
		end
	end;
end;
function defpos()
	local lastwindow = {
	lastwx = 120;
	lastwy = 220;
	lastww = 500;
	lastwh = 200;
	lastcpwx = math_round(ScrX/3);
	lastcpwy = math_round(ScrY/8);
	lastcpww = math_round(ScrX/3);
	lastcpwh = 60;
	lastwx1 = math_round(ScrX/8);
	lastwy1 = math_round(ScrY/3);
	lastww1 = 500;
	lastwh1 = 355;
	lastwx2 = math_round(ScrX/2);
	lastwy2 = math_round(ScrY/3)-(tSettings.WindowsAdv.gButtonsize+tSettings.WindowsAdv.gButtonspace);
	lastww2 = 500;
	lastwh2 = 355;
	lastchwx = math_round(ScrX/2);
	lastchwy = math_round(ScrY/4);
	};
	return lastwindow
end;
function centX(frame)
	return frame.mvbutton.la+(frame:ww()/3)
end;
function centY(frame)
	return frame.mvbutton.ba-(frame:wh()/3)
end;
function winRecomp(rzsbtn)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	for i,v in ipairs(rzsbtn.wobj.tButtons) do
		v.ba = rzsbtn.wobj.mainFrame:wh()+lcButtonspace
		v.la = rzsbtn.wobj.mainFrame:ww()-lcButtonsize*v.bindex - ((v.bindex-1)*lcButtonspace)
		v.ra = (v.bindex-1)*lcButtonspace+(v.bindex-1)*lcButtonsize
	end
	if rzsbtn.wobj.objtype == "uniWinObject" then
		for i,v in ipairs(rzsbtn.wobj.tVbars) do
			v.la = rzsbtn.wobj.mainFrame:ww()+lcButtonspace
		end
		for i,v in ipairs(rzsbtn.wobj.tHbars) do
			v.ta = rzsbtn.wobj.mainFrame:wh()+lcButtonspace;
			v.ra = -rzsbtn.wobj.mainFrame:ww()+2*(lcButtonsize+lcButtonspace);
		end
	end;
	rzsbtn.la = rzsbtn.wobj.mainFrame:ww()+lcButtonspace
	rzsbtn.ta = rzsbtn.wobj.mainFrame:wh()+lcButtonspace
	if rzsbtn.wobj.mainFrame:ww() <= 10*lcButtonsize then
		rzsbtn.wobj.mainFrame.ra = -10*lcButtonsize
	end;
	if rzsbtn.wobj.mainFrame:wh() <= 3*lcButtonsize then
		rzsbtn.wobj.mainFrame.ba = -3*lcButtonsize
	end;
end;
function refreshInfoPanes(finder)
	local infpane, btnbox, parent, xx, yy
	local totalpanes = #finder.infoPanes
	for i=1,totalpanes do
		infpane = finder.infoPanes[1]
		btnbox = infpane.btnbox
		parent = btnbox.Parent
		xx = infpane.menupane.la
		yy = ScrY-infpane.menupane.ta
		btnbox.Stck = infpane.menupane.Sticky
		btnbox.Hid = infpane.menupane.Hiding
		btnbox.Vis = infpane.menupane.Visible
		infpane.okbutton.Action(infpane.okbutton);
		btnbox.popupmenu(btnbox,parent,xx,yy)
	end
end;
function refreshCommCons(finder)
	local commpane, btnbox, parent, xx, yy
	local totalcoms = #finder.openCommands
	for i=1,totalcoms do
		commpane = finder.openCommands[1]
		commpane:moveItem(-1,"restart")
	end
end;
function refreshParDlgs(finder)
	local pardlg, btnbox, parent, xx, yy
	local totalcoms = #finder.openParDlgs
	for i=1,totalcoms do
		pardlg = finder.openParDlgs[1]
		btnbox = pardlg.btnbox
		parent = btnbox.Parent
		xx = pardlg.menupane.la
		yy = ScrY-pardlg.menupane.ta
		btnbox.Stck = pardlg.menupane.Sticky
		btnbox.Hid = pardlg.menupane.Hiding
		btnbox.Vis = pardlg.menupane.Visible
		pardlg.closebutton.Action(pardlg.closebutton);
		btnbox.popupmenu(btnbox,parent,xx,yy)
	end
end;
function externInput()
	local inputfile = string.gsub(profileDIR,"saves/","").."input.txt";
	local extinp, msg = io.open(inputfile, "r");
	local content = "< error >";
	if not extinp then
		CPlog("CelPad Alert: external input failed! Error msg: "..tostring(msg))
		local noExtInputMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		noExtInputMSG:init(ControlPanel.mainFrame,"noExtInputMSG",nil,nil,nil,{
		templates2.popMsg.noExtInputMSG[1],
		templates2.popMsg.noExtInputMSG[2],
		templates2.popMsg.noExtInputMSG[3],
		tostring(msg),
		txtfnt = templates2.popMsg.noExtInputMSG.txtfnt;
		},nil,"ok");
		noExtInputMSG:makeBranch(ControlPanel);
	else
		content = extinp:read("*line")
		if not content or content == "" then
			CPlog("CelPad Warning: external input file '"..tostring(inputfile).."' is empty")
			local emptyExtInputMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
			emptyExtInputMSG:init(ControlPanel.mainFrame,"emptyExtInputMSG",nil,nil,nil,{
			templates2.popMsg.emptyExtInputMSG[1],
			templates2.popMsg.emptyExtInputMSG[2],
			templates2.popMsg.emptyExtInputMSG[3].."'"..inputfile.."'"..templates2.popMsg.emptyExtInputMSG[4],
			},nil,"ok");
			emptyExtInputMSG:makeBranch(ControlPanel);
		end;
		extinp:close()
	end;
	return content;
end;
function pressSwitch(frame)
	if frame.mvrType == "movable" then
		if frame.Pressed then
			frame.Parent.Pressed = true
			frame.oldpressed = true
		else
			if frame.oldpressed then
				frame.oldpressed = false
				frame.Parent.Pressed = false
			end
		end
	end
end;
function returnView(finder)
	if finder.viewMode == "log" then
		tCelPadHUD.functions.viewLog(finder.oriframe)
	elseif finder.viewMode == "resultset" then
		tCelPadHUD.functions.viewResults(finder.oriframe)
	else
	end;
end;
function runStrFnc(finder)
	local runstr = ""
	local cntstr = #finder.resultSet
	if finder.runningTask == 100 then
		runstr = " (copying)";
	end;
	if finder.findertype == 1 then
		if finder.runningScan then
			runstr = " (scanning)";
		end;
		if finder.cancelscan then
			runstr = runstr.." (cancelled)"
		end
	elseif finder.findertype == 2 then
		if finder.runningTask == 1 then
			runstr = " (marking)";
		end;
		if finder.runningTask == 2 then
			runstr = " (comm. set)";
		end;
		if (finder.marker and finder.marker.cancelrq) or (finder.feeder and finder.feeder.cancelrq) or (finder.cmdset and finder.cmdset.cancelrq) then
			runstr = runstr.." (cancelled)"
		end
	end;
	if finder.niling then
		runstr = runstr.." (cleaning)";
	end;
	if finder.closing then
		runstr = runstr.." (closing)"
	end;
	if finder.runReady then
		runstr = " (waiting)";
	end;
	if runstr == "" then
		runstr = " (idle)";
	end;
	if finder.posDed then
		cntstr = "(d) "..cntstr
	end;
	if finder.paused then
		cntstr = cntstr.." (paused)"
	end;
	runstr = cntstr..runstr
	return runstr
end;
function tablepage(frame,intable,pagenum,attrtbl)
	local tab_ins = table.insert
	local dtable = {};
	dtable.txtcol = {};
	if pagenum == 1 then
		startline = 1;
	else
		startline = ((pagenum-1)*frame.Maxpageitems)+1;
	end;
	for x = startline,startline+(frame.Maxpageitems-1) do
		tab_ins(dtable,intable[x]);
		tab_ins(dtable.txtcol,(x-startline)+1,intable.txtcol[x]);
		if attrtbl then
			for i,a in ipairs(attrtbl) do
				if dtable[a] == nil then
					dtable[a] = {};
				end;
				tab_ins(dtable[a],intable[a][x]);
			end;
		end;
	end
	return dtable;
end;
function getMsgColor(msgsev)
	local cpborpupmsg, cpfillpupmsg, cpcolpupmsg = cpborpupmsgi, cpfillpupmsgi, cpcolpupmsgi;
	local cpborpupbx, cpfillpupbx, cpcolpupbx = cpborpupbxi, cpfillpupbxi, cpcolpupbxi;
	local cpfillpupbtn, cpborpupbtn, cpcolpupbtn = cpfillpupbtni, cpborpupbtni, cpcolpupbtni;
	if msgsev == "a" then
		cpborpupmsg, cpfillpupmsg, cpcolpupmsg = cpborpupmsga, cpfillpupmsga, cpcolpupmsga;
		cpborpupbx, cpfillpupbx, cpcolpupbx = cpborpupbxa, cpfillpupbxa, cpcolpupbxa;
		cpfillpupbtn, cpborpupbtn, cpcolpupbtn = cpfillpupbtna, cpborpupbtna, cpcolpupbtna;
	elseif msgsev == "w" then
		cpborpupmsg, cpfillpupmsg, cpcolpupmsg = cpborpupmsgw, cpfillpupmsgw, cpcolpupmsgw;
		cpborpupbx, cpfillpupbx, cpcolpupbx = cpborpupbxw, cpfillpupbxw, cpcolpupbxw;
		cpfillpupbtn, cpborpupbtn, cpcolpupbtn = cpfillpupbtnw, cpborpupbtnw, cpcolpupbtnw;
	end;
	return cpborpupmsg, cpfillpupmsg, cpcolpupmsg, cpborpupbx, cpfillpupbx, cpcolpupbx, cpfillpupbtn, cpborpupbtn, cpcolpupbtn
end;
function wrapInfLine(txt,mw,fntsz)
	local lcButtonsize,lcButtonspace = gButtonsize,gButtonspace
	local cpgetwidth = cpgetwidth;
	local s_sub = string.sub
	local s_len = string.len
	local wtxt, rsttxt, txtsub, bx, bw
	local estmsgw = cpgetwidth(fntsz,string.rep("x",mw))
	if s_sub(txt,1,1) == " " then txt = s_sub(txt,2) end;
	if cpgetwidth(fntsz,txt) > estmsgw then
		local tmpstr = s_sub(txt,1,mw)
		while cpgetwidth(fntsz,tmpstr) < estmsgw do
			bx = s_len(tmpstr)+1
			tmpstr = tmpstr..s_sub(txt,bx,bx)
		end
		bw = s_len(tmpstr)
		txtsub = s_sub(tmpstr,bw,bw)
		if s_sub(txt,bw+1,bw+1) ~= " " then
			while not (bw < 1 or (txtsub == " " or txtsub == "," or txtsub == "." or txtsub == ":")) do
				bw = bw - 1
				txtsub = s_sub(tmpstr,bw,bw)
			end
		end
		wtxt = s_sub(tmpstr,1,bw)
		rsttxt = s_sub(txt,bw+1)
	else
		wtxt = txt
		rsttxt = ""
	end
	return wtxt, rsttxt
end;
function cloneFinder(finder,duplicatedFinder)
	local deepcopy = deepcopy
	local oldftype = finder.findertype
	local newftype = duplicatedFinder.mainFrame.CPFinder.findertype
	local newfinder = duplicatedFinder.mainFrame.CPFinder
	if ms060InheritFinder then
		if oldftype == 1 and newftype == 1 then
			newfinder.queryStars = deepcopy(finder.queryStars)
			newfinder.metaQueryStars = deepcopy(finder.metaQueryStars)
			newfinder.queryPlanets = deepcopy(finder.queryPlanets)
			newfinder.metaQueryPlanets = deepcopy(finder.metaQueryPlanets)
			newfinder.queryDsos = deepcopy(finder.queryDsos)
			newfinder.metaQueryDsos = deepcopy(finder.metaQueryDsos)
			newfinder.queryLocations = deepcopy(finder.queryLocations)
			newfinder.metaQueryLocations = deepcopy(finder.metaQueryLocations)
			newfinder.SUM.srctab = deepcopy(finder.SUM.srctab)
			newfinder.defQRSloaded = finder.defQRSloaded
			newfinder.defQROloaded = finder.defQROloaded
			newfinder.defQRDloaded = finder.defQRDloaded
			newfinder.defQRLloaded = finder.defQRLloaded
			newfinder.defSUMloaded = finder.defSUMloaded
			newfinder.newSwhat = finder.newSwhat
		elseif oldftype == 2 and newftype == 2 then
			newfinder.markerParams = deepcopy(finder.markerParams)
			newfinder.refmarkParams = deepcopy(finder.refmarkParams)
			newfinder.CMDS.srctab = deepcopy(finder.CMDS.srctab)
			newfinder.CMDS.cmdopts = deepcopy(finder.CMDS.cmdopts)
			newfinder.defCMDSloaded = finder.defCMDSloaded
		end;
		newfinder.VW.srctab = deepcopy(finder.VW.srctab)
		newfinder.defVWloaded = finder.defVWloaded
		newfinder.unittable = deepcopy(finder.unittable)
		newfinder.unitmeta = deepcopy(finder.unitmeta)
	end
	newfinder.nilToRisk = finder.nilToRisk;
end;
function mergemenutabs(t1,t2)
	local tab_ins = table.insert
	local t = {
		switch = {};
		fnctab = {};
		runfnc = {};
	};
	for i,v in ipairs(t1) do
		tab_ins(t,v);
	end;
	for i,v in ipairs(t2) do
		tab_ins(t,v);
	end;
	for i,v in ipairs(t1["switch"]) do
		tab_ins(t["switch"],v);
	end;
	for i,v in ipairs(t2["switch"]) do
		tab_ins(t["switch"],v);
	end;
	for i,v in ipairs(t1["fnctab"]) do
		tab_ins(t["fnctab"],v);
	end;
	for i,v in ipairs(t2["fnctab"]) do
		tab_ins(t["fnctab"],v);
	end;
	for i,v in ipairs(t1["runfnc"]) do
		tab_ins(t["runfnc"],v);
	end;
	for i,v in ipairs(t2["runfnc"]) do
		if v > 0 then
			tab_ins(t["runfnc"],v+#t1);
		else
			tab_ins(t["runfnc"],0);
		end;
	end;
	return t
end;
function checkFindPrgs(finder)
	return (finder.niling or finder.feeder or finder.marker or finder.cmdset or finder.locset or finder.runReady)
end;
function checkScanBusy(finder)
	return (finder.runningScan or finder.runReady or finder.runningTask == 100)
end;
function getLogValStr(finder,task)
	local logstr
	if type(finder.queryVal[task]) == "string" then
		if finder.queryVal[task]=="" then
			logstr = "searching for empty string"
		else
			logstr = "searching for substring: "..finder.queryVal[task];
		end;
	elseif type(finder.queryVal[task]) == "boolean" then
		logstr = tostring(finder.queryVal[task])
	elseif finder.queryVal[task] and finder.queryVal[task].minv then
		if finder.unittable[task] then
			local unittext = finder.unitmeta[task].valuelist[finder.unitmeta[task].metaindx]
			if unittext~="" then
				logstr = "interval ["..unittext.."]: "
			else
				logstr = "interval: "
			end;
			logstr = logstr..finder.unittable[task][1](finder.queryVal[task].minv,"fromnative").." - "..finder.unittable[task][1](finder.queryVal[task].maxv,"fromnative");
		else
			logstr = "interval "..finder.queryVal[task].minv.." - "..finder.queryVal[task].maxv;
		end;
	elseif finder.queryVal[task] and finder.queryVal[task].choicelist then
		logstr = finder.queryVal[task].mcstr;
	else
		logstr = "unspecified"
	end;
	return logstr;
end
function buildSumtab(finder,task)
	finder.SUM.summary[task] = {
	minn = math.huge;
	maxn = -math.huge;
	mnnamef = nil;
	mnnamel = nil;
	mxnamef = nil;
	mxnamel = nil;
	mval = {};
	bool = {
	["true"] = 0;
	["false"] = 0;
	["no data"] = 0;
	};
	extval = {};
	};
end
function procLoopCoef(tag)
	local parsLoop = ms010ScanLoop*(tCelPadFinder.loopCoef[tag] or 1)
	if parsLoop <= 10 then parsLoop = 10; end
	return parsLoop
end;
function getKeyName(object,finder)
	if object.getinfo then
		local parname
		local m_rnd = math.random
		if object:getinfo().parent then
			parname = object:getinfo().parent:name()
		else
			parname = "noparent"
		end
		local ltype = object:type() or "notype"
		if ltype == "location" then
			ltype = object:getinfo().featureType or "notype"
		end;
		local lname = object:name()
		local kname = ltype..":"..parname.."/"..lname
		if finder then
			if finder.posDed then
				local obj_pos  = object:getposition()
				kname = kname..";"..obj_pos.x..";"..obj_pos.y..";"..obj_pos.z
				if finder.tmpObjects[kname] then
					finder.dupNum = finder.dupNum or 0
					finder.dupNum = finder.dupNum + 1;
					if finder.alrtlogs then
						CPlog("!!! warning: position conflict: "..tostring(kname),0,finder.sysLog)
					end
				end;
			else
				if finder.tmpObjects[kname] then
					kname = kname..(m_rnd())..(m_rnd())
				end;
			end;
		end;
		return kname
	else
		return "no data"
	end
end;
function locsnum(object)
	local num = 0
	for k in object:locations() do
		num = num + 1
	end
	return num
end;
function endScanMsg(finder)
	local exstat
	if finder.cancelscan then
		exstat = "cancelled";
	else
		exstat = "finished";
	end;
	if finder.closing then
		CPlog("scanner closing, please wait..",0,finder.sysLog)
	else
		if finder.scanWhat ~= "summary" then
			local objnum = #finder.resultSet
			CPlog("### scan "..exstat..", "..tostring(objnum).." results",0,finder.sysLog)
			if ms065VwSumAutoLd then
				local vwindx = templates.vwindx;
				if finder.newSwhat == "getpars" and (finder.oldSwhat == "locations" or finder.oldSwhat == "getlocs") then
					vwindx["getpars"] = "satellites";
				end;
				if vwindx[finder.newSwhat] then
					myCelPad:loadCP("VW",vwindx[finder.newSwhat],finder)
				end;
			end;
			CPlog("### to see the result set, switch view in scanner menu, then right click on item for item menu",0,finder.sysLog)
			returnView(finder)
		else
			CPlog("### summary "..exstat..";",0,finder.sysLog)
			returnView(finder)
		end;
	end;
	nilStatLogs(finder)
end;
function finalizeScan(finder)
	if finder.paused then finder.paused = nil; end;
	finder.cancelscan = nil;
	finder.canceldone = nil;
	finder.runningScan = nil;
	finder.oldSwhat = finder.newSwhat;
	if fastCleanup then
		local objnum = #finder.resultSet
		local famid = finder.famid
		finder.nilfam[famid][1] = objnum
		if myCelPad.nilfams[famid] and myCelPad.nilfams[famid][famid] then
			myCelPad.nilfams[famid][famid][1] = objnum
			if finder.scanType == "cel" then
				finder.nilfam[famid][3] = finder.nilfam[famid][3] or objnum
				myCelPad.nilfams[famid][famid][3] = myCelPad.nilfams[famid][famid][3] or objnum
			end;
		else
			CPlog("!!! warning: fast clean thread finished in an unexpected manner")
		end
		for t,y in pairs(finder.nilfam) do
			if y[1] > 0 then
				myCelPad.nilfams[t][famid][1] = objnum
			end
		end
		if finder.scanType == "rs" and finder.nilfam[famid][3] and finder.nilfam[famid][3]>0 then
			checkNilfam(finder,false,true)
			if table_num(myCelPad.nilfams[famid]) == 1 and myCelPad.nilfams[famid][famid] then
				finder.nilfam[famid][3] = objnum
				myCelPad.nilfams[famid][famid][3] = objnum
			end;
		end
	end;
	if finder.runningTask ~= 0 then
		if finder.alrtlogs then
			CPlog("!!! alert: forced running task "..tostring(finder.runningTask).." reset after regular scan finish",0,finder.sysLog)
		end
		finder.runningTask = 0
	end;
end;
function nilStatLogs(finder)
	finder.statlogx1 = {};
	finder.statlogx2 = {};
	finder.statbodlog = {};
	finder.statparlog = {};
	finder.statloclog = {};
	finder.statlog1 = nil;
	finder.statlog2 = nil;
	finder.statlogsm = nil;
	finder.tasktablog1 = nil;
	finder.tasktablog2 = nil;
	finder.taskcntlog = nil;
	finder.statmark2 = nil;
	finder.statcmd = nil;
	if finder.nilparser then
		finder.nilparser.statnillog = nil;
	end;
	finder.statnillogx = nil;
	finder.statlocpprlog = nil;
end;
function argAbrv(argname)
	local abrvName
	local argTmp = deepcopy(templates.inputParam[argname].meta[1])
	local red3str = templates.inputParam.zcmddistance.meta[1].." "..templates.inputParam.zcmdduration.meta[1]
	if string.find(red3str,argTmp) then
		abrvName = string.sub(argTmp,1,3).."."
	elseif argTmp == templates.inputParam.zcmdintpol.meta[1] then
		abrvName = "Interp."
	elseif string.find(argTmp,"Marker") then
		abrvName = string.gsub(argTmp,"Marker","M.")
	elseif string.find(argTmp,"Obs. Speed:") then
		abrvName = "Speed";
	else
		abrvName = argTmp
	end
	return abrvName
end;
function cmdstart(finder,box,parent,x,y)
	local itemnum = #finder.resultSet
	local checkFindPrgs = checkFindPrgs
	if itemnum ~= 0 then
		finder.CMDS.cmdopts.data.co01startobj = finder.CMDS.cmdopts.data.co01startobj or 1
		finder.CMDS.cmdopts.data.co02endobj = finder.CMDS.cmdopts.data.co02endobj or #finder.resultSet
		finder.CMDS.cmdopts.meta.co02endobj[4] = #finder.resultSet
		if checkFindPrgs(finder) then
			if not box.MSGupT["PopTgtBusy"] then
				box.PopTgtBusy = PopMessage:new({parent.popupMenus});
				box.PopTgtBusy:init(box,"PopTgtBusy",x,y,nil,nil,nil,"ok");
				box.PopTgtBusy:makeBranch(box);
			end;
		else
			finder.runReady = true;
			local runcmds = function()
				if #finder.runningCommands > 0 then
					if not box.MSGupT["oneCmdSetMSG"] then
						box.oneCmdSetMSG = PopMessage:new({parent.popupMenus});
						box.oneCmdSetMSG:init(box,"oneCmdSetMSG",x,y,nil,nil,nil,"ok");
						box.oneCmdSetMSG:makeBranch(box);
					end
					finder.runReady = nil;
				else
					if finder.CMDS.mtdlg then
						finder.CMDS.mtdlg.btnselfAPL:Action()
					end
					finder:runCommandSet();
					CPlog("command set started; "..tostring(finder.CMDS.cmdopts.data.co02endobj-finder.CMDS.cmdopts.data.co01startobj+1).." objects; starting at #"..tostring(finder.CMDS.cmdopts.data.co01startobj).."; finishing at #"..tostring(finder.CMDS.cmdopts.data.co02endobj).."",0,finder.sysLog);
					finder.runReady = nil;
				end
			end;
			if timedelta >= markSetLim[4] then
				if not box.MSGupT["slowWarnMSG"] then
					box.slowWarnMSG = PopMessage:new({parent.popupMenus});
					box.slowWarnMSG:init(box,"slowWarnMSG",x,y,nil,nil,nil,"yn",
					function()
						runcmds()
					end,
					function()
						finder.runReady = nil;
					end
					);
					box.slowWarnMSG:makeBranch(box)
				end;
			else
				runcmds()
			end
		end;
	else
		if not box.MSGupT["PopMSGOKnoresults"] then
			box.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
			box.PopMSGOKnoresults:init(box,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
			box.PopMSGOKnoresults:makeBranch(box.oribtn);
			if box.wobj then
				box.wobj:quitpopup(box.wobj.btnbox);
				box.oriparent.popup = box.oriparent.popup:quitpopup(box.oriparent);
			end
		end;
	end;
end;
function execCommandSet(parser,finder,srctbl)
	if parser.object and type(parser.object) == "userdata" then
		local timerid = "CMD-"..parser.object:name().."-"..tostring(math.random())
		local obs = observer
		local minseq = math.huge
		local oriik = parser.ik
		for h,j in ipairs(srctbl.data[1][1]) do
			if j then
				minseq = math.min(minseq,h)
				local commandSetTimer = CPtimer:new({tCelPad.Timers,finder.runningCommands});
				commandSetTimer:init("commandSetTimer",timerid,srctbl.data.argTbl[h].dly,"chainSTART",h,
				function(o)
					o.cmdname = srctbl.data[1].choicelist[h]
					o.cmdargs = deepcopy(templates.cpcmds[o.cmdname].args)
					o.paramtab = {};
					o.object = parser.object
					if finder.cmdset and finder.cmdset.ik then
						oriik = finder.cmdset.ik
					end
					if finder.viewMode == "resultset" then
						finder.oriframe.whtable.txtcol[oriik] = cpfntcolruncmd;
					end
					if finder.CMDS.mtdlg then
						finder.CMDS.mtdlg.cmdtimer = o
					end
					parser.cmdtimer = commandSetTimer
					o.cmdargs = string.gsub(o.cmdargs,"zcmddistaarc ","")
					local i = 1
					for p in string.gmatch(o.cmdargs,"%w+") do
						if p ~= "dly" then
							for r,t in pairs(srctbl.data.argTbl[h]) do
								if r == p then
									if r == "zcmddistance" and srctbl.data.argTbl[h]["zcmddistaarc"] > 0 then
										t = (o.object:getinfo().radius or 1)*srctbl.data.argTbl[h]["zcmddistaarc"]
										if finder.CMDS.mtdlg then
											finder.CMDS.mtdlg.menutab.argTbl[h]["zcmddistance"] = t
										end
									end
									if r == "zcmdvector" and (math.abs(t[1])+math.abs(t[2])+math.abs(t[3])) == 0 then
										CPlog("!!! warning: illegal vector definition {"..t[1]..","..t[2]..","..t[3].."}, using {0,1,0} instead",0,finder.sysLog)
										t = {0,1,0};
									end
									if type(t) == "table" and (t.valuelist or t.choicelist) then
										o.paramtab[i] = t[1]
									else
										o.paramtab[i] = t
									end
								end
							end
							i = i + 1;
						end
					end
					templates.cpcmds[o.cmdname].fnc(obs,o.object,o.paramtab,finder,parser)
				end,
				function(o)
					if o.status ~= "kill" or (o.status == "kill" and #o.chain == 0) then
						if #o.chain == 0 then
							parser.finished = true
							if finder.viewMode == "resultset" and not finder.paused then
								finder.oriframe.whtable.txtcol[oriik] = cpfntcolmainw;
							end
							if finder.locset then finder.locset = nil end;
							if finder.CMDS.mtdlg then
								finder.CMDS.mtdlg:moveItem(-1,"fincmds")
							end
							parser.cmdtimer = nil;
						end
					end
				end
				);
				commandSetTimer:makeBranch(finder)
			end
		end
		if tCelPad.Timers.chained[timerid][minseq].status ~= "active" then
			tCelPad.Timers.chained[timerid][minseq].status = "active"
		end
	else
		cmdError(finder,parser,"Invalid or missing object! No parameter on input.")
	end
end;
function cmdError(finder,parser,errmsg)
	if not parser.object then
		parser.object = {name = function() return "no object" end};
	end
	if parser then
		myCelPad:systemMsg(nil,nil,"generr",finder,errmsg,parser)
		if parser.cmdtimer then
			parser.cmdtimer:killchain();
		end
	end;
	if not parser.popup and finder.cmdset then
		finder.cmdset.cancelrq = true;
	end;
end;
function markerstart(action,finder,box,parent,x,y)
	local itemnum = #finder.resultSet
	local checkFindPrgs = checkFindPrgs
	local markmsg
	if itemnum ~= 0 then
		if checkFindPrgs(finder) then
			if not box.MSGupT["PopTgtBusy"] then
				box.PopTgtBusy = PopMessage:new({parent.popupMenus});
				box.PopTgtBusy:init(box,"PopTgtBusy",x,y,nil,nil,nil,"ok");
				box.PopTgtBusy:makeBranch(box);
			end;
		else
			finder.runReady = true;
			local runmark = function()
				local markfnc, condition
				if action == "mark" then
					markmsg = "toMarkMSG"
					local mshape = finder.markerParams.zmkp2shape[1]
					local msize = finder.markerParams.zmkp3size
					local mcolor = finder.markerParams.zmkp1color[1]
					condition = (itemnum > markSetLim[1])
					markfnc = function()
						CPlog("marking started; "..mshape.."; "..mcolor.."; "..msize,0,finder.sysLog);
						finder:markObjects(true);
						if box.wobj then
							box.wobj:quitpopup(box.wobj.btnbox);
						end
						finder.runReady = nil;
					end;
				else
					markmsg = "toUnMarkMSG"
					markfnc = function()
						CPlog("unmarking started",0,finder.sysLog);
						finder:markObjects(false);
						finder.runReady = nil;
					end;
					condition = true;
				end;
				if condition then
					if not box.MSGupT[markmsg] then
						finder.MarkMSG = PopMessage:new({parent.popupMenus});
						finder.MarkMSG:init(box,markmsg,x,y,nil,{
						templates2.popMsg[markmsg][1],
						templates2.popMsg[markmsg][2]..tostring(itemnum)..templates2.popMsg[markmsg][3],
						templates2.popMsg[markmsg][4],
						templates2.popMsg[markmsg][5],
						templates2.popMsg[markmsg][6],
						txtfnt = templates2.popMsg[markmsg].txtfnt;
						},nil,"yn",
						function(o)
							if (itemnum > markSetLim[2] or timedelta >= markSetLim[3]) and not tSettings.SystemSet.ms020AdaptiveLoops then
								box.adaptOnMarkMSG = PopMessage:new({parent.popupMenus});
								box.adaptOnMarkMSG:init(box,"adaptOnMarkMSG",x,y,nil,
								nil,nil,"yn",
								function(o)
									oldAdaptLoops = tSettings.SystemSet.ms020AdaptiveLoops
									tSettings.SystemSet.ms020AdaptiveLoops = true;
									gVarBinds.updateGlobals();
									markfnc();
								end,
								function(o)
									finder.runReady = nil;
								end
								);
								box.adaptOnMarkMSG:makeBranch(box.oribtn);
							else
								markfnc();
							end;
						end,
						function(o)
							finder.runReady = nil;
						end
						);
						finder.MarkMSG:makeBranch(box.oribtn);
					end;
				else
					markfnc()
				end;
			end;
			if timedelta >= markSetLim[4] then
				if not box.MSGupT["slowWarnMSG"] then
					box.slowWarnMSG = PopMessage:new({parent.popupMenus});
					box.slowWarnMSG:init(box,"slowWarnMSG",x,y,nil,nil,nil,"yn",
					function()
						runmark()
					end,
					function()
						finder.runReady = nil;
					end
					);
					box.slowWarnMSG:makeBranch(box)
				end;
			else
				runmark()
			end
		end;
	else
		if not box.MSGupT["PopMSGOKnoresults"] then
			box.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
			box.PopMSGOKnoresults:init(box,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
			box.PopMSGOKnoresults:makeBranch(box.oribtn);
			if box.wobj then
				box.wobj:quitpopup(box.wobj.btnbox);
				box.oriparent.popup = box.oriparent.popup:quitpopup(box.oriparent);
			end
		end;
	end;
end;
function rmAllRefMarks()
	local src
	for k,v in pairs(tCelPadFinder.refMarked) do
		if k ~= "celObj" then
			src = tCelPadFinder.refMarked.celObj[k]
			for ki,vi in pairs(v) do
				src:removereferencemark(ki)
				tCelPadFinder.refMarked[k][ki] = nil
			end
			tCelPadFinder.refMarked.celObj[k]=nil
			tCelPadFinder.refMarked[k] = nil
		end
	end
end
function checkNilfam(finder,temp,chngroot)
	local abrupt, errstat, skipcheck
	local famid = finder.famid
	local nillimit = 10
	local ref1, ref2 = 0,0
	local objnum
	local rootnum, obnum, nxtroot, busy, oriroot
	local nxtrtnum = 0;
	if temp then
		objnum = #finder.tmpResSet
	else
		objnum = #finder.resultSet
	end
	local cntRoot = function(t1,w1)
		local frnroots = 0
		local selfroot = myCelPad.nilfams[t1][w1][5]
		local selfobjnum = #selfroot.resultSet
		for k,l in pairs(selfroot.nilfam) do
			if l[3] and k ~= famid then
				frnroots = frnroots + (l[2] or 0)
			end
		end
		local retval = ((selfobjnum - frnroots) >= rootnum)
		return retval;
	end;
	local changeNilRoot = function(t1,nxtroot)
		if not temp then
		for r,g in pairs(myCelPad.nilfams) do
			for j,k in pairs(g) do
				if k[5].nilfam[nxtroot] then
					k[5].nilfam[nxtroot][3] = rootnum
					if j == nxtroot then
						k[5].nilfam[nxtroot][1] = k[5].nilfam[t1][2]
					end
				end
				if k[5].nilfam[t1] then
					if k[5].nilfam[nxtroot] then
						k[5].nilfam[t1][3] = nil;
					else
						if k[5].famid == t1 and not chngroot then
						else
							k[5].nilfam[nxtroot] = {};
							k[5].nilfam[nxtroot][1] = k[5].nilfam[t1][1]
							k[5].nilfam[nxtroot][2] = k[5].nilfam[t1][2]
							k[5].nilfam[nxtroot][3] = k[5].nilfam[t1][3]
							k[5].nilfam[nxtroot][4] = k[5].nilfam[t1][4]
							k[5].nilfam[nxtroot][5] = k[5].nilfam[t1][5]
							k[5].nilfam[t1][3] = nil;
						end
						myCelPad.nilfams[nxtroot][k[5].famid] = {};
						myCelPad.nilfams[nxtroot][k[5].famid][1] = #k[5].resultSet
						myCelPad.nilfams[nxtroot][k[5].famid][5] = k[5]
					end
				end
			end
			if g[nxtroot] then
				g[nxtroot][3] = rootnum
				g[nxtroot][1] = rootnum
			end
			if g[t1] then
				g[t1][3] = nil;
			end
		end;
		else
		end
		abrupt = true
	end;
	local fndRoot = function(fm)
		local rx = 0;
		for h,j in pairs(myCelPad.nilfams) do
			if j[fm] then
				for k,l in pairs(myCelPad.nilfams[h]) do
					if k ~= fm and (l[1] and l[1] > rx) then
						nxtroot = k
						rootnum = l[1]
						rx = l[1]
					end
				end
			end
		end;
	end;
	for t,y in pairs(finder.nilfam) do
		rootnum = y[3]
		obnum = y[2]
		if rootnum and rootnum > 0 then
			if myCelPad.nilfams[t] then
				if  table_num(myCelPad.nilfams[t]) == 1 then
					if myCelPad.nilfams[t][famid] then
						if not temp and not chngroot then
							if myCelPad.nilfams[t][famid][3] and myCelPad.nilfams[t][famid][3] > 0 then
								fndRoot(famid);
								if nxtroot then
									changeNilRoot(t,nxtroot)
								else
									CPlog("fast clean info: last finder in thread",0,finder.sysLog)
									abrupt = false
									skipcheck = true
								end
							end
							myCelPad.nilfams[t][famid] = nil
						else
						end
						abrupt = false
						skipcheck = true
					else
						if myCelPad.nilfams[t][t] then
							if myCelPad.nilfams[t][t][3] and myCelPad.nilfams[t][t][3] > 0 then
								abrupt = true;
							else
								CPlog("!!! alert: unhandled error(1), fast clean inconsistent")
								errstat = true
							end;
						else
							CPlog("!!! alert: unhandled error(2), fast clean inconsistent")
							errstat = true
						end;
					end
				else
					if myCelPad.nilfams[t][famid] then
						if not skipcheck then
							oriroot = myCelPad.nilfams[t][t]
							if oriroot then
								busy = oriroot[5].runningScan
							else
								CPlog("!!! alert: original root unavailable, fast clean inconsistent")
								errstat = true
							end
							if not busy and t ~= famid and oriroot and oriroot[1] >= oriroot[3] and cntRoot(t,oriroot[5].famid) then
								abrupt = true
							else
								for w,e in pairs(myCelPad.nilfams[t]) do
									busy = e[5].runningScan
									if not busy and w ~= famid then
										if e[3] == nil then
											if e[2] then
												if e[2] >= rootnum and e[2] >= nxtrtnum then
													if cntRoot(t,w) then
														nxtroot = w
														nxtrtnum = e[2]
													end
												end
											else
												local nxrtobjn = #e[5].resultSet;
												if nxrtobjn >= rootnum and nxrtobjn > nxtrtnum then
													if cntRoot(t,w) then
														nxtroot = w
														nxtrtnum = nxrtobjn
													end
												end
											end
										end
									end
								end
								if nxtroot then
									changeNilRoot(t,nxtroot)
								else
									if myCelPad.nilfams[famid][t][3] then
										fndRoot(famid);
										if nxtroot then
											changeNilRoot(t,nxtroot)
										else
											CPlog("!!! alert: next root could not be determined, fast clean inconsistent")
											errstat = true
										end
									end
									abrupt = false
									skipcheck = true
								end
							end
						else
						end
					else
						CPlog("!!! alert: unhandled error(3), fast clean inconsistent")
						errstat = true
					end
				end
			else
				CPlog("!!! alert: root record for cleanup missing, fast clean inconsistent")
				errstat = true
			end
		end;
	end;
	if abrupt and not errstat then
		nillimit = 0
	end;
	if errstat then
		myCelPad:systemMsg(nil,nil,"fcerr");
	end;
	return nillimit
end;
function nilIdRst(finder)
	if finder.oldfamid then
		myCelPad.nilfams[finder.oldfamid][finder.oldfamid] = nil;
		if table_num(myCelPad.nilfams[finder.oldfamid]) == 0 then
			myCelPad.nilfams[finder.oldfamid] = nil
		end
		for p,l in pairs(myCelPad.nilfams) do
			myCelPad.nilfams[p][finder.oldfamid] = nil;
		end
		finder.oldfamid = nil;
	end
end;
function nilResSet(finder,t,inrisk)
	local tabid = tostring(t)
	local math_dround = math_dround
	local niledtxt, temp
	local fctxt = "";
	tCelPadHUD.functions.viewLog(finder.oriframe)
	if tabid == "resultSet" then
		niledtxt = "result set"
	else
		niledtxt = "temporary set"
		temp = true
	end;
	local nillimit
	if fastCleanup and finder.famid then
		nillimit = checkNilfam(finder,temp)
	else
		nillimit = 10
	end
	local nilToDlt = nilTmoRisk[3];
	local nilToNewClnLps = nilTmoRisk[4];
	local nilToMinRedLps = nilTmoRisk[5];
	local nilToDownsteps = nilTmoRisk[6];
	local scanLoopFuse1 = ms010ScanLoop*Fuse
	if nillimit ~= 0 then
		finder.niling = tostring(t);
		finder.nilparser = CPLoopPars:new({tCelPad.Parsers})
		finder.nilparser.items = #finder[t]
		finder.nilparser.t = t;
		finder.nilparser.oldtimdlt = timedelta;
		finder.nilparser.newrun = true;
		finder.nilparser.rstloops = 0;
		finder.nilparser.ikl = 0;
		finder.lagcnt = finder.lagcnt or 0;
		finder.nilLoop = finder.nilLoop or scanLoopFuse1
		if (finder.nilLoop == scanLoopFuse1) or inrisk then
			if finder.nilToRisk then
				finder.nilLoop = math.floor(finder.nilLoop/nilToDownsteps)
				finder.lagcnt = nilToDownsteps
				if finder.alrtlogs then
					CPlog("!!! warning: cleanup flagged as risky, initial pack decreased "..tostring(nilToDownsteps).." times",0,finder.sysLog)
				end
			end;
		end;
		finder.nilparser:init("nilparser",finder.nilLoop,
		function(o)
			o.ik = o.ik or o.items
			o.ik = o.ik - 1
			finder[t][o.ik] = nil;
		end,
		function(o)
			return (o.ik <= nillimit )
		end,
		function(o)
			finder[t] = nil
			finder[t] = {
			};
			if ms131fastCleanup then
				fctxt = ", deep clean";
			end
			CPlog("cleanup finished ("..niledtxt..fctxt..")",0,finder.sysLog,o.statnillog)
			finder.niling = nil;
			if finder.nilWarnMSGup then
				finder.nilToWarnMSG.ynbutton.ynbuttonN:Action();
			end
			if fastCleanup then
				if tabid == "resultSet" then
					finder:init_nilid()
				end
			end
		end,
		function(o)
			local tdelta = timedelta
			local scanLoopFuse2 = ms010ScanLoop*Fuse
			o.statnillog = o.statnillog or #finder.sysLog+1
			CPlog("cleanup running, please wait; cleaning item #"..tostring(o.ik).."; pack:"..tostring(o.maxinloop),0,finder.sysLog,o.statnillog);
			if o.newrun then
				 if finder.lagcnt > 0 then
					if o.ikl < nilToNewClnLps then
						o.ikl = o.ikl + 1
					else
						if finder.lagcnt > 1 then
							o.ikl = 0;
							finder.lagcnt = finder.lagcnt - 1
							o.maxinloop = math.floor(scanLoopFuse2/finder.lagcnt);
							finder.nilLoop = o.maxinloop;
						else
							o.maxinloop = scanLoopFuse2;
							o.newrun = nil;
						end
					end;
				 end;
			end;
			local lagdelta = (tdelta - o.oldtimdlt)
			if lagdelta >= nilToDlt then
				o.newrun = nil;
				if not finder.nilToRisk then
					if finder.alrtlogs then
						CPlog("!!! warning: cleanup lag detected ("..tostring(math_dround(lagdelta,3)).." s), setting cleanup to risky",0,finder.sysLog)
					end
					finder.nilToRisk = true;
				else
				end
				if (not finder.nilWarnMSGup and finder.lagcnt > 0) and (not finder.closing) then
					myCelPad:systemMsg(centX(finder.oriframe),centY(finder.oriframe),"nillag",finder,nil,o)
				end;
				finder.lagcnt = finder.lagcnt + 1;
				o.maxinloop = math.floor(scanLoopFuse2/finder.lagcnt)
				if o.maxinloop < nilToMinRedLps then
					o.maxinloop = nilToMinRedLps
				end;
				finder.nilLoop = o.maxinloop
				if finder.lagcnt > 1 then
					if finder.alrtlogs then
						CPlog("!!! warning: cleanup lags detected ("..tostring(math_dround(lagdelta,3)).." s), cleanup pack changed to "..tostring(o.maxinloop),0,finder.sysLog);
					end
				end;
			end;
			o.oldtimdlt = tdelta
		end
		);
		finder.nilparser:makeBranch(finder);
	else
		finder[t] = nil
		finder[t] = {
		};
		if ms131fastCleanup then
			fctxt = ", abrupt";
		end
		CPlog("cleanup finished ("..niledtxt..fctxt..")",0,finder.sysLog,finder.statnillog)
		finder.niling = nil;
		if finder.nilWarnMSGup then
			finder.nilToWarnMSG.ynbutton.ynbuttonN:Action();
		end
		if fastCleanup then
			if tabid == "resultSet" then
				finder:init_nilid()
			end
		end
	end;
end;
function nilTmpObj(finder,t)
	local nillimit = 10
	local tnums = table_num(finder[t])
	if tnums > nillimit then
		finder.niling = tostring(t);
		local nilparser = CPLoopPars:new({tCelPad.Parsers})
		nilparser.t = t
		nilparser:init("nilparser",procLoopCoef("nilobj"),
		function(o)
			o.ik = o.ik or 0
			o.ik = o.ik + 1;
			local indexnum = o.ik;
			o.nilobjkey = next(finder.tmpObjects,o.niloldkey)
			o.niloldkey = o.nilobjkey
			finder.tmpObjects[o.nilobjkey] = nil;
		end,
		function(o)
			return (o.ik >= (tnums-nillimit))
		end,
		function(o)
			finder[t] = nil
			finder[t] = {};
			finder.niling = nil;
			CPlog("cleanup finished (temporary objects, deep clean)",0,finder.sysLog,o.statnillog)
		end,
		function(o)
			o.statnillog = o.statnillog or #finder.sysLog+1
			CPlog("cleanup running, please wait; cleaning item #"..(tnums-o.ik),0,finder.sysLog,o.statnillog);
		end
		);
		nilparser:makeBranch(finder);
	else
		finder[t] = nil
		finder[t] = {};
		finder.statnillogx = finder.statnillogx or #finder.sysLog+1
		CPlog("cleanup finished (temporary objects, abrupt)",0,finder.sysLog,finder.statnillogx)
		finder.niling = nil;
	end;
end;
-- __genOrderedIndex, orderedNext, orderedPairs; thanx to http://lua-users.org/wiki/SortedIteration
function __genOrderedIndex( t )
	local orderedIndex = {}
	for key in pairs(t) do
		table.insert( orderedIndex, key )
	end
	table.sort( orderedIndex )
	return orderedIndex
end
function orderedNext(t, state)
	-- Equivalent of the next function, but returns the keys in the alphabetic
	-- order. We use a temporary ordered key table that is stored in the
	-- table being iterated.
	--print("orderedNext: state = "..tostring(state) )
	if state == nil then
		-- the first time, generate the index
		t.__orderedIndex = __genOrderedIndex( t )
		key = t.__orderedIndex[1]
		return key, t[key]
	end
	-- fetch the next value
	key = nil
	for i = 1,table.getn(t.__orderedIndex) do
		if t.__orderedIndex[i] == state then
			key = t.__orderedIndex[i+1]
		end
	end
	if key then
		return key, t[key]
	end
	-- no more value to return, cleanup
	t.__orderedIndex = nil
	return
end
function orderedPairs(t)
	-- Equivalent of the pairs() function on tables. Allows to iterate
	-- in order
	return orderedNext, t, nil
end
-- deepcopy; thanx to http://snippets.luacode.org/snippets/Deep_copy_of_a_Lua_Table_2
function deepcopy(t)
	if type(t) ~= 'table' then return t end
	--local mt = getmetatable(t)
	local res = {}
	for k,v in pairs(t) do
		if type(v) == 'table' then
			v = deepcopy(v)
		end
		res[k] = v
	end
	--setmetatable(res,mt) --
	return res
end
