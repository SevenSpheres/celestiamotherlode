-- CelPadFinder.lua

celestia:log("CelPad: loading finder")

tCelPadFinder = {
sysLog = {
};
runningFinders = {};
runningLogs = {};
refMarked = {
celObj = {};
};
queryfnc = {
main = {
qr001_distance = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local object = finder.tmpResSet[indexnum]
	local fixpos = finder.fixpos
	local obs, obs_pos
	if fixpos then
		obs_pos = fixpos
	else
		obs = observer
		obs_pos = obs:getposition()
	end
	local lcVal=obs_pos:distanceto(object:getposition(celestia:gettime()))
	if (lcVal >= finder.queryVal.qr001_distance.minv and lcVal <= finder.queryVal.qr001_distance.maxv)  then
		t_ins(finder.resultSet,finder.tmpResSet[indexnum])
	end;
end;
qr012_catalogNumber = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().catalogNumber
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr012_catalogNumber.minv and lcVal <= finder.queryVal.qr012_catalogNumber.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr002_name_str = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:name()
	local condition
	if finder.queryVal.qr002_name_str == "" then
		condition = (finder.tmpResSet[indexnum]:name()=="")
	else
		condition = string.find(lcVal,finder.queryVal.qr002_name_str)
	end;
	if condition then
		if not negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end
	end;
end;
qr005_radius = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().radius
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr005_radius.minv and lcVal <= finder.queryVal.qr005_radius.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr100_dso_radius = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().radius
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr100_dso_radius.minv and lcVal <= finder.queryVal.qr100_dso_radius.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr007_temperature = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().temperature
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr007_temperature.minv and lcVal <= finder.queryVal.qr007_temperature.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr006_luminosity = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().luminosity
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr006_luminosity.minv and lcVal <= finder.queryVal.qr006_luminosity.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr008_absoluteMagnitude = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().absoluteMagnitude
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr008_absoluteMagnitude.minv and lcVal <= finder.queryVal.qr008_absoluteMagnitude.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr009_bolometricMagnitude = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().bolometricMagnitude
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr009_bolometricMagnitude.minv and lcVal <= finder.queryVal.qr009_bolometricMagnitude.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr004_stellarClass_str = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:getinfo().stellarClass
	local inclnils = finder.nils
	local condition
	if finder.queryVal.qr004_stellarClass_str == "" then
		condition = (lcVal=="")
	else
		condition = string.find(lcVal,finder.queryVal.qr004_stellarClass_str)
	end;
	if lcVal then
		if condition then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr003_stellarClass = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local inclnils = finder.nils
	local lcVal = finder.tmpResSet[indexnum]:getinfo().stellarClass
	if lcVal then
		lcVal = string.sub(finder.tmpResSet[indexnum]:getinfo().stellarClass,1,1)
		for i in string.gmatch(finder.queryVal.qr003_stellarClass.mcstr, "%a+") do
			if lcVal == i then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end
end;
qr030_numPlanets = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local inclnils = finder.nils
	local lcVal = #finder.tmpResSet[indexnum]:getchildren()
	if lcVal then
		if (lcVal >= finder.queryVal.qr030_numPlanets.minv and lcVal <= finder.queryVal.qr030_numPlanets.maxv) then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr999_isVisible = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:visible()
	local inclnils = finder.nils
	if lcVal == nil then
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if finder.queryVal.qr999_isVisible then
			if lcVal  then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if not lcVal then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	end;
end;
qr017_type_str = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:getinfo().type
	local condition
	if finder.queryVal.qr017_type_str == "" then
		condition = (lcVal=="")
	else
		condition = string.find(lcVal,finder.queryVal.qr017_type_str)
	end;
	if condition then
		if not negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr016_type = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local inclnils = finder.nils
	local lcVal = finder.tmpResSet[indexnum]:getinfo().type
	if lcVal then
		for i in string.gmatch(finder.queryVal.qr016_type.mcstr, "%a+") do
			if lcVal == i then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr028_rotationPeriod = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().rotationPeriod
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr028_rotationPeriod.minv and lcVal <= finder.queryVal.qr028_rotationPeriod.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr029_orbitPeriod = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().orbitPeriod
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr029_orbitPeriod.minv and lcVal <= finder.queryVal.qr029_orbitPeriod.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr018_oblateness = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().oblateness
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr018_oblateness.minv and lcVal <= finder.queryVal.qr018_oblateness.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr019_albedo = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().albedo
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr019_albedo.minv and lcVal <= finder.queryVal.qr019_albedo.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr020_lifespanStart = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().lifespanStart
	local inclnils = finder.nils
	local negator = finder.negatepointer
	if lcVal then
		if (lcVal >= finder.queryVal.qr020_lifespanStart.minv and lcVal <= finder.queryVal.qr020_lifespanStart.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr021_lifespanEnd = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().lifespanEnd
	local inclnils = finder.nils
	local negator = finder.negatepointer
	if lcVal then
		if (lcVal >= finder.queryVal.qr021_lifespanEnd.minv and lcVal <= finder.queryVal.qr021_lifespanEnd.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr022_atmosphereHeight = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().atmosphereHeight
	local inclnils = finder.nils
	local negator = finder.negatepointer
	if lcVal then
		if (lcVal >= finder.queryVal.qr022_atmosphereHeight.minv and lcVal <= finder.queryVal.qr022_atmosphereHeight.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr023_atmosphereCloudHeight = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().atmosphereCloudHeight
	local inclnils = finder.nils
	local negator = finder.negatepointer
	if lcVal then
		if (lcVal >= finder.queryVal.qr023_atmosphereCloudHeight.minv and lcVal <= finder.queryVal.qr023_atmosphereCloudHeight.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr024_atmosphereCloudSpeed = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().atmosphereCloudSpeed
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr024_atmosphereCloudSpeed.minv and lcVal <= finder.queryVal.qr024_atmosphereCloudSpeed.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr300_parent_str = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local inclnils = finder.nils
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:getinfo().parent
	if lcVal then
		lcVal = lcVal:name();
	else
		lcVal = "";
	end;
	if finder.queryVal.qr300_parent_str == "" then
		condition = (lcVal=="")
	else
		condition = string.find(lcVal,finder.queryVal.qr300_parent_str)
	end;
	if condition then
		if not negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end
	end;
end;
qr101_hubbleType = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local inclnils = finder.nils
	local lcVal = finder.tmpResSet[indexnum]:getinfo().hubbleType
	if lcVal then
		for i in string.gmatch(finder.queryVal.qr101_hubbleType.mcstr, "%w+") do
			if lcVal == i then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr102_hubbleType_str = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:getinfo().hubbleType
	local condition
	local inclnils = finder.nils
	if not lcVal then
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if finder.queryVal.qr102_hubbleType_str == "" then
			condition = (lcVal=="")
		else
			condition = string.find(lcVal,finder.queryVal.qr102_hubbleType_str)
		end;
		if condition then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	end;
end;
qr026_hasRings = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().hasRings
	local inclnils = finder.nils
	if lcVal == nil then
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if finder.queryVal.qr026_hasRings then
			if lcVal  then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if not lcVal then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	end;
end;
qr027_mass = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().mass
	local negator = finder.negatepointer;
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr027_mass.minv and lcVal <= finder.queryVal.qr027_mass.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr302_infoURL = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local inclnils = finder.nils
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:getinfo().infoURL
	if lcVal then
		local condition
		if finder.queryVal.qr302_infoURL == "" then
			condition = (lcVal=="")
		else
			condition = string.find(lcVal,finder.queryVal.qr302_infoURL)
		end;
		if condition then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
q23_rotationOffset = function(o)
end;
q24_rotationEpoch = function(o)
end;
q25_rotationAscendingNode = function(o)
end;
q26_rotationPrecessionRate = function(o)
end;
qr025_Locations = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local locsnum = locsnum
	local lcVal = locsnum(finder.tmpResSet[indexnum])
	if (lcVal >= finder.queryVal.qr025_Locations.minv and lcVal <= finder.queryVal.qr025_Locations.maxv) then
		if not negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if negator then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end
end;
qr202_size = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().size
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr202_size.minv and lcVal <= finder.queryVal.qr202_size.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr203_importance = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = finder.tmpResSet[indexnum]:getinfo().importance
	local negator = finder.negatepointer
	local inclnils = finder.nils
	if lcVal then
		if (lcVal >= finder.queryVal.qr203_importance.minv and lcVal <= finder.queryVal.qr203_importance.maxv)  then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr200_featureType = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local inclnils = finder.nils
	local lcVal = finder.tmpResSet[indexnum]:getinfo().featureType
	if lcVal then
		for i in string.gmatch(finder.queryVal.qr200_featureType.mcstr, "%w+") do
			if lcVal == i then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	else
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	end;
end;
qr201_featureType_str = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local negator = finder.negatepointer
	local lcVal = finder.tmpResSet[indexnum]:getinfo().featureType
	local condition
	local inclnils = finder.nils
	if not lcVal then
		if inclnils then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end;
	else
		if finder.queryVal.qr201_featureType_str == "" then
			condition = (lcVal=="")
		else
			condition = string.find(lcVal,finder.queryVal.qr201_featureType_str)
		end;
		if condition then
			if not negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		else
			if negator then
				t_ins(finder.resultSet,finder.tmpResSet[indexnum])
			end;
		end;
	end;
end;
q_dummy = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	t_ins(finder.resultSet,finder.tmpResSet[indexnum])
end;
sum_num = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local task = finder.taskself
	local getval
	if task ~= "dsoradius" then
		getval = task
	else
		getval = "radius";
	end;
	o.sumtab = finder.SUM.summary;
	local celobj = finder.resultSet[indexnum]
	local lcVal = celobj:getinfo()[getval]
	o.nilsn = o.nilsn or 0
	o.isdata = o.isdata or false;
	if lcVal and type(lcVal)=="number" then
		if lcVal ~= 0 and lcVal ~= -1 then
			o.isdata = true
			local objnm
			local parent = celobj:getinfo().parent
			if parent then
				objnm = celobj:getinfo().type..":"..parent:name().."/"..celobj:name()
			else
				objnm = celobj:getinfo().type..":"..celobj:name()
			end;
			if lcVal <= o.sumtab[task].minn then
				if lcVal < o.sumtab[task].minn then
					o.sumtab[task].mnnamef = objnm
				end;
				o.sumtab[task].minn = lcVal
				if lcVal == o.sumtab[task].minn then
					o.sumtab[task].mnnamel = objnm
				end;
			end;
			if  lcVal >= o.sumtab[task].maxn then
				if lcVal > o.sumtab[task].maxn then
					o.sumtab[task].mxnamef = objnm
				end;
				o.sumtab[task].maxn = lcVal
				if lcVal == o.sumtab[task].maxn then
					o.sumtab[task].mxnamel = objnm
				end;
			end;
		else
			o.sumtab[task].extval[lcVal] = o.sumtab[task].extval[lcVal] or 0;
			o.sumtab[task].extval[lcVal] = o.sumtab[task].extval[lcVal] + 1;
		end
	else
		o.nilsn = o.nilsn + 1
	end;
end;
sum_mch = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local task = finder.taskself
	o.sumtab = finder.SUM.summary;
	o.nilsn = o.nilsn or 0
	o.isdata = o.isdata or false;
	local celobj = finder.resultSet[indexnum]
	local lcVal = celobj:getinfo()[task] or "no data"
	o.sumtab[task].mval[lcVal] = o.sumtab[task].mval[lcVal] or 0
	o.sumtab[task].mval[lcVal] = o.sumtab[task].mval[lcVal] + 1
	if lcVal == "no data" then
		o.nilsn = o.nilsn + 1
	else
		o.isdata = true
	end;
end;
sum_bool = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local task = finder.taskself
	o.sumtab = finder.SUM.summary;
	o.nilsn = o.nilsn or 0
	o.isdata = o.isdata or false;
	local celobj = finder.resultSet[indexnum]
	local lcVal
	if task == "hasRings" then
		lcVal = celobj:getinfo()[task]
	elseif task == "visible" then
		lcVal = celobj:visible()
	end;
	if lcVal ~= nil then
		o.isdata = true;
		if lcVal == true then
			o.sumtab[task].bool["true"] = o.sumtab[task].bool["true"] or 0
			o.sumtab[task].bool["true"] = o.sumtab[task].bool["true"] + 1
		elseif lcVal == false then
			o.sumtab[task].bool["false"] = o.sumtab[task].bool["false"] or 0
			o.sumtab[task].bool["false"] = o.sumtab[task].bool["false"] + 1
		end
	else
		o.nilsn = o.nilsn + 1
		o.sumtab[task].bool["no data"] = o.sumtab[task].bool["no data"] or 0
		o.sumtab[task].bool["no data"] = o.sumtab[task].bool["no data"] + 1
	end;
end;
iterators = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local task = finder.taskself
	local locsnum = locsnum
	o.sumtab = finder.SUM.summary;
	o.isdata = o.isdata or false;
	local celobj = finder.resultSet[indexnum]
	local lcVal
	if task == "locations" then
		lcVal =  locsnum(celobj)
	elseif task == "getchildren" then
		lcVal =  #celobj:getchildren()
	end;
	local objnm
	local parent = celobj:getinfo().parent
	if parent then
		objnm = celobj:getinfo().type..":"..parent:name().."/"..celobj:name()
	else
		objnm = celobj:getinfo().type..":"..celobj:name()
	end;
	if lcVal and type(lcVal)=="number" then
		o.isdata = true;
		if lcVal>0 then
			if lcVal <= o.sumtab[task].minn then
				if lcVal < o.sumtab[task].minn then
					o.sumtab[task].mnnamef = objnm
				end;
				o.sumtab[task].minn = lcVal
				if lcVal == o.sumtab[task].minn then
					o.sumtab[task].mnnamel = objnm
				end;
			end;
			if lcVal >= o.sumtab[task].maxn then
				if lcVal > o.sumtab[task].maxn then
					o.sumtab[task].mxnamef = objnm
				end;
				o.sumtab[task].maxn = lcVal
				if lcVal == o.sumtab[task].maxn then
					o.sumtab[task].mxnamel = objnm
				end;
			end;
		else
			o.sumtab[task].extval[lcVal] = o.sumtab[task].extval[lcVal] or 0;
			o.sumtab[task].extval[lcVal] = o.sumtab[task].extval[lcVal] + 1;
		end
	end;
end;
lifespan = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local task = finder.taskself
	o.sumtab = finder.SUM.summary;
	local celobj = finder.resultSet[indexnum]
	local lcVal = celobj:getinfo()[task]
	local parent = celobj:getinfo().parent
	if parent then
		objnm = celobj:getinfo().type..":"..parent:name().."/"..celobj:name()
	else
		objnm = celobj:getinfo().type..":"..celobj:name()
	end;
	o.nilsn = o.nilsn or 0
	o.isdata = o.isdata or false;
	if lcVal and type(lcVal)=="number" then
		if (lcVal > -math.huge and lcVal < math.huge) then
			o.isdata = true
			if o.sumtab[task].minn >= lcVal then
				if o.sumtab[task].minn > lcVal then
					o.sumtab[task].mnnamef = objnm
				end;
				o.sumtab[task].minn = lcVal
				if lcVal == o.sumtab[task].minn then
					o.sumtab[task].mnnamel = objnm
				end;
			end;
			if o.sumtab[task].maxn <= lcVal then
				if o.sumtab[task].maxn < lcVal then
					o.sumtab[task].mxnamef = objnm
				end;
				o.sumtab[task].maxn = lcVal
				if lcVal == o.sumtab[task].maxn then
					o.sumtab[task].mxnamel = objnm
				end;
			end;
		else
			o.sumtab[task].extval[lcVal] = o.sumtab[task].extval[lcVal] or 0;
			o.sumtab[task].extval[lcVal] = o.sumtab[task].extval[lcVal] + 1;
		end
	else
		o.nilsn = o.nilsn + 1
	end;
end;
z_has_bodies = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local lcVal = #finder.tmpResSet[indexnum]:getchildren()
	if lcVal then
		if lcVal > 0 then
			t_ins(finder.resultSet,finder.tmpResSet[indexnum])
		end
	end;
end;
z_get_bodies = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1;
	local object = finder.tmpResSet[indexnum]
	o.lobject = object
	finder:getBodiesTask(object)
end;
z_get_locations = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local object = finder.tmpResSet[indexnum]
	o.lobject = object
	finder:getLocationsTask(object)
end;
z_transfer_objects = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik;
	local finder = o.finderpnt1;
	o.oobjkey = next(finder.tmpObjects,o.oldkey)
	o.oldkey = o.oobjkey
	o.obj = finder.tmpObjects[o.oobjkey]
	table.insert(finder.resultSet,o.obj);
end;
z_get_parents = function(o)
	o.ik = o.ik or 0;
	o.ik = o.ik + 1;
	local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
	local object = finder.tmpResSet[indexnum]
	o.lobject = object
	local oparent = object:getinfo().parent
	if oparent then
		local pname = oparent:name()
		finder.tmpObjects[pname] = oparent
	end;
end;
z_postprocess = function(o)
	local finder = o.finderpnt1;
	local parstab = finder.postProc.parsers
	o.ik = o.ik or 0;
	if #parstab == 0 then
		if o.ik < #finder.tmpResSet then
		o.ik = o.ik + 1;
			local indexnum = o.ik;
			local ptype = finder.postProc.ptype
			local object = finder.tmpResSet[indexnum]
			o.lobject = object
			if ptype == 1 then
				finder:getBodiesTask(object)
			elseif ptype == 2 then
				finder:getLocationsTask(object)
			end;
		end;
	end;
end;
};
xit = {
z_transfer_objects = function(o)
	local finder = o.finderpnt1;
	return (not o.oobjkey)
end;
z_postprocess = function(o)
	return (((o.ik >= #o.finderpnt1.tmpResSet) and #o.finderpnt1.postProc.parsers == 0) or not o.ik)
end;
};
quit = {
z_get_objects = function(o)
	local finder = o.finderpnt1
	local table_num = table_num
	local numres = table_num(finder.tmpObjects)
	local numpost = #finder.postProc.tab
	if o.cancelrq then
		CPlog("stage "..tostring(finder.tasknum).." cancelled",0,finder.sysLog)
		if finder.niling ~= "tmpObjects" then
			nilTmpObj(finder,"tmpObjects")
		end;
		finder.postProc.tab = nil;
		finder.postProc.tab = {};
		finder.resultSet = finder.tmpResSet;
		finder.tmpResSet = nil;
		finder.tasktab.status[finder.tasknum]=3;
	else
		if numres ~= 0 or numpost ~= 0 then
			if numpost ~= 0 then
				CPlog("stage "..finder.tasknum.."; "..numpost.." objects cached for postprocess",0,finder.sysLog)
				finder.postproc = finder.tasknum;
				nilStatLogs(finder)
			else
				CPlog("stage "..finder.tasknum.."; no postprocess, ready for transfer",0,finder.sysLog)
				finder.transfer = finder.tasknum;
			end;
		else
			if not finder.closing then
				finder.RetainSetMSG = PopMessage:new({finder.oriframe.popupMenus});
				finder.RetainSetMSG:init(finder.oriframe,"RetainSetMSG",centX(finder.oriframe),centY(finder.oriframe),nil,nil,nil,"yn",
				function()
					CPlog("latest result set retained; "..#finder.tmpResSet.." objects",0,finder.sysLog)
					finder.resultSet=finder.tmpResSet;
					finder.tmpResSet = nil;
					returnView(finder)
					finder.tasktab.nextTask[finder.tasknum+1]=0
					finder.tasktab.status[finder.tasknum]=3;
				end,
				function()
					if finder.niling ~= "tmpResSet" then
						nilResSet(finder,"tmpResSet")
						CPlog("original result set cleared",0,finder.sysLog)
					else
						if finder.alrtlogs then
							CPlog("!!! alert: post-retain tmpResSet cleanup running",0,finder.sysLog)
						end
					end;
					finder.resultSet = nil;
					finder.resultSet = {
					};
					nilStatLogs(finder)
					returnView(finder)
					finder.tasktab.nextTask[finder.tasknum+1]=0
					finder.tasktab.status[finder.tasknum]=3;
				end
				);
				finder.RetainSetMSG:makeBranch(finder);
			end;
			CPlog("stage "..finder.tasknum.." returned "..numres.." objects, remaining tasks aborted...",0,finder.sysLog)
		end;
	end;
	if finder.tmscl then
		celestia:settimescale(finder.tmscl)
		finder.tmscl = nil
	end
	if finder.oldDdup then
		finder.posDed = finder.oldDdup
		finder.oldDdup = nil;
	end;
	if finder.dupNum then
		CPlog("stage "..finder.tasknum.." found "..finder.dupNum.." redundant objects in position deduplication",0,finder.sysLog)
		finder.dupNum = 0;
	end
	finder.stage2parser = nil;
end;
z_postprocess = function(o)
	local finder = o.finderpnt1
		if o.cancelrq then
			CPlog("stage "..finder.tasknum.."; postprocess cancelled",0,finder.sysLog)
			if finder.niling ~= "tmpObjects" then
				nilTmpObj(finder,"tmpObjects")
			else
				if finder.alrtlogs then
					CPlog("!!! alert: post-transfer tmpObjects cleanup running",0,finder.sysLog)
				end
			end;
			finder.resultSet = finder.tmpResSet;
			finder.tmpResSet = nil;
			finder.tasktab.status[finder.tasknum]=3;
		else
			finder.tasktab.status[finder.tasknum]=2;
			finder.transfer = finder.postproc;
			nilStatLogs(finder)
		end
	if finder.tmscl then
	celestia:settimescale(finder.tmscl)
	finder.tmscl = nil
	end
	if finder.oldDdup then
		finder.posDed = finder.oldDdup
		finder.oldDdup = nil;
	end;
	if finder.dupNum then
		CPlog("stage "..finder.tasknum.." found "..finder.dupNum.." redundant objects in position deduplication",0,finder.sysLog)
		finder.dupNum = 0;
	end
		finder.postproc = nil;
end;
z_transfer_objects = function(o)
	local finder = o.finderpnt1
	local exstat = "";
	if o.cancelrq then
		exstat = "cancelled";
	else
		exstat = "finished";
	end;
	CPlog("stage "..finder.tasknum.."; transfer "..exstat.."; ",0,finder.sysLog,finder.statlogx2[finder.tasknum])
	if finder.niling ~= "tmpObjects" then
		nilTmpObj(finder,"tmpObjects")
	else
		if finder.alrtlogs then
			CPlog("!!! alert: post-transfer tmpObjects cleanup running",0,finder.sysLog)
		end
	end;
	finder.transfer = nil
	finder.tasktab.status[finder.tasknum]=3;
end;
};
loop = {
z_get_objects = function(o)
	local finder = o.finderpnt1
	if finder.verblogs then
		finder.statparlog = finder.statparlog or {};
		finder.statparlog[finder.tasknum] = finder.statparlog[finder.tasknum] or #finder.sysLog+1;
		CPlog("getting objects stage "..finder.tasknum.."; scanned object #"..o.ik.."; pack: "..o.maxinloop,0,finder.sysLog,finder.statparlog[finder.tasknum])
	end;
end;
z_transfer_objects = function(o)
	local finder = o.finderpnt1
	if finder.tmpResSet and finder.verblogs then
		finder.statlogx2 = finder.statlogx2 or {};
		finder.statlogx2[finder.tasknum] = finder.statlogx2[finder.tasknum] or #finder.sysLog+1;
		CPlog("stage "..finder.tasknum.."; transferred object #"..(o.ik-1).."; pack: "..o.maxinloop,0,finder.sysLog,finder.statlogx2[finder.tasknum])
	end;
end;
sum_mch	= function(o)
	local finder = o.finderpnt1
	local sumtab = o.sumtab
	local srctab = finder.SUM.srctab
	local task = finder.taskself
	local indexnum = o.ik;
	local qtask = finder.rndtabAtr[task]
	local delim = srctab.data.argTbl[srctab.meta.indxTbl[task]].delim[1]
	local equals = srctab.data.argTbl[srctab.meta.indxTbl[task]].equals[1]
	local name = srctab.data.argTbl[srctab.meta.indxTbl[task]].cstname
	local tmpstr = "";
	for q,w in pairs(sumtab[task].mval) do
		tmpstr = tmpstr..q..equals..w..delim.." "
	end;
	finder.statlogsm = finder.statlogsm or {};
	finder.statlogsm[finder.tasknum] = finder.statlogsm[finder.tasknum] or #finder.sysLog+1;
	o.logstr = name..delim.." "..tmpstr
	local logtxt = name..delim.." no data yet..."
	if o.isdata then
		logtxt = o.logstr
	end
	CPlog("summarizing #"..indexnum..delim.." "..o.logstr,0,finder.sysLog,finder.statlogsm[finder.tasknum])
end;
sum_bool = function(o)
	local finder = o.finderpnt1
	local sumtab = o.sumtab
	local srctab = finder.SUM.srctab
	local task = finder.taskself
	local indexnum = o.ik;
	local qtask = finder.rndtabAtr[task]
	local delim = srctab.data.argTbl[srctab.meta.indxTbl[task]].delim[1]
	local equals = srctab.data.argTbl[srctab.meta.indxTbl[task]].equals[1]
	local name = srctab.data.argTbl[srctab.meta.indxTbl[task]].cstname
	local tmpstr = "";
	for q,w in pairs(sumtab[task].bool) do
		tmpstr = tmpstr..q..equals..w..delim.." "
	end;
	finder.statlogsm = finder.statlogsm or {};
	finder.statlogsm[finder.tasknum] = finder.statlogsm[finder.tasknum] or #finder.sysLog+1;
	o.logstr = name..delim.." "..tmpstr
	local logtxt = name..delim.." no data yet..."
	if o.isdata then
		logtxt = o.logstr
	end
	CPlog("summarizing #"..indexnum..delim.." "..o.logstr,0,finder.sysLog,finder.statlogsm[finder.tasknum])
end;
};
};
loopCoef = {
z_get_bodies = 0.1;
z_get_locations = 0.1;
z_transfer_objects = 0.1;
sum_num = 0.5;
nilobj = 0.1;
};
};
syslogInit(tCelPadFinder.sysLog)
CelPadScanner = CClass {
classname = "CelPadScanner";
superclass = CPObject;
init = function (this, objname, header)
	this.Header = header or this.Header or "unnamed";
	this.objname = objname;
	this:updGlobVars();
	this.tCelPadFinder = tCelPadFinder;
	this.numOfStars   = celestia:getstarcount()
	this.numOfDsos   = celestia:getdsocount()
	this.active = true;
	this.findertype = 1
	this.runningTask = 0;
	this.scanType = 0;
	this.sobject = 0;
	this.maxinloop = 1;
	this.resultSet = {
	};
	this.sysLog = {};
	syslogInit(this.sysLog);
	this.tmpResSet = {};
	this.postProc = {
	tab = {};
	parsers = {};
	ptype = 0;
	postPrLim = postProcLimit;
	};
	this:init_query();
	this:init_allattr();
	this:init_units();
	this:init_view();
	this:init_sum();
	if fastCleanup then
		this:init_nilid()
	end
	this.tasktab = {
	status = {};
	nextTask = {};
	};
	this.openQueries = {};
	CPlog("scanner initialized",0,this.sysLog);
	CPlog(tostring(this.numOfStars).." stars",0,this.sysLog);
	CPlog(tostring(this.numOfDsos).." deep space objects",0,this.sysLog);
	CPlog("### right click on top bar for scanner menu",0,this.sysLog);
end;
init_query = function(this)
	local deepcopy = deepcopy
	this.queryStars  = deepcopy(templates.query.queryStars);
	this.queryPlanets = deepcopy(templates.query.queryPlanets);
	this.queryDsos = deepcopy(templates.query.queryDsos);
	this.queryLocations = deepcopy(templates.query.queryLocations);
	this.metaQueryStars = {
	qtype = "stars";
	q_dummy = deepcopy(templates.metaQuery.q_dummy);
	qr001_distance = deepcopy(templates.metaQuery.qr001_distance);
	qr002_name_str = deepcopy(templates.metaQuery.qr002_name_str);
	qr003_stellarClass = deepcopy(templates.metaQuery.qr003_stellarClass);
	qr004_stellarClass_str = deepcopy(templates.metaQuery.qr004_stellarClass_str);
	qr005_radius = deepcopy(templates.metaQuery.qr005_radius);
	qr006_luminosity = deepcopy(templates.metaQuery.qr006_luminosity);
	qr007_temperature = deepcopy(templates.metaQuery.qr007_temperature);
	qr008_absoluteMagnitude = deepcopy(templates.metaQuery.qr008_absoluteMagnitude);
	qr009_bolometricMagnitude = deepcopy(templates.metaQuery.qr009_bolometricMagnitude);
	qr012_catalogNumber = deepcopy(templates.metaQuery.qr012_catalogNumber);
	qr017_type_str = deepcopy(templates.metaQuery.qr017_type_str);
	qr028_rotationPeriod = deepcopy(templates.metaQuery.qr028_rotationPeriod);
	qr029_orbitPeriod = deepcopy(templates.metaQuery.qr029_orbitPeriod);
	qr030_numPlanets = deepcopy(templates.metaQuery.qr030_numPlanets);
	qr300_parent_str = deepcopy(templates.metaQuery.qr300_parent_str);
	z_get_bodies = deepcopy(templates.metaQuery.z_get_bodies);
	z_get_parents = deepcopy(templates.metaQuery.z_get_parents);
	z_transfer_parents = deepcopy(templates.metaQuery.z_transfer_parents);
	zz1_scan_fixpos = deepcopy(templates.metaQuery.zz1_scan_fixpos);
	zz1_scan_pure = deepcopy(templates.metaQuery.zz1_scan_pure);
	zz1_scan_within = deepcopy(templates.metaQuery.zz1_scan_within);
	z_postprocess = deepcopy(templates.metaQuery.z_postprocess);
	};
	this.metaQueryPlanets = {
	qtype = "satellites";
	q_dummy = deepcopy(templates.metaQuery.q_dummy);
	qr001_distance = deepcopy(templates.metaQuery.qr001_distance);
	qr002_name_str = deepcopy(templates.metaQuery.qr002_name_str);
	qr005_radius = deepcopy(templates.metaQuery.qr005_radius);
	qr016_type = deepcopy(templates.metaQuery.qr016_type);
	qr017_type_str = deepcopy(templates.metaQuery.qr017_type_str);
	qr018_oblateness = deepcopy(templates.metaQuery.qr018_oblateness);
	qr019_albedo = deepcopy(templates.metaQuery.qr019_albedo);
	qr020_lifespanStart = deepcopy(templates.metaQuery.qr020_lifespanStart);
	qr021_lifespanEnd = deepcopy(templates.metaQuery.qr021_lifespanEnd);
	qr022_atmosphereHeight = deepcopy(templates.metaQuery.qr022_atmosphereHeight);
	qr023_atmosphereCloudHeight = deepcopy(templates.metaQuery.qr023_atmosphereCloudHeight);
	qr024_atmosphereCloudSpeed = deepcopy(templates.metaQuery.qr024_atmosphereCloudSpeed);
	qr025_Locations = deepcopy(templates.metaQuery.qr025_Locations);
	qr026_hasRings = deepcopy(templates.metaQuery.qr026_hasRings);
	-- qr027_mass = deepcopy(templates.metaQuery.qr027_mass);
	qr028_rotationPeriod = deepcopy(templates.metaQuery.qr028_rotationPeriod);
	qr029_orbitPeriod = deepcopy(templates.metaQuery.qr029_orbitPeriod);
	qr030_numPlanets = deepcopy(templates.metaQuery.qr030_numPlanets);
	qr300_parent_str = deepcopy(templates.metaQuery.qr300_parent_str);
	qr302_infoURL = deepcopy(templates.metaQuery.qr302_infoURL);
	qr999_isVisible = deepcopy(templates.metaQuery.qr999_isVisible);
	z_has_bodies = deepcopy(templates.metaQuery.z_has_bodies);
	z_get_bodies = deepcopy(templates.metaQuery.z_get_bodies);
	z_get_locations = deepcopy(templates.metaQuery.z_get_locations);
	z_get_parents = deepcopy(templates.metaQuery.z_get_parents);
	z_transfer_bodies = deepcopy(templates.metaQuery.z_transfer_bodies);
	z_transfer_objects = deepcopy(templates.metaQuery.z_transfer_objects);
	z_transfer_parents = deepcopy(templates.metaQuery.z_transfer_parents);
	zz1_scan_fixpos = deepcopy(templates.metaQuery.zz1_scan_fixpos);
	zz1_scan_pure = deepcopy(templates.metaQuery.zz1_scan_pure);
	zz1_scan_within = deepcopy(templates.metaQuery.zz1_scan_within);
	z_postprocess = deepcopy(templates.metaQuery.z_postprocess);
	};
	this.metaQueryDsos = {
	qtype = "dsos";
	q_dummy = deepcopy(templates.metaQuery.q_dummy);
	qr001_distance = deepcopy(templates.metaQuery.qr001_distance);
	qr002_name_str = deepcopy(templates.metaQuery.qr002_name_str);
	qr008_absoluteMagnitude = deepcopy(templates.metaQuery.qr008_absoluteMagnitude);
	qr016_type = deepcopy(templates.metaQuery.qr016_type);
	qr017_type_str = deepcopy(templates.metaQuery.qr017_type_str);
	qr100_dso_radius = deepcopy(templates.metaQuery.qr100_dso_radius);
	qr101_hubbleType = deepcopy(templates.metaQuery.qr101_hubbleType);
	qr102_hubbleType_str = deepcopy(templates.metaQuery.qr102_hubbleType_str);
	qr999_isVisible = deepcopy(templates.metaQuery.qr999_isVisible);
	zz1_scan_fixpos = deepcopy(templates.metaQuery.zz1_scan_fixpos);
	zz1_scan_pure = deepcopy(templates.metaQuery.zz1_scan_pure);
	zz1_scan_within = deepcopy(templates.metaQuery.zz1_scan_within);
	z_postprocess = deepcopy(templates.metaQuery.z_postprocess);
	};
	this.metaQueryLocations = {
	qtype = "locations";
	q_dummy = deepcopy(templates.metaQuery.q_dummy);
	qr001_distance = deepcopy(templates.metaQuery.qr001_distance);
	qr002_name_str = deepcopy(templates.metaQuery.qr002_name_str);
	qr200_featureType = deepcopy(templates.metaQuery.qr200_featureType);
	qr201_featureType_str = deepcopy(templates.metaQuery.qr201_featureType_str);
	qr202_size = deepcopy(templates.metaQuery.qr202_size);
	qr203_importance = deepcopy(templates.metaQuery.qr203_importance);
	qr300_parent_str = deepcopy(templates.metaQuery.qr300_parent_str);
	qr302_infoURL = deepcopy(templates.metaQuery.qr302_infoURL);
	z_has_bodies = deepcopy(templates.metaQuery.z_has_bodies);
	z_get_bodies = deepcopy(templates.metaQuery.z_get_bodies);
	z_get_locations = deepcopy(templates.metaQuery.z_get_locations);
	z_transfer_locations = deepcopy(templates.metaQuery.z_transfer_locations);
	z_transfer_objects = deepcopy(templates.metaQuery.z_transfer_objects);
	zz1_scan_fixpos = deepcopy(templates.metaQuery.zz1_scan_fixpos);
	zz1_scan_pure = deepcopy(templates.metaQuery.zz1_scan_pure);
	zz1_scan_within = deepcopy(templates.metaQuery.zz1_scan_within);
	z_postprocess = deepcopy(templates.metaQuery.z_postprocess);
	};
	tCelPadFinder.queryfnc.loop["z_get_bodies"] = tCelPadFinder.queryfnc.loop.z_get_objects
	tCelPadFinder.queryfnc.quit["z_get_bodies"] = tCelPadFinder.queryfnc.quit.z_get_objects
	tCelPadFinder.queryfnc.loop["z_get_parents"] = tCelPadFinder.queryfnc.loop.z_get_objects
	tCelPadFinder.queryfnc.quit["z_get_parents"] = tCelPadFinder.queryfnc.quit.z_get_objects
	tCelPadFinder.queryfnc.loop["z_get_locations"] = tCelPadFinder.queryfnc.loop.z_get_objects
	tCelPadFinder.queryfnc.quit["z_get_locations"] = tCelPadFinder.queryfnc.quit.z_get_objects
	tCelPadFinder.queryfnc.xit["z_transfer_bodies"] = tCelPadFinder.queryfnc.xit.z_transfer_objects
	tCelPadFinder.queryfnc.quit["z_transfer_bodies"] = tCelPadFinder.queryfnc.quit.z_transfer_objects
	tCelPadFinder.queryfnc.loop["z_transfer_bodies"] = tCelPadFinder.queryfnc.loop.z_transfer_objects
	tCelPadFinder.queryfnc.xit["z_transfer_parents"] = tCelPadFinder.queryfnc.xit.z_transfer_objects
	tCelPadFinder.queryfnc.quit["z_transfer_parents"] = tCelPadFinder.queryfnc.quit.z_transfer_objects
	tCelPadFinder.queryfnc.loop["z_transfer_parents"] = tCelPadFinder.queryfnc.loop.z_transfer_objects
	tCelPadFinder.queryfnc.xit["z_transfer_locations"] = tCelPadFinder.queryfnc.xit.z_transfer_objects
	tCelPadFinder.queryfnc.quit["z_transfer_locations"] = tCelPadFinder.queryfnc.quit.z_transfer_objects
	tCelPadFinder.queryfnc.loop["z_transfer_locations"] = tCelPadFinder.queryfnc.loop.z_transfer_objects
	tCelPadFinder.queryfnc.loop["z_postprocess"] = tCelPadFinder.queryfnc.loop.z_get_objects
	this.minMaxMeta = {};
	local tabstr = "metaQueryStars metaQueryPlanets metaQueryDsos metaQueryLocations";
	local intabproc = function(i,intab)
		for t,y in pairs(intab) do
			for d = 3,6,2 do
				if this[i][t] then
					this[i][t][d] = deepcopy(intab[t].minv)
					this[i][t][d+1] = deepcopy(intab[t].maxv)
				end
			end;
			if this[i][t] then
				this.minMaxMeta[t] = {};
				for j = 1,2 do
					this.minMaxMeta[t][j] = this[i][t][j]
				end;
			end;
		end;
	end;
	this.minMaxUpd = function(this,intab)
		local i = "metaQueryVal";
		intabproc(i,intab);
	end;
	this.minMaxUpdInit = function(this,intab)
		for i in string.gmatch(tabstr,"%w+") do
			intabproc(i,intab);
		end;
	end;
	this.minMaxGet = function(this)
		local outtab = {};
		local i = "metaQueryVal";
			for h,j in pairs(templates.minMaxDefault) do
				if this[i][h] then
					outtab[h] = outtab[h] or {};
					if this[i][h] then
						outtab[h].minv = deepcopy(this[i][h][3])
						outtab[h].maxv = deepcopy(this[i][h][4])
					end;
				end;
			end;
		return outtab;
	end;
	this:minMaxUpdInit(templates.minMaxDefault)
end;
init_allattr = function(this)
	local getsetuphi = getsetuphi
	this.infoPanes = {};
	this.openParDlgs = {};
	this.rndtabAtr = {};
	this.rndtabQr = {};
	this.rndtabNames = {};
	this.srchstr = "";
	this.mcsrchstr = "";
	this.starallattr = {};
	local getsrchstr = function(t,i)
		if type(t[i]) == "table" and t[i].choicelist then
			if not string.find(this.mcsrchstr,tostring(i)) then
				this.mcsrchstr = this.mcsrchstr..tostring(i).." "
			end
		end
		if string.sub(tostring(i),-4)=="_str" then
			if not string.find(this.srchstr,tostring(i)) then
				this.srchstr = this.srchstr..tostring(i).." "
			end
		end
	end;
	for i,v in orderedPairs(this.metaQueryStars) do
		if v.cprop then
			this.rndtabAtr[v.cprop] = i
			this.rndtabQr[i] = v.cprop
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryStars)
			table.insert(this.starallattr,v.cprop)
		else
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryStars)
		end;
		getsrchstr(this.queryStars,i)
	end;
	table.insert(this.starallattr,2,"type")
	this.bodyallattr = {};
	for i,v in orderedPairs(this.metaQueryPlanets) do
		if v.cprop then
			this.rndtabAtr[v.cprop] = i
			this.rndtabQr[i] = v.cprop
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryPlanets)
			table.insert(this.bodyallattr,v.cprop)
		else
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryPlanets)
		end;
		getsrchstr(this.queryPlanets,i)
	end;
	this.dsoallattr = {}
	for i,v in orderedPairs(this.metaQueryDsos) do
		if v.cprop then
			this.rndtabQr[i] = v.cprop
			this.rndtabAtr[v.cprop] = i
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryDsos)
			table.insert(this.dsoallattr,v.cprop)
		else
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryDsos)
		end;
		getsrchstr(this.queryDsos,i)
	end;
	this.locsallattr = {}
	for i,v in orderedPairs(this.metaQueryLocations) do
		if v.cprop then
			this.rndtabQr[i] = v.cprop
			this.rndtabAtr[v.cprop] = i
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryLocations)
			table.insert(this.locsallattr,v.cprop)
		else
			this.rndtabNames[i] = getsetuphi(i,this.metaQueryLocations)
		end;
		getsrchstr(this.queryLocations,i)
	end;
	local totmcstr = ""
	for x,c in ipairs(this.queryStars.qr003_stellarClass[1]) do
		totmcstr = totmcstr..this.queryStars.qr003_stellarClass.choicelist[x].." "
	end;
	this.metaQueryStars.qr003_stellarClass.fullmcstr = totmcstr
	totmcstr = ""
	for x,c in ipairs(this.queryPlanets.qr016_type[1]) do
		totmcstr = totmcstr..this.queryPlanets.qr016_type.choicelist[x].." "
	end;
	this.metaQueryPlanets.qr016_type.fullmcstr = totmcstr
	totmcstr = ""
	for x,c in ipairs(this.queryDsos.qr016_type[1]) do
		totmcstr = totmcstr..this.queryDsos.qr016_type.choicelist[x].." "
	end;
	this.metaQueryDsos.qr016_type.fullmcstr = totmcstr
	totmcstr = ""
	for x,c in ipairs(this.queryDsos.qr101_hubbleType[1]) do
		totmcstr = totmcstr..this.queryDsos.qr101_hubbleType.choicelist[x].." "
	end;
	this.metaQueryDsos.qr101_hubbleType.fullmcstr = totmcstr
	totmcstr = ""
	for x,c in ipairs(this.queryLocations.qr200_featureType[1]) do
		totmcstr = totmcstr..this.queryLocations.qr200_featureType.choicelist[x].." "
	end;
	this.metaQueryLocations.qr200_featureType.fullmcstr = totmcstr
end;
init_units = function(this)
	local deepcopy = deepcopy
	local infTab = {
	};
	infTab["-1,#INF"] = -math.huge
	infTab["1,#INF"] = math.huge
	infTab["-1.#INF"] = -math.huge
	infTab["1.#INF"] = math.huge
	local str_match = string.match
	local math_dround = math_dround
	local s_to = tostring
	local s_find = string.find
	local s_num = tonumber
	this.retv = function(v)
		if s_find(v,"INF") then
			v = infTab[s_to(v)];
		end;
		return s_num(v);
	end;
	local consttab = templates.unitsConst;
	this.unittable = {
	qr001_distance = {
	"", valuelist = {
	function(v,fromto) -- ly
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.ly;
		elseif fromto == "tonative" then
			v = v*consttab.distance.ly;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- km native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- AU
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.AU;
		elseif fromto == "tonative" then
			v = v*consttab.distance.AU;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- pc 3.0857e+13
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.pc;
		elseif fromto == "tonative" then
			v = v*consttab.distance.pc;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- mi 1.609344
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.mi;
		elseif fromto == "tonative" then
			v = v*consttab.distance.mi;
		end;
		return(this.retv(v))
	end;
	}};
	zcmddistance = {
	"", valuelist = {
	function(v,fromto) -- km native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- ly
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.ly;
		elseif fromto == "tonative" then
			v = v*consttab.distance.ly;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- AU
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.AU;
		elseif fromto == "tonative" then
			v = v*consttab.distance.AU;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- pc 3.0857e+13
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.pc;
		elseif fromto == "tonative" then
			v = v*consttab.distance.pc;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- mi 1.609344
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.mi;
		elseif fromto == "tonative" then
			v = v*consttab.distance.mi;
		end;
		return(this.retv(v))
	end;
	}};
	zcmdduration = {
	"", valuelist = {
	function(v,fromto) --seconds -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- min
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.duration.mins;
		elseif fromto == "tonative" then
			v = v*consttab.duration.mins;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- hour
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.duration.hours;
		elseif fromto == "tonative" then
			v = v*consttab.duration.hours;
		end;
		return(this.retv(v))
	end;
	};
	};
	zcmdangle = {
	"", valuelist = {
	function(v,fromto) --radian -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- degrees
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.angle.deg;
		elseif fromto == "tonative" then
			v = v/consttab.angle.deg;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- arcsecs
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.angle.arcsec;
		elseif fromto == "tonative" then
			v = v/consttab.angle.arcsec;
		end;
		return(this.retv(v))
	end;
	};
	};
	zcmdrate = {
	"", valuelist = {
	function(v,fromto) --- rad/s native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) --deg/s
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.angle.deg;
		elseif fromto == "tonative" then
			v = v/consttab.angle.deg;
		end;
		return(this.retv(v))
	end;
	};
	};
	zcmdspeed = {
	"", valuelist = {
	function(v,fromto) -- uly/s native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- ly/s
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.lys;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.lys;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- c
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.c;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.c;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr005_radius = {--stars,planets - km, sol = 696000
	"", valuelist = {
	function(v,fromto) -- KM -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- RSUN
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.radius.RSUN;
		elseif fromto == "tonative" then
			v = v*consttab.radius.RSUN;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) --REARTH
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.radius.REARTH;
		elseif fromto == "tonative" then
			v = v*consttab.radius.REARTH;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) --mi
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.radius.mi;
		elseif fromto == "tonative" then
			v = v*consttab.radius.mi;
		end;
		return(this.retv(v))
	end;
	}};
	qr100_dso_radius = {--dso
	"", valuelist = {
	function(v,fromto) -- ly -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end,
	function(v,fromto) -- pc
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.dso_radius.pc;
		elseif fromto == "tonative" then
			v = v*consttab.dso_radius.pc;
		end;
		return(this.retv(v))
	end,
	function(v,fromto) --km
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.dso_radius.km
		elseif fromto == "tonative" then
			v = v/consttab.dso_radius.km
		end;
		return(this.retv(v))
	end,
	function(v,fromto) --mi --5.87849981e+12
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.dso_radius.mi;
		elseif fromto == "tonative" then
			v = v/consttab.dso_radius.mi;
		end;
		return(this.retv(v))
	end
	}};
	qr007_temperature = {
	"", valuelist = {
	function(v,fromto) -- Kelvin -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- Celsius
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v-consttab.temperature.Cels;
		elseif fromto == "tonative" then
			v = v+consttab.temperature.Cels;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- Fahrenheint
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = 1.8*(v-consttab.temperature.Cels)+32;
		elseif fromto == "tonative" then
			v = ((v-32)/1.8)+consttab.temperature.Cels;
		end;
		return(this.retv(v))
	end;
	}};
	qr006_luminosity = {
	"", valuelist = {
	function(v,fromto) --x Sun -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- gigawatts  3.839e+026 W = 3.839e+020 GW
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.luminosity.GW;
		elseif fromto == "tonative" then
			v = v/consttab.luminosity.GW;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr028_rotationPeriod = {
	"", valuelist = {
	function(v,fromto) --days -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- hours
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.period.hours;
		elseif fromto == "tonative" then
			v = v/consttab.period.hours;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- years
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.period.years;
		elseif fromto == "tonative" then
			v = v*consttab.period.years;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr029_orbitPeriod = {
	"", valuelist = {
	function(v,fromto) --days -native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- hours
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.period.hours;
		elseif fromto == "tonative" then
			v = v/consttab.period.hours;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- years
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.period.years;
		elseif fromto == "tonative" then
			v = v*consttab.period.years;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr022_atmosphereHeight = {
	"", valuelist = {
	function(v,fromto) -- km native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- mi 1.609344
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.mi;
		elseif fromto == "tonative" then
			v = v*consttab.distance.mi;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr023_atmosphereCloudHeight  = {
	"", valuelist = {
	function(v,fromto) -- km native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- mi 1.609344
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v/consttab.distance.mi;
		elseif fromto == "tonative" then
			v = v*consttab.distance.mi;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr024_atmosphereCloudSpeed = {--?? native 1000x m/min
	"", valuelist = {
	function(v,fromto) --m/s?
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.atmspeed.ms
		elseif fromto == "tonative" then
			v = v/consttab.atmspeed.ms
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- km/h?
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.atmspeed.kmh
		elseif fromto == "tonative" then
			v = v/consttab.atmspeed.kmh;
		end;
		return(this.retv(v))
	end;
	function(v,fromto) -- mph?
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.atmspeed.mph
		elseif fromto == "tonative" then
			v = v/consttab.atmspeed.mph;
		end;
		return(this.retv(v))
	end;
	};
	};
	qr020_lifespanStart = {
	"", valuelist = {
	function(v,fromto) --TDB native
		if not v then return "no data"; end;
		return(this.retv(v))
	end;
	function(v,fromto) -- date1
		if not v then return "no data"; end;
		local rv
		if fromto == "fromnative" then
			if v == -math.huge then
				rv = "-infinity"
			elseif v == math.huge then
				rv = "infinity"
			else
				local utc = celestia:tdbtoutc(v)
				rv = utc.year.."/"..utc.month.."/"..utc.day.." "..utc.hour..":"..utc.minute..":"..math_dround(utc.seconds,0)
			end
		elseif fromto == "tonative" then
			if v == "-infinity" then
				rv = -math.huge
			elseif v == "infinity" then
				rv = math.huge
			else
				local tdb = {};
				tdb.year = str_match(v,"^([0-9]+)\/")
				tdb.month = str_match(v,"^[0-9]+\/([0-9]+)")
				tdb.day = str_match(v,"^[0-9]+\/[0-9]+\/([0-9]+)")
				tdb.hour = str_match(v," ([0-9]+):")
				tdb.min = str_match(v," [0-9]+:([0-9]+)")
				tdb.sec = str_match(v," [0-9]+:[0-9]+:([0-9]+)")
				if not (tdb.year and tdb.month and tdb.day and tdb.hour and tdb.min and tdb.sec) then
					if tonumber(v) ~= nil then
						rv = celestia:utctotdb(v)
					else
						rv = nil
					end
				else
					rv = celestia:utctotdb(tdb.year,tdb.month,tdb.day,tdb.hour,tdb.min,tdb.sec)
				end;
			end;
		end;
		return(rv)
	end;
	};
	};
	};
	this.unittable.qr021_lifespanEnd = deepcopy(this.unittable.qr020_lifespanStart)
	this.unittable.zcmdlonglat = deepcopy(this.unittable.zcmdangle)
	this.unitmeta = {};
	local tabindx = tabindx
	for o,p in pairs(templates.metaUnits) do
		this.unitmeta[o] = {};
		this.unitmeta[o][1] = "";
		this.unitmeta[o].valuelist = deepcopy(templates.metaUnits[o].valuelist)
		this.unitmeta[o].metaindx = tabindx(templates.metaUnits[o][1],templates.metaUnits[o].valuelist)
		if o == "zcmddistance" or o == "zcmdduration" or o == "zcmdangle" or o == "zcmdrate" or o == "zcmdspeed" or o == "zcmdlonglat" then
			this.unitmeta[o][1] = deepcopy(templates.metaQuery[o][1])
		end
	end;
	for q,w in pairs(this.unittable) do
		this.unittable[q][1]=this.unittable[q].valuelist[this.unitmeta[q].metaindx];
	end;
	for s,d in pairs(this.rndtabNames) do
		if this.unitmeta[s] then
			this.unitmeta[s][1] = d
		end;
	end;
end;
init_view = function(this)
	this.vwpage = {
	log = 0;
	resultset = 0;
	};
	this.VW = {
	srctab={
	data = {
	{{},choicelist = {};},
	argTbl = {};
	};
	meta = {
	{},
	argTbl = {};
	indxTbl = {};
	infostr = "View";
	};
	}};
	local ii = 0
	local metaname
	for i,v in orderedPairs(this.rndtabQr) do
		ii = ii + 1;
		metaname = this.rndtabNames[i]
		this.VW.srctab.data[1][1][ii] = false
		this.VW.srctab.data[1].choicelist[ii] = i
		this.VW.srctab.meta[ii] = {metaname}
		this.VW.srctab.data.argTbl[ii] = {cstname=metaname..": ",delim={";",valuelist=deepcopy(templates.delims);}};
		this.VW.srctab.meta.argTbl[ii] = {cstname={"Visual Name:"},delim={"delimiter end"}}
	end;
	if not this.defVWloaded  and not myCelPad.fileConv then
		this.defVWloaded = true
		myCelPad:loadCP("VW","default",this)
	end;
end;
init_sum = function(this)
	local deepcopy = deepcopy
	this.SUM = {
	srctab={
	data = {
	{{},choicelist = {};},
	argTbl = {};
	};
	meta = {
	{},
	argTbl = {};
	indxTbl = {};
	infostr = "Summary";
	};
	};
	summary = {
	};
	};
	local ii = 0
	local metaname
	local notstring = "name infoURL parent";
	for k,v in orderedPairs(this.rndtabAtr) do
		if not string.find(notstring,k) then
			ii = ii + 1;
			this.SUM.srctab.data[1][1][ii] = true
			this.SUM.srctab.data[1].choicelist[ii] = k
			metaname = tostring(this.rndtabNames[v])
			this.SUM.srctab.meta[ii] = {metaname}
			this.SUM.srctab.data.argTbl[ii] = {cstname=k,delim={";",valuelist=deepcopy(templates.delims)},equals={": ",valuelist=deepcopy(templates.equals)},shnils=false};
			this.SUM.srctab.meta.argTbl[ii] = {cstname={"Visual:"},delim={"Delimiter:"},equals={"Equals:"},shnils={"No Data"}};
			buildSumtab(this,k)
		end
	end;
	local mchfnc = "type stellarClass hubbleType featureType";
	local boolfnc = "hasRings visible";
	for i,v in orderedPairs(this.rndtabAtr) do
		if not string.find(mchfnc..boolfnc,i) then
			tCelPadFinder.queryfnc.main[i] = tCelPadFinder.queryfnc.main[i] or tCelPadFinder.queryfnc.main.sum_num
			tCelPadFinder.queryfnc.xit[i] = tCelPadFinder.queryfnc.xit[i] or tCelPadFinder.queryfnc.xit.sum_num
			tCelPadFinder.queryfnc.quit[i] = tCelPadFinder.queryfnc.quit[i] or tCelPadFinder.queryfnc.quit.sum_num
			tCelPadFinder.queryfnc.loop[i] = tCelPadFinder.queryfnc.loop[i] or tCelPadFinder.queryfnc.loop.sum_num
			tCelPadFinder.loopCoef[i] = tCelPadFinder.loopCoef.sum_num
		end
	end;
	for fn in string.gmatch(mchfnc,"%w+") do
		tCelPadFinder.queryfnc.main[fn] = tCelPadFinder.queryfnc.main[fn] or tCelPadFinder.queryfnc.main.sum_mch
		tCelPadFinder.queryfnc.xit[fn] = tCelPadFinder.queryfnc.xit[fn] or tCelPadFinder.queryfnc.xit.sum_mch
		tCelPadFinder.queryfnc.quit[fn] = tCelPadFinder.queryfnc.quit[fn] or tCelPadFinder.queryfnc.quit.sum_mch
		tCelPadFinder.queryfnc.loop[fn] = tCelPadFinder.queryfnc.loop[fn] or tCelPadFinder.queryfnc.loop.sum_mch
		tCelPadFinder.loopCoef[fn] = tCelPadFinder.loopCoef.sum_mch
	end;
	for fn in string.gmatch(boolfnc,"%w+") do
		tCelPadFinder.queryfnc.main[fn] = tCelPadFinder.queryfnc.main[fn] or tCelPadFinder.queryfnc.main.sum_bool
		tCelPadFinder.queryfnc.xit[fn] = tCelPadFinder.queryfnc.xit[fn] or tCelPadFinder.queryfnc.xit.sum_bool
		tCelPadFinder.queryfnc.quit[fn] = tCelPadFinder.queryfnc.quit[fn] or tCelPadFinder.queryfnc.quit.sum_bool
		tCelPadFinder.queryfnc.loop[fn] = tCelPadFinder.queryfnc.loop[fn] or tCelPadFinder.queryfnc.loop.sum_bool
		tCelPadFinder.loopCoef[fn] = tCelPadFinder.loopCoef.sum_bool
	end;
	tCelPadFinder.queryfnc.main["getchildren"] = tCelPadFinder.queryfnc.main.iterators
	tCelPadFinder.queryfnc.main["locations"] = tCelPadFinder.queryfnc.main.iterators
	tCelPadFinder.loopCoef["getchildren"] = tCelPadFinder.loopCoef.iterators
	tCelPadFinder.loopCoef["locations"] = tCelPadFinder.loopCoef.iterators
	tCelPadFinder.queryfnc.main["lifespanStart"] = tCelPadFinder.queryfnc.main.lifespan
	tCelPadFinder.queryfnc.main["lifespanEnd"] = tCelPadFinder.queryfnc.main.lifespan
	tCelPadFinder.loopCoef["lifespanStart"] = tCelPadFinder.loopCoef.lifespan
	tCelPadFinder.loopCoef["lifespanEnd"] = tCelPadFinder.loopCoef.lifespan
	if not this.defSUMloaded and not myCelPad.fileConv then
		this.defSUMloaded = true
		myCelPad:loadCP("SUM","default",this)
	end;
end;
init_nilid = function(this)
	local lnilid = tostring(math.random())
	local objn = #this.resultSet
	nilIdRst(this)
	if not this.closing then
		this.famid = "famid"..lnilid
		this.nilid = this.nilid or "nilid"..lnilid
		this.nilfam = {};
		this.nilfam[this.famid] = {};
		this.nilfam[this.famid][1] = objn
		this.oldfamid = this.famid;
		myCelPad.nilfams[this.famid] = {};
		myCelPad.nilfams[this.famid][this.famid] = {};
		myCelPad.nilfams[this.famid][this.famid][1] = objn;
		myCelPad.nilfams[this.famid][this.famid][5] = this;
	end
	for h,j in pairs(myCelPad.nilfams) do
		if type(j)=="table" and table_num(j) == 0 then
			myCelPad.nilfams[h] = nil;
		end
	end
end;
updGlobVars = function(this)
	this.verblogs = ms160VerboseLogs;
	this.alrtlogs = ms161AlertsInLogs;
	this.posDed = ms085PosDedup;
	this.nils = ms080InclNils;
	this.decplac = ms130untDecPlac;
	this.showPos = ms036ShowPos
	this.showCat = ms037ShowCat
	fastCleanup = tSettings.SystemSet.ms131fastCleanup
end;
verbstr = function(this,object,i)
	local output = ""
	if object and type(object) == "userdata" then
		local unittable = this.unittable
		local unitmeta = this.unitmeta
		local rndtabQr = this.rndtabQr
		local table_num = table_num
		local math_dround = math_dround
		local t_num, t_str = tonumber, tostring
		local t1, t2, prop
		local attrtab = this.VW.srctab.data
		local attrfnc
		for q,w in ipairs(attrtab[1].choicelist) do
			if attrtab[1][1][q] then
				prop = rndtabQr[w];
				if prop == "dsoradius" then prop = "radius" end;
				if prop == "getchildren" then
					attrfnc = #object:getchildren()
				elseif prop == "locations" then
					attrfnc = locsnum(object)
				elseif prop == "visible" then
					attrfnc = object:visible()
				elseif prop == "parent" and object:getinfo().parent then
					attrfnc = object:getinfo().parent
					if attrfnc then attrfnc = attrfnc:name() end
					attrfnc = attrfnc or "no data"
				else
					attrfnc = object:getinfo()[prop]
				end
				if unitmeta[w] then
					if t_num(attrfnc) then
						if w == "qr020_lifespanStart" or w == "qr021_lifespanEnd" then
							t1 = unittable[w][1](attrfnc,"fromnative")
						else
							t1 = math_dround(unittable[w][1](attrfnc,"fromnative"),this.decplac)
						end
					else
						t1 = unittable[w][1](attrfnc,"fromnative")
					end
					t2 = unitmeta[w].valuelist[unitmeta[w].metaindx]
				else
					t1 = t_str(attrfnc)
					if t1 == "nil" then t1 = "no data"; end;
					t2 = "";
				end;
				output = output..attrtab.argTbl[q].cstname.." "..t1.." "..t2.." "..attrtab.argTbl[q].delim[1].." "
			end
		end;
		if type(object) == "table" then
			output = t_str(object)..":"..table_num(object)..output
		end;
	else
		output = "!!! alert: invalid or missing item";
	end
	return output;
end;
tersstr = function(this,object,i)
	local output = ""
	if object and type(object) == "userdata" then
		local math_dround = math_dround
		local obs = observer
		local obs_pos  = obs:getposition()
		local distance = obs_pos:distanceto(object:getposition(celestia:gettime()))
		local posstr = ""
		if this.showPos then
			local obj_pos  = object:getposition()
			posstr = "; current position: "..string.format("x: %.2f y: %.2f z: %.2f",obj_pos.x,obj_pos.y,obj_pos.z)
		end;
		output = object:getinfo().type..": "..object:name().."; current distance: "..math_dround(this.unittable["qr001_distance"][1](distance,"fromnative"),this.decplac).." "..this.unitmeta["qr001_distance"].valuelist[this.unitmeta["qr001_distance"].metaindx]..posstr;
	else
		output = "!!! alert: invalid or missing item";
	end
	return output;
end;
update = function(this)
	if this.feeder then
		this.feeder.paused = this.paused
	end
	if this.stage2parser then
		this.stage2parser.paused = this.paused
	end
	if not this.niling and this.cancelscan and not this.canceldone and this.tasknum then
		for l,p in pairs(this.oriframe.popupMenus) do
			if string.sub(p.objname,1,9) == "RetainSet" then
				p.ynbutton.ynbuttonY:Action()
			end;
			if p.objname == "nilToWarnMSG" then
				p.ynbutton.ynbuttonN:Action()
			end;
		end;
		if this.runningScan then
			if this.tasktab.status[1] == 2 then
				this.tasktab.nextTask[1]=0;
				this.canceldone = true
			else
				if this.stage2parser then
					for x,c in ipairs(this.postProc.parsers) do
						c.cancelrq = true;
					end
					this.stage2parser.cancelrq = true;
					if (this.transfer or this.postproc) then
						this.tasktab.nextTask[this.tasknum+1]=0;
					end
				else
					this.tasktab.status[this.tasknum] = 3
					this.tasktab.nextTask[this.tasknum+1] = 0;
					this.canceldone = true
				end;
			end;
		else
			this.cancelscan = nil
			this.canceldone = nil
		end
	end;
	if (this.tasktab.status[1]~=0 and this.tasktab.status[1]~=4) and not this.niling then
		if this.tasktab.status[1]==5 and not (this.transfer or this.postproc) then
			this.tasktab.status[1]=3
		end;
		if this.tasktab.status[1]==1 or this.tasktab.status[1]==2 then
			if this.tasktab.status[1]==1 then
				this.tasktab.status[1]=2;
				this.runningTask = 1;
				local logStr
				if this.metaQueryVal.qr001_distance.scan and (this.scanWhat == "stars" or this.scanWhat == "dsos") then
					logStr = getLogValStr(this,"qr001_distance")
				else
					logStr = "unlimited";
				end;
				CPlog("running base scan, distance "..logStr,0,this.sysLog)
				CPlog("base task: "..tostring(this.basetask).."; "..tostring(this.baselog),0,this.sysLog)
			end
			if (not this.paused) or this.cancelscan then
				this:BaseScan()
			end
		end;
		if this.tasktab.status[1]==3 then
			this.tasktab.status[1]=4
			if #this.resultSet == 0 then
				if not this.oriframe.MSGupT["nullBaseMSG"] then
					this.nullBaseMSG = PopMessage:new({this.oriframe.popupMenus});
					this.nullBaseMSG:init(this.oriframe,"nullBaseMSG",centX(this.oriframe),centY(this.oriframe),nil,{
					templates2.popMsg.nullBaseMSG[1],
					templates2.popMsg.nullBaseMSG[2]..tostring(this.basetask)..templates2.popMsg.nullBaseMSG[3],
					txtfnt = templates2.popMsg.nullBaseMSG.txtfnt;
					},nil,"ok");
					this.nullBaseMSG:makeBranch(this);
				end;
				this.tasktab.nextTask[1] = 0;
			end
			if this.tasktab.nextTask[1]~=0 then
				this.tasktab.status[2] = 1;
			else
				endScanMsg(this)
				finalizeScan(this)
			end;
		end;
	end;
	if this.tasktab.status[1]==4 and this.tasktab.nextTask[1]~=0 then
		this.taskcnt = this.taskcnt or 2
		if not this.niling and not (this.transfer or this.postproc) then
			if  this.tasktab.status[this.taskcnt]==1 then
				this.tasktab.status[this.taskcnt]=2
				this.runningTask = this.taskcnt;
				this:ScanStage(this.tasktab.nextTask[this.taskcnt],this.taskcnt);
			end
			if this.tasktab.status[this.taskcnt]==3 then
				this.tasktab.status[this.taskcnt]=4;
				this.runningTask = 0;
				if this.tasktab.nextTask[this.taskcnt+1]~=0 then
					this.tasktab.status[this.taskcnt+1]=1;
				else
					endScanMsg(this)
					finalizeScan(this)
				end;
			end
		end;
		this.taskcnt = this.taskcnt + 1;
		if this.tasktab.nextTask[this.taskcnt] == 0 then this.taskcnt = 2; end;
	end;
	if this.postproc then
		if not this.niling and this.tasktab.status[this.postproc]==2 then
			this.tasktab.status[this.postproc]=5
			this:ScanStage("z_postprocess",this.postproc)
		end;
	elseif this.transfer then
		if this.tmpResSet and #this.tmpResSet>0 then
			if this.niling ~= "tmpResSet" then
				nilResSet(this,"tmpResSet")
			end
		end;
		if not this.niling and this.tasktab.status[this.transfer]==2 then
			this.tasktab.status[this.transfer]=5
			this:ScanStage("z_transfer_objects",this.transfer)
		end;
	end;
	if this.closing then
		this.paused = nil;
		this:closeFinder();
	end;
end;
taskManager = function(this)
	local deepcopy = deepcopy
	this.runReady = true;
	if ms132updateOpened then
		this:updGlobVars();
	end
	local tasktab_templ_stars = {
	status =   {1,0,0,0,0,0,0,0,0,0,0,0,0,0};
	nextTask = {1,"qr001_distance","qr002_name_str","qr004_stellarClass_str","qr003_stellarClass","qr300_parent_str","qr005_radius","qr006_luminosity","qr007_temperature","qr008_absoluteMagnitude","qr009_bolometricMagnitude","qr028_rotationPeriod","qr029_orbitPeriod","qr030_numPlanets","qr012_catalogNumber",0};
	};
	local tasktab_templ_bodies = {
	status =   {1,0,0,0,0,0,0,0,0,0,0,0,0,0};
	nextTask = {1,"z_has_bodies","z_get_bodies","qr001_distance","qr016_type","qr017_type_str","qr002_name_str","qr300_parent_str","qr302_infoURL","qr005_radius","qr028_rotationPeriod","qr029_orbitPeriod","qr018_oblateness","qr019_albedo","qr020_lifespanStart","qr021_lifespanEnd","qr022_atmosphereHeight","qr023_atmosphereCloudHeight","qr024_atmosphereCloudSpeed","qr026_hasRings","qr030_numPlanets","qr025_Locations","qr999_isVisible",0}; --,"qr027_mass"
	};
	local tasktab_templ_dsos = {
	status =   {1,0,0,0,0,0,0,0,0,0,0,0,0,0};
	nextTask = {1,"qr001_distance","qr016_type","qr017_type_str","qr101_hubbleType","qr102_hubbleType_str","qr002_name_str","qr100_dso_radius","qr008_absoluteMagnitude","qr999_isVisible",0};
	};
	local tasktab_templ_locations = {
	status =   {1,0,0,0,0,0,0,0,0,0,0,0,0,0};
	nextTask = {1,"z_has_bodies","z_get_bodies","z_get_locations","qr001_distance","qr200_featureType","qr201_featureType_str","qr002_name_str","qr300_parent_str","qr302_infoURL","qr202_size","qr203_importance",0};
	};
	this.tasktab = {
	status = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	nextTask = {1,0};
	}
	this.tmpObjects = nil;
	this.tmpObjects = {};
	this.basetaskraw = "";
	local templ_tbl;
	if this.scanWhat == "stars" then
		templ_tbl = tasktab_templ_stars.nextTask
	elseif this.scanWhat == "satellites" then
		templ_tbl = tasktab_templ_bodies.nextTask
		this.metaQueryVal.z_has_bodies.scan = true
		this.metaQueryVal.z_get_bodies.scan = true
	elseif this.scanWhat == "dsos" then
		templ_tbl = tasktab_templ_dsos.nextTask
	elseif this.scanWhat == "locations" then
		templ_tbl = tasktab_templ_locations.nextTask
	elseif this.scanWhat == "getorbs" then
		this.queryVal = this.queryPlanets;
		this.metaQueryVal = this.metaQueryPlanets;
		this.metaQueryVal.z_has_bodies.scan = true
		this.metaQueryVal.z_get_bodies.scan = true
		templ_tbl = {1,"z_has_bodies","z_get_bodies",0};
	elseif this.scanWhat == "getlocs" then
		this.queryVal = this.queryLocations;
		this.metaQueryVal = this.metaQueryLocations;
		this.metaQueryVal.z_get_locations.scan = true
		templ_tbl = {1,"z_get_locations",0};
	elseif this.scanWhat == "getpars" then
		this.queryVal = this.queryPlanets;
		this.metaQueryVal = this.metaQueryPlanets;
		this.metaQueryVal.z_get_parents.scan = true
		this.metaQueryVal.z_transfer_parents.scan = true
		templ_tbl = {1,"z_get_parents",0};
	elseif this.scanWhat == "summary" then
		templ_tbl = {};
		local ki = 0
		for k,l in ipairs(this.SUM.srctab.data[1][1]) do
			if l then
				ki = ki + 1;
				templ_tbl[ki] = this.SUM.srctab.data[1].choicelist[k];
			end;
		end;
	else
		if this.alrtlogs then
			CPlog("!!! alert: unknown scan target: "..tostring(this.scanWhat)..", try again...",0,this.sysLog);
		end
	end;
	if this.scanType == "rs" then
		CPlog("### scanning result set for "..tostring(this.scanWhat),0,this.sysLog);
		local scopetxt
		if this.scanWhat ~= "summary" then
			scopetxt = {this.metaQueryVal.zz1_scan_within.valuelist[1],this.metaQueryVal.zz1_scan_within.valuelist[2]}
		else
			scopetxt = "not applicable"
		end
		local stxtindx = 0
		if this.scanWhat == "satellites" then
			if this.queryVal.zz1_scan_within[1] == "results" then
				this.metaQueryVal.z_has_bodies.scan = false
				this.metaQueryVal.z_get_bodies.scan = false
				stxtindx = 1
			else
				this.metaQueryVal.z_has_bodies.scan = true
				this.metaQueryVal.z_get_bodies.scan = true
				stxtindx = 2
			end;
		elseif this.scanWhat == "locations" then
			if this.queryVal.zz1_scan_within[1] == "results" then
				this.metaQueryVal.z_has_bodies.scan = false
				this.metaQueryVal.z_get_bodies.scan = false
				this.metaQueryVal.z_get_locations.scan = false
				stxtindx = 1
			else
				this.metaQueryVal.z_has_bodies.scan = false
				this.metaQueryVal.z_get_bodies.scan = false
				this.metaQueryVal.z_get_locations.scan = true
				stxtindx = 2
			end
		end;
		if stxtindx ~= 0 then
			CPlog(string.lower(this.metaQueryVal.zz1_scan_within[1]..": "..scopetxt[stxtindx]),0,this.sysLog);
		end
		if this.scanWhat ~= "summary" then
			if  this.queryVal.zz1_scan_pure then
				CPlog("set purified for "..tostring(this.scanWhat),0,this.sysLog)
				if this.scanWhat == "stars" then
					table.insert(templ_tbl,2,"qr017_type_str")
					this.metaQueryVal.qr017_type_str.scan = true;
					this.queryVal.qr017_type_str = "star"
				elseif this.scanWhat == "satellites" then
					if not this.metaQueryVal.qr017_type_str.scan and not this.metaQueryVal.qr016_type.scan then
						this.metaQueryVal.qr016_type.scan = true;
						this.queryVal.qr016_type.mcstr = this.metaQueryPlanets.qr016_type.fullmcstr
					end;
				elseif this.scanWhat == "dsos" then
					if not this.metaQueryVal.qr017_type_str.scan and not this.metaQueryVal.qr016_type.scan then
						this.metaQueryVal.qr016_type.scan = true;
						this.queryVal.qr016_type.mcstr = this.metaQueryDsos.qr016_type.fullmcstr;
					end;
				elseif this.scanWhat == "locations" then
					if not this.metaQueryVal.qr201_featureType_str.scan and not this.metaQueryVal.qr200_featureType.scan then
						this.metaQueryVal.qr200_featureType.scan = true;
						this.queryVal.qr200_featureType.mcstr = this.metaQueryLocations.qr200_featureType.fullmcstr;
					end;
				end;
			else
				CPlog("set not purified",0,this.sysLog)
			end;
		else
		end;
	elseif this.scanType == "cel" then
		CPlog("### scanning Celestia for "..tostring(this.scanWhat),0,this.sysLog);
		if this.scanWhat == "satellites" then
			this.metaQueryVal.z_has_bodies.scan = true
			this.metaQueryVal.z_get_bodies.scan = true
		end;
		if this.scanWhat == "locations" then
			this.metaQueryVal.z_has_bodies.scan = true
			this.metaQueryVal.z_get_bodies.scan = true
			this.metaQueryVal.z_get_locations.scan = true
		end;
	else
		if this.alrtlogs then
			CPlog("!!! alert: unknown scan type: "..tostring(this.scanType)..", try again...",0,this.sysLog);
		end
	end;
	if this.scanWhat ~= "summary" then
		this.newSwhat = this.scanWhat;
		if this.queryVal.zz1_scan_fixpos then
			this.fixpos = celestia:getobserver():getposition()
			CPlog("observer's position fixed ("..string.format("%.2f; %.2f; %.2f",this.fixpos.x,this.fixpos.y,this.fixpos.z)..")",0,this.sysLog)
		else
			this.fixpos = nil;
			CPlog("observer's position not fixed",0,this.sysLog)
		end;
	end
	local minmaxrisk = {};
	local mcrisk = math.huge
	if this.scanWhat ~= "summary" then
		local cnt = 2
		for i,v in ipairs(templ_tbl) do
			if type(v)~="number" and this.metaQueryVal[v].scan then
				if v == "qr001_distance" and this.scanType == "cel" and (this.scanWhat == "stars" or this.scanWhat == "dsos") then
				else
					this.tasktab.nextTask[cnt]=v;
					cnt=cnt+1;
				end;
			end;
		end;
		this.tasktab.nextTask[#this.tasktab.nextTask+1]=0;
		local sorttable = {
		indx = {};
		task = {};
		rate = {};
		};
		local srtcnt = 1;
		for i,v in ipairs(this.tasktab.nextTask) do
			if type(this.queryVal[v])=="table" and this.queryVal[v].maxv then
				if this.metaQueryVal[v][3] and this.metaQueryVal[v][6] then
					local lcrateBig = this.metaQueryVal[v][6] - this.metaQueryVal[v][3]
					local lcrateSmall = this.queryVal[v].maxv - this.queryVal[v].minv
					local lcrate = lcrateSmall/lcrateBig;
					if v == "qr012_catalogNumber" then
						lcrate = lcrateSmall/this.numOfStars
					end
					if v == "qr029_orbitPeriod" and this.scanWhat == "stars" then
						lcrate = 0.1
					end
					if string.sub(v,7,14) == "lifespan" then
						if (this.queryVal[v].minv ~= -math.huge or this.queryVal[v].maxv ~= math.huge) then
							lcrate = 0.0000000001
						else
							lcrate = 0.99999999999
						end
					end
					if this.metaQueryVal[v].negate then
						lcrate = 1 - lcrate;
					end;
					minmaxrisk[v] = lcrate
					sorttable.indx[srtcnt] = i;
					sorttable.task[srtcnt] = v;
					sorttable.rate[srtcnt] = lcrate;
					srtcnt = srtcnt + 1;
				end;
			end;
		end;
		for y=1,#sorttable.task do
			for i=1,#sorttable.task do
				if sorttable.rate[i+1] then
					if sorttable.rate[i]>sorttable.rate[i+1] then
						sorttable.rate[i],sorttable.rate[i+1] = sorttable.rate[i+1],sorttable.rate[i]
						sorttable.task[i],sorttable.task[i+1] = sorttable.task[i+1],sorttable.task[i]
					end;
				end;
			end;
		end;
		local wintask, winrate;
		local logstr = "unspecified";
		local skipindx,tmpwintsk, tmplogstr ;
		local getLogValStr = getLogValStr
		if this.scanType == "cel" and (this.scanWhat == "stars" or this.scanWhat == "dsos") and #sorttable.task > 0 then
			if sorttable.rate[1]<0.5 then
				wintask = sorttable.task[1]
				winrate = sorttable.rate[1]
				logstr = getLogValStr(this,wintask)
				skipindx = sorttable.indx[1]
			else
				tmpwintsk = sorttable.task[1]
				tmplogstr =  getLogValStr(this,tmpwintsk)
				tmpskipndx = sorttable.indx[1]
			end;
		end;
		for i=1,#sorttable.task do
			this.tasktab.nextTask[sorttable.indx[i]] = sorttable.task[i];
		end;
		if this.scanType == "cel" then
			if this.scanWhat == "stars" or this.scanWhat == "dsos" then
				local winnerstr = "";
				local srchtask, tobewin, winnertsk, killnxd, docheck;
				local isnot, tbwlen, starparent, stparq
				-- local isfrqnt
				for q = #this.tasktab.nextTask,1,-1 do
					srchtask = this.tasktab.nextTask[q]
					if type(srchtask)=="string" and string.find(this.srchstr,srchtask) then
						tobewin = this.queryVal[srchtask]
						--	isfrqnt = string.find("HIP;TYC",tobewin)
						isnot = this.metaQueryVal[srchtask].negate
						docheck = false;
						tbwlen = string.len(tobewin)
						if tbwlen>2 then
							if isnot then
								-- if isfrqnt then
								-- docheck = true;
								-- end;
							else
								--if not isfrqnt then
								docheck = true;
								--end;
							end;
						end;
						if docheck then
							if tbwlen >= string.len(winnerstr) then
								winnerstr = tobewin;
								winnertsk = srchtask
								killnxd = q;
							end;
						end;
						if srchtask == "qr300_parent_str" and this.scanWhat == "stars" then
							starparent = srchtask
							stparq = q
						end
					end;
				end;
				if starparent then
					if this.metaQueryVal[starparent].negate then
						if this.queryVal[starparent] == "" then
							winnertsk = nil;
							wintask = starparent
							skipindx = stparq
							logstr = getLogValStr(this,wintask)
						end
					else
						if this.queryVal[starparent] ~= "" then
							winnertsk = nil;
							wintask = starparent
							skipindx = stparq
							logstr = getLogValStr(this,wintask)
						end
					end
				end
				if winnertsk then
					if wintask then
						if winrate > 0.3 or tbwlen > 2 then
							wintask = winnertsk;
							skipindx = killnxd;
							logstr = getLogValStr(this,wintask)
						end;
					else
						wintask = winnertsk;
						skipindx = killnxd;
						logstr = getLogValStr(this,wintask)
					end;
				end;
				if not wintask then
					for ts in string.gmatch(this.mcsrchstr, "[%w,_]+") do
						winnertsk = ts
						local sclasses = -1;
						for q = #this.tasktab.nextTask,1,-1 do
							if this.tasktab.nextTask[q] == winnertsk then
								killnxd = q
								sclasses = 0
							end;
						end;
						if sclasses == 0 then
							for n,m in ipairs(this.queryVal[winnertsk][1]) do
								if m then sclasses = sclasses + 1; end;
							end;
							local sclrate = sclasses/#this.queryVal[winnertsk][1]
							if sclrate < 0.5 then
								wintask = winnertsk;
								skipindx = killnxd;
								logstr = this.queryVal[wintask].mcstr;
							end;
						end;
					end
				end;
				if not wintask and tmpwintsk then
					wintask = tmpwintsk;
					skipindx = tmpskipndx;
					logstr = tmplogstr;
				end;
				if not wintask then
					local lasttsk = this.tasktab.nextTask[2]
					if type(lasttsk) == "string" then
						wintask = lasttsk
						skipindx = 2
						logstr = getLogValStr(this,wintask);
					end;
				end;
			elseif this.scanWhat == "satellites" or this.scanWhat == "locations" then
				wintask = "z_has_bodies";
				skipindx = 2
				logstr = "unspecified"
			end;
			if this.tasktab.nextTask[3]==0 then
				this.tasktab.nextTask[1]=0;
			end;
			if not wintask then
				this.tasktab.nextTask[1]=0;
				wintask = "q_dummy";
			else
				table.remove(this.tasktab.nextTask,skipindx)
			end;
			if this.metaQueryVal[wintask].negate then
				logstr = "NOT ("..tostring(logstr)..")";
			end;
			this.basefnc = this.tCelPadFinder.queryfnc.main[wintask];
			this.basenegator = this.metaQueryVal[wintask].negate
			this.baselog = logstr;
			this.basetaskraw = wintask;
			if tostring(this.metaQueryVal[wintask][1]) == "" then
				this.basetask = wintask;
			else
				this.basetask = string.lower(this.metaQueryVal[wintask][1])
			end
		end;
		local switch = {};
		templ_tbl = nil;
		templ_tbl = deepcopy(this.tasktab.nextTask)
		this.tasktab.nextTask = nil;
		this.tasktab.nextTask = {};
		local ik = 0
		local notstring
		for i,t in ipairs(templ_tbl) do
			if this.metaQueryVal[t] then notstring = this.metaQueryVal[t].negate end
			if (type(t)=="string" and string.find(this.srchstr,t)) and ((
				(this.scanWhat ~= "stars") and notstring)
				or (
				(this.scanWhat == "stars") and ((t ~= "qr300_parent_str" and notstring)
					or
					(t == "qr300_parent_str" and ((this.queryVal.qr300_parent_str == "" and not notstring)
						or
						(this.queryVal.qr300_parent_str ~= "" and notstring)
				)))))
			then
				table.insert(switch,t)
			else
				ik = ik + 1
				this.tasktab.nextTask[ik] = t
			end
		end
		templ_tbl = nil;
		templ_tbl = deepcopy(this.tasktab.nextTask)
		this.tasktab.nextTask = nil;
		this.tasktab.nextTask = {};
		ik = 0
		local mcrate, mccond1, mccond2
		for i,t in ipairs(templ_tbl) do
			mccond1 = (type(t) == "string")
			mccond2 = string.find(this.mcsrchstr,t)
			if mccond1 and mccond2 then
				mcrate = string.len(tostring(this.queryVal[t].mcstr))/string.len(tostring(this.metaQueryVal[t].fullmcstr))
				mcrisk = math.min(mcrisk,mcrate)
			end;
			if mccond1 and mccond2 and mcrate > 0.5  then
				table.insert(switch,t)
			else
				ik = ik + 1
				this.tasktab.nextTask[ik] = t
			end
		end
		local tn = #this.tasktab.nextTask
		for i=tn,tn+#switch do
			this.tasktab.nextTask[i] = switch[i-tn+1]
		end;
		table.insert(this.tasktab.nextTask,0)
	else
		local cnt = 2
		for i,v in ipairs(templ_tbl) do
			if type(v) ~= "number" then
				this.tasktab.nextTask[cnt] = v;
				cnt = cnt + 1;
			end;
		end;
		this.tasktab.nextTask[#this.tasktab.nextTask+1]=0;
	end;
	local tsum
	if this.scanType == "cel" then
		tsum = tostring(this.basetask).."; ";
	else
		tsum = "";
	end
	if this.scanWhat ~= "summary" then
		if this.nils then
			CPlog("items with 'no data' included",0,this.sysLog);
		else
			CPlog("items with 'no data' NOT included",0,this.sysLog);
		end;
	end;
	if this.scanWhat ~= "summary" then
		for ik,vk in ipairs(this.tasktab.nextTask) do
			if type(vk)=="string" then
				tsum = tsum..this.rndtabNames[vk].."; ";
			end
		end;
		if this.metaQueryVal.qr001_distance.scan and this.scanType == "cel" and (this.scanWhat == "stars" or this.scanWhat == "dsos") then
			tsum = this.metaQueryVal["qr001_distance"][1].."; "..tsum
		end;
		CPlog("scanning tasks: "..string.lower(tsum),0,this.sysLog);
		if this.scanType == "rs" then
			CPlog("stage 1 not applicable",0,this.sysLog);
		end;
	else
		for ik,vk in ipairs(this.tasktab.nextTask) do
			if type(vk)=="string" then
				tsum = tsum..vk.."; ";
			end
		end;
		CPlog("preparing summary for attributes: "..tsum,0,this.sysLog);
	end;
	local nilltorisk;
	local launchfnc = function()
		this.taskcnt = 2;
		if this.scanType == "cel" then
			if this.scanWhat == "dsos" then
				this.numofobj = this.numOfDsos
			else
				this.numofobj = this.numOfStars
			end;
			this.tasktab.status[1]=1;
		elseif this.scanType == "rs" then
			this.tasktab.status[1]=4;
			this.tasktab.nextTask[1]=1;
			this.tasktab.status[2]=1;
			if this.scanWhat == "summary" then
				for f,g in pairs(this.SUM.summary) do
					buildSumtab(this,f)
				end
			end;
		else
			if this.alrtlogs then
				CPlog("!!! alert: unknown scan type: "..tostring(this.scanType)..", try again...",0,this.sysLog);
			end
		end;
		tCelPadHUD.functions.viewLog(this.wobj.mainFrame)
		this.wobj.mainFrame.pagenumber = this.wobj.mainFrame.pages;
		this.lagcnt = nil;
		this.nilLoop = nil;
		this.nilToRisk = nilltorisk;
		this.runReady = nil;
		this.runningScan = true;
	end;
	local risky = {}
	local risktasks = "z_has_bodies z_get_bodies z_get_locations";
	local tasksn = 0
	if timedelta > timeObjRisk then
		risky["sslow"] = true
	end
	if this.scanWhat ~= "summary" then
	local distint
	local distrisk = 0
	if this.metaQueryVal.qr001_distance.scan then
		tasksn = 1;
		distint = this.queryVal.qr001_distance.maxv - this.queryVal.qr001_distance.minv
		if distint > distLargeRisk then
			distrisk = 0.9
		end;
	else
		distrisk = 1
	end
	local restrisk = math.huge
	local tmprisk, deduprisk
	for n,m in ipairs(this.tasktab.nextTask) do
		if type(m) == "string" then
			if string.sub(m,1,5) == "z_get" then
				deduprisk = true
			end
			if string.find(this.srchstr,m) then
				if m == "qr300_parent_str" then
					if this.queryVal[m] == "" then
						tmprisk = 0.9
					else
						tmprisk = 0.1
					end;
				else
					tmprisk = 0.1
				end
				if this.metaQueryVal[m].negate then
					tmprisk = 1 - tmprisk
				end
			else
				tmprisk = restrisk
			end
			restrisk = math.min(restrisk,tmprisk)
			if not string.find(risktasks,m) then
				tasksn = tasksn + 1
			end;
		end
	end
	local mmxrisk = math.huge
	for k,l in pairs(minmaxrisk) do
		if mmxrisk > 0 then
			mmxrisk = math.min(mmxrisk,l)
		end
	end
	local baserisk
	if this.scanType == "cel" then
		if this.basetaskraw and not string.find(risktasks,this.basetaskraw) then
			if string.find(this.mcsrchstr,this.basetaskraw) then
				baserisk = string.len(tostring(this.queryVal[this.basetaskraw].mcstr))/string.len(tostring(this.metaQueryVal[this.basetaskraw].fullmcstr))
			elseif string.find(this.srchstr,this.basetaskraw) then
					if this.basetaskraw == "qr300_parent_str" then
						if this.queryVal.qr300_parent_str == "" then
							baserisk = 0.9
						else
							baserisk = 0.1
						end
					else
						baserisk = 0.1
					end
				if this.metaQueryVal[this.basetaskraw].negate then
					baserisk = 1 - baserisk
				end
			elseif type(this.queryVal[this.basetaskraw]) == "table" and this.queryVal[this.basetaskraw].minv then
				baserisk = minmaxrisk[this.basetaskraw] or 0.1
			else
				baserisk = 0.9;
			end
		end
	else
		baserisk = 0.9
	end
	if this.scanWhat == "stars" and (this.scanType == "cel" or #this.resultSet > nilTmoRisk[1]) then
		local isbig = math.huge
		isbig = math.min(isbig,restrisk)
		isbig = math.min(isbig,baserisk)
		isbig = math.min(isbig,mcrisk)
		isbig = math.min(isbig,mmxrisk)
	if distrisk > 0.1 then
		if isbig and isbig >= lrgSetRisk or
		tasksn == 1 and distrisk == 0.9
		then
			risky["large"] = true
		end
	end
	end
	if (#this.resultSet > nilTmoRisk[1] and tasksn > nilTmoRisk[2]) and this.scanWhat ~= "summary" then
		risky["niltotasks"] = true
		nilltorisk = true;
	end
	if not string.find("getorbs getlocs",this.scanWhat) and (tasksn == 0 and (this.basetaskraw == "" or this.basetaskraw == "q_dummy" or string.find(risktasks,this.basetaskraw))) then
		if this.scanType == "cel" then
			risky["notaskscel"] = true
		else
			risky["notasksrs"] = true
		end
	end
	if this.posDed and deduprisk then
		risky["posDed"] = true
	end
	end
	local riskystr = ""
	for t,y in pairs(risky) do
		riskystr = riskystr.." "..tostring(t)
	end
	if riskystr ~= "" and ms055ShowScanWarnings then
		myCelPad:systemMsg(centX(this.oriframe),centY(this.oriframe),riskystr,this,launchfnc)
	else
		launchfnc()
	end;
end;
getBodies = function(this,bParent)
	local t_ins = table.insert
	if this.verblogs then
		this.statbodlog = this.statbodlog or {};
		this.statbodlog[this.tasknum] = this.statbodlog[this.tasknum] or #this.sysLog+1;
		CPlog("getting orbiting bodies of "..tostring(bParent:name()),0,this.sysLog,this.statbodlog[this.tasknum]);
	end;
	local satellites = bParent:getchildren()
	for i,v in ipairs(satellites) do
		t_ins(this.resultSet,v);
		if #v:getchildren()>0 then this:getBodies(v) end;
	end;
	satellites = nil;
end;
getBodiesTask = function(this,bParent)
	local getKeyName = getKeyName
	local t_ins = table.insert
	if this.scanType ~= "cel" and this.verblogs then
		this.statbodlog = this.statbodlog or {};
		this.statbodlog[this.tasknum] = this.statbodlog[this.tasknum] or #this.sysLog+1;
		CPlog("getting orbiting bodies of "..tostring(bParent:name()),0,this.sysLog,this.statbodlog[this.tasknum]);
	end;
	local satellites = bParent:getchildren()
	local satnum = #satellites
	local postprlim = this.postProc.postPrLim
	if satnum >= postprlim and not this.postproc then
		t_ins(this.postProc.tab,bParent)
		this.postProc.ptype = 1;
		satellites = nil;
	else
		if this.postproc then
			this:postProcessObj(bParent)
		else
			for i,v in ipairs(satellites) do
				this.tmpObjects[getKeyName(v,this)]=v
				if #v:getchildren()>0 then this:getBodiesTask(v) end;
			end;
		end;
		satellites = nil;
	end
end;
getLocations = function(this,bParent)
	local t_ins = table.insert
	local locnum = 0
	if this.verblogs  then
		this.statloclog = this.statloclog or {};
		this.statloclog[this.tasknum] = this.statloclog[this.tasknum] or #this.sysLog+1;
		CPlog("getting locations of "..tostring(bParent:name()),0,this.sysLog,this.statloclog[this.tasknum]);
	end;
	local locs = bParent:locations()
	for loc in locs do
		locnum = locnum + 1;
		t_ins(this.resultSet,loc);
	end;
end;
getLocationsTask = function(this,bParent)
	local getKeyName = getKeyName
	local t_ins = table.insert
	local locsnum = locsnum
	local postprlim = this.postProc.postPrLim
	local locn = locsnum(bParent)
	local locs = bParent:locations()
	if locn >= postprlim and not this.postproc then
		t_ins(this.postProc.tab,bParent)
		this.postProc.ptype = 2;
	else
		if this.verblogs and not this.postproc then
			this.statloclog = this.statloclog or {};
			this.statloclog[this.tasknum] = this.statloclog[this.tasknum] or #this.sysLog+1;
			CPlog("getting locations of "..tostring(bParent:name()),0,this.sysLog,this.statloclog[this.tasknum]);
		end;
		if this.postproc then
				this:postProcessObj(bParent)
		else
			for loc in locs do
				this.tmpObjects[getKeyName(loc,this)] = loc
			end;
		end;
	end
end;
postProcessObj = function(this,bParent)
	local postprlim = this.postProc.postPrLim
	local ptype = this.postProc.ptype
	local getKeyName = getKeyName
	local logobjs
	local instab
	local t_str = tostring
	if this.postProc.ptype == 1 then
		instab = bParent:getchildren()
		logobjs = "satellites"
	elseif this.postProc.ptype == 2 then
		local locs = bParent:locations()
		local locstab = {};
		for loc in locs do
			table.insert(locstab,loc)
		end
		instab = locstab
		logobjs = "locations"
	end
	local postPrPars = CPLoopPars:new({tCelPad.Parsers})
	postPrPars.finderpnt1 = this
	postPrPars:init("postPrPars",postprlim,
	function(o) --QTrue
		o.ik = o.ik or 0;
		o.ik = o.ik + 1;
		local indexnum = o.ik; local finder = o.finderpnt1; local t_ins = table.insert;
		local object = instab[indexnum]
		o.finderpnt1.tmpObjects[getKeyName(object,o.finderpnt1)] = object
		if ptype == 1 then
			if #object:getchildren()>0 then o.finderpnt1:getBodiesTask(object) end;
		end
	end,
	function(o) --xitFnc
		return ((o.ik >= #instab) or not o.ik);
	end,
	function(o) --finFnc
		if o.cancelrq then
			o.finderpnt1.statlog2 = o.finderpnt1.statlog2 or #o.finderpnt1.sysLog+1;
			CPlog("stage "..t_str(o.finderpnt1.tasknum).." postprocess parser cancelled",0,o.finderpnt1.sysLog,o.finderpnt1.statlog2)
		end;
		local parstab = o.finderpnt1.postProc.parsers
		table.remove(parstab,o:tindex(parstab))
	end,
	function(o) --loopFnc
		if o.finderpnt1.verblogs then
			o.finderpnt1.statlocpprlog = o.finderpnt1.statlocpprlog or #o.finderpnt1.sysLog+1;
			CPlog("postprocessing "..t_str(o.ik).." "..t_str(logobjs).." of "..t_str(bParent:name()),0,o.finderpnt1.sysLog,o.finderpnt1.statlocpprlog);
		end;
	end
	);
	postPrPars:makeBranch(this);
	table.insert(this.postProc.parsers,postPrPars)
end;
ScanStage = function(this, findx, num)
	if findx== 0 then
		CPlog("no tasks for this scan",0,this.sysLog)
		this.tasktab.status[num]=3;
		this.tasktab.nextTask[num]=0;
		this.runningTask = 0;
	else
		local logTaskName;
		local logValString;
		local QTrue
		local xitFnc
		local finFnc;
		local loopFnc;
		local getLogValStr = getLogValStr
		local t_str = tostring;
		local objnum = #this.resultSet
		if this.scanWhat ~= "summary" then
			if t_str(this.metaQueryVal[findx][1]) == "" then
				logTaskName = findx;
			else
				logTaskName = string.lower(this.metaQueryVal[findx][1])
			end
			logValString = getLogValStr(this,findx)
			if this.metaQueryVal[findx] and this.metaQueryVal[findx].negate then
				logValString = "NOT("..logValString..")";
			end;
			if objnum == 0 then
				objnum = table_num(this.tmpObjects)
			end
			CPlog("running scanner stage "..t_str(num).."; objects #"..t_str(objnum).."; task: "..logTaskName.."; "..logValString,0,this.sysLog)
			QTrue = this.tCelPadFinder.queryfnc.main[findx];
			xitFnc = this.tCelPadFinder.queryfnc.xit[findx] or
			function(o)
				return ((o.ik >= #o.finderpnt1.tmpResSet) or not o.ik);
			end;
			finFnc = this.tCelPadFinder.queryfnc.quit[findx] or
			function(o)
				o.ik = nil;
				local numres = #o.finderpnt1.resultSet
				local numtask = o.finderpnt1.tasknum
				local finder = o.finderpnt1
				local endlog = "";
				if finder.scanWhat ~= "getorbs" and finder.scanWhat ~= "getpars" and finder.scanWhat ~= "getlocs" then
					endlog = t_str(#finder.tmpResSet-numres).." objects excluded from previous stage"
				end
				finder.statlogx2 = finder.statlogx2 or {};
				finder.statlogx2[finder.tasknum] = finder.statlogx2[finder.tasknum] or #finder.sysLog+1
				local exstat = "";
				if o.cancelrq then
					exstat = "cancelled";
				else
					exstat = "finished";
				end;
				CPlog("stage "..t_str(numtask).." "..exstat.."; "..endlog,0,finder.sysLog,finder.statlogx2[finder.tasknum])
				if numres ~= 0 then
					if finder.niling ~= "tmpResSet" then
						nilResSet(finder,"tmpResSet")
					else
						if finder.alrtlogs then
							CPlog("!!! alert: post-stage tmpResSet cleanup running",0,finder.sysLog)
						end
					end;
				finder.tasktab.status[finder.tasknum]=3;
				finder.stage2parser = nil;
				else
					if not finder.closing then
						finder.RetainSetStgMSG = PopMessage:new({finder.oriframe.popupMenus});
						finder.RetainSetStgMSG:init(finder.oriframe,"RetainSetStgMSG",centX(finder.oriframe),centY(finder.oriframe),nil,{
						templates2.popMsg.RetainSetStgMSG[1]..t_str(numtask)..templates2.popMsg.RetainSetStgMSG[2],
						templates2.popMsg.RetainSetStgMSG[3],
						txtfnt = templates2.popMsg.RetainSetStgMSG.txtfnt;
						},nil,"yn",
						function()
							CPlog("latest temporary result set retained; "..t_str(#finder.tmpResSet).." objects",0,finder.sysLog)
							finder.resultSet=finder.tmpResSet;
							finder.tmpResSet = nil;
							returnView(finder)
							finder.tasktab.status[finder.tasknum]=3;
							finder.stage2parser = nil;
						end,
						function()
							if finder.niling ~= "tmpResSet" then
								nilResSet(finder,"tmpResSet")
							else
								if finder.alrtlogs then
									CPlog("!!! alert: retain tmpResSet cleanup running",0,finder.sysLog)
								end;
							end;
							finder.resultSet = nil;
							finder.resultSet = {
							};
							nilStatLogs(finder)
							returnView(finder)
							finder.tasktab.status[finder.tasknum]=3;
							finder.stage2parser = nil;
							CPlog("latest temporary result set cleared",0,finder.sysLog)
						end
						);
						finder.RetainSetStgMSG:makeBranch(finder);
					end
					CPlog("stage "..t_str(finder.tasknum).." returned "..t_str(numres).." objects, remaining tasks aborted...",0,finder.sysLog)
					finder.tasktab.nextTask[finder.tasknum+1]=0
				end;
			end
			loopFnc = this.tCelPadFinder.queryfnc.loop[findx] or
			function(o)
				local finder = o.finderpnt1
				if finder.tmpResSet and finder.verblogs then
					finder.statlogx2 = finder.statlogx2 or {};
					finder.statlogx2[finder.tasknum] = finder.statlogx2[finder.tasknum] or #finder.sysLog+1;
					CPlog("stage "..t_str(finder.tasknum).."; scanned object #"..t_str(o.ik).."; pack: "..t_str(o.maxinloop),0,finder.sysLog,finder.statlogx2[finder.tasknum])
					o.finderpnt1.statlogx1 = o.finderpnt1.statlogx1 or {};
					o.finderpnt1.statlogx1[o.finderpnt1.tasknum] = o.finderpnt1.statlogx1[o.finderpnt1.tasknum] or #o.finderpnt1.sysLog+1;
					CPlog("stage "..t_str(o.finderpnt1.tasknum).."; found: "..t_str(#o.finderpnt1.resultSet).." objects",0,o.finderpnt1.sysLog,o.finderpnt1.statlogx1[o.finderpnt1.tasknum])
				end;
			end;
		else --is summary
			QTrue = this.tCelPadFinder.queryfnc.main[findx]
			xitFnc = this.tCelPadFinder.queryfnc.xit[findx] or
			function(o)
				return (o.ik >= #o.finderpnt1.resultSet);
			end;
			finFnc = this.tCelPadFinder.queryfnc.quit[findx] or
			function(o)
				o.ik = nil;
				local finder = o.finderpnt1
				local srctab = finder.SUM.srctab
				local task = finder.taskself
				local shnodata = srctab.data.argTbl[srctab.meta.indxTbl[task]].shnils
				local delim = t_str(srctab.data.argTbl[srctab.meta.indxTbl[task]].delim[1])
				local name = t_str(srctab.data.argTbl[srctab.meta.indxTbl[task]].cstname)
				if not o.isdata then
					if (not shnodata) then
						finder.statlogsm[finder.tasknum+1] = finder.statlogsm[finder.tasknum]
					else
						o.logstr = name..delim.." no data found"
					end;
				end;
				CPlog(t_str(o.logstr or "no data"),0,finder.sysLog,finder.statlogsm[finder.tasknum])
				finder.tasktab.status[finder.tasknum]=3;
				o.cancelrq = nil;
				finder.stage2parser = nil;
			end
			loopFnc = this.tCelPadFinder.queryfnc.loop[findx] or
			function(o)
				local finder = o.finderpnt1
				local sumtab = o.sumtab
				local srctab = finder.SUM.srctab
				local task = finder.taskself
				local indexnum = o.ik;
				local unittable = finder.unittable
				local unitmeta = finder.unitmeta
				local xmath_dround = math_dround
				local lcmath_dround
				local dummath_dround = function(a,b)
					return a
				end
				local qtask = finder.rndtabAtr[task]
				local delim = t_str(srctab.data.argTbl[srctab.meta.indxTbl[task]].delim[1])
				local equals = t_str(srctab.data.argTbl[srctab.meta.indxTbl[task]].equals[1])
				local name = t_str(srctab.data.argTbl[srctab.meta.indxTbl[task]].cstname)
				finder.statlogsm = finder.statlogsm or {};
				finder.statlogsm[finder.tasknum] = finder.statlogsm[finder.tasknum] or #finder.sysLog+1;
				local mnnames, mxnames = "","";
				if o.shNames then
					mnnames = " (first: "..t_str(o.sumtab[task].mnnamef or "no data")..", last: "..t_str(o.sumtab[task].mnnamel or "no data")..") "
					mxnames = " (first: "..t_str(o.sumtab[task].mxnamef or "no data")..", last: "..t_str(o.sumtab[task].mxnamel or "no data")..") "
				end;
				local extvalstr = ""
				for f,g in pairs(o.sumtab[task].extval) do
					extvalstr = extvalstr..t_str(f)..equals..t_str(g)..delim.." "
				end
				if extvalstr ~= "" then
					extvalstr = " boundary values count"..equals..extvalstr
				end
				if qtask == "qr020_lifespanStart" or qtask == "qr021_lifespanEnd" then
					lcmath_dround = dummath_dround
				else
					lcmath_dround = xmath_dround
				end
				if unittable[qtask] then
					o.logstr = name..delim.." min"..equals..lcmath_dround(unittable[qtask][1](sumtab[task].minn,"fromnative"),finder.decplac).." "..unitmeta[qtask].valuelist[unitmeta[qtask].metaindx]..mnnames..delim.." max"..equals..lcmath_dround(unittable[qtask][1](sumtab[task].maxn,"fromnative"),finder.decplac).." "..unitmeta[qtask].valuelist[unitmeta[qtask].metaindx]..mxnames..delim.." no data: "..t_str(o.nilsn or "not found")..delim..extvalstr
				else
					o.logstr = name..delim.." min"..equals..lcmath_dround(sumtab[task].minn,finder.decplac)..mnnames..delim.." max"..equals..lcmath_dround(sumtab[task].maxn,finder.decplac)..mxnames..delim.." no data: "..t_str(o.nilsn or "not found")..delim..extvalstr
				end;
				local logtxt = name..delim.." no data yet..."
				if o.isdata then
					logtxt = o.logstr
				end
				CPlog("summarizing #"..t_str(indexnum)..delim.." "..logtxt,0,finder.sysLog,finder.statlogsm[finder.tasknum])
			end;
		end;
		local loopn
		this.stage2parser = CPLoopPars:new({tCelPad.Parsers})
		this.stage2parser.finderpnt1 = this;
		this.stage2parser.finderpnt1.ik = nil;
		if this.scanWhat ~= "summary" then
			if findx == "z_postprocess" then
				this.tmpResSet = this.postProc.tab;
				this.postProc.tab = nil;
				this.postProc.tab = {};
				loopn = 1
			else
				this.tmpResSet = this.resultSet
				this.resultSet = nil;
				this.resultSet = {
				};
				this.negatepointer = this.metaQueryVal[findx].negate
				loopn = procLoopCoef(findx)
			end
		else
			this.stage2parser.shNames = ms038sumShowNames;
			loopn = procLoopCoef(findx)
		end;
		if (findx == "z_get_bodies" or findx == "z_postprocess") and this.tasktab.nextTask[num+1] == "z_get_locations" then
			this.oldDdup = this.posDed
			this.posDed = false;
		end;
		if this.posDed and (findx == "z_get_bodies" or findx == "z_get_locations" or findx == "z_postprocess") then
			this.tmscl = celestia:gettimescale()
			celestia:settimescale(0)
		end;
		this.taskself = findx;
		this.tasknum = num;
		this.stage2parser.paused = this.paused
		this.stage2parser:init("this.stage2parser",loopn,
		QTrue,
		xitFnc,
		finFnc,
		loopFnc
		);
		this.stage2parser:makeBranch(this);
	end;
end;
BaseScan = function(this)
	local t_str = tostring
	this.maxinloop = math.ceil(ms010ScanLoop*Fuse);
	this.fobject = this.sobject
	if this.fobject >= this.numofobj-1 then this.fobject = this.numofobj-1; end;
	this.lobject = this.fobject + this.maxinloop;
	for i = this.fobject,this.lobject do
		if i<=this.numofobj-1 then
			local object, obs , obs_pos, distance
			if this.scanWhat == "dsos" then
				object = celestia:getdso(i)
			else
				object = celestia:getstar(i)
			end;
			if this.fixpos then
				obs_pos = this.fixpos
			else
				obs = observer
				obs_pos = obs:getposition()
			end
			distance=obs_pos:distanceto(object:getposition(celestia:gettime()))
			if (this.scanWhat ~= "stars" and this.scanWhat ~= "dsos") or (not this.metaQueryVal.qr001_distance.scan) or (distance >= this.queryVal.qr001_distance.minv and distance <= this.queryVal.qr001_distance.maxv)  then
				this.finderpnt1 = this;
				this.finderpnt1.ik = 0;
				this.finderpnt1.tmpResSet = {};
				this.finderpnt1.tmpResSet[1]=object;
				this.finderpnt1.tasknum = 1;
				this.finderpnt1.negatepointer = this.basenegator;
				this.finderpnt1.nils = this.nils;
				this.basefnc(this);
				this.finderpnt1.tmpResSet = nil;
			end;
		else
			break
		end;
	end
	if (this.lobject >= this.numofobj-1) or this.cancelscan then
		local numres = #this.resultSet
		this.tasktab.status[1]=3;
		this.lobject = -1;
		if string.sub(this.basetaskraw,1,5) == "z_get" then
			local tmpHolder = {};
			tmpHolder.finderpnt1 = this
			local basequit = this.tCelPadFinder.queryfnc.quit[this.basetaskraw]
			if basequit then
				basequit(tmpHolder)
			end;
			CPlog("base scan finished, "..table_num(this.tmpObjects).." objects waiting for transfer",0,this.sysLog,this.statlog1);
		else
			CPlog("base scan finished; "..t_str(numres).." objects found",0,this.sysLog,this.statlog1);
		end;
		if this.verblogs then
			syslogRmItem(this.sysLog,this.statlog1+1)
		end;
		this.runningTask = 0;
	else
		if this.verblogs then
			this.statlog1 = this.statlog1 or #this.sysLog+1;
			CPlog("base scan total: "..t_str(this.numofobj).."; scanned: "..t_str(this.lobject).."; pack: "..t_str(this.maxinloop),0,this.sysLog, this.statlog1);
			CPlog("stage 1; found: "..t_str(#this.resultSet).." objects",0,this.sysLog,this.statlog1+1)
		end;
	end;
	this.sobject = this.lobject + 1;
end;
copyItems = function(this,finder)
	local t_str = tostring
	finder.copytab = finder.copytab or {};
	table.insert(finder.copytab,this)
	this.feeder = CPLoopPars:new({tCelPad.Parsers})
	this.feeder.srctbl = finder
	this.feeder.finderpnt2 = this;
	this.runningTask = 100
	this.nilToRisk = finder.nilToRisk;
	this.feeder:init("CPFinder.feeder",ms010ScanLoop,
	function(o)
		o.ik = o.ik or 0;
		o.ik = o.ik + 1;
		local indexnum = o.ik
		local object = o.srctbl.resultSet[indexnum];
		table.insert(o.finderpnt2.resultSet,object);
	end,
	function(o)
		return (o.ik >= #o.srctbl.resultSet)
	end,
	function(o)
		local exstat = "";
		if o.cancelrq then
			exstat = "cancelled";
		else
			exstat = "finished";
		end;
		CPlog("copy "..exstat..", "..t_str(o.ik).." items copied from "..t_str(o.srctbl.Header),0,o.finderpnt2.sysLog);
		CPlog("copy "..exstat..", "..t_str(o.ik).." items copied to "..t_str(o.finderpnt2.Header),0,o.srctbl.sysLog);
		o.finderpnt2.statmark2 = nil;
		o.finderpnt2.runningTask = 0;
		o.finderpnt2.feeder = nil;
		if fastCleanup then
			local tfamid = o.finderpnt2.famid
			local sfamid = o.srctbl.famid
			for t,y in pairs(o.srctbl.nilfam) do
				o.finderpnt2.nilfam[t] = o.finderpnt2.nilfam[t] or {}
				if sfamid == t then
					o.finderpnt2.nilfam[t][1] = math.max(o.ik,o.finderpnt2.nilfam[t][1] or 0)
					o.finderpnt2.nilfam[t][2] = (o.finderpnt2.nilfam[t][2] or 0) + o.ik
					o.finderpnt2.nilfam[t][4] = (o.finderpnt2.nilfam[t][4] or 0) + (o.srctbl.nilfam[4] or 1)
				else
					o.finderpnt2.nilfam[t][1] = y[1]
					o.finderpnt2.nilfam[t][2] = y[2]
					o.finderpnt2.nilfam[t][4] = y[4]
				end;
				o.finderpnt2.nilfam[t][3] = o.finderpnt2.nilfam[t][3] or y[3]
				if myCelPad.nilfams[t] then
					myCelPad.nilfams[t][tfamid] = myCelPad.nilfams[t][tfamid] or {}
					myCelPad.nilfams[t][tfamid][1] = #o.finderpnt2.resultSet
					myCelPad.nilfams[t][tfamid][5] = o.finderpnt2
				else
					o.srctbl.nilfam[t] = nil;
				end;
			end;
			myCelPad.nilfams[sfamid][tfamid][4] = (myCelPad.nilfams[sfamid][tfamid][4] or 0) + 1
			myCelPad.nilfams[sfamid][tfamid][2] = (myCelPad.nilfams[sfamid][tfamid][2] or 0) + o.ik
			myCelPad.nilfams[sfamid][tfamid][3] = o.finderpnt2.nilfam[tfamid][3]
		end
	table.remove(o.srctbl.copytab,tabindx(o.finderpnt2,o.srctbl.copytab))
	end,
	function(o)
		if o.finderpnt2.verblogs then
			o.finderpnt2.statmark2 = o.finderpnt2.statmark2 or #o.finderpnt2.sysLog+1;
			CPlog("copying item #"..t_str(o.ik).."; pack:"..t_str(o.maxinloop),0,o.finderpnt2.sysLog,o.finderpnt2.statmark2)
		end;
	end
	);
	this.feeder:makeBranch(this);
end;
closeFinder = function(this)
	if this.runningTask ~= 0 then
		this.cancelscan = true;
		if this.tasktab then
			this.tasktab.nextTask[this.runningTask+1]=0;
		end;
	end;
	if this.stage2parser then this.stage2parser.cancelrq = true; end;
	if this.feeder then this.feeder.cancelrq = true; end;
	if this.marker then this.marker.cancelrq = true; end;
	if this.cmdset then this.cmdset.cancelrq = true; end;
	local cnd = true
	if this.tasktab and this.tasktab.status[1]~=4 then cnd = false; end;
	if not (this.stage2parser or this.feeder or this.marker or this.cmdset) and cnd then
		this.runningTask = 0;
	end;
	local copying = this.copytab or {}
	for c,k in ipairs(copying) do
		k.feeder.cancelrq = true
	end
	if (this.runningTask == 0 and #copying == 0) and not (this.findertype == 2 and #this.runningCommands > 0) then
		if this.tmpResSet and #this.tmpResSet > 0 then
			if not this.niling then
				nilResSet(this,"tmpResSet",true)
			end
		elseif this.tmpObjects and table_num(this.tmpObjects) > 0 then
			if not this.niling then
				nilTmpObj(this,"tmpObjects")
			end
		elseif this.resultSet and #this.resultSet > 0 and not this.niling then
			nilResSet(this,"resultSet",true)
		elseif (not this.niling) then
			if fastCleanup then
				if myCelPad.nilfams[this.famid] then
					myCelPad.nilfams[this.famid][this.famid] = nil
				end;
			end
			if this.findertype == 2 then
				this.runningCommands = nil;
				this.openCommands = nil;
				this.CMDS = nil;
				this.env = nil;
			end
			this.closing = nil;
			this.active = false;
			syslogNil(this.sysLog)
			if this.objname ~= "tmpFinder" then
				this.wobj = this.wobj:wkill();
			end
			this = nil;
		end;
	end;
end;
};
CPSelectionLog = CClass {
classname = "CPSelectionLog";
superclass = CelPadScanner;
init = function(this,objname,header)
	this.Header = header or this.Header or "unnamed";
	this.objname = objname;
	this:updGlobVars();
	this.tCelPadFinder = tCelPadFinder;
	this.active = true;
	this.findertype = 2
	this.runningTask = 0;
	this.resultSet = {
	};
	this.sysLog = {
	logLevel = {};
	timestamp = {};
	logNum = {};
	}
	syslogInit(this.sysLog);
	this:init_query();
	this:init_allattr();
	this:init_units();
	this:init_view();
	this:init_marker();
	this:init_cmds();
	if fastCleanup then
		this:init_nilid()
	end
	CPlog("selection pad initialized",0,this.sysLog)
	CPlog("### right click on top bar for selection pad menu",0,this.sysLog);
end;
init_marker = function(this)
	local deepcopy = deepcopy
	this.markerParams = {};
	this.metaMarkerParams = {};
	local params = "zmkp1color zmkp2shape zmkp3size zmkp4opaque zmkp5occlud"
	for p in string.gmatch(params, "%w+") do
		this.markerParams[p] = deepcopy(templates.inputParam[p].data)
		this.metaMarkerParams[p] = deepcopy(templates.inputParam[p].meta)
	end;
	this.refmarkParams = deepcopy(templates.marker.refmarkParams);
	this.metaRefmarkParams = deepcopy(templates.marker.metaRefmarkParams);
end;
init_cmds = function(this)
	local deepcopy = deepcopy
	this.openCommands = {}
	this.runningCommands = {};
	this.CMDS = {
	srctab={
	data = {
	{{},choicelist = {};},
	argTbl = {};
	};
	meta = {
	{},
	argTbl = {};
	indxTbl = {};
	infostr = "Command Set";
	};
	};
	cmdopts = {
	data = {};
	meta = {};
	};
	};
	this.CMDS.cmdopts.data = deepcopy(templates.cmdopts.data);
	this.CMDS.cmdopts.meta = deepcopy(templates.cmdopts.meta);
	this.CMDS.cmdopts.data.co03repeatloop = ms152cmdRptSet;
	local ii = 0
	local metaname
	local cmdtab = deepcopy(templates.cpcmds)
	for i,v in orderedPairs(cmdtab) do
		if v.args and v.args ~= "" then
			ii = ii + 1;
			metaname = tostring(i)
			this.CMDS.srctab.data[1][1][ii] = true
			this.CMDS.srctab.data[1].choicelist[ii] = i
			this.CMDS.srctab.meta[ii] = {metaname}
			this.CMDS.srctab.data.argTbl[ii] = this.CMDS.srctab.data.argTbl[ii] or {};
			this.CMDS.srctab.meta.argTbl[ii] = this.CMDS.srctab.meta.argTbl[ii] or {};
			for p in string.gmatch(v.args, "%w+") do
				this.CMDS.srctab.data.argTbl[ii][p] = deepcopy(templates.inputParam[p].data)
				this.CMDS.srctab.meta.argTbl[ii][p] = deepcopy(templates.inputParam[p].meta)
				this.CMDS.srctab.meta.argTbl[ii][p][1] = argAbrv(p)
			end
		end;
	end;
	this.checklog = function() nilStatLogs(this) end;
	this.cancelthis = function()
		if this.cmdset and this.cmdset.cmdtimer then
			this.cmdset.cmdtimer.status = "kill";
		end
	end;
	this.cancelall = function()
		if this.cmdset and this.cmdset.cmdtimer then
			this.cmdset.cmdtimer:killchain()
		end
	end;
	this.pause = function()
		if this.cmdset and this.cmdset.cmdtimer then
			this.cmdset.cmdtimer.status = "frozen";
		end
	end;
	this.resume = function()
		if this.cmdset and this.cmdset.cmdtimer then
			this.cmdset.cmdtimer.status = "unfrozen";
		end
	end;
	if not this.defCMDSloaded  and not myCelPad.fileConv then
		this.defCMDSloaded = true
		myCelPad:loadCP("CMDS","default",this)
	end;
end;
update = function(this)
	if this.cmdset then
		this.cmdset.paused = this.paused
		local oriik = this.cmdset.ik
		if this.paused and this.cmdset.cmdtimer then
			this.cmdset.cmdtimer:killchain();
			this.cmdset.opaused = this.cmdset.paused
		end
		if this.cmdset.opaused ~= nil and this.cmdset.opaused ~= this.cmdset.paused then
			if this.CMDS.mtdlg then
				this.CMDS.mtdlg.btnselfAPL:Action()
			end
			if this.viewMode == "resultset" and this.cmdset.ik then
				this.oriframe.whtable.txtcol[oriik] = cpfntcolmainw;
			end
			this.cmdset.opaused = this.cmdset.paused
		end
	end
	if #this.openCommands == 0 then
		this.CMDS.mtdlg = nil
	end
	if this.feeder then
		this.feeder.paused = this.paused
	end
	if this.marker then
		this.marker.paused = this.paused
	end
	if this.closing then
		this.paused = nil;
		this:closeFinder();
	end;
end;
markObjects = function(this, mark)
	local commands = templates.celcmds
	celestia:show("markers")
	if ms132updateOpened then
		this:updGlobVars();
	end
	this.marker = CPLoopPars:new({tCelPad.Parsers});
	this.marker.finderpnt2 = this;
	this.marker.finderpnt2.runningTask = 1
	this.marker:init("this.marker",ms010ScanLoop*0.1,
	function(o)
		o.ik = o.ik or 0;
		o.ik = o.ik + 1;
		local indexnum = o.ik
		local object = o.finderpnt2.resultSet[indexnum];
		if object and type(object) == "userdata" then
			commands.unmark(nil,object,{})
			if mark then
				commands.mark(nil,object,{o.finderpnt2.markerParams.zmkp1color[1],o.finderpnt2.markerParams.zmkp2shape[1],o.finderpnt2.markerParams.zmkp3size, o.finderpnt2.markerParams.zmkp4opaque, o.finderpnt2.markerParams.zmkp5occlud})
			end;
		else
			myCelPad:systemMsg(nil,nil,"generr",o.finderpnt2,"Invalid or missing item.","marking objects, item #"..o.ik)
			o.cancelrq = true;
		end
	end,
	function(o)
		return (o.ik >= #o.finderpnt2.resultSet)
	end,
	function(o)
		local exstat = "";
		if o.cancelrq then
			exstat = "cancelled";
		else
			exstat = "finished";
		end;
		CPlog("marker "..exstat,0,o.finderpnt2.sysLog);
		o.finderpnt2.statmark2 = nil;
		o.finderpnt2.runningTask = 0;
		o.finderpnt2.marker = nil;
		if oldAdaptLoops ~= nil then
			tSettings.SystemSet.ms020AdaptiveLoops = oldAdaptLoops
			oldAdaptLoops = nil;
		end
	end,
	function(o)
		if o.finderpnt2.verblogs then
			o.finderpnt2.statmark2 = o.finderpnt2.statmark2 or #o.finderpnt2.sysLog+1;
			CPlog("marker running on #"..tostring(o.ik).."; pack: "..tostring(o.maxinloop),0,o.finderpnt2.sysLog,o.finderpnt2.statmark2)
		end;
	end
	);
	this.marker:makeBranch(this);
end;
runCommandSet = function(this)
	local t_str = tostring
	if ms132updateOpened then
		this:updGlobVars();
	end
	this.CMDS.cmdopts.data.co01startobj = this.CMDS.cmdopts.data.co01startobj or 1
	this.CMDS.cmdopts.meta.ostartobj = this.CMDS.cmdopts.meta.ostartobj or this.CMDS.cmdopts.data.co01startobj
	this.CMDS.cmdopts.data.co02endobj = this.CMDS.cmdopts.data.co02endobj or #this.resultSet
	this.CMDS.cmdopts.meta.oendobj = this.CMDS.cmdopts.meta.oendobj or this.CMDS.cmdopts.data.co02endobj
	this.CMDS.cmdopts.meta.co02endobj[4] = #this.resultSet
	this.cmdset = CPLoopPars:new({tCelPad.Parsers});
	this.cmdset.finderpnt2 = this;
	this.cmdset.finderpnt2.runningTask = 2
	this.cmdset:init("this.cmdset",1,
	function(o) --main
		o.ik = o.ik or o.finderpnt2.CMDS.cmdopts.data.co01startobj
		o.object = o.finderpnt2.resultSet[o.ik]
		if o.finderpnt2.CMDS.mtdlg then
			o.finderpnt2.CMDS.mtdlg.cmdtimer = o.cmdtimer
		end
		if not o.called and o.ik <= #o.finderpnt2.resultSet then
			o.finished = false;
			execCommandSet(o,this,this.CMDS.srctab)
			refreshInfoPanes(o.finderpnt2)
			o.called = true
		end
	end,
	function(o) --xit
		return (o.ik > (o.finderpnt2.CMDS.cmdopts.data.co02endobj or #o.finderpnt2.resultSet))
	end,
	function(o) --quit
		local exstat = "";
		if o.cancelrq then
			exstat = "cancelled";
			if o.cmdtimer then
				o.cmdtimer:killchain();
			end
			nilStatLogs(o.finderpnt2)
		else
			exstat = "finished";
		end;
		if o.finderpnt2.cmdset and o.finderpnt2.cmdset.cmdtimer then
			o.finderpnt2.cmdset.cmdtimer:killchain()
		end
		CPlog("command set "..exstat,0,o.finderpnt2.sysLog,o.finderpnt2.statcmd);
		nilStatLogs(o.finderpnt2)
		o.finderpnt2.statcmd = nil;
		o.finderpnt2.runningTask = 0;
		o.finderpnt2.cmdset = nil;
		o.finderpnt2.CMDS.cmdopts.meta.ostartobj = nil;
		o.finderpnt2.CMDS.cmdopts.meta.oendobj = nil;
		if o.finderpnt2.CMDS.cmdopts.data.co03repeatloop and not o.cancelrq then
			CPlog("commands loop",0,o.finderpnt2.sysLog)
			this:runCommandSet();
		end
	end,
	function(o) --loop
		if o.object and type(o.object) == "userdata" then
			if o.finderpnt2.verblogs then
				local cmd
				if o.cmdtimer then
					cmd = o.cmdtimer.cmdname
				else
					cmd = "no data"
				end
				o.finderpnt2.statcmd = o.finderpnt2.statcmd or #o.finderpnt2.sysLog+1;
				CPlog("command set running on #"..t_str(o.ik).."("..t_str(o.object:name())..")["..t_str(cmd).."]; pack: "..t_str(o.maxinloop),0,o.finderpnt2.sysLog,o.finderpnt2.statcmd)
			end;
			if o.finished then
				o.ik = o.ik + 1
				o.called = false;
				if o.finderpnt2.CMDS.cmdopts.data.co01startobj ~= o.finderpnt2.CMDS.cmdopts.meta.ostartobj then
					CPlog("command set interval change, new starting point (from "..t_str(o.finderpnt2.CMDS.cmdopts.meta.ostartobj).." to "..(o.finderpnt2.CMDS.cmdopts.data.co01startobj or "no data")..")",0,o.finderpnt2.sysLog)
					o.ik = o.finderpnt2.CMDS.cmdopts.data.co01startobj
					o.finderpnt2.CMDS.cmdopts.meta.ostartobj = o.finderpnt2.CMDS.cmdopts.data.co01startobj
				end;
				if o.finderpnt2.CMDS.cmdopts.data.co02endobj ~= o.finderpnt2.CMDS.cmdopts.meta.oendobj then
					CPlog("command set interval change, new finishing point (from "..t_str(o.finderpnt2.CMDS.cmdopts.meta.oendobj)..", to "..(o.finderpnt2.CMDS.cmdopts.data.co02endobj or "no data")..")",0,o.finderpnt2.sysLog)
					o.finderpnt2.CMDS.cmdopts.meta.oendobj = o.finderpnt2.CMDS.cmdopts.data.co02endobj
				end
			end
		else
			if o.ik <= #o.finderpnt2.resultSet then
				cmdError(o.finderpnt2,o,"Invalid or missing object! Item changed in an unexpected manner.")
			end
		end
	end
	);
	this.cmdset:makeBranch(this);
end;
};
