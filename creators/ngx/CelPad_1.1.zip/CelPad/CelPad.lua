-- CelPad.lua

celestia:log("CelPad: loading chasis")

require "CPClass";
tCelPad = {
sysLog = {};
Timers = {
chained = {};
};
Parsers = {
tabIDs = {};
};
};
CelPad = CClass {
classname = "CelPad";
superclass = CPObject;
initialized = function (this,c)
	if c ~= nil then
		this.Initialized = (c ~= false);
		return this;
	else
		return this.Initialized or false;
	end
end;
deinitialized = function (this,c)
	if c ~= nil then
		this.Deinitialized = (c ~= false);
		return this;
	else
		return this.Deinitialized or false;
	end
end;
running = function (this,c)
	if c ~= nil then
		this.Running = (c ~= false);
		return this;
	else
		return this.Running or false;
	end
end;
init_allattr = function(this)
	this.objname = "myCelPad";
	this.tCelPad = tCelPad;
	this.tCelPadFinder = tCelPadFinder;
	this.SavingMSG = {};
	this.LoadingMSG = {};
	this.SavedMSG = {};
	this.closeTab = {};
	this.rstcmdtab = this.rstcmdtab or {};
	fastCleanup = nil;
	this.noconvert = false;
end;
Initialize = function(this)
	if not gCPload then
		require "comLib";
		require "CelPadConfig";
		require "CPBox";
		require "CelPadHUD";
		require "CelPadFinder";
		require "CelPadHELP";
		syslogInit(tCPClass.sysLog)
		syslogInit(tCelPad.sysLog);
		gCPload = true;
		CPlog("CelPad: loaded")
	end;
	startInst = #CPInstances
	if DebugLog	then
		CPlog("CelPad DEBUG: "..#CPInstances.." instances at the start")
	end
	this:init_allattr()
	gVarBinds:gUpdate();
	myCelPadHUD = CelPadHUD:new()
	myCelPadHUD:init()
	CPlog("CelPad: GUI created as "..tostring(myCelPadHUD))
	if table_num(this.rstcmdtab) == 0 then
		this:loadCP("profile","ini");
		if not this.fileConv then
			this:loadCP("SYS","default");
			this:loadCP("GUI","default");
		end
	else
		for i,k in pairs(this.rstcmdtab) do
			k();
			this.rstcmdtab[i] = nil;
		end
	end
	CPSquareWindow.Visible = true;
	this.nilfams = {};
	this:initialized(true)
	this:deinitialized(false)
	CPlog("CelPad: initialized")
end;
Deinitialize = function (this)
	this:initialized(false)
	this:deinitialized(true)
	rmAllRefMarks()
	if ControlPanel then
		ControlPanel.mainFrame.CPFinder = nil
		ControlPanel:wkill();
		ControlPanel = nil;
	end;
	myCelPadHUD:destruct();
	CPlog("CelPad: GUI "..tostring(myCelPadHUD).." closed")
	this.ClosingCPMSG = nil;
	this.saved = nil;
	this.sortedL, this.sortedS = nil,nil;
	this.openSetTimer = nil;
	this.systemSlowTimer = nil;
	IconsReposTimer = nil;
	this:init_allattr()
	CPSquareWindow.Visible = false;
	if restPurgeLogs then
		syslogNil(tCelPad.sysLog)
		syslogInit(tCelPad.sysLog)
		syslogNil(tCelPadHUD.sysLog)
		syslogInit(tCelPadHUD.sysLog)
		syslogNil(tCelPadFinder.sysLog)
		syslogInit(tCelPadFinder.sysLog)
		syslogNil(tCPClass.sysLog)
		syslogInit(tCPClass.sysLog)
	end;
	CPlog("CelPad: closed")
	this.closerq = nil;
	if DebugLog then
		CPlog("CelPad DEBUG: "..#CPInstances.." instances at the end")
	end
	if #CPInstances ~= startInst then
		CPlog("CelPad Alert: inconsistent instances exit status! ("..#CPInstances.."; should be "..startInst..")")
	end
	collectgarbage();
	if table_num(this.rstcmdtab) > 0 then
		CelPadCheck:Action()
	end
end;
CelPadUpdate = function(this)
	if this.Running then
		if not this.Initialized then
			this:Initialize();
		end;
		myCelPadHUD:updateScrRsz();
		--update timers
		for i,v in ipairs(this.tCelPad.Timers) do
			v:update();
		end;
		--update scanners
		for i,v in ipairs(this.tCelPadFinder.runningFinders) do
			v:update();
		end;
		--update logs
		for i,v in ipairs(this.tCelPadFinder.runningLogs) do
			v:update();
		end;
		--update parsers
		for i,v in ipairs(this.tCelPad.Parsers) do
			v:update();
		end;
		-- following updates
		gVarBinds:gUpdate();
		if this.closerq then
			if ControlPanel and not this.ClosingCPMSG then
				this.ClosingCPMSG = PopMessage:new({tCelPadHUD.popMsgs});
				this.ClosingCPMSG:init(ControlPanel.mainFrame,"ClosingCPMSG",x,y,nil,nil,nil,"ok")
				this.ClosingCPMSG:makeBranch(ControlPanel);
				CPlog("CelPad: close request...")
			end;
			for i,v in ipairs(tCelPadFinder.runningFinders) do
				if v.feeder and not v.feeder.cancelrq then
					v.feeder.cancelrq  = true
				end
				if v.runningScan then
					v.cancelscan = true
				end
			end;
			for i,v in ipairs(tCelPadFinder.runningLogs) do
				if v.feeder and not v.feeder.cancelrq then
					v.feeder.cancelrq  = true
				end
				if v.marker and not v.marker.cancelrq then
					v.marker.cancelrq  = true
				end
				if v.cmdset and not v.cmdset.cancelrq then
					v.cmdset.cancelrq  = true
				end
			end;
			for i,v in ipairs(tCelPad.Timers) do
				v.status = "kill";
			end
			if (not (this.saving or this.savingprf)) then
				local finder
				this.saved = this.saved or false
				this.sortedL = this.sortedL or false
				if not this.sortedL then
					if fastCleanup then
						table.sort(this.closeTab,function(a,b)
							local retval
							local acond =  a.nilfam[a.famid][3]
							local bcond =  b.nilfam[b.famid][3]
							if acond == nil and bcond ~= nil then
								retval = true
							end
							return retval
						end)
					end
					this.sortedL = true
				end
				if #this.closeTab >= 1 and this.sortedL then
						finder = this.closeTab[1]
						if not finder.closing then
							finder.wobj.closeButton:Action()
						end;
				elseif not this.saved then
					myCelPadHUD:saveallpos()
					this.saved = true
					CPlog("CelPad: all finders closed, GUI positions saved",0,this.sysLog);
				else
					local tabs = (#tCelPadFinder.runningFinders  + #tCelPadFinder.runningLogs  + #tCelPad.Timers)
					if tabs == 0 then
						this:running(false)
					end
				end;
			end
		end;
		collectgarbage();
	else
		if not this.Deinitialized then
			this:Deinitialize()
		end
	end;
end;
firstRun = function(this,chkconv)
	this.FirstRun = PopMessage:new();
	this.FirstRun:init(CelPadBox,"FirstRun",x,y,nil,nil,nil,"ok");
	this.FirstRun:makeBranch(myCelPadHUD);
	if chkconv then
		this:convertSaves()
	end;
end;
settingsOpened = function(this)
	if ms022OpenSetWarn > 0 then
		this.openSetTimer = CPtimer:new({tCelPad.Timers});
		this.openSetTimer:init("this.openSetTimer","this.openSetTimer",ms022OpenSetWarn,"standalone",0,
		function(o)
			this.CloseSetMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
			this.CloseSetMSG:init(CPSquareWindow,"CloseSetMSG",x,y,nil,nil,nil,"yn",
				function()
					local paneself
					while #tCelPadHUD.setupPanes > 0 do
						paneself = tCelPadHUD.setupPanes[1]
						paneself.closebutton.Action()
					end;
					this.openSetTimer = nil;
				end,
				function()
					this.openSetTimer = nil;
				end
				);
				this.CloseSetMSG:makeBranch(myCelPadHUD);
				this.CloseSetMSG.ynbutton.ynbuttonN.Customdraw = function(this)
				if #tCelPadHUD.setupPanes == 0 then this.Action(this); end;
			end;
		end
		);
		this.openSetTimer:makeBranch(this)
	end
end;
systemMsg = function(this,x,y,cause,finder,lnchfnc,parser)
	if string.find(cause,"1") then
		local setdelay = ms025autoAdaptOn or 4
		local runtask = 0
		for i,v in ipairs(this.tCelPadFinder.runningFinders) do
			runtask = runtask + (v.runningTask or 0)
		end;
		for i,v in ipairs(this.tCelPadFinder.runningLogs) do
			runtask = runtask + (v.runningTask or 0)
		end;
		if runtask > 0 and ControlPanel then
			if not this.systemSlowTimer and tSettings.SystemSet.ms020AdaptiveLoops == false then
				this.systemSlowTimer = CPtimer:new({tCelPad.Timers});
				this.systemSlowTimer:init("this.systemSlowTimer","this.systemSlowTimer",setdelay,"standalone",0,
				function(o)
					if timedelta>sysSlowRisk and tSettings.SystemSet.ms020AdaptiveLoops == false then
						for i,v in ipairs(ControlPanel.mainFrame.popupMenus) do
							if v.objname == "SystemSlowMSG" then
								v.okbutton:Action()
							end
						end
						tSettings.SystemSet.ms020AdaptiveLoops = true;
						gVarBinds.updateGlobals();
						this.SystemSlowMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
						this.SystemSlowMSG:init(ControlPanel.mainFrame,"SystemSlowMSG",x,y,nil,nil,nil,"ok");
						this.SystemSlowMSG:makeBranch(ControlPanel);
					end
					this.systemSlowTimer=nil;
				end
				);
				this.systemSlowTimer:makeBranch(this)
			end
		end
	elseif cause == "fcerr" then
		this.FastCleanErr = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.FastCleanErr:init(ControlPanel.mainFrame,"FastCleanErr",x,y,nil,nil,nil,"ok");
		this.FastCleanErr:makeBranch(ControlPanel);
	elseif cause == "generr" then
		local errlog, objinfo, errhead
		if parser and parser.object then
			if type(parser.object) == "userdata" then
				objinfo = "object: "..parser.object:name()
			else
				objinfo = "< type unknown >"
			end
			errlog = "command error ("..objinfo.."): "..tostring(lnchfnc)
			errhead = "Command error"
		else
			if parser then
				objinfo = tostring(parser)
			end
			errlog = "general error: "..tostring(lnchfnc)
		end
		CPlog("!!! alert: "..errlog,0,finder.sysLog)
		CPlog("CelPad Alert: "..errlog)
		finder.oriframe.genErrMSG = PopMessage:new({finder.oriframe.popupMenus});
		finder.oriframe.genErrMSG:init(finder.oriframe,"genErrMSG",centX(finder.oriframe),centY(finder.oriframe),nil,{
		templates2.popMsg.genErrMSG[1],
		templates2.popMsg.genErrMSG[2],
		(errhead or templates2.popMsg.genErrMSG[3]).." (time: "..time_str..")",
		"(log:"..tostring(finder.sysLog).."; '"..tostring(finder.Header).."')",
		objinfo or "< unspecified >",
		lnchfnc,
		txtfnt = templates2.popMsg.genErrMSG.txtfnt
		},nil,"ok");
		finder.oriframe.genErrMSG:makeBranch(finder.oriframe);
	else
		if string.find(cause,"nillag") then
			finder.nilWarnMSGup = true
			finder.nilToWarnMSG = PopMessage:new({finder.oriframe.popupMenus});
			finder.nilToWarnMSG:init(finder.oriframe,"nilToWarnMSG",centX(finder.oriframe),centY(finder.oriframe),nil,nil,nil,"yn",
			function()
				if finder.niling then
					if finder.alrtlogs then
						CPlog("!!! warning: cleanup loops reset when value reached "..parser.maxinloop,0,finder.sysLog)
					end
					parser.maxinloop = ms010ScanLoop*Fuse
					finder.lagcnt = 1
				end;
				finder.nilWarnMSGup = nil
			end,
			function()
				finder.nilWarnMSGup = nil
			end
			);
			finder.nilToWarnMSG:makeBranch(finder.oriframe);
		else
			local sumlaunch
			local risksmsg = {
			"< autowrap >",
			"<-70",
			"Scan risks:"
			};
			local scanwarn = templates2.scanWarn;
			for i in string.gmatch(cause,"%w+") do
				table.insert(risksmsg,scanwarn[i].msgm)
				sumlaunch = true
			end;
			if sumlaunch then
				table.insert(risksmsg,"")
				table.insert(risksmsg,"Are you sure you want to continue?")
				finder.scanRiskMSG = PopMessage:new({finder.oriframe.popupMenus});
				finder.scanRiskMSG:init(finder.oriframe,"scanRiskMSG",x,y,"Warning",risksmsg,"w","yn",
				function()
					if finder.alrtlogs then
						for i in string.gmatch(cause,"%w+") do
							CPlog(tostring(scanwarn[i].logm),0,finder.sysLog)
						end;
					end
					lnchfnc()
				end,
				function()
					CPlog("### scan aborted",0,finder.sysLog);
					finder.runReady = nil;
				end
				);
				finder.scanRiskMSG:makeBranch(finder);
			end
		end;
	end;
end;
saveCP = function(this,what,savename,finder)
	local deepcopy = deepcopy
	if myCelPad.fileConv then
		tts[what] = ttc[what]
	else
		tts[what] = {};
	end
	local qtype ="";
	if what == "QR" then
		qtype = finder.metaQueryVal.qtype;
	end;
	local profileFile = profileDIR..savename.."_"..what..qtype..".cpsv1";
	local savefile = io.open(profileFile, "w");
	if not savefile then
		CPlog("CelPad Alert: save failed, directory inaccessible!")
		this.SaveFailMSG = PopMessage:new({tCelPadHUD.popMsgs});
		this.SaveFailMSG:init(CelPadBox,"SaveFailMSG",x,y,nil,{
		templates2.popMsg.SaveFailMSG[1]..savename.." "..what..templates2.popMsg.SaveFailMSG[2],
		"",
		templates2.popMsg.SaveFailMSG[3],
		templates2.popMsg.SaveFailMSG[4]..profileDIR,
		"",
		templates2.popMsg.SaveFailMSG[5],
		templates2.popMsg.SaveFailMSG[6],
		txtfnt = templates2.popMsg.SaveFailMSG.txtfnt;
		},nil,"ok");
		this.SaveFailMSG:makeBranch(myCelPadHUD);
	else
		if not myCelPad.fileConv then
			if what == "GUI" then
				tts.GUI[1] = deepcopy(tSettings.Windows);
				tts.GUI[2] = deepcopy(tSettings.WindowsAdv);
				tts.GUI[3] = deepcopy(tSettings.WindowsAdvMW);
				tts.GUI[4] = deepcopy(tSettings.WindowsAdvMN);
				tts.GUI[5] = deepcopy(tSettings.WindowsAdvCP);
				tts.GUI[6] = deepcopy(tSettings.WindowsAdvPM);
				tts.GUI[7] = deepcopy(tDeltaSettings);
			elseif string.sub(what,1,2) == "QR" then
				finder.metaQueryVal["zz1_scan_within"]["valuelist"][1] = deepcopy(templates.metaQuery.zz1_scan_within.valuelist[1])
				finder.metaQueryVal["zz1_scan_within"]["valuelist"][2] = deepcopy(templates.metaQuery.zz1_scan_within.valuelist[2])
				finder.metaQueryVal["zz1_scan_pure"]["valuelist"][1] = deepcopy(templates.metaQuery.zz1_scan_pure.valuelist[1])
				tts[what][1] = deepcopy(finder.queryVal);
				tts[what][2] = deepcopy(finder.metaQueryVal);
			elseif what == "SYS" then
				tts.SYS[1] = deepcopy(tSettings.SystemSet);
				tts.SYS[2] = deepcopy(templates.minMaxDefault);
				tts.SYS[3] = deepcopy(templates.metaUnits);
			elseif what == "profile" then
				tts.profile[1] = deepcopy(tProfiles);
				tts.profile[2] = deepcopy(lastwindow);
				this.savingprf = true;
				local iniparser = CPTabPars:new({tCelPad.Parsers})
				iniparser:init("iniparser",tts[what],LoadLoop,
				function(o)
					savefile:write("tts."..tostring(what)..tostring(o.tabindexstr).."="..tostring(o.tabvalstr)..";\n");
				end,
				function(o)
					savefile:close();
					this.savingprf = nil;
					tts.profile = nil;
					tts.profile = {};
				end,
				function(o)
				end
				);
				iniparser:makeBranch(this);
			elseif what ~= "" then
				if finder then
					if finder[what].mtdlg then
						tts[what][1] = deepcopy(finder[what].mtdlg.menutab);
						tts[what][2] = deepcopy(finder[what].mtdlg.metatab);
					else
						tts[what][1] = deepcopy(finder[what].srctab.data);
						tts[what][2] = deepcopy(finder[what].srctab.meta);
					end;
				end;
			end;
		end
		if what ~= "profile" then
			if not myCelPad.fileConv and string.sub(what,1,2) == "QR" and #finder.openQueries == 0 then
				return;
			else
				local msgtgt
				if finder then
					msgtgt = finder.sysLog
				end
				if myCelPad.fileConv then
					templates2.popMsg.SavingMSG[1] = "Converting "
				else
					templates2.popMsg.SavingMSG[1] = "Saving "
				end
				CPlog("saving "..tMetaSettings["Saves"..what].hiname.." '"..savename.."'",0,msgtgt or tCelPad.sysLog);
				this.SavingMSG[what] = PopMessage:new({tCelPadHUD.popMsgs});
				this.SavingMSG[what]:init(CelPadBox,"SavingMSG",x,y,nil,{
				templates2.popMsg.SavingMSG[1]..tMetaSettings["Saves"..what].hiname.." '"..savename.."'.",
				templates2.popMsg.SavingMSG[2],
				templates2.popMsg.SavingMSG[3],
				txtfnt = templates2.popMsg.SavingMSG.txtfnt;
				},nil,"ok");
				this.SavingMSG[what]:makeBranch(myCelPadHUD);
				this.SavingMSG[what].okbutton.Action = (function()
					return
					function()
					end
				end) ();
				this.saving = true;
				local tabparser = CPTabPars:new({tCelPad.Parsers})
				local svtable = tts[what]
				local t_str = tostring
				local tabid = t_str(svtable)
				tabparser:init("tabparser",svtable,LoadLoop,
				function(o)
					if string.find(t_str(o.tabvalstr),"^\".*\"$") then
						local purestr = string.gsub(o.tabvalstr,"^\"(.*)\"$","%1")
						purestr = string.gsub(purestr,"([\(\)]+)","\\%1")
						purestr = string.gsub(purestr,"([\"]+)","\\%1")
						purestr = string.gsub(purestr,"([\[]+)","\\%1")
						purestr = string.gsub(purestr,"([\]]+)","\\%1")
						purestr = string.gsub(purestr,"([\{\}]+)","\\%1")
					o.tabvalstr = "\""..purestr.."\""
					end
					local writestr = "tts."..t_str(what)..t_str(o.tabindexstr).."="..t_str(o.tabvalstr)..";\n"
					writestr = string.gsub(writestr,"1.#INF","math.huge");
					local conprefx
					if o.tabcons then
						for g,h in ipairs(tCelPad.Parsers.tabIDs[tabid]) do
							if conprefx then
								conprefx = conprefx.."tts."..what..h.."={};\n"
							else
								conprefx = "tts."..what..h.."={};\n"
							end
							tCelPad.Parsers.tabIDs[tabid][g]=nil
						end
					end;
					savefile:write((conprefx or "")..writestr);
				end,
				function(o)
					savefile:close();
					if this.SavingMSG[what] then
						this.SavingMSG[what]:quitpopup(CelPadBox)
						this.SavingMSG[what] = nil
					end;
					this.saving = nil;
					svtable = nil;
					svtable = {};
					this.SavedMSG[what] = PopMessage:new({tCelPadHUD.popMsgs});
					this.SavedMSG[what]:init(CelPadBox,"SavedMSG-"..what,x,y,"Info",{
					tMetaSettings["Saves"..what].hiname.." '"..savename.."' saved.",
					txtfnt = {"normalfont"};
					},"i","ok",2)
					this.SavedMSG[what]:makeBranch(myCelPadHUD);
				end,
				function(o)
				end
				);
				tabparser:makeBranch(this);
			end;
		end;
	end;
end;
loadCP = function(this,what,savename,finder)
	local tabrnd = string.sub(tostring(math.random()),3)
	tts[what..tabrnd] = nil;
	tts[what..tabrnd] = {};
	ttl[what..tabrnd] = nil;
	ttl[what..tabrnd] = {};
	local profileFile = profileDIR..savename.."_"..what..".cpsv1";
	local savefile, msg = io.open(profileFile, "r");
	local t_ins = table.insert
	local constr
	if savefile == nil then
		CPlog("CelPad Warning: file "..savename.."_"..what.." missing, creating from current values...")
		if what == "profile" then
			this:firstRun(true)
			return "nok";
		elseif string.sub(what,1,2) == "QR" then
			this:saveCP(what,savename,finder);
			return "nok";
		elseif what ~= "" then
			this:saveCP(what,savename,finder);
			return "nok";
		end;
	end;
	if what == "GUI" then
		t_ins(tts["GUI"..tabrnd],tSettings.Windows);
		t_ins(tts["GUI"..tabrnd],tSettings.WindowsAdv);
		t_ins(tts["GUI"..tabrnd],tSettings.WindowsAdvMW);
		t_ins(tts["GUI"..tabrnd],tSettings.WindowsAdvMN);
		t_ins(tts["GUI"..tabrnd],tSettings.WindowsAdvCP);
		t_ins(tts["GUI"..tabrnd],tSettings.WindowsAdvPM);
		t_ins(tts["GUI"..tabrnd],tDeltaSettings);
	elseif string.sub(what,1,2) == "QR" then
		t_ins(tts[what..tabrnd],finder.queryVal);
		t_ins(tts[what..tabrnd],finder.metaQueryVal);
		for t=1,#finder.openQueries do
			for i,v in ipairs (finder.openQueries[t].menupane.popupMenus) do
				v.closebutton:Action()
			end
		end;
	elseif what == "SYS" then
		t_ins(tts["SYS"..tabrnd],tSettings.SystemSet);
		t_ins(tts["SYS"..tabrnd],templates.minMaxDefault);
		t_ins(tts["SYS"..tabrnd],templates.metaUnits);
	elseif what == "profile" then
		t_ins(tts.profile,tProfiles);
		t_ins(tts.profile,lastwindow);
		local iniparser = CPLoopPars:new({tCelPad.Parsers})
		iniparser:init("iniparser",LoadLoop,
		function(o)
			o.fline = savefile:read("*line")
			if o.fline then
				o.statloadlog2 = o.statloadlog2 or #tCelPadHUD.sysLog+1;
				loadstring(o.fline)();
			end;
		end,
		function(o)
			if o.fline then return false else
				return true
			end;
		end,
		function(o)
			savefile:close();
			tts[what..tabrnd] = nil;
			ttl[what..tabrnd] = nil;
			this.loading = nil;
		end
		);
		iniparser:makeBranch(this);
	elseif what ~= "" then
		constr = true
		if finder then
			if finder[what].mtdlg then
				t_ins(ttl[what..tabrnd],finder[what].mtdlg.menutab);
				t_ins(ttl[what..tabrnd],finder[what].mtdlg.metatab);
			else
				t_ins(ttl[what..tabrnd],finder[what].srctab.data);
				t_ins(ttl[what..tabrnd],finder[what].srctab.meta);
			end;
		end;
	end;
	if what ~= "profile" then
		local msgtgt
		if finder then
			msgtgt = finder.sysLog
		end
		CPlog("loading "..tMetaSettings["Saves"..what].hiname.." '"..savename.."'",0,msgtgt or tCelPad.sysLog);
		this.loading = true;
		local tabparser = CPLoopPars:new({tCelPad.Parsers})
		tabparser:init("tabparser",LoadLoop,
		function(o)
			o.fline = savefile:read("*line")
			if o.fline then
				o.fline = string.gsub(o.fline,"(tts\.[^\[]+)","%1"..tabrnd)
				if string.find(o.fline,"=\{\};") and not constr then
				else
					loadstring(o.fline)();
				end;
			end;
		end,
		function(o)
			if o.fline then return false else
				return true
			end;
		end,
		function(o)
			savefile:close();
			if constr then
				for k,v in ipairs(tts[what..tabrnd]) do
					for i,t in pairs(tts[what..tabrnd][k]) do
						ttl[what..tabrnd][k][i] = deepcopy(tts[what..tabrnd][k][i])
					end
				end
			end;
			if finder and finder[what] and finder[what].mtdlg then
				finder[what].mtdlg:moveItem(-1,"load")
				if finder[what].mtdlg.menupane.btnselfAPL then
					finder[what].mtdlg.menupane.btnselfAPL:Action()
				end
			end;
			IconsRepos = true
			tts[what..tabrnd] = nil;
			ttl[what..tabrnd] = nil;
			this.loading = nil;
			gVarBinds.updateGlobals(true);
		end
		);
		tabparser:makeBranch(this);
	end;
	return "ok";
end;
deleteCP = function(this,what,savename)
	local profileFile
	if what == "QR" then
		profileFile = profileDIR..savename.."_"..what.."stars"..".cpsv1";
		os.remove(profileFile);
		profileFile = profileDIR..savename.."_"..what.."satellites"..".cpsv1";
		os.remove(profileFile);
		profileFile = profileDIR..savename.."_"..what.."dsos"..".cpsv1";
		os.remove(profileFile);
		profileFile = profileDIR..savename.."_"..what.."locations"..".cpsv1";
		os.remove(profileFile);
	else
		profileFile = profileDIR..savename.."_"..what..".cpsv1";
		os.remove(profileFile);
	end;
end;
convertSaves = function(this)
	local oldIni, msg = io.open(profileDIR.."ini_profile.cpsav","r")
	local prfTab = {};
	local prftabIndx, fwarn
	local frec1 = {};
	local deepcopy = deepcopy
	local s_sub, s_gsub, t_ins, s_find = string.sub, string.gsub, table.insert, string.find
	local chkSkip = function(str)
		local skip
		if s_find(str,"ttc\.[VW,SUM]+[\[][2][\]][\[][0-9]+[\]][\[][2][\]]=1;") or
		s_find(str,"ttc\.[VW,SUM]+[\[][2][\]][\[]\"argTbl\"[\]][\[][0-9]+[\]][\[]\"[delim,cstname]+\"[\]][\[][2][\]]=1;") or
		s_find(str,"ttc\.SYS[\[][3][\]][\[]\"qr018_oblateness\"[\]]") or
		s_find(str,"ttc\.SYS[\[][3][\]][\[]\"qr008_absoluteMagnitude\"[\]]") or
		s_find(str,"ttc\.SYS[\[][3][\]][\[]\"qr019_albedo\"[\]]") or
		s_find(str,"ttc\.SYS[\[][3][\]][\[]\"qr009_bolometricMagnitude\"[\]]")
		then
			skip = true
		end
		return skip
	end
	local chkChange = function(str)
		if s_find(str,"ms190OpenSetWarn") then
			str = s_gsub(str,"ms190OpenSetWarn","ms022OpenSetWarn")
		elseif s_find(str,"ms200autoAdaptOn") then
			str = s_gsub(str,"ms200autoAdaptOn","ms025autoAdaptOn")
		elseif s_find(str,"ms090ShowPos") then
			str = s_gsub(str,"ms090ShowPos","ms036ShowPos")
		elseif s_find(str,"ms100ShowCat") then
			str = s_gsub(str,"ms100ShowCat","ms037ShowCat")
		elseif s_find(str,"ms110sumShowNames") then
			str = s_gsub(str,"ms110sumShowNames","ms038sumShowNames")
		elseif s_find(str,"ms165ShowScanWarnings") then
			str = s_gsub(str,"ms165ShowScanWarnings","ms055ShowScanWarnings")
		elseif s_find(str,"ms300fastCleanup") then
			str = s_gsub(str,"ms300fastCleanup","ms131fastCleanup")
		elseif s_find(str,"ms400updateOpened") then
			str = s_gsub(str,"ms400updateOpened","ms132updateOpened")
		end
		return str
	end
	local ldProfile = function(this,savefile)
		local frecord, fprfrec
		this.loading = true;
		for k,v in pairs(tProfiles) do
			if k ~= "SavesCMDS" then
				tProfiles[k].savename.valuelist = {};
			end
		end
		local tabparser = CPLoopPars:new({tCelPad.Parsers})
		tabparser:init("tabparser",LoadLoop,
		function(o)
			o.fline = savefile:read("*line")
			if o.fline then
				if s_sub(o.fline,1,14) == "tts.profile[1]" then
					if s_find(o.fline,"valuelist") then
						frecord = s_gsub(o.fline,".*Saves","")
						frecord = s_gsub(frecord,"\".*","")
						frecord = s_gsub(o.fline,"\";","").."_"..frecord
						frecord = s_gsub(frecord,".*\"","")..".cpsav"
						if s_sub(frecord,1,12) ~= "< new save >" then
							t_ins(prfTab,frecord)
							fprfrec = s_gsub(o.fline,"tts.profile[\[]1[\]]","tProfiles")
							loadstring(fprfrec)();
						end
					end
				elseif s_sub(o.fline,1,14) == "tts.profile[2]" then
					frecord = "lastwindow"..s_sub(o.fline,15)
					loadstring(frecord)();
				end
			end;
		end,
		function(o)
			if o.fline then return false else
				return true
			end;
		end,
		function(o)
			savefile:close();
			this.loading = nil;
		end
		);
		tabparser:makeBranch(this);
	end;
	local ldFile = function(this,savefile,lwhat,lname,tmpFinder)
		local frecord
		this.loading = true;
		local tabparser = CPLoopPars:new({tCelPad.Parsers})
		tabparser:init("tabparser",LoadLoop,
		function(o)
			o.fline = savefile:read("*line")
			if o.fline then
				frecord = s_gsub(o.fline,"tts.","ttc.")
				if not chkSkip(frecord) then
					loadstring(chkChange(frecord))();
				end
			end;
		end,
		function(o)
			if o.fline then return false else
				return true
			end;
		end,
		function(o)
			savefile:close();
			this.loading = nil;
			prfTab[prftabIndx] = nil
			CPlog("CelPad: converting '"..lname.."_"..lwhat.."'")
			this:saveCP(lwhat,lname,tmpFinder)
		end
		);
		tabparser:makeBranch(this);
	end;
	if oldIni == nil then
		CPlog("CelPad: old 'ini_profile.cpsav' missing, conversion is not applicable")
		this:saveCP("profile","ini");
	else
		this.fileConv = true;
		this.convStartMSG = PopMessage:new();
		this.convStartMSG:init(CelPadBox,"convStartMSG",x,y,nil,
		{
		templates2.popMsg.convStartMSG[1],
		templates2.popMsg.convStartMSG[2],
		templates2.popMsg.convStartMSG[3]..profileDIR..templates2.popMsg.convStartMSG[4],
		"",
		templates2.popMsg.convStartMSG[5],
		"",
		templates2.popMsg.convStartMSG[6],
		templates2.popMsg.convStartMSG[7],
		"",
		templates2.popMsg.convStartMSG[8],
		templates2.popMsg.convStartMSG[9],
		"",
		templates2.popMsg.convStartMSG[10],
		txtfnt = templates2.popMsg.convStartMSG.txtfnt;
		}
		,nil,"yn",
		function()
			CPlog("CelPad: conversion started")
			ldProfile(this,oldIni)
			local lwhat, lname
			local tmpFinder = CelPadScanner:new({tCelPadFinder.runningFinders,myCelPad.closeTab});
			tmpFinder:init("tmpFinder","tmpFinder");
			tmpFinder:makeBranch(this)
			local convFiles = CPLoopPars:new({tCelPad.Parsers})
			convFiles:init("convFiles",1,
			function(o)
				prftabIndx = #prfTab
				if prfTab[prftabIndx] and not this.loading and not this.saving then
					fileName = prfTab[prftabIndx]
					lwhat = s_gsub(s_gsub(fileName,".*_",""),".cpsav","")
					lname = s_gsub(fileName,"_[^_]+.cpsav","")
					ttc = deepcopy(templates.tts)
					if lwhat == "SYS" then
						t_ins(ttc.SYS,deepcopy(tSettings.SystemSet))
						t_ins(ttc.SYS,deepcopy(templates.minMaxDefault));
						t_ins(ttc.SYS,deepcopy(templates.metaUnits));
					elseif lwhat == "QRlocations" then
						t_ins(ttc.QRlocations,deepcopy(tmpFinder.queryLocations))
						t_ins(ttc.QRlocations,deepcopy(tmpFinder.metaQueryLocations))
					elseif lwhat == "QRstars" then
						t_ins(ttc.QRstars,deepcopy(tmpFinder.queryStars))
						t_ins(ttc.QRstars,deepcopy(tmpFinder.metaQueryStars))
					elseif lwhat == "QRsatellites" then
						t_ins(ttc.QRsatellites,deepcopy(tmpFinder.queryPlanets))
						t_ins(ttc.QRsatellites,deepcopy(tmpFinder.metaQueryPlanets))
					elseif lwhat == "QRdsos" then
						t_ins(ttc.QRdsos,deepcopy(tmpFinder.queryDsos))
						t_ins(ttc.QRdsos,deepcopy(tmpFinder.metaQueryDsos))
					elseif lwhat == "VW" then
						t_ins(ttc.VW,deepcopy(tmpFinder.VW.srctab.data))
						t_ins(ttc.VW,deepcopy(tmpFinder.VW.srctab.meta))
					elseif lwhat == "SUM" then
						t_ins(ttc.SUM,deepcopy(tmpFinder.SUM.srctab.data))
						t_ins(ttc.SUM,deepcopy(tmpFinder.SUM.srctab.meta))
					elseif lwhat == "GUI" then
						t_ins(ttc.GUI,deepcopy(tSettings.Windows));
						t_ins(ttc.GUI,deepcopy(tSettings.WindowsAdv));
						t_ins(ttc.GUI,deepcopy(tSettings.WindowsAdvMW));
						t_ins(ttc.GUI,deepcopy(tSettings.WindowsAdvMN));
						t_ins(ttc.GUI,deepcopy(tSettings.WindowsAdvCP));
						t_ins(ttc.GUI,deepcopy(tSettings.WindowsAdvPM));
						t_ins(ttc.GUI,deepcopy(tDeltaSettings));
					elseif lwhat == "CMDS" then
					end
					oldFile, msg = io.open(profileDIR..fileName,"r");
					if oldFile then
						ldFile(this,oldFile,lwhat,lname,tmpFinder)
					else
						CPlog("CelPad Warning: file '"..fileName.."' defined in 'ini_profile' not found. File will be created from currently used values.")
						this.loading = nil;
						fwarn = true;
						prfTab[prftabIndx] = nil
					end
				end
			end,
			function(o)
				return (prftabIndx == 0)
			end,
			function(o)
				tmpFinder:closeFinder();
				tmpFinder:destruct();
				this.fileConv = nil;
				local msgtbl
				if fwarn then
					msgtbl = "convEnd2MSG";
				else
					msgtbl = "convEnd1MSG"
				end
				t_ins(myCelPad.rstcmdtab,
				function()
					this:loadCP("SYS","default");
					this:loadCP("GUI","default");
					this.convEnd = PopMessage:new({tCelPadHUD.popMsgs});
					this.convEnd:init(CelPadBox,msgtbl,x,y,nil,nil,nil,"ok")
					this.convEnd:makeBranch(myCelPadHUD);
					this.convEnd.okbutton.Action = (function()
						return
						function(this)
							if this.wobj.MSGtimer then
								this.wobj.MSGtimer.status = "kill";
								this.wobj.MSGtimer = nil;
							end;
							this.box = this.wobj:quitpopup(this.btnbox);
						end
					end) ();
				myCelPad:firstRun()
				end);
				this.noconvert = true
				CelPadCheck:Action()
			end,
			function(o)
			end
			)
			convFiles:makeBranch(this)
		end,
		function()
			this.saved = true
			this.fileConv = nil;
			this.noconvert = true
			CelPadCheck:Action()
			this:deleteCP("profile","ini")
		end
		)
		this.convStartMSG:makeBranch(myCelPadHUD)
	end
end;
}
CPtimer = CClass {
classname = "CPtimer";
superclass = CPObject;
init = function(this,objname,TimerID,delay,TimerType,seq,what,quit)
	this.objname=objname;
	this.delay = delay;
	this.start = os.clock();
	this.what = what;
	this.quit = quit
	this.TimerType = TimerType;
	this.seq = seq;
	this.TimerID = TimerID;
	this.status = "undefined";
	this.chainSTARTdone = false;
	this.chain_last = 1;
	this.reset = false;
	if this.TimerType == "chainEND" or this.TimerType == "chainSTART" then
		this.status = "queued";
		this.chain = {};
		tCelPad.Timers.chained[TimerID] = tCelPad.Timers.chained[TimerID] or {};
		tCelPad.Timers.chained[TimerID][seq] = this
	end;
	if this.TimerType == "standalone" or this.seq == 1 then
		this.status = "active";
	end;
	this.timetoend = (this.start+this.delay)-os.clock();
end;
update = function(this)
	if this.reset then
		this.start = os.clock();
		this.reset = false;
	end;
	if this.chain_last then
		if this.status == "unfrozen" and  this.chain_last == this.seq then
			this.status = "active";
			this.delay = this.delay_next;
			this.start = os.clock();
		end;
	end;
	if this.status ~= "frozen" then
		if this.status == "active" or this.status == "execute" or this.status == "kill" then
			this.timetoend = (this.start+this.delay)-os.clock();
			this.delay_next = this.timetoend;
			if this.status == "execute" or this.status == "kill" then
				this.timetoend = 0;
			end;
			if this.TimerType == "chainSTART" then
				if this.chainSTARTdone == false then
					if this.status ~= "kill" then
						this:what()
					end
					this.chainSTARTdone = true;
				end;
				if this.timetoend <= 0 then
					this:timerend()
				end;
			else
				if this.timetoend <= 0 then
					if this.status ~= "kill" then
						this:what()
						this:timerend()
					else
						this:timerend()
					end;
				end;
			end;
		end;
	end;
end;
timerend = function(this)
	local maxmin = maxmin
	local t_ins = table.insert
	this.timetoend = 0
	if this.TimerType == "chainEND" or this.TimerType == "chainSTART" then
		this.chain = this.chain or {};
		for i,v in ipairs(tCelPad.Timers) do
			if v.TimerID == this.TimerID and not (v.seq == this.seq) then
				t_ins(this.chain,v.seq);
			end;
		end;
		this.chain_max, this.chain_min = maxmin(this.chain);
		for i,v in ipairs(tCelPad.Timers) do
			if v.TimerID == this.TimerID and v.seq == this.chain_min then
				v.start = os.clock();
				v.chain_last = this.chain_min;
				v.delay_next = v.delay;
				if v.status == "queued" or v.status == "unfrozen" then
					v.status = "active";
				end;
			end;
		end;
		if #this.chain == 0 then
			tCelPad.Timers.chained[this.TimerID] = nil;
		end
	end;
	if this.quit then
		this:quit()
	end
	this.status = "finished"
	this:destruct();
end;
killchain = function(this)
	if this.status ~= "finished" and this.status ~= "kill" then
		for i,v in ipairs(tCelPad.Timers) do
			if v.TimerID == this.TimerID then
				v.status = "kill";
			end
		end
	end
end;
};
CPTabPars = CClass {
classname = "CPTabPars";
superclass = CPObject;
init = function(this,objname,intable,scanloop,fnctodo,fnctofin,fncinloop,tabprefix,oritable,tabcons,tabid)
	this.objname=objname;
	this.scanloop = scanloop
	this.maxinloop = scanloop or 0;
	this.intable = intable;
	this.oritable = oritable or intable;
	this.fnctodo = fnctodo;
	this.fnctofin = fnctofin;
	this.fncinloop = fncinloop
	this.branches = {};
	this.oldnxt = nil
	this.tabprefix = (tabprefix or "");
	this.tabcons = tabcons
	if not tabid then
		this.tabid = tostring(intable)
		tCelPad.Parsers.tabIDs[this.tabid] = {};
	else
		this.tabid = tabid
	end
end;
update = function(this)
	local lcFuse = Fuse
	local ltabcons
	this.maxinloop = math.ceil(this.scanloop*lcFuse)
	this.ii = 1
	while this.ii <= this.maxinloop do
		if #this.branches == 0 then
			local k = next(this.intable,this.oldnxt)
			if k == nil or this.cancelrq then
				if this.fnctofin then
					this.fnctofin(this);
					tCelPad.Parsers.tabIDs[this.tabid] = nil;
				end;
				tCelPad.Parsers.tabIDs[this.tabid] = {};
				this:quit();
				break;
			end;
			local wh = this.intable[k]
			this.whtype = type(wh)
			if this.whtype=="string" then
				this.tabvalstr = "\""..wh.."\"";
			elseif this.whtype=="number" then
				this.tabvalstr = string.gsub(wh,",",".");
			else
				this.tabvalstr = wh;
			end;
			if tonumber(k) == nil then
				xk = "\""..k.."\"";
			else
				xk = k;
			end;
			if this.whtype == "table" then
				this.wtblindx = string.gsub(string.gsub(string.gsub(this.tabprefix,"%-%-","]["),"^%-","["),"%-$","]")
				if k and this.wtblindx then
					if type(k) == "string" then
						ltabcons = this.wtblindx.."[\""..k.."\"]"
					else
						ltabcons = this.wtblindx.."["..k.."]"
					end
					this.tabcons = ltabcons
					table.insert(tCelPad.Parsers.tabIDs[this.tabid],ltabcons)
				end;
				this.parser = CPTabPars:new({tCelPad.Parsers})
				this.parser:init("parserX-"..this.objname..":"..this.ii,wh,this.maxinloop,this.fnctodo,nil,nil,this.tabprefix.."-"..xk.."-",this.oritable,this.tabcons,this.tabid)
				this.parser:makeBranch(this)
			else
				this.tabindexstr = string.gsub(string.gsub(string.gsub(this.tabprefix,"%-%-","]["),"^%-","["),"%-$","]").."["..xk.."]"
				this.k = k
				this.wh = wh
				this.xk = xk
				this.fnctodo(this)
				this.tabcons = nil
			end;
			this.oldnxt = k;
			this.ii = this.ii + 1
		else
			break;
		end;
	end;
	if this.fncinloop then
		this.fncinloop(this)
	end;
end;
quit = function(this)
	this.intable = nil;
	this.oritable = nil;
	this:destruct()
end;
};
CPLoopPars = CClass {
classname = "CPLoopPars";
superclass = CPObject;
init = function(this,objname,scanloop,fnctodo,fnctoxit,fnctofin,fncinloop)
	this.objname=objname;
	this.scanloop = scanloop;
	this.maxinloop = scanloop;
	this.fnctodo = fnctodo;
	this.fnctoxit = fnctoxit;
	this.fnctofin = fnctofin;
	this.fncinloop = fncinloop;
	this.tabprefix = (tabprefix or "");
end;
update = function(this)
	if not this.paused then
		local lcFuse = Fuse
		if this.objname~="nilparser" then
			this.maxinloop = math.ceil(this.scanloop*lcFuse)
		end;
		this.ii = this.maxinloop
		if not this.cancelrq then
			for ii=1,this.maxinloop do
				this.fnctodo(this)
				this.ii = this.ii - 1
				if this.fnctoxit(this) then
					break;
				end;
			end;
		end
		if this.fncinloop and not this.cancelrq then
			this.fncinloop(this)
		end;
		if this.cancelrq or this.fnctoxit(this) then
			this.fnctofin(this)
			this:quit();
		end;
	else
		if this.cancelrq then
			if this.finderpnt1 then this.finderpnt1.paused = false; end;
			if this.finderpnt2 then this.finderpnt2.paused = false; end;
			this.paused = false;
		end
	end
end;
quit = function(this)
	this:destruct()
end;
};
celestia:log("CelPad: chasis loaded")
