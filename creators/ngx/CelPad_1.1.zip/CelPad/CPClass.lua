-- CPClass.lua
-- based on code CXClass.lua, Lua Edu Tools

celestia:log("CelPad: loading modified class model")

CPInstances = {};
CPClasses = {};
tCPClass = {
sysLog = {
};
}
CClass = function(newmetatable)
	local newclass;
	if CPClass then
		newclass = CPClass:new();
	else
		newclass = newmetatable;
	end;
	newclass.__index = newmetatable;
	if type(newmetatable.superclass) == "table" then
		setmetatable(newmetatable,newmetatable.superclass);
	end;
	return newclass;
end;
CPClass = CClass {
classname = "CPClass";
new = function (o,t)
	local t_ins = table.insert
	local newinstance = {};
	setmetatable(newinstance,o);
	if newinstance.classname == "CPClass" then
		t_ins(CPClasses, newinstance);
	else
		t_ins(CPInstances, newinstance);
	end;
	if t then
		newinstance.itables = {}
		for i,v in ipairs(t) do
			t_ins(v,newinstance)
			t_ins(newinstance.itables, v)
		end
	end
	newinstance.MSGupT = {};
	return newinstance;
end;
kill = function (o)
	table.remove(CPInstances,o:tindex(CPInstances))
	o.MSGupT = nil;
	o = nil;
	return (o);
end;
superclass = function (o)
	return getmetatable(o.__index);
end;
}
CPObject = CClass {
classname = "CPObject";
superclass = CPClass;
objname = "unnamed";
objtype = "generic";
makeBranch = function(o,trunk)
	trunk.branches = trunk.branches or {}
	o.trunks = o.trunks or {}
	table.insert(trunk.branches, o)
	table.insert(o.trunks, trunk)
end;
removeBranch = function (o,extrunk)
	for i,v in ipairs(o.trunks) do
		if v == extrunk then
			table.remove(o.trunks,v:tindex(o.trunks))
			for i1,v1 in ipairs(extrunk.branches) do
				if v1 == o then
					table.remove(extrunk.branches,v1:tindex(extrunk.branches))
				end
			end
		end
	end;
end;
tindex = function(o,t)
	local index;
	for i,v in ipairs(t) do
		if v == o then
			index = i;
		end
	end;
	return index;
end;
destruct = function (o)
	if o.branches then
		local exbranch
		while #o.branches > 0 do
			exbranch = o.branches[#o.branches]
			exbranch:destruct()
		end;
	end;
	if o.trunks then
		for i,v in ipairs(o.trunks) do
			table.remove(v.branches,o:tindex(v.branches))
		end;
	end;
	if o.itables then
		for i,v in ipairs(o.itables) do
			table.remove(v,o:tindex(v))
		end
	end;
	if o.Parent then
		if o.Parent.attachments then
			table.remove(o.Parent.attachments, o:tindex(o.Parent.attachments))
		end
	end;
	o:kill();
	return nil;
end;
}
