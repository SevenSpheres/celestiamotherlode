############
CelPad v.1.1
(c) ngx 2013
############

CelPad is plugin for Lua Edu Tools v.1.2 Beta, developed and tested on Celestia 1.6.1.

CelPad is a tool with simple graphical interface (GUI), which searches for Celestia objets and allows to perform some commands, like 'go to' or 'mark' and others. Searches are based on defined object parameters. It is working with stars, orbiting bodies, deep space objects and locations. CelPad scans through Celestia objects by means of editable queries, which define objects' attributes that should be searched for (name, radius, type etc.). Query definitions can be saved to files on HDD for future re-use.

There are also many editable settings for GUI appearence and behaviour, as well as for other CelPad functions. You can try various settings combinations to make CelPad match your requirements. CelPad settings profiles can also be saved to files.

Version 1.1 provides also possibility to define, save and run set of configurable Celestia commands (including free LUA code definition) applied to objects in Selection Pad.

Refer to application Help panes ('?' buttons) for detailed usage information.


### CREDITS ###
Many thanx to:

-Creators of Lua Edu Tools - Vincent Giangiulio and Hank Ramsey - for their master code. CPBox and CPClass files are modified code from Lua Edu Tools with kind permission from Vincent Giangiulio.

-Jogad for inspiration and very good learning material in the 'slideshow' plugin.

-lua-users.org and snippets.luacode.org for some very useful functions.


### PREREQUISITIES ###

-Celestia 1.6.1. Not extensively tested on 1.6.0, but should work. Definitely, will not work on Celestia 1.5 and older. Tested only on Windows PCs.
-Lua Edu Tools 1.2 Beta8 (download from http://www.celestiamotherlode.net/creators/v_giangiulio/Lua_Edu_Tools_1.2beta8.zip) or unofficial Vincent's 'Lua Edu Tools 1.2beta9' (http://gvince.perso.sfr.fr/celestia/lua/, thanx to Marco Klunder for advice and instructions).
-To save CelPad profiles, Celestia must have read/write access to its ..\extras\ directory. If saves are not permitted, CelPad will work, however settings will not be saved and unpredictable errors may occure.


### INSTALLATION ###

1. Check installation prerequisities (see bulletpoints above). Make sure 'Lua Edu Tools' are correctly installed and functional. Refer to included README_Lua_Edu_Tools.txt if needed.

2. Extract CelPad directory from CelPad.zip archive into Celestia's \extras\ directory (usually C:\Program Files\Celestia\extras\). If you want to use different directory within Celestia's \extras\ (i.e. Lua Edu Tools' '\adds\'), edit 'profileDIR' property on the beginning of 'CelPadConfig.lua' file accordingly.
If upgrading from version 1.0 (do not forget to make backup of your old installation), copy files OVER the old ones.

3. If you are doing fresh install, edit config.lua file in ...\Celestia\extras\lua_edu_tools\ directory as follows (if doing upgrade, this would be already present):
3.1 Find 'toolset' section (starts around line 47 in original file).
3.2 Add "CelPadBox", (including double quotes and comma) entry before "compassBox", entry, like this:

        "HRBox",
        "KeplerParamBox",
        "CelPadBox", -- <- CelPad checkbox entry
        --"virtualPadBox",
        "compassBox",

4. Start Celestia and check presence of CelPad's checkbox in Lua Edu Tools.


### IMPORTANT!: Sometimes, Lua Edu Tools may fail to load during the first Celestia start on slower or overloaded PCs (i.e. on some notebooks or virtual machines) after the PC's start-up. Just re-start Celestia, next starts usualy work fine.
If you want to avoid this problem for good, use unofficial 'Lua Edu Tools 1.2beta9' (see PREREQUISITIES section above).
Note: Failed load is indicated with message "attempt to perform arithmetic on global 'toolBoxHeight' (a nil value)" in Celastia log.


### GETTING STARTED:
To start CelPad, click CelPad checkbox in Lua Edu Tools.

If you upgraded from version 1.0, CelPad will automatically convert your saved files to a new format at its first start. To start the conversion, click 'Yes' when confirmation dialog shows up. If you click 'No', CelPad will exit. New files have .cpsv1 extension. To save the space, you can remove old .cpsav files after the conversion.
IMPORTANT! Do NOT exit Celestia during the conversion. If you need to re-run the conversion for any reason, remove new 'ini_profile.cpsv1' file from '...\CelPad\saves\' directory. Of course, all your old files (including 'ini_profile.cpsav') must be present. Note, that file 'ini_profile.cpsav' contains references to all of your old saves.

After starting CelPad (with completed conversion), small square with 'CelPad' name will show up. Click on that square to start CelPad GUI Control Panel. Drag the square or Control Panel anywhere on the screen. Right click on Control Panel to get CelPad functions menu. Right click on CelPad square to show/hide the ControlPanel. Uncheck CelPad box (or close GUI Control Panel) for clean shutdown.
Note: After the very first start of CelPad, initial ini_profile file is created, which generates warning message in Celestia's log. That is not an error, the message can be ignored.


### PERFORMANCE NOTES (mainly for slower PCs): Please read Help panes, especially 'Performance Considerations' to avoid occurence of Lua hook timeouts and other performance problems. Timeouts occure when Lua script (or also .celx scripts) runs longer than certain time ( very short ) without contacting Celestia. This does not have to be fatal in case of CelPad, however, it leaves the system in unclear state so Celestia restart is necessary.

CelPad processing (for example scanning or marking) can be tuned to avoid timeouts. CelPad performs tasks on object packs instead of on the whole set. Bigger pack makes the process faster, but more vulnerable for timeouts. Small packs make scan safe, but longer. Try to find optimum, packs on their upper limit don't necessarily have to make overall scans faster. The more powerful is your PC, the bigger packs can be used. Slower or loaded systems should use small packs settings.


### CHANGE LOG, v.1.1 ###
### new features and fixed bugs

-Commands Set, function to create a batch of various commands that can be applied at objects in Selection Pads. Commands are defined via GUI dialog and usually they are based on Celestia's native commands. It is possible to run these command sets either sequentially on Selection Pad records, or on an individually picked object. I addition to pre-defined commands, it is also possible to directly write short LUA code (like in .celx scripts). See application help panes for details.
For more information about commands usage, see http://en.wikibooks.org/wiki/Celestia/Celx_Scripting/CELX_Lua_Methods

-Pause/resume of running process (scan, mark, copy, commands). It can be used to decrease system load for a while without need to cancel the process. Pausing of running command set allows re-defining of the command set parameters, however, other actions are usually disabled as the finder is busy.

-New save file format (due to command set control panel structure). Your saves from previous version (like your queries, settings, etc.) are automatically converted during the first start of new version.

-Summary provides "boundary values" count for some numeric attributes. In example, zero or infinite values are in some cases reported separately.

-To avoid interaction of mapped keyboard keys when writing into edit boxes, it is possible to use external text file 'input.txt' for an alternative input. The value that is saved in the file (i.e. using notepad) is read into the edit box. This feature can be useful in Celestia161-ED, where mapped keys are widely used.

-'Lifespan Start', 'Lifespan End', 'Angle' and 'Longitude/Latitude' now have their unit functions. 'Lifespan' attributes can be defined either in TDB (native) or in 'Y/M/D h:m:s' format. 'Angle' and 'Longitude/Latitude' can be defined in 'rad', 'deg' and 'arcsec' units.

-Info string on Control Panel's top bar can be changed via shortcut located in 'Observer Commands' menu. The menu contains also units definition for this info as well as for other observer commands (speed, rotation).

-Marker options were enhanced with another two parameters ('opaque' and 'occludable'), 'Marker Shape' attribute provides more shapes, 'Marker Color' provides more colors.

-Optional icon info, icon text is preceeded by letter 'a' for 'active', 'p' for 'paused', 'c' for 'cleanup' and 'i' for 'idle'. It gives you rough information about the current finder status.

-Right click on window's item precision is enhanced and window is not shattered during resize or move.

-Mouse click repeat delay and rate are configurable in GUI settings.

-Added font options for pop-up messages.

-To prevent discrepancies, items cannot be removed from pop-up menu during the processing. To remove item, cancel processing first.

-If item in Selection Pad is moved up or down, it does not disappear behind the edge. The text is scrolled instead.

-Fixed some rounding error troubles.

-Fixed incorrect 'no data' report for summary of 'lifespan' attributes.

-Fixed incorrect "surface" (edge) distance information in Info Panes for DSO objects.

-Fixed various incorrect GUI fonts usage (i.e in main window header etc.).

-Fixed instances count inconsistency error at CelPad exit that occured after some save/load dialogs usage.

-Fixed extra +1 object after the process cancellation.

-Fixed error that caused re-writing of some button texts if they were held by mouse along with keyboard usage.

-Fixed Lua Edu Tools crash if records were cleared during the marking process.

-Fixed error that appeared after attempt to run unmark on empty Selection Pad.

-Fixed problems with view/summary autoload with opened dialog.

-Slightly improved performance by reducing 'tostring' and 'string.format' functions usage.

-Several other minor bugs fixes and improvements.

-To save the space, debugging tools (i.e. internal syslogs) were removed from the code. If you need them, send me an e-mail, I'll send you separated debug module.


### KNOWN BUGS AND LIMITATIONS ###
(if you find new bug, please send the description to my email: ngx@zoznam.sk):

-If an individual command that was not processed yet is set to 'paused', Command Set Panel top bar displays 'no data' instead of object's identification. The process itself runs correctly.

-Usage of zero distance in commands like 'gotodistance' and 'gotolonglat' cause observer's mispositioning, which usually requires Celestia restart. Celestia pages refer to this bug for version 1.3.1, possibly it is still not fixed.

-Not all LUA commands are supported for running free LUA code. Some of them are generally considered "unsafe", like metatable or package commands. They were not mapped into sandboxed environment to prevent interaction with Lua Edu Tools's or CelPad's code. However, please be careful, there still might be some unhandled things left.

-If the system is slower and the mouse button is clicked right in the split second when Command Set Panel is refreshed, its help pane can be popped up. Just close the pane and go on. That situation also happens if summary of command delays is close to zero (i.e. in '1-line' profile) and the panel refresh is too fast. In that case, just run commands with closed Command Set Panel.

-Searching for object names can use only values returned by 'object:name()' method. Alternative names are not available in this version.

-If regular expression is used in some string search, its invalid definition will lead to whole Lua Edu Tools crash. Celestia must be restarted after.

-Re-scannings of large result sets (1 000 000+) with more complex queries increase the risk of cleanup lags, which can sometimes lead to timeouts. Although certain protecting workaround mechanism is implemented, so far I don't know how to get rid of it for good, sorry :(

-Text fields edit actions can collide with key mappings in Celestia script if such a script is running along with CelPad. In that case usually script takes priority. Edit also collides with 'a' and 'z' Celestia keys, so if you write something with 'a' or 'z' in it, observer's speed changes. This can be partly avoided using external input file for text editing (see help for system settings).

-Numbers with long decimals may sometimes exceed display field width. Click the box (as if you want to edit), the dialog will resize.

-If amount of icons in Control Panel cause panel to resize over its defined limits, icons draw will become faulty.

-If menu or info panes in sticky mode reach the screen edge during the Celestia window resize, they will become scattered. Press sticky button to turn sticky OFF, they will recompute.

-If message pane is in hiding mode, it can flick all over the screen for a split second when hiding past the bottom. Ugly, but harmless.

-Horizontal or vertical sliders can sometimes start flicker when window content is changed. Just drag them forward and back a bit, they will recompute.

-'Fast Cleanup' feature is still experimental and unstable, please read Help panes for more information. If you try it and you experience errors, turn it off.

-No localization in this version.


### TODO LIST ###

-bugfix
-code cleanup and optimization
-localization readiness (if there's an interest...)


### PROGRAMMERS NOTE ###

CelPad code is free for non-commercial use or addon extensions, the code used from Lua Edu Tools is copyrighted the same as Lua Edu Tools.

If you decide to go public with your extensions, please don't change original files, just add yours. That would prevent mismatch in case of updates or patches. If you need inevitable change in CelPad code, please email me details.

It was one of my firsts encounters with OOP and LUA, sorry for the mess :) Many things could have been done better, however, during the final code cleanup I left some code intact (don't scratch it, it works...).

Please send bug reports, comments and suggestions, if you have some, to my email address.

Thank you!

ngx@zoznam.sk
