-- CelPadHUD.lua

celestia:log("CelPad: loading user interface")

tCelPadHUD = {
sysLog = {
};
popMsgs = {};
setupPanes = {};
Icons = {};
winObjects = {};
functions = {
saveDlg = function(this,parent,x,y,what,finder)
	local profindex="Saves"..what;
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "setupdlg"
	this.setupdlg.menutab = tProfiles[profindex];
	this.setupdlg:init(this,parent,profindex,x,y,"Save Profile","dlgok");
	this.setupdlg:makeBranch(this);
	this.setupdlg.setuptype = "savedlg"
	this.setupdlg.btnself.tsimpleinput = {savenamex = "< click to edit >";};
	if finder then
		finder.setupdlg = this.setupdlg;
		finder.setupdlg.closebutton.Action = (function()
			return
			function()
				finder.setupdlg.menupane = finder.setupdlg:quitpopup(finder.setupdlg.btnbox);
				finder.setupdlg = nil;
			end
		end) ();
	end;
	if this.oribtn and this.oribtn.oribtn and this.oribtn.oribtn.wframe then
		this.setupdlg.btnself.finder = this.oribtn.oribtn.wframe.CPFinder;
	end;
	if finder then
		this.setupdlg.btnself.finder = finder
	end;
	this.setupdlg.btnself.saveme = function(this)
		local savefnc = function()
			if not this.overwrite then
				tProfiles[profindex]["savename"].valuelist[this.numvallist+1] = this.tsimpleinput.savenamex;
				tProfiles[profindex].savename[1] = this.tsimpleinput.savenamex;
			end;
			myCelPad:saveCP(what,this.tsimpleinput.savenamex,this.finder);
			myCelPad:saveCP("profile","ini");
			this.wobj.closebutton:Action()
			this.setup = nil;
			if finder then
			finder.setupdlg = nil;
			end;
		end;
		local nosavefnc = function()
			this.tsimpleinput.savenamex = "< click to edit >"
			this.overwrite = false;
			this.setup = nil;
		end;
		if this.tsimpleinput.savenamex == "< click to edit >" then
			this.tsimpleinput.savenamex = tProfiles[profindex].savename[1];
		end;
		local isthere = 0;
		for i,v in ipairs (tProfiles[profindex]["savename"].valuelist) do
			if v == this.tsimpleinput.savenamex then
				isthere = isthere + 1;
			end;
		end;
		if isthere > 0 then this.overwrite = true;
		else
			this.overwrite = false
		end;
		if this.overwrite then
			if not this.MSGupT["PopMSGoverwrite"] then
				this.PopMSGoverwrite = PopMessage:new({this.wobj.menupane.popupMenus});
				this.PopMSGoverwrite:init(this,"PopMSGoverwrite",x,y,nil,{
				templates2.popMsg.PopMSGoverwrite[1],
				"'"..tostring(this.tsimpleinput.savenamex).."' ?",
				txtfnt = templates2.popMsg.PopMSGoverwrite.txtfnt
				},nil,"yn",
				savefnc,
				nosavefnc
				);
				this.PopMSGoverwrite.Ybranchkill = true;
				this.PopMSGoverwrite:makeBranch(this.wobj.menupane);
			end;
		else
			savefnc();
		end;
	end;
	local numvallist = #tProfiles[profindex]["savename"].valuelist;
	if tProfiles[profindex]["savename"].valuelist[numvallist] == "< new save >" then
		numvallist = numvallist - 1;
	end;
	tProfiles[profindex]["savename"].valuelist[numvallist+1] = "< new save >";
	this.setupdlg.btnself.numvallist = numvallist;
	this.setupdlg.btnself.Customdraw = function(this)
		if this.tsimpleinput.savenamex ~= "< click to edit >" then
			this.saveme(this);
			if this.setup then
				this.setup.closebutton:Action()
				this.setup = nil
			end;
		end;
		if tProfiles[profindex].savename[1] == "< new save >"  then
			if this.setup then
				this.setup.closebutton:Action()
				this.setup = nil
			else
			this.setup = SetupMenu:new({parent.popupMenus});
			this.setup.objtype = "setupdlg"
			this.setup.menutab = this.tsimpleinput;
			this.setup.metatab = {savenamex = {"New Save:"};};
			this.setup:init(this,parent,"savenamesimp",x,y,"Enter Save Name");
			this.setup:makeBranch(this.wobj.menupane);
			tProfiles[profindex].savename[1]="default";
			end
		end;
	end;
	if parent.wobj and parent.wobj.wobj and parent.wobj.wobj.objtype == "multiTool" then
		this.setupdlg.btnself.mtwobj = parent.wobj.wobj
	else
		this.setupdlg.btnself.mtwobj = nil;
	end
	this.setupdlg.btnself.Action = (function()
		return
		function(this)
			if this.mtwobj then this.mtwobj:writeTabs() end
			this.saveme(this);
		end
	end) ();
end;
loadDlg = function(this,parent,x,y,what,finder)
	local profindex="Saves"..what;
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "setupdlg"
	this.setupdlg.menutab = tProfiles[profindex];
	this.setupdlg:init(this,parent,profindex,x,y,"Load Profile","dlgok");
	this.setupdlg:makeBranch(this);
	this.setupdlg.setuptype = "loaddlg";
	if finder then
		finder.setupdlg = this.setupdlg;
		finder.setupdlg.closebutton.Action = (function()
			return
			function()
				finder.setupdlg.menupane = finder.setupdlg:quitpopup(finder.setupdlg.btnbox);
				finder.setupdlg = nil;
			end
		end) ();
	end;
	local numvallist = #tProfiles[profindex]["savename"].valuelist;
	if tProfiles[profindex]["savename"].valuelist[numvallist] == "< new save >" then
		table.remove(tProfiles[profindex]["savename"].valuelist,numvallist);
	end;
	if this.oribtn and this.oribtn.oribtn and this.oribtn.oribtn.wframe then
		this.setupdlg.btnself.finder = this.oribtn.oribtn.wframe.CPFinder;
	end;
	if finder then
		this.setupdlg.btnself.finder = finder
	end;
	this.setupdlg.btnself.Action = (function()
		return
		function(this)
			if parent and parent.wobj and parent.wobj.wobj and parent.wobj.wobj.cmdtimer then
				if not this.MSGupT["noLoadCmdMSG"] then
					this.noLoadCmdMSG = PopMessage:new({parent.popupMenus});
					this.noLoadCmdMSG:init(this,"noLoadCmdMSG",x,y,nil,nil,nil,"ok");
					this.noLoadCmdMSG:makeBranch(this);
				end
			else
				myCelPad:loadCP(what,tProfiles[profindex].savename[1],this.finder)
				this.wobj:quitpopup(this.wobj.btnbox);
				if finder then
					finder.setupdlg = nil;
				end;
			end
		end
	end) ();
end;
delDlg = function(this,parent,x,y,what,finder)
	local profindex="Saves"..what;
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "setupdlg"
	this.setupdlg.menutab = tProfiles[profindex];
	this.setupdlg:init(this,parent,profindex,x,y,"Delete Profile","dlgok");
	this.setupdlg:makeBranch(this);
	local numvallist = #tProfiles[profindex]["savename"].valuelist;
	if tProfiles[profindex]["savename"].valuelist[numvallist] == "< new save >" then
		table.remove(tProfiles[profindex]["savename"].valuelist,numvallist);
	end;
	this.setupdlg.btnself.Action = (function()
		return
		function(this)
			local prfname = tostring(tProfiles[profindex].savename[1])
			if prfname == "default" then
				if not this.MSGupT["noDefDelMSG"] then
					this.noDefDelMSG = PopMessage:new({this.wobj.menupane.popupMenus});
					this.noDefDelMSG:init(this,"noDefDelMSG",x,y,nil,nil,nil,"ok")
					this.noDefDelMSG:makeBranch(this.wobj.menupane);
				end;
			else
				if not this.MSGupT["PopMSGdelete"] then
					this.PopMSGdelete = PopMessage:new({this.wobj.menupane.popupMenus});
					this.PopMSGdelete:init(this,"PopMSGdelete",x,y,nil,{
					templates2.popMsg.PopMSGdelete[1].."'"..prfname.."' ?"
					},nil,"yn",
					function(o)
						for i,v in ipairs(tProfiles[profindex]["savename"].valuelist) do
							if v == tProfiles[profindex].savename[1] then
								table.remove(tProfiles[profindex]["savename"].valuelist,i);
							end;
						end;
						if finder then
							CPlog("deleting profile "..prfname,0,finder.sysLog)
						end;
						myCelPad:deleteCP(what,tProfiles[profindex].savename[1])
						tProfiles[profindex].savename[1] = "default";
						myCelPad:saveCP("profile","ini");
						this.wobj:quitpopup(this.wobj.btnbox);
					end,
					function(o)
					end
					);
					this.PopMSGdelete.Ybranchkill = true;
					this.PopMSGdelete:makeBranch(this.wobj.menupane);
				end;
			end;
		end
	end) ();
end;
parDlg = function(this,parent,x,y,obs,object,celcmd,params)
	if this.finder then
		local deepcopy = deepcopy
		this.setupdlg = SetupMenu:new({parent.popupMenus,this.finder.openParDlgs});
		this.setupdlg.objtype = "setupdlg"
		this.setupdlg.menutab = {};
		this.setupdlg.metatab = {};
		this.setupdlg.finder = this.finder
		for p in string.gmatch(params, "%w+") do
			this.setupdlg.menutab[p] = deepcopy(templates.inputParam[p].data)
			this.setupdlg.metatab[p] = deepcopy(templates.inputParam[p].meta)
		end;
		this.setupdlg:init(this,parent,"parameters",x,y,"Enter Parameters","dlgok");
		this.setupdlg:makeBranch(this);
		local commands = templates.celcmds;
		this.setupdlg.btnself.menuitem = this
		this.setupdlg.btnself.Action = (function()
			return
			function(this)
				local paramtab = {};
				local i = 1
				for p in string.gmatch(params, "%w+") do
					paramtab[i] = this.wobj.menutab[p]
					i = i + 1;
				end;
				commands[celcmd](obs,object,paramtab)
				this.wobj:quitpopup(this.wobj.btnbox);
			end
		end) ();
		this.setupdlg.btnself.Customdraw = function(this)
			for q in string.gmatch(params, "%w+") do
				this.menuitem[q] = deepcopy(this.wobj.menutab[q])
				if q == "zcmdvector" then
					if this.wobj.menutab[q][1]==0 and this.wobj.menutab[q][2]==0 and this.wobj.menutab[q][3]==0 then
						this.wobj.menutab[q][1] = templates.inputParam.zcmdvector.data[1]
						this.menuitem[q][1] = this.wobj.menutab[q][1]
						this.wobj.menutab[q][2] = templates.inputParam.zcmdvector.data[2]
						this.menuitem[q][2] = this.wobj.menutab[q][2]
						this.wobj.menutab[q][3] = templates.inputParam.zcmdvector.data[3]
						this.menuitem[q][3] = this.wobj.menutab[q][3]
					end
				end
			end
		end;
	else
		CPlog("CelPad Alert: finder missing for dialog object '"..tostring(this.objname).."'!")
	end;
end;
tableprepCelObj = function(frame)
	local textlayout = textlayout
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local lcfnt = cpfntmainw
	local units = frame.CPFinder.unittable
	local finder = frame.CPFinder
	local lcFuse = Fuse
	local idnt = cpgetwidth(lcfnt,finder.Header)
	local runstrfnc = runStrFnc
	local math_dround = math_dround
	frame.runstr = runstrfnc(finder)
	local tagstr
	textlayout:setpos(frame.lb+49+idnt, frame.tb-lcfnt:getheight()+18);
	if finder.resultSet then
		textlayout:setfont(cpfntheader);
		textlayout:println(frame.runstr)
		textlayout:setfont(lcfnt);
		if ms020AdaptiveLoops then
			textlayout:setpos(frame.lb+idnt, frame.tb-lcfnt:getheight()+18);
			textlayout:println("*:"..math_dround(lcFuse,3))
		end;
	end;
	textlayout:setpos(frame.lb+5, frame.tb-lcfnt:getheight());
	for i=1,table.maxn(frame.dtable) do
		if frame.Verbose then
			table.insert(frame.frametext,"["..i.."] "..finder:verbstr(frame.dtable[i],i))
		else
			tagstr = ""
			table.insert(frame.frametext,"["..i.."] "..tagstr..finder:tersstr(frame.dtable[i],i))
		end;
		table.insert(frame.frametext.txtcol,i,frame.dtable.txtcol[i]);
	end;
end;
viewLog = function(frame)
	local textlayout = textlayout
	local finder = frame.CPFinder
	finder.viewMode = "log";
	frame.whtable = frame.CPFinder.sysLog;
	frame.whtable.txtcol = {};
	local getheight = getheight
	local cpgetwidth = cpgetwidth
	local math_dround = math_dround
	frame.pagenumber = finder.vwpage[finder.viewMode]
	if frame.pagenumber == 0 then frame.pagenumber = 1 end;
	frame.marginoffset = 0;
	frame.tableprep = function (frame)
		local lcfnt = cpfntmainw
		local lcFuse = Fuse
		local idnt = cpgetwidth(lcfnt,finder.Header)
		local runstrfnc = runStrFnc
		frame.runstr = runstrfnc(finder)
		textlayout:setpos(frame.lb+49+idnt, frame.tb-lcfnt:getheight()+18);
		if finder.resultSet then
			textlayout:setfont(cpfntheader);
			textlayout:println(frame.runstr)
			textlayout:setfont(lcfnt);
			if ms020AdaptiveLoops then
				textlayout:setpos(frame.lb+idnt, frame.tb-lcfnt:getheight()+18);
				textlayout:println("*:"..math_dround(lcFuse,3))
			end;
		end;
		textlayout:setpos(frame.lb+5, frame.tb-lcfnt:getheight());
		for i=1,table.maxn(frame.dtable) do
			if frame.Verbose then
				table.insert(frame.frametext,"["..frame.dtable.logNum[i].."] "..frame.dtable.timestamp[i]..": "..frame.dtable[i]);
			else
				table.insert(frame.frametext,frame.dtable.timestamp[i]..": "..frame.dtable[i]);
			end;
			table.insert(frame.frametext.txtcol,i,frame.dtable.txtcol[i]);
		end;
	end;
	frame.popupwindow = tCelPadHUD.functions.syslogPopWin
end;
viewResults = function(frame)
	local finder = frame.CPFinder
	if not (finder.niling) then
		finder.viewMode = "resultset";
		frame.whtable =  finder.resultSet;
		frame.whtable.txtcol = {};
		frame.pagenumber = finder.vwpage[finder.viewMode]
		if frame.pagenumber == 0 then frame.pagenumber = 1 end;
		frame.marginoffset = 0;
		frame.tableprep = tCelPadHUD.functions.tableprepCelObj;
		if finder.findertype == 2 and finder.cmdset and finder.cmdset.ik then
			finder.oriframe.whtable.txtcol[finder.cmdset.ik] = cpfntcolruncmd;
		end
		frame.popupwindow = function (this, parent, x, y, item_index)
			local infinder = this.oriwobj.mainFrame.CPFinder
			if infinder.resultSet[item_index] and type(infinder.resultSet[item_index]) == "userdata" then
				this.popup = PopupMenu:new({this.popupMenus,this.pickedItems});
				this.popup:init(this,parent,"ResultSetItem",x,y,"["..item_index.."]["..infinder.resultSet[item_index]:name().."]","no");
				this.popup.menupane.itempopup = true;
				this.popup.menupane.item_index = item_index;
				this.popup.menupane.pane = this.popup;
				this.popup.menupane.src = this;
				this.popup:makeBranch(this);
			else
				myCelPad:systemMsg(nil,nil,"generr",finder,"Invalid or missing item.","pop-up attempt, item #"..tostring(item_index))
			end;
		end;
	end;
end;
viewSysLog = function(frame)
	local textlayout = textlayout
	local getheight = getheight
	local math_round = math_round
	frame.whtable = frame.sysLog;
	frame.whtable.txtcol = {};
	syslogWindow.slwin.mainFrame.tableprep = function (frame)
		textlayout:setpos(frame.lb+155, frame.tb-cpfntheader:getheight()+18);
		textlayout:println("loglevel:"..frame.dispLogLevel)
		textlayout:setpos(frame.lb+5, frame.tb-cpfntheader:getheight());
		for i=1,table.maxn(frame.dtable) do
			if frame.dtable.logLevel[i] <= frame.dispLogLevel then
				local sltext = "["..frame.dtable.logNum[i].."] "..frame.dtable.timestamp[i].." {"..frame.dtable.logLevel[i].."}: "..frame.dtable[i];
				if string.find(sltext,frame.dispFilter) then
					if frame.Verbose then
						table.insert(frame.frametext,"["..frame.dtable.logNum[i].."] "..frame.dtable.timestamp[i].." {"..frame.dtable.logLevel[i].."}: "..frame.dtable[i]);
					else
						table.insert(frame.frametext,frame.dtable.timestamp[i]..": "..frame.dtable[i]);
					end;
					table.insert(frame.frametext.txtcol,i,frame.dtable.txtcol[i]);
				end
			end
		end;
	end;
	syslogWindow.slwin.mainFrame.popupmenu = function (frame, parent, x, y)
		if frame.Wrapline or frame.dispFilter ~= "" then
			if not frame.MSGupT["PopMSGOKwf"] then
				frame.PopMSGOKwf = PopMessage:new({frame.popupMenus});
				frame.PopMSGOKwf:init(frame,"PopMSGOKwf",x,y,nil,nil,nil,"ok");
				frame.PopMSGOKwf:makeBranch(frame);
			end;
		else
			ox1, oy1 = frame:offset(x,y)
			local item_index = ((frame.endline-(math_round((oy1+3)/cpfntmainw:getheight())-1)) + frame.lineoffset)+((frame.pagenumber-1)*frame.Maxpageitems);
			if item_index > 0 and item_index <= #frame.whtable then
				frame:popupwindow(parent, x, y, item_index);
			else
				if not frame.MSGupT["PopMSGnoLitem"] then
					frame.PopMSGnoLitem = PopMessage:new({frame.popupMenus});
					frame.PopMSGnoLitem:init(frame,"PopMSGnoLitem",x,y,nil,nil,nil,"ok");
					frame.PopMSGnoLitem:makeBranch(frame);
				end;
			end;
		end;
	end;
	syslogWindow.slwin.mainFrame.popupwindow = tCelPadHUD.functions.syslogPopWin
end;
syslogPopWin = function(frame, parent, x, y, item_index)
	local finder = frame.CPFinder
	local headtext
	if finder then
		headtext = "["..item_index.."]["..finder.sysLog[item_index].."]"
	else
		headtext = "["..item_index.."]["..frame.whtable[item_index].."]"
	end;
	local headtxtw = maxSyslWidth/2
	if string.len(headtext) > headtxtw then
		headtext = string.sub(headtext,1,headtxtw).."...]";
	end;
	frame.popup = PopupMenu:new({frame.popupMenus,frame.pickedItems});
	frame.popup:init(frame,parent,"syslogPopup",x,y,headtext,"no");
	frame.popup.menupane.itempopup = true;
	frame.popup.menupane.item_index = item_index;
	frame.popup.menupane.pane = frame.popup;
	frame.popup.menupane.src = frame;
	frame.popup:makeBranch(frame);
end;
cmdsDlg = function(this,parent,x,y,finder)
	if #finder.openCommands > 0 then
		if not this.MSGupT["oneCmdMSG"] then
			this.oneCmdMSG = PopMessage:new({parent.popupMenus});
			this.oneCmdMSG:init(this,"oneCmdMSG",x,y,nil,nil,nil,"ok");
			this.oneCmdMSG:makeBranch(this);
		end
	else
		local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
		local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
		local math_dround = math_dround
		this.finder = finder
		this.finder.CMDS.mtdlg = MultiMenu:new({parent.popupMenus,finder.openCommands});
		this.finder.CMDS.mtdlg.srctab = this.finder.CMDS.srctab
		if this.mvitem then
			this.finder.CMDS.mtdlg.menutab = this.menutab
			this.finder.CMDS.mtdlg.metatab = this.metatab
			this.menutab = nil
			this.metatab = nil
			this.mvitem = false
		end;
		this.finder.CMDS.mtdlg.cmditem = true
		this.finder.CMDS.mtdlg.what = "CMDS"
		this.finder.CMDS.mtdlg.finder = this.finder
		this.finder.CMDS.mtdlg:init(this,parent,"CommandSet",x,y,"Command Set","dlgok");
		this.finder.CMDS.mtdlg:makeBranch(this);
		this.mtdlg = this.finder.CMDS.mtdlg;
		this.what = this.finder.CMDS.mtdlg.what;
		for r,t in pairs(this.mtdlg.tmultimenu) do
			for f,y in pairs(t) do
				if y.objname == "dly" then
					y.srctab = this.mtdlg.srctab
					y.mtdlg = this.mtdlg
					local dumfnc = function() end;
					this.mtdlg.tmultimenu[r][6].right.oAction = this.mtdlg.tmultimenu[r][6].right.oAction or this.mtdlg.tmultimenu[r][6].right.Action
					this.mtdlg.tmultimenu[r][6].right.oCustomdraw = this.mtdlg.tmultimenu[r][6].right.oCustomdraw or this.mtdlg.tmultimenu[r][6].right.Customdraw
					this.mtdlg.tmultimenu[r][6].left.oAction = this.mtdlg.tmultimenu[r][6].left.oAction or this.mtdlg.tmultimenu[r][6].left.Action
					this.mtdlg.tmultimenu[r][6].left.oCustomdraw = this.mtdlg.tmultimenu[r][6].left.oCustomdraw or this.mtdlg.tmultimenu[r][6].left.Customdraw
					y.finder = this.finder
					y.Customdraw = function(this)
						pressSwitch(this)
						if this.wobj.cmdtimer then
							local pretimer = tCelPad.Timers.chained[this.wobj.cmdtimer.TimerID] or {}
							local timer = pretimer[r]
							if timer then
								this.mtdlg.tmultimenu[r][6].right.Action = dumfnc
								this.mtdlg.tmultimenu[r][6].right.Customdraw = dumfnc
								this.mtdlg.tmultimenu[r][6].left.Action = dumfnc
								this.mtdlg.tmultimenu[r][6].left.Customdraw = dumfnc
								this.mtdlg.tmultimenu[r][6].Text = math_dround(timer.timetoend,1)
								if timer.status == "active" or timer.status == "frozen" then
									local fntcol = cpfntcolhghlt
									if timer.status == "frozen" then
										fntcol = cpfntcolmainw
										this.mtdlg.tmultimenu[r][5]:text("paused")
									else
										this.mtdlg.tmultimenu[r][5]:text(this.mtdlg.srctab.meta.argTbl[r].dly[1])
									end
									this.mtdlg.tmultimenu[r][4]:textcolor(fntcol)
									local obj = timer.object or {
									name = function() return "no data" end;
									}
									local parser = this.finder.cmdset or {ik = "?"}
									this.mtdlg.menupane.Text = this.mtdlg.srctab.meta.infostr..": #"..tostring(parser.ik).." ("..getKeyName(obj)..") ["..(timer.cmdname or "no data").."]"
								else
									this.mtdlg.tmultimenu[r][4]:textcolor(cpcolmenul)
									if timer.status == "finished" then
										this.mtdlg.tmultimenu[r][5]:text("done")
										if this.mtdlg.tmultimenu[r][4].popup then
											this.mtdlg.tmultimenu[r][4].popup:quitpopup(this.mtdlg.tmultimenu[r][4])
										end
									end
								end
							else
								this.mtdlg.tmultimenu[r][6].right.Action = this.mtdlg.tmultimenu[r][6].right.oAction
								this.mtdlg.tmultimenu[r][6].right.Customdraw = this.mtdlg.tmultimenu[r][6].right.oCustomdraw
								this.mtdlg.tmultimenu[r][6].left.Action = this.mtdlg.tmultimenu[r][6].left.oAction
								this.mtdlg.tmultimenu[r][6].left.Customdraw = this.mtdlg.tmultimenu[r][6].left.oCustomdraw
							end
						end
					end
				end
			end
		end
		local pw = this.finder.CMDS.mtdlg.pw
		if pw >= ScrX then
			myCelPad:systemMsg(nil,nil,"generr",finder,"Dialog cannot be displayed, screen is too narrow.")
			this.finder.CMDS.mtdlg.closebutton.Action();
		end
	end
end;
infoPane = function(this,parent,x,y,finder,celobj)
	local starallattr = finder.starallattr
	local bodyallattr = finder.bodyallattr
	local dsoallattr = finder.dsoallattr
	local locsallattr = finder.locsallattr
	local rndtabAtr = finder.rndtabAtr
	local rndtabNames = finder.rndtabNames
	local t_ins = table.insert
	local s_find = string.find
	local s_format = string.format
	local s_to = tostring
	local t_num = tonumber
	local math_dround = math_dround
	local infoattr = {
	txtfnt = {"normalfont"};
	};
	local consttab = templates.unitsConst;
	local tmpinfo;
	local tmptype = celobj:getinfo().type
	local bodymcstr = finder.metaQueryPlanets.qr016_type.fullmcstr
	local dsomcstr = finder.metaQueryDsos.qr016_type.fullmcstr
	local distfnc = function(obj)
		local obs = observer
		local obs_pos  = obs:getposition()
		local distance = obs_pos:distanceto(obj:getposition(celestia:gettime()))
		local lpmsg = "Current distance (center)`"
		local rpmsg = math_dround(finder.unittable["qr001_distance"][1](distance,"fromnative"),finder.decplac).." "..finder.unitmeta["qr001_distance"].valuelist[finder.unitmeta["qr001_distance"].metaindx];
		return lpmsg, rpmsg
	end;
	local distsfcfnc = function(obj)
		local obs = observer
		local obs_pos  = obs:getposition()
		local radius = obj:getinfo().radius
		local lpmsg = "Current distance (surface)`"
		local rpmsg
		if radius then
			if s_find(dsomcstr,tmptype) then
				radius = radius*consttab.distance.ly
				lpmsg = "Current distance (edge)`"
			end
			local sfcdistance = obs_pos:distanceto(obj:getposition(celestia:gettime())) - radius
			rpmsg = math_dround(finder.unittable["qr001_distance"][1](sfcdistance,"fromnative"),finder.decplac).." "..finder.unitmeta["qr001_distance"].valuelist[finder.unitmeta["qr001_distance"].metaindx];
		else
			rpmsg = "no data"
		end
		return lpmsg, rpmsg
	end;
	local posfnc = function(obj)
		local obs = observer
		local obj_pos  = obj:getposition()
		local lpmsg = "Current position`"
		local rpmsg = s_format("%.2f; %.2f; %.2f",obj_pos.x,obj_pos.y,obj_pos.z)
		return lpmsg, rpmsg
	end
	if tmptype == "star" then
		tmpinfo = starallattr;
	elseif s_find(bodymcstr,tmptype) then
		tmpinfo = bodyallattr;
	elseif s_find(dsomcstr,tmptype) then
		tmpinfo = dsoallattr;
	else
		tmpinfo = locsallattr;
	end;
	local infostring,valpres,getval,attrfnc;
	local maxtxt = 0;
	local locsnum = locsnum
	for i,v in ipairs(tmpinfo) do
		getval = v
		if getval == "dsoradius" then getval = "radius" end;
		if getval == "getchildren" then
			attrfnc = #celobj:getchildren()
		elseif getval == "locations" then
			attrfnc = locsnum(celobj)
		elseif getval == "parent" then
			attrfnc = celobj:getinfo().parent
			if attrfnc then attrfnc = attrfnc:getinfo().type..": "..attrfnc:name() end;
			attrfnc = attrfnc or "no data"
		elseif getval == "visible" then
			attrfnc = celobj:visible()
		elseif getval == "infoURL" then
			attrfnc = celobj:getinfo()[getval] or "no data"
			if attrfnc == "" then attrfnc = "empty" end;
		elseif getval == "hubbleType" or getval == "featureType" then
			attrfnc = celobj:getinfo()[getval] or "no data"
		else
			attrfnc = celobj:getinfo()[getval]
		end
		if t_num(attrfnc) then
			valpres = math_dround(attrfnc,finder.decplac)
		else
			valpres = s_to(attrfnc)
		end
		infostring = s_to(rndtabAtr[v]).."`"..valpres
		t_ins(infoattr,infostring);
	end;
	if tmptype == "star" and finder.showCat then
		t_ins(infoattr,"Henry Draper Catalog`"..(celobj:catalognumber("HD") or "no data"));
		t_ins(infoattr,"SAO Catalog`"..(celobj:catalognumber("SAO") or "no data"));
		t_ins(infoattr,"Hipparcos Catalog`"..(celobj:catalognumber("HIP") or "no data"));
	end;
	local ldmsg, rdmsg = distfnc(celobj)
	t_ins(infoattr,ldmsg..rdmsg)
	ldmsg, rdmsg = distsfcfnc(celobj)
	t_ins(infoattr,ldmsg..rdmsg)
	if finder.showPos then
		ldmsg, rdmsg = posfnc(celobj)
		t_ins(infoattr,ldmsg..rdmsg)
	end
	if not this.MSGupT["InfoPaneMSG"] then
		this.InfoPaneMSG = PopMessage:new({parent.popupMenus,finder.infoPanes});
		this.InfoPaneMSG.finder = finder
		this.InfoPaneMSG:init(this,"InfoPaneMSG",x,y,"Info Pane",infoattr,"i","inf");
		this.InfoPaneMSG:makeBranch(this);
	end;
	this.InfoPaneMSG.okbutton.message = this.InfoPaneMSG.message;
	this.InfoPaneMSG.okbutton.object = celobj;
	this.InfoPaneMSG.okbutton.finder = finder;
	this.InfoPaneMSG.okbutton.Customdraw = function(this)
		local ldmsg, rdmsg
		if finder.showPos then
			ldmsg, rdmsg = distfnc(this.object)
			this.message[#this.message-2] = ldmsg..rdmsg
			ldmsg, rdmsg = distsfcfnc(this.object)
			this.message[#this.message-1] = ldmsg..rdmsg
			ldmsg, rdmsg = posfnc(this.object)
			this.message[#this.message] = ldmsg..rdmsg
		else
			ldmsg, rdmsg = distfnc(this.object)
			this.message[#this.message-1] = ldmsg..rdmsg
			ldmsg, rdmsg = distsfcfnc(this.object)
			this.message[#this.message] = ldmsg..rdmsg
		end;
	end;
	return this.InfoPaneMSG
end;
};
Menu = {
CPpopup={
"Celestia Scanner","Selection Pad","Settings",
switch={0,0,1};
fnctab = {
function(this) -- Celestia Scanner
	local ScannerWin=CPUniWindow:new({tCelPadHUD.winObjects})
	local mergemenutabs = mergemenutabs
	lastwindow.lastwx1,lastwindow.lastwy1,lastwindow.lastww1,lastwindow.lastwh1 = myCelPadHUD:borderchk(lastwindow.lastwx1,lastwindow.lastwy1,lastwindow.lastww1,lastwindow.lastwh1)
	ScannerWin:init("ScannerWin", lastwindow.lastwx1,lastwindow.lastwy1,lastwindow.lastww1,lastwindow.lastwh1, "f", tCelPadFinder.sysLog, "Finder log")
	ScannerWin.mainFrame:header("Scanner "..tostring(time_str));
	ScannerWin:makeBranch(ControlPanel);
	ScannerWin.mainFrame.CPFinder = CelPadScanner:new({tCelPadFinder.runningFinders,myCelPad.closeTab});
	ScannerWin.mainFrame.CPFinder.oriframe = ScannerWin.mainFrame;
	ScannerWin.mainFrame.CPFinder.wobj = ScannerWin;
	ScannerWin.mainFrame.CPFinder:init("CPFinder-Scanner",ScannerWin.mainFrame.Header);
	ScannerWin.mainFrame.CPFinder:makeBranch(ScannerWin);
	ScannerWin:savelastpos("finder")
	ScannerWin.moveButton.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.wframe.popupMenus});
		this.popup.menutab = mergemenutabs(tCelPadHUD.Menu["mvbtnpup"],tCelPadHUD.Menu["ScannerWinTB"]);
		this.popup.menutab = mergemenutabs(this.popup.menutab,tCelPadHUD.Menu["mvbtnpupUW"]);
		this.popup:init(this,parent,"ScannerWinTB",x,y,"Scanner Functions","no");
		this.popup:makeBranch(this);
	end;
	if ms040DefView1[1]=="log" then
		tCelPadHUD.functions.viewLog(ScannerWin.mainFrame)
	elseif ms040DefView1[1]=="resultset" then
		tCelPadHUD.functions.viewResults(ScannerWin.mainFrame)
	end;
	return 	ScannerWin;
end;
function(this) -- Selection Pad
	local SelLogWin=CPUniWindow:new({tCelPadHUD.winObjects})
	local mergemenutabs = mergemenutabs
	lastwindow.lastwx2,lastwindow.lastwy2,lastwindow.lastww2,lastwindow.lastwh2 = myCelPadHUD:borderchk(lastwindow.lastwx2,lastwindow.lastwy2,lastwindow.lastww2,lastwindow.lastwh2)
	SelLogWin:init("SelLogWin", lastwindow.lastwx2,lastwindow.lastwy2,lastwindow.lastww2,lastwindow.lastwh2, "f", tCelPadFinder.sysLog, "Selection Pad")
	SelLogWin.mainFrame:header("Selection Pad "..tostring(time_str));
	SelLogWin:makeBranch(ControlPanel);
	SelLogWin.addselbtn = SelLogWin:winButton(SelLogWin.btnindex,"A");
	SelLogWin.addselbtn:menuitem(true);
	SelLogWin.btnindex = SelLogWin.btnindex + 1;
	SelLogWin.addselbtn.wobj = SelLogWin
	SelLogWin.addselbtn.popupmenu = function(this,parent,x,y)
		local locSelection = celestia:getselection();
		local finder = this.wobj.mainFrame.CPFinder
		if locSelection:getinfo().type ~= "null" then
			CPlog("manually added object "..tostring(locSelection:name()),0,this.wobj.mainFrame.CPFinder.sysLog);
			table.insert(finder.resultSet,locSelection);
			if fastCleanup then
				finder.nilfam[finder.famid][1] = finder.nilfam[finder.famid][1] + 1
				myCelPad.nilfams[finder.famid][finder.famid][1] = myCelPad.nilfams[finder.famid][finder.famid][1] + 1
			end
			if ms132updateOpened then
				finder:updGlobVars();
			end
		else
			if not this.MSGupT["popNoSel"] then
				this.popNoSel = PopMessage:new({this.wobj.mainFrame.popupMenus});
				this.popNoSel:init(this,"popNoSel",x,y,nil,nil,nil,"ok");
				this.popNoSel:makeBranch(this);
			end;
		end;
	end;
	SelLogWin.moveButton.addselbtn = SelLogWin.addselbtn;
	SelLogWin.mainFrame.CPFinder = CPSelectionLog:new({tCelPadFinder.runningLogs,myCelPad.closeTab});
	SelLogWin.mainFrame.CPFinder.oriframe = SelLogWin.mainFrame;
	SelLogWin.mainFrame.CPFinder.wobj = SelLogWin;
	SelLogWin.mainFrame.CPFinder:init("CPFinder-SelPad",SelLogWin.mainFrame.Header);
	SelLogWin.mainFrame.CPFinder:makeBranch(SelLogWin);
	SelLogWin:savelastpos("finder")
	SelLogWin.moveButton.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.wframe.popupMenus});
		this.popup.menutab = mergemenutabs(tCelPadHUD.Menu["mvbtnpup"],tCelPadHUD.Menu["SelectionLogTB"]);
		this.popup.menutab = mergemenutabs(this.popup.menutab,tCelPadHUD.Menu["mvbtnpupUW"]);
		this.popup:init(this,parent,"SelectionLogTB",x,y,"Selection Pad Functions","no");
		this.popup:makeBranch(this);
	end;
	if ms050DefView2[1]=="log" then
		tCelPadHUD.functions.viewLog(SelLogWin.mainFrame)
	elseif ms050DefView2[1]=="resultset" then
		tCelPadHUD.functions.viewResults(SelLogWin.mainFrame)
	end;
	return SelLogWin;
end;
function(this, parent, x, y) --settings
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"settingspane",x,y,"Settings","no");
	this.popup:makeBranch(this);
end;
function(frame)
	local textlayout = textlayout
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local pressSwitch = pressSwitch
	local str_format = string.format
	local math_dround = math_dround
	local starSol = starSol
	local obj, dist, objn
	local tabindx = tabindx
	local consttab = templates.unitsConst;
	local decplac = obsInfoDec;
	local unitfnc = function(v,unit)
		return(v/consttab.distance[unit])
	end;
	frame.Customdraw = function(frame)
		local unitmeta = frame.CPFinder.unitmeta;
		local addinfo = ms030AddInfo
		textlayout:setfont(cpfntheader);
		textlayout:setpos(frame.lb+5, frame.tb-cpfntheader:getheight()+19);
		textlayout:setlinespacing(cpfntheader:getheight());
		textlayout:setfontcolor(cpcolheader);
		textlayout:println(tostring(frame.Header));
		textlayout:setpos(frame.lb+5+cpgetwidth(cpfntheader,frame.Header), frame.tb-cpfntheader:getheight()+19);
		pressSwitch(frame)
		local posstr = ""
		if addinfo ~= "none" then
			if addinfo == "meminfo" then
				dist = collectgarbage("count")
				posstr = "Mem. used [Kbytes]: "..math_dround(dist,3)
			else
				local obs_pos = observer:getposition()
				if addinfo == "obspos" then
					posstr = str_format("position: %.2f; %.2f; %.2f",obs_pos.x,obs_pos.y,obs_pos.z)
				else
					local dunit = unitmeta["zcmddistance"].valuelist[unitmeta["zcmddistance"].metaindx]
					if addinfo == "objdist" then
						obj = celestia:getselection()
					elseif addinfo == "homdist" then
						obj = starSol
					end
					objn = obj:name()
					if objn ~= "?" then
						dist = obs_pos:distanceto(obj:getposition(celestia:gettime()))
						posstr = "dist. from "..objn.." ["..dunit.."]: "..math_dround(unitfnc(dist,dunit),decplac)
					else
						posstr = "no selection"
					end
				end
			end;
		end;
		textlayout:println(tostring(posstr));
		if IconsRepos then
			local CPborTol = 10;
			local tCelPadHUD = tCelPadHUD;
			if CPicor == "horizontal" then
				for i,v in ipairs(tCelPadHUD.Icons) do
					v.itindex = i;
					if switchdone == false then
						if i > 1 then
							if ((v.la < (frame:ww() - tCelPadHUD.Icons[i-1].ra) - 5) and (v.line == tCelPadHUD.Icons[i-1].line))
								or (v.ta < (v.line-1)*(CPiconH+lcButtonspace)-5 and v.la < 2*lcButtonspace)
								then
								local kk = tCelPadHUD.Icons[i];
								tCelPadHUD.Icons[i] = tCelPadHUD.Icons[i-1]
								tCelPadHUD.Icons[i-1] = kk;
								switchdone = true;
							end;
						end;
						if i < table.maxn(tCelPadHUD.Icons) then
							if ((v.ra < (frame:ww() - tCelPadHUD.Icons[i+1].la) - 5) and (v.line == tCelPadHUD.Icons[i+1].line))
								or (v.ta > (v.line-1)*(CPiconH+lcButtonspace)+lcButtonspace+5 and tCelPadHUD.Icons[i+1].line > v.line)
								then
								local kz = tCelPadHUD.Icons[i];
								tCelPadHUD.Icons[i] = tCelPadHUD.Icons[i+1]
								tCelPadHUD.Icons[i+1] = kz;
								switchdone = true;
							end;
						end;
					end;
					local v_totaliw = 0;
					local v_locline = 1;
					for i,v in ipairs(tCelPadHUD.Icons) do
						v.iw = cpgetwidth(cpfntmenu,v.icontext);
						v_totaliw = v_totaliw + (v.iw+lcButtonspace);
						if v_totaliw > (CPmaxW-CPborTol-(lcButtonsize+lcButtonspace)) then
							v_locline = v_locline + 1;
							v_totaliw = v.iw;
						end;
						if v_totaliw > v.Parent:ww() - CPborTol then
							v.CPpointer:resizePanel(1,0);
						end;
						v.line = v_locline;
						if v.line*(CPiconH + lcButtonspace)> v.Parent:wh() - CPborTol then
							v.CPpointer:resizePanel(0,1);
						end;
					end;
					if v.itindex > 1 then
						if tCelPadHUD.Icons[v.itindex-1].line == v.line then
							v.ixla = tCelPadHUD.Icons[v.itindex-1].la + tCelPadHUD.Icons[v.itindex-1].iw
						elseif tCelPadHUD.Icons[v.itindex-1].line + 1 == v.line then
							v.ixla = 0;
						end;
					else
						v.ixla = 0;
					end;
					v.la = lcButtonspace+v.ixla;
					v.ra = v.Parent:ww() - v.la - (v.iw or 0);
					v.ta = lcButtonspace + ((v.line-1)*(CPiconH+lcButtonspace));
					v.ba = v.Parent:wh() - (lcButtonspace + CPiconH)*v.line
				end;
			elseif CPicor == "vertical" then
				local maxln = math.floor((CPmaxH - CPborTol)/CPiconH) - 1;
				for i,v in ipairs(tCelPadHUD.Icons) do
					v.itindex = i;
					local fff;
					if i > maxln then
						fff = (frame:ww()-tCelPadHUD.Icons[v.itindex-maxln].ra)
					else
						fff = 0
					end;
					if switchdone == false then
						if i > 1 then
							if ((v.ta < (frame:wh() - tCelPadHUD.Icons[i-1].ba) - 5) and (v.clmn == tCelPadHUD.Icons[i-1].clmn))
								or (v.la < fff - 5 and  tCelPadHUD.Icons[i-1].clmn < v.clmn)
								then
								local kk = tCelPadHUD.Icons[i];
								tCelPadHUD.Icons[i] = tCelPadHUD.Icons[i-1]
								tCelPadHUD.Icons[i-1] = kk;
								switchdone = true;
							end;
						end;
						if i < table.maxn(tCelPadHUD.Icons) then
							if ((v.ba < (frame:wh() - tCelPadHUD.Icons[i+1].ta) - 5) and (v.clmn == tCelPadHUD.Icons[i+1].clmn))
								or (v.la > lcButtonspace + fff  and v.ba < CPiconH )
								then
								local kz = tCelPadHUD.Icons[i];
								tCelPadHUD.Icons[i] = tCelPadHUD.Icons[i+1]
								tCelPadHUD.Icons[i+1] = kz;
								switchdone = true;
							end;
						end;
					end;
					local v_totalih = 0;
					local v_locclmn = 1;
					for i,v in ipairs(tCelPadHUD.Icons) do
						v.iw = cpgetwidth(cpfntmenu,v.window.mainFrame.Header);
						v_totalih = v_totalih + (CPiconH+lcButtonspace);
						if v_totalih > (CPmaxH-CPborTol) then
							v_locclmn = v_locclmn + 1;
							v_totalih = CPiconH;
						end;
						if v.la + 2*lcButtonspace + v.iw > v.Parent:ww() - CPborTol then
							v.CPpointer:resizePanel(1,0);
						end;
						v.clmn = v_locclmn;
						if v_totalih > v.Parent:wh() - CPborTol then
							v.CPpointer:resizePanel(0,1);
						end;
					end;
					if v.itindex > 1 then
						if tCelPadHUD.Icons[v.itindex-1].clmn == v.clmn then
							v.ixta = tCelPadHUD.Icons[v.itindex-1].ta + CPiconH;
						elseif tCelPadHUD.Icons[v.itindex-1].clmn + 1 == v.clmn then
							v.ixta = 0;
						end;
					else
						v.ixta = 0;
					end;
					v.la = lcButtonspace + fff
					v.ra = v.Parent:ww() - v.la - (v.iw or 0);
					v.ta = lcButtonspace + v.ixta
					v.ba = frame:wh()-(v.ixta+(CPiconH+lcButtonspace));
				end;
			end;
		end
		if frame:ww() > CPmaxW then
			frame.wobj:resizePanel(-5,0);
		end;
		if frame:wh() > CPmaxH then
			frame.wobj:resizePanel(0,-5);
		end;
		if IconsRepos == true then
			if IconsReposTimer == nil then
				IconsReposTimer = CPtimer:new({tCelPad.Timers});
				IconsReposTimer:init("IconsReposTimer","IconsReposTimer",2,"standalone",0,
				function(o)
					IconsRepos = nil;
					IconsReposTimer = nil;
				end
				);
				IconsReposTimer:makeBranch(ControlPanel)
			end;
		end;
	end;
end;
};
runfnc = {4};
};
settingspane = { --Settings
"GUI Settings","System Settings","Windows Positions",
switch = {1,1,1,1,1};
fnctab =
{
function(this, parent, x, y) -- GUI Settings
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"settingsGUI",x,y,"GUI Settings","no");
	this.popup:makeBranch(this);
end;
function(this, parent, x, y) --System Settings
	this.setup = PopupMenu:new({parent.popupMenus});
	this.setup:init(this,parent,"settingsSYS",x,y,"System Settings");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) -- Positions Save
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"settingsPos",x,y,"Position Settings","no");
	this.popup:makeBranch(this);
end;
};
runfnc = {0};
};
settingsPos = {
"Reset Windows Position","Save Windows Position",
switch = {1,1};
fnctab = {
function(this, parent, x, y) -- reset pos
	if not this.MSGupT["PopRstPosMSG"] then
		this.PopRstPosMSG = PopMessage:new({parent.popupMenus});
		this.PopRstPosMSG:init(this,"PopRstPosMSG",x,y,nil,nil,nil,"yn",
		function(o)
			lastwindow = defpos();
			ControlPanel.moveButton.la = lastwindow.lastcpwx
			ControlPanel.moveButton.ba = (lastwindow.lastcpwy+lastwindow.lastcpwh)
			ControlPanel.moveButton.ra = ScrX-(lastwindow.lastcpwx+gButtonsize+lastwindow.lastcpww)
			ControlPanel.moveButton.ta = ScrY-(lastwindow.lastcpwh+lastwindow.lastcpwy+gButtonsize+gButtonspace)
			ControlPanel.moveButton.Pressed = true
			ControlPanel.moveButton.rstpos = true
			ControlPanel:resizePanel(lastwindow.lastcpww-ControlPanel.mainFrame:ww(),lastwindow.lastcpwh-ControlPanel.mainFrame:wh())
			IconsRepos = true;
			this.oribtn.oribtn:quitmenu()
		end,
		function(o)
		end
		);
		this.PopRstPosMSG.Ybranchkill = true;
		this.PopRstPosMSG:makeBranch(this);
	end;
end;
function(this, parent, x, y) -- Save Position
	if not this.MSGupT["PopMSGosavpos"] then
		this.PopMSGosavpos = PopMessage:new({parent.popupMenus});
		this.PopMSGosavpos:init(this,"PopMSGosavpos",x,y,nil,nil,nil,"yn",
		function(o)
			myCelPadHUD:saveallpos()
			this:quitmenu()
		end,
		function(o)
		end
		);
		this.PopMSGosavpos.Ybranchkill = true;
		this.PopMSGosavpos:makeBranch(this);
	end;
end;
};
runfnc = {0};
};
settingsGUI = { -- GUI Base settings
"Edit Basic GUI Settings","Edit Advanced GUI Settings","Save GUI Profile","Load GUI Profile","Delete GUI Profile",
switch = {1,1,1,1,1};
fnctab = {
function(this, parent, x, y)
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"Windows",x,y,"Basic GUI Settings");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y)
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"settingsGUIadv",x,y,"Advanced GUI Settings","no");
	this.popup:makeBranch(this);
end;
function(this,parent,x,y)-- save GUI settings
	tCelPadHUD.functions.saveDlg(this,parent,x,y,"GUI")
end;
function(this,parent,x,y) -- Load GUI settings
	tCelPadHUD.functions.loadDlg(this,parent,x,y,"GUI")
end;
function(this,parent,x,y) -- Delete GUI settings
	tCelPadHUD.functions.delDlg(this,parent,x,y,"GUI")
end;
};
runfnc = {0};
};
settingsGUIadv = { -- GUI Adv settings
"Main Window Color Deltas","Menu Color Deltas","Control Panel Color Deltas","Popup Messages Colors","Other GUI Settings",
switch = {1,1,1,1,1};
fnctab =
{
function(this, parent, x, y) -- Main Window Color Deltas
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"WindowsAdvMW",x,y,"Main Window Color Deltas");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) -- Menu Color Deltas
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"WindowsAdvMN",x,y,"Menu Color Deltas");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) -- Control Panel Color Deltas
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"WindowsAdvCP",x,y,"Control Panel Color Deltas");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) -- Popup Messages Colors
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"WindowsAdvPM",x,y,"Popup Messages Color Deltas");
	this.setup:makeBranch(this);
	local xx,yy
	xx = 100
	yy = ScrY-this.setup.menupane.ph+100
	this.PopSampa = PopMessage:new({this.setup.menupane.popupMenus});
	this.PopSampa:init(this.setup.menupane,"PopSampa",xx,yy,"Alert",templates2.popMsg.PopSamp,"a","ok");
	this.PopSampa:makeBranch(this.setup);
	this.PopSampw = PopMessage:new({this.setup.menupane.popupMenus});
	this.PopSampw:init(this.setup.menupane,"PopSampw",(xx or 0)+10,(yy or 0)+10,"Warning",templates2.popMsg.PopSamp,"w","ok");
	this.PopSampw:makeBranch(this.setup);
	this.PopSampi = PopMessage:new({this.setup.menupane.popupMenus});
	this.PopSampi:init(this.setup.menupane,"PopSampi",(xx or 0)+20,(yy or 0)+20,"Info",templates2.popMsg.PopSamp,"i","ok");
	this.PopSampi:makeBranch(this.setup);
end;
function(this, parent, x, y) -- Other Adv settings
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"WindowsAdv",x,y,"Other GUI Settings");
	this.setup:makeBranch(this);
end;
};
runfnc = {0};
};
settingsSYS = {
"Edit System Settings","Edit Min/Max Defaults","Edit Units Defaults","Save System Profile","Load System Profile","Delete System Profile",
switch = {1,1,1,1,1,1};
fnctab = {
function(this, parent, x, y) --System Settings
	this.setup = SetupMenu:new({parent.popupMenus,tCelPadHUD.setupPanes});
	this.setup:init(this,parent,"SystemSet",x,y,"System Settings");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) --Edit Min/Max Defaults
	this.setup = SetupMenu:new({parent.popupMenus});
	this.setup.objtype = "setupdlg"
	this.setup.menutab = templates.minMaxDefault
	this.setup.metatab = {};
	for k,l in pairs(templates.minMaxDefault) do
		this.setup.metatab[k] = {};
		this.setup.metatab[k][1] = templates.metaQuery[k][1]
		this.setup.metatab[k][2] = templates.metaQuery[k][2]
	end
	this.setup:init(this,parent,"minMaxDefault",x,y,"Edit Min/Max Default Limits");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) --Edit Units Defaults
	this.setup = SetupMenu:new({parent.popupMenus});
	this.setup.objtype = "setupdlg"
	this.setup.menutab = templates.metaUnits;
	this.setup.metatab = {};
	for k,l in pairs(templates.metaUnits) do
		this.setup.metatab[k] = {};
		this.setup.metatab[k][1] = templates.metaQuery[k][1]
		this.setup.metatab[k].valuelist = templates.metaUnits[k].valuelist
	end
	this.setup:init(this,parent,"defaultUnits",x,y,"Edit Units Default Settings");
	this.setup:makeBranch(this);
end;
function(this, parent, x, y) -- save System Settings
	tCelPadHUD.functions.saveDlg(this,parent,x,y,"SYS")
end;
function(this, parent, x, y) -- load System settings
	tCelPadHUD.functions.loadDlg(this,parent,x,y,"SYS")
end;
function(this, parent, x, y) -- delete System settings
	tCelPadHUD.functions.delDlg(this,parent,x,y,"SYS")
end;
};
runfnc = {0};
};
saveLoadQR = {
"Save Query","Load Query","Delete Query",
switch = {1,1,1};
fnctab = {
function(this,parent,x,y)
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.openQueries == 0 or finder.openQueries[1].objtype~="queryMenu" then
		if not this.MSGupT["PopMSGnoqr"] then
			this.PopMSGnoqr = PopMessage:new({parent.popupMenus});
			this.PopMSGnoqr:init(this,"PopMSGnoqr",x,y,nil,nil,nil,"ok");
			this.PopMSGnoqr:makeBranch(this);
		end;
	else
		if finder.setupdlg and finder.setupdlg.setuptype == "loaddlg" then
			finder.setupdlg.closebutton.Action();
			finder.setupdlg = nil;
		end;
		tCelPadHUD.functions.saveDlg(this,parent,x,y,"QR"..finder.metaQueryVal.qtype,finder)
	end;
end;
function(this,parent,x,y) -- Load Query
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.openQueries == 0 or finder.openQueries[1].objtype~="queryMenu" then
		if not this.MSGupT["PopMSGnoqr"] then
			this.PopMSGnoqr = PopMessage:new({parent.popupMenus});
			this.PopMSGnoqr:init(this,"PopMSGnoqr",x,y,nil,nil,nil,"ok");
			this.PopMSGnoqr:makeBranch(this);
		end;
	else
		if finder.setupdlg and finder.setupdlg.setuptype == "savedlg" then
			finder.setupdlg.closebutton.Action();
			finder.setupdlg = nil;
		end;
		tCelPadHUD.functions.loadDlg(this,parent,x,y,"QR"..finder.metaQueryVal.qtype,finder)
	end;
end;
function(this,parent,x,y) -- Delete Query
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"deleteQR",x,y,"Delete Query");
	this.popup:makeBranch(this);
end;
};
runfnc = {0};
};
deleteQR = {
"Delete Stars Query","Delete Satellites Query","Delete DSO Query","Delete Locations Query",
switch = {1,1,1,1};
fnctab = {
function(this,parent,x,y) -- Delete Stars Query
	local finder = this.oribtn.oribtn.oribtn.wframe.CPFinder
	tCelPadHUD.functions.delDlg(this,parent,x,y,"QRstars",finder)
end;
function(this,parent,x,y) -- Delete Planets Query
	local finder = this.oribtn.oribtn.oribtn.wframe.CPFinder
	tCelPadHUD.functions.delDlg(this,parent,x,y,"QRsatellites",finder)
end;
function(this,parent,x,y) -- Delete DSO Query
	local finder = this.oribtn.oribtn.oribtn.wframe.CPFinder
	tCelPadHUD.functions.delDlg(this,parent,x,y,"QRdsos",finder)
end;
function(this,parent,x,y) -- Delete Locations Query
	local finder = this.oribtn.oribtn.oribtn.wframe.CPFinder
	tCelPadHUD.functions.delDlg(this,parent,x,y,"QRlocations",finder)
end
};
runfnc = {0};
};
CPHelp = {
"Performance Considerations","GUI Help","Scanner Help","Selection Pad Help","Settings Help",
switch={1,1,1,1,1};
fnctab = {
function(this, parent, x, y)--Performance Considerations
	local infoattr = Help.perfHelp;
	if not ControlPanel.mainFrame.MSGupT["Help1perfHelp"] then
		this.HelpPANE1 = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.HelpPANE1.objtype = "helpPane"
		this.HelpPANE1:init(ControlPanel.mainFrame,"Help1perfHelp",x,y,"Performance Considerations",infoattr,"i","inf");
		this.HelpPANE1:makeBranch(ControlPanel);
	end;
	if this.HelpPANE1 then
		this.HelpPANE1.menupane:visible(true)
	end;
end;
function(this, parent,x, y) --GUI Help
	local infoattr = Help.guiHelp;
	if not ControlPanel.mainFrame.MSGupT["Help2guiHelp"] then
		this.HelpPANE2 = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.HelpPANE2.objtype = "helpPane"
		this.HelpPANE2:init(ControlPanel.mainFrame,"Help2guiHelp",x,y,"GUI Help",infoattr,"i","inf");
		this.HelpPANE2:makeBranch(ControlPanel);
	end;
	if this.HelpPANE2 then
		this.HelpPANE2.menupane:visible(true)
	end
end;
function(this, parent, x, y) --Scanner Help
	local infoattr = Help.scanHelp;
	if not ControlPanel.mainFrame.MSGupT["Help3scanHelp"] then
		this.HelpPANE3 = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.HelpPANE3.objtype = "helpPane"
		this.HelpPANE3:init(ControlPanel.mainFrame,"Help3scanHelp",x,y,"Scanner Help",infoattr,"i","inf");
		this.HelpPANE3:makeBranch(ControlPanel);
	end;
	if this.HelpPANE3 then
		this.HelpPANE3.menupane:visible(true)
	end
end;
function(this, parent, x, y) --Selection Pad Help
	local infoattr = Help.selpHelp;
	if not ControlPanel.mainFrame.MSGupT["Help4selpHelp"] then
		this.HelpPANE4 = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.HelpPANE4.objtype = "helpPane"
		this.HelpPANE4:init(ControlPanel.mainFrame,"Help4selpHelp",x,y,"Selection Pad Help",infoattr,"i","inf");
		this.HelpPANE4:makeBranch(ControlPanel);
	end;
	if this.HelpPANE4 then
		this.HelpPANE4.menupane:visible(true)
	end
end;
function(this, parent, x, y) --Settings Help
	local infoattr = Help.settHelp;
	if not ControlPanel.mainFrame.MSGupT["Help5settHelp"] then
		this.HelpPANE5 = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.HelpPANE5.objtype = "helpPane"
		this.HelpPANE5:init(ControlPanel.mainFrame,"Help5settHelp",x,y,"Settings Help",infoattr,"i","inf");
		this.HelpPANE5:makeBranch(ControlPanel);
	end;
	if this.HelpPANE5 then
		this.HelpPANE5.menupane:visible(true)
	end
end;
};
runfnc = {0};
};
ObsComm = {
templates.ObsComm[1],templates.ObsComm[2],templates.ObsComm[3],templates.ObsComm[4],templates.ObsComm[5],templates.ObsComm[6],templates.ObsComm[7],
switch={0,0,1,1,1,1,1,1};
fnctab = {
function(this)--Stop Observer
	local obs = observer
	templates.celcmds.cancelgoto(obs,nil)
	templates.celcmds.setspeed(obs,nil,{0})
	templates.speedtab.s1_obsspeed = 0
end;
function(this) --lookback
	local obs = observer
	templates.celcmds.rotate(obs,nil,{{0,1,0},math.pi})
end;
function(this, parent,x, y) --movement
	local finder = this.oribtn.wframe.CPFinder
	this.finder = finder
	local obs = observer
	local stretchmenu = stretchmenu
	local nspeed, ospeed, aspeed, oclutch, ounit
	local math_dround = math_dround
	local commands = templates.celcmds
	local speedtab = templates.speedtab
	local metaspeedtab = templates.metaspeedtab
	local unittable = finder.unittable
	local s_num = tonumber
	local unitfnc = unittable.s1_obsspeed[1]
	ospeed = unitfnc(obs:getspeed(),"fromnative")
	oclutch = speedtab.s4_clutchon
	this.setup = SetupMenu:new({parent.popupMenus,finder.openParDlgs});
	this.setup.finder = finder
	this.setup.menutab = speedtab
	this.setup.metatab = metaspeedtab
	this.setup.menutab.s1_obsspeed = ospeed
	this.setup:init(this,parent,"sets1_obsspeed",x,y,"Speed Parameters");
	this.setup:makeBranch(this);
	local menuitem = this.setup.setitem[1].editbox
	menuitem.wobj = this.setup
	menuitem.Customdraw = function(this)
		this.menuline:showunits(finder);
		metaspeedtab.s1_obsspeed[2] = unitfnc(speedtab.s3_increment[1],"fromnative")
		nspeed = unitfnc(speedtab.s1_obsspeed,"tonative")
		if oclutch ~= speedtab.s4_clutchon then
			if speedtab.s4_clutchon then
				commands.setspeed(obs,nil,{nspeed})
			end;
			oclutch = speedtab.s4_clutchon
		end;
		if speedtab.s4_clutchon then
			if nspeed ~= ospeed then
				commands.setspeed(obs,nil,{nspeed})
				ospeed = nspeed
			end;
			aspeed = unitfnc(obs:getspeed(),"fromnative")
			if aspeed ~= unitfnc(nspeed,"fromnative") then
				speedtab.s1_obsspeed = aspeed
			end;
		end;
		stretchmenu(this,false)
		if this.Highlight then
			this.menuline:textcolor(cpfntcolhghlt);
		else
			this.menuline:textcolor(cpcolmenul);
			if this.ch == "C-m" then
				if s_num(this.Text) == nil then
					this.Text = string.gsub(this.Text,",",".");
				end;
				if s_num(this.Text) == nil then
					this.Text = string.gsub(this.Text,"%.",",");
				end;
				if this.Text == "1,#INF" then this.Text = math.huge; end;
				if this.Text == "-1,#INF" then this.Text = -math.huge; end;
				if s_num(this.Text) ~= nil then
					this.wobj.menutab["s1_obsspeed"] = s_num(this.Text);
					this.ch = nil;
				else
					this.Text = this.wobj.menutab["s1_obsspeed"];
				end;
			else
				this.Text = math_dround(this.wobj.menutab["s1_obsspeed"],2);
			end;
		end;
	end;
end;
function(this, parent,x, y) --Observer to Position
	local finder = this.oribtn.wframe.CPFinder
	this.finder = finder
	local math_dround = math_dround
	local obs = observer
	local obs_pos = obs:getposition()
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,nil,"setposition","zcmdposition")
	this["zcmdposition"] = this["zcmdposition"] or {};
	this["zcmdposition"][1] = this["zcmdposition"][1] or math_dround(obs_pos.x,2)
	this["zcmdposition"][2] = this["zcmdposition"][2] or math_dround(obs_pos.y,2)
	this["zcmdposition"][3] = this["zcmdposition"][3] or math_dround(obs_pos.z,2)
	this.setupdlg.menutab["zcmdposition"][1] = this["zcmdposition"][1]
	this.setupdlg.menutab["zcmdposition"][2] = this["zcmdposition"][2]
	this.setupdlg.menutab["zcmdposition"][3] = this["zcmdposition"][3]
end;
function(this, parent, x, y) --Observer Rotation Switch
	local finder = this.oribtn.wframe.CPFinder
	this.finder = finder
	local obs = observer
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,nil,"rotate","zcmdvector zcmdangle")
	this["zcmdangle"] = this["zcmdangle"] or deepcopy(templates.inputParam.zcmdangle.data);
	this.setupdlg.menutab["zcmdangle"] = this["zcmdangle"]
	this["zcmdvector"] = this["zcmdvector"] or deepcopy(templates.inputParam.zcmdvector.data);
	this.setupdlg.menutab["zcmdvector"][1] = this["zcmdvector"][1]
	this.setupdlg.menutab["zcmdvector"][2] = this["zcmdvector"][2]
	this.setupdlg.menutab["zcmdvector"][3] = this["zcmdvector"][3]
end;
function(this, parent, x, y) --CLI
	tCelPadHUD.Menu.ComSetPopup.fnctab[6](this,parent,x,y);
end;
function(this, parent, x, y) --CP info - shortcut
	local finder = this.oribtn.wframe.CPFinder
	this.setup = SetupMenu:new({parent.popupMenus});
	this.setup.menutab = {
	tSettings.SystemSet.ms030AddInfo,
	finder.CMDS.cmdopts.data.co04maxCmdHist
	};
	this.setup.metatab = {
	tMetaSettings.SystemSet.ms030AddInfo,
	finder.CMDS.cmdopts.meta.co04maxCmdHist
	};
	for j,k in pairs(finder.unittable) do
		table.insert(this.setup.menutab,deepcopy(finder.unittable[j]))
		table.insert(this.setup.metatab,deepcopy(finder.unitmeta[j]))
	end
	this.setup.finder = finder
	this.setup:init(this,parent,"setObsComShort",x,y,"Settings Shortcuts","dlgao");
	this.setup:makeBranch(this);
	this.setup.setfnc = function(this)
		this.finder.unittable.s1_obsspeed = deepcopy(this.menutab[3])
		this.finder.unitmeta.s1_obsspeed = deepcopy(this.metatab[3])
		this.finder.unittable.zcmdangle = deepcopy(this.menutab[4])
		this.finder.unitmeta.zcmdangle = deepcopy(this.metatab[4])
		this.finder.unittable.zcmddistance = deepcopy(this.menutab[5])
		this.finder.unitmeta.zcmddistance = deepcopy(this.metatab[5])
		refreshInfoPanes(this.finder)
		refreshParDlgs(this.finder)
	end;
	this.setup.btnselfOK.Action = (function()
		return
		function(this)
			this.wobj:setfnc()
			this.wobj:quitpopup(this.wobj.btnbox);
		end
	end) ();
	this.setup.btnselfOK.Customdraw = function(this)
		ms030AddInfo = tSettings.SystemSet.ms030AddInfo[1]
		finder.CMDS.cmdopts.data.co04maxCmdHist =  this.wobj.menutab[2]
	end;
	this.setup.btnselfAPL.Action = (function()
		return
		function(this)
			this.wobj:setfnc()
		end
	end) ();
end;
};
runfnc = {0};
};
mvbtnpup = {
"Rename",
switch ={1};
fnctab = {
function(this, parent, x, y) --Rename
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "setupdlg"
	this.setupdlg.menutab = {winname = this.oribtn.wframe.Header;};
	this.setupdlg.metatab = {winname = {"Edit:"};};
	this.setupdlg:init(this,parent,"renamesinp",x,y,"Window Name","dlgok");
	this.setupdlg:makeBranch(this);
	this.setupdlg.btnself.wframe = this.oribtn.wframe;
	this.setupdlg.btnself.menutab = this.setupdlg.menutab;
	this.setupdlg.btnself.Customdraw = function(this)
	end;
	this.setupdlg.btnself.Action = (function()
		return
		function(this)
			this.wframe:header(this.menutab["winname"]);
			if this.wframe.CPFinder then
				this.wframe.CPFinder.Header = this.wframe.Header;
			end;
			IconsRepos = true;
			this.wobj:quitpopup(this.wobj.btnbox);
		end
	end) ();
end;
};
runfnc = {0};
};
mvbtnpupUW = {
"Scroll","Verbose","Wrap","Text","Close",
switch ={false,false,false,false,1,1};
fnctab = {
function(this) -- scroll
	this.oribtn.wframe:scroll(not this.oribtn.wframe.Scroll)
end;
function(this) --verbose
	this.oribtn.wframe:verbose(not this.oribtn.wframe.Verbose)
end;
function(this) --wrap
	this.oribtn.wframe:wrapline(not this.oribtn.wframe.Wrapline)
end;
function(this) --showtext
	this.oribtn.wframe:drawtext(not this.oribtn.wframe.Drawtext)
end;
function(this,parent,x,y) -- Close window
	local oriwobj = this.oribtn.wobj
	if not this.MSGupT["CloseWinMSG"] then
		oriwobj.CloseWinMSG = PopMessage:new({parent.popupMenus});
		oriwobj.CloseWinMSG:init(this,"CloseWinMSG",x,y,nil,nil,nil,"yn",
		function(o)
			oriwobj.closeButton.nosave = true
			oriwobj.closeButton:Action();
		end,
		function(o)
		end
		);
		oriwobj.CloseWinMSG.Ybranchkill = true;
		oriwobj.CloseWinMSG:makeBranch(this);
	end;
end;
};
runfnc = {0};
};
PopupWindow = {
"undefined","Remove Item",
switch = {0,1};
fnctab = {
function(this) -- undefined
	this:quitmenu();
end;
function(this) -- remove item
	table.remove(this.Parent.whtablepointer,this.Parent.item_index)
end;
};
runfnc = {0};
};
syslogPopup = {
"Message Pane","Remove Line","Clear Log",
switch = {1,0,1};
fnctab = {
function(this,parent,x,y) -- Message Pane
	local slTable = this.Parent.whtablepointer
	local slIndex = this.Parent.item_index
	local winhead = "Syslog ["..tostring(slTable.logNum[slIndex]).."] "..tostring(slTable.timestamp[slIndex]).."; ("..(this.oribtn.oriwobj.mainFrame.Header or "no header")..")";
	local msgtxt = tostring(slTable[slIndex])
	local msgattr = {
	"< autowrap >",
	"<-"..maxSyslWidth,
	};
	table.insert(msgattr,msgtxt)
	this.syslogInfoMSG = PopMessage:new({parent.popupMenus});
	this.syslogInfoMSG:init(this,"syslogInfoMSG",x,y,winhead,msgattr,"i","inf");
	this.syslogInfoMSG:makeBranch(this);
end;
function(this) -- remove item
	local slTable = this.Parent.whtablepointer
	local slIndex = this.Parent.item_index
	syslogRmItem(slTable,slIndex)
	this:quitmenu();
end;
function(this,parent,x,y) -- Clear Log
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	local frame = this.oribtn.oriwobj.mainFrame
	local logtbl
	if finder then
		logtbl = finder.sysLog
	else
		logtbl = frame.sysLog
	end
	if not this.MSGupT["ClearLogMSG"] then
		this.ClearLogMSG = PopMessage:new({parent.popupMenus});
		this.ClearLogMSG:init(this,"ClearLogMSG",x,y,nil,
		{templates2.popMsg.ClearLogMSG[1]..tostring(logtbl).."' ?",
		txtfnt = templates2.popMsg.ClearLogMSG.txtfnt;
		}
		,nil,"yn",
		function(o)
			syslogNil(logtbl)
			syslogInit(logtbl);
			CPlog("log cleared",0,logtbl)
			if finder then
				nilStatLogs(finder);
				tCelPadHUD.functions.viewLog(frame);
			else
				tCelPadHUD.functions.viewSysLog(frame);
			end;
		end,
		function(o)
		end
		);
		this.ClearLogMSG:makeBranch(this);
	end;
end;
};
runfnc = {0};
};
ScannerWinTB = {
"View Log","View Result Set","Scan Celestia","Scan Current Result Set","Cancel Running Scan/Copy","Copy Results to New Scanner","Copy Results to Selection Pad","Pause/Resume Process",
"Clear Result Set","Save/Load/Delete Query","Select Units","Verbose View Settings",
switch = {true,true,1,1,1,1,1,1,1,1,1,1};
fnctab = {
function(this,fncrun) -- View Log
	this.switchbox.frame = this.oribtn.wframe;
	this.switchbox.Customdraw = function(this)
		if this.frame.whtable == this.frame.CPFinder.sysLog then
			this:text("x");
		else
			this:text("");
		end;
	end;
	if not fncrun then
		tCelPadHUD.functions.viewLog(this.oribtn.wframe)
	end;
end;
function(this,fncrun) -- View Results
	this.switchbox.frame = this.oribtn.wframe;
	this.switchbox.Customdraw = function(this)
		if this.frame.whtable == this.frame.CPFinder.resultSet then
			this:text("x");
		else
			this:text("");
		end;
	end;
	if not fncrun then
		tCelPadHUD.functions.viewResults(this.oribtn.wframe)
	end;
end;
function(this,parent,x,y) -- Scan Celestia
	local finder = this.oribtn.wframe.CPFinder
	local checkScanBusy = checkScanBusy
	if checkScanBusy(finder) then
		if not this.MSGupT["PopTgtBusy"] then
			this.PopTgtBusy = PopMessage:new({parent.popupMenus});
			this.PopTgtBusy:init(this,"PopTgtBusy",x,y,nil,nil,nil,"ok");
			this.PopTgtBusy:makeBranch(this);
		end;
	elseif #finder.resultSet ~= 0 then
		if not this.MSGupT["PopMSGOKresults"] then
			this.PopMSGOKresults = PopMessage:new({parent.popupMenus});
			this.PopMSGOKresults:init(this,"PopMSGOKresults",x,y,nil,nil,nil,"ok");
			this.PopMSGOKresults:makeBranch(this);
		end;
	else
		if this.oribtn then
			finder.scanType = "cel";
		end;
		this.popup = PopupMenu:new({parent.popupMenus});
		this.popup:init(this,parent,"ScanCelMenu",x,y,"Scan Celestia","no");
		this.popup:makeBranch(this);
	end;
end;
function(this,parent,x,y) -- Scan Current Result Set
	local finder = this.oribtn.wframe.CPFinder
	local checkScanBusy = checkScanBusy
	local mergemenutabs = mergemenutabs
	if checkScanBusy(finder) or finder.niling then
		if not this.MSGupT["PopTgtBusy"] then
			this.PopTgtBusy = PopMessage:new({parent.popupMenus});
			this.PopTgtBusy:init(this,"PopTgtBusy",x,y,nil,nil,nil,"ok");
			this.PopTgtBusy:makeBranch(this);
		end;
	elseif finder.copytab and #finder.copytab > 0 then
		if not this.MSGupT["ScanCopyMSG"] then
			this.ScanCopyMSG = PopMessage:new({parent.popupMenus});
			this.ScanCopyMSG:init(this,"ScanCopyMSG",x,y,nil,{
			templates2.popMsg.ScanCopyMSG[1]..tostring(#finder.copytab),
			templates2.popMsg.ScanCopyMSG[2],
			txtfnt = templates2.popMsg.ScanCopyMSG.txtfnt;
			},nil,"ok");
			this.ScanCopyMSG:makeBranch(this);
		end;
	elseif #finder.resultSet == 0 then
		if not this.MSGupT["PopMSGOKsnoresults"] then
			this.PopMSGOKsnoresults = PopMessage:new({parent.popupMenus});
			this.PopMSGOKsnoresults:init(this,"PopMSGOKsnoresults",x,y,nil,nil,nil,"ok");
			this.PopMSGOKsnoresults:makeBranch(this);
		end;
	else
		local GetOrbs = {
		templates.GetOrbs[1],templates.GetOrbs[2],templates.GetOrbs[3],templates.GetOrbs[4],
		switch = {1,1,1,1};
		fnctab = {
		function(this,parent,x,y) --Get Children of Result Set
			local finder = this.oribtn.oribtn.wframe.CPFinder;
			if not this.MSGupT["GetOrbsMSG"] then
				finder.GetOrbsMSG = PopMessage:new({parent.popupMenus});
				finder.GetOrbsMSG:init(this,"GetOrbsMSG",x,y,nil,nil,nil,"yn",
				function()
					finder.scanWhat = "getorbs";
					finder:taskManager();
					this:quitmenu();
				end,
				function()
				end
				);
				finder.GetOrbsMSG.Ybranchkill = true
				finder.GetOrbsMSG:makeBranch(this.oribtn.popup.menupane);
			end;
		end;
		function(this,parent,x,y) --Get Locations
			local finder = this.oribtn.oribtn.wframe.CPFinder;
			if not this.MSGupT["GetLocsMSG"] then
				finder.GetLocsMSG = PopMessage:new({parent.popupMenus});
				finder.GetLocsMSG:init(this,"GetLocsMSG",x,y,nil,nil,nil,"yn",
				function()
					finder.scanWhat = "getlocs";
					finder:taskManager();
					this:quitmenu();
				end,
				function()
				end
				);
				finder.GetLocsMSG.Ybranchkill = true
				finder.GetLocsMSG:makeBranch(this.oribtn.popup.menupane);
			end;
		end;
		function(this,parent,x,y) --Get Parents of Result Set
			local finder = this.oribtn.oribtn.wframe.CPFinder;
			if not this.MSGupT["GetParsMSG"] then
				finder.GetParsMSG = PopMessage:new({parent.popupMenus});
				finder.GetParsMSG:init(this,"GetParsMSG",x,y,nil,nil,nil,"yn",
				function()
					finder.scanWhat = "getpars";
					finder:taskManager();
					this:quitmenu();
				end,
				function()
				end
				);
				finder.GetParsMSG.Ybranchkill = true
				finder.GetParsMSG:makeBranch(this.oribtn.popup.menupane);
			end;
		end;
		function(this,parent,x,y) --Summarize Result Set
			this.finder = this.oribtn.oribtn.wframe.CPFinder
			if #this.finder.openQueries == 1 then
				this.finder.openQueries[1].closebutton.Action();
			end;
			this.finder.SUM.mtdlg = MultiMenu:new({parent.popupMenus,this.finder.openQueries});
			this.finder.SUM.mtdlg.srctab = this.finder.SUM.srctab
			if this.mvitem then
				this.finder.SUM.mtdlg.menutab = this.menutab
				this.finder.SUM.mtdlg.metatab = this.metatab
				this.menutab = nil
				this.metatab = nil
				this.mvitem = false
			end;
			this.finder.SUM.mtdlg.what = "SUM"
			this.finder.SUM.mtdlg.finder = this.finder
			this.finder.SUM.mtdlg:init(this,parent,"SummaryData",x,y,"Summary","dlgok");
			this.finder.SUM.mtdlg:makeBranch(this);
			this.finder.SUM.mtdlg.btnselfOK.oribtn = this
			this.finder.SUM.mtdlg.btnselfOK.Action = (function()
				return
				function(this)
					this.wobj:writeTabs();
					this.oribtn.finder.scanWhat = "summary";
					this.oribtn.finder:taskManager();
					this.oribtn:quitmenu();
				end
			end) ();
			this.what = this.finder.SUM.mtdlg.what;
			this.finder.SUM.mtdlg.menupane:visible(this.finder.SUM.mtdlg.metatab.Vis)
			if ms065VwSumAutoLd and this.finder.newSwhat and not this.sumloaded then
				local vwindx = templates.vwindx;
				if vwindx[this.finder.newSwhat] then
					myCelPad:loadCP("SUM",vwindx[this.finder.newSwhat],this.finder)
				end;
				this.sumloaded = true;
			end;
		end;
		};
		runfnc = {0};
		};
		finder.scanType = "rs";
		nilStatLogs(finder);
		this.popup = PopupMenu:new({parent.popupMenus});
		this.popup.menutab = mergemenutabs(tCelPadHUD.Menu["ScanCelMenu"],GetOrbs);
		this.popup:init(this,parent,"ScanCelMenu",x,y,"Scan Result Set","no");
		this.popup:makeBranch(this);
	end;
end;
function(this,parent,x,y) --Cancel Running Scan
	local finder = this.oribtn.wframe.CPFinder
	if not this.MSGupT["PopMSGOKnoscan"] then
		if not (finder.runningScan or finder.runningTask ~= 0 ) then
			this.PopMSGOKnoscan = PopMessage:new({parent.popupMenus});
			this.PopMSGOKnoscan:init(this,"PopMSGOKnoscan",x,y,nil,nil,nil,"ok");
			this.PopMSGOKnoscan:makeBranch(this);
		else
			if finder.runningTask == 100 then
				finder.CancelCopyMSG = PopMessage:new({parent.popupMenus});
				finder.CancelCopyMSG:init(this,"CancelCopyMSG",x,y,nil,nil,nil,"yn",
				function(o)
					if finder.feeder then
						CPlog("cancelling copy",0,finder.sysLog);
						finder.feeder.cancelrq = true;
					else
						CPlog("nothing to cancel",0,finder.sysLog);
					end;
				end,
				function(o)
				end
				);
				finder.CancelCopyMSG:makeBranch(this);
			else
				finder.CancelScanMSG = PopMessage:new({parent.popupMenus});
				finder.CancelScanMSG:init(this,"CancelScanMSG",x,y,nil,nil,nil,"yn",
				function(o)
					CPlog("cancelling scan",0,finder.sysLog);
					finder.cancelscan = true;
				end,
				function(o)
				end
				);
				finder.CancelScanMSG:makeBranch(this);
			end
		end;
	end;
end;
function(this,parent,x,y) -- Duplicate Scanner
	tCelPadHUD.Menu.SelectionLogTB.fnctab[5](this,parent,x,y);
end;
function(this,parent,x,y) -- Feed Log Window From Current Set
	tCelPadHUD.Menu.FeedLog.fnctab[1](this,parent,x,y);
end;
function(this,parent,x,y) -- Pause/Resume
	local finder = this.oribtn.wframe.CPFinder
	if (checkFindPrgs(finder) or checkScanBusy(finder)) and finder.niling ~= "resultSet" then
		local pausquest
		if finder.paused then
			pausquest = "Resume paused";
		else
			pausquest = "Pause running";
		end;
		if not this.MSGupT["pauseQuestMSG"] then
			this.pauseQuestMSG = PopMessage:new({parent.popupMenus});
			this.pauseQuestMSG:init(this,"pauseQuestMSG",x,y,nil,{
			pausquest..templates2.popMsg.pauseQuestMSG[1],
			txtfnt = templates2.popMsg.pauseQuestMSG.txtfnt;
			},nil,"yn",
			function()
				if (checkFindPrgs(finder) or checkScanBusy(finder)) and finder.niling ~= "resultSet" then
					finder.paused = not finder.paused
					local pausmsg
					if finder.paused then
						pausmsg = "paused"
					else
						pausmsg = "resumed"
					end
					CPlog("process "..pausmsg,0,finder.sysLog)
				else
					if not this.MSGupT["noPauseMSG"] then
						this.noPauseMSG = PopMessage:new({parent.popupMenus});
						this.noPauseMSG:init(this,"noPauseMSG",x,y,nil,nil,nil,"ok");
						this.noPauseMSG:makeBranch(this);
					end
				end
			end,
			function()
			end
			);
			this.pauseQuestMSG:makeBranch(this);
		end
	else
		if not this.MSGupT["noPauseMSG"] then
			this.noPauseMSG = PopMessage:new({parent.popupMenus});
			this.noPauseMSG:init(this,"noPauseMSG",x,y,nil,nil,nil,"ok");
			this.noPauseMSG:makeBranch(this);
		end
	end
end;
function(this,parent,x,y) -- Clear Current Set
	local finder = this.oribtn.wframe.CPFinder
	local checkScanBusy = checkScanBusy
	if #finder.resultSet == 0 then
		if not this.MSGupT["PopMSGOKnoresults"] then
			this.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
			this.PopMSGOKnoresults:init(this,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
			this.PopMSGOKnoresults:makeBranch(this);
		end;
	else
		if checkScanBusy(finder) or checkFindPrgs(finder) then
			if not this.MSGupT["ClearRunningMSG"] then
				this.ClearRunningMSG = PopMessage:new({parent.popupMenus});
				this.ClearRunningMSG:init(this,"ClearRunningMSG",x,y,nil,nil,nil,"ok");
				this.ClearRunningMSG:makeBranch(this);
			end;
		else
			if not this.MSGupT["ClearSetMSG"] then
				finder.ClearSetMSG = PopMessage:new({parent.popupMenus});
				finder.ClearSetMSG:init(this,"ClearSetMSG",x,y,nil,nil,nil,"yn",
				function(o)
					if finder.niling then
						this.PopMSGOKniling = PopMessage:new({parent.popupMenus});
						this.PopMSGOKniling:init(this,"PopMSGOKniling",x,y,nil,nil,nil,"ok");
						this.PopMSGOKniling:makeBranch(this);
					elseif finder.copytab and #finder.copytab > 0 then
						this.ClearCopyMSG = PopMessage:new({parent.popupMenus});
						this.ClearCopyMSG:init(this,"ClearCopyMSG",x,y,nil,{
						templates2.popMsg.ClearCopyMSG[1]..tostring(#finder.copytab),
						templates2.popMsg.ClearCopyMSG[2],
						txtfnt = templates2.popMsg.ClearCopyMSG.txtfnt;
						},nil,"ok");
						this.ClearCopyMSG:makeBranch(this);
					elseif checkScanBusy(finder) or checkFindPrgs(finder) or (finder.runningCommands and #finder.runningCommands ~= 0) then
						if not this.MSGupT["ClearRunningMSG"] then
							this.ClearRunningMSG = PopMessage:new({parent.popupMenus});
							this.ClearRunningMSG:init(this,"ClearRunningMSG",x,y,nil,nil,nil,"ok");
							this.ClearRunningMSG:makeBranch(this);
						end;
					else
						CPlog("clearing result set ("..tostring(#finder.resultSet).." objects)",0,finder.sysLog);
						nilResSet(finder,"resultSet",true)
						if parent.menuline[5].popup then
							parent.menuline[5].popup.closebutton.Action();
						end;
						if finder.findertype == 2 then
							finder.CMDS.cmdopts.data.co01startobj = nil;
							finder.CMDS.cmdopts.data.co02endobj = nil;
						end
						nilStatLogs(finder)
						if this.oribtn.wframe.whtable ~= finder.sysLog then
							this.oribtn.wframe.whtable = finder.resultSet
							this.oribtn.wframe.whtable.txtcol = {};
						end;
					end;
				end,
				function(o)
				end
				);
				finder.ClearSetMSG:makeBranch(this);
			end;
		end;
	end;
end;
function(this,parent,x,y) -- Save/Load Query
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"saveLoadQR",x,y,"Save/Load Query");
	this.popup:makeBranch(this);
end;
function(this,parent,x,y) -- Select Units
	local deepcopy = deepcopy
	local finder = this.oribtn.wframe.CPFinder
	this.setup = SetupMenu:new({parent.popupMenus});
	this.setup.objtype = "setupdlg"
	this.setup.menutab = deepcopy(finder.unittable)
	this.setup.metatab = deepcopy(finder.unitmeta)
	this.setup.finder = finder
	this.setup:init(this,parent,"Units",x,y,"Select Units","dlgao");
	this.setup:makeBranch(this);
	this.setup.setfnc = function(this)
		this.finder.unittable = deepcopy(this.menutab)
		this.finder.unitmeta = deepcopy(this.metatab)
		if this.finder.findertype == 1 and #this.finder.openQueries > 0 then
			local query = this.finder.openQueries[1]
			query.btnbox.Stck = query.menupane.Sticky
			query.btnbox.Hid = query.menupane.Hiding
			query.btnbox.Vis = query.menupane.Visible
			query.btnbox.popupmenu(query.btnbox,query.parent,query.menupane.la,ScrY-query.menupane.ta)
		end;
		refreshInfoPanes(this.finder)
		refreshParDlgs(this.finder)
		if this.finder.findertype == 2 then
			refreshCommCons(this.finder)
		end
	end;
	this.setup.btnselfOK.Action = (function()
		return
		function(this)
			this.wobj.setfnc(this.wobj)
			this.wobj:quitpopup(this.wobj.btnbox);
		end
	end) ();
	this.setup.btnselfAPL.Action = (function()
		return
		function(this)
			this.wobj.setfnc(this.wobj)
		end
	end) ();
end;
function(this,parent,x,y) -- Verbose View Settings
	this.finder = this.oribtn.wframe.CPFinder
	this.finder.VW.mtdlg = MultiMenu:new({parent.popupMenus});
	this.finder.VW.mtdlg.srctab = this.finder.VW.srctab
	if this.mvitem then
		this.finder.VW.mtdlg.menutab = this.menutab
		this.finder.VW.mtdlg.metatab = this.metatab
		this.menutab = nil
		this.metatab = nil
		this.mvitem = false
	end;
	this.finder.VW.mtdlg.what = "VW"
	this.finder.VW.mtdlg.finder = this.finder
	this.finder.VW.mtdlg:init(this,parent,"CustomizeView",x,y,"Customize View","dlgok");
	this.finder.VW.mtdlg:makeBranch(this);
	this.mtdlg = this.finder.VW.mtdlg;
	this.what = this.finder.VW.mtdlg.what;
	this.finder.VW.mtdlg.menupane:visible(this.finder.VW.mtdlg.metatab.Vis)
end;
};
runfnc = {1,2};
};
SelectionLogTB = {
"View Log","View Records","Add Current Selection to Records","Copy Records / Cancel Copy","Copy Records to New Scanner","Mark Records","Command Set","Pause/Resume Process",
"Clear Records","Select Units","Verbose View Settings",
switch = {true,true,1,1,1,1,1,1,1,1,1};
fnctab = {
function(this,fncrun) -- View Log Sellog
	tCelPadHUD.Menu.ScannerWinTB.fnctab[1](this,fncrun);
end;
function(this,fncrun) -- View Results Sellog
	tCelPadHUD.Menu.ScannerWinTB.fnctab[2](this,fncrun);
end;
function(this,parent,x,y) -- Selection Add
	this.oribtn.addselbtn.popupmenu(this.oribtn.addselbtn,parent,x,y);
end;
function(this,parent,x,y) --copy records
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"FeedLog",x,y,"Copy to Selection Pad","no");
	this.popup:makeBranch(this);
end;
function(this,parent,x,y) --create scanner
	local finder = this.oribtn.wframe.CPFinder
	local checkFindPrgs, checkScanBusy = checkFindPrgs, checkScanBusy
	if #finder.resultSet == 0 then
		if not this.MSGupT["PopMSGOKnoresults"] then
			this.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
			this.PopMSGOKnoresults:init(this,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
			this.PopMSGOKnoresults:makeBranch(this);
		end;
	else
		if checkFindPrgs(finder) then
			if not this.MSGupT["SrcBusyMSG"] then
				this.SrcBusyMSG = PopMessage:new({parent.popupMenus});
				this.SrcBusyMSG:init(this,"SrcBusyMSG",x,y,nil,nil,nil,"ok");
				this.SrcBusyMSG:makeBranch(this.oribtn);
			end;
		else
			if not this.MSGupT["openNewScMSG"] then
				finder.openNewScMSG = PopMessage:new({parent.popupMenus});
				finder.openNewScMSG:init(this,"openNewScMSG",x,y,nil,nil,nil,"yn",
				function(o)
					if checkScanBusy(finder) or checkFindPrgs(finder) then
						if not this.MSGupT["SrcBusyMSG"] then
							this.SrcBusyMSG = PopMessage:new({parent.popupMenus});
							this.SrcBusyMSG:init(this,"SrcBusyMSG",x,y,nil,nil,nil,"ok");
							this.SrcBusyMSG:makeBranch(this.oribtn);
						end;
					else
						local duplicatedFinderWin = tCelPadHUD.Menu.CPpopup.fnctab[1](this)
						cloneFinder(finder,duplicatedFinderWin)
						duplicatedFinderWin.mainFrame.CPFinder:copyItems(finder);
						local itemnum = #finder.resultSet
						CPlog("copying "..tostring(itemnum).." items to "..tostring(duplicatedFinderWin.mainFrame.CPFinder.Header),0,finder.sysLog)
						CPlog("copying "..tostring(itemnum).." items from "..tostring(finder.Header),0,duplicatedFinderWin.mainFrame.CPFinder.sysLog)
						if parent.menuline[5].popup then
							parent.menuline[5].popup.closebutton.Action();
						end;
					end;
				end,
				function(o)
				end
				);
				finder.openNewScMSG:makeBranch(this);
			end;
		end;
	end;
end;
function(this,parent,x,y) --Mark Records
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"MarkObjects",x,y,"Mark Result Set","no");
	this.popup:makeBranch(this);
end;
function(this,parent,x,y) --Command Set
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"ComSet",x,y,"Command Set","no");
	this.popup:makeBranch(this);
end;
function(this,parent,x,y) -- Pause/Resume
	tCelPadHUD.Menu.ScannerWinTB.fnctab[8](this,parent,x,y)
end;
function(this,parent,x,y) -- Clear All
	tCelPadHUD.Menu.ScannerWinTB.fnctab[9](this,parent,x,y)
end;
function(this,parent,x,y) --Select Units
	tCelPadHUD.Menu.ScannerWinTB.fnctab[11](this,parent,x,y);
end;
function(this,parent,x,y) --Verbose View Settings
	tCelPadHUD.Menu.ScannerWinTB.fnctab[12](this,parent,x,y);
end;
};
runfnc = {1,2};
};
ScanCelMenu = {
"Scan Stars","Scan Satellites","Scan Deep Space Objects","Scan Locations",
switch = {1,1,1,1};
fnctab = {
function(this,parent,x,y) --Scan Stars
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.openQueries == 1 then
		finder.openQueries[1].closebutton.Action();
	end;
	finder.queryVal = finder.queryStars;
	finder.metaQueryVal = finder.metaQueryStars;
	finder.scanWhat = "stars";
	this.inquery = QueryMenu:new({parent.popupMenus,finder.openQueries});
	this.inquery.menutab = finder.queryVal;
	this.inquery.menutab.qr017_type_str = nil;
	this.inquery.metatab = finder.metaQueryVal;
	this.inquery.finder = finder
	this.inquery.menuline = this
	this.inquery.oriparent = parent;
	this.inquery:init(this,parent,"Scan",x,y,"Scan Stars","dlgok");
	this.inquery:makeBranch(this);
	this.inquery.btnself.oribtn = this.oribtn;
	if not finder.defQRSloaded then
		finder.defQRSloaded = true;
		myCelPad:loadCP("QRstars","default",finder);
	end
end;
function(this,parent,x,y) --scan planets/moons
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.openQueries == 1 then
		finder.openQueries[1].closebutton.Action();
	end;
	finder.queryVal = finder.queryPlanets;
	finder.metaQueryVal = finder.metaQueryPlanets;
	finder.scanWhat = "satellites";
	this.inquery = QueryMenu:new({parent.popupMenus,finder.openQueries});
	this.inquery.menutab = finder.queryVal;
	this.inquery.metatab = finder.metaQueryVal;
	this.inquery.finder = finder;
	this.inquery.menuline = this
	this.inquery.oriparent = parent;
	this.inquery:init(this,parent,"Scan",x,y,"Scan Planets/Moons","dlgok");
	this.inquery:makeBranch(this)
	this.inquery.btnself.oribtn = this.oribtn;
	if not finder.defQROloaded then
		myCelPad:loadCP("QRsatellites","default",finder);
		finder.defQROloaded = true;
	end
end;
function(this,parent,x,y) -- Scan for Deep Space Objects
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.openQueries == 1 then
		finder.openQueries[1].closebutton.Action();
	end;
	finder.queryVal = finder.queryDsos;
	finder.metaQueryVal = finder.metaQueryDsos;
	this.inquery = QueryMenu:new({parent.popupMenus,finder.openQueries});
	this.inquery.menutab = finder.queryVal;
	this.inquery.metatab = finder.metaQueryVal;
	this.inquery.finder = finder;
	this.inquery.menuline = this
	this.inquery.oriparent = parent;
	this.inquery:init(this,parent,"Scan",x,y,"Scan Deep Space Objects","dlgok");
	this.inquery:makeBranch(this)
	this.inquery.btnself.oribtn = this.oribtn;
	finder.scanWhat = "dsos";
	if not finder.defQRDloaded then
		myCelPad:loadCP("QRdsos","default",finder);
		finder.defQRDloaded = true;
	end
end;
function(this,parent,x,y) -- Scan for Locations
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.openQueries == 1 then
		finder.openQueries[1].closebutton.Action();
	end;
	finder.queryVal = finder.queryLocations;
	finder.metaQueryVal = finder.metaQueryLocations;
	this.inquery = QueryMenu:new({parent.popupMenus,finder.openQueries});
	this.inquery.menutab = finder.queryVal;
	this.inquery.metatab = finder.metaQueryVal;
	this.inquery.finder = finder;
	this.inquery.menuline = this
	this.inquery.oriparent = parent;
	this.inquery:init(this,parent,"Scan",x,y,"Scan Locations","dlgok");
	this.inquery:makeBranch(this)
	this.inquery.btnself.oribtn = this.oribtn;
	finder.scanWhat = "locations";
	if not finder.defQRLloaded then
		myCelPad:loadCP("QRlocations","default",finder);
		finder.defQRLloaded = true;
	end
end;
};
runfnc = {0};
};
ResultSetItem = {
"Info Pane","Select","Center","GoTo","Follow","Copy to Selection Pad","Remove from Result Set","More Commands",
switch = {1,0,1,1,0,1,1,1};
fnctab = {
function(this, parent, x, y)  --Celestia Info Pane
	local locCObjTab = this.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.Parent.item_index;
	local celobj = locCObjTab[locItemIndex]
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	tCelPadHUD.functions.infoPane(this,parent,x,y,finder,celobj)
end;
function(this) -- Select Cel Obj
	local locCObjTab = this.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.Parent.item_index;
	templates.celcmds.select(nil,locCObjTab[locItemIndex])
end;
function(this,parent,x,y) --Center
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = this.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	this.finder = finder
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,object,"center","zcmdduration")
	this["zcmdduration"] = this["zcmdduration"] or ms150defDur;
	this.setupdlg.menutab["zcmdduration"] = this["zcmdduration"]
	if not ms140askForDur then
		this.setupdlg.btnself:Action(this.setupdlg.btnself)
	end;
end;
function(this,parent,x,y) -- Go To Obj
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = this.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	this.finder = finder
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,object,"goto","zcmdduration zcmdintpol")
	this["zcmdduration"] = this["zcmdduration"] or ms150defDur;
	this.setupdlg.menutab["zcmdduration"] = this["zcmdduration"]
	this["zcmdintpol"] = this["zcmdintpol"] or deepcopy(templates.inputParam.zcmdintpol.data);
	this.setupdlg.menutab["zcmdintpol"][1] = this["zcmdintpol"][1]
	this.setupdlg.menutab["zcmdintpol"][2] = this["zcmdintpol"][2]
	if not ms140askForDur then
		this.setupdlg.btnself:Action(this.setupdlg.btnself)
	end;
end;
function(this) --Follow
	local locCObjTab = this.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	templates.celcmds.follow(obs,object)
end;
function(this,parent,x,y) --Copy
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.Parent.item_index;
	local object = locCObjTab[locItemIndex];
	local checkFindPrgs = checkFindPrgs
	local logstbl = tCelPadFinder.runningLogs;
	local findertype = finder.findertype;
	local duplicatedFinder
	if #logstbl==(findertype-1) then
		duplicatedFinder = tCelPadHUD.Menu.CPpopup.fnctab[2](this);
		cloneFinder(finder,duplicatedFinder)
	end;
	local logTblSel = {tablsel = {valuelist = {};};};
	if finder == logstbl[#logstbl] then
		table.insert(logTblSel["tablsel"],logstbl[1]);
	else
		table.insert(logTblSel["tablsel"],logstbl[#logstbl]);
	end;
	for i,v in ipairs(logstbl) do
		table.insert(logTblSel["tablsel"]["valuelist"],v);
	end;
	local metaLogTblSel = {tablsel = {"Target",valuelist={};};};
	for i,v in ipairs(logstbl) do
		table.insert(metaLogTblSel["tablsel"]["valuelist"],v.Header);
	end;
	this.setup = SetupMenu:new({parent.popupMenus});
	this.setup.objtype = "setupdlg"
	this.setup.menutab = logTblSel;
	this.setup.metatab = metaLogTblSel;
	this.setup:init(this,parent,"tablsel",x,y,"Log Select","dlgok");
	this.setup:makeBranch(this)
	this.setup.btnself.oribtn = this.oribtn.oribtn;
	this.setup.btnself.oriparent = this.oribtn;
	this.setup.btnself.logtblsel = logTblSel;
	this.setup.btnself.obj = object;
	this.setup.btnself.cnum = celnum;
	this.setup.btnself.finder = finder;
	this.setup.btnself.Action = (function()
		return
		function(this)
			if this.logtblsel["tablsel"][1].active then
				if this.finder == this.logtblsel["tablsel"][1] then
					if not this.MSGupT["noSelfCpMSG"] then
						this.noSelfCpMSG = PopMessage:new({parent.popupMenus});
						this.noSelfCpMSG:init(this,"noSelfCpMSG",x,y,nil,nil,nil,"ok");
						this.noSelfCpMSG:makeBranch(this);
					end;
				else
					if checkFindPrgs(this.logtblsel["tablsel"][1]) then
						if not this.MSGupT["PopTgtBusy"] then
							this.PopTgtBusy = PopMessage:new({parent.popupMenus});
							this.PopTgtBusy:init(this,"PopTgtBusy",x,y,nil,nil,nil,"ok");
							this.PopTgtBusy:makeBranch(this);
						end;
					else
						local itemnum = #this.finder.resultSet
						CPlog("copying object "..tostring(this.obj:name()).." to "..tostring(this.logtblsel["tablsel"][1].Header),0,this.finder.sysLog)
						CPlog("copying object "..tostring(this.obj:name()).." from "..tostring(this.finder.Header),0,this.logtblsel["tablsel"][1].sysLog)
						local tgttbl = this.logtblsel["tablsel"][1];
						table.insert(tgttbl.resultSet,this.obj);
						this.wobj:quitpopup(this.wobj.btnbox);
					end;
				end;
			else
				if not this.MSGupT["noTgtMSG"] then
					this.noTgtMSG = PopMessage:new({parent.popupMenus});
					this.noTgtMSG:init(this,"noTgtMSG",x,y,tostring(this.logtblsel["tablsel"][1].Header),nil,nil,"ok");
					this.noTgtMSG:makeBranch(this.wobj.btnbox);
					this.wobj:quitpopup(this.wobj.btnbox);
				end;
			end;
		end
	end) ();
end;
function(this,parent,x,y) -- delete Sel Obj
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local object = locCObjTab[this.Parent.item_index];
	local name = tostring(object:getinfo().name)
	if not this.MSGupT["DelItemMSG"] then
		finder.DelItemMSG = PopMessage:new({parent.popupMenus});
		finder.DelItemMSG:init(this,"DelItemMSG",x,y,nil,{
		templates2.popMsg.DelItemMSG[1],
		name.." ?",
		txtfnt = templates2.popMsg.DelItemMSG.txtfnt;
		},nil,"yn",
		function(o)
			if checkFindPrgs(finder) or checkScanBusy(finder) then
				if not this.MSGupT["ClearRunningMSG"] then
					this.ClearRunningMSG = PopMessage:new({parent.popupMenus});
					this.ClearRunningMSG:init(this,"ClearRunningMSG",x,y,nil,nil,nil,"ok");
					this.ClearRunningMSG:makeBranch(this);
				end;
			else
				if finder.findertype == 2 then
					local cmdopts = finder.CMDS.cmdopts.data
					if cmdopts.co02endobj and this.Parent.item_index <= cmdopts.co02endobj then
						cmdopts.co02endobj = cmdopts.co02endobj - 1
						if cmdopts.co01startobj and cmdopts.co02endobj < cmdopts.co01startobj then
							cmdopts.co02endobj = cmdopts.co01startobj
						end;
					end;
					if cmdopts.co01startobj and this.Parent.item_index < cmdopts.co01startobj then
						cmdopts.co01startobj = cmdopts.co01startobj - 1
					end;
					if #locCObjTab == 0 then
						cmdopts.co01startobj = nil;
						cmdopts.co02endobj = nil;
					end
				end;
				table.remove(locCObjTab,this.Parent.item_index);
				CPlog("manually removed object "..name,0,finder.sysLog)
			end;
		end,
		function(o)
		end
		);
		finder.DelItemMSG:makeBranch(this);
	end;
end;
function(this, parent, x, y)  --More
	local finder = this.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.Parent.item_index;
	local object = locCObjTab[locItemIndex];
	local name = tostring(object:getinfo().name)
	local dlgname = "ResSetMore";
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup.menutab = tCelPadHUD.Menu["ResSetMore"]
	if finder.findertype == 2 then
		this.popup.menutab = mergemenutabs(this.popup.menutab,tCelPadHUD.Menu["SelLogPopup"]);
		dlgname = "ResSetMoreSP"
	end;
	this.popup:init(this,parent,dlgname,x,y,"More ["..name.."]","no");
	this.popup:makeBranch(this);
end;
};
runfnc = {0};
};
ResSetMore = {
"Track","Chase","Sync Orbit","Center Orbit","Surface","GoTo (parametric)","Visible ON/OFF","Open Info URL","Get Orbiting Bodies","Get Locations","Get Parent",
switch = {false,0,0,1,1,1,false,1,1,1,0};
fnctab = {
function(this,fncrun) --Track
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local trk_object = obs:gettrackedobject()
	finder.itemcelcmd = finder.itemcelcmd or {};
	if not fncrun then
		finder.itemcelcmd[locItemIndex] = not finder.itemcelcmd[locItemIndex]
	end;
	this.switchbox.Customdraw = function(this)
		if trk_object == object or finder.itemcelcmd[locItemIndex] then
			this:text("x")
			templates.celcmds.track(obs,object)
		else
			this:text(" ")
			templates.celcmds.track(obs,nil)
		end
	end;
end;
function(this) --Chase
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	templates.celcmds.chase(obs,object)
end;
function(this) --Sync Orbit
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	templates.celcmds.synchronous(obs,object)
end;
function(this,parent,x,y) --Center orbit
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	this.finder = finder
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,object,"centerorbit","zcmdduration")
	this["zcmdduration"] = this["zcmdduration"] or ms150defDur;
	this.setupdlg.menutab["zcmdduration"] = this["zcmdduration"]
	if not ms140askForDur then
		this.setupdlg.btnself:Action(this.setupdlg.btnself)
	end;
end;
function(this, parent, x, y) -- Surface/
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	this.finder = finder
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,object,"gotosurface","zcmdduration")
	this["zcmdduration"] = this["zcmdduration"] or ms150defDur;
	this.setupdlg.menutab["zcmdduration"] = this["zcmdduration"]
	if not ms140askForDur then
		this.setupdlg.btnself:Action(this.setupdlg.btnself)
	end;
end;
function(this,parent,x,y) -- Go To adv
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	local params = "zcmdduration zcmddistance zcmdlonglat zcmdvector"
	this.finder = finder
	tCelPadHUD.functions.parDlg(this,parent,x,y,obs,object,"gotolonglat",params)
	local lradius = object:getinfo().radius
	if not lradius then
		if object:getinfo().parent then
			lradius = object:getinfo().parent:getinfo().radius
		else
			lradius = 100
		end
	end
	this["zcmddistance"] = this["zcmddistance"] or math.ceil(lradius*ms151defRadMtpl)
	this.setupdlg.menutab["zcmddistance"] = this["zcmddistance"]
	this["zcmdduration"] = this["zcmdduration"] or ms150defDur;
	this.setupdlg.menutab["zcmdduration"] = this["zcmdduration"]
	this["zcmdvector"] = this["zcmdvector"] or deepcopy(templates.inputParam.zcmdvector.data);
	this.setupdlg.menutab["zcmdvector"][1] = this["zcmdvector"][1]
	this.setupdlg.menutab["zcmdvector"][2] = this["zcmdvector"][2]
	this.setupdlg.menutab["zcmdvector"][3] = this["zcmdvector"][3]
	this["zcmdlonglat"] = this["zcmdlonglat"] or deepcopy(templates.inputParam.zcmdlonglat.data);
	this.setupdlg.menutab["zcmdlonglat"][1] = this["zcmdlonglat"][1]
	this.setupdlg.menutab["zcmdlonglat"][2] = this["zcmdlonglat"][2]
end;
function(this,fncrun) --Visible
	local locCObjTab = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	this.switchbox.Customdraw = function(this)
		if object:visible() then
			this:text("x")
		else
			this:text(" ")
		end
	end;
	if not fncrun then
		object:setvisible(not object:visible())
	end;
end;
function(this, parent, x, y) --open URL
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local object = locCObjTab[locItemIndex]
	local iURL = object:getinfo().infoURL
	if not iURL then
		if not this.MSGupT["noUrlMSG"] then
			this.noUrlMSG = PopMessage:new({parent.popupMenus});
			this.noUrlMSG:init(this,"noUrlMSG",x,y,nil,{
			templates2.popMsg.noUrlMSG[1]..tostring(object:name()),
			txtfnt = templates2.popMsg.noUrlMSG.txtfnt;
			},nil,"ok");
			this.noUrlMSG:makeBranch(this);
		end
	elseif  iURL=="" or iURL==" " then
		if not this.MSGupT["emptyUrlMSG"] then
			this.emptyUrlMSG = PopMessage:new({parent.popupMenus});
			this.emptyUrlMSG:init(this,"emptyUrlMSG",x,y,nil,{
			templates2.popMsg.emptyUrlMSG[1]..tostring(object:name()),
			txtfnt = templates2.popMsg.emptyUrlMSG.txtfnt;
			},nil,"ok");
			this.emptyUrlMSG:makeBranch(this);
		end
	else
		if not this.MSGupT["openUrlMSG"] then
			this.openUrlMSG = PopMessage:new({parent.popupMenus});
			this.openUrlMSG:init(this,"openUrlMSG",x,y,nil,nil,nil,"yn",
			function(o)
				CPlog("CelPad: opening URL "..tostring(iURL))
				CPlog("opening URL "..tostring(iURL),0,finder.sysLog)
				os.execute(URLstartCMD..iURL)
			end,
			function(o)
			end
			)
			this.openUrlMSG:makeBranch(this);
		end;
	end;
end;
function(this, parent, x, y) --Get Orbiting Bodies
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local object = locCObjTab[locItemIndex];
	local getbods = function()
		local duplicatedFinder = tCelPadHUD.Menu.CPpopup.fnctab[finder.findertype](this);
		cloneFinder(finder,duplicatedFinder)
		duplicatedFinder.mainFrame.CPFinder.tasknum = 1;
		duplicatedFinder.mainFrame.CPFinder:getBodies(object);
		tCelPadHUD.functions.viewResults(duplicatedFinder.mainFrame)
		if ms065VwSumAutoLd then
			myCelPad:loadCP("VW","satellites",duplicatedFinder.mainFrame.CPFinder)
		end;
	end;
	if finder.posDed then
		if not this.MSGupT["noDedupMSG"] then
			this.noDedupMSG = PopMessage:new({parent.popupMenus});
			this.noDedupMSG:init(this,"noDedupMSG",x,y,nil,nil,nil,"yn",
			getbods,
			function(o)
			end
			);
			this.noDedupMSG:makeBranch(this);
		end;
	else
		getbods();
	end;
end;
function(this, parent, x, y) --Get Locations
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local object = locCObjTab[locItemIndex];
	local getlocs = function()
		local duplicatedFinder = tCelPadHUD.Menu.CPpopup.fnctab[finder.findertype](this);
		cloneFinder(finder,duplicatedFinder)
		duplicatedFinder.mainFrame.CPFinder.tasknum = 1;
		duplicatedFinder.mainFrame.CPFinder:getLocations(object);
		tCelPadHUD.functions.viewResults(duplicatedFinder.mainFrame)
		if ms065VwSumAutoLd then
			myCelPad:loadCP("VW","locations",duplicatedFinder.mainFrame.CPFinder)
		end;
	end;
	if finder.posDed then
		if not this.MSGupT["noDedupMSG"] then
			this.noDedupMSG = PopMessage:new({parent.popupMenus});
			this.noDedupMSG:init(this,"noDedupMSG",x,y,nil,nil,nil,"yn",
			getlocs,
			function(o)
			end
			);
			this.noDedupMSG:makeBranch(this);
		end;
	else
		getlocs();
	end;
end;
function(this) --Get Parent
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local object = locCObjTab[locItemIndex]:getinfo().parent;
	local obtype = locCObjTab[locItemIndex]:getinfo().type
	local duplicatedFinder = tCelPadHUD.Menu.CPpopup.fnctab[finder.findertype](this);
	cloneFinder(finder,duplicatedFinder)
	table.insert(duplicatedFinder.mainFrame.CPFinder.resultSet,object);
	tCelPadHUD.functions.viewResults(duplicatedFinder.mainFrame)
	if ms065VwSumAutoLd then
		local ldwhat = "stars"
		if obtype ~= "star" and obtype ~= "planet" then ldwhat = "satellites" end;
		if obtype == "location" then ldwhat = "satellites" end;
		myCelPad:loadCP("VW",ldwhat,duplicatedFinder.mainFrame.CPFinder)
	end;
end;
};
runfnc = {1,7};
};
SelLogPopup = {
"Mark/Unmark","Ref. Mark Add/Remove","Command Set","Move Up","Move Down",
switch = {1,1,1,0,0};
fnctab = {
function(this, parent, x, y) -- Mark/Unmark
	local finder = this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local object = locCObjTab[locItemIndex]
	local commands = templates.celcmds;
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "params"
	this.setupdlg.menutab = finder.markerParams;
	this.setupdlg.metatab = finder.metaMarkerParams;
	this.setupdlg:init(this,parent,"markerParams",x,y,"Marker Parameters","dlgao");
	this.setupdlg:makeBranch(this)
	this.setupdlg.btnselfAPL:text("Add")
	this.setupdlg.btnselfOK:text("Rmv")
	celestia:show("markers")
	this.setupdlg.btnselfAPL.object = object
	this.setupdlg.btnselfOK.object = object
	this.setupdlg.btnselfAPL.Action = (function()
		return
		function(this)
			commands.unmark(nil,object,{})
			commands.mark(nil,object,{finder.markerParams.zmkp1color[1], finder.markerParams.zmkp2shape[1], finder.markerParams.zmkp3size, finder.markerParams.zmkp4opaque, finder.markerParams.zmkp5occlud})
		end
	end) ();
	this.setupdlg.btnselfOK.Action = (function()
		return
		function(this)
			commands.unmark(nil,object,{})
		end
	end) ();
end;
function(this, parent, x, y) -- ref
	local finder =  this.oribtn.oribtn.oriwobj.mainFrame.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex = this.oribtn.Parent.item_index;
	local obs = observer
	local object = locCObjTab[locItemIndex]
	local tgt, refmtbl
	local getKeyName = getKeyName
	local table_num = table_num
	local math_round = math_round
	local cursel = celestia:getselection()
	local locexit = function(this,srctype)
		if not parent.MSGupT["refNotPossMSG"] then
			local xx,yy
			xx = this.wobj.menupane.la
			yy = this.wobj.menupane.ba
			finder.refNotPossMSG = PopMessage:new({parent.popupMenus});
			finder.refNotPossMSG:init(parent,"refNotPossMSG",xx,yy,nil,{
			templates2.popMsg.refNotPossMSG[1].." '"..tostring(srctype).."'.",
			txtfnt = templates2.popMsg.refNotPossMSG.txtfnt;
			},nil,"ok");
			finder.refNotPossMSG:makeBranch(parent);
		end;
	end;
	local paramsnum = #finder.refmarkParams.zrtag.valuelist
	for t = 3,paramsnum do
		finder.refmarkParams.zrtag.valuelist[t]=nil;
	end
	if tCelPadFinder.refMarked[getKeyName(object)] then
		for i,v in pairs(tCelPadFinder.refMarked[getKeyName(object)]) do
			local isthere=false
			for k,l in ipairs(finder.refmarkParams.zrtag.valuelist) do
				if l==v then
					isthere=true
				end
			end
			if not isthere then
				table.insert(finder.refmarkParams.zrtag.valuelist,v)
			end
		end
	end
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "params"
	this.setupdlg.menutab = deepcopy(finder.refmarkParams);
	this.setupdlg.metatab = deepcopy(finder.metaRefmarkParams);
	this.setupdlg:init(this,parent,"refmarkParams",x,y,"Reference Mark Parameters","dlgao");
	this.setupdlg:makeBranch(this)
	this.setupdlg.btnselfAPL:text("Add")
	this.setupdlg.btnselfOK:text("Rmv")
	this.setupdlg.btnselfAPL.Action = (function()
		return
		function(this)
			cursel = celestia:getselection()
			if cursel:getinfo().type == "null" then
				if not parent.MSGupT["noRefSelMSG"] then
					local xx,yy
					xx = this.wobj.menupane.la
					yy = this.wobj.menupane.ba
					finder.noRefSelMSG = PopMessage:new({parent.popupMenus});
					finder.noRefSelMSG:init(parent,"noRefSelMSG",xx,yy,nil,nil,nil,"ok");
					finder.noRefSelMSG:makeBranch(parent);
				end;
			else
				if this.wobj.menutab.srctgt[1] == "objtosel" then
					this.src = object
					tgt = cursel
				elseif this.wobj.menutab.srctgt[1] == "seltoobj" then
					this.src = cursel
					tgt = object
				end
				if string.find("star location globular nebula opencluster galaxy",this.src:getinfo().type) then
					locexit(this,this.src:getinfo().type)
				elseif getKeyName(this.src) == getKeyName(tgt) then
					if not parent.MSGupT["sameRefMSG"] then
						local xx,yy
						xx = this.wobj.menupane.la
						yy = this.wobj.menupane.ba
						finder.sameRefMSG = PopMessage:new({parent.popupMenus});
						finder.sameRefMSG:init(parent,"sameRefMSG",xx,yy,nil,nil,nil,"ok");
						finder.sameRefMSG:makeBranch(parent);
					end;
				else
					local rupdating = false
					local unqtgtname = getKeyName(tgt)
					local unqsrcname = getKeyName(this.src)
					local tgttag = this.wobj.menutab.rtype[1]..unqtgtname
					if tCelPadFinder.refMarked[unqsrcname] and tCelPadFinder.refMarked[unqsrcname][tgttag] then
						rupdating = true
						if not parent.MSGupT["refExMSG"] then
							local xx,yy
							xx = this.wobj.menupane.la
							yy = this.wobj.menupane.ba
							finder.refExMSG = PopMessage:new({parent.popupMenus});
							finder.refExMSG:init(parent,"refExMSG",xx,yy,nil,{
							templates2.popMsg.refExMSG[1]..tostring(this.wobj.menutab.rtype[1]),
							templates2.popMsg.refExMSG[2]..this.src:name()..templates2.popMsg.refExMSG[3]..tgt:name()..templates2.popMsg.refExMSG[4],
							txtfnt = templates2.popMsg.refExMSG.txtfnt;
							},nil,"ok",2);
							finder.refExMSG:makeBranch(parent);
						end;
					end
					refmtbl = {};
					refmtbl.type = this.wobj.menutab.rtype[1];
					if rupdating then
						this.src:removereferencemark(tgttag)
					else
						this.wobj.menutab.rsize = math_round(this.src:getinfo().radius)
					end
					refmtbl.size =   this.wobj.menutab.rsize;
					refmtbl.color =  this.wobj.menutab.rcolor[1];
					refmtbl.opacity =  this.wobj.menutab.ropacity;
					refmtbl.tag = tgttag
					refmtbl.target = tgt
					this.src:addreferencemark(refmtbl)
					tCelPadFinder.refMarked[unqsrcname] = tCelPadFinder.refMarked[unqsrcname] or {}
					tCelPadFinder.refMarked[unqsrcname][tgttag] = unqtgtname
					tCelPadFinder.refMarked.celObj[unqsrcname] = this.src
					local isthere=false
					for i,v in ipairs(this.wobj.menutab.zrtag.valuelist) do
						if v==unqtgtname then
							isthere=true
						end
					end
					if not isthere then
						local indxtag = #this.wobj.menutab.zrtag.valuelist+1
						this.wobj.menutab.zrtag.valuelist[indxtag] = unqtgtname
					end
					this.wobj.menutab.zrtag[1] = unqtgtname
				end
			end
		end
	end) ();
	this.setupdlg.btnselfOK.Action = (function()
		return
		function(this)
			local lczrtag = this.wobj.menutab.zrtag[1]
			local rmtag = this.wobj.menutab.rtype[1]..lczrtag
			cursel = celestia:getselection()
			if this.wobj.menutab.srctgt[1] == "objtosel" then
				this.src = object
				tgt = cursel
			elseif this.wobj.menutab.srctgt[1] == "seltoobj" then
				this.src = cursel
				tgt = object
			end
			if string.find("star location ",this.src:getinfo().type) or this.src:getinfo().hubbleType then
				locexit(this,this.src:getinfo().type)
			else
				local srckeyname = getKeyName(this.src)
				local rmfnc = function(rmtag)
					if not tCelPadFinder.refMarked[srckeyname] or not tCelPadFinder.refMarked[srckeyname][rmtag] then
						if not parent.MSGupT["noRefMarkMSG"] then
							local xx,yy
							xx = this.wobj.menupane.la
							yy = this.wobj.menupane.ba
							finder.noRefMarkMSG = PopMessage:new({parent.popupMenus});
							finder.noRefMarkMSG:init(parent,"noRefMarkMSG",xx,yy,nil,{
							templates2.popMsg.noRefMarkMSG[1]..tostring(this.wobj.menutab.rtype[1]).."'",
							templates2.popMsg.noRefMarkMSG[2]..tostring(this.src:name())..templates2.popMsg.noRefMarkMSG[3]..tostring(string.gsub(this.wobj.menutab.zrtag[1],".*/",""))..templates2.popMsg.noRefMarkMSG[4],
							txtfnt = templates2.popMsg.noRefMarkMSG.txtfnt;
							},nil,"ok");
							finder.noRefMarkMSG:makeBranch(parent);
						end;
					else
						this.src:removereferencemark(rmtag)
						tCelPadFinder.refMarked[srckeyname][rmtag] = nil
						if lczrtag == "allloc" then
							for u =3,#this.wobj.menutab.zrtag.valuelist do
								this.wobj.menutab.zrtag.valuelist[u]=nil
							end
						else
							local isthere = false
							for a,b in pairs(tCelPadFinder.refMarked[srckeyname]) do
								if b == lczrtag then
									isthere = true
								end
							end;
							if not isthere then
								local indx = 0
								for i,k in ipairs(this.wobj.menutab.zrtag.valuelist) do
									if k == lczrtag then
										indx = i
									end
								end
								table.remove(this.wobj.menutab.zrtag.valuelist,indx)
							end;
						end
						if table_num(tCelPadFinder.refMarked[srckeyname]) == 0 then
							tCelPadFinder.refMarked[srckeyname] = nil
							tCelPadFinder.refMarked.celObj[srckeyname] = nil
						end
						this.wobj.menutab.zrtag[1] = this.wobj.menutab.zrtag.valuelist[1]
					end
				end
				if lczrtag == "allloc" then
					if not tCelPadFinder.refMarked[srckeyname] then
						if not parent.MSGupT["noRefMarkAllMSG"] then
							local xx,yy
							xx = this.wobj.menupane.la
							yy = this.wobj.menupane.ba
							finder.noRefMarkAllMSG = PopMessage:new({parent.popupMenus});
							finder.noRefMarkAllMSG:init(parent,"noRefMarkAllMSG",xx,yy,nil,{
							templates2.popMsg.noRefMarkAllMSG[1]..tostring(this.src:name()),
							txtfnt = templates2.popMsg.noRefMarkAllMSG.txtfnt;
							},nil,"ok");
							finder.noRefMarkAllMSG:makeBranch(parent);
						end;
					else
						if not parent.MSGupT["unrefAllLocMSG"] then
							local xx,yy
							xx = this.wobj.menupane.la
							yy = this.wobj.menupane.ba
							finder.unrefAllLocMSG = PopMessage:new({parent.popupMenus});
							finder.unrefAllLocMSG:init(parent,"unrefAllLocMSG",xx,yy,nil,{
							templates2.popMsg.unrefAllLocMSG[1]..tostring(this.src:name()).."?",
							txtfnt = templates2.popMsg.unrefAllLocMSG.txtfnt;
							},nil,"yn",
							function(o)
								for k,v in pairs(tCelPadFinder.refMarked[srckeyname]) do
									rmfnc(k)
								end
								this.wobj.menutab.zrtag[1] = this.wobj.menutab.zrtag.valuelist[1]
							end,
							function(o)
							end
							);
							finder.unrefAllLocMSG:makeBranch(parent);
						end;
					end
				elseif lczrtag == "allglob" then
					if not parent.MSGupT["unrefAllGlobMSG"] then
						local xx,yy
						xx = this.wobj.menupane.la
						yy = this.wobj.menupane.ba
						finder.unrefAllGlobMSG = PopMessage:new({parent.popupMenus});
						finder.unrefAllGlobMSG:init(parent,"unrefAllGlobMSG",xx,yy,nil,nil,nil,"yn",
						function(o)
							rmAllRefMarks();
							this.wobj:quitpopup(this.wobj.btnbox)
						end,
						function(o)
						end
						);
						finder.unrefAllGlobMSG:makeBranch(parent);
					end;
				else
					if not parent.MSGupT["unrefObjMSG"] then
						local xx,yy
						xx = this.wobj.menupane.la
						yy = this.wobj.menupane.ba
						finder.unrefObjMSG = PopMessage:new({parent.popupMenus});
						finder.unrefObjMSG:init(parent,"unrefObjMSG",xx,yy,nil,{
						templates2.popMsg.unrefObjMSG[1]..tostring(this.wobj.menutab.rtype[1])..templates2.popMsg.unrefObjMSG[2],
						templates2.popMsg.unrefObjMSG[3]..tostring(this.src:name())..tostring(templates2.popMsg.unrefObjMSG[4])..tostring(string.gsub(rmtag,".*/","")).."?",
						txtfnt = templates2.popMsg.unrefObjMSG.txtfnt;
						}
						,nil,"yn",
						function(o)
							rmfnc(rmtag)
						end,
						function(o)
						end
						);
						finder.unrefObjMSG:makeBranch(parent);
					end
				end
			end
		end
	end) ();
end;
function(this, parent, x, y) -- Comm Set
	this.popup = PopupMenu:new({parent.popupMenus});
	this.popup:init(this,parent,"ComSetPopup",x,y,"Command Set","no");
	this.popup:makeBranch(this);
end;
function(this) -- Move Up
	local wframe = this.oribtn.oribtn.oriwobj.mainFrame
	local finder = wframe.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex, itemLine
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	local makeMove = function()
		locItemIndex = this.oribtn.Parent.item_index;
		itemLine = locItemIndex%wframe.Maxpageitems
		if wframe.Scroll then wframe:scroll(false) end;
		if itemLine == 0 then itemLine = wframe.Maxpageitems end
		if locItemIndex > 1 then
			locCObjTab[locItemIndex-1],locCObjTab[locItemIndex] = locCObjTab[locItemIndex],locCObjTab[locItemIndex-1];
			locItemIndex = locItemIndex - 1
			if wframe.lineoffset > 0 and itemLine - 1 <= wframe.lineoffset then
				wframe.lineoffset = wframe.lineoffset - 1
			end
			if ((locItemIndex-1*0)/(wframe.pagenumber-1)) == wframe.Maxpageitems then
				wframe.pagenumber = wframe.pagenumber - 1
				wframe.lineoffset = wframe.Maxpageitems
			else
				if wframe.pagenumber ~= (math.floor((locItemIndex-2/2)/wframe.Maxpageitems))+1 then
					wframe.pagenumber = (math.floor((locItemIndex-2/2)/wframe.Maxpageitems))+1
				end
				if itemLine < wframe.lineoffset + 2 then
					wframe.lineoffset = itemLine - 2
				end
				if itemLine > wframe.lineoffset + wframe.endline then
					wframe.lineoffset = itemLine - wframe.endline - 1
				end
			end
			if finder.cmdset and finder.cmdset.ik then
				local cmdopts = finder.CMDS.cmdopts.data
				if finder.cmdset.ik == locItemIndex then
					finder.cmdset.ik = finder.cmdset.ik + 1
					if locItemIndex == cmdopts.co02endobj then
						finder.cmdset.ik = cmdopts.co02endobj - 1
						if finder.cmdset.cmdtimer then
							finder.cmdset.cmdtimer:killchain()
						end
					end;
				elseif finder.cmdset.ik == locItemIndex + 1 then
					finder.cmdset.ik = finder.cmdset.ik - 1
					if finder.cmdset.ik < cmdopts.co01startobj then
						if finder.cmdset.cmdtimer then
							finder.cmdset.cmdtimer:killchain()
						end
					end
				end
			end
		end;
	end;
	if this.mntimer then
		this.mntimer.status = "kill";
		this.mntimer = nil;
	end;
	this.xdone = nil;
	makeMove()
	this.Customdraw = function(this)
		if this.Pressed then
			if this.xdone == nil then
				this.xdone = true;
				menudelay=ldelay1;
			else
				menudelay=ldelay2;
			end;
			if not this.mntimer then
				timerrand=tostring(math.random());
				this.mntimer = CPtimer:new({tCelPad.Timers})
				this.mntimer:init("mntimer","mntimer:"..timerrand,menudelay,"standalone",0,
				function(o)
					if this.Pressed then
						makeMove()
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.mntimer = nil;
				end
				);
				this.mntimer:makeBranch(ControlPanel)
			end;
		end
	end;
end;
function(this) -- Move Down
	local wframe = this.oribtn.oribtn.oriwobj.mainFrame
	local finder = wframe.CPFinder
	local locCObjTab = finder.resultSet;
	local locItemIndex, itemLine
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	local makeMove = function()
		locItemIndex = this.oribtn.Parent.item_index;
		itemLine = locItemIndex%wframe.Maxpageitems
		if wframe.Scroll then wframe:scroll(false) end;
		if itemLine == 0 then itemLine = wframe.Maxpageitems end
		if locItemIndex < #locCObjTab then
			locCObjTab[locItemIndex+1],locCObjTab[locItemIndex] = locCObjTab[locItemIndex],locCObjTab[locItemIndex+1];
			locItemIndex = locItemIndex + 1
			if wframe.lineoffset < wframe.Maxpageitems and itemLine >= wframe.lineoffset + wframe.endline then
				wframe.lineoffset = wframe.lineoffset + 1
			end
			if ((locItemIndex-1)/(wframe.pagenumber)) == wframe.Maxpageitems then
				wframe.pagenumber = wframe.pagenumber + 1
				wframe.lineoffset = 0
			else
				if wframe.pagenumber ~= (math.floor((locItemIndex-1*2)/wframe.Maxpageitems))+1 then
					wframe.pagenumber = (math.floor((locItemIndex-1*2)/wframe.Maxpageitems))+1
				end
				if itemLine < wframe.lineoffset + 1 then
					wframe.lineoffset = itemLine
				end
				if itemLine > wframe.lineoffset + wframe.endline then
					wframe.lineoffset = itemLine - wframe.endline + 1
				end
			end
			if finder.cmdset and finder.cmdset.ik then
				local cmdopts = finder.CMDS.cmdopts.data
				if finder.cmdset.ik == locItemIndex then
					finder.cmdset.ik = finder.cmdset.ik - 1
					if locItemIndex == cmdopts.co01startobj then
						finder.cmdset.cmdtimer:killchain()
					end
				elseif finder.cmdset.ik == locItemIndex - 1 then
					finder.cmdset.ik = finder.cmdset.ik + 1
					if finder.cmdset.ik > cmdopts.co02endobj then
						if finder.cmdset.cmdtimer then
							finder.cmdset.cmdtimer:killchain()
						end
					end
				end
			end
		end;
	end;
	if this.mntimer then
		this.mntimer.status = "kill";
		this.mntimer = nil;
	end;
	this.xdone = nil;
	makeMove()
	this.Customdraw = function(this)
		if this.Pressed then
			if this.xdone == nil then
				this.xdone = true;
				menudelay=ldelay1;
			else
				menudelay=ldelay2;
			end;
			if not this.mntimer then
				timerrand=tostring(math.random());
				this.mntimer = CPtimer:new({tCelPad.Timers})
				this.mntimer:init("mntimer","mntimer:"..timerrand,menudelay,"standalone",0,
				function(o)
					if this.Pressed then
						makeMove()
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.mntimer = nil;
				end
				);
				this.mntimer:makeBranch(ControlPanel)
			end;
		end
	end;
end;
};
runfnc = {0};
};
MarkObjects = {
"Mark Current Set","Unmark Current Set","Cancel Marking/Unmarking","Unmark All",
switch = {1,1,1,1};
fnctab = {
function(this, parent, x, y) --Mark Current Set
	local finder = this.oribtn.oribtn.wframe.CPFinder
	local markerstart = markerstart
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "params"
	this.setupdlg.menutab = finder.markerParams;
	this.setupdlg.metatab = finder.metaMarkerParams;
	this.setupdlg:init(this,parent,"markerParamsSet",x,y,"Marker Parameters","dlgok");
	this.setupdlg:makeBranch(this)
	this.setupdlg.btnself.oribtn = this.oribtn.oribtn;
	this.setupdlg.btnself.oriparent = this.oribtn;
	this.setupdlg.btnself.Action = (function()
		return
		function(this)
			markerstart("mark",finder,this,parent,x,y)
		end
	end) ();
end;
function(this, parent, x, y) --Unmark Current Set
	local finder = this.oribtn.oribtn.wframe.CPFinder
	local markerstart = markerstart
	markerstart("unmark",finder,this, parent, x, y)
end;
function(this, parent, x, y) --Cancel Marking/Unmarking
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if not finder.marker then
		if not this.MSGupT["noMarkMSG"] then
			this.noMarkMSG = PopMessage:new({parent.popupMenus});
			this.noMarkMSG:init(this,"noMarkMSG",x,y,nil,nil,nil,"ok");
			this.noMarkMSG:makeBranch(this.oribtn);
		end;
	else
		if not this.MSGupT["CancelMarkMSG"] then
			finder.CancelMarkMSG = PopMessage:new({parent.popupMenus});
			finder.CancelMarkMSG:init(this,"CancelMarkMSG",x,y,nil,nil,nil,"yn",
			function(o)
				if finder.marker then
					CPlog("cancelling marking/unmarking",0,finder.sysLog);
					finder.marker.cancelrq = true;
					this.oribtn.popup = this.oribtn.popup:quitpopup(this.oribtn);
				else
					CPlog("nothing to cancel",0,finder.sysLog);
				end;
			end,
			function(o)
			end
			);
			finder.CancelMarkMSG:makeBranch(this.oribtn);
		end;
	end;
end;
function(this, parent, x, y) --Unmark All
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if not this.MSGupT["UnmarkAllMSG"] then
		finder.UnmarkAllMSG = PopMessage:new({parent.popupMenus});
		finder.UnmarkAllMSG:init(this,"UnmarkAllMSG",x,y,nil,nil,nil,"yn",
		function(o)
			CPlog("unmarking everything",0,finder.sysLog);
			celestia:unmarkall();
		end,
		function(o)
		end
		);
		finder.UnmarkAllMSG:makeBranch(this);
	end;
end;
};
runfnc = {0};
};
FeedLog = {
"Copy to other Pad Window","Cancel Copy to this Pad",
switch = {1,1};
fnctab = {
function(this,parent,x,y) --Copy to Selection Pad Window
	local finder, findertype
	local checkFindPrgs, checkScanBusy = checkFindPrgs, checkScanBusy
	local duplicatedFinder
	if this.oribtn.oribtn then
		findertype = this.oribtn.oribtn.wframe.CPFinder.findertype
		finder = this.oribtn.oribtn.wframe.CPFinder
	else
		findertype = this.oribtn.wframe.CPFinder.findertype
		finder = this.oribtn.wframe.CPFinder
	end;
	if #finder.resultSet == 0 then
		if not this.MSGupT["PopMSGOKnoresults"] then
			this.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
			this.PopMSGOKnoresults:init(this,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
			this.PopMSGOKnoresults:makeBranch(this);
		end;
	else
		if #tCelPadFinder.runningLogs==(findertype-1) then
			duplicatedFinder = tCelPadHUD.Menu.CPpopup.fnctab[2](this);
			cloneFinder(finder,duplicatedFinder)
		end;
		local logstbl = tCelPadFinder.runningLogs;
		local logTblSel = {tablsel = {valuelist = {};};};
		if finder == logstbl[#logstbl] then
			table.insert(logTblSel["tablsel"],logstbl[1]);
		else
			table.insert(logTblSel["tablsel"],logstbl[#logstbl]);
		end;
		for i,v in ipairs(logstbl) do
			table.insert(logTblSel["tablsel"]["valuelist"],v);
		end;
		local metaLogTblSel = {tablsel = {"Target",valuelist={};};};
		for i,v in ipairs(logstbl) do
			table.insert(metaLogTblSel["tablsel"]["valuelist"],v.Header);
		end;
		this.setup = SetupMenu:new({parent.popupMenus});
		this.setup.objtype = "setupdlg"
		this.setup.menutab = logTblSel;
		this.setup.metatab = metaLogTblSel;
		this.setup:init(this,parent,"tablsel",x,y,"Log Select","dlgok");
		this.setup:makeBranch(this)
		if this.oribtn.oribtn then
			this.setup.btnself.oribtn = this.oribtn.oribtn;
		else
			this.setup.btnself.oribtn = this.oribtn;
		end;
		this.setup.btnself.oriparent = this.oribtn;
		this.setup.btnself.logtblsel = logTblSel;
		this.setup.btnself.Action = (function()
			return
			function(this)
				if this.logtblsel["tablsel"][1].active then
					if #finder.resultSet ~= 0 then
						if (checkFindPrgs(finder) or checkScanBusy(finder)) and not finder.cmdset then
							if not this.MSGupT["SrcBusyMSG"] then
								this.SrcBusyMSG = PopMessage:new({parent.popupMenus});
								this.SrcBusyMSG:init(this,"SrcBusyMSG",x,y,nil,nil,nil,"ok");
								this.SrcBusyMSG:makeBranch(this.oribtn);
								this.wobj:quitpopup(this.wobj.btnbox);
								if finder.findertype == 2 then
									this.oriparent.popup = this.oriparent.popup:quitpopup(this.oriparent);
								end;
							end;
						else
							if finder == this.logtblsel["tablsel"][1] then
								if not this.MSGupT["noSelfCpMSG"] then
									this.noSelfCpMSG = PopMessage:new({parent.popupMenus});
									this.noSelfCpMSG:init(this,"noSelfCpMSG",x,y,nil,nil,nil,"ok");
									this.noSelfCpMSG:makeBranch(this);
								end;
							else
								if checkFindPrgs(this.logtblsel["tablsel"][1]) then
									if not this.MSGupT["PopTgtBusy"] then
										this.PopTgtBusy = PopMessage:new({parent.popupMenus});
										this.PopTgtBusy:init(this,"PopTgtBusy",x,y,nil,nil,nil,"ok");
										this.PopTgtBusy:makeBranch(this);
									end;
								else
									local itemnum = #finder.resultSet
									CPlog("copying "..tostring(itemnum).." items to "..tostring(this.logtblsel["tablsel"][1].Header),0,finder.sysLog)
									CPlog("copying "..tostring(itemnum).." items from "..tostring(finder.Header),0,this.logtblsel["tablsel"][1].sysLog)
									this.logtblsel["tablsel"][1]:copyItems(finder);
									if finder.findertype == 1 and parent.menuline[5].popup then
										parent.menuline[5].popup.closebutton.Action();
									end;
									this.wobj:quitpopup(this.wobj.btnbox);
								end;
							end;
						end;
					else
						if not this.MSGupT["PopMSGOKnoresults"] then
							this.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
							this.PopMSGOKnoresults:init(this,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
							this.PopMSGOKnoresults:makeBranch(this.oribtn);
							this.wobj:quitpopup(this.wobj.btnbox);
							if finder.findertype == 2 then
								this.oriparent.popup = this.oriparent.popup:quitpopup(this.oriparent);
							end;
						end;
					end;
				else
					if not this.MSGupT["noTgtMSG"] then
						this.noTgtMSG = PopMessage:new({parent.popupMenus});
						this.noTgtMSG:init(this,"noTgtMSG",x,y,tostring(this.logtblsel["tablsel"][1].Header),nil,nil,"ok");
						this.noTgtMSG:makeBranch(this.oribtn);
						this.wobj:quitpopup(this.wobj.btnbox);
						if finder.findertype == 2 then
							this.oriparent.popup = this.oriparent.popup:quitpopup(this.oriparent);
						end;
					end;
				end;
			end
		end) ();
	end
end;
function(this,parent,x,y)--Cancel Copy
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if not finder.feeder then
		if not this.MSGupT["noCopyMSG"] then
			this.noCopyMSG = PopMessage:new({parent.popupMenus});
			this.noCopyMSG:init(this,"noCopyMSG",x,y,nil,nil,nil,"ok");
			this.noCopyMSG:makeBranch(this.oribtn);
			this.oribtn.popup = this.oribtn.popup:quitpopup(this.oribtn);
		end;
	else
		if not this.MSGupT["CancelCopyMSG"] then
			finder.CancelCopyMSG = PopMessage:new({parent.popupMenus});
			finder.CancelCopyMSG:init(this,"CancelCopyMSG",x,y,nil,nil,nil,"yn",
			function(o)
				if finder.feeder then
					CPlog("copy cancelled",0,finder.sysLog);
					finder.feeder.cancelrq = true;
				else
					CPlog("nothing to cancel",0,finder.sysLog);
				end
				this.oribtn.popup = this.oribtn.popup:quitpopup(this.oribtn);
			end,
			function(o)
			end
			);
			finder.CancelCopyMSG:makeBranch(this.oribtn);
		end;
	end;
end;
};
runfnc = {0};
};
SavLdMT = {
"Save ","Load ","Delete ",
switch = {1,1,1};
fnctab = {
function(this,parent,x,y) --Save MT
	local finder = parent.wobj.finder
	local what = parent.wobj.what
	if finder.setupdlg and finder.setupdlg.setuptype == "loaddlg" then
		finder.setupdlg.closebutton.Action();
		finder.setupdlg = nil;
	end
	tCelPadHUD.functions.saveDlg(this,parent,x,y,what,finder)
end;
function(this,parent,x,y) --Load MT
	local finder = parent.wobj.finder
	local what = parent.wobj.what
	if finder.setupdlg and finder.setupdlg.setuptype == "savedlg" then
		finder.setupdlg.closebutton.Action();
		finder.setupdlg = nil;
	end;
	tCelPadHUD.functions.loadDlg(this,parent,x,y,what,finder)
end;
function(this,parent,x,y) --Delete MT
	local finder = parent.wobj.finder
	local what = parent.wobj.what
	tCelPadHUD.functions.delDlg(this,parent,x,y,what,finder)
end;
};
runfnc = {0};
};
ComSet = {
"Command Set Panel","Run Commands on Records","Info Pane of Running Object","Goto Running Object","Cancel Running Commands","Command Set Options",
switch = {1,1,1,1,1,1};
fnctab = {
function(this,parent,x,y) -- Command Set
	local finder = this.oribtn.oribtn.wframe.CPFinder
	tCelPadHUD.functions.cmdsDlg(this,parent,x,y,finder)
end;
function(this,parent,x,y) --run
	local finder = this.oribtn.oribtn.wframe.CPFinder
	local cmdstart = cmdstart
	local cmdmenutab, cmdmetatab
	cmdmenutab = {srot={{},choicelist={};};}
	cmdmetatab = {srot={"Window(s)",choicelist={};};};
	local logstbl = tCelPadFinder.runningLogs;
	for i,v in ipairs(logstbl) do
		if #v.resultSet > 0 then
			if v == finder then
				table.insert(cmdmenutab["srot"][1],true)
			else
				table.insert(cmdmenutab["srot"][1],false)
			end
			table.insert(cmdmenutab["srot"]["choicelist"],v);
		end;
	end;
	for i,v in ipairs(logstbl) do
		table.insert(cmdmetatab["srot"]["choicelist"],v.Header);
	end;
	if #cmdmenutab["srot"]["choicelist"] == 0 then
		if not this.MSGupT["noAvailCmdsMSG"] then
			this.noAvailCmdsMSG = PopMessage:new({parent.popupMenus});
			this.noAvailCmdsMSG:init(this,"noAvailCmdsMSG",x,y,nil,nil,nil,"ok");
			this.noAvailCmdsMSG:makeBranch(this);
		end;
	else
		this.setupdlg = SetupMenu:new({parent.popupMenus});
		this.setupdlg.objtype = "params"
		this.setupdlg.menutab = cmdmenutab;
		this.setupdlg.metatab = cmdmetatab;
		this.setupdlg:init(this,parent,"runCmdsDlg",x,y,"Run Command Sets","dlgok");
		this.setupdlg:makeBranch(this)
		this.setupdlg.btnself.oribtn = this.oribtn.oribtn;
		this.setupdlg.btnself.oriparent = this.oribtn;
		this.setupdlg.btnself.wobj = this
		this.setupdlg.btnself.Action = (function()
			return
			function(this)
				local runtab, runlist = {}, "";
				for i,l in ipairs(cmdmenutab["srot"][1]) do
					if l then
						table.insert(runtab,cmdmenutab["srot"]["choicelist"][i])
						runlist = runlist..cmdmenutab["srot"]["choicelist"][i].Header.."; "
					end
				end
				local runfnc = function()
					if #runtab == 0 then
						if not this.MSGupT["cmdNoSelectMSG"] then
							this.cmdNoSelectMSG = PopMessage:new({parent.popupMenus});
							this.cmdNoSelectMSG:init(this.wobj,"cmdNoSelectMSG",x,y,nil,nil,nil,"ok")
							this.cmdNoSelectMSG:makeBranch(this.wobj)
						end
					else
						for k,l in ipairs(runtab) do
							if l.active then
								if l ~= finder then
									CPlog("command set start requested from '"..finder.Header.."'",0,l.sysLog)
								end
								cmdstart(l,this.wobj, parent, x, y)
							else
								this.noTgtMSG = PopMessage:new({parent.popupMenus});
								this.noTgtMSG:init(this.wobj,"noTgtMSG",x,y,tostring(l.Header),nil,nil,"ok")
								this.noTgtMSG:makeBranch(this.wobj)
							end;
						end
					end
				end;
				if #runtab > 1 then
					if not this.MSGupT["toRunCmdsMSG"] then
						this.toRunCmdsMSG = PopMessage:new({parent.popupMenus});
						this.toRunCmdsMSG:init(this.wobj,"toRunCmdsMSG",x,y,nil,
						{
						templates2.popMsg["toRunCmdsMSG"][1],
						templates2.popMsg["toRunCmdsMSG"][2],
						templates2.popMsg["toRunCmdsMSG"][3],
						templates2.popMsg["toRunCmdsMSG"][4]..tostring(runlist),
						txtfnt = templates2.popMsg["toRunCmdsMSG"].txtfnt;
						}
						,nil,"yn",
						function(o)
							runfnc()
						end,
						function(o)
						end
						)
						this.toRunCmdsMSG:makeBranch(this.wobj)
					end
				else
					runfnc()
				end
				this.wobj.setupdlg:quitpopup(this.wobj.setupdlg.btnbox);
			end
		end) ();
	end
end;
function(this,parent,x,y) --Info pane
	local finder = this.oribtn.oribtn.wframe.CPFinder
	local locCObjTab = this.oribtn.oribtn.wframe.CPFinder.resultSet;
	if finder.cmdset then
		local locItemIndex = finder.cmdset.ik
		local celobj = locCObjTab[locItemIndex]
		finder.cmdInfo = tCelPadHUD.functions.infoPane(this,parent,x,y,finder,celobj)
	else
		if not this.MSGupT["noCmdsMSG"] then
			this.noCmdsMSG = PopMessage:new({parent.popupMenus});
			this.noCmdsMSG:init(this,"noCmdsMSG",x,y,nil,nil,nil,"ok");
			this.noCmdsMSG:makeBranch(this.oribtn);
		end;
	end
end;
function(this,parent,x,y) --goto object
	local wframe = this.oribtn.oribtn.wframe
	local finder = wframe.CPFinder
	local locCObjTab = wframe.CPFinder.resultSet;
	if finder.cmdset then
		local locItemIndex = finder.cmdset.ik
		local celobj = locCObjTab[locItemIndex]
		if not this.MSGupT["gotoCmdMSG"] then
			this.gotoCmdMSG = PopMessage:new({parent.popupMenus});
			this.gotoCmdMSG:init(this,"gotoCmdMSG",x,y,nil,{
			templates2.popMsg.gotoCmdMSG[1]..locItemIndex.." ("..celobj:name()..")?",
			txtfnt = templates2.popMsg.gotoCmdMSG.txtfnt;
			},nil,"yn",
			function()
				if finder.viewMode ~= "resultset" then
					tCelPadHUD.functions.viewResults(wframe)
				end
				wframe:scroll(false)
				local itemLine = locItemIndex%wframe.Maxpageitems
				wframe.lineoffset = itemLine-1
				if itemLine == 0 then
					wframe.lineoffset = wframe.Maxpageitems
				end
				wframe.pagenumber = (math.floor((locItemIndex-2/2)/wframe.Maxpageitems))+1
				wframe.popupmenu(wframe, wframe.mvbutton, x, y, locItemIndex)
			end,
			function()
			end
			);
			this.gotoCmdMSG:makeBranch(this);
		end
	else
		if not this.MSGupT["noCmdsMSG"] then
			this.noCmdsMSG = PopMessage:new({parent.popupMenus});
			this.noCmdsMSG:init(this,"noCmdsMSG",x,y,nil,nil,nil,"ok");
			this.noCmdsMSG:makeBranch(this.oribtn);
		end;
	end
end;
function(this,parent,x,y) --cancel
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if not finder.cmdset then
		if not this.MSGupT["noCmdsMSG"] then
			this.noCmdsMSG = PopMessage:new({parent.popupMenus});
			this.noCmdsMSG:init(this,"noCmdsMSG",x,y,nil,nil,nil,"ok");
			this.noCmdsMSG:makeBranch(this.oribtn);
		end;
	else
		if not this.MSGupT["CancelCmdsMSG"] then
			finder.CancelCmdsMSG = PopMessage:new({parent.popupMenus});
			finder.CancelCmdsMSG:init(this,"CancelCmdsMSG",x,y,nil,nil,nil,"yn",
			function(o)
				if finder.cmdset then
					CPlog("cancelling command set",0,finder.sysLog);
					finder.cmdset.cancelrq = true;
				else
					CPlog("nothing to cancel",0,finder.sysLog);
				end;
			end,
			function(o)
			end
			);
			finder.CancelCmdsMSG:makeBranch(this.oribtn);
		end;
	end;
end;
function(this,parent,x,y) --command options
	local finder = this.oribtn.oribtn.wframe.CPFinder
	if #finder.resultSet ~= 0 then
		finder.CMDS.cmdopts.data.co01startobj = finder.CMDS.cmdopts.data.co01startobj or 1
		finder.CMDS.cmdopts.data.co02endobj = finder.CMDS.cmdopts.data.co02endobj or #finder.resultSet
		finder.CMDS.cmdopts.meta.co02endobj[4] = #finder.resultSet
		this.setupdlg = SetupMenu:new({parent.popupMenus});
		this.setupdlg.objtype = "params"
		this.setupdlg.menutab = finder.CMDS.cmdopts.data
		this.setupdlg.metatab =  finder.CMDS.cmdopts.meta
		this.setupdlg:init(this,parent,"comOpts",x,y,"Command Set Options")
		this.setupdlg:makeBranch(this)
		this.setupdlg.setitem[1].menuline.wobj = this.setupdlg
		this.setupdlg.setitem[1].menuline.Customdraw = function(this)
			finder.CMDS.cmdopts.meta.co02endobj[4] = #finder.resultSet
			if #finder.resultSet == 0 then
				this.wobj.closebutton:Action()
			end
			if this.wobj.menutab.co02endobj and this.wobj.menutab.co01startobj then
				if this.wobj.menutab.co02endobj < this.wobj.menutab.co01startobj then
				this.wobj.menutab.co02endobj = 	this.wobj.menutab.co01startobj
				end
			end
		end
		this.setupdlg.setitem[3].menuline.wobj = this.setupdlg
		this.setupdlg.setitem[3].menuline.Customdraw = function(this)
		end
	else
		if not this.MSGupT["PopMSGOKnoresults"] then
			this.PopMSGOKnoresults = PopMessage:new({parent.popupMenus});
			this.PopMSGOKnoresults:init(this,"PopMSGOKnoresults",x,y,nil,nil,nil,"ok");
			this.PopMSGOKnoresults:makeBranch(this.oribtn);
		end;
	end
end;
};
runfnc = {0};
};
ComSetPopup = {
"Command Set Panel","Run Commands on Object","Set Object as Starting Point","Set Object as Ending Point","Jump on Object",templates.ObsComm[6],
switch = {1,1,1,1,1,1};
fnctab = {
function(this,parent,x,y) --popup Create Command Set
	local finder = this.oribtn.oribtn.oribtn.CPFinder
	tCelPadHUD.functions.cmdsDlg(this,parent,x,y,finder)
end;
function(this,parent,x,y) --popup run
	local locCObjTab = this.oribtn.oribtn.oribtn.CPFinder.resultSet;
	local finder = this.oribtn.oribtn.oribtn.CPFinder
	local execCommandSet = execCommandSet
	if finder.runningTask == 2 then
		if not this.MSGupT["oneCmdSetMSG"] then
			this.oneCmdSetMSG = PopMessage:new({parent.popupMenus});
			this.oneCmdSetMSG:init(this,"oneCmdSetMSG",x,y,nil,nil,nil,"ok");
			this.oneCmdSetMSG:makeBranch(this);
		end
	else
		if not this.MSGupT["toRunCmdObjMSG"] then
			finder.toRunCmdObjMSG = PopMessage:new({parent.popupMenus});
			finder.toRunCmdObjMSG:init(this,"toRunCmdObjMSG",x,y,nil,{
			templates2.popMsg["toRunCmdObjMSG"][1],
			templates2.popMsg["toRunCmdObjMSG"][2]..tostring(locCObjTab[this.oribtn.oribtn.Parent.item_index]:name())..templates2.popMsg["toRunCmdObjMSG"][3],
			txtfnt = templates2.popMsg["toRunCmdObjMSG"].txtfnt;
			},nil,"yn",
			function(o)
				if finder.runningTask == 2 then
					if not this.MSGupT["oneCmdSetMSG"] then
						this.oneCmdSetMSG = PopMessage:new({parent.popupMenus});
						this.oneCmdSetMSG:init(this,"oneCmdSetMSG",x,y,nil,nil,nil,"ok");
						this.oneCmdSetMSG:makeBranch(this);
					end
				else
					if finder.CMDS.mtdlg then
						finder.CMDS.mtdlg.btnselfAPL:Action()
					end
					finder.locset = finder.locset or {};
					finder.locset["object"] = locCObjTab[this.oribtn.oribtn.Parent.item_index]
					finder.locset["ik"] = this.oribtn.oribtn.Parent.item_index
					if finder.locset.cmdtimer then
						finder.locset.cmdtimer:killchain();
					end
					execCommandSet(finder.locset,finder,finder.CMDS.srctab)
				end
			end,
			function(o)
			end
			);
			finder.toRunCmdObjMSG:makeBranch(this.oribtn);
		end;
	end;
end;
function(this,parent,x,y) -- start
	local finder = this.oribtn.oribtn.oribtn.CPFinder
	local locCObjTab = this.oribtn.oribtn.oribtn.CPFinder.resultSet;
	if finder.CMDS.cmdopts.data.co02endobj and this.oribtn.oribtn.Parent.item_index > finder.CMDS.cmdopts.data.co02endobj then
		if not this.MSGupT["cmdNoStartMSG"] then
			this.cmdNoStartMSG = PopMessage:new({parent.popupMenus});
			this.cmdNoStartMSG:init(this,"cmdNoStartMSG",x,y,nil,{
			templates2.popMsg.cmdNoStartMSG[1]..this.oribtn.oribtn.Parent.item_index..templates2.popMsg.cmdNoStartMSG[2],
			templates2.popMsg.cmdNoStartMSG[3]..finder.CMDS.cmdopts.data.co02endobj..templates2.popMsg.cmdNoStartMSG[4],
			txtfnt = templates2.popMsg.cmdNoStartMSG.txtfnt;
			},nil,"ok");
			this.cmdNoStartMSG:makeBranch(this);
		end
	else
		if not this.MSGupT["cmdStartMSG"] then
			this.cmdStartMSG = PopMessage:new({parent.popupMenus});
			this.cmdStartMSG:init(this,"cmdStartMSG",x,y,nil,{
			templates2.popMsg.cmdStartMSG[1]..tostring(locCObjTab[this.oribtn.oribtn.Parent.item_index]:name())..templates2.popMsg.cmdStartMSG[2],
			templates2.popMsg.cmdStartMSG[3],
			txtfnt = templates2.popMsg.cmdStartMSG.txtfnt;
			},nil,"yn",
			function()
				local cond = finder.cmdset and finder.cmdset.ik
				local oriik
				if cond then
					oriik = finder.cmdset.ik
				end
				local cmdopts = finder.CMDS.cmdopts.data
				if cmdopts.co01startobj and this.oribtn.oribtn.Parent.item_index > cmdopts.co01startobj then
					if cond then
						finder.cmdset.ik = this.oribtn.oribtn.Parent.item_index
						if finder.cmdset.cmdtimer then
							finder.cmdset.cmdtimer:killchain()
						end
					end
				end
				if cond then
					finder.oriframe.whtable.txtcol[oriik] = cpfntcolmainw;
				end
				cmdopts.co01startobj = this.oribtn.oribtn.Parent.item_index
			end,
			function()
			end
			);
			this.cmdStartMSG:makeBranch(this);
		end
	end
end;
function(this,parent,x,y) --stop
	local finder = this.oribtn.oribtn.oribtn.CPFinder
	local locCObjTab = this.oribtn.oribtn.oribtn.CPFinder.resultSet;
	if finder.CMDS.cmdopts.data.co01startobj and this.oribtn.oribtn.Parent.item_index < finder.CMDS.cmdopts.data.co01startobj then
		if not this.MSGupT["cmdNoEndMSG"] then
			this.cmdNoEndMSG = PopMessage:new({parent.popupMenus});
			this.cmdNoEndMSG:init(this,"cmdNoEndMSG",x,y,nil,{
			templates2.popMsg.cmdNoEndMSG[1]..this.oribtn.oribtn.Parent.item_index..templates2.popMsg.cmdNoEndMSG[2],
			templates2.popMsg.cmdNoEndMSG[3]..finder.CMDS.cmdopts.data.co01startobj..templates2.popMsg.cmdNoEndMSG[4],
			txtfnt = templates2.popMsg.cmdNoEndMSG.txtfnt;
			},nil,"ok");
			this.cmdNoEndMSG:makeBranch(this);
		end
	else
		if not this.MSGupT["cmdEndMSG"] then
			this.cmdEndMSG = PopMessage:new({parent.popupMenus});
			this.cmdEndMSG:init(this,"cmdEndMSG",x,y,nil,{
			templates2.popMsg.cmdEndMSG[1]..tostring(locCObjTab[this.oribtn.oribtn.Parent.item_index]:name())..templates2.popMsg.cmdStartMSG[2],
			templates2.popMsg.cmdEndMSG[3],
			txtfnt = templates2.popMsg.cmdEndMSG.txtfnt;
			},nil,"yn",
			function()
				local cond = finder.cmdset and finder.cmdset.ik
				local oriik
				if cond then
					oriik = finder.cmdset.ik
				end
				local cmdopts = finder.CMDS.cmdopts.data
				if cmdopts.co02endobj and this.oribtn.oribtn.Parent.item_index < cmdopts.co02endobj then
					if cond then
						if finder.cmdset.cmdtimer then
							finder.cmdset.cmdtimer:killchain()
						end
					end
				end
				if cond then
					finder.oriframe.whtable.txtcol[oriik] = cpfntcolmainw;
				end
				cmdopts.co02endobj = this.oribtn.oribtn.Parent.item_index
			end,
			function()
			end
			);
			this.cmdEndMSG:makeBranch(this);
		end
	end
end;
function(this,parent,x,y) --cursor
	local finder = this.oribtn.oribtn.oribtn.CPFinder
	local locCObjTab = this.oribtn.oribtn.oribtn.CPFinder.resultSet;
	local msg1 = function()
		if not this.MSGupT["cmdGoto1MSG"] then
			this.cmdGoto1MSG = PopMessage:new({parent.popupMenus});
			this.cmdGoto1MSG:init(this,"cmdGoto1MSG",x,y,nil,nil,nil,"ok");
			this.cmdGoto1MSG:makeBranch(this.oribtn);
		end;
	end;
	local resetitem = function()
		if not finder.cmdset then
			if not this.MSGupT["noCmdsMSG"] then
				this.noCmdsMSG = PopMessage:new({parent.popupMenus});
				this.noCmdsMSG:init(this,"noCmdsMSG",x,y,nil,nil,nil,"ok");
				this.noCmdsMSG:makeBranch(this.oribtn);
			end;
		else
			local oriik = finder.cmdset.ik
			if this.oribtn.oribtn.Parent.item_index > 1 then
				if finder.cmdset.cmdtimer then
					finder.cmdset.cmdtimer:killchain();
				end
				finder.cmdset.ik = this.oribtn.oribtn.Parent.item_index	- 1
			else
				msg1()
			end
			if finder.viewMode == "resultset" then
				finder.oriframe.whtable.txtcol[oriik] = cpfntcolmainw;
			end
		end
	end
	if not finder.cmdset then
		if not this.MSGupT["noCmdsMSG"] then
			this.noCmdsMSG = PopMessage:new({parent.popupMenus});
			this.noCmdsMSG:init(this,"noCmdsMSG",x,y,nil,nil,nil,"ok");
			this.noCmdsMSG:makeBranch(this.oribtn);
		end;
	else
		if this.oribtn.oribtn.Parent.item_index == 1 then
			msg1()
		else
			if this.oribtn.oribtn.Parent.item_index < finder.CMDS.cmdopts.data.co01startobj then
				if not this.MSGupT["cmdCursStartMSG"] then
					this.cmdCursStartMSG = PopMessage:new({parent.popupMenus});
					this.cmdCursStartMSG:init(this,"cmdCursStartMSG",x,y,nil,{
					templates2.popMsg.cmdCursStartMSG[1]..this.oribtn.oribtn.Parent.item_index..templates2.popMsg.cmdCursStartMSG[2],
					templates2.popMsg.cmdCursStartMSG[3]..finder.CMDS.cmdopts.data.co01startobj..templates2.popMsg.cmdCursStartMSG[4],
					txtfnt = templates2.popMsg.cmdCursStartMSG.txtfnt;
					},nil,"yn",
					function()
						finder.CMDS.cmdopts.data.co01startobj = this.oribtn.oribtn.Parent.item_index
						resetitem()
					end,
					function()
					end
					);
					this.cmdCursStartMSG:makeBranch(this);
				end
			elseif this.oribtn.oribtn.Parent.item_index > finder.CMDS.cmdopts.data.co02endobj then
				if not this.MSGupT["cmdCursEndMSG"] then
					this.cmdCursEndMSG = PopMessage:new({parent.popupMenus});
					this.cmdCursEndMSG:init(this,"cmdCursEndMSG",x,y,nil,{
					templates2.popMsg.cmdCursEndMSG[1]..this.oribtn.oribtn.Parent.item_index..templates2.popMsg.cmdCursEndMSG[2],
					templates2.popMsg.cmdCursEndMSG[3]..finder.CMDS.cmdopts.data.co02endobj..templates2.popMsg.cmdCursEndMSG[4],
					txtfnt = templates2.popMsg.cmdCursEndMSG.txtfnt;
					},nil,"yn",
					function()
						finder.CMDS.cmdopts.data.co02endobj = this.oribtn.oribtn.Parent.item_index
						resetitem()
					end,
					function()
					end
					);
					this.cmdCursEndMSG:makeBranch(this);
				end
			else
				if not this.MSGupT["cmdCursMSG"] then
					this.cmdCursMSG = PopMessage:new({parent.popupMenus});
					this.cmdCursMSG:init(this,"cmdCursMSG",x,y,nil,{
					templates2.popMsg.cmdCursMSG[1]..locCObjTab[this.oribtn.oribtn.Parent.item_index]:name().."' ?",
					txtfnt = templates2.popMsg.cmdCursMSG.txtfnt;
					},nil,"yn",
					function()
						resetitem()
					end,
					function()
					end
					);
					this.cmdCursMSG:makeBranch(this);
				end
			end
		end
	end
end;
function(this,parent,x,y) --CLI
	local finder, locCObjTab
	if this.oribtn.objname == "moveButton" then
		finder = this.oribtn.wframe.CPFinder
	else
		finder = this.oribtn.oribtn.oribtn.CPFinder
		locCObjTab = this.oribtn.oribtn.oribtn.CPFinder.resultSet;
	end
	local maxhist = finder.CMDS.cmdopts.data.co04maxCmdHist
	local obs = observer
	finder.climenu = finder.climenu or
	{
	cmdhist = {"",valuelist={""};};
	zcmdline = "";
	};
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "setupdlg"
	this.setupdlg.menutab = finder.climenu
	this.setupdlg.metatab = {
	cmdhist = {"History:"};
	zcmdline = {"Command:"};
	};
	local dhist = (#finder.climenu.cmdhist.valuelist-1) - maxhist
	if dhist <= 0 then dhist = 0 end
	for r=1,dhist do
		table.remove(finder.climenu.cmdhist.valuelist,2)
	end
	this.setupdlg:init(this,parent,"freecli",x,y,"Command Line","dlgao");
	this.setupdlg:makeBranch(this);
	this.setupdlg.btnselfAPL.menutab = this.setupdlg.menutab;
	this.setupdlg.btnselfAPL.menu = finder.climenu
	this.setupdlg.btnselfOK.menutab = this.setupdlg.menutab;
	this.setupdlg.btnselfOK.menu = finder.climenu
	local cmdAction = function(this)
		local command = this.menutab["zcmdline"]
		if command ~= "" then
			local errmsg, locItemIndex, object
			if locCObjTab then
				locItemIndex = this.wobj.btnbox.oribtn.oribtn.Parent.item_index;
				object = locCObjTab[locItemIndex]
			end
			local exstat2,cmdexec2 = templates.celcmds.freecmd(obs,object,{command},finder,{["object"] = object, popup = true, ik = locItemIndex})
			if exstat2 then
				this.menu.cmdhist[1] = command
				local isthere
				for k,l in ipairs(this.menu.cmdhist.valuelist) do
					if l == command then isthere = true end
				end
				if not isthere then
					table.insert(this.menu.cmdhist.valuelist,command)
				end
				if #this.menu.cmdhist.valuelist > maxhist+1 then
					table.remove(this.menu.cmdhist.valuelist,2)
				end
			end
		end
	end
	this.setupdlg.btnselfAPL.Customdraw = function(this)
		if this.wobj.setitem[1].editbox.selected then
			this.menu.zcmdline = this.wobj.setitem[1].editbox.selected
			this.wobj.setitem[1].editbox.selected = nil
		end
	end;
	this.setupdlg.btnselfAPL.Action = (function()
		return
		function(this)
			cmdAction(this)
		end
	end) ();
	this.setupdlg.btnselfOK.Action = (function()
		return
		function(this)
			cmdAction(this)
			this.wobj:quitpopup(this.wobj.btnbox);
		end
	end) ();
end;
};
runfnc = {0};
};
ComItem = {
"Duplicate","Delete","Change",
switch = {1,1,1};
fnctab = {
function(this,parent,x,y) -- Duplicate
	local deepcopy = deepcopy
	local item = this.oribtn.wobj.menupane.itembox[this.oribtn.indx]
	if not this.MSGupT["CopyItemMSG"] then
		this.CopyItemMSG = PopMessage:new({parent.popupMenus});
		this.CopyItemMSG:init(this,"CopyItemMSG",x,y,nil,{
		templates2.popMsg.CopyItemMSG[1]..getsetuphi(item.indx,item.metatab)..templates2.popMsg.CopyItemMSG[2],
		txtfnt = templates2.popMsg.CopyItemMSG.txtfnt;
		},nil,"yn",
		function(o)
			table.insert(item.menutab[1][1],item.indx+1,deepcopy(item.menutab[1][1][item.indx]));
			table.insert(item.menutab[1].choicelist,item.indx+1,deepcopy(item.menutab[1].choicelist[item.indx]));
			table.insert(item.menutab.argTbl,item.indx+1,deepcopy(item.menutab.argTbl[item.indx]));
			table.insert(item.metatab,item.indx+1,deepcopy(item.metatab[item.indx]));
			table.insert(item.metatab.argTbl,item.indx+1,deepcopy(item.metatab.argTbl[item.indx]));
			item.wobj.btnbox.mvitem = true
			item.wobj.btnbox.menutab = item.wobj.menutab
			item.wobj.btnbox.metatab = item.wobj.metatab
			refreshCommCons(item.wobj.finder)
		end,
		function(o)
		end
		);
		this.CopyItemMSG.Ybranchkill = true;
		this.CopyItemMSG:makeBranch(this);
	end;
end;
function(this,parent,x,y) --Delete
	local item = this.oribtn.wobj.menupane.itembox[this.oribtn.indx]
	if not this.MSGupT["RmvItemMSG"] and #item.menutab.argTbl > 1 then
		this.RmvItemMSG = PopMessage:new({parent.popupMenus});
		this.RmvItemMSG:init(this,"RmvItemMSG",x,y,nil,{
		templates2.popMsg.RmvItemMSG[1]..getsetuphi(item.indx,item.metatab)..templates2.popMsg.RmvItemMSG[2],
		txtfnt = templates2.popMsg.RmvItemMSG.txtfnt;
		},nil,"yn",
		function(o)
			table.remove(item.menutab[1][1],item.indx);
			table.remove(item.menutab[1].choicelist,item.indx);
			table.remove(item.menutab.argTbl,item.indx);
			table.remove(item.metatab,item.indx);
			table.remove(item.metatab.argTbl,item.indx);
			item.wobj.btnbox.mvitem = true
			item.wobj.btnbox.menutab = item.wobj.menutab
			item.wobj.btnbox.metatab = item.wobj.metatab
			refreshCommCons(item.wobj.finder)
		end,
		function(o)
		end
		);
		this.RmvItemMSG.Ybranchkill = true;
		this.RmvItemMSG:makeBranch(this);
	end;
end;
function(this,parent,x,y) --change
	local item = this.oribtn.wobj.menupane.itembox[this.oribtn.indx]
	this.setupdlg = SetupMenu:new({parent.popupMenus});
	this.setupdlg.objtype = "setupdlg"
	this.setupdlg.menutab = {cmditem={valuelist={}}};
	this.setupdlg.metatab = {cmditem={"New Item",valuelist={}}};
	this.setupdlg.menutab.cmditem[1] = item.menutab[1].choicelist[item.indx]
	for t,h in orderedPairs(templates.cpcmds) do
		table.insert(this.setupdlg.menutab.cmditem.valuelist,tostring(t))
	end
	this.setupdlg:init(this,parent,"change",x,y,"Change Item","dlgok");
	this.setupdlg:makeBranch(this);
	this.setupdlg.btnself.Action = (function()
		return
		function()
			item.menutab[1].choicelist[item.indx] = this.setupdlg.menutab.cmditem[1]
			item.metatab[item.indx] = {this.setupdlg.menutab.cmditem[1]}
			item.menutab.argTbl[item.indx] = {};
			item.metatab.argTbl[item.indx] = {};
			for p in string.gmatch(templates.cpcmds[this.setupdlg.menutab.cmditem[1]].args, "%w+") do
				item.menutab.argTbl[item.indx][p] = deepcopy(templates.inputParam[p].data)
				item.metatab.argTbl[item.indx][p] = deepcopy(templates.inputParam[p].meta)
			item.metatab.argTbl[item.indx][p][1] = argAbrv(p)
			end;
			item.wobj.btnbox.mvitem = true
			item.wobj.btnbox.menutab = item.wobj.menutab
			item.wobj.btnbox.metatab = item.wobj.metatab
			refreshCommCons(item.wobj.finder)
		end
	end) ();
end;
};
runfnc = {0};
};
};
};
syslogInit(tCelPadHUD.sysLog)
CelPadHUD = CClass {
classname = "CelPadHUD";
superclass = CPObject;
oldScrX = 0;
oldScrY = 0;
init = function(this)
	this.objname = "myCelPadHUD";
	syslogWindow = {};
	CPlog("mounted syslog window object as "..tostring(syslogWindow),0,tCelPadHUD.sysLog);
end;
updateScrRsz = function(this)
	if (ScrX ~= this.oldScrX or ScrY ~= this.oldScrY) and ( ScrX*ScrY ~= 0 ) then
	local llbx,lbbx,lrbx,ltbx
		for i,v in ipairs(tCelPadHUD.winObjects) do
			v.moveButton.la = v.moveButton.la + ( ScrX - this.oldScrX )*0.5;
			v.moveButton.ba = v.moveButton.ba + ( ScrY - this.oldScrY )*0.5;
			v.moveButton.ra = v.moveButton.ra + ( ScrX - this.oldScrX )*0.5;
			v.moveButton.ta = v.moveButton.ta + ( ScrY - this.oldScrY )*0.5;
			v.moveButton.statlbrt["statla"] = v.moveButton.la;
			v.moveButton.statlbrt["statba"] = v.moveButton.ba;
			v.moveButton.statlbrt["statra"] = v.moveButton.ra;
			v.moveButton.statlbrt["statta"] = v.moveButton.ta;
			v:processFrameMenu(v.moveButton.wframe,
			function(o)
				if o.menupane.Sticky then
					o.menupane.la = o.menupane.la + ( ScrX - this.oldScrX )*0.5;
					if o.msgtype == "inf" then
						o.menupane.ba = o.menupane.ba + ( ScrY - this.oldScrY )*1.5;
					else
						o.menupane.ba = o.menupane.ba + ( ScrY - this.oldScrY )*0.5;
					end;
					o.menupane.ra = o.menupane.ra + ( ScrX - this.oldScrX )*0.5;
					o.menupane.ta = o.menupane.ta + ( ScrY - this.oldScrY )*0.5;
					llbx,lbbx,lrbx,ltbx = o.menupane.btboxpointer:bounds()
					o.menupane.lbtn = llbx
					o.menupane.tbtn = ltbx
				else
					if o.msgtype == "inf" then
						o.menupane.ba = o.menupane.ba + ( ScrY - this.oldScrY )*2;
					end;
				end;
			end
			);
		end;
		for t,y in ipairs(tCelPadHUD.popMsgs) do
			y.menupane.la = y.menupane.la + ( ScrX - this.oldScrX )*0.5;
			y.menupane.ba = y.menupane.ba + ( ScrY - this.oldScrY )*0.5;
			y.menupane.ra = y.menupane.ra + ( ScrX - this.oldScrX )*0.5;
			y.menupane.ta = y.menupane.ta + ( ScrY - this.oldScrY )*0.5;
			llbx,lbbx,lrbx,ltbx = y.menupane.btboxpointer:bounds()
			y.menupane.lbtn = llbx
			y.menupane.tbtn = ltbx
		end;
		this.oldScrX = ScrX
		this.oldScrY = ScrY
	end;
end;
saveallpos = function(this)
	if #tCelPadFinder.runningFinders > 0 then
		tCelPadFinder.runningFinders[#tCelPadFinder.runningFinders].wobj:savelastpos("close")
	end;
	if #tCelPadFinder.runningLogs > 0 then
		tCelPadFinder.runningLogs[#tCelPadFinder.runningLogs].wobj:savelastpos("close")
	end;
	if ControlPanel then
		ControlPanel:savelastpos();
	end;
	myCelPad:saveCP("profile","ini");
end;
borderchk = function(this,lx,ly,lw,lh)
	if (ly+lh) > (ScrY-(gButtonsize+2*gButtonspace)) then
		ly = (ScrY-(gButtonsize+2*gButtonspace))-lh
	end;
	if lx > (ScrX-lw) then
		lx = (ScrX-lw)
	end;
	return lx,ly,lw,lh
end;
}
CPWindow = CClass {
classname = "CPWindow";
superclass = CPObject;
objtype = "winObject";
init = function (this, objname, swx, swy, sww, swh)
	this.objname = objname;
	this.wx, this.wy, this.ww, this.wh = swx, swy, sww, swh;
	if this.wy < 20 then this.wy = ScrY - (this.wh+20); end;
	if (this.wx + this.ww) > (ScrX - 20) then this.wx = 20; end;
	this.tButtons = {};
	this.mvrType = wMovWin
	this.Minimized = false;
	this.tCelPadHUD = tCelPadHUD;
	this:winMoveButton()
	this:winMainFrame()
	this.mainFrame.mvbutton = this.moveButton
	this.moveButton.wframe = this.mainFrame;
	this:winRszButton();
	this:winCloseButton(0);
	this:winMinButton(1)
	if showMenuHidBtn then
		this.btnindex = 3
		this:winHidMButton(2)
	else
		this.btnindex = 2;
	end;
	this:savelastpos("init")
end;
winMoveButton = function(this)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local winRecomp = winRecomp
	this.moveButton = CPBox:new()
	:init("moveButton", 0, 0, 0, 0)
	:bordercolor(cpbormvbtn)
	:fillcolor(cpfillmvbtn)
	:movable(true)
	:clickable(false)
	:visible(true)
	:active(true)
	:attach(screenBox, this.wx,(this.wy+this.wh), ScrX-(this.wx+lcButtonsize+this.ww), ScrY-(this.wh+this.wy+lcButtonsize+lcButtonspace))
	this.moveButton:makeBranch(this);
	this.moveButton.ww = ScrX - this.moveButton.la - this.moveButton.ra
	this.moveButton.wh = ScrY - this.moveButton.ba - this.moveButton.ta
	this.moveButton.wobj = this;
	this.moveButton.menuindc = CPBox:new()
	:init("moveButton.menuindc", 0, 0, 0, 0)
	:bordercolor(cpfillmvbtn)
	:fillcolor(cpcolrzbtn)
	:movable(false)
	:clickable(true)
	:visible(false)
	:active(false)
	:attach(this.moveButton,-lcButtonsize+lcButtonspace,lcButtonspace, lcButtonspace, lcButtonspace)
	this.moveButton.menuindc:makeBranch(this);
	this.moveButton.menuindc.wobj = this;
	this.moveButton.menuindc.Customdraw = function(this)
		if #this.wobj.mainFrame.popupMenus == 0 then
			this.wobj.mainFrame.HidMenu = false;
			this:visible(false)
		end;
	end;
	this.moveButton.pressedfnc = function(o)
		o.menupane:orderfront()
	end;
	this.moveButton.statlbrt = {
	statla = this.moveButton.la;
	statba = this.moveButton.ba;
	statra = this.moveButton.ra;
	statta = this.moveButton.ta;
	};
	this.moveButton.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.wframe.popupMenus});
		this.popup:init(this,parent,"mvbtnpup",x,y,"undefined","no");
		this.popup:makeBranch(this);
	end;
	this.moveButton.Customdraw = function(this)
		this.ra = this.wobj.mainFrame.ra + (#(this.wobj.tButtons)-1)*(lcButtonsize+lcButtonspace)
		this.statlbrt["statra"] = this.ra;
		if this.Pressed then
			if this.wobj.objtype == "cpWindow" then
				IconsRepos = true;
			end
			winRecomp(this.wobj.RszButton)
			this.statlbrt["statla"] = this.la;
			this.statlbrt["statba"] = this.ba;
			this.statlbrt["statra"] = this.ra;
			this.statlbrt["statta"] = this.ta;
			this.wobj:processFrameMenu(this.wobj.mainFrame, this.pressedfnc)
			if this.rstpos then
				this.Pressed = false
				this.rstpos = nil;
			end
		else
			this.la = this.statlbrt["statla"];
			this.ba = this.statlbrt["statba"];
			this.ra = this.statlbrt["statra"];
			this.ta = this.statlbrt["statta"];
		end
	end
	return this.moveButton
end;
processFrameMenu = function(this, recp, fnctodo)
	for i,v in ipairs(recp.popupMenus) do
		fnctodo(v);
		v:processMenu(v,fnctodo)
	end
end;
winButton = function(this, bindex, btxt)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.wButton = CPBox:new({this.tButtons})
	:init("vsbtn", 0, 0, 0, 0)
	:bordercolor(cpborrzbtn)
	:fillcolor(cpfillrzbtn)
	:textfont(cpfntmenu)
	:textcolor(cpcolrzbtn)
	:textpos("center")
	:movetext(1, 7)
	:text(btxt)
	:movable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()-lcButtonsize*bindex - ((bindex-1)*lcButtonspace), this.mainFrame:wh()+lcButtonspace, (bindex-1)*lcButtonspace+(bindex-1)*lcButtonsize, -(lcButtonspace + lcButtonsize))
	this.wButton:makeBranch(this);
	this.wButton.bindex = bindex
	return this.wButton
end;
winHidMButton = function(this, bindex)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.whidmbtn = CPBox:new({this.tButtons})
	:init("whidmbtn", 0, 0, 0, 0)
	:bordercolor(cpborrzbtn)
	:fillcolor(cpfillrzbtn)
	:textfont(cpfntmenu)
	:textcolor(cpcolrzbtn)
	:textpos("center")
	:movetext(0, 7)
	:text("#")
	:movable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()-lcButtonsize*bindex - ((bindex-1)*lcButtonspace), this.mainFrame:wh()+lcButtonspace, (bindex-1)*lcButtonspace+(bindex-1)*lcButtonsize, -(lcButtonspace + lcButtonsize))
	this.whidmbtn:makeBranch(this);
	this.whidmbtn.bindex = bindex;
	this.whidmbtn.pfnc1 = function(o)
		if not o.menupane.Sticky then
			o.menupane:visible(false);
		end;
	end;
	this.whidmbtn.pfnc2 = function(o)
		o.menupane:visible(true);
		o.menupane:orderfront();
	end;
	this.whidmbtn.Action = (function()
		return
		function()
			if #this.mainFrame.popupMenus ~= 0 then
				this.mainFrame.HidMenu = not this.mainFrame.HidMenu;
				this.moveButton.menuindc:visible(this.mainFrame.HidMenu)
			end;
		end
	end) (this);
	this.whidmbtn.Customdraw = function()
		if this.whidmbtn.Pressed then
			this:processFrameMenu(this.mainFrame,
			function(o)
				o.menupane:orderfront();
			end)
			if this.mainFrame then
				if this.mainFrame.HidMenu then
					this:processFrameMenu(this.mainFrame,this.whidmbtn.pfnc1)
				else
					this:processFrameMenu(this.mainFrame,this.whidmbtn.pfnc2)
				end
			end
		end;
		if this.mainFrame then
			if this.mainFrame.HidMenu then
				this.whidmbtn:text("M")
			else
				this.whidmbtn:text("m")
			end
		end
	end
	return this.whidmbtn
end;
winRszButton = function(this)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local winRecomp = winRecomp
	this.RszButton = CPBox:new()
	:init("RszButton", 0, 0, 0, 0)
	:bordercolor(cpborrzbtn)
	:fillcolor(cpfillrzbtn)
	:textfont(cpfntmenu)
	:textcolor(cpcolrzbtn)
	:textpos("center")
	:movetext(2, 7)
	:text("+")
	:movable(false)
	:rszbutton(true)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()+lcButtonspace, -(lcButtonspace + lcButtonsize), -(lcButtonspace + lcButtonsize), this.mainFrame:wh()+lcButtonspace)
	this.RszButton:makeBranch(this);
	this.RszButton.wobj = this;
	this.RszButton.Customdraw = function(this)
		if this.doresize then
			winRecomp(this)
		end
		if this.Pressed then
			if this.wobj.objtype == "cpWindow" then
				IconsRepos = true;
			end
			for i,v in ipairs(this.wobj.mainFrame.popupMenus) do
				v.menupane:orderfront();
			end;
			if (this.Parent.Parent.ta-this.Parent.ba)+2*(lcButtonsize+2*lcButtonspace) > ScrY then
				this.onborder = true
				this.Parent.ba = 2*(lcButtonsize+2*lcButtonspace) + this.Parent.Parent.ta - ScrY
			end;
			if (this.Parent.Parent.la-this.Parent.ra)+(lcButtonsize+2*lcButtonspace) > ScrX then
				this.onborder = true
				this.Parent.ra = (lcButtonsize+2*lcButtonspace) + this.Parent.Parent.la - ScrX
			end;
		else
			if this.wobj.objtype == "uniWinObject" then
				local red = 4
				local winh = this.wobj.mainFrame:wh()
				local whred = winh - red
				local fh = cpfntmainw:getheight()
				local modfnt = whred%fh
				if modfnt ~= 0 then
					if fh-modfnt > fh/2 then
						this.wobj.mainFrame.ba = this.wobj.mainFrame.ba+modfnt
					else
						this.wobj.mainFrame.ba = this.wobj.mainFrame.ba-(fh-modfnt)
					end
					winRecomp(this)
				end
			end
		end;
	end;
	return this.RszButton
end;
winMinButton = function(this, bindex)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.wminbtn = CPBox:new({this.tButtons})
	:init("wminbtn", 0, 0, 0, 0)
	:bordercolor(cpborrzbtn)
	:fillcolor(cpfillrzbtn)
	:textfont(cpfntmenu)
	:textcolor(cpcolrzbtn)
	:textpos("center")
	:movetext(1, 10)
	:text("_")
	:movable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()-lcButtonsize, this.mainFrame:wh()+lcButtonspace, 0, -(lcButtonspace + lcButtonsize))
	this.wminbtn:makeBranch(this);
	this.wminbtn.bindex = bindex;
	this.wminbtn.pressedfnc = function(o)
		if o.menupane.Sticky == false then
			o.menupane:visible(false);
		end;
	end;
	this.wminbtn.Action = (function()
		return
		function()
			if not this.Minimized then
				this.Minimized = true;
				this.moveButton:visible(false);
				this:processFrameMenu(this.mainFrame, this.wminbtn.pressedfnc)
			end;
		end
	end) (this);
	return this.wminbtn
end;
winCloseButton = function(this, bindex)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.closeButton = CPBox:new({this.tButtons})
	:init("closeButton", 0, 0, 0, 0)
	:bordercolor(cpborrzbtn)
	:fillcolor(cpfillrzbtn)
	:textfont(cpfntmenu)
	:textcolor(cpcolrzbtn)
	:textpos("center")
	:movetext(0, 8)
	:text("x")
	:movable(false)
	:active(true)
	:menuitem(true)
	:attach(this.mainFrame, this.mainFrame:ww()+lcButtonspace, this.mainFrame:wh()+lcButtonspace, -(lcButtonspace + lcButtonsize), -(lcButtonspace + lcButtonsize))
	this.closeButton:makeBranch(this);
	this.closeButton.wobj = this
	this.closeButton.Action = (function()
		return
		function(this)
			IconsRepos = true;
			if not this.nosave then
				this.wobj:savelastpos("close")
			end;
			if this.wobj.mainFrame.CPFinder then this.wobj.mainFrame.CPFinder.closing = true;
				CPlog("closing window, please wait...",0,this.wobj.mainFrame.CPFinder.sysLog)
			else
				this.wobj = this.wobj:wkill();
			end;
		end
	end) ();
	return this.closeButton
end;
wkill = function(this)
	this:destruct();
	return ( nil );
end;
winMainFrame = function(this)
	local textlayout = textlayout
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local pressSwitch = pressSwitch
	local winact = true
	if this.mvrType == "holey" then
		winact = false
	end
	this.mainFrame = CPBox:new()
	:init("CPWindow.mainFrame", 0, 0, 0, 0)
	this.mainFrame.la = 0;
	this.mainFrame.ba = -this.wh;
	this.mainFrame.ra = -this.ww;
	this.mainFrame.ta = lcButtonsize + 2*lcButtonspace;
	this.mainFrame.popupMenus = {};
	this.mainFrame.pickedItems = {};
	this.mainFrame.mvrType = this.mvrType
	this.mainFrame.mover = true
	this.mainFrame:header("");
	this.mainFrame:bordercolor(cpborframe)
	this.mainFrame:fillcolor(cpfillframe)
	this.mainFrame:movable(false)
	this.mainFrame:clickable(false)
	this.mainFrame:visible(true)
	this.mainFrame:attach(this.moveButton, 0, -this.wh, -this.ww , lcButtonsize + 2*lcButtonspace)
	this.mainFrame:makeBranch(this);
	this.mainFrame.Customdraw = function(this)
		textlayout:setfont(cpfntheader);
		textlayout:setpos(this.lb+5, this.tb-cpfntheader:getheight()+18);
		textlayout:setlinespacing(cpfntheader:getheight());
		textlayout:setfontcolor(cpcolheader);
		textlayout:println(tostring(this.Header));
		pressSwitch(this)
	end;
	return this.mainFrame;
end;
savelastpos = function(this,src)
	if this.mainFrame.CPFinder then
		if this.mainFrame.CPFinder.findertype == 1 then
			if src == "finder" or src == "init" then
				lastwindow.lastwx1 = this.moveButton:wx()+(gButtonsize+gButtonspace);
				lastwindow.lastwy1 = (this.moveButton:wy() - this.mainFrame:wh())-(gButtonsize+gButtonspace);
			else
				lastwindow.lastwx1 = this.moveButton:wx();
				lastwindow.lastwy1 = this.moveButton:wy() - this.mainFrame:wh();
			end;
			lastwindow.lastww1 = this.mainFrame:ww();
			lastwindow.lastwh1 = this.mainFrame:wh();
		elseif this.mainFrame.CPFinder.findertype == 2 then
			if src == "finder" or src == "init" then
				lastwindow.lastwx2 = this.moveButton:wx()+(gButtonsize+gButtonspace);
				lastwindow.lastwy2 = (this.moveButton:wy() - this.mainFrame:wh())-(gButtonsize+gButtonspace);
			else
				lastwindow.lastwx2 = this.moveButton:wx();
				lastwindow.lastwy2 = this.moveButton:wy() - this.mainFrame:wh();
			end;
			lastwindow.lastww2 = this.mainFrame:ww();
			lastwindow.lastwh2 = this.mainFrame:wh();
		end;
	else
		if src == "init" then
			lastwindow.lastwx = this.moveButton:wx()+(gButtonsize+gButtonspace);
			lastwindow.lastwy = (this.moveButton:wy() - this.mainFrame:wh())-(gButtonsize+gButtonspace);
		else
			lastwindow.lastwx = this.moveButton:wx();
			lastwindow.lastwy = this.moveButton:wy() - this.mainFrame:wh();
		end;
		lastwindow.lastww = this.mainFrame:ww();
		lastwindow.lastwh = this.mainFrame:wh();
	end;
end
}
CPControlPanel = CClass {
classname = "CPControlPanel";
superclass = CPWindow;
objtype = "cpWindow";
init = function (this, objname, swx, swy, sww, swh)
	this.objname = objname;
	this.wx, this.wy, this.ww, this.wh = swx, swy, sww, swh;
	this.tButtons = {};
	this.Minimized = false;
	this.tCelPadHUD = tCelPadHUD;
	this.mvrType = wMovWin
	myCelPadHUD.Cascade = defzCascade;
	this:winMoveButton(this)
	this.moveButton.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.wframe.popupMenus});
		this.popup:init(this,parent,"ObsComm",x,y,"Observer Commands","no");
		this.popup:makeBranch(this);
	end;
	this:winMainFrame()
	this.mainFrame.mvbutton = this.moveButton
	this.moveButton.wframe = this.mainFrame;
	this:winRszButton();
	this:winCloseButton(0);
	this.closeButton.Action = (function()
		return
		function(this)
			CelPadCheck:Action()
		end
	end) ();
	this:winMinButton(1)
	if showMenuHidBtn then
		this.btnindex = 3
		this:winHidMButton(2)
	else
		this.btnindex = 2;
	end;
	this.hideallbtn = this:winButton(this.btnindex,"V");
	this.hideallbtn:menuitem(true);
	this.hideallbtn.popupmenu = function(this)
		if this.Text == "V" then
			for i,v in ipairs(tCelPadHUD.Icons) do
				if not v.window.Minimized then
					v:popupmenu()
				end
			end;
			this:text("v")
		elseif this.Text == "v" then
			for i,v in ipairs(tCelPadHUD.Icons) do
				if v.window.Minimized then
					v:popupmenu()
				end
			end;
			this:text("V")
		end;
	end;
	this.hideallbtn.Customdraw = function(this)
		local maxim, minim = 0,0
		local icnum = #tCelPadHUD.Icons
		for i,v in ipairs(tCelPadHUD.Icons) do
			if v.window.Minimized then
				minim = minim + 1
			else
				maxim = maxim + 1
			end
			if minim == icnum then
				this:text("v")
			elseif maxim == icnum then
				this:text("V")
			end;
		end;
	end
	this.btnindex = this.btnindex + 1;
	this.cascadebtn = this:winButton(this.btnindex,"c");
	this.cascadebtn:menuitem(true);
	this.cascadebtn.popupmenu = function(this)
		myCelPadHUD.Cascade = not myCelPadHUD.Cascade;
	end;
	this.cascadebtn.Customdraw = function()
		if this.mainFrame then
			if myCelPadHUD.Cascade then
				this.cascadebtn:text("C")
			else
				this.cascadebtn:text("c")
			end
		end
	end
	this.btnindex = this.btnindex + 1;
	this.helpbtn = this:winButton(this.btnindex,"?");
	this.helpbtn:menuitem(true);
	this.helpbtn.wframe = this.mainFrame
	this.helpbtn.popupmenu = function(this,parent,x,y)
		this.popup = PopupMenu:new({this.wframe.popupMenus});
		this.popup:init(this,parent,"CPHelp",x,y,"CelPad Help","no");
		this.popup:makeBranch(this);
	end;
	this.helpbtn.Action = (function()
		return
		function(this)
			if this.popup then
				this.popup.menupane:visible(true)
			end;
		end
	end) ();
	local deepcopy = deepcopy
	local s_find = string.find
	local s_num = tonumber
	local s_to = tostring
	local consttab = templates.unitsConst;
	local tmpFinder = CPSelectionLog:new({tCelPadFinder.runningFinders,myCelPad.closeTab});
	tmpFinder:init("tmpFinder","tmpFinder");
	tmpFinder:makeBranch(this)
	tmpFinder.unittable.s1_obsspeed = {
	"", valuelist = {
	function(v,fromto) -- uly/s native
		if not v then return "no data"; end;
		return(tmpFinder.retv(v))
	end;
	function(v,fromto) -- ly/s
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.lys;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.lys;
		end;
		return(tmpFinder.retv(v))
	end;
	function(v,fromto) -- c
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.c;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.c;
		end;
		return(tmpFinder.retv(v))
	end;
	function(v,fromto) -- mi/s
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.mis;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.mis;
		end;
		return(tmpFinder.retv(v))
	end;
	function(v,fromto) -- km/s
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.kms;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.kms;
		end;
		return(tmpFinder.retv(v))
	end;
	function(v,fromto) ---m/s
		if not v then return "no data"; end;
		if fromto == "fromnative" then
			v = v*consttab.obsspeed.ms;
		elseif fromto == "tonative" then
			v = v/consttab.obsspeed.ms;
		end;
		return(tmpFinder.retv(v))
	end;
	};
	};
	tmpFinder.unitmeta.s1_obsspeed = {
	"uly/s",
	valuelist = {
	"uly/s","ly/s","c","mi/s","km/s","m/s"
	};
	};
	tmpFinder.unitmeta.s1_obsspeed.metaindx = tabindx("m/s",tmpFinder.unitmeta.s1_obsspeed.valuelist)
	tmpFinder.unitmeta.s1_obsspeed[1] = deepcopy(templates.metaQuery.zcmdspeed[1])
	tmpFinder.unittable.s1_obsspeed[1]=tmpFinder.unittable.s1_obsspeed.valuelist[tmpFinder.unitmeta.s1_obsspeed.metaindx];
	this.mainFrame.CPFinder = {objname = "dummyFinder"};
	this.mainFrame.CPFinder.decplac = tmpFinder.decplac
	this.mainFrame.CPFinder.unittable = deepcopy(tmpFinder.unittable)
	this.mainFrame.CPFinder.unitmeta = deepcopy(tmpFinder.unitmeta)
	this.mainFrame.CPFinder.CMDS = {};
	this.mainFrame.CPFinder.CMDS.cmdopts = deepcopy(tmpFinder.CMDS.cmdopts)
	this.mainFrame.CPFinder.oriframe = ControlPanel.mainFrame
	local obsunits = "s1_obsspeed zcmdangle zcmddistance"
	for k,v in pairs(this.mainFrame.CPFinder.unittable)	do
		if not string.find(obsunits,k) then
			this.mainFrame.CPFinder.unittable[k] = nil
			this.mainFrame.CPFinder.unitmeta[k] = nil
		end
	end
	this.mainFrame.CPFinder.infoPanes = deepcopy(tmpFinder.infoPanes)
	this.mainFrame.CPFinder.openParDlgs = deepcopy(tmpFinder.openParDlgs)
	tmpFinder:closeFinder();
	tmpFinder:destruct();
end;
winMainFrame = function(this)
	local textlayout = textlayout
	local getheight = getheight
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local winact = true
	local pressSwitch = pressSwitch
	if this.mvrType == "holey" then
		winact = false
	end
	this.mainFrame = CPBox:new()
	:init("mainFrame.CPControlPanel", 0, 0, 0, 0)
	:bordercolor(cpborframecp)
	:fillcolor(cpfillframecp)
	:movable(false)
	:clickable(false)
	:active(winact)
	:visible(true)
	:attach(this.moveButton, 0, -this.wh, -this.ww , lcButtonsize + 2*lcButtonspace)
	this.mainFrame:makeBranch(this);
	this.mainFrame.wobj = this
	this.mainFrame.la = 0;
	this.mainFrame.ba = -this.wh;
	this.mainFrame.ra = -this.ww;
	this.mainFrame.ta = lcButtonsize + 2*lcButtonspace;
	this.mainFrame:header("");
	this.mainFrame.lineoffset = 0;
	this.mainFrame.slidingV = false;
	this.mainFrame.marginoffset = 0;
	this.mainFrame.slidingH = false;
	this.mainFrame.SbLimit = false;
	this.mainFrame.BbLimit = false;
	this.mainFrame.popupMenus = {};
	this.mainFrame.mvrType = this.mvrType
	this.mainFrame.mover = true
	this.mainFrame.tableprep = function (this)
		for i=1,table.maxn(this.dtable) do
			table.insert(this.frametext,"right click for menu...");
			table.insert(this.frametext.txtcol,i,cpcolmenul)
		end;
	end;
	this.mainFrame.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.popupMenus});
		this.popup:init(this,parent,"CPpopup",x,y,"CelPad Functions","no");
		this.popup:makeBranch(this);
	end;
	this.mainFrame.Customdraw = function(this)
		textlayout:setfont(cpfntmenu);
		textlayout:setpos(this.lb+5, this.tb-cpfntmenu:getheight());
		textlayout:setlinespacing(cpfntmenu:getheight());
		textlayout:setfontcolor(cpcolheader);
		textlayout:setpos(this.lb+5, this.tb-normalfont:getheight()+19);
		textlayout:println(tostring(this.Header));
		textlayout:setfontcolor(cpcolmenul);
		textlayout:setpos(this.lb+5, this.tb-cpfntmenu:getheight());
		textlayout:println("Right click here for CelPad functions menu.");
		textlayout:println("Right click on top bar for observer commands.");
		pressSwitch(this)
	end;
	return this.mainFrame;
end;
resizePanel = function(this,dw,dh)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.mainFrame.ra = this.mainFrame.ra - dw;
	this.mainFrame.ba = this.mainFrame.ba - dh;
	for i,v in ipairs(this.tButtons) do
		v.ba = this.mainFrame:wh()+lcButtonspace
		v.la = this.mainFrame:ww()-lcButtonsize*v.bindex - ((v.bindex-1)*lcButtonspace)
		v.ra = (v.bindex-1)*lcButtonspace+(v.bindex-1)*lcButtonsize
	end
	this.RszButton.la = this.RszButton.la + dw;
	this.RszButton.ta = this.RszButton.ta + dh;
end;
createIcon = function(this, wObject, iconname)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local textlayout = textlayout
	local s_gsub, t_str = string.gsub, tostring
	local iconinfo = ms035IconInfo
	local finder = wObject.mainFrame.CPFinder
	IconsRepos = true;
	this.icon = CPBox:new({tCelPadHUD.Icons})
	:init("this.icon-"..tostring(iconname), 0, 0, 0, 0)
	:bordercolor(cpboriconn)
	:fillcolor(cpfilliconn)
	:movable(true)
	:clickable(false)
	:visible(true)
	:active(true)
	:attach(this.mainFrame, 10,10,10,10);
	this.icon.window = wObject;
	this.icon.CPpointer = this;
	this.icon.line = 1;
	this.icon.clmn = 1;
	this.icon.ixla = 0;
	this.icon.ixta = 0;
	this.icon.icontext = "none"
	this.icon.popupmenu = function(this, wFrame, x, y)
		this.window.Minimized = not this.window.Minimized
		this.window.moveButton:visible(not this.window.Minimized);
		this.window:processFrameMenu(this.window.mainFrame,
		function(o)
			if o.menupane.Sticky == false then
				if this.window.Minimized then
					o.menupane:visible(false);
				else
					if not this.window.mainFrame.HidMenu then
						o.menupane:visible(true);
					end
				end
			end;
			o.menupane:orderfront();
		end
		)
	end;
	this.icon.Customdraw = function(this)
		local infletter = "i:"
		local finder = this.window.mainFrame.CPFinder
		textlayout:setfont(cpfntmenu);
		textlayout:setpos(this.lb+6, this.tb-cpfntmenu:getheight());
		textlayout:setlinespacing(cpfntmenu:getheight());
		textlayout:setfontcolor(cpcolicon);
		if iconinfo and finder then
			if finder.runningTask ~= 0 then
				infletter = "a:"
				if finder.paused then
					infletter = "p:"
				end
			elseif finder.niling then
				infletter = "c:"
			end
			this.icontext = infletter..this.window.mainFrame.Header
		else
			this.icontext = this.window.mainFrame.Header
		end
		textlayout:println(this.icontext);
		if this.window.Minimized then
			this:fillcolor(cpfilliconm)
			this:bordercolor(cpboriconm)
		else
			this:fillcolor(cpfilliconn)
			this:bordercolor(cpboriconn)
		end;
		if this.Pressed then
			IconsRepos = true
		end;
	end;
	this.icon.Action = (function()
		return
		function(this)
			switchdone = false;
			this.window.moveButton:orderfront();
			this.window:processFrameMenu(this.window.mainFrame, this.window.moveButton.pressedfnc)
		end
	end) ()
	return this.icon;
end;
savelastpos = function(this)
	lastwindow.lastcpwx = this.moveButton:wx();
	lastwindow.lastcpwy = this.moveButton:wy() - this.mainFrame:wh();
	lastwindow.lastcpww = this.mainFrame:ww();
	lastwindow.lastcpwh = this.mainFrame:wh();
end
}
CPUniWindow = CClass {
classname = "CPUniWindow";
superclass = CPWindow;
objtype = "uniWinObject";
init = function (this, objname, swx, swy, sww, swh, dwhat, dobject, dodesc)
	this.objname = objname;
	local mergemenutabs = mergemenutabs
	this.wx, this.wy, this.ww, this.wh = swx, swy, sww, swh;
	if this.wy < 20 then this.wy = ScrY - (this.wh+20); end;
	if (this.wx + this.ww) > (ScrX - 20) then this.wx = 20; end;
	this.dwhat = dwhat;
	this.dobject = dobject;
	this.dodesc = dodesc;
	this.tButtons = {};
	this.tVbars = {};
	this.tHbars = {};
	this.tCelPadHUD = tCelPadHUD;
	this.mvrType = wMovWin
	this:winMoveButton()
	this:winMainFrame(this.dobject, this.dodesc)
	this.mainFrame.mvbutton = this.moveButton
	this.moveButton.wframe = this.mainFrame;
	this.moveButton.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.wframe.popupMenus});
		this.popup.menutab = mergemenutabs(tCelPadHUD.Menu["mvbtnpup"],tCelPadHUD.Menu["mvbtnpupUW"]);
		this.popup:init(this,parent,"mvbtnpupUW",x,y,"undefined","no");
		this.popup:makeBranch(this);
	end;
	this:winRszButton();
	this:winCloseButton(0);
	this:winMinButton(1)
	if showMenuHidBtn then
		this.btnindex = 3
		this:winHidMButton(2)
	else
		this.btnindex = 2;
	end;
	if showWrapBtn then
		this.txwrapbtn = this:winButton(this.btnindex,"w");
		this.btnindex = this.btnindex + 1;
		this.txwrapbtn.Action = (function()
			return
			function()
				this.mainFrame:wrapline(not this.mainFrame.Wrapline);
			end
		end) ();
		this.txwrapbtn.Customdraw = function()
			if this.mainFrame then
				if this.mainFrame.Wrapline then
					this.txwrapbtn:text("W")
				else
					this.txwrapbtn:text("w")
				end
			end
		end
	end;
	if showScrollBtn then
		this.txtscrlbtn = this:winButton(this.btnindex,"s");
		this.btnindex = this.btnindex + 1;
		this.txtscrlbtn.Action = (function()
			return
			function()
				this.mainFrame:scroll(not this.mainFrame.Scroll);
			end
		end) ();
		this.txtscrlbtn.Customdraw = function()
			if this.mainFrame then
				if this.mainFrame.Scroll then
					this.txtscrlbtn:text("S")
				else
					this.txtscrlbtn:text("s")
				end
			end
		end
	end;
	if showTextBtn then
		this.txttxtbtn = this:winButton(this.btnindex,"t");
		this.btnindex = this.btnindex + 1;
		this.txttxtbtn.Action = (function()
			return
			function()
				this.mainFrame:drawtext(not this.mainFrame.Drawtext);
			end
		end) ();
		this.txttxtbtn.Customdraw = function()
			if this.mainFrame then
				if this.mainFrame.Drawtext then
					this.txttxtbtn:text("T")
				else
					this.txttxtbtn:text("t")
				end
			end
		end
	end;
	if showVerbBtn then
		this.txtvrbbtn = this:winButton(this.btnindex,"v");
		this.btnindex = this.btnindex + 1;
		this.txtvrbbtn.Action = (function()
			return
			function()
				this.mainFrame:verbose(not this.mainFrame.Verbose);
			end
		end) ();
		this.txtvrbbtn.Customdraw = function()
			if this.mainFrame then
				if this.mainFrame.Verbose then
					this.txtvrbbtn:text("V")
				else
					this.txtvrbbtn:text("v")
				end
			end
		end
	end;
	if showViewBtn and this.dwhat == "f" then
		this.viewmodebtn = this:winButton(this.btnindex,"L");
		this.btnindex = this.btnindex + 1;
		this.viewmodebtn.Action = (function()
			return
			function()
				if this.mainFrame.whtable == this.mainFrame.CPFinder.sysLog then
					tCelPadHUD.functions.viewResults(this.mainFrame)
				elseif this.mainFrame.whtable == this.mainFrame.CPFinder.resultSet then
					tCelPadHUD.functions.viewLog(this.mainFrame)
				end;
			end
		end) ();
		this.viewmodebtn.Customdraw = function()
			if this.mainFrame.whtable == this.mainFrame.CPFinder.sysLog then
				this.viewmodebtn:text("L")
			elseif this.mainFrame.whtable == this.mainFrame.CPFinder.resultSet then
				this.viewmodebtn:text("R")
			else
				this.viewmodebtn:text(" ")
			end
		end
	end;
	this:scrollBarV();
	this:scrollBarH();
	this.cpicon = ControlPanel:createIcon(this,this.moveButton.Header)
	this.cpicon:makeBranch(this);
	this:savelastpos("init")
end;
scrollBarV = function(this)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local winRecomp = winRecomp
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	this.SbFrame = CPBox:new({this.tVbars})
	:init("this.SbFrame", 0, 0, 0, 0)
	:bordercolor(cpbormwslfr)
	:fillcolor(cpfillmwslfr)
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()+lcButtonspace, lcButtonsize+lcButtonspace, -lcButtonsize-lcButtonspace, lcButtonsize+lcButtonspace)
	this.SbFrame:makeBranch(this);
	this.SbFrame.wobj = this;
	this.SbFrame.Customdraw = function(this)
		this.bw, this.bh = this:size()
		this.wobj.mainFrame.sbh = this.bh;
		if this.Pressed then
			winRecomp(this.wobj.RszButton)
			if this.wobj.mainFrame.xba > this.coy then
				this.wobj.mainFrame.lineoffset = this.wobj.mainFrame.lineoffset+1;
			end;
			if this.wobj.mainFrame.xta > 3 and (this.bh - this.wobj.mainFrame.xta) < this.coy then
				this.wobj.mainFrame.lineoffset = this.wobj.mainFrame.lineoffset-1;
			end;
		end;
	end;
	this.SbFrame.SbUpButton = CPBox:new({this.tVbars})
	:init("this.SbFrame.SbUpButton", 0, 0, 0, 0)
	:bordercolor(cpbormwarrow)
	:fillcolor(cpfillmwarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolmwarrow)
	:textpos("center")
	:movetext(0, 5)
	:text("^")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()+lcButtonspace, this.mainFrame:wh()-(lcButtonsize+lcButtonspace), -lcButtonsize-lcButtonspace, 0)
	this.SbFrame.SbUpButton:makeBranch(this);
	this.SbFrame.SbUpButton.wobj = this;
	this.SbFrame.SbUpButton.Customdraw = function(this)
		this.ba=this.wobj.mainFrame:wh()-(lcButtonsize+lcButtonspace)
		local arrowdelay, timerrand
		if this.Pressed then
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.wobj.mainFrame.lineoffset = this.wobj.mainFrame.lineoffset-1;
						if this.wobj.mainFrame.lineoffset < 0 then this.wobj.mainFrame.lineoffset = 0; end
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.SbFrame.SbUpButton.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.wobj.mainFrame.lineoffset = this.wobj.mainFrame.lineoffset-1;
			if this.wobj.mainFrame.lineoffset < 0 then this.wobj.mainFrame.lineoffset = 0; end
		end
	end) ();
	this.SbFrame.SbDownButton = CPBox:new({this.tVbars})
	:init("this.SbFrame.SbDownButton", 0, 0, 0, 0)
	:bordercolor(cpbormwarrow)
	:fillcolor(cpfillmwarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolmwarrow)
	:textpos("center")
	:movetext(0, 9)
	:text("v")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()+lcButtonspace, 0, -lcButtonsize-lcButtonspace, this.mainFrame:wh()-(lcButtonsize+lcButtonspace))
	this.SbFrame.SbDownButton:makeBranch(this);
	this.SbFrame.SbDownButton.wobj = this;
	this.SbFrame.SbDownButton.Customdraw = function(this)
		this.ta=this.wobj.mainFrame:wh()-(lcButtonsize+lcButtonspace)
		local arrowdelay, timerrand
		if this.Pressed then
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.wobj.mainFrame.lineoffset = this.wobj.mainFrame.lineoffset+1;
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.SbFrame.SbDownButton.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.wobj.mainFrame.lineoffset = this.wobj.mainFrame.lineoffset+1;
		end
	end) ();
	this.SbFrame.SbSlider = CPBox:new()
	:init("SbSlider", 0, 13, 0, 13)
	:bordercolor(cpbormwslider)
	:fillcolor(cpfillmwslider)
	:movable(true)
	:clickable(false)
	:active(true)
	:attach(this.SbFrame, 0, 13, 0, 13)
	this.SbFrame.SbSlider:makeBranch(this);
	this.SbFrame.SbSlider.wobj = this;
	this.SbFrame.SbSlider.Customdraw = function(this)
		if this.wobj.mainFrame.lineoffset < 0 then
			this.wobj.mainFrame.xta = 3;
			this.wobj.mainFrame.xba = 3;
			this.ta = 3;
			this.ba = 3;
		end;
		if this.Pressed then
			winRecomp(this.wobj.RszButton)
			for i,v in ipairs(this.wobj.mainFrame.popupMenus) do
				v.menupane:orderfront();
			end;
			this.wobj.mainFrame.slidingV = true
			this.wobj.mainFrame.xta=this.ta;
			if this.wobj.mainFrame.xta < 4 then
				this.wobj.mainFrame.xta = 0;
				this.ta = 3;
				this.wobj.mainFrame.lineoffset = 0;
			end;
		else
			this.wobj.mainFrame.slidingV = false
			if this.wobj.mainFrame.xta > 2 then
				this.ta=this.wobj.mainFrame.xta;
			else
				this.ta=3
			end
		end;
		this.ba=this.wobj.mainFrame.xba
		if this.wobj.mainFrame.xba < 4 then
			this.wobj.mainFrame.xba = 1;
			this.ba = 3;
		end;
		this.bw, this.bh = this:size()
		this.wobj.mainFrame.xh = this.bh
	end
	return this.SbFrame;
end;
scrollBarH = function(this)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local winRecomp = winRecomp
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	this.BbFrame = CPBox:new({this.tHbars})
	:init("this.BbFrame", 0, 0, 0, 0)
	:bordercolor(cpbormwslfr)
	:fillcolor(cpfillmwslfr)
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.mainFrame, lcButtonsize+lcButtonspace, -lcButtonsize-lcButtonspace, -this.mainFrame:ww()+2*(lcButtonsize+lcButtonspace), this.mainFrame:wh()+lcButtonspace)
	this.BbFrame:makeBranch(this);
	this.BbFrame.wobj = this;
	this.BbFrame.Customdraw = function(this)
		this.bw, this.bh = this:size()
		this.wobj.mainFrame.sbw = this.bw;
		if this.Pressed then
			winRecomp(this.wobj.RszButton)
			if this.bw - this.wobj.mainFrame.xra < this.cox then
				this.wobj.mainFrame.marginoffset = this.wobj.mainFrame.marginoffset+1;
			end;
			if this.cox < this.wobj.mainFrame.xla and this.wobj.mainFrame.xla > 3  then
				this.wobj.mainFrame.marginoffset = this.wobj.mainFrame.marginoffset-1;
			end;
		end;
	end;
	this.BbFrame.BbRightButton = CPBox:new()
	:init("this.BbFrame.BbRightButton", 0, 0, 0, 0)
	:bordercolor(cpbormwarrow)
	:fillcolor(cpfillmwarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolmwarrow)
	:textpos("center")
	:movetext(0, 8)
	:text(">")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.mainFrame, this.mainFrame:ww()-lcButtonsize, -lcButtonsize-lcButtonspace, 0, this.mainFrame:wh()+lcButtonspace)
	this.BbFrame.BbRightButton:makeBranch(this.BbFrame)
	this.BbFrame.BbRightButton.wobj = this;
	this.BbFrame.BbRightButton.Customdraw =	function(this)
		this.la = this.wobj.mainFrame:ww()-lcButtonsize
		this.ta = this.wobj.mainFrame:wh()+lcButtonspace
		local arrowdelay, timerrand
		if this.Pressed then
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						if this.wobj.mainFrame.xra >= 3 then
							this.wobj.mainFrame.marginoffset = this.wobj.mainFrame.marginoffset+1;
						end
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.BbFrame.BbRightButton.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			if this.wobj.mainFrame.xra >= 3 then
				local mx = 1
				if this.wobj.mainFrame.marginoffset == 0 then mx = 3 end;
				this.wobj.mainFrame.marginoffset = this.wobj.mainFrame.marginoffset+mx;
			end;
		end
	end) ();
	this.BbFrame.BbLeftButton = CPBox:new()
	:init("this.BbFrame.BbLeftButton", 0, 0, 0, 0)
	:bordercolor(cpbormwarrow)
	:fillcolor(cpfillmwarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolmwarrow)
	:textpos("center")
	:movetext(0, 8)
	:text("<")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.mainFrame, 0, -lcButtonsize-lcButtonspace, this.mainFrame:ww()-lcButtonsize, this.mainFrame:wh()+lcButtonspace)
	this.BbFrame.BbLeftButton:makeBranch(this.BbFrame)
	this.BbFrame.BbLeftButton.wobj = this;
	this.BbFrame.BbLeftButton.Customdraw = function(this)
		this.ra = this.wobj.mainFrame:ww()-lcButtonsize
		this.ta = this.wobj.mainFrame:wh()+lcButtonspace
		local arrowdelay, timerrand
		if this.Pressed then
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.wobj.mainFrame.marginoffset = this.wobj.mainFrame.marginoffset-1;
						if this.wobj.mainFrame.marginoffset < 0 then this.wobj.mainFrame.marginoffset=0 end;
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.BbFrame.BbLeftButton.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.wobj.mainFrame.marginoffset = this.wobj.mainFrame.marginoffset-1;
			if this.wobj.mainFrame.marginoffset < 0 then this.wobj.mainFrame.marginoffset=0 end;
		end
	end) ();
	this.BbFrame.BbSlider = CPBox:new()
	:init("BbSlider", 0, 0, 0, 0)
	:bordercolor(cpbormwslider)
	:fillcolor(cpfillmwslider)
	:movable(true)
	:clickable(false)
	:active(true)
	:attach(this.BbFrame, 6, 0, 6, 0)
	this.BbFrame.BbSlider:makeBranch(this.BbFrame)
	this.BbFrame.BbSlider.wobj = this;
	this.BbFrame.BbSlider.Customdraw = function(this)
		this.bw, this.bh = this:size()
		if this.Pressed then
			winRecomp(this.wobj.RszButton)
			for i,v in ipairs(this.wobj.mainFrame.popupMenus) do
				v.menupane:orderfront();
			end;
			this.wobj.mainFrame.slidingH = true
			this.wobj.mainFrame.xla=this.la;
		else
			this.wobj.mainFrame.slidingH = false
			this.la=this.wobj.mainFrame.xla;
		end;
		this.ra=this.wobj.mainFrame.xra
		if this.wobj.mainFrame.xla < 4 then
			this.wobj.mainFrame.xla = 0;
			this.la=3;
			this.wobj.mainFrame.marginoffset = 0;
		end;
		if this.wobj.mainFrame.xra < 3 then
			this.wobj.mainFrame.xra=2;
			this.ra=2;
		end;
		this.wobj.mainFrame.xw = this.bw
	end
	return this.BbFrame;
end;
winMainFrame = function(this, whtable, dtdesc)
	local textlayout = textlayout
	local getwidth = getwidth
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local cpfntmainw = cpfntmainw
	local tablepage = tablepage
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local s_to = tostring
	local s_sub = string.sub
	local s_len = string.len
	local m_ceil = math.ceil
	local t_ins = table.insert
	local math_round = math_round;
	local pressSwitch = pressSwitch
	local getTxtChars = getTxtChars
	local winact = true
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	if this.mvrType == "holey" then
		winact = false
	end
	this.mainFrame = CPBox:new()
	:init("mainFrame", 0, 0, 0, 0)
	:bordercolor(cpborframe)
	:fillcolor(cpfillframe)
	:clickable(false)
	:active(winact)
	:movable(false)
	:visible(true)
	:attach(this.moveButton, 0, -this.wh, -this.ww , lcButtonsize + 2*lcButtonspace)
	this.mainFrame:makeBranch(this)
	this.mainFrame.mvrType = this.mvrType
	this.mainFrame.mover = true
	this.mainFrame:drawtext(defgDrawtext)
	this.mainFrame:verbose(defgVerbose)
	this.mainFrame:scroll(defgScroll)
	this.mainFrame:wrapline(defgWordwrap)
	this.mainFrame:header("")
	this.mainFrame.la = 0;
	this.mainFrame.ba = -this.wh;
	this.mainFrame.ra = -this.ww;
	this.mainFrame.ta = lcButtonsize + 2*lcButtonspace;
	this.mainFrame.xba = 2;
	this.mainFrame.xta = 2;
	this.mainFrame.xla = 2;
	this.mainFrame.xra = 2;
	this.mainFrame.xh = 1;
	this.mainFrame.xw = 1;
	this.mainFrame.sbh = 0;
	this.mainFrame.sbw = 0;
	this.mainFrame.endline = 1
	this.mainFrame.popupMenus = {};
	this.mainFrame.pickedItems = {};
	this.mainFrame.oriwobj = this;
	this.mainFrame.wobj = this;
	this.mainFrame.dtable = whtable;
	this.mainFrame.dtable.txtcol = {};
	this.mainFrame.whtable = whtable;
	this.mainFrame.whtable.txtcol = {};
	this.mainFrame.dtdesc = dtdesc;
	this.mainFrame.HidMenu = false;
	this.mainFrame.lineoffset = 0;
	this.mainFrame.slidingV = false;
	this.mainFrame.marginoffset = 0;
	this.mainFrame.slidingH = false;
	this.mainFrame.SbLimit = false;
	this.mainFrame.BbLimit = false;
	this.mainFrame.switch_wrap=false;
	this.mainFrame.pagenumber = 1;
	this.mainFrame.Maxpageitems = Maxpageitems
	this.mainFrame.browseButtons = function (this)
		this.wobj.rendbtn = this.wobj:winButton(#(this.wobj.tButtons),">|");
		this.wobj.rendbtn.Action = (function()
			return
			function()
				this.pagenumber = this.pages
				this.Scroll = false;
				this.lineoffset = 0;
			end
		end) ();
		this.wobj.rbrwbtn = this.wobj:winButton(#(this.wobj.tButtons),">");
		this.wobj.rbrwbtn.Action = (function()
			return
			function()
				if this.wobj.rbrwbtn.rbrwbtntimer then
					this.wobj.rbrwbtn.rbrwbtntimer.status = "kill";
					this.wobj.rbrwbtn.rbrwbtntimer = nil;
				end;
				this.wobj.rbrwbtn.xdone = nil;
				this.pagenumber = this.pagenumber + 1;
				if this.pagenumber > this.pages then this.pagenumber = this.pages; end;
				this.Scroll = false;
				this.lineoffset = 0;
			end
		end) ();
		this.wobj.rbrwbtn.Customdraw = function ()
			local arrowdelay, timerrand
			if this.wobj.rbrwbtn.Pressed then
				if this.wobj.rbrwbtn.xdone == nil then
					this.wobj.rbrwbtn.xdone = true;
					arrowdelay=ldelay1;
				else
					arrowdelay=ldelay2;
				end;
				if not this.wobj.rbrwbtn.rbrwbtntimer then
					timerrand=s_to(math.random());
					this.wobj.rbrwbtn.rbrwbtntimer = CPtimer:new({tCelPad.Timers})
					this.wobj.rbrwbtn.rbrwbtntimer:init("rbrwbtntimer","rbrwbtntimer:"..timerrand,arrowdelay,"standalone",0,
					function(o)
						if this.wobj.rbrwbtn.Pressed then
							this.pagenumber = this.pagenumber + 1;
							if this.pagenumber > this.pages then this.pagenumber = this.pages; end
							this.wobj.rbrwbtn.xdone = true;
						else
							this.wobj.rbrwbtn.xdone = nil;
						end
						this.wobj.rbrwbtn.rbrwbtntimer = nil;
					end
					);
					this.wobj.rbrwbtn.rbrwbtntimer:makeBranch(ControlPanel)
				end;
			end;
		end;
		this.wobj.lbrwbtn = this.wobj:winButton(#(this.wobj.tButtons),"<");
		this.wobj.lbrwbtn.Action = (function()
			return
			function()
				if this.wobj.lbrwbtn.lbrwbtntimer then
					this.wobj.lbrwbtn.lbrwbtntimer.status = "kill";
					this.wobj.lbrwbtn.lbrwbtntimer = nil;
				end;
				this.wobj.lbrwbtn.xdone = nil;
				this.pagenumber = this.pagenumber - 1;
				if this.pagenumber < 1 then this.pagenumber = 1; end;
				if this.pagenumber > this.pages then this.pagenumber = this.pages; end;
				this.Scroll = false;
				this.lineoffset = 0;
			end
		end) ();
		this.wobj.lbrwbtn.Customdraw = function ()
			pagestext = this.pagenumber.."/"..this.pages;
			if this.pagenumber > this.pages then this.pagenumber = this.pages; end
			textlayout:setpos(this.wobj.lendbtn.lb-cpgetwidth(cpfntmenu,pagestext), (this.wobj.lendbtn.tb-lcButtonsize+lcButtonspace)-1);
			textlayout:setfontcolor(cpcolheader);
			textlayout:setfont(cpfntheader);
			textlayout:println(pagestext);
			textlayout:setfont(cpfntmainw);
			local arrowdelay, timerrand
			if this.wobj.lbrwbtn.Pressed then
				if this.wobj.lbrwbtn.xdone == nil then
					this.wobj.lbrwbtn.xdone = true;
					arrowdelay=ldelay1;
				else
					arrowdelay=ldelay2;
				end;
				if not this.wobj.lbrwbtn.lbrwbtntimer then
					timerrand=s_to(math.random());
					this.wobj.lbrwbtn.lbrwbtntimer = CPtimer:new({tCelPad.Timers})
					this.wobj.lbrwbtn.lbrwbtntimer:init("lbrwbtntimer","lbrwbtntimer:"..timerrand,arrowdelay,"standalone",0,
					function(o)
						if this.wobj.lbrwbtn.Pressed then
							this.pagenumber = this.pagenumber - 1;
							if this.pagenumber < 1 then this.pagenumber = 1; end
							this.wobj.lbrwbtn.xdone = true;
						else
							this.wobj.lbrwbtn.xdone = nil;
						end
						this.wobj.lbrwbtn.lbrwbtntimer = nil;
					end
					);
					this.wobj.lbrwbtn.lbrwbtntimer:makeBranch(ControlPanel)
				end;
			end;
		end;
		this.wobj.lendbtn = this.wobj:winButton(#(this.wobj.tButtons),"|<");
		this.wobj.lendbtn.Action = (function()
			return
			function()
				this.pagenumber = 1
				this.Scroll = false;
				this.lineoffset = 0;
			end
		end) ();
		local mnuptable = {
		this.wobj.rendbtn;
		this.wobj.rbrwbtn;
		this.wobj.lbrwbtn;
		this.wobj.lendbtn;
		};
		local upcheck = function()
			local mnup;
			for g,h in ipairs(mnuptable) do
				mnup = mnup or h.Menuup
			end
			return mnup
		end;
		this.wobj.rendbtn.frame = this
		this.wobj.rendbtn.popupmenu = function(this,parent,x,y)
			if not upcheck() then
				this.popup = SetupMenu:new({parent.popupMenus});
				this.popup.menutab = {pgnum = this.frame.pagenumber;};
				this.popup.metatab = {pgnum = {"Page Number:",1,1,this.frame.pages};};
				this.popup:init(this,parent,"pgnum",x,y,"Go To Page","dlgok");
				this.popup:makeBranch(this);
				this.popup.btnself.Action = (function()
				return
					function()
						this.frame:scroll(false)
						this.frame.pagenumber = this.popup.menutab.pgnum
						this.popup:quitpopup(this.popup.btnbox);
					end;
				end) ();
			end
		end;
		for r,t in ipairs(mnuptable) do
			if t ~= this.wobj.rendbtn then
				t.frame = this
				t.popupmenu = this.wobj.rendbtn.popupmenu
			end
		end
	end;
	this.mainFrame.browseButtonsQuit = function (this)
		this.wobj.rbrwbtn:destruct();
		this.wobj.lbrwbtn:destruct();
		this.wobj.rendbtn:destruct();
		this.wobj.lendbtn:destruct();
	end;
	this.mainFrame.tableprep = function (this)
		for i=1,table.maxn(this.dtable) do
			if this.Verbose then
				t_ins(this.frametext,": dtable["..i.."]: "..s_to(this.dtable[i]).."; objname: "..s_to(this.dtable[i].objname).."; classname: "..s_to(this.dtable[i].classname)..": superclass: "..s_to(this.dtable[i].superclass).."; objtype: "..s_to(this.dtable[i].objtype));
			else
				if s_to(this.dtable[i].classname) ~= "CPBox" then
					t_ins(this.frametext,": dtable["..i.."]: "..s_to(this.dtable[i]).."; objname: "..s_to(this.dtable[i].objname).."; classname: "..s_to(this.dtable[i].classname)..": superclass: "..s_to(this.dtable[i].superclass).."; objtype: "..s_to(this.dtable[i].objtype));
				end;
			end;
			t_ins(this.frametext.txtcol,i,this.dtable.txtcol[i]);
		end;
	end;
	this.mainFrame.popupmenu = function (this, parent, x, y, itemIndex)
		if this.Wrapline then
			if not this.MSGupT["PopMSGOKw"] then
				this.PopMSGOKw = PopMessage:new({this.popupMenus});
				this.PopMSGOKw:init(this,"PopMSGOKw",x,y,nil,nil,nil,"ok");
				this.PopMSGOKw:makeBranch(this);
			end;
		else
			ox1, oy1 = this:offset(x,y)
			local item_index
			if itemIndex then
				item_index = itemIndex
			else
				item_index = ((this.endline-(math_round((oy1+3)/cpfntmainw:getheight())-1)) + this.lineoffset)+((this.pagenumber-1)*this.Maxpageitems);
			end
			if this.whtable.txtcol[item_index] ~= cpfntcolhghlt then
				if item_index > 0 and item_index <= #this.whtable then
					this:popupwindow(parent, x, y, item_index);
				else
					if not this.MSGupT["PopMSGnoitem"] then
						this.PopMSGnoitem = PopMessage:new({this.popupMenus});
						this.PopMSGnoitem:init(this,"PopMSGnoitem",x,y,nil,nil,nil,"ok");
						this.PopMSGnoitem:makeBranch(this);
					end;
				end;
			else
				if not this.MSGupT["itemPopRunMSG"] then
					this.itemPopRunMSG = PopMessage:new({this.popupMenus});
					this.itemPopRunMSG:init(this,"itemPopRunMSG",x,y,nil,{
					templates2.popMsg.itemPopRunMSG[1]..s_to(item_index)..templates2.popMsg.itemPopRunMSG[2],
					txtfnt = templates2.popMsg.itemPopRunMSG.txtfnt;
					},nil,"ok");
					this.itemPopRunMSG:makeBranch(this);
				end;
			end;
		end;
	end;
	this.mainFrame.popupwindow = function (this, parent, x, y, item_index)
		this.popup = PopupMenu:new({this.popupMenus,this.pickedItems});
		this.popup:init(this,parent,"PopupWindow",x,y,"Popup ["..s_to(item_index).."] "..s_to(this.whtable[item_index]),"no");
		this.popup.menupane.itempopup = true;
		this.popup.menupane.item_index = item_index;
		this.popup.menupane.pane = this.popup;
		this.popup.menupane.src = this;
		this.popup:makeBranch(this);
	end;
	this.mainFrame.Customdraw = function(this)
		textlayout:setfont(cpfntheader);
		textlayout:setpos(this.lb+5, this.tb-cpfntheader:getheight()+18);
		textlayout:setlinespacing(cpfntheader:getheight());
		textlayout:setfontcolor(cpcolheader);
		textlayout:println(this.Header);
		pressSwitch(this)
		if this.Drawtext == true then
			textlayout:setlinespacing(cpfntmainw:getheight());
			textlayout:setfont(cpfntmainw);
			this.frametext = {};
			this.frametext.txtcol = this.frametext.txtcol or {};
			this.displaytext = {};
			this.displaytext.txtcol = this.displaytext.txtcol or {};
			local margin = 15;
			local startline = 1;
			local wrappoints = 0;
			this.pages = m_ceil(#this.whtable/this.Maxpageitems);
			if this.pagenumber > this.pages then this.pagenumber = this.pages end;
			if this.CPFinder then
				this.CPFinder.vwpage[this.CPFinder.viewMode] = this.pagenumber;
			end;
			this.dtable = this.whtable;
			if #this.whtable > this.Maxpageitems then
				if not this.brwbuttons then
					this:browseButtons();
					this.brwbuttons = true;
				end;
				if this.dtable.logNum then
					this.dtable = tablepage(this,this.whtable,this.pagenumber,{"logNum","timestamp","logLevel"});
				else
					this.dtable = tablepage(this,this.whtable,this.pagenumber);
				end;
			else
				if this.brwbuttons then
					this.browseButtonsQuit(this);
					this.brwbuttons = false;
				end;
			end;
			this.tableprep(this);
			for i=1, #this.frametext do
				local txtw = getTxtChars(s_sub(this.frametext[i],this.marginoffset),this:ww(),margin)
				if this.Wrapline then
					this.marginoffset = 0;
					this.xra = 3
					local textdisp
					local txtlaststart = 0
					local fulltext = this.frametext[i]
					local txtlen = s_len(fulltext)
					local exloop = 0
					repeat
						exloop = exloop + 1
						local txtlpos = txtw+txtlaststart
						if txtlpos < txtlen then
							textdisp = s_sub(fulltext,txtlaststart+1,txtlpos);
						else
							textdisp = s_sub(fulltext,txtlaststart+1);
						end;
						t_ins(this.displaytext,textdisp);
						t_ins(this.displaytext.txtcol,i,this.frametext.txtcol[i]);
						txtlaststart = txtlpos
						local textrest = s_sub(fulltext,txtlaststart+1)
						txtw = getTxtChars(textrest,this:ww(),margin)
					until cpfntmainw:getwidth(textdisp) < (this:ww() - margin) or exloop > 10;
					wrappoints=exloop*(cpfntmainw:getheight())
				else
					local textline1 = s_sub(this.frametext[i],1+this.marginoffset,txtw+this.marginoffset);
					t_ins(this.displaytext,textline1);
					t_ins(this.displaytext.txtcol,i,this.frametext.txtcol[i]);
				end;
			end;
			local maxlinepoints=#this.displaytext*cpfntmainw:getheight()
			maxlinepoints=maxlinepoints+wrappoints
			local maxtxtw=0
			this.endline = m_ceil((this:wh()+lcButtonspace)/cpfntmainw:getheight() - 1);
			local maxline = startline+this.lineoffset
			local dlines = this.endline - startline
			if this.Scroll then
				this.pagenumber = this.pages;
				if #this.displaytext>dlines then
					this.lineoffset = table.maxn(this.displaytext) - this.endline
				end
			end
			for line=startline+this.lineoffset,this.endline+this.lineoffset do
				if this.displaytext[line] == nil then
					if this.lineoffset > 0 then
						this.lineoffset = this.lineoffset-1
					end
					this.displaytext[line] = "";
				end;
				if this.Wrapline then
					textlayout:setfontcolor(cpfntcolmainw);
				else
					textlayout:setfontcolor(this.displaytext.txtcol[line] or cpfntcolmainw);
				end;
				textlayout:println(this.displaytext[line] or "");
				local lasttxtw = s_len(this.frametext[line] or "");
				if lasttxtw > maxtxtw then maxtxtw=lasttxtw; maxline=line; end;
			end
			local wrapoffset=math_round((this.xta*table.maxn(this.displaytext))/(this:wh()-2*((lcButtonsize+lcButtonspace))));
			local sblmt = 1;
			if this.xh  < sblmt*lcButtonsize then
				this.SbLimit = true;
			else
				if this.sbh - (this:wh()-(this:wh()*this:wh()/(maxlinepoints-2*cpfntmainw:getheight()))-this.xta) - this.xta > sblmt*lcButtonsize+lcButtonsize/2 then
					this.SbLimit = false;
				end
			end;
			if this.xw  < sblmt*lcButtonsize and this.xw  > 0 then
				this.BbLimit = true;
			else
				if this.sbw - ((this:ww()-(this:ww()*(s_len(this.displaytext[maxline] or " "))/(s_len(this.frametext[maxline] or " "))))-this.xla) - this.xla  > sblmt*lcButtonsize then
					this.BbLimit = false;
				end
			end;
			if this.slidingV then
				this.Scroll = false;
				this.lineoffset = math_round(table.maxn(this.displaytext)*this.xta/(this:wh()-2*(lcButtonsize+lcButtonspace)))
				if this.lineoffset > table.maxn(this.displaytext) - this.endline then
					this.lineoffset = table.maxn(this.displaytext) - this.endline
				end
			else
				this.xta = this.lineoffset*(this:wh()-2*(lcButtonsize+lcButtonspace))/table.maxn(this.displaytext)
			end;
			if not this.SbLimit then
				this.xba = (this:wh()-2*(lcButtonsize+lcButtonspace))*(1 - this.endline/table.maxn(this.displaytext)) - this.xta
			else
				this.xba=this.sbh-(this.xta+sblmt*lcButtonsize)
			end
			if this.slidingH then
				this.marginoffset=math_round(s_len(this.frametext[maxline] or "")*this.xla/this:ww());
			else
				this.xla=this:ww()*this.marginoffset/s_len(this.frametext[maxline] or " ")
			end;
			if not this.Wrapline then
				if not this.BbLimit then
					if #this.dtable>0 then
						this.xra = (this:ww()-(this:ww()*(s_len(this.displaytext[maxline] or " "))/(s_len(this.frametext[maxline] or " "))))-this.xla;
					else
						this.xra = 2
					end;
				else
					this.xra = this.sbw-(this.xla+sblmt*lcButtonsize)
				end
			end;
			if this.Wrapline then
				if this.switch_wrap==false then
					this.switch_wrap = true;
					this.lineoffset=wrapoffset;
				end;
			else
				if this.switch_wrap==true then
					this.switch_wrap=false;
					this.lineoffset=wrapoffset;
				end;
			end;
		else
			textlayout:setfont(cpfntmainw);
			textlayout:setfontcolor(cpfntcolmainw);
			textlayout:println("Text OFF");
			this.xra = 2
			this.xla = 2
			this.xba = 2
			this.xta = 2
		end;
	end;
	return this.mainFrame;
end;
}
PopupMenu = CClass {
classname = "PopupMenu";
superclass = CPObject;
objtype = "popupMenu";
init = function (this, btnbox, parent, objname, swx, swy, text, stpdlg)
	this.popupMenus = {};
	this.tCelPadHUD = tCelPadHUD;
	this.objname = objname;
	this.wx, this.wy = swx, swy;
	this.panebuttons = {};
	this.mvrType = wMovMenu
	this.Header = text;
	this.stpdlg = stpdlg;
	this.parent = parent;
	this.btnbox = btnbox;
	if this.objtype == "queryMenu" then
		if this.finder.scanType == "cel" then
			this.finder.metaQueryVal["zz1_scan_within"].valuelist[1] = ""
			this.finder.metaQueryVal["zz1_scan_pure"].valuelist[1] = ""
		elseif this.finder.scanType == "rs" then
			this.finder.metaQueryVal["zz1_scan_within"].valuelist[1] = deepcopy(templates.metaQuery["zz1_scan_within"].valuelist[1])
			this.finder.metaQueryVal["zz1_scan_pure"].valuelist[1] = deepcopy(templates.metaQuery["zz1_scan_pure"].valuelist[1])
		end
	end;
	this:makePopupPane(btnbox, this.wx, this.wy)
	if btnbox.Stck ~= nil then
		this.menupane.Sticky = btnbox.Stck
	else
		this.menupane.Sticky = defMnSticky
	end
	if btnbox.Hid ~= nil then
		this.menupane.Hiding = btnbox.Hid
	else
		this.menupane.Hiding = defMnHiding
	end
	if btnbox.Vis ~= nil then
		this.menupane:visible(btnbox.Vis)
	end
	btnbox.Menuup = true;
	this:popupCloseBtn(this.menupane, btnbox);
	this:popupStickyBtn(this.menupane, btnbox);
	this:popupHideBtn(this.menupane, btnbox);
	if Help[objname] then
		this:popupHelpBtn(this.menupane, btnbox);
	end;
	if myCelPad.openSetTimer and this.objtype == "setupMenu" then
		myCelPad.openSetTimer.reset = true;
	end
	local btnx = (string.find(this.btnbox.objname,"moveButton") or string.find(this.btnbox.objname,"mainFrame") or string.find(this.btnbox.objname,"vsbtn"))
	if myCelPadHUD.Cascade and btnx ~= 1 and this.parent then
		if btnbox.Stck == nil then
			this.menupane.Sticky = this.parent.Sticky
		end;
		if btnbox.Hid == nil then
			this.menupane.Hiding = this.parent.Hiding
		end;
	end;
	if btnbox.Stck ~= nil then btnbox.Stck = nil end;
	if btnbox.Hid ~= nil then btnbox.Hid = nil end;
	if this.menupane.Sticky then
		local llbx,lbbx,lrbx,ltbx = this.menupane.btboxpointer:bounds()
		this.menupane.lbtn = llbx
		this.menupane.tbtn = ltbx
	end
end;
popupCloseBtn = function(this, box, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.closebutton = CPBox:new({this.panebuttons})
	:init("pupclbtn", 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:textpos("center")
	:movetext(0, 9)
	:text("x")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(box,this.pw-lcButtonsize-lcButtonspace,  this.ph-lcButtonsize-lcButtonspace,  lcButtonspace,  lcButtonspace);
	this.closebutton:makeBranch(this)
	this.closebutton.Action = (function()
		return
		function()
			box = this:quitpopup(btnbox);
		end
	end) ();
	return this.closebutton;
end;
doCascade = function(this, what, btnbox)
	local cascfnc = function(v)
		if what == "Sticky" and v.menupane.Sticky ~= this.menupane.Sticky then
			v.stickybutton:popupmenu(this)
		end
		if what == "Hiding" and v.menupane.Hiding ~= this.menupane.Hiding then
			v.hidebutton:popupmenu(this)
		end
	end
	if myCelPadHUD.Cascade then
		if this.menupane.itempopup then
			for i,v in ipairs(btnbox.pickedItems) do
				cascfnc(v)
			end;
		end;
		for i,v in ipairs(this.menupane.popupMenus) do
			cascfnc(v)
			if #v.menupane.popupMenus > 0 then
				v:doCascade();
			end;
		end;
	end;
end;
popupStickyBtn = function(this, box, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.stickybutton = CPBox:new({this.panebuttons})
	:init("pupstickybtn", 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:textpos("left")
	:movable(false)
	:clickable(false)
	:active(true)
	:menuitem(true)
	if this.objtype == "popupMSG" or this.objtype == "helpPane" then
		this.stickybutton:attach(box,this.pw-(lcButtonsize+lcButtonspace), -lcButtonsize, -lcButtonsize, lcButtonspace);
	else
		this.stickybutton:attach(box,this.pw-2*(lcButtonsize+lcButtonspace), -lcButtonsize,-lcButtonsize, lcButtonspace);
	end;
	this.stickybutton:makeBranch(this)
	this.stickybutton.btnbox = btnbox;
	this.stickybutton.wobj = this
	this.stickybutton.popupmenu = function (this)
		box.Sticky = not box.Sticky;
		if box.Sticky then
			box.lbtn = box.lbx
			box.tbtn = box.tbx
		end;
		this.wobj:doCascade("Sticky",this.btnbox);
	end;
	this.stickybutton.Customdraw = function(this)
		if box.Sticky then
			this:movetext(-2, 9)
			this:text("o")
		else
			this:movetext(0, 11)
			this:text(".")
		end;
	end;
	return this.stickybutton;
end;
popupHideBtn = function(this, box, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.hidebutton = CPBox:new({this.panebuttons})
	:init("puphidebutton", 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:textpos("center")
	:movetext(0, 8)
	:movable(false)
	:clickable(false)
	:active(true)
	:menuitem(true)
	if this.objtype == "popupMSG" or this.objtype == "helpPane" then
		this.hidebutton:attach(box,this.pw-2*(lcButtonsize+lcButtonspace), -lcButtonsize, -lcButtonsize, lcButtonspace);
	else
		this.hidebutton:attach(box,this.pw-3*(lcButtonsize+lcButtonspace), -lcButtonsize, -lcButtonsize, lcButtonspace);
	end;
	this.hidebutton:makeBranch(this)
	this.hidebutton.btnbox = btnbox;
	this.hidebutton.wobj = this
	this.hidebutton.popupmenu = function (this)
		box.Hiding = not box.Hiding;
		this.wobj:doCascade("Hiding",this.btnbox);
	end;
	this.hidebutton.Customdraw = function(this)
		if box.Hiding then
			this:text("H");
		else
			this:text("h");
		end;
	end;
	return this.hidebutton;
end;
popupHelpBtn = function(this, box, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	this.helpbutton = CPBox:new({this.panebuttons})
	:init("puphelpbutton", 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:textpos("center")
	:movetext(0, 8)
	:text("?")
	:movable(false)
	:clickable(false)
	:active(true)
	:menuitem(true)
	if this.objtype == "popupMSG" then
		this.helpbutton:attach(box,this.pw-2*(lcButtonsize+lcButtonspace), -lcButtonsize, -lcButtonsize, lcButtonspace);
	else
		this.helpbutton:attach(box,this.pw-4*(lcButtonsize+lcButtonspace), -lcButtonsize, -lcButtonsize, lcButtonspace);
	end;
	this.helpbutton:makeBranch(this)
	this.helpbutton.wobj=this
	this.helpbutton.btnbox = btnbox;
	this.helpbutton.popupmenu = function (this, parent, x, y)
		local infoattr =  Help[this.wobj.objname]
		if not ControlPanel.mainFrame.MSGupT["HelpPaneMSG"..this.wobj.objname] then
			this.HelpPaneMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
			this.HelpPaneMSG.objtype = "helpPane"
			this.HelpPaneMSG:init(ControlPanel.mainFrame,"HelpPaneMSG"..this.wobj.objname,x,y,"Help: "..this.wobj.Header,infoattr,"i","inf");
			this.HelpPaneMSG:makeBranch(ControlPanel);
		end;
		if this.HelpPaneMSG then
			this.HelpPaneMSG.menupane:visible(true)
		end;
	end;
	return this.helpbutton;
end;
CustomdrawMP = function(pane)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local rsbtn = pane.rsbtn
	pane.pwx, pane.phx = pane:size()
	pane.lbx,pane.bbx,pane.rbx,pane.tbx = pane.btboxpointer:bounds();
	if pane.itempopup then
		if (not pane.itempopupDone) then
			pane.btboxpointer.Menuup = false;
			if pane.wobj.menutab then
			end;
			pane.btboxpointer.whtable = pane.btboxpointer.whtable or {"",txtcol={}};
			pane.pickeditem = pane.btboxpointer.whtable[pane.item_index];
			pane.whtablepointer = pane.btboxpointer.whtable;
			pane.itempopupDone = true;
		end;
		if pane.pickeditem ~= pane.btboxpointer.whtable[pane.item_index] then
			pane.changedindex = false;
			for i,v in ipairs(pane.btboxpointer.whtable) do
				if pane.pickeditem == v then
					local oldindex = pane.item_index;
					pane.item_index = i;
					pane.changedindex = true;
					pane.btboxpointer.whtable.txtcol[oldindex] = cpfntcolmainw;
					local finder = pane.btboxpointer.CPFinder
					if finder then
						if finder.viewMode == "resultset" and finder.cmdset and finder.cmdset.ik == oldindex then
							if oldindex >= finder.CMDS.cmdopts.data.co01startobj then
								pane.btboxpointer.whtable.txtcol[oldindex] = cpfntcolruncmd;
							end
						end
					end
				end;
			end;
			if not pane.changedindex == true then
				pane.pane:quitpopup(pane.btboxpointer);
			end;
		else
			pane.btboxpointer.whtable.txtcol[pane.item_index or 1] = cpfntcolhghlt;
		end;
	end;
	local lalimit, balimit, ralimit, talimit = 4,4,4,4;
	if (pane.la <= lalimit) and not pane.Pressed then
		pane.onborder = 1;
	elseif pane.ba <= balimit then
		pane.onborder = 2;
	elseif pane.ra <= ralimit then
		pane.onborder = 3;
	elseif pane.ta <= talimit then
		pane.onborder = 4;
	else pane.onborder = 0;
	end;
	if not pane.Pressed then
		if pane.Sticky and pane.movingsticky then
			pane.lof = pane.lof + pane.lofd
			pane.tof = pane.tof + pane.tofd
			pane.lofd = 0
			pane.tofd = 0
			pane.movingsticky = false
		end
		if not pane.Sticky then
			pane.lof = pane.lof + pane.lofd
			pane.tof = pane.tof + pane.tofd
			pane.lofd = 0
			pane.tofd = 0
			pane.la = pane.lbx + pane.lof
			if pane.la < lalimit then
				if pane.Hiding then
					pane.la =  -pane.pw
					pane.ra = (ScrX - pane.pw) - (pane.lbx + pane.lof)
				else
					pane.la = lalimit
					pane.ra = (ScrX - pane.pw) - lalimit
				end;
			end;
			pane.ta = (ScrY - pane.tbx) + pane.tof
			if pane.ta < talimit then
				if pane.Hiding then
					pane.ta =  -pane.ph
					pane.ba = (ScrY-pane.ph) - ((ScrY - pane.tbx) + pane.tof)
				else
					pane.ta = talimit;
					pane.ba = (ScrY-pane.ph) - talimit
				end;
			end
			mpba = ScrY - (pane.ta + pane.ph)
			if mpba < balimit then
				pane.ta = pane.ta + (mpba-balimit)
			end
			if pane.ta > talimit then
				if rsbtn and rsbtn.doresize then
				else
					pane.ba = ScrY - (pane.ta + pane.ph)
				end;
			end
			mpra = ScrX - (pane.la + pane.pw)
			if mpra < ralimit then
				pane.la = pane.la + (mpra-ralimit)
			end
			if pane.la > lalimit then
				pane.ra = ScrX - (pane.la + pane.pw)
			end
			if pane.Hiding then
				if  mpra < ralimit then
					pane.ra = -pane.pw
					pane.la = pane.lbx + pane.lof
				end
				if mpba < balimit then
					pane.ba = -pane.ph
					pane.ta = (ScrY - pane.tbx) + pane.tof
				end
			end
		else
			pane.lofd = pane.lbtn - pane.lbx
			pane.tofd =  -(pane.tbtn - pane.tbx)
		end;
	else
		if pane.Sticky then
			pane.movingsticky = true
			pane.lofd = (pane.la - pane.lpupm)
			pane.tofd = (pane.ta - pane.tpupm)
		else
			if pane.onborder == 2 then
				pane.tofd = -(pane.tbtn - pane.tbx) ;
			end;
			pane.movingsticky = false
			pane.lofd = (pane.la - pane.lpupm)
			pane.tofd = (pane.ta - pane.tpupm)
		end
		for i,v in ipairs(pane.popupMenus) do
			v.menupane:orderfront();
		end;
	end;
end;
ActionMP = (function()
	return
	function(pane)
		local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
		if pane.onborder ~= 0 then
			pane.Hiding = false;
		end;
		if pane.onborder == 1 then
			pane.lof = pane.la - pane.lbx;
		end;
		if pane.onborder == 2 then
			pane.tof = ((ScrY-pane.ph) - pane.ba)-(ScrY - pane.tbx);
		end;
		if pane.onborder == 3 then
			pane.lof = (ScrX - pane.pw) - pane.lbx - pane.ra;
		end;
		if pane.onborder == 4 then
			pane.tof = pane.ta - (ScrY - pane.tbx);
		end;
		if pane.lofd*pane.tofd ~= 0 then
			pane.lof = pane.lof + pane.lofd
			pane.tof = pane.tof + pane.tofd
			pane.lofd = 0
			pane.tofd = 0
		end
		pane.lpupm = pane.la
		pane.tpupm = pane.ta
		pane.lbtn = pane.lbx
		pane.tbtn = pane.tbx
	end
end) ();
makePopupPane = function(this, btnbox, x, y)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local maxmin = maxmin
	local maxitem = 0
	this.pw = cpgetwidth(cpfntmenu,this.Header) + 4*(lcButtonsize+lcButtonspace)
	this.menutab = this.menutab or this.tCelPadHUD.Menu[this.objname];
	for itemnum = 1, table.maxn(this.menutab) do
		maxitem=cpgetwidth(cpfntmenu,this.menutab[itemnum])
		if maxitem > this.pw then this.pw = maxitem; end;
	end;
	this.ph = (lcButtonsize+2*lcButtonspace)+((lcMenusize+lcButtonspace)*(table.maxn(this.menutab)));
	this.pra = ScrX-x-this.pw
	this.pba = y-this.ph
	if  this.pra < 4 then x=(x+this.pra)-10 end
	if  this.pba < 4 then y=(y-this.pba)+10 end
	this.menupane = CPBox:new()
	:init("1menupane-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpbormenup)
	:fillcolor(cpfillmenup)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenup)
	:movetext(0, 6)
	:textpos("left")
	:text((this.Header))
	:movable(true)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(screenBox, x, y-this.ph, ScrX-x-this.pw, ScrY-y);
	this.menupane:makeBranch(this);
	this.menupane.ph = this.ph;
	this.menupane.pw = this.pw
	this.menupane.lof,this.menupane.bof = btnbox:offset(x,y);
	this.menupane.pwx, this.menupane.phx = btnbox:size()
	this.menupane.tof =  this.menupane.phx - this.menupane.bof
	this.menupane.lpupm = this.menupane.la
	this.menupane.lofd = 0;
	this.menupane.tpupm = this.menupane.ta
	this.menupane.tofd = 0;
	this.menupane.lbtn = btnbox.ba
	this.menupane.tbtn = btnbox.ta
	this.menupane.popupMenus = {};
	this.menupane.Sticky = defMnSticky;
	this.menupane.Hiding = defMnHiding;
	this.menupane.movingsticky = false;
	this.menupane.itempopup = false;
	this:makePopShadow(this.menupane);
	this.menupane.Action = this.ActionMP;
	this.menupane.btboxpointer = btnbox;
	this.menupane.wobj = this;
	this.menupane.Customdraw = this.CustomdrawMP;
	this.menupane.menuline = {};
	for i,menuitemtext in ipairs(this.menutab) do
		this.menupane.menuline[i] = CPBox:new()
		:init(tostring(menuitemtext), 0, 0, 0, 0)
		:bordercolor(cpbormenul)
		:fillcolor(cpfillmenul)
		:textfont(cpfntmenu)
		:textcolor(cpcolmenul)
		:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
		:textpos("left")
		:text((tostring(menuitemtext)))
		:movable(false)
		:clickable(false)
		:active(true)
		:visible(true)
		:menuitem(true)
		:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
		this.menupane.menuline[i]:makeBranch(this);
		this.menupane.menuline[i].quitmenu = function()
			this:quitpopup(btnbox);
		end;
		this.menupane.menuline[i].oribtn = btnbox;
		if this.menutab.switch[i] == 1 then
			this.menupane.menuline[i].popupmenu=this.menutab.fnctab[i];
		else
			this.menupane.menuline[i].Action = (function()
				return
				this.menutab.fnctab[i];
			end
			) (this);
		end;
		if this.menutab.switch[i] ~= 0 and this.menutab.switch[i] ~= 1 then
			this.menupane.menuline[i].switchbox = CPBox:new()
			:init("this.menupane.menuline[i].switchbox-"..tostring(i), 0, 0, 0, 0)
			:bordercolor(cpborbutton)
			:textfont(cpfntmenu)
			:textcolor(cpcolbutton)
			:movetext(-4, 12)
			:textpos("left")
			:movable(false)
			:clickable(false)
			:active(false)
			:visible(true)
			:attach(this.menupane.menuline[i],this.menupane.pw-(lcButtonsize+lcButtonspace),lcButtonspace,lcButtonspace,lcButtonspace)
			this.menupane.menuline[i].switchbox:makeBranch(this.menupane.menuline[i]);
			this.menupane.menuline[i].switchbox.state = this.menutab.switch[i]
			this.menupane.menuline[i].switchbox.frame = this.menupane.menuline[i].oribtn.wframe
			if menuitemtext == "Scroll" then
				this.menupane.menuline[i].switchbox.Customdraw = function(this)
					if this.frame.Scroll then
						this:text("x")
					else
						this:text(" ")
					end
				end;
			elseif menuitemtext == "Verbose" then
				this.menupane.menuline[i].switchbox.Customdraw = function(this)
					if this.frame.Verbose then
						this:text("x")
					else
						this:text(" ")
					end
				end;
			elseif menuitemtext == "Wrap" then
				this.menupane.menuline[i].switchbox.Customdraw = function(this)
					if this.frame.Wrapline then
						this:text("x")
					else
						this:text(" ")
					end
				end;
			elseif menuitemtext == "Text" then
				this.menupane.menuline[i].switchbox.Customdraw = function(this)
					if this.frame.Drawtext then
						this:text("x")
					else
						this:text(" ")
					end
				end;
			else
				this.menupane.menuline[i].switchbox.Customdraw = function(this)
					if this.state then
						this:text("x")
					else
						this:text(" ")
					end
				end;
			end
		end
		for zz,zv in ipairs(this.menutab.runfnc) do
			if zv == i then
				this.menutab.fnctab[zv](this.menupane.menuline[i],true);
			end;
		end;
	end;
	local max,min = maxmin(this.menutab.runfnc);
	if max > #this.menutab then
		this.menutab.fnctab[max](this.menupane.menuline[#this.menupane.menuline].oribtn);
	end;
	return this.menupane;
end;
makePopShadow = function(this, wobj, valpane)
	if gShowShadows then
		local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
		local lcShadowsize = gShadowsize;
		local lcmsgButtonheight = msgButtonheight;
		local lpw = ScrX - wobj.la - wobj.ra;
		local lph = ScrY - wobj.ba - wobj.ta;
		if (this.stpdlg == "dlgok" or this.stpdlg == "dlgao") and not valpane then
			lph = lph + (lcmsgButtonheight+2*lcButtonspace);
		end;
		local winact = true
		if this.mvrType == "holey" then
			winact = false
		end
		local pressSwitch = pressSwitch
		if wobj.shdr then wobj.shdr:destruct(); end;
		wobj.shdr = CPBox:new()
		:init("wobj.shdr-"..tostring(wobj.objname), 0, 0, 0, 0)
		:fillcolor(cpfillshadow)
		:movable(false)
		:clickable(false)
		:active(winact)
		:visible(true)
		:attach(wobj, lpw,-lph+lcShadowsize,-lcShadowsize,lcShadowsize);
		wobj.shdr:makeBranch(wobj);
		wobj.shdr.mvrType = this.mvrType
		wobj.shdr.mover = true
		wobj.shdr.wobj = this
		wobj.shdr.Action = (function()
		return
		function(this)
			if this.mvrType == "movable" then
				this.wobj.ActionMP(this.wobj.menupane)
			end
		end
	end) ();
		wobj.shdr.Customdraw = function(this)
			pressSwitch(this)
		end;
		if wobj.shdb then wobj.shdb:destruct(); end;
		wobj.shdb = CPBox:new()
		:init("wobj.shdb-"..tostring(wobj.objname), 0, 0, 0, 0)
		:fillcolor(cpfillshadow)
		:movable(false)
		:clickable(false)
		:active(winact)
		:visible(true)
		:attach(wobj, lcShadowsize,-lcShadowsize,-lpw,lph);
		wobj.shdb:makeBranch(wobj);
		wobj.shdb.mvrType = this.mvrType
		wobj.shdb.mover = true
		wobj.shdb.wobj = this
		wobj.shdb.Action = wobj.shdr.Action;
		wobj.shdb.Customdraw = wobj.shdr.Customdraw;
	end;
end;
processMenu = function(this, recp, fnctodo)
	if not fnctodo then
		recpt2 = recp;
		recp = this;
		fnctodo = recpt2
	end;
	if table.maxn(recp.menupane.popupMenus) > 0 then
		for i2,v2 in ipairs(recp.menupane.popupMenus) do
			fnctodo(v2);
			recp:processMenu(v2,fnctodo)
		end;
	end;
end;
quitpopup = function(this, btnbox)
	btnbox.Menuup = false;
	if this.menupane.itempopup then
		if this.menupane.item_index then
			btnbox.whtable.txtcol[this.menupane.item_index] = cpfntcolmainw;
			if btnbox.CPFinder and btnbox.CPFinder.viewMode == "resultset" and btnbox.CPFinder.cmdset and btnbox.CPFinder.cmdset.ik == this.menupane.item_index then
				btnbox.whtable.txtcol[this.menupane.item_index] = cpfntcolruncmd;
			end
		end;
	end;
	if this.objtype == "queryMenu" then
		if this.btnself.oribtn.oribtn.wframe.CPFinder.setupdlg then
			this.btnself.oribtn.oribtn.wframe.CPFinder.setupdlg.closebutton:Action();
			this.btnself.oribtn.oribtn.wframe.CPFinder.setupdlg = nil;
		end;
	end;
	if this.objtype == "setupMenu" then
		if (myCelPad.openSetTimer and #tCelPadHUD.setupPanes == 1) then
			myCelPad.openSetTimer.status = "kill"
			myCelPad.openSetTimer = nil;
		end;
	end;
	if btnbox.finder and btnbox.what then
		btnbox.finder[btnbox.what].mtdlg = nil;
	end;
	btnbox.popup = nil;
	btnbox.setup = nil;
	btnbox.setupdlg = nil;
	this:destruct();
	return ( nil );
end;
}
SetupMenu = CClass {
classname = "SetupMenu";
superclass = PopupMenu;
objtype = "setupMenu";
makePopupPane = function(this, btnbox, x, y)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	this.menutab = this.menutab or tSettings[this.objname];
	this.metatab = this.metatab or tMetaSettings[this.objname];
	this.setitem = {};
	this:getPaneBase(btnbox, x, y)
	return this.menupane;
end;
getPaneBase = function(this,btnbox, x, y)
	local t_str = tostring
	local cpgetwidth = cpgetwidth
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local getsetuphi = getsetuphi
	local table_num = table_num
	local m_min, m_max = math.min, math.max
	local maxitem = 0;
	local maxhiitem = 0;
	local oldcheck = {};
	local statswitch = false
	this.pw = cpgetwidth(cpfntmenu,this.Header) + 4*(lcButtonsize+lcButtonspace)
	this.maxitemi=0;
	this.maxitemv=0;
	local finder = this.finder;
	for i,v in orderedPairs(this.menutab) do
		this.maxitemi=m_max(this.maxitemi,cpgetwidth(cpfntmenu,t_str(i)));
		this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,t_str(v)));
		if this.metatab[i] then
			local hitext = getsetuphi(i,this.metatab)
			if hitext ~= "" then
				if finder and finder.unitmeta and finder.unitmeta[i] then
					local maxmeta = "";
					for a,z in ipairs(finder.unitmeta[i].valuelist) do
						if cpgetwidth(cpfntmenu,z) > cpgetwidth(cpfntmenu,maxmeta) then
							maxmeta = z;
						end;
					end
					hitext = hitext.." ["..maxmeta.."]"
				end;
				this.maxitemi=m_max(this.maxitemi,cpgetwidth(cpfntmenu,hitext));
			end;
		end;
		if t_str(type(v))=="table" then
			if this.menutab[i].valuelist then
				for z,x in ipairs(this.menutab[i].valuelist) do
					this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,t_str(x)));
					if this.metatab[i] and this.metatab[i].valuelist then
						this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,t_str(this.metatab[i].valuelist[z])));
					end;
				end;
			elseif this.menutab[i].choicelist then
				for z,x in ipairs(this.menutab[i].choicelist) do
					this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,t_str(x))+2*(lcButtonsize+lcButtonspace));
					if this.metatab[i] and this.metatab[i].choicelist then
						this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,t_str(this.metatab[i].choicelist[z]))+2*(lcButtonsize+lcButtonspace));
					end;
				end;
			elseif this.menutab[i].maxv then
				local maxminlen;
				if this.metatab[i] then
					for j=3,6,2 do
						if this.metatab[i][j] then
							if finder and finder.unittable and finder.unittable[i] and type(finder.unittable[i][1]) ~= "string" then
								maxminlen = m_max(cpgetwidth(cpfntmenu,t_str(finder.unittable[i][1](this.metatab[i][j],"fromnative"))),cpgetwidth(cpfntmenu,t_str(finder.unittable[i][1](this.metatab[i][j+1],"fromnative"))));
							else
								maxminlen = m_max(cpgetwidth(cpfntmenu,t_str(this.metatab[i][j])),cpgetwidth(cpfntmenu,t_str(this.metatab[i][j+1])));
							end;
							maxminlen = (2*maxminlen)+4*(lcButtonsize+2*lcButtonspace);
							this.maxitemv=m_max(this.maxitemv,maxminlen);
						else
							if finder and finder.unittable and finder.unittable[i] and type(finder.unittable[i][1]) ~= "string" then
								maxminlen = m_max(cpgetwidth(cpfntmenu,t_str(finder.unittable[i][1](this.menutab[i].minv,"fromnative"))),cpgetwidth(cpfntmenu,t_str(finder.unittable[i][1](this.menutab[i].maxv,"fromnative"))));
							else
								maxminlen = m_max(cpgetwidth(cpfntmenu,t_str(this.menutab[i].minv)),cpgetwidth(cpfntmenu,t_str(this.menutab[i].maxv)));
							end;
							maxminlen = (2*maxminlen)+6*lcButtonspace+4*lcButtonsize;
							this.maxitemv=m_max(this.maxitemv,maxminlen);
						end;
					end;
				else
				end;
			else
				local multivstr = "";
				for z,x in ipairs(this.menutab[i]) do
					multivstr = multivstr..t_str(x).."; ";
				end;
				this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,t_str(multivstr)));
			end;
		elseif type(v) == "number" then
			this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,this.metatab[i][3])+2*(lcButtonsize+lcButtonspace))
			this.maxitemv=m_max(this.maxitemv,cpgetwidth(cpfntmenu,this.metatab[i][4])+2*(lcButtonsize+lcButtonspace))
		end;
	end;
	if this.objtype == "queryMenu" then
		this.maxitemi = this.maxitemi + (lcButtonsize+4*lcButtonspace)
	end;
	if this.maxitemi+this.maxitemv > this.pw then
		this.pw = this.maxitemi+this.maxitemv;
	else
		if this.maxitemi > this.maxitemv then this.maxitemv=this.pw-this.maxitemi;
		elseif this.maxitemi < this.maxitemv then this.maxitemi=this.pw-this.maxitemv;
		else
			this.maxitemi=this.pw/2;
			this.maxitemv=this.pw/2;
		end;
	end;
	this.ph = (lcButtonsize+2*lcButtonspace)+((lcMenusize+lcButtonspace)*(table_num(this.menutab)))
	this.pra = ScrX-x-this.pw
	this.pba = y-this.ph
	if  this.pra < 4 then x=(x+this.pra)-10 end
	if  this.pba < 4 then y=(y-this.pba)+10 end
	this.menupane = CPBox:new()
	:init("setuppane-"..t_str(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpbormenup)
	:fillcolor(cpfillmenup)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenup)
	:movetext(0, 6)
	:textpos("left")
	:text(this.Header)
	:movable(true)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(screenBox, x, y-this.ph, ScrX-x-this.pw, ScrY-y);
	this.menupane:makeBranch(this);
	this.menupane.ph = this.ph;
	this.menupane.pw = this.pw
	this.menupane.lof,this.menupane.bof = btnbox:offset(x,y);
	this.menupane.pwx, this.menupane.phx = btnbox:size()
	this.menupane.tof =  this.menupane.phx - this.menupane.bof
	this.menupane.lpupm = this.menupane.la
	this.menupane.lofd = 0;
	this.menupane.tpupm = this.menupane.ta
	this.menupane.tofd = 0;
	this.menupane.lbtn = btnbox.ba
	this.menupane.tbtn = btnbox.ta
	this.menupane.popupMenus = {};
	this.menupane.Sticky = defMnSticky;
	this.menupane.Hiding = defMnHiding;
	this.menupane.movingsticky = false;
	if this.stpdlg == "dlgok" then
		this:dlgOkPane(this,btnbox);
	end;
	if this.stpdlg == "dlgao" then
		this:dlgAOPane(this,btnbox);
	end;
	this:makePopShadow(this.menupane);
	this.menupane.Action = this.ActionMP;
	this.menupane.Customdraw = this.CustomdrawMP
	this.menupane.btboxpointer = btnbox;
	this.menupane.wobj = this;
	local i = 0;
	for prop,value in orderedPairs(this.menutab) do
		if this.metatab[prop] and this.metatab[prop].valuelist and t_str(this.metatab[prop].valuelist[1])=="" then
		else
			i = i + 1;
			this.prop = prop;
			this.value = value;
			this:makeItem(btnbox,i)
		end
		if this.objtype == "queryMenu" then
			if string.sub(t_str(this.prop),1,8)~="zz1_scan" then
				this.setitem[i].scanbox = CPBox:new()
				this.setitem[i].scanbox:init(t_str(prop), 0, 0, 0, 0)
				this.setitem[i].scanbox:bordercolor(cpborbutton)
				this.setitem[i].scanbox:fillcolor(cpfillbutton)
				this.setitem[i].scanbox:textfont(cpfntmenu)
				this.setitem[i].scanbox:textcolor(cpcolbutton)
				this.setitem[i].scanbox:movetext(-2, -0.5*(cpfntmenu:getheight()+lcMenusize)+23)
				this.setitem[i].scanbox:textpos("left")
				this.setitem[i].scanbox:text(getsetuphi(prop,this.metatab))
				this.setitem[i].scanbox:movable(false)
				this.setitem[i].scanbox:clickable(false)
				this.setitem[i].scanbox:active(true)
				this.setitem[i].scanbox:visible(true)
				this.setitem[i].scanbox:attach(this.menupane, this.maxitemi-2*(lcButtonsize+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+(lcButtonsize+2*lcButtonspace), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
				this.setitem[i].scanbox:makeBranch(this);
				this.setitem[i].scanbox.menutab = this.menutab;
				this.setitem[i].scanbox.metatab = this.metatab;
				this.setitem[i].scanbox.prop = prop;
				this.setitem[i].scanbox.wobj = this;
				this.setitem[i].scanbox.Action = (function()
					return
					function(this,unall)
						this.metatab[this.prop].scan = not this.metatab[this.prop].scan
						if not unall then
							oldcheck = nil;
							oldcheck = {};
							this.wobj.clrbtn:text(" ")
							statswitch = false;
						end
					end
				end) ();
				this.setitem[i].scanbox.Customdraw = function(this)
					if this.metatab[this.prop].scan then
						this:text("x")
					else
						this:text(" ")
					end
				end;
				local notstring = "qr002_name_str;qr005_radius;qr007_temperature;qr006_luminosity;qr008_absoluteMagnitude;qr009_bolometricMagnitude;qr004_stellarClass_str;qr017_type_str;qr028_rotationPeriod;qr029_orbitPeriod;qr018_oblateness;qr019_albedo;qr022_atmosphereHeight;qr023_atmosphereCloudHeight;qr024_atmosphereCloudSpeed;qr027_mass;qr302_infoURL;qr020_lifespanStart;qr021_lifespanEnd;qr030_numPlanets;qr300_parent_str;qr100_dso_radius;qr102_hubbleType_str;qr025_Locations;qr202_size;qr203_importance;qr201_featureType_str;qr012_catalogNumber;;;;;;;;;;;;;;;;;;;;;;;;";
				if string.find(notstring,t_str(this.prop)) then
					this.setitem[i].negatebox = CPBox:new()
					this.setitem[i].negatebox:init(t_str(prop), 0, 0, 0, 0)
					this.setitem[i].negatebox:bordercolor(cpborbutton)
					this.setitem[i].negatebox:fillcolor(cpfillbutton)
					this.setitem[i].negatebox:textfont(cpfntmenu)
					this.setitem[i].negatebox:textcolor(cpcolbutton)
					this.setitem[i].negatebox:movetext(-1, -0.5*(cpfntmenu:getheight()+lcMenusize)+21)
					this.setitem[i].negatebox:textpos("left")
					this.setitem[i].negatebox:text(getsetuphi(prop,this.metatab))
					this.setitem[i].negatebox:movable(false)
					this.setitem[i].negatebox:clickable(false)
					this.setitem[i].negatebox:active(true)
					this.setitem[i].negatebox:visible(true)
					this.setitem[i].negatebox:attach(this.menupane, this.maxitemi-(lcButtonsize+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
					this.setitem[i].negatebox:makeBranch(this);
					this.setitem[i].negatebox.menutab = this.menutab;
					this.setitem[i].negatebox.metatab = this.metatab;
					this.setitem[i].negatebox.prop = prop;
					this.setitem[i].negatebox.wobj = this;
					this.setitem[i].negatebox.Action = (function()
						return
						function(this)
							this.metatab[this.prop].negate = not this.metatab[this.prop].negate
						end
					end) ();
					this.setitem[i].negatebox.Customdraw = function(this)
						if this.metatab[this.prop].negate then
							this:text("!")
						else
							this:text(" ")
						end
					end;
				end;
			end;
		end
	end;
	if this.objtype == "queryMenu" then
		this.clrbtn = CPBox:new()
		this.clrbtn:init("queryMenu.clrbtn", 0, 0, 0, 0)
		this.clrbtn:bordercolor(cpborbutton)
		this.clrbtn:fillcolor(cpfillbutton)
		this.clrbtn:textfont(cpfntmenu)
		this.clrbtn:textcolor(cpcolbutton)
		this.clrbtn:movetext(-2, -0.5*(cpfntmenu:getheight()+lcMenusize)+23)
		this.clrbtn:textpos("left")
		this.clrbtn:text(" ")
		this.clrbtn:movable(false)
		this.clrbtn:clickable(false)
		this.clrbtn:active(true)
		this.clrbtn:visible(true)
		this.clrbtn:attach(this.menupane, this.maxitemi-2*(lcButtonsize+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)-(lcMenusize+lcButtonspace)), this.maxitemv+(lcButtonsize+2*lcButtonspace), (2*lcButtonspace+lcButtonsize)-(lcMenusize+lcButtonspace));
		this.clrbtn:makeBranch(this);
		this.clrbtn.Action = (function()
			return
			function()
				if not statswitch then
					for k,v in ipairs(this.setitem) do
						if v.scanbox and v.scanbox.Text == "x" then
							oldcheck[k] = true
							v.scanbox:Action(true)
						end
					end
					this.clrbtn:text("x")
					statswitch = true
				else
					for k,v in ipairs(this.setitem) do
						if v.scanbox and oldcheck[k] then
							v.scanbox:Action(true)
						end
					end
					this.clrbtn:text(" ")
					statswitch = false
				end;
			end
		end) ();
	end;
end;
getBottomPane = function(this, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local pressSwitch = pressSwitch
	local winact = true
	if this.mvrType == "holey" then
		winact = false
	end
	this.menupane.btnpane = CPBox:new()
	:init("this.menupane.btnpane-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpbormenup)
	:fillcolor(cpfillmenup)
	:movable(false)
	:clickable(false)
	:active(winact)
	:visible(true)
	:attach(this.menupane, 0, -(lcmsgButtonheight+2*lcButtonspace), 0, this.ph);
	this.menupane.btnpane:makeBranch(this.menupane);
	this.menupane.btnpane.mover = true
	this.menupane.btnpane.mvrType = this.mvrType
	this.menupane.btnpane.wobj = this
	this.menupane.btnpane.Action = (function()
		return
		function(this)
			this:orderfront();
			if this.mvrType == "movable" then
				this.wobj.ActionMP(this.wobj.menupane)
			end
		end
	end) ();
	this.menupane.btnpane.Customdraw = function(this)
		pressSwitch(this)
		this.Sticky = this.wobj.menupane.Sticky
		this.Hiding = this.wobj.menupane.Hiding
	end;
end;
dlgOkPane = function(this,btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	this:getBottomPane(btnbox)
	this.menupane.btnself = CPBox:new()
	:init("this.menupane.btnself-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:movetext(0, 6)
	:textpos("center")
	:text("OK")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	:attach(this.menupane.btnpane, math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace)/2)), lcButtonspace, math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace)/2)), lcButtonspace);
	this.menupane.btnself:makeBranch(this.menupane);
	this.menupane.btnself.wobj = this;
	this.menupane.btnself.btnbox = btnbox;
	this.btnself = this.menupane.btnself;
end;
dlgAOPane = function(this,btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	this:getBottomPane(btnbox)
	this.menupane.btnselfAPL = CPBox:new()
	:init("this.menupane.btnselfAPL-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:movetext(0, 6)
	:textpos("center")
	:text("Apply")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	:attach(this.menupane.btnpane, math.ceil((this.pw/2)-((lcmsgButtonwidth+2*lcButtonspace))), lcButtonspace, math.ceil((this.pw/2)+lcButtonspace), lcButtonspace);
	this.menupane.btnselfAPL:makeBranch(this.menupane);
	this.menupane.btnselfAPL.wobj = this;
	this.menupane.btnselfAPL.btnbox = btnbox;
	this.btnselfAPL = this.menupane.btnselfAPL;
	this.menupane.btnselfOK = CPBox:new()
	:init("this.menupane.btnselfOK-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:movetext(0, 6)
	:textpos("center")
	:text("OK")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	:attach(this.menupane.btnpane, math.ceil((this.pw/2)), lcButtonspace, math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace))), lcButtonspace);
	this.menupane.btnselfOK:makeBranch(this.menupane);
	this.menupane.btnselfOK.wobj = this;
	this.menupane.btnselfOK.btnbox = btnbox;
	this.btnselfOK = this.menupane.btnselfOK;
end;
makeItem = function(this,btnbox,i,c)
	local pressSwitch = pressSwitch
	local proptype = type(this.value);
	if proptype == "string" then
		this.setitem[i] = this:textEditBox(btnbox,this.prop,this.value,i,c);
	elseif proptype == "number" then
		this.setitem[i] = this:arrowsNumberBox(btnbox,this.prop,this.value,i,c);
	elseif proptype == "boolean" then
		this.setitem[i] = this:yesNoBox(btnbox,this.prop,this.value,i,c);
	elseif proptype == "table" then
		local listpnt
		if c then
			listpnt = this.menutab.argTbl[i][this.prop]
		else
			listpnt = this.menutab[this.prop]
		end
		if listpnt.valuelist then
			this.setitem[i] = this:choiceBox(btnbox,this.prop,this.value,i,c);
		elseif listpnt.choicelist then
			this.setitem[i] = this:multiChoiceBox(btnbox,this.prop,this.value,i,c);
		elseif listpnt.maxv then
			this.setitem[i] = this:minMaxBox(btnbox,this.prop,this.value,i,c);
		else
			this.setitem[i] = this:multiValBox(btnbox,this.prop,this.value,i,c);
		end;
	end;
	local winact = true
	if this.mvrType == "holey" then
		winact = false
	end
	this.setitem[i].menuline:active(winact)
	this.setitem[i].menuline.mover = true
	this.setitem[i].menuline.mvrType = this.mvrType
	this.setitem[i].menuline.wobj = this
	this.setitem[i].menuline.Action = (function()
		return
		function(this)
			if this.mvrType == "movable" then
				this.wobj.ActionMP(this.wobj.menupane)
			end
		end
	end) ();
	this.setitem[i].menuline.Customdraw = function(this)
		pressSwitch(this)
	end;
	return this.setitem[i];
end;
textEditBox = function(this, btnbox, prop, value,i,c)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonheight = msgButtonheight;
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local getsetuphi = getsetuphi
	local stretchmenu = stretchmenu
	local ms070autoScanOn = ms070autoScanOn
	local ms136externInput = ms136externInput
	local externInput = externInput
	local metapnt, mnpnt
	local separator = string.find(prop,"< separator >")
	if c then
		metapnt = this.metatab.argTbl[i]
		mnpnt = this.menutab.argTbl[i]
	else
		metapnt = this.metatab
		mnpnt = this.menutab
	end;
	local txtEdBox={};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	:text(getsetuphi(prop,metapnt))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.menuline:attach(this.menupane, this.maxmtitemv + (this.propbari[c]+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	elseif separator then
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
		this.menupane.menuline:textpos("center")
		this.menupane.menuline:text(tostring(value))
	else
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	if not separator then
		this.menupane.editbox = CPBox:new()
		:init("this.menupane.editbox-"..tostring(i), 0, 0, 0, 0)
		:bordercolor(cpbormenue)
		:fillcolor(cpfillmenue)
		:textfont(cpfntmenu)
		:textcolor(cpcolmenue)
		:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
		:textpos("left")
		:text("value")
		:editable(true)
		:movable(false)
		:clickable(false)
		:active(true)
		:visible(true)
		if c then
			if prop == "zcmdfreecmd" then
			this.menupane.editbox:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
			else
			this.menupane.editbox:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),this.argbarv[c], (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
			end
		else
			this.menupane.editbox:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
		end;
		this.menupane.editbox:makeBranch(this);
		this.menupane.editbox.wobj = this;
		this.menupane.editbox.menutab = mnpnt
		this.menupane.editbox.metatab = metapnt
		this.menupane.editbox.prop = prop;
		this.menupane.editbox.menuline = this.menupane.menuline;
		if c then
			this.menupane.editbox.wobj.maxitemv = this.maxmtitemv
		end;
		this.menupane.editbox.Customdraw = function(this)
			if this.Highlight then
				if ms136externInput and not this.extinp then
					this.Text = externInput();
					this.extinp = true
				else
					this.menuline:textcolor(cpfntcolhghlt);
					if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
					if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
						if this.wobj.setitem[i].scanbox then
							if this.Text ~= "" then
								if this.wobj.setitem[i].scanbox.Text ~= "x" then
									this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
								end;
							else
								if this.wobj.setitem[i].scanbox.Text == "x" then
									this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
								end;
							end;
						end;
					end;
					stretchmenu(this,c)
				end
			else
				this.menuline:textcolor(cpcolmenul);
				if this.ch == "C-m" or this.ch == "\r" then
					this.menutab[this.prop] = this.Text;
					this.ch = nil;
				else
					this.Text = this.menutab[this.prop];
				end;
				if this.Text == "< click to edit >" or this.Text == "< error >" then
					this.Text = "";
				end;
				this.extinp = false
			end;
		end;
	end
	txtEdBox.menuline = this.menupane.menuline;
	txtEdBox.editbox = this.menupane.editbox or {};
	return txtEdBox;
end;
arrowsNumberBox = function(this, btnbox, prop, value,i,c)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local stretchmenu = stretchmenu
	local getheight = getheight
	local getmvalinc = getmvalinc
	local getmvalminmax = getmvalminmax
	local getsetuphi = getsetuphi
	local ms070autoScanOn = ms070autoScanOn
	local ms136externInput = ms136externInput
	local externInput = externInput
	local metapnt, mnpnt
	local math_dround = math_dround
	local t_num = tonumber
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	if c then
		metapnt = this.metatab.argTbl[i]
		mnpnt = this.menutab.argTbl[i]
	else
		metapnt = this.metatab
		mnpnt = this.menutab
	end;
	local arrNumBox={};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	this.menupane.menuline:text(getsetuphi(prop,metapnt))
	this.menupane.menuline:movable(false)
	this.menupane.menuline:clickable(false)
	this.menupane.menuline:active(true)
	this.menupane.menuline:visible(true)
	if c then
		this.menupane.menuline:attach(this.menupane, this.maxmtitemv + (this.propbari[c]+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	this.menupane.menuline.hitext = getsetuphi(prop,metapnt);
	this.menupane.menuline.showunits = function(this, finder)
		if finder.unitmeta and finder.unitmeta[prop] then
			local unittext = finder.unitmeta[prop].valuelist[finder.unitmeta[prop].metaindx]
			if unittext ~= "" then
				this:text(this.hitext.." ["..unittext.."]");
			else
				this:text(this.hitext);
			end;
		end;
	end;
	local dumincfnc = function(val,x)
		return val
	end;
	local unitinc
	if this.finder then
		if this.finder.unittable[prop] then
			unitinc = this.finder.unittable[prop][1]
		else
			unitinc = dumincfnc
		end;
	else
		unitinc = dumincfnc
	end;
	this.menupane.editbox = CPBox:new()
	:init("this.menupane.editbox-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("value")
	:editable(true)
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.editbox:attach(this.menupane, this.maxmtitemv +  (this.argbari[c]+(lcButtonspace+lcButtonsize)), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),this.argbarv[c]+(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox:attach(this.menupane, this.maxitemi+lcButtonsize+2*lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonsize+2*lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox:makeBranch(this);
	this.menupane.editbox.menuline = this.menupane.menuline;
	this.menupane.editbox.menutab = mnpnt
	this.menupane.editbox.metatab = metapnt
	this.menupane.editbox.prop = prop;
	this.menupane.editbox.wobj = this;
	this.menupane.editbox.left = CPBox:new()
	:init("this.menupane.editbox.left"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("<")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.editbox.left:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]-lcButtonsize, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox.left:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv-(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox.left:makeBranch(this);
	this.menupane.editbox.left.menuline = this.menupane.editbox.menuline;
	this.menupane.editbox.left.metatab = metapnt
	this.menupane.editbox.left.menutab = mnpnt
	this.menupane.editbox.left.prop = prop;
	this.menupane.editbox.left.wobj = this;
	this.menupane.editbox.left.unitinc = unitinc;
	this.menupane.editbox.left.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.menutab[this.prop] = this.menutab[this.prop] - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end;
			end;
		end
	end) ();
	this.menupane.editbox.left.Customdraw = function(this)
		local arrowdelay, timerrand
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.menutab[this.prop] = this.menutab[this.prop] - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.menupane.editbox.right = CPBox:new()
	:init("this.menupane.editbox.right"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text(">")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.editbox.right:attach(this.menupane, (this.pw-this.argbarv[c])-(lcButtonsize), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.argbarv[c], (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox.right:attach(this.menupane, this.pw-(lcButtonspace+lcButtonsize), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox.right:makeBranch(this);
	this.menupane.editbox.right.menuline = this.menupane.editbox.menuline;
	this.menupane.editbox.right.metatab = metapnt
	this.menupane.editbox.right.menutab = mnpnt
	this.menupane.editbox.right.prop = prop;
	this.menupane.editbox.right.wobj = this;
	this.menupane.editbox.right.unitinc = unitinc;
	this.menupane.editbox.right.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.menutab[this.prop] = this.menutab[this.prop] + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end
			end;
		end
	end) ();
	this.menupane.editbox.right.Customdraw = function(this)
		local arrowdelay, timerrand
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.menutab[this.prop] = this.menutab[this.prop] + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.menupane.editbox.Customdraw = function(this)
		local finder = this.wobj.finder or {};
		this.menuline:showunits(finder);
		if this.Highlight then
			if not this.boxedited then
				if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
					this.Text =  finder.unittable[this.prop][1](this.menutab[this.prop],"fromnative");
				else
					this.Text = this.menutab[this.prop]
				end
				this.boxedited = true;
			end
			if ms136externInput and not this.extinp then
				this.Text = externInput();
				this.extinp = true
			else
				this.menuline:textcolor(cpfntcolhghlt);
				if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
				if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
					if this.wobj.setitem[i].scanbox then
						if this.wobj.setitem[i].scanbox.Text ~= "x" then
							this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
						end;
					end;
				end;
				stretchmenu(this,c)
			end
			this.actval = nil;
		else
			this.menuline:textcolor(cpcolmenul);
			this.actval = this.actval or this.Text
			if this.boxedited then
				this.boxedited = false;
			end
			if this.ch == "C-m" then
				if t_num(this.actval) == nil then
					this.actval = string.gsub(this.actval,",",".");
				end;
				if t_num(this.actval) == nil then
					this.actval = string.gsub(this.actval,"%.",",");
				end;
				if this.actval == "1,#INF" then this.actval = math.huge; end;
				if this.actval == "-1,#INF" then this.actval = -math.huge; end;
				if t_num(this.actval) ~= nil then
					if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
						this.menutab[this.prop] = finder.unittable[this.prop][1](t_num(this.actval),"tonative");
					else
						this.menutab[this.prop] = t_num(this.actval);
					end;
					this.ch = nil;
				else
					this.actval = this.menutab[this.prop];
				end;
			else
				if mnpnt[this.prop] < getmvalinc(this.prop,metapnt)*0.01 and  mnpnt[this.prop] > -getmvalinc(this.prop,metapnt)*0.01 then
					mnpnt[this.prop] = 0;
				end;
				local minlmt,maxlmt = getmvalminmax(this.prop,metapnt);
				if mnpnt[this.prop] <= minlmt then mnpnt[this.prop] = minlmt; end;
				if mnpnt[this.prop] >= maxlmt then mnpnt[this.prop] = maxlmt; end;
				if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
					this.actval =  finder.unittable[this.prop][1](this.menutab[this.prop],"fromnative");
				else
					this.actval = mnpnt[this.prop];
				end;
			end;
			this.Text =  math_dround(this.actval,finder.decplac)
			this.extinp = false
		end;
	end;
	arrNumBox.menuline = this.menupane.menuline;
	arrNumBox.editbox = this.menupane.editbox;
	return arrNumBox;
end;
minMaxBox = function(this, btnbox, prop, value,i)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local stretchmenu = stretchmenu
	local getheight = getheight
	local getmvalinc = getmvalinc
	local getmvalminmax = getmvalminmax
	local getsetuphi = getsetuphi
	local ms070autoScanOn = ms070autoScanOn
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	local ms136externInput = ms136externInput
	local lifeval = (string.sub(prop,7,14) == "lifespan")
	local t_num = tonumber;
	local ms136externInput = ms136externInput
	local externInput = externInput
	local math_dround = math_dround
	local minMaxBox={};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	:text(getsetuphi(prop,this.metatab))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	this.menupane.menuline.hitext = getsetuphi(prop,this.metatab);
	this.menupane.menuline.showunits = function(this, finder)
		if finder.unitmeta and finder.unitmeta[prop] then
			local unittext = finder.unitmeta[prop].valuelist[finder.unitmeta[prop].metaindx]
			if unittext ~= "" then
				this:text(this.hitext.." ["..unittext.."]");
			else
				this:text(this.hitext);
			end;
		end;
	end;
	local dumincfnc = function(val,x)
		return val
	end;
	local unitinc
	if this.finder then
		if this.finder.unittable[prop] and not lifeval then
			unitinc = this.finder.unittable[prop][1]
		else
			unitinc = dumincfnc
		end;
	else
		unitinc = dumincfnc
	end;
	this.menupane.editboxMin = CPBox:new()
	:init("this.menupane.editboxMin-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("value")
	:editable(true)
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, this.maxitemi+lcButtonsize+2*lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), (this.maxitemv*0.5)+(3*lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.editboxMin:makeBranch(this);
	this.menupane.editboxMin.menuline = this.menupane.menuline;
	this.menupane.editboxMin.menutab = this.menutab;
	this.menupane.editboxMin.metatab = this.metatab;
	this.menupane.editboxMin.prop = prop;
	this.menupane.editboxMin.wobj = this;
	this.menupane.editboxMin.left = CPBox:new()
	:init("this.menupane.editboxMin.left"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("<")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv-(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.editboxMin.left:makeBranch(this);
	this.menupane.editboxMin.left.menuline = this.menupane.editboxMin.menuline;
	this.menupane.editboxMin.left.metatab = this.metatab;
	this.menupane.editboxMin.left.menutab = this.menutab;
	this.menupane.editboxMin.left.prop = prop;
	this.menupane.editboxMin.left.wobj = this;
	this.menupane.editboxMin.left.unitinc = unitinc
	this.menupane.editboxMin.left.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.menutab[this.prop].minv = this.menutab[this.prop].minv - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end;
			end;
		end
	end) ();
	this.menupane.editboxMin.left.Customdraw = function(this)
		local arrowdelay, timerrand
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.menutab[this.prop].minv = this.menutab[this.prop].minv - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.menupane.editboxMin.right = CPBox:new()
	:init("this.menupane.editboxMin.right"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text(">")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, (this.maxitemi)+((this.maxitemv*0.5)-(2*lcButtonspace+lcButtonsize)), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), (this.maxitemv*0.5)+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.editboxMin.right:makeBranch(this);
	this.menupane.editboxMin.right.menuline = this.menupane.editboxMin.menuline;
	this.menupane.editboxMin.right.metatab = this.metatab;
	this.menupane.editboxMin.right.menutab = this.menutab;
	this.menupane.editboxMin.right.prop = prop;
	this.menupane.editboxMin.right.wobj = this;
	this.menupane.editboxMin.right.unitinc = unitinc
	this.menupane.editboxMin.right.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.menutab[this.prop].minv = this.menutab[this.prop].minv + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end;
			end;
		end
	end) ();
	this.menupane.editboxMin.right.Customdraw = function(this)
		local arrowdelay, timerrand
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.menutab[this.prop].minv = this.menutab[this.prop].minv + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.menupane.editboxMin.Customdraw = function(this)
		local finder = this.wobj.finder or {};
		this.menuline:showunits(finder);
		if this.Highlight then
			if not this.boxedited then
				if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
					this.Text =  finder.unittable[this.prop][1](this.menutab[this.prop].minv,"fromnative");
				else
					this.Text = this.menutab[this.prop].minv
				end
				this.boxedited = true;
			end
			if ms136externInput and not this.extinp then
				this.Text = externInput();
				this.extinp = true
			else
				this.menuline:textcolor(cpfntcolhghlt);
				if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
				if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
					if this.wobj.setitem[i].scanbox then
						if this.wobj.setitem[i].scanbox.Text ~= "x" then
							this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
						end;
					end;
				end;
				stretchmenu(this,false)
			end
			this.actval = nil;
		else
			this.menuline:textcolor(cpcolmenul);
			this.actval = this.actval or this.Text
			if this.boxedited then
				this.boxedited = false;
			end
			if this.ch == "C-m" then
				if t_num(this.actval) == nil then
					this.actval = string.gsub(this.actval,",",".");
				end;
				if t_num(this.actval) == nil then
					this.actval = string.gsub(this.actval,"%.",",");
				end;
				if this.actval == "1,#INF" then this.actval = math.huge; end;
				if this.actval == "-1,#INF" then this.actval = -math.huge; end;
				if t_num(this.actval) ~= nil then
					if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
						this.menutab[this.prop].minv = finder.unittable[this.prop][1](t_num(this.actval),"tonative");
					else
						this.menutab[this.prop].minv = t_num(this.actval);
					end;
				else
					if lifeval then
						this.actval = finder.unittable[this.prop][1](this.actval,"tonative");
						if t_num(this.actval) then
							this.menutab[this.prop].minv = t_num(this.actval);
						end
					else
						this.actval =  this.menutab[this.prop].minv ;
					end;
				end;
				this.ch = nil;
			else
				if this.menutab[this.prop].minv < getmvalinc(this.prop,this.metatab)*0.01 and  this.menutab[this.prop].minv > -getmvalinc(this.prop,this.metatab)*0.01 then
					this.menutab[this.prop].minv = 0;
				end;
				local minlmt,maxlmt = getmvalminmax(this.prop,this.metatab);
				if this.menutab[this.prop].minv <= minlmt then this.menutab[this.prop].minv = minlmt; end;
				if this.menutab[this.prop].minv >= maxlmt then this.menutab[this.prop].minv = maxlmt; end;
				if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
					this.actval =  finder.unittable[this.prop][1](this.menutab[this.prop].minv,"fromnative");
				else
					this.actval =  this.menutab[this.prop].minv ;
				end;
			end;
			if lifeval then
				this.Text =  this.actval
			else
				this.Text =  math_dround(this.actval,finder.decplac)
			end
			this.extinp = false;
		end;
	end;
	this.menupane.editboxMax = CPBox:new()
	:init("this.menupane.editboxMax-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("value")
	:editable(true)
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, this.maxitemi+lcButtonsize+2*lcButtonspace+(this.maxitemv*0.5), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonsize+2*lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.editboxMax:makeBranch(this);
	this.menupane.editboxMax.menuline = this.menupane.menuline;
	this.menupane.editboxMax.menutab = this.menutab;
	this.menupane.editboxMax.metatab = this.metatab;
	this.menupane.editboxMax.prop = prop;
	this.menupane.editboxMax.wobj = this;
	this.menupane.editboxMax.left = CPBox:new()
	:init("this.menupane.editboxMax.left"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("<")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, this.maxitemi+(0.5*this.maxitemv), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), (this.maxitemv*0.5)-(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.editboxMax.left:makeBranch(this);
	this.menupane.editboxMax.left.menuline = this.menupane.editboxMax.menuline;
	this.menupane.editboxMax.left.metatab = this.metatab;
	this.menupane.editboxMax.left.menutab = this.menutab;
	this.menupane.editboxMax.left.prop = prop;
	this.menupane.editboxMax.left.wobj = this;
	this.menupane.editboxMax.left.unitinc = unitinc
	this.menupane.editboxMax.left.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.menutab[this.prop].maxv = this.menutab[this.prop].maxv - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end;
			end;
		end
	end) ();
	this.menupane.editboxMax.left.Customdraw = function(this)
		local arrowdelay, timerrand
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.menutab[this.prop].maxv = this.menutab[this.prop].maxv - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.menupane.editboxMax.right = CPBox:new()
	:init("this.menupane.editboxMax.right"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text(">")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, this.pw-(lcButtonspace+lcButtonsize), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.editboxMax.right:makeBranch(this);
	this.menupane.editboxMax.right.menuline = this.menupane.editboxMax.menuline;
	this.menupane.editboxMax.right.metatab = this.metatab;
	this.menupane.editboxMax.right.menutab = this.menutab;
	this.menupane.editboxMax.right.prop = prop;
	this.menupane.editboxMax.right.wobj = this;
	this.menupane.editboxMax.right.unitinc = unitinc
	this.menupane.editboxMax.right.Action = (function()
		return
		function(this)
			if this.arwtimer then
				this.arwtimer.status = "kill";
				this.arwtimer = nil;
			end
			this.xdone = nil;
			this.menutab[this.prop].maxv = this.menutab[this.prop].maxv + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end;
			end;
		end
	end) ();
	this.menupane.editboxMax.right.Customdraw = function(this)
		local arrowdelay, timerrand
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
			if this.xdone == nil then
				this.xdone = true;
				arrowdelay=ldelay1;
			else
				arrowdelay=ldelay2;
			end;
			if not this.arwtimer then
				timerrand=tostring(math.random());
				this.arwtimer = CPtimer:new({tCelPad.Timers})
				this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
				function(o)
					if this.Pressed then
						this.menutab[this.prop].maxv = this.menutab[this.prop].maxv + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
						this.xdone = true;
					else
						this.xdone = nil;
					end
					this.arwtimer = nil;
				end
				);
				this.arwtimer:makeBranch(ControlPanel)
			end;
		end;
	end;
	this.menupane.editboxMax.Customdraw = function(this)
		local finder = this.wobj.finder or {};
		if this.Highlight then
			if not this.boxedited then
				if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
					this.Text =  finder.unittable[this.prop][1](this.menutab[this.prop].maxv,"fromnative");
				else
					this.Text = this.menutab[this.prop].maxv
				end
				this.boxedited = true;
			end
			if ms136externInput and not this.extinp then
				this.Text = externInput();
				this.extinp = true
			else
				this.menuline:textcolor(cpfntcolhghlt);
				if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
				if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
					if this.wobj.setitem[i].scanbox then
						if this.wobj.setitem[i].scanbox.Text ~= "x" then
							this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
						end;
					end;
				end;
				stretchmenu(this,false)
			end
			this.actval = nil;
		else
			this.actval = this.actval or this.Text
			if this.boxedited then
				this.boxedited = false;
			end
			if this.ch == "C-m" then
				if t_num(this.actval) == nil then
					this.actval = string.gsub(this.actval,",",".");
				end;
				if t_num(this.actval) == nil then
					this.actval = string.gsub(this.actval,"%.",",");
				end;
				if this.actval == "1,#INF" then this.actval = math.huge; end;
				if this.actval == "-1,#INF" then this.actval = -math.huge; end;
				if t_num(this.actval) ~= nil then
					if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
						this.menutab[this.prop].maxv = finder.unittable[this.prop][1](t_num(this.actval),"tonative");
					else
						this.menutab[this.prop].maxv = t_num(this.actval);
					end;
				else
					if lifeval then
						this.actval =  finder.unittable[this.prop][1](this.actval,"tonative");
						if t_num(this.actval) then
							this.menutab[this.prop].maxv = t_num(this.actval);
						end
					else
						this.actval =  this.menutab[this.prop].maxv;
					end;
				end;
				this.ch = nil;
			else
				if this.menutab[this.prop].maxv < getmvalinc(this.prop,this.metatab)*0.01 and  this.menutab[this.prop].maxv > -getmvalinc(this.prop,this.metatab)*0.01 then
					this.menutab[this.prop].maxv = 0;
				end;
				local minlmt,maxlmt,minlmt2,maxlmt2  = getmvalminmax(this.prop,this.metatab);
				if this.menutab[this.prop].maxv <= minlmt2 then this.menutab[this.prop].maxv = minlmt2; end;
				if this.menutab[this.prop].maxv >= maxlmt2 then this.menutab[this.prop].maxv = maxlmt2; end;
				local lcminv = this.menutab[this.prop].minv
				if this.menutab[this.prop].maxv <= lcminv then this.menutab[this.prop].maxv = lcminv; end;
				if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
					this.actval =  finder.unittable[this.prop][1](this.menutab[this.prop].maxv,"fromnative");
				else
					this.actval =  this.menutab[this.prop].maxv;
				end;
			end;
			if lifeval then
				this.Text =  this.actval
			else
				this.Text =  math_dround(this.actval,finder.decplac)
			end
			this.extinp = false;
		end;
	end;
	minMaxBox.menuline = this.menupane.menuline;
	minMaxBox.editboxMin = this.menupane.editboxMin;
	minMaxBox.editboxMax = this.menupane.editboxMax;
	return minMaxBox;
end;
choiceBox = function(this, btnbox, prop, value,i,c)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local getheight = getheight
	local getsetuphi = getsetuphi
	local ms070autoScanOn = ms070autoScanOn
	local metapnt, mnpnt
	if c then
		metapnt = this.metatab.argTbl[i]
		mnpnt = this.menutab.argTbl[i]
	else
		metapnt = this.metatab
		mnpnt = this.menutab
	end;
	local chBox = {};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	:text(getsetuphi(prop,metapnt))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.menuline:attach(this.menupane, this.maxmtitemv + (this.propbari[c]+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	this.menupane.editbox = CPBox:new()
	:init("this.menupane.editbox-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text(mnpnt[prop][1])
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	if c then
		this.menupane.editbox:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),this.argbarv[c], (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox:makeBranch(this);
	this.menupane.editbox.menutabvl = mnpnt[prop]
	this.menupane.editbox.metatabvl = metapnt[prop]
	this.menupane.editbox.menuline = this.menupane.menuline;
	this.menupane.editbox.wobj = this;
	this.menupane.editbox.lnum = i;
	this.menupane.editbox.menutab = mnpnt
	this.menupane.editbox.metatab = metapnt
	this.menupane.editbox.prop = prop;
	this.menupane.editbox.Action = (function()
		return
		function(this)
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.Parent.Hiding and this.Parent.onborder ~= 0 then
				this.Parent.Hiding = false;
			else
				this:valueList(this.menutabvl, this.metatabvl, this.menuline);
			end;
		end
	end) ();
	this.menupane.editbox.Customdraw = function(this)
		if this.metatab[prop] and this.metatab[prop].valuelist then
			for i,v in ipairs(this.menutab[prop].valuelist) do
				if v == this.menutab[prop][1] then
					this.Text = this.metatab[prop].valuelist[i] or this.menutab[this.prop][1];
					this.metatab[prop].metaindx=i;
				end;
			end;
		else
			this.Text = this.menutab[this.prop][1];
		end;
	end;
	this.menupane.editbox.valueList = function(this, menutabvl, metatabvl, menuline)
		local posindex = 0;
		local maxindex = table.maxn(menutabvl.valuelist);
		for i,v in ipairs(menutabvl.valuelist) do
			if menutabvl[1]==v then posindex = i; end;
		end;
		if posindex == 0 then CPlog("CelPad: MISSING VALUE!!!, should DIE!!!"); end;
		this.wba = -lcButtonspace+(this.Parent.ba+this.ba)-(lcButtonsize+lcButtonspace)*(maxindex-posindex);
		this.wta = -lcButtonspace+(this.Parent.ta+this.ta)-(lcButtonsize+lcButtonspace)*(posindex-1);
		if this.wba < 5 then
			posindex = maxindex;
		end;
		if this.wta < 5 then
			posindex = 1;
		end;
		this.vallist = CPBox:new()
		this.vallist:init("vallist", 0, 0, 0, 0)
		this.vallist:bordercolor(cpborvlist)
		this.vallist:fillcolor(cpfillvlist)
		this.vallist:movable(false)
		this.vallist:clickable(false)
		this.vallist:active(false)
		this.vallist:visible(true)
		this.vallist:attach(screenBox, this.Parent.la+this.la, -lcButtonspace+(this.Parent.ba+this.ba)-(lcButtonsize+lcButtonspace)*(maxindex-posindex), this.Parent.ra+this.ra, -lcButtonspace+(this.Parent.ta+this.ta)-(lcButtonsize+lcButtonspace)*(posindex-1));
		this.vallist:makeBranch(this);
		this.vallist.menuline = menuline;
		menuline:textcolor(cpfntcolhghlt);
		this.wobj:makePopShadow(this.vallist,true);
		for i,v in ipairs(menutabvl.valuelist) do
			this.valitem = CPBox:new()
			:init("valitem", 0, 0, 0, 0)
			:bordercolor(cpbormenue)
			:fillcolor(cpfillmenue)
			:textfont(cpfntmenu)
			:textcolor(cpcolmenue)
			:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
			:textpos("center")
			:text(tostring(menutabvl.valuelist[i]) or "nometa")
			:movable(false)
			:clickable(false)
			:active(true)
			:visible(true)
			:attach(this.vallist, lcButtonspace, lcButtonspace+(maxindex-i)*(lcButtonsize+lcButtonspace), lcButtonspace, lcButtonspace+(i-1)*(lcButtonsize+lcButtonspace));
			this.valitem:makeBranch(this.vallist);
			if metatabvl and metatabvl.valuelist then
				this.valitem:text(metatabvl.valuelist[i]);
			end;
			this.valitem.value = menutabvl.valuelist[i];
			this.valitem.box = this
			this.selected = nil
			this.valitem.Action  = (function()
				return
				function(this)
					menutabvl[1]=this.value;
					if myCelPad.openSetTimer and this.box.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
					if this.box.wobj.objtype == "queryMenu" and ms070autoScanOn then
						if this.box.wobj.setitem[this.box.lnum].scanbox then
							if this.box.wobj.setitem[this.box.lnum].scanbox.Text ~= "x" then
								this.box.wobj.setitem[this.box.lnum].scanbox.Action(this.box.wobj.setitem[this.box.lnum].scanbox)
							end;
						end;
					end;
					this.Parent.menuline:textcolor(cpcolmenul);
					this.Parent:destruct();
					this.box.selected = this.value
				end
			end) ();
		end;
		this.vallist.Customdraw = function(this)
			local mxatt, psatt = this:getfrontpos();
			if (mxatt - psatt) > 1  then
				this.menuline:textcolor(cpcolmenul);
				this:destruct();
			end;
		end;
	end;
	chBox.menuline = this.menupane.menuline;
	chBox.editbox = this.menupane.editbox;
	return chBox;
end;
yesNoBox = function(this, btnbox, prop, value,i,c)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local getheight = getheight
	local getsetuphi = getsetuphi
	local ms070autoScanOn = ms070autoScanOn
	local metapnt, mnpnt
	if c then
		metapnt = this.metatab.argTbl[i]
		mnpnt = this.menutab.argTbl[i]
	else
		metapnt = this.metatab
		mnpnt = this.menutab
	end;
	local ynBox = {};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	:text(getsetuphi(prop,metapnt))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.menuline:attach(this.menupane, this.maxmtitemv + (this.propbari[c]+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	this.menupane.editbox = CPBox:new()
	:init("this.menupane.editbox-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text("YES/NO")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.editbox:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),this.argbarv[c], (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox:makeBranch(this);
	this.menupane.editbox.wobj = this;
	this.menupane.editbox.menuline = this.menupane.menuline;
	this.menupane.editbox.menutab = mnpnt
	this.menupane.editbox.metatab = metapnt
	this.menupane.editbox.prop = prop;
	this.menupane.editbox.Customdraw = function(this)
		if this.Pressed then
			this.menuline:textcolor(cpfntcolhghlt);
		else
			this.menuline:textcolor(cpcolmenul);
		end;
		if this.menutab[this.prop] == true then
			this.Text = "YES";
		else
			this.Text = "NO";
		end;
	end;
	this.menupane.editbox.Action = (function()
		return
		function(this)
			this.menutab[this.prop] = not this.menutab[this.prop];
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.wobj.objtype == "queryMenu"	and ms070autoScanOn then
				if this.wobj.setitem[i].scanbox then
					if this.wobj.setitem[i].scanbox.Text ~= "x" then
						this.wobj.setitem[i].scanbox.Action(this.wobj.setitem[i].scanbox)
					end;
				end;
			end;
		end
	end) ();
	ynBox.menuline = this.menupane.menuline;
	ynBox.editbox = this.menupane.editbox;
	return ynBox;
end;
multiValBox = function(this, btnbox, prop, value,i,c)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local getheight = getheight
	local getmvalinc = getmvalinc
	local getmvalminmax = getmvalminmax
	local getsetuphi = getsetuphi
	local ms070autoScanOn = ms070autoScanOn
	local metapnt, mnpnt
	local ms136externInput = ms136externInput
	local externInput = externInput
	local math_dround = math_dround
	local t_num = tonumber
	if c then
		metapnt = this.metatab.argTbl[i]
		mnpnt = this.menutab.argTbl[i]
	else
		metapnt = this.metatab
		mnpnt = this.menutab
	end;
	local ldelay1, ldelay2 = mtBtnDelay1, mtBtnDelay2;
	local mltValBox = {};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	:text(getsetuphi(prop,metapnt))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.menuline:attach(this.menupane, this.maxmtitemv + (this.propbari[c]+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	this.menupane.menuline.hitext = getsetuphi(prop,metapnt);
	this.menupane.menuline.showunits = function(this, finder)
		if finder.unitmeta and finder.unitmeta[prop] then
			local unittext = finder.unitmeta[prop].valuelist[finder.unitmeta[prop].metaindx]
			if unittext ~= "" then
				this:text(this.hitext.." ["..unittext.."]");
			else
				this:text(this.hitext);
			end;
		end;
	end;
	local dumincfnc = function(val,x)
		return val
	end;
	local unitinc
	if this.finder then
		this.menupane.menuline.finder = this.finder
		if this.finder.unittable[prop] then
			unitinc = this.finder.unittable[prop][1]
		else
			unitinc = dumincfnc
		end;
	else
		unitinc = dumincfnc
	end;
	this.menupane.editbox = CPBox:new()
	:init("this.menupane.editbox-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	this.menupane.editbox:text(mnpnt[prop][1])
	this.menupane.editbox:movable(false)
	this.menupane.editbox:clickable(false)
	this.menupane.editbox:active(true)
	this.menupane.editbox:visible(true)
	this.menupane.editbox:menuitem(true)
	if c then
		this.menupane.editbox:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),this.argbarv[c], (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox:makeBranch(this);
	this.menupane.editbox.menutabvl = mnpnt[prop]
	this.menupane.editbox.menutab = mnpnt
	this.menupane.editbox.metatab = metapnt
	this.menupane.editbox.menuline = this.menupane.menuline;
	this.menupane.editbox.wobj = this;
	this.menupane.editbox.lnum = i;
	this.menupane.editbox.prop = prop;
	this.menupane.editbox.menuname = this.objname;
	this.menupane.editbox.Action = (function()
		return
		function(this)
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.Parent.Hiding and this.Parent.onborder ~= 0 then
				this.Parent.Hiding = false;
			else
				this:valueList(this.menutabvl, this.menuline);
			end;
		end
	end) ();
	this.menupane.editbox.Customdraw = function(this)
		local finder = this.menuline.finder or {};
		this.menuline:showunits(finder);
		local ex,ey = this:size()
		local txtstr = "";
		for i,v in ipairs(this.menutab[this.prop]) do
			if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
				v = finder.unittable[this.prop][1](t_num(v),"fromnative");
			else
				v = t_num(v);
			end;
			v = math_dround(v,finder.decplac)
			if i == #this.menutab[this.prop] then
				txtstr = txtstr..v;
			else
				txtstr = txtstr..v.."; ";
			end;
			local txtsw = getTxtChars(txtstr,ex,lcButtonsize)
			if cpgetwidth(cpfntmenu,txtstr) > ex then
				this.Text = string.sub(txtstr,1,txtsw-3).."...";
			else
				this.Text = string.sub(txtstr,1,txtsw);
			end;
		end;
	end;
	this.menupane.editbox.valueList = function(this, menutabvl, menuline)
		local maxindex = table.maxn(menutabvl);
		local posindex = math.ceil(maxindex/2);
		this.wba = -lcButtonspace+(this.Parent.ba+this.ba)-(lcButtonsize+lcButtonspace)*(maxindex-posindex);
		this.wta = -lcButtonspace+(this.Parent.ta+this.ta)-(lcButtonsize+lcButtonspace)*(posindex-1);
		if this.wba < 5 then
			posindex = maxindex;
		end;
		if this.wta < 5 then
			posindex = 1;
		end;
		this.vallist = CPBox:new()
		this.vallist:init("vallist", 0, 0, 0, 0)
		this.vallist:bordercolor(cpborvlist)
		this.vallist:fillcolor(cpfillvlist)
		this.vallist:movable(false)
		this.vallist:clickable(false)
		this.vallist:active(false)
		this.vallist:visible(true)
		this.vallist:attach(screenBox, this.Parent.la+this.la, -lcButtonspace+(this.Parent.ba+this.ba)-(lcButtonsize+lcButtonspace)*(maxindex-posindex), this.Parent.ra+this.ra, -lcButtonspace+(this.Parent.ta+this.ta)-(lcButtonsize+lcButtonspace)*(posindex-1));
		this.vallist:makeBranch(this);
		this.vallist.menuline = menuline;
		menuline:textcolor(cpfntcolhghlt);
		this.wobj:makePopShadow(this.vallist,true);
		this.valitem = this.valitem or {};
		this.wobj.valitem = this.valitem
		for iy,v in ipairs(menutabvl) do
			this.valitem[iy] = CPBox:new()
			:init("valitem[iy]"..iy, 0, 0, 0, 0)
			:bordercolor(cpbormenue)
			:fillcolor(cpfillmenue)
			:textfont(cpfntmenu)
			:textcolor(cpcolmenue)
			:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
			:textpos("center")
			:text("value")
			:movable(false)
			:clickable(false)
			:active(true)
			:visible(true)
			:editable(true)
			:attach(this.vallist, 2*lcButtonspace+lcButtonsize, lcButtonspace+(maxindex-iy)*(lcButtonsize+lcButtonspace), 2*lcButtonspace+lcButtonsize, lcButtonspace+(iy-1)*(lcButtonsize+lcButtonspace));
			this.valitem[iy]:makeBranch(this.vallist);
			this.valitem[iy].menutabvl = menutabvl;
			this.valitem[iy].menuline = menuline;
			this.valitem[iy].metatab = metapnt
			this.valitem[iy].wobj = this.wobj;
			this.valitem[iy].vallist = this.vallist
			this.valitem[iy].prop = prop;
			this.valitem[iy].Customdraw = function(this)
				this.wobj.vallist = this.vallist
				local finder = this.wobj.finder or {};
				if this.Highlight then
					if not this.boxedited then
						if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
							this.Text =  finder.unittable[this.prop][1](this.menutabvl[iy],"fromnative");
						else
							this.Text = this.menutabvl[iy]
						end
						this.boxedited = true;
					end
					if ms136externInput and not this.extinp then
						this.Text = externInput();
						this.extinp = true
					else
						if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
						if this.wobj.objtype == "queryMenu" and ms070autoScanOn then
							if this.wobj.setitem[this.lnum].scanbox then
								if this.wobj.setitem[this.lnum].scanbox.Text ~= "x" then
									this.wobj.setitem[this.lnum].scanbox.Action(this.wobj.setitem[this.lnum].scanbox)
								end;
							end;
						end;
						stretchmenu(this,c)
					end
					this.actval = nil;
				else
					this.actval = this.actval or this.Text
					if this.boxedited then
						this.boxedited = false;
					else
						if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
							this.actval =  finder.unittable[this.prop][1](this.menutabvl[iy],"fromnative");
						else
							this.actval =  this.menutabvl[iy] ;
						end;
					end;
					if t_num(this.actval) == nil then
						this.actval = string.gsub(this.actval,",",".");
					end;
					if t_num(this.actval) == nil then
						this.actval = string.gsub(this.actval,"%.",",");
					end;
					if this.actval == "1,#INF" then this.actval = math.huge; end;
					if this.actval == "-1,#INF" then this.actval = -math.huge; end;
					if t_num(this.actval) ~= nil then
						if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
							this.menutabvl[iy] = finder.unittable[this.prop][1](t_num(this.actval),"tonative");
						else
							this.menutabvl[iy] = t_num(this.actval);
						end;
					else
						this.actval =  this.menutabvl[iy] ;
					end;
					if this.ch == "C-m" or this.ch == "\r" then
						this.Parent:destruct();
						this.Parent.menuline:textcolor(cpcolmenul);
					else
						if this.menutabvl[iy] < getmvalinc(this.prop,this.metatab)*0.01 and  this.menutabvl[iy] > -getmvalinc(this.prop,this.metatab)*0.01 then
							this.menutabvl[iy] = 0;
						end;
						local minlmt,maxlmt = getmvalminmax(this.prop,this.metatab);
						if this.menutabvl[iy] <= minlmt then this.menutabvl[iy] = minlmt; end;
						if this.menutabvl[iy] >= maxlmt then this.menutabvl[iy] = maxlmt; end;
						if finder.unittable and finder.unittable[this.prop] and type(finder.unittable[this.prop][1]) ~= "string" then
							this.actval =  finder.unittable[this.prop][1](this.menutabvl[iy],"fromnative");
						else
							this.actval =  this.menutabvl[iy] ;
						end;
					end;
					this.Text =  math_dround(this.actval,finder.decplac)
					this.ch = nil;
					this.extinp = false;
				end;
			end;
			local ex, ey = this:size()
			this.valitem[iy].left = CPBox:new()
			:init("this.menupane.editbox.left"..tostring(iy), 0, 0, 0, 0)
			:bordercolor(cpborarrow)
			:fillcolor(cpfillarrow)
			:textfont(cpfntmenu)
			:textcolor(cpcolarrow)
			:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
			:textpos("center")
			:text("<")
			:movable(false)
			:clickable(false)
			:active(true)
			:visible(true)
			:attach(this.vallist, lcButtonspace, lcButtonspace+(maxindex-iy)*(lcButtonsize+lcButtonspace),ex-(lcButtonsize+lcButtonspace), lcButtonspace+(iy-1)*(lcButtonsize+lcButtonspace));
			this.valitem[iy].left:makeBranch(this.vallist);
			this.valitem[iy].left.menutabvl = menutabvl;
			this.valitem[iy].left.metatab = metapnt
			this.valitem[iy].left.wobj = this;
			this.valitem[iy].left.prop = prop;
			this.valitem[iy].left.unitinc = unitinc;
			this.valitem[iy].left.Action = (function()
				return
				function(this)
					if this.arwtimer then
						this.arwtimer.status = "kill";
						this.arwtimer = nil;
					end
					this.xdone = nil;
					this.menutabvl[iy] = this.menutabvl[iy] - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
					if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
					if this.wobj.objtype == "queryMenu" and ms070autoScanOn then
						if this.wobj.setitem[this.lnum].scanbox then
							if this.wobj.setitem[this.lnum].scanbox.Text ~= "x" then
								this.wobj.setitem[this.lnum].scanbox.Action(this.wobj.setitem[this.lnum].scanbox)
							end;
						end;
					end;
				end
			end) ();
			this.valitem[iy].left.Customdraw = function(this)
				local arrowdelay, timerrand
				if this.Pressed then
					if this.xdone == nil then
						this.xdone = true;
						arrowdelay=ldelay1;
					else
						arrowdelay=ldelay2;
					end;
					if not this.arwtimer then
						timerrand=tostring(math.random());
						this.arwtimer = CPtimer:new({tCelPad.Timers})
						this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
						function(o)
							if this.Pressed then
								this.menutabvl[iy] = this.menutabvl[iy] - this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
								this.xdone = true;
							else
								this.xdone = nil;
							end
							this.arwtimer = nil;
						end
						);
						this.arwtimer:makeBranch(ControlPanel)
					end;
				end;
			end;
			this.valitem[iy].right = CPBox:new()
			:init("this.menupane.editbox.right"..tostring(iy), 0, 0, 0, 0)
			:bordercolor(cpborarrow)
			:fillcolor(cpfillarrow)
			:textfont(cpfntmenu)
			:textcolor(cpcolarrow)
			:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
			:textpos("center")
			:text(">")
			:movable(false)
			:clickable(false)
			:active(true)
			:visible(true)
			:attach(this.vallist, ex-(lcButtonsize+lcButtonspace), lcButtonspace+(maxindex-iy)*(lcButtonsize+lcButtonspace),lcButtonspace, lcButtonspace+(iy-1)*(lcButtonsize+lcButtonspace));
			this.valitem[iy].right:makeBranch(this.vallist);
			this.valitem[iy].right.menutabvl = menutabvl;
			this.valitem[iy].right.metatab = metapnt
			this.valitem[iy].right.wobj = this;
			this.valitem[iy].right.prop = prop;
			this.valitem[iy].right.unitinc = unitinc;
			this.valitem[iy].right.Action = (function()
				return
				function(this)
					if this.arwtimer then
						this.arwtimer.status = "kill";
						this.arwtimer = nil;
					end
					this.xdone = nil;
					this.menutabvl[iy] = this.menutabvl[iy] + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
					if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
					if this.wobj.objtype == "queryMenu" and ms070autoScanOn then
						if this.wobj.setitem[this.lnum].scanbox then
							if this.wobj.setitem[this.lnum].scanbox.Text ~= "x" then
								this.wobj.setitem[this.lnum].scanbox.Action(this.wobj.setitem[this.lnum].scanbox)
							end;
						end;
					end;
				end
			end) ();
			this.valitem[iy].right.Customdraw = function(this)
				local arrowdelay, timerrand
				if this.Pressed then
					if this.xdone == nil then
						this.xdone = true;
						arrowdelay=ldelay1;
					else
						arrowdelay=ldelay2;
					end;
					if not this.arwtimer then
						timerrand=tostring(math.random());
						this.arwtimer = CPtimer:new({tCelPad.Timers})
						this.arwtimer:init("arwtimer","arwtimer:"..timerrand,arrowdelay,"standalone",0,
						function(o)
							if this.Pressed then
									this.menutabvl[iy] = this.menutabvl[iy] + this.unitinc(getmvalinc(this.prop,this.metatab),"tonative");
								this.xdone = true;
							else
								this.xdone = nil;
							end
							this.arwtimer = nil;
						end
						);
						this.arwtimer:makeBranch(ControlPanel)
					end;
				end;
			end;
		end;
		this.vallist.Customdraw = function(this)
			mxatt, psatt = this:getfrontpos();
			if (mxatt - psatt) > 1  then
				this.menuline:textcolor(cpcolmenul);
				this:destruct();
			end;
		end;
	end;
	mltValBox.menuline = this.menupane.menuline;
	mltValBox.editbox = this.menupane.editbox;
	return mltValBox;
end;
multiChoiceBox = function(this, btnbox, prop, value,i,c)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local getheight = getheight
	local getsetuphi = getsetuphi
	local ms070autoScanOn = ms070autoScanOn
	local metapnt, mnpnt
	local getTxtChars = getTxtChars
	local cpgetwidth = cpgetwidth
	if c then
		metapnt = this.metatab.argTbl[i]
		mnpnt = this.menutab.argTbl[i]
	else
		metapnt = this.metatab
		mnpnt = this.menutab
	end;
	local mltChBox = {};
	this.menupane.menuline = CPBox:new()
	:init(tostring(prop), 0, 0, 0, 0)
	:bordercolor(cpbormenul)
	:fillcolor(cpfillmenul)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenul)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("left")
	:text(getsetuphi(prop,metapnt))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	if c then
		this.menupane.menuline:attach(this.menupane, this.maxmtitemv + (this.propbari[c]+lcButtonspace), this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.propbarv[c]+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.menuline:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.maxitemv+lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.menuline:makeBranch(this);
	this.menupane.menuline.quitmenu = function()
		this:quitpopup(btnbox);
	end;
	this.oldvalue = value;
	this.menupane.editbox = CPBox:new()
	:init("this.menupane.editbox-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text(tostring(mnpnt[prop][1]))
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	if c then
		this.menupane.editbox:attach(this.menupane, this.maxmtitemv + this.argbari[c], this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),this.argbarv[c], (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	else
		this.menupane.editbox:attach(this.menupane, this.maxitemi, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), lcButtonspace, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	end;
	this.menupane.editbox:makeBranch(this);
	this.menupane.editbox.menutabvl = mnpnt[prop]
	this.menupane.editbox.metatabvl = metapnt[prop]
	this.menupane.editbox.menuline = this.menupane.menuline;
	this.menupane.editbox.menutab = mnpnt
	this.menupane.editbox.metatab = metapnt
	this.menupane.editbox.wobj = this;
	this.menupane.editbox.lnum = i;
	this.menupane.editbox.prop = prop;
	this.menupane.editbox.Action = (function()
		return
		function(this)
			if myCelPad.openSetTimer and this.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
			if this.Parent.Hiding and this.Parent.onborder ~= 0 then
				this.Parent.Hiding = false;
			else
				this:valueList(this.menutabvl, this.metatabvl, this.menuline);
			end
		end
	end) ();
	this.menupane.editbox.Customdraw = function(this)
		local mchtext = "";
		local ex,ey = this:size()
		for i,v  in ipairs(this.menutab[prop][1]) do
			if v then
				local lntext;
				if this.metatab[prop] and this.metatab[prop].choicelist then
					lntext = this.metatab[prop].choicelist[i]
				else
					lntext = this.menutab[prop].choicelist[i]
				end;
				if i == #this.menutab[this.prop][1] then
					mchtext = mchtext..lntext
				else
					mchtext = mchtext..lntext.."; "
				end;
			end
		end
		if mchtext == "" then mchtext="< no selection >"; end;
		local mchtxtw = getTxtChars(mchtext,ex,lcButtonsize)
		if cpgetwidth(cpfntmenu,mchtext) > ex then
			this.Text = string.sub(mchtext,1,mchtxtw-3).."...";
		else
			this.Text = string.sub(mchtext,1,mchtxtw);
		end;
	end;
	this.menupane.editbox.valueList = function(this, menutabvl, metatabvl, menuline)
		local maxindex = table.maxn(menutabvl.choicelist);
		local posindex = math.ceil(maxindex/2);
		this.wba = -lcButtonspace+(this.Parent.ba+this.ba)-(lcButtonsize+lcButtonspace)*(maxindex-posindex);
		this.wta = -lcButtonspace+(this.Parent.ta+this.ta)-(lcButtonsize+lcButtonspace)*(posindex-1);
		if this.wba < 5 then
			posindex = maxindex;
		end;
		if this.wta < 5 then
			posindex = 1;
		end;
		this.vallist = CPBox:new()
		this.vallist:init("vallist", 0, 0, 0, 0)
		this.vallist:bordercolor(cpborvlist)
		this.vallist:fillcolor(cpfillvlist)
		this.vallist:movable(false)
		this.vallist:clickable(false)
		this.vallist:active(false)
		this.vallist:visible(true)
		this.vallist:attach(screenBox, this.Parent.la+this.la, (-lcButtonspace+(this.Parent.ba+this.ba)-(lcButtonsize+lcButtonspace)*(maxindex-posindex))-(lcButtonsize+lcButtonspace), this.Parent.ra+this.ra, -lcButtonspace+(this.Parent.ta+this.ta)-(lcButtonsize+lcButtonspace)*(posindex-1));
		this.vallist:makeBranch(this);
		this.vallist.menuline = menuline;
		menuline:textcolor(cpfntcolhghlt);
		this.wobj:makePopShadow(this.vallist,true);
		local btni
		this.valitem = {};
		for i,v in ipairs(menutabvl.choicelist) do
			this.valitem[i] = CPBox:new()
			:init("valitem-"..tostring(i).."-"..tostring(v), 0, 0, 0, 0)
			:bordercolor(cpbormenue)
			:fillcolor(cpfillmenue)
			:textfont(cpfntmenu)
			:textcolor(cpcolmenue)
			:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
			:textpos("center")
			:text(tostring(menutabvl.choicelist[i]))
			:movable(false)
			:clickable(false)
			:active(true)
			:visible(true)
			:attach(this.vallist, lcButtonspace, (lcButtonspace+(maxindex-i)*(lcButtonsize+lcButtonspace))+(lcButtonsize+lcButtonspace), lcButtonspace, lcButtonspace+(i-1)*(lcButtonsize+lcButtonspace));
			this.valitem[i]:makeBranch(this.vallist);
			if metatabvl and metatabvl.choicelist then
				this.valitem[i]:text(metatabvl.choicelist[i]);
			end;
			this.valitem[i].switchbox = CPBox:new()
			:init("this.menupane.menuline.switchbox-"..tostring(i), 0, 0, 0, 0)
			:bordercolor(cpborbutton)
			:textfont(cpfntmenu)
			:textcolor(cpcolbutton)
			:movetext(-4, 12)
			:textpos("left")
			:movable(false)
			:clickable(false)
			:active(false)
			:visible(true)
			:attach(this.valitem[i],this.valitem[i]:ww()-(lcButtonsize+lcButtonspace),lcButtonspace,lcButtonspace,lcButtonspace)
			this.valitem[i].switchbox:makeBranch(this.valitem[i]);
			this.valitem[i].switchbox.Customdraw = function(this)
				this.state = menutabvl[1][i]
				if this.state then
					this:text("x")
				else
					this:text(" ")
				end
			end;
			this.valitem[i].Customdraw = function(this)
				if menutabvl[1][i] then
					this:textcolor(cpfntcolhghlt);
				else
					this:textcolor(cpcolmenue);
				end;
			end;
			this.valitem[i].box = this
			this.valitem[i].Action  = (function()
				return
				function(this)
					menutabvl[1][i] = not menutabvl[1][i];
					if myCelPad.openSetTimer and this.box.wobj.objtype == "setupMenu" then myCelPad.openSetTimer.reset = true; end
					if this.box.wobj.objtype == "queryMenu" and ms070autoScanOn then
						if this.box.wobj.setitem[this.box.lnum].scanbox then
							if this.box.wobj.setitem[this.box.lnum].scanbox.Text ~= "x" then
								this.box.wobj.setitem[this.box.lnum].scanbox.Action(this.box.wobj.setitem[this.box.lnum].scanbox)
							end;
						end
					end;
				end
			end) ();
			btni = i+1;
		end;
		this.btn = {};
		for i = 1,3 do
			this.btn[i] = CPBox:new()
			:init("this.menupane.menuline.this.btn-"..tostring(i), 0, 0, 0, 0)
			:bordercolor(cpborbutton)
			:fillcolor(cpfillbutton)
			:textfont(cpfntmenu)
			:textcolor(cpcolbutton)
			:movetext(0, 8)
			:textpos("center")
			:movable(false)
			:clickable(false)
			:active(true)
			:visible(true)
			:attach(this.vallist, lcButtonspace+(i-1)*(lcButtonsize+lcButtonspace), (lcButtonspace+(maxindex-btni)*(lcButtonsize+lcButtonspace)), this.valitem[1]:ww()-(lcButtonsize+lcButtonspace), lcButtonspace+(btni-1)*(lcButtonsize+lcButtonspace));
			this.btn[i]:makeBranch(this.vallist)
		end;
		this.btn[1]:text("i")
		this.btn[1].Action = (function()
			return
			function()
				for t,h in ipairs(menutabvl[1]) do
					menutabvl[1][t] = not menutabvl[1][t]
				end
				if this.wobj.setitem[this.lnum].scanbox and this.wobj.setitem[this.lnum].scanbox.Text ~= "x" then
					this.wobj.setitem[this.lnum].scanbox:Action()
				end
			end
		end)();
		this.btn[2]:text("x")
		this.btn[2].Action = (function()
			return
			function()
				for t,h in ipairs(menutabvl[1]) do
					menutabvl[1][t] = true
				end
				if this.wobj.setitem[this.lnum].scanbox and this.wobj.setitem[this.lnum].scanbox.Text ~= "x" then
					this.wobj.setitem[this.lnum].scanbox:Action()
				end
			end
		end)();
		this.btn[3]:text(" ")
		this.btn[3].Action = (function()
			return
			function()
				for t,h in ipairs(menutabvl[1]) do
					menutabvl[1][t] = false
				end
			end
		end)();
		this.vallist.Customdraw = function(this)
			mxatt, psatt = this:getfrontpos();
			if (mxatt - psatt) > 1  then
				this.menuline:textcolor(cpcolmenul);
				this:destruct();
			end;
		end;
	end;
	mltChBox.menuline = this.menupane.menuline;
	mltChBox.editbox = this.menupane.editbox;
	return mltChBox;
end;
}
QueryMenu = CClass {
classname = "QueryMenu";
superclass = SetupMenu;
objtype = "queryMenu";
makePopupPane = function(this, btnbox, x, y)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local getheight = getheight
	local finder = btnbox.oribtn.oribtn.wframe.CPFinder
	this.menutab = this.menutab or tSettings[this.objname];
	this.metatab = this.metatab or tMetaSettings[this.objname];
	this.setitem = {};
	this:getPaneBase(btnbox, x, y)
	local startscan = function(this)
		local lcQueryTbl = finder.queryVal
		for y,w in pairs(lcQueryTbl) do
			if type(lcQueryTbl[y])=="table" and lcQueryTbl[y].choicelist then
				local lcMcstr = ""
				local lcMctbl = finder.queryVal[y].choicelist
				for i,v in ipairs(finder.queryVal[y][1]) do
					if v then
						lcMcstr = lcMcstr.." "..lcMctbl[i]
					end;
				end;
				finder.queryVal[y].mcstr = lcMcstr;
			end;
		end;
		finder:taskManager();
		this.wobj:quitpopup(this.btnbox);
		this:orderfront();
		this.oribtn.popup.closebutton:Action()
	end;
	this.menupane.btnself.wobj = this;
	this.menupane.btnself.Action = (function()
		return
		function(this)
			startscan(this)
		end
	end) ();
	this.menupane.btnself.Customdraw = function(this)
		for i,v in pairs(finder.queryVal) do
			if type(v) == "table" and v.choicelist then
				local kk = 0;
				for q,w in ipairs(v[1]) do
					if w then kk = kk + 1 end;
				end;
				if kk == 0 then
					finder.metaQueryVal[i].scan=nil;
				end;
			end;
		end;
	end;
	this.menupane.edminmax = CPBox:new()
	:init("this.menupane.edminmax-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:movetext(0, 6)
	:textpos("center")
	:text("Min/Max Ranges")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	:attach(this.menupane.btnpane, lcButtonspace, lcButtonspace, this.pw-(3*lcmsgButtonwidth+lcButtonspace), lcButtonspace);
	this.menupane.edminmax:makeBranch(this.menupane);
	this.menupane.edminmax.wobj = this;
	this.menupane.edminmax.btnbox = btnbox;
	this.menupane.edminmax.oripane = this.menupane;
	this.menupane.edminmax.popupmenu = function (this, parent, x, y)
		local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
		local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
		this.wobj.setup = SetupMenu:new({this.wobj.menupane.popupMenus});
		this.wobj.setup.menutab = finder:minMaxGet();
		this.wobj.setup.metatab = finder.minMaxMeta;
		this.wobj.setup.finder = finder
		this.wobj.setup:init(this,parent,"minMaxRanges",x,y,"Edit Min/Max Ranges","dlgao");
		this.wobj.setup:makeBranch(this);
		this.wobj.setup.btnselfOK.Action = (function()
			return
			function(this)
				this.wobj.finder:minMaxUpd(this.wobj.menutab)
				if this.wobj.finder.findertype == 1 and #this.wobj.finder.openQueries > 0 then
					local query = this.wobj.finder.openQueries[1]
					query.btnbox.popupmenu(query.btnbox,query.parent,query.menupane.la,ScrY-query.menupane.ta)
				end;
			end
		end) ();
		local query
		this.wobj.setup.btnselfAPL.Action = (function()
			return
			function(this)
				this.wobj.finder:minMaxUpd(this.wobj.menutab)
			end
		end) ();
		this.wobj.setup.menupane.defltbtn = CPBox:new()
		:init("this.menupane.defltbtn-", 0, 0, 0, 0)
		:bordercolor(cpborbutton)
		:fillcolor(cpfillbutton)
		:textfont(cpfntmenu)
		:textcolor(cpcolbutton)
		:movetext(0, 6)
		:textpos("center")
		:text("Defaults")
		:movable(false)
		:clickable(false)
		:active(true)
		:visible(true)
		:menuitem(true)
		:attach(this.wobj.setup.menupane.btnpane, lcButtonspace, lcButtonspace, this.wobj.setup.pw-(2*lcmsgButtonwidth+lcButtonspace), lcButtonspace);
		this.wobj.setup.menupane.defltbtn:makeBranch(this.wobj.setup.menupane);
		this.wobj.setup.menupane.defltbtn.setup = this.wobj.setup
		this.wobj.setup.menupane.defltbtn.Action = (function()
			return
			function(this)
				if not this.MSGupT["PopResetDeflt"] then
					local xx,yy
					xx = this.setup.menupane.la
					yy = this.setup.menupane.ba
					this.PopResetDeflt = PopMessage:new({this.setup.menupane.popupMenus});
					this.PopResetDeflt:init(this,"PopResetDeflt",xx,yy,nil,nil,nil,"yn",
					function(o)
						for t,y in pairs(this.setup.menutab) do
							this.setup.menutab[t].minv = deepcopy(templates.minMaxDefault[t].minv)
							this.setup.menutab[t].maxv = deepcopy(templates.minMaxDefault[t].maxv)
						end;
					end,
					function(o)
					end
					);
					this.PopResetDeflt:makeBranch(this)
				end;
			end
		end) ();
	end;
	return this.menupane;
end;
}
MultiMenu = CClass {
classname = "MultiMenu";
superclass = SetupMenu;
objtype = "multiTool";
makePopupPane = function(this, btnbox, x, y)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local cpgetwidth = cpgetwidth
	local getsetuphi = getsetuphi
	local m_max, m_min = math.max, math.min
	this.oldcheck = this.oldcheck or {};
	this.statswitch = this.statswitch or false
	this.menutab = this.menutab or {{{},choicelist={}},argTbl={}};
	this.metatab = this.metatab or {{},argTbl={};};
	this.setitem = {};
	if #this.menutab[1][1] == 0 then
		this.menutab = deepcopy(this.srctab.data)
		this.metatab = deepcopy(this.srctab.meta)
	end;
	local maxitem = 0;
	local maxhiitem = 0;
	this.pw = 0
	this.ph = (lcButtonsize+2*lcButtonspace)+((lcMenusize+lcButtonspace)*#this.menutab[1][1])
	this.maxmtitemv=0;
	for i,v in ipairs(this.menutab[1].choicelist) do
		if getsetuphi(i,this.metatab) ~= "" then
			this.maxmtitemv = m_max(this.maxmtitemv,cpgetwidth(cpfntmenu,getsetuphi(i,this.metatab)));
		else
		end;
	end;
	this.maxmtitemv=this.maxmtitemv+(2*lcButtonsize+6*lcButtonspace)
	local ii
	local nmval = 0; local nmmin = 0; local nmax = 0; local fcmdw, fwi = 60, 0
	local menuval = 0; local metaval = 0
	local tblval = 0; local tblmet = 0
	local sumlen,summax = 0,0
	this.argbarv = this.argbarv or {};
	this.argbari = this.argbari or {};
	this.propbarv = this.propbarv or {};
	this.propbari = this.propbari or {};
	this.maxargs = this.maxargs or 0;
	this.tmpargbarv = {};
	this.tmppropbarv = {};
	for y,w in ipairs(this.menutab[1].choicelist) do
		ii = 0
		sumlen = 0
		for iy,iw in orderedPairs(this.menutab.argTbl[y]) do
			ii = ii + 1
			this.tmpargbarv[ii] = this.tmpargbarv[ii] or 0;
			this.tmppropbarv[ii] = this.tmppropbarv[ii] or 0;
			local unln = 0
			if templates.metaUnits[iy] then
				for jj,ll in ipairs(templates.metaUnits[iy].valuelist) do
					unln = m_max(unln,cpgetwidth(cpfntmenu,tostring(ll))/1.1)
				end
			end
			metaval = cpgetwidth(cpfntmenu,tostring(this.metatab.argTbl[y][iy][1]))+unln
			this.tmppropbarv[ii] = m_max(this.tmppropbarv[ii],metaval)
			if type(iw) == "number" then
				nmval = cpgetwidth(cpfntmenu,tostring(iw))+2*(lcButtonsize+lcButtonspace)
				this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],nmval)
				nmmin = cpgetwidth(cpfntmenu,tostring(this.metatab.argTbl[y][iy][3]))+2*(lcButtonsize+lcButtonspace)
				this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],nmmin)
				nmmax = cpgetwidth(cpfntmenu,tostring(this.metatab.argTbl[y][iy][4]))+2*(lcButtonsize+lcButtonspace)
				this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],nmmax)
			elseif type(iw) == "table" then
				if iw.valuelist then
					for n,m in ipairs(iw.valuelist) do
						tblval = cpgetwidth(cpfntmenu,tostring(m))
						this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],tblval)
						if 	this.metatab.argTbl[y][iy].valuelist then
							tblmet = cpgetwidth(cpfntmenu,tostring(this.metatab.argTbl[y][iy].valuelist[n]))
							this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],tblmet)
						end;
					end;
				elseif iw.choicelist then
					for n,m in ipairs(iw.choicelist) do
						tblval = cpgetwidth(cpfntmenu,tostring(m))
						this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],tblval)
						if 	this.metatab.argTbl[y][iy].choicelist then
							tblmet = cpgetwidth(cpfntmenu,tostring(this.metatab.argTbl[y][iy].choicelist[n]))
							this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],tblmet)
						end;
					end;
				else
					tblval = 0
					for n,m in ipairs(iw) do
						tblval = tblval+cpgetwidth(cpfntmenu,tostring(m).."; ")
					end
					this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],tblval)
					this.tmpargbarv[ii] = m_min(this.tmpargbarv[ii],100)
					this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],60)
				end;
			elseif type(iw) == "string" then
				if iy ~= "zcmdfreecmd" then
					nmval = cpgetwidth(cpfntmenu,tostring(iw))
					this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],nmval)
				else
					if fcmdw < cpgetwidth(cpfntmenu,tostring(iw)) then
						fcmdw = cpgetwidth(cpfntmenu,tostring(iw))
						fwi = ii
					end
				end
				this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],60)
			elseif type(iw) == "boolean" then
				this.tmpargbarv[ii] = m_max(this.tmpargbarv[ii],60)
			end;
			if ii > 2 then
				sumlen = (sumlen + this.tmppropbarv[ii] + this.tmpargbarv[ii])
			end
		end
		this.maxargs = m_max(this.maxargs,ii)
		summax = m_max(summax,sumlen)
	end;
	if fcmdw > summax then
		this.tmpargbarv[fwi] = fcmdw - summax
	end
	local g
	for k = 1,this.maxargs do
		g = 0
		for ki = this.maxargs,k,-1 do
			g = g + this.tmpargbarv[ki] + this.tmppropbarv[ki]
		end;
		this.argbarv[k] = g - (this.tmpargbarv[k] + this.tmppropbarv[k])
		this.propbarv[k] = g - this.tmppropbarv[k]
	end;
	local z
	for t = 1,this.maxargs do
		z = 0
		for ti = 1,t do
			z = z + this.tmpargbarv[ti] + this.tmppropbarv[ti]
		end;
		this.argbari[t] = z - (this.tmpargbarv[t])
		this.propbari[t] = z - (this.tmppropbarv[t] + this.tmpargbarv[t])
	end;
	this.restofbar = (this.tmppropbarv[1] or 0 ) + (this.tmpargbarv[1] or 0) + (this.argbarv[1] or 0)
	this.pw = this.maxmtitemv + this.restofbar
	this.pra = ScrX-x-this.pw
	this.pba = y-this.ph
	if  this.pra < 4 then x=(x+this.pra)-10 end
	if  this.pba < 4 then y=(y-this.pba)+10 end
	this.menupane = CPBox:new()
	:init("setuppane-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpbormenup)
	:fillcolor(cpfillmenup)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenup)
	:movetext(lcButtonsize, 6)
	:textpos("left")
	:text(this.Header)
	:movable(true)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(screenBox, x, y-this.ph, ScrX-x-this.pw, ScrY-y);
	this.menupane:makeBranch(this);
	this.menupane.ph = this.ph;
	this.menupane.pw = this.pw
	this.menupane.lof,this.menupane.bof = btnbox:offset(x,y);
	this.menupane.pwx, this.menupane.phx = btnbox:size()
	this.menupane.tof =  this.menupane.phx - this.menupane.bof
	this.menupane.lpupm = this.menupane.la
	this.menupane.lofd = 0;
	this.menupane.tpupm = this.menupane.ta
	this.menupane.tofd = 0;
	this.menupane.lbtn = btnbox.ba
	this.menupane.tbtn = btnbox.ta
	this.menupane.popupMenus = {};
	this.menupane.movingsticky = false;
	this:dlgAOPane(btnbox);
	this.btnselfOK.wobj = this;
	this.btnselfOK.Action = (function()
		return
		function(this)
			this.wobj:writeTabs();
			this.wobj:quitpopup(this.btnbox);
		end
	end) ();
	this.btnselfAPL.wobj = this;
	this.btnselfAPL.Action = (function()
		return
		function(this)
			this.wobj:writeTabs();
			this.wobj:moveItem(-1,"apply")
		end
	end) ();
	this:makePopShadow(this.menupane);
	this.menupane.Action = this.ActionMP;
	this.menupane.btboxpointer = btnbox;
	this.menupane.wobj = this;
	this.menupane.Customdraw = this.CustomdrawMP
	local i = 0;
	this.tmultimenu = {};
	for ix,value in ipairs(this.menutab[1].choicelist) do
		i = ix
		this.prop = ix;
		this.value = value;
		table.insert(this.tmultimenu,{});
		this.setitem[i] = this:multiLineBox(btnbox,this.prop,this.value,i);
	end;
	for k,l in ipairs(this.menutab[1].choicelist) do
		this.metatab.indxTbl[l] = k;
	end;
	this.menupane.savldbtn = CPBox:new()
	:init("this.menupane.savldbtn-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(cpborbutton)
	:fillcolor(cpfillbutton)
	:textfont(cpfntmenu)
	:textcolor(cpcolbutton)
	:movetext(0, 6)
	:textpos("center")
	:text("Save/Load")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:menuitem(true)
	:attach(this.menupane.btnpane, lcButtonspace, lcButtonspace, this.pw-(2*lcmsgButtonwidth+lcButtonspace), lcButtonspace);
	this.menupane.savldbtn:makeBranch(this.menupane);
	this.menupane.savldbtn.wobj = this;
	this.menupane.savldbtn.btnbox = btnbox;
	this.menupane.savldbtn.oripane = this.menupane;
	this.menupane.savldbtn.popupmenu = function (this, parent, x, y)
		this.popup = PopupMenu:new({this.oripane.popupMenus});
		local infostr = tostring(this.wobj.srctab.meta.infostr)
		this.popup.menutab = deepcopy(tCelPadHUD.Menu.SavLdMT)
		for q,w in ipairs(this.popup.menutab) do
			if not string.find(this.popup.menutab[q],infostr) then
				this.popup.menutab[q] = tCelPadHUD.Menu.SavLdMT[q]..infostr
			end
		end;
		this.popup.finder = this.wobj.finder;
		this.popup.what = this.wobj.what;
		this.popup.wobj = this.wobj
		this.popup:init(this,parent,"saveldmt",x,y,"Save/Load ");
		this.popup:makeBranch(this);
	end;
	this.argbarv = nil;
	this.argbari = nil;
	this.propbarv = nil;
	this.propbari = nil;
	this.maxargs = nil;
	this.clrbtn = CPBox:new()
	this.clrbtn:init("MultiMenu.clrbtn", 0, 0, 0, 0)
	this.clrbtn:bordercolor(cpborarrow)
	this.clrbtn:textfont(cpfntmenu)
	this.clrbtn:textcolor(cpcolarrow)
	this.clrbtn:movetext(-2, -0.5*(cpfntmenu:getheight()+lcMenusize)+23)
	this.clrbtn:textpos("left")
	this.clrbtn:text(" ")
	this.clrbtn:movable(false)
	this.clrbtn:clickable(false)
	this.clrbtn:active(true)
	this.clrbtn:visible(true)
	this.clrbtn:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)-(lcMenusize+lcButtonspace)), this.pw-(lcButtonsize+lcButtonspace), (2*lcButtonspace+lcButtonsize)-(lcMenusize+lcButtonspace));
	this.clrbtn:makeBranch(this);
	this.clrbtn.Action = (function()
		return
		function()
			if not this.cmdtimer then
				if not this.statswitch then
					for k,v in ipairs(this.menupane.itembox) do
						if v.check and v.check.Text == "x" then
							this.oldcheck[k] = true
							v.check:Action(true)
						end
					end
					this.clrbtn:text("x")
					this.statswitch = true
				else
					for k,v in ipairs(this.menupane.itembox) do
						if v.check and this.oldcheck[k] then
							v.check:Action(true)
						end
					end
					this.clrbtn:text(" ")
					this.statswitch = false
				end;
			end;
		end
	end) ();
	return this.menupane;
end;
writeTabs = function(this)
	this.srctab.data = deepcopy(this.menutab)
	this.srctab.meta = deepcopy(this.metatab)
end;
moveItem = function(this,i,dir)
	if dir == "up" then
		this.menutab[1][1][i-1],this.menutab[1][1][i] = this.menutab[1][1][i],this.menutab[1][1][i-1]
		this.menutab[1].choicelist[i-1],this.menutab[1].choicelist[i] = this.menutab[1].choicelist[i],this.menutab[1].choicelist[i-1]
		this.metatab[i-1],this.metatab[i] = this.metatab[i],this.metatab[i-1]
		this.menutab.argTbl[i-1],this.menutab.argTbl[i] = this.menutab.argTbl[i],this.menutab.argTbl[i-1]
		this.metatab.argTbl[i-1],this.metatab.argTbl[i] = this.metatab.argTbl[i],this.metatab.argTbl[i-1]
		this.metatab.indxTbl[this.menutab[1].choicelist[i]] = this.metatab.indxTbl[this.menutab[1].choicelist[i]] - 1
	elseif dir == "down" then
		this.menutab[1][1][i+1],this.menutab[1][1][i] = this.menutab[1][1][i],this.menutab[1][1][i+1]
		this.menutab[1].choicelist[i+1],this.menutab[1].choicelist[i] = this.menutab[1].choicelist[i],this.menutab[1].choicelist[i+1]
		this.metatab[i+1],this.metatab[i] = this.metatab[i],this.metatab[i+1]
		this.menutab.argTbl[i+1],this.menutab.argTbl[i] = this.menutab.argTbl[i],this.menutab.argTbl[i+1]
		this.metatab.argTbl[i+1],this.metatab.argTbl[i] = this.metatab.argTbl[i],this.metatab.argTbl[i+1]
		this.metatab.indxTbl[this.menutab[1].choicelist[i]] = this.metatab.indxTbl[this.menutab[1].choicelist[i]] + 1
	end;
	this.btnbox.mvitem = true
	this.btnbox.menutab = this.menutab
	this.btnbox.metatab = this.metatab
	this.btnbox.Stck = this.menupane.Sticky
	this.btnbox.Hid = this.menupane.Hiding
	this.btnbox.Vis = this.menupane.Visible
	this.closebutton.Action();
	this.btnbox.popupmenu(this.btnbox,this.parent,this.menupane.la,ScrY-this.menupane.ta,this.menutab,this.metatab)
end;
multiLineBox =  function(this, btnbox, prop, value, i)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local lcmsgButtonheight = msgButtonheight;
	local getheight = getheight
	local getsetuphi = getsetuphi
	local oldcheck = {};
	local statswitch = false
	local mltLneBox={};
	local pressSwitch = pressSwitch
	local winact = true
	if this.mvrType == "holey" then
		winact = false
	end
	local finder
	if btnbox.oribtn and btnbox.oribtn.oribtn then
		if btnbox.oribtn.oribtn.wframe then
			finder = btnbox.oribtn.oribtn.wframe.CPFinder;
		elseif btnbox.oribtn.oribtn.oribtn then
			finder = btnbox.oribtn.oribtn.oribtn.CPFinder;
		end
	end
	finder = finder or {};
	this.menupane.itembox = this.menupane.itembox or {};
	this.menupane.itembox[i] = CPBox:new()
	:init("this.menupane.itembox[i]-"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpbormenue)
	:fillcolor(cpfillmenue)
	:textfont(cpfntmenu)
	:textcolor(cpcolmenue)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+21)
	:textpos("center")
	:text(getsetuphi(i,this.metatab))
	:editable(false)
	:movable(false)
	:clickable(false)
	:active(winact)
	:visible(true)
	:attach(this.menupane, 3*lcButtonsize+4*lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), this.restofbar, (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.itembox[i]:makeBranch(this);
	this.menupane.itembox[i].mover = true
	this.menupane.itembox[i].mvrType = this.mvrType
	this.menupane.itembox[i].pane = this.menupane;
	this.menupane.itembox[i].menutab = this.menutab;
	this.menupane.itembox[i].metatab = this.metatab;
	this.menupane.itembox[i].prop = prop;
	this.menupane.itembox[i].wobj = this;
	this.menupane.itembox[i].indx = i
	this.menupane.itembox[i].Action = (function()
		return
		function(this)
			this:orderfront();
			if this.mvrType == "movable" then
				this.wobj.ActionMP(this.wobj.menupane)
			end
		end
	end) ();
	this.menupane.itembox[i].Customdraw = function(this)
		pressSwitch(this)
	end;
	if this.cmditem then
		this.menupane.itembox[i].popupmenu = function (this, parent, x, y)
			local menufnc = function(menutab)
				local cmdname = this.Text
				this.popup = PopupMenu:new({parent.popupMenus});
				if menutab then
					this.popup.menutab = menutab
				else
					if templates.cpcmds[cmdname].describe then
						local descmenu = {
						"Describe",
						switch = {1};
						fnctab = {
						function(o)
							if not ControlPanel.mainFrame.MSGupT["cmdDescribe"..cmdname] then
								this.cmdDescribe = PopMessage:new({ControlPanel.mainFrame.popupMenus});
								this.cmdDescribe:init(ControlPanel.mainFrame,"cmdDescribe"..cmdname,x,y,"Describe: "..cmdname,templates.cpcmds[cmdname].describe,nil,"inf");
								this.cmdDescribe:makeBranch(ControlPanel);
							end;
							if this.cmdDescribe then
								this.cmdDescribe.menupane:visible(true)
							end;
						end;
						};
						runfnc = {0};
						};
						this.popup.menutab = mergemenutabs(tCelPadHUD.Menu.ComItem,descmenu)
					end
				end
				this.popup:init(this,parent,"ComItem",x,y,cmdname,"no");
				this.popup.indx = i
				this.popup:makeBranch(this);
			end
			if this.wobj.cmdtimer and this.wobj.srctab.data[1][1][this.indx] then
				local pausmenu = {
				templates.pausmenu[1],templates.pausmenu[2],templates.pausmenu[3],
				switch = {0,0,0};
				fnctab = {
				function(o)
					local item = this
					if tCelPad.Timers.chained[this.wobj.cmdtimer.TimerID][item.indx].status == "frozen" then
						tCelPad.Timers.chained[this.wobj.cmdtimer.TimerID][item.indx].status = "unfrozen";
					else
						tCelPad.Timers.chained[this.wobj.cmdtimer.TimerID][item.indx].status = "frozen";
					end;
				end;
				function(o)
					local item = this
					tCelPad.Timers.chained[this.wobj.cmdtimer.TimerID][item.indx].status = "kill";
					o:quitmenu()
				end;
				function(o)
					local item = this
					tCelPad.Timers.chained[this.wobj.cmdtimer.TimerID][item.indx]:killchain();
				end;
				};
				runfnc = {0};
				}
				menufnc(pausmenu)
			elseif not this.wobj.cmdtimer and not(finder.runningTask == 2 and not finder.paused) then
				menufnc()
			end
		end
	end;
	this.menupane.itembox[i].check = CPBox:new()
	:init("this.menupane.itembox[i].check"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(2,-0.5*(cpfntmenu:getheight()+lcMenusize)+23)
	:textpos("center")
	:text("x")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),(this.restofbar+this.maxmtitemv)-(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.itembox[i].check:makeBranch(this);
	this.menupane.itembox[i].check.wobj = this
	this.menupane.itembox[i].check.prop = prop
	this.menupane.itembox[i].check.Action = (function()
		return
		function(this, unall)
			if not this.wobj.cmdtimer then
				this.wobj.menutab[1][1][this.prop] = not this.wobj.menutab[1][1][this.prop]
				if not unall then
					this.wobj.oldcheck = nil;
					this.wobj.oldcheck = {};
					this.wobj.clrbtn:text(" ")
					this.wobj.statswitch = false;
				end
			end
		end
	end) ();
	this.menupane.itembox[i].check.Customdraw = function(this)
		if this.wobj.menutab[1][1][this.prop] then
			this:text("x")
		else
			this:text(" ")
		end
	end;
	this.menupane.itembox[i].toup = CPBox:new()
	:init("this.menupane.itembox[i].toup"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0, -0.5*(cpfntmenu:getheight()+lcMenusize)+19)
	:textpos("left")
	:text("^")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, 2*lcButtonspace+lcButtonsize, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)),(this.restofbar+this.maxmtitemv)-2*(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.itembox[i].toup:makeBranch(this);
	this.menupane.itembox[i].toup.metatab = this.metatab;
	this.menupane.itembox[i].toup.menutab = this.menutab;
	this.menupane.itembox[i].toup.prop = prop;
	this.menupane.itembox[i].toup.wobj = this;
	this.menupane.itembox[i].toup.maxargs = this.maxargs
	this.menupane.itembox[i].toup.Action = (function()
		return
		function(this)
			if not this.wobj.cmdtimer then
				if this.prop > 1 then
					this.wobj:moveItem(this.prop,"up")
				end;
			end
		end
	end) ();
	this.menupane.itembox[i].todwn = CPBox:new()
	:init("this.menupane.itembox[i].todwn"..tostring(i), 0, 0, 0, 0)
	:bordercolor(cpborarrow)
	:fillcolor(cpfillarrow)
	:textfont(cpfntmenu)
	:textcolor(cpcolarrow)
	:movetext(0,-0.5*(cpfntmenu:getheight()+lcMenusize)+23)
	:textpos("center")
	:text("v")
	:movable(false)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(this.menupane, 2*lcButtonsize+3*lcButtonspace, this.ph-((2*lcButtonspace+lcButtonsize+lcMenusize)+(i-1)*(lcMenusize+lcButtonspace)), (this.maxmtitemv+this.restofbar)-3*(lcButtonspace+lcButtonsize), (2*lcButtonspace+lcButtonsize)+(i-1)*(lcMenusize+lcButtonspace));
	this.menupane.itembox[i].todwn:makeBranch(this);
	this.menupane.itembox[i].todwn.maxargs = this.maxargs
	this.menupane.itembox[i].todwn.metatab = this.metatab;
	this.menupane.itembox[i].todwn.menutab = this.menutab;
	this.menupane.itembox[i].todwn.prop = prop;
	this.menupane.itembox[i].todwn.wobj = this;
	this.menupane.itembox[i].todwn.Action = (function()
		return
		function(this)
			if not this.wobj.cmdtimer then
				if this.prop < #this.wobj.menutab[1][1] then
					this.wobj:moveItem(this.prop,"down")
				end;
			end;
		end
	end) ();
	table.insert(this.tmultimenu[i],this.menupane.itembox[i].check);
	table.insert(this.tmultimenu[i],this.menupane.itembox[i].toup);
	table.insert(this.tmultimenu[i],this.menupane.itembox[i].todwn);
	table.insert(this.tmultimenu[i],this.menupane.itembox[i]);
	local c = 0;
	local sitem
	for q,a in orderedPairs(this.menutab.argTbl[i]) do
		c = c + 1;
		this.prop = q;
		this.value = a;
		sitem = this:makeItem(btnbox,i,c)
		table.insert(this.tmultimenu[i],sitem.menuline)
		table.insert(this.tmultimenu[i],sitem.editbox)
	end;
	mltLneBox.menuline = this.menupane.menuline;
	mltLneBox.editbox = this.menupane.editbox;
	return mltLneBox;
end;
}
PopMessage = CClass {
classname = "PopMessage";
superclass = PopupMenu;
objtype = "popupMSG";
init = function (this, btnbox, objname, swx, swy, text, message, msgsev, msgtype, yfnc, nfnc)
	this.objname = objname;
	this.tCelPadHUD = tCelPadHUD;
	this.btnbox = btnbox;
	if swx == nil or swy == nil then
		swx = nil
		swy = nil
	end;
	this.wx = swx
	this.wy = swy
	this.panebuttons = {};
	this.tVbars = {};
	this.mvrType = wMovMenu
	if (yfnc and type(yfnc)=="function") or (nfnc and type(nfnc)=="function") then
		this.yfnc = yfnc;
		this.nfnc = nfnc;
		this.msgtype = "yn";
	else
		this.msgtype = msgtype;
	end;
	this.Header = text or (templates2.popMsg[objname].title or "Untitled");
	local msgtxt = deepcopy(message or templates2.popMsg[objname]);
	msgtxt.txtfnt = deepcopy(msgtxt.txtfnt or {});
	this.fonttab = {};
	this.fonttab[smallfont] = {
	[smallfont] = smallfont;
	[normalfont] = smallfont;
	[bigfont] = normalfont;
	};
	this.fonttab[normalfont] = {
	[smallfont] = smallfont;
	[normalfont] = normalfont;
	[bigfont] = bigfont;
	};
	this.fonttab[bigfont] = {
	[smallfont] = normalfont;
	[normalfont] = bigfont;
	[bigfont] = bigfont;
	};
	local wdth, btnx
	if msgtxt[1] == "< autowrap >" then
		table.remove(msgtxt,1)
		if string.sub(msgtxt[1],1,2) == "<-" then
			wdth = tonumber(string.sub(msgtxt[1],3))
			table.remove(msgtxt,1)
		end
		this:msgPrep(msgtxt,wdth)
	else
		this.message = msgtxt
	end
	this.msgsev = msgsev or msgtxt.sev or templates2.popMsg[objname].sev or "a";
	msgtxt = nil;
	this.cpborpupmsg, this.cpfillpupmsg, this.cpcolpupmsg, this.cpborpupbx, this.cpfillpupbx, this.cpcolpupbx, this.cpfillpupbtn, this.cpborpupbtn, this.cpcolpupbtn  = getMsgColor(this.msgsev)
	this:makePopupMSG(btnbox, this.wx, this.wy)
	if btnbox.Stck ~= nil then
		this.menupane.Sticky = btnbox.Stck
	else
		this.menupane.Sticky = defMnSticky
	end
	if btnbox.Hid ~= nil then
		this.menupane.Hiding = btnbox.Hid
	else
		this.menupane.Hiding = defMnHiding
	end
	if btnbox.Vis ~= nil then
		this.menupane:visible(btnbox.Vis)
	end
	this:popupStickyBtn(this.menupane, btnbox);
	this.stickybutton:bordercolor(this.cpborpupbtn)
	this.stickybutton:fillcolor(this.cpfillpupbtn)
	this.stickybutton:textcolor(this.cpcolpupbtn)
	this:popupHideBtn(this.menupane, btnbox);
	this.hidebutton:bordercolor(this.cpborpupbtn)
	this.hidebutton:fillcolor(this.cpfillpupbtn)
	this.hidebutton:textcolor(this.cpcolpupbtn)
	if this.msgtype == "ok" then
		this:popupOKBtn(this.menupane, btnbox);
		if yfnc and type(yfnc) == "number" and yfnc>0 then
			this.MSGtimer = CPtimer:new({tCelPad.Timers}); -- dont branch!
			this.MSGtimer:init("this.MSGtimer","this.MSGtimer",yfnc,"standalone",0,
			function(o)
				this.okbutton.Action(this.okbutton)
				this.MSGtimer=nil;
			end
			);
		end;
	elseif this.msgtype == "yn" then
		this:popupYNbtn(this.menupane, btnbox);
	elseif this.msgtype == "inf" then
		this:popupOKBtn(this.menupane, btnbox);
		this.okbutton:text("Close");
		this:popupScrollV()
		this:popupRszBtn()
		this.menupane.rsbtn = this.RszButton
	end;
	this.YN = "--";
	this.OK = false;
	if Help[objname] then
		this:popupHelpBtn(this.menupane, btnbox);
		this.helpbutton:bordercolor(this.cpborpupbtn)
		this.helpbutton:fillcolor(this.cpfillpupbtn)
		this.helpbutton:textcolor(this.cpcolpupbtn)
	end;
	if btnbox.MSGupT then
		btnbox.MSGupT[this.objname] = true;
	end;
	if btnbox.Parent and btnbox.Parent.objname then
		btnx = (string.find(btnbox.Parent.objname,"moveButton") or string.find(btnbox.Parent.objname,"mainFrame"))
	else
		btnx = 1
	end;
	if myCelPadHUD.Cascade and btnbox.Parent and btnx ~= 1 then
		if btnbox.Stck == nil then
			this.menupane.Sticky = btnbox.Parent.Sticky
		end;
		if btnbox.Hid == nil then
			this.menupane.Hiding = btnbox.Parent.Hiding
		end;
	end;
	if btnbox.Stck ~= nil then btnbox.Stck = nil end;
	if btnbox.Hid ~= nil then btnbox.Hid = nil end;
	if this.menupane.Sticky then
		local llbx,lbbx,lrbx,ltbx = this.menupane.btboxpointer:bounds()
		this.menupane.lbtn = llbx
		this.menupane.tbtn = ltbx
	end
	this.menupane:orderfront();
end;
msgPrep = function(this,msgtxt,wdth)
	local fntsz = tCPfonts[msgtxt.txtfnt[1]] or normalfont
	local tmpmsg = {
	txtfnt = {};
	};
	local wrapInfLine = wrapInfLine;
	local msgw = wdth or string.len(msgtxt[1]) + 2
	local ltxt, rtxt
	local lmsgx, ix, wrtxt = 0, 0, 0
	local ltxtlen
	for i=1,#msgtxt do
		ltxt = string.match(msgtxt[i],"(.+)`");
		rtxt = string.match(msgtxt[i],"`(.+)");
		if ltxt then
			ltxtlen = string.len(ltxt)
			if ltxtlen > lmsgx then
				lmsgx = ltxtlen
				ix = i
				wrtxt = msgw - lmsgx
				this.lmsgmx = ltxt
			end;
		end;
	end;
	local txt1, txt2, ttxt, idnt, cnd
	local mfnt
	for i=1,#msgtxt do
		mfnt = msgtxt.txtfnt[i]
		ltxt = string.match(msgtxt[i],"(.+)`");
		rtxt = string.match(msgtxt[i],"`(.+)");
		if not ltxt and not rtxt then
			if msgtxt[i] ~= "" then
				ttxt = msgtxt[i]
				while ttxt ~= "" do
					txt1,txt2 = wrapInfLine(ttxt,msgw,fntsz)
					table.insert(tmpmsg,txt1)
					table.insert(tmpmsg.txtfnt,mfnt)
					ttxt = txt2
				end
			else
				table.insert(tmpmsg,"")
				table.insert(tmpmsg.txtfnt,mfnt)
			end;
		else
			if string.sub(rtxt,1,2) == "->" then
				idnt = true
				rtxt = string.sub(rtxt,3)
			end
			txt1,txt2 = wrapInfLine(rtxt,wrtxt,fntsz)
			ttxt = ltxt.."`"..txt1
			table.insert(tmpmsg,ttxt)
			table.insert(tmpmsg.txtfnt,mfnt)
			ttxt = txt2
			while  ttxt ~= ""  do
				if idnt then
					txt1,txt2 = wrapInfLine(txt2,wrtxt,fntsz)
					txt1 = "->`"..txt1
				else
					txt1,txt2 = wrapInfLine(txt2,msgw,fntsz)
				end
				table.insert(tmpmsg,txt1)
				table.insert(tmpmsg.txtfnt,mfnt)
				ttxt = txt2
			end
			idnt = false
		end;
	end;
	this.message = tmpmsg;
end;
popupOKBtn = function(this, box, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	this.okbutton = CPBox:new()
	:init("pupOKbtn", 0, 0, 0, 0)
	:bordercolor(this.cpborpupbtn)
	:fillcolor(this.cpfillpupbtn)
	:textfont(cpfntmenu)
	:textcolor(this.cpcolpupbtn)
	:textpos("center")
	:movetext(0, 6)
	:text("OK")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(box,math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace)/2)),lcButtonspace,  math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace)/2)), this.ph-(lcmsgButtonheight+lcButtonspace));
	this.okbutton:makeBranch(this);
	this.okbutton.btnbox = btnbox;
	this.okbutton.box = box;
	this.okbutton.wobj = this
	this.okbutton.Action = (function()
		return
		function(this)
			if this.wobj.MSGtimer then
				this.wobj.MSGtimer.status = "kill";
				this.wobj.MSGtimer = nil;
			end;
			this.box = this.wobj:quitpopup(this.btnbox);
		end
	end) ();
	return this.okbutton;
end;
popupYNbtn = function(this, box, btnbox)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	this.ynbutton = {};
	this.ynbutton.ynbuttonY = CPBox:new()
	:init("ynbuttonY", 0, 0, 0, 0)
	:bordercolor(this.cpborpupbtn)
	:fillcolor(this.cpfillpupbtn)
	:textfont(cpfntmenu)
	:textcolor(this.cpcolpupbtn)
	:textpos("center")
	:movetext(0, 6)
	:text("YES")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(box,math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace/2))),lcButtonspace,  math.ceil((this.pw/2)+lcButtonspace/2),  this.ph-(lcmsgButtonheight+lcButtonspace));
	this.ynbutton.ynbuttonY:makeBranch(this);
	this.ynbutton.ynbuttonY.wobj = this
	this.ynbutton.ynbuttonY.Action = (function()
		return
		function(this)
			this.wobj.YN = "Y";
			if this.wobj.yfnc then
				this.wobj.yfnc();
				if not this.wobj.Ybranchkill then
					this.wobj:quitpopup(btnbox);
				end;
			end;
		end
	end) ();
	this.ynbutton.ynbuttonN = CPBox:new()
	:init("ynbuttonN", 0, 0, 0, 0)
	:bordercolor(this.cpborpupbtn)
	:fillcolor(this.cpfillpupbtn)
	:textfont(cpfntmenu)
	:textcolor(this.cpcolpupbtn)
	:textpos("center")
	:movetext(0, 6)
	:text("NO")
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(box,math.ceil((this.pw/2)+lcButtonspace/2),lcButtonspace,  math.ceil((this.pw/2)-((lcmsgButtonwidth+lcButtonspace/2))),  this.ph-(lcmsgButtonheight+lcButtonspace));
	this.ynbutton.ynbuttonN:makeBranch(this);
	this.ynbutton.ynbuttonN.wobj = this
	this.ynbutton.ynbuttonN.Action = (function()
		return
		function(this)
			this.wobj.YN = "N";
			if this.wobj.nfnc then
				this.wobj.nfnc();
				if not this.wobj.Nbranchkill then
					this.wobj:quitpopup(btnbox);
				end;
			end;
		end
	end) ();
	return this.ynbutton;
end;
popupRszBtn = function(this)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local lcShadowsize = gShadowsize;
	local showShadow = gShowShadows;
	this.RszButton = CPBox:new()
	:init("popupRszBtn", 0, 0, 0, 0)
	:bordercolor(this.cpborpupbtn)
	:fillcolor(this.cpfillpupbtn)
	:textfont(cpfntmenu)
	:textcolor(this.cpcolpupbtn)
	:textpos("center")
	:movetext(2, 13)
	:text("_")
	:movable(false)
	:rszbutton(true)
	:active(true)
	:attach(this.menupane, this.menupane.pw-(lcButtonspace+lcButtonsize), lcButtonspace, lcButtonspace, this.menupane.ph-(lcButtonspace+lcButtonsize))
	this.RszButton:makeBranch(this);
	this.RszButton.stoph = true
	this.RszButton.wobj = this
	this.RszButton.Customdraw = function(this)
	if this.wobj.panedone then
		local mw, mh = this.wobj.menupane:size()
		if not this.wobj.mhdone then
		mh = this.wobj.ph
		this.wobj.mhdone = true
		end
		if this.Pressed then
			this.wobj.menupane.ph = mh
			if this.wobj.menupane.onborder ~= 0 then
				this.wobj.menupane.Hiding = false;
			end;
		end
		this.wobj.okbutton.ta = mh-(lcmsgButtonheight+lcButtonspace)
		this.ta = mh-(lcButtonspace+lcButtonsize)
		local cmph = ScrY - this.wobj.menupane.ba - this.wobj.menupane.ta
		if showShadow then
			if not this.wobj.menupane.Hiding or (mh == cmph and this.wobj.menupane.onborder ~= 4)  then
				this.wobj.menupane.shdr.ba = -(ScrY - this.wobj.menupane.ba - this.wobj.menupane.ta)+lcShadowsize
				this.wobj.menupane.shdb.ta = ScrY - this.wobj.menupane.ba - this.wobj.menupane.ta
			end
		end
		if mh ~= cmph and this.wobj.menupane.onborder ~= 2  then
			if not this.wobj.menupane.Pressed then
				this.wobj.menupane.ph = mh
				if this.wobj.menupane.onborder == 0  or (this.wobj.menupane.onborder ~= 0 and not this.wobj.menupane.Hiding) then
					this.wobj.menupane.ba = ScrY - mh - this.wobj.menupane.ta
				end
			end
		end
		if mh < 4*(lcButtonsize+lcButtonspace) and this.wobj.menupane.onborder ~= 2 then
			this.wobj.menupane.ba = ScrY-this.wobj.menupane.ta-4*(lcButtonsize+lcButtonspace)
		end;
		if mh >= this.wobj.maxh-2 then
			if this.wobj.menupane.onborder == 0 or (this.wobj.menupane.onborder ~= 0 and not this.wobj.menupane.Hiding) then
				this.wobj.menupane.ba = ScrY-this.wobj.menupane.ta-this.wobj.maxh
			end
			this.wobj.SbFrame:visible(false)
		else
			if not this.wobj.SbFrame.Visible then
				this.wobj.SbFrame:visible(true)
			end
		end
	end
	end;
	return this.RszButton
end;
popupScrollV = function(this)
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local cpborpupmsg, cpfillpupmsg, cpcolpupmsg, cpborpupbx, cpfillpupbx, cpcolpupbx = getMsgColor(this.msgsev)
	this.SbFrame = CPBox:new({this.tVbars})
	:init("this.SbFrame", 0, 0, 0, 0)
	:bordercolor(cpfillpupmsg)
	:movable(false)
	:clickable(false)
	:active(true)
	:attach(this.menupane, this.menupane.pw-(lcButtonspace+lcButtonsize), msgButtonheight+2*lcButtonspace, lcButtonspace, lcButtonsize+2*lcButtonspace)
	this.SbFrame:makeBranch(this);
	this.SbFrame.wobj = this;
	this.SbFrame.Customdraw = function(this)
		this.bw, this.bh = this:size()
		this.wobj.sbh = this.bh;
		if this.Pressed then
			if this.wobj.xba > this.coy then
				this.wobj.lineoffset = this.wobj.lineoffset+1;
			end;
			if this.wobj.xta > 3 and (this.bh - this.wobj.xta) < this.coy then
				this.wobj.lineoffset = this.wobj.lineoffset-1;
			end;
		end;
	end;
	this.SbFrame.SbSlider = CPBox:new()
	:init("SbSlider", 0, 13, 0, 13)
	:bordercolor(this.cpborpupbtn)
	:fillcolor(this.cpfillpupbtn)
	:movable(true)
	:clickable(false)
	:active(true)
	:attach(this.SbFrame, 0, 13, 0, 13)
	this.SbFrame.SbSlider:makeBranch(this);
	this.SbFrame.SbSlider.wobj = this;
	this.SbFrame.SbSlider.Customdraw = function(this)
		if this.wobj.lineoffset < 0 then
			this.wobj.xta = 3;
			this.wobj.xba = 3;
			this.ta = 3;
			this.ba = 3;
		end;
		if this.Pressed then
			for i,v in ipairs(this.wobj.menupane.popupMenus) do
				v.menupane:orderfront();
			end;
			this.wobj.slidingV = true
			this.wobj.xta=this.ta;
			if this.wobj.xta < 4 then
				this.wobj.xta = 0;
				this.ta = 3;
				this.wobj.lineoffset = 0;
			end;
		else
			this.wobj.slidingV = false
			if this.wobj.xta > 2 then
				this.ta=this.wobj.xta;
			else
				this.ta=3
			end
		end;
		this.ba=this.wobj.xba
		if this.wobj.xba < 4 then
			this.wobj.xba = 1;
			this.ba = 3;
		end;
		this.bw, this.bh = this:size()
		this.wobj.xh = this.bh
	end
	return this.SbFrame;
end;
makePopupMSG = function(this, btnbox, x, y)
	local textlayout = textlayout
	local cpgetwidth = cpgetwidth
	local getheight = getheight
	local lcButtonsize, lcButtonspace = gButtonsize, gButtonspace;
	local lcMenusize = gMenusize;
	local m_min,m_max = math.min, math.max
	local lcmsgButtonwidth, lcmsgButtonheight = msgButtonwidth, msgButtonheight;
	local fntsz = tCPfonts[this.message.txtfnt[1]] or normalfont
	local cpfntmainw = cpfntmainw
	local math_round = math_round;
	local maxitem = 0
	local itemx, noitems = 0,0
	for itemnum = 1, #this.message do
		if this.message[itemnum] then
			itemx = itemx + 1
		else
			this.message[itemnum] = "nix";
			noitems = noitems + 1;
		end;
	end;
	local infofnc = function(txt,finder)
		if txt then
			local ltxt, rtxt
			ltxt = string.match(txt,"(.+)`") or txt;
			rtxt = string.match(txt,"`(.+)") or "";
			if finder then
				if finder.unittable[ltxt] then
					if not tonumber(rtxt) then
						rtxt = string.gsub(rtxt,"%.",",");
						if rtxt == "-1,#INF" then rtxt = -math.huge; end;
						if rtxt == "1,#INF" then rtxt = math.huge; end;
						rtxt = tonumber(rtxt)
					end;
					rtxt = finder.unittable[ltxt][1](rtxt,"fromnative")
					if rtxt ~= "no data" then
						rtxt = rtxt.." "..finder.unitmeta[ltxt].valuelist[finder.unitmeta[ltxt].metaindx]
					end
				end;
				ltxt = finder.rndtabNames[ltxt] or ltxt
				rtxt = rtxt or "no data";
			end
			return ltxt, rtxt
		else
			return "", ""
		end
	end;
	this.pw = cpgetwidth(cpfntmenu,this.Header) + 4*(lcButtonsize+lcButtonspace)
	local ltxtln, rtxtln
	local ltxtmax,rtxtmax, msgh, pwmax = 0,0,0,0
	local oldfont = "normalfont"
	for i,v in ipairs(this.message) do
		if v ~= "nix" then
			ltxtln, rtxtln = infofnc(v,this.finder)
			if not this.message.txtfnt[i] then
				this.message.txtfnt[i] = oldfont
			else
				oldfont = this.message.txtfnt[i]
			end
			pwmax = m_max(pwmax,cpgetwidth(tCPfonts[oldfont],ltxtln))
			if rtxtln ~= "" then
				ltxtln = cpgetwidth(tCPfonts[oldfont],ltxtln)
				rtxtln = cpgetwidth(tCPfonts[oldfont],rtxtln)
				ltxtmax = m_max(ltxtmax,ltxtln)
				rtxtmax = m_max(rtxtmax,rtxtln)
				pwmax = m_max(pwmax,ltxtmax + rtxtmax)
			end;
			msgh = msgh + tCPfonts[oldfont]:getheight()
		end;
	end;
	this.pw = m_max(this.pw,pwmax)
	this.ph = (lcButtonsize+2*lcButtonspace)+msgh+(lcmsgButtonheight+4*lcButtonspace)
	this.maxh = this.ph
	if this.msgtype == "inf" then
		this.ph = m_min(this.ph,maxInfoHght)
		this.pw = this.pw + lcButtonsize
	end;
	x = x or (ScrX/2-this.pw/2);
	y = y or (ScrY/2+this.ph/2);
	this.pra = ScrX-x-this.pw
	this.pba = y-this.ph
	if  this.pra < 4 then x=(x+this.pra)-10 end
	if  this.pba < 4 then y=(y-this.pba)+10 end
	this.menupane = CPBox:new()
	:init("infopane-"..tostring(btnbox.objname), 0, 0, 0, 0)
	:bordercolor(this.cpborpupmsg)
	:fillcolor(this.cpfillpupmsg)
	:textfont(cpfntmenu)
	:textcolor(this.cpcolpupmsg)
	:movetext(0, 6)
	:textpos("left")
	:text(this.Header)
	:movable(true)
	:clickable(false)
	:active(true)
	:visible(true)
	:attach(screenBox, x, y-this.ph, ScrX-x-this.pw, ScrY-y);
	this.menupane:makeBranch(this);
	this.menupane.ph = this.ph;
	this.menupane.pw = this.pw
	this:makePopShadow(this.menupane);
	this.menupane.lof,this.menupane.bof = btnbox:offset(x,y);
	this.menupane.pwx, this.menupane.phx = btnbox:size()
	this.menupane.tof =  this.menupane.phx - this.menupane.bof
	this.menupane.lpupm = this.menupane.la
	this.menupane.lofd = 0;
	this.menupane.tpupm = this.menupane.ta
	this.menupane.tofd = 0;
	this.menupane.lbtn = btnbox.ba
	this.menupane.tbtn = btnbox.ta
	this.menupane.popupMenus = {};
	this.menupane.movingsticky = false;
	this.menupane.Action = this.ActionMP;
	this.menupane.btboxpointer = btnbox;
	this.menupane.wobj = this;
	this.menupane.Customdraw = this.CustomdrawMP;
	local pressSwitch = pressSwitch
	local winact = true
	if this.mvrType == "holey" then
		winact = false
	end
	this.menupane.msgbox = CPBox:new()
	:init("menupane.msgbox", 0, 0, 0, 0)
	:bordercolor(this.cpborpupbx)
	:fillcolor(this.cpfillpupbx)
	:movable(false)
	:active(winact)
	:visible(true)
	:attach(this.menupane, lcButtonspace, lcmsgButtonheight+2*lcButtonspace, lcButtonspace, lcButtonsize+2*lcButtonspace);
	this.menupane.msgbox:makeBranch(this.menupane);
	this.menupane.msgbox.message = this.message;
	this.menupane.msgbox.wobj = this
	this.menupane.msgbox.mvrType = this.mvrType
	this.menupane.msgbox.mover = true
	local lmsg, rmsg
	local maxmsgln = #this.message
	local upoffset, dwnoffset = 0,0
	this.lineoffset = 0
	this.xh = 0;
	this.xta = 2;
	this.xba = 2;
	this.sbh = 0;
	this.menupane.msgbox.Action = (function()
		return
		function(this)
			if this.mvrType == "movable" then
				this.wobj.ActionMP(this.wobj.menupane)
			end
		end
	end) ();
	this.menupane.msgbox.valpos = this.menupane.msgbox.valpos or cpgetwidth(fntsz,this.lmsgmx or "");
	this.menupane.msgbox.Customdraw = function(this)
		local startpos = -2;
		local bw,bh = this:size()
		local mw,mh = this.wobj.menupane:size()
		pressSwitch(this)
		if this.wobj.msgtype == "inf" then
			this.wobj.endline = math.ceil(bh/fntsz:getheight())-1
		else
			this.wobj.lineoffset = 0
			this.wobj.endline = #this.message
		end
		for i=1+this.wobj.lineoffset,this.wobj.endline+this.wobj.lineoffset do
			if this.message[i] ~= "nix" then
				if this.message[i] == nil then
					if this.wobj.lineoffset > 0 then
						this.wobj.lineoffset = this.wobj.lineoffset-1
					end
				end
				local finfnt
				finfnt = this.wobj.fonttab[fntsz][cpfntmsgmid]
				textlayout:setfont(finfnt);
				textlayout:setfontcolor(this.wobj.cpcolpupbx);
				fntsz = tCPfonts[this.message.txtfnt[i]] or normalfont
				finfnt = this.wobj.fonttab[fntsz][cpfntmsgmid]
				textlayout:setfont(finfnt);
				lmsg, rmsg = infofnc(this.message[i],this.wobj.finder)
				startpos = startpos + fntsz:getheight()
				if rmsg == "" then
					textlayout:setpos(this.lb+5, (this.tb)-startpos);
					textlayout:println(lmsg)
				else
					this.valpos = m_max(this.valpos,cpgetwidth(fntsz,lmsg))
					if lmsg ~= "->" then
						textlayout:setpos(this.lb+5, (this.tb)-startpos);
						local lindelim = ":"
						if lmsg == " " then
							lindelim = ""
						end
						textlayout:println(lmsg..lindelim.." ")
					end
					textlayout:setpos(this.lb+this.valpos, (this.tb)-startpos);
					textlayout:println(rmsg)
				end;
			end;
		end;
		if this.wobj.msgtype == "inf" then
			local sblmt = 1;
			local maxlinepoints=((this.wobj.endline+this.wobj.lineoffset)-(1+this.wobj.lineoffset))*cpfntmainw:getheight()
			if this.wobj.xh  < sblmt*lcButtonsize then
				this.wobj.SbLimit = true;
			else
				if this.wobj.sbh - (mh-(mh*mh/(maxlinepoints-2*fntsz:getheight()))-this.wobj.xta) - this.wobj.xta > sblmt*lcButtonsize+lcButtonsize/2 then
					this.wobj.SbLimit = false;
				end
			end;
			if this.wobj.slidingV then
				this.wobj.lineoffset = math_round(table.maxn(this.message)*this.wobj.xta/(mh-2*(lcButtonsize+lcButtonspace)))
				if this.wobj.lineoffset > table.maxn(this.message) - this.wobj.endline then
					this.wobj.lineoffset = table.maxn(this.message) - this.wobj.endline
				end
			else
				this.wobj.xta = this.wobj.lineoffset*(mh-2*(lcButtonsize+lcButtonspace))/table.maxn(this.message)
			end;
			if not this.wobj.SbLimit then
				this.wobj.xba = (mh-2*(lcButtonsize+lcButtonspace))*(1 - this.wobj.endline/table.maxn(this.message)) - this.wobj.xta
			else
				this.wobj.xba=this.wobj.sbh-(this.wobj.xta+sblmt*lcButtonsize)
			end
		end
	end;
	this.panedone = true
	return this.menupane;
end;
quitpopup = function(this, btnbox)
	if btnbox.MSGupT then
		btnbox.MSGupT[this.objname] = nil;
	end;
	this:destruct();
	return ( nil );
end;
};

CPSquareWindow = CPBox:new()
:init("CPSquareWindow", 0, 0, 0, 0)
:bordercolor(cbubordoff)
:fillcolor(csetbofill)
:movable(true)
:clickable(false)
:visible(false)
:active(true)
:attach(screenBox, lastwindow.lastchwx, lastwindow.lastchwy, -52, -45);
CPSquareWindow.statlbrt = {
statla = CPSquareWindow.la;
statba = CPSquareWindow.ba;
statra = CPSquareWindow.ra;
statta = CPSquareWindow.ta;
};
CPSquareWindow.CPLup = false;
CPSquareWindow.popupmenu = function(this, parent, x, y)
	if ControlPanel then
		ControlPanel.Minimized = not ControlPanel.Minimized
		ControlPanel.moveButton:visible(not ControlPanel.Minimized);
		ControlPanel:processFrameMenu(ControlPanel.mainFrame,
		function(o)
			if o.menupane.Sticky == false then
				if not ControlPanel.Minimized then
					if not ControlPanel.mainFrame.HidMenu then
						o.menupane:visible(true)
					end;
				else
					o.menupane:visible(false)
				end
			end;
			o.menupane:orderfront();
		end
		)
	end;
end;
CPSquareWindow.Customdraw = function(this)
	textlayout:setfont(normalfont);
	textlayout:setpos(this.lb+5, this.tb-14);
	textlayout:setlinespacing(normalfont:getheight());
	textlayout:setfontcolor(cpcolheader);
	textlayout:println("CelPad");
	textlayout:setlinespacing(smallfont:getheight());
	if ControlPanel then
		CPSquareWindow.CPLup = true;
		textlayout:println("ver. "..CPver)
		textlayout:setfont(smallfont);
		textlayout:println(string.format("%.6f",timedelta));
	else
		CPSquareWindow.CPLup = false;
		textlayout:setfont(smallfont);
		textlayout:setpos(this.lb+3, this.tb-27);
		if not myCelPad.fileConv then
			textlayout:println("Click here");
			textlayout:setpos(this.lb+5, this.tb-37);
			textlayout:println("to begin...");
		else
			textlayout:println("waiting for");
			textlayout:setpos(this.lb+3, this.tb-37);
			textlayout:println("conversion");
		end
	end;
	if this.Pressed then
		this.statlbrt["statla"] = this.la;
		this.statlbrt["statba"] = this.ba;
		this.statlbrt["statra"] = this.ra;
		this.statlbrt["statta"] = this.ta;
		lastwindow.lastchwx = this.la
		lastwindow.lastchwy = this.ba
	else
		this.la = this.statlbrt["statla"];
		this.ba = this.statlbrt["statba"];
		this.ra = this.statlbrt["statra"];
		this.ta = this.statlbrt["statta"];
		this.la = lastwindow.lastchwx
		this.ba = lastwindow.lastchwy
	end
	for i,v in ipairs(tCelPadHUD.popMsgs) do
		v.menupane:orderfront();
	end;
	if this.la > (ScrX-60) then
		this.la = ScrX-60
	end;
	if this.ba > (ScrY-60) then
		this.ba = ScrY-60
	end;
	local ca = (this.ba+50)-(ScrY-toolBoxHeight)
	local cb = (this.la+50)-(ScrX-boxWidth)
	if ca>0 and cb>0 then
		if ca>cb then
			this.la = ScrX-boxWidth-50
		else
			this.ba = ScrY-toolBoxHeight-50
		end
	end
end;
CPSquareWindow.Action = (function()
	return
	function(this)
		-- timedeltamax = 0;
		if not myCelPad.fileConv then
			CPSquareWindow:bordercolor(cpborframecp)
			CPSquareWindow:fillcolor(cpfillframecp)
			if CPSquareWindow.CPLup == false then
				ControlPanel=CPControlPanel:new({tCelPadHUD.winObjects})
				lastwindow.lastcpwx, lastwindow.lastcpwy,lastwindow.lastcpww,lastwindow.lastcpwh = myCelPadHUD:borderchk(lastwindow.lastcpwx, lastwindow.lastcpwy,lastwindow.lastcpww,lastwindow.lastcpwh)
				ControlPanel:init("ControlPanel", lastwindow.lastcpwx, lastwindow.lastcpwy,lastwindow.lastcpww,lastwindow.lastcpwh);
				ControlPanel.mainFrame:drawtext(false);
				ControlPanel.mainFrame:header(("Control Panel"));
				ControlPanel:makeBranch(this);
			else
				ControlPanel.moveButton:orderfront();
			end
		end
	end
end) ()
