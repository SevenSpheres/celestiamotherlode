-- CelPadBox.lua

celestia:log("CelPad: attaching Lua Edu Tools checkbox")

require "CXClass"
require "CXBox"
require "CelPad"

myCelPad = CelPad:new()
:deinitialized(true)
:initialized(false)
:running(false)
celestia:log("CelPad: created as "..tostring(myCelPad))

CelPadBox = CXBox:new()
:init("CelPadBox",0, 0, 0, 0)
:movable(false)
:clickable(true)
:attach(screenBox, width, height, 0, 0);

CelPadBox.Customdraw = function(this)
	textlayout:setfont(normalfont);
	textlayout:setfontcolor(ctext);
	textlayout:setpos(this.lb+25, this.tb-14);
	textlayout:println("CelPad");
	myCelPad:CelPadUpdate();
	if CPquitOK then
		if CPquitOK.YN == "Y" then
			gCelPadStarted = false;
			CPquitOK = CPquitOK:quitpopup(CelPadBox);
			myCelPad.closerq = true;
			CelPadCheck.Text = "";
		elseif CPquitOK.YN == "N" then
			gCelPadStarted = true;
			CPquitOK = CPquitOK:quitpopup(CelPadBox);
		end;
	end;

end;

CelPadCheck = CXBox:new()
:init("CelPadCheck",0, 0, 0, 0)
:bordercolor(cbubordoff)
:textfont(normalfont)
:textcolor(cbutextoff)
:textpos("center")
:movetext(0, 9)
:text("")
:movable(false)
:active(true)
:attach(CelPadBox, boxWidth - 40, 4, 29, 5)

CelPadCheck.Action = (function()
	return
	function()
		if not myCelPad.closerq and not CPquitOK then
			if not myCelPad.fileConv then
				gCelPadStarted = not gCelPadStarted;
				if gCelPadStarted then
					myCelPad:running(true)
					CelPadCheck.Text = "x";
				else
					if not CPquitOK then
						CPquitOK = PopMessage:new({tCelPadHUD.popMsgs});
						CPquitOK:init(screenBox,"CPquitOK",x,y,nil,nil,nil,"yn");
						CPquitOK:makeBranch(myCelPadHUD);
						if table_num(myCelPad.rstcmdtab) > 0 or myCelPad.noconvert then
							CPquitOK.ynbutton.ynbuttonY:Action()
						end
					end;
				end
			end
		end
	end
end) ();
