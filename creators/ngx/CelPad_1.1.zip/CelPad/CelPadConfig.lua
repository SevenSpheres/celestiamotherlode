--CelPadConfig.lua

celestia:log("CelPad: loading configuration ")

profileDIR = "extras/CelPad/saves/";

--following commented line is an example for putting CelPad into Lua Edu Tools' 'adds' directory.
--profileDIR = "extras/lua_edu_tools/adds/CelPad/saves/";

--Do not edit the file below this line unless you know exactly what you are doing. CelPad settings can be edited and saved using the graphical user interface.
URLstartCMD = "start \"cmd\" cmd /C start \"web\" ";
CPver = "1.1"
ScrX, ScrY = celestia:getscreendimension();
starSol = celestia:find("Sol")
Fuse = 1;
LoadLoop = 300;
DebugLog = false;
restPurgeLogs = true; --purge syslogs when restarted
timeObjRisk = 0.5;--risky timedeta before scan
postProcLimit = 1000; --minimum children for postprocessing
nilTmoRisk = {
1000000, --minimum limit of objects for warning message
4, --minimum limit of tasks for warning message
0.1, --time delta for cleanup lag detection
10, --new clean loops until cleanup pack reset
100, --minimum limit for reduction of cleanup pack
3 --steps down on nilparser entry when risky niling
}; --risky set-tasks combination
sysSlowRisk = 0.8; --system slow detection time delta in s
sysSlowBack = 0.4;
distLargeRisk = 10000000000000000; --too big distance limit for warning message in km
lrgSetRisk = 0.5; --min. rate for large result set risk
obsInfoDec = 4; --observer info distance decimals
markSetLim = {
10000, --minimum limit for ask message
30000, --minimum limit for forced adaptive
0.4, --time delta for forced adaptive
0.2 --time delta for slow system warning
}; --mark set limit
tProfiles = {
SavesGUI = {
savename = {"default", valuelist = {"default","LETtheme","blue","ghost","heavy"}};
};
SavesQRstars = {
savename = {"default", valuelist = {"default","star_example_1","star_example_2"}};
};
SavesQRsatellites = {
savename = {"default", valuelist = {"default","sat_example_1","sat_example_2"}};
};
SavesQRdsos = {
savename = {"default", valuelist = {"default","dso_example_1"}};
};
SavesQRlocations = {
savename = {"default", valuelist = {"default","loc_example_1"}};
};
SavesVW = {
savename = {"default", valuelist = {"default","stars","satellites","dsos","locations"}};
};
SavesSUM = {
savename = {"default", valuelist = {"default","stars","satellites","dsos","locations","full","empty"}};
};
SavesSYS = {
savename = {"default", valuelist = {"default","slowPC","fastPC"}};
};
SavesCMDS = {
savename = {"default", valuelist = {"default","cmds1","cmds2","1-line"}};
};
};
tSettings = {
Windows = {
--Menu Pane Color Scheme
cp1schmenup = {0.05, 0.1 , 0.1, 0.9};
--Main Window Color Scheme
cp1schmainw = {0.05, 0.1 , 0.1, 0.9};
--Control Panel Color Scheme
cp1schcontp = {0.05, 0.1 , 0.1, 0.9};
-- highlighted text color
cpfntcolhghlt = {1,1,1,1};
--main window font color
cpfntcolmainw = {0.8, 0.8, 0.8, 0.7};
--running command font color
cpfntcolruncmd = {0, 0.7, 0.7, 0.9};
--menu font
cpfntmenu = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}};
--main window font
cpfntmainw = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}};
--window header font
cpfntheader = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}};
--message middle font
cpfntmsgmid = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}};
Maxpageitems = 100;
rclHideMenu = false;
showMenuHidBtn = false;
showScrollBtn = true;
showTextBtn = false;
showVerbBtn = true;
showViewBtn = true;
showWrapBtn = false;
wMovWin = {"movable", valuelist = {"movable","locked","holey"}};
wMovMenu = {"movable", valuelist = {"movable","locked","holey"}};
};
WindowsAdv = {
["< separator >"] = "Colors";
cpbordon = {0.6, 0, 0, 0.4};
cpfillshadow = {0, 0 , 0, 0.6};
["cpfillshadow < separator >"] = "Control Panel Parameters";
CPiconH = 22;
CPicor = {"horizontal", valuelist = {"horizontal","vertical"};};
CPmaxH = 250;
CPmaxW = 650;
["CPmaxW < separator >"] = "Default Window Status";
defgDrawtext = true;
defgScroll = true;
defgVerbose = false;
defgWordwrap = false;
defMnHiding = false;
defMnSticky = false;
defzCascade = false;
["defzCascade < separator >"] = "Menu and Messages Parameters";
gButtonsize = 12;
gButtonspace = 2;
gMenusize = 12;
gShadowsize = 8;
gShowShadows = true;
maxInfoHght = 360;
maxSyslWidth = 70;
msgButtonheight = 16;
msgButtonwidth = 32;
["msgButtonwidth < separator >"] = "Mouse";
mtBtnDelay1 = 0.4;
mtBtnDelay2 = 0.05
};
WindowsAdvMW = {
--Main Window Color Scheme
Dcpfillmvbtn = {0, 0 , 0, 0};
Dcpborframe =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillframe = {0, 0 , 0, 0};
Dcpbormvbtn =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillmwarrow = {0, 0 , 0, 0};
Dcpcolmwarrow = {0.35, 0.5 , 0.5, 0};
Dcpbormwarrow =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillmwslider = {0, 0 , 0, 0};
Dcpbormwslider =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillmwslfr = {-0.1, -0.1 , -0.1, -0.4};
Dcpbormwslfr =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillrzbtn = {0, 0 , 0, 0};
Dcpcolrzbtn = {0.35, 0.5 , 0.5, 0};
Dcpborrzbtn =  {0.15, 0.3 , 0.3, -0.3};
Dcpcolheader = {0.75, 0.7 , 0.7, -0.1};
};
WindowsAdvMN = {
--menu pane color scheme
Dcpfillmenup = {0, 0 , 0, 0};
Dcpbormenup = {0.15,0.3,0.3,-0.3};
Dcpcolmenup = {0.35,0.5,0.5,0};
Dcpfillbutton = {0.15,0.2,0.2,-0.5};
Dcpcolbutton = {0.2,0.4,0.4,0.5};
Dcpborbutton = {0,0.2,0.2,0};
Dcpfillmenul = {0, 0 , 0, 0};
Dcpbormenul = {0.15, 0.3 , 0.3, -0.3};
Dcpcolmenul = {0.35, 0.5 , 0.5, 0};
Dcpfillmenue = {0, 0 , 0, 0};
Dcpbormenue = {0.15, 0.3 , 0.3, -0.3};
Dcpcolmenue = {0.35, 0.5 , 0.5, 0};
Dcpfillvlist = {-0.05, 0, 0, 0};
Dcpborvlist =  {0.3, 0.4 , 0.35, 0.1};
Dcpfillarrow = {0.15,0.2,0.2,-0.5};
Dcpborarrow = {0.15, 0.3 , 0.3, -0.3};
Dcpcolarrow = {0.35, 0.5 , 0.5, 0};
};
WindowsAdvCP = {
--Control Panel Color Scheme
Dcpfillframecp = {0, 0, 0, 0};
Dcpborframecp =  {0.15, 0.3 , 0.3, -0.3};
Dcpfilliconn = {0.25,0.3,0.3,-0.4};
Dcpboriconn = {-0.6, -0.4 , -0.4, 0};
Dcpfilliconm = {0.05, 0, 0, -0.8};
Dcpboriconm = {0, 0.2 , 0.2, 0.5};
Dcpcolicon = {0.45, 0.45 , 0.45, -0.1};
};
WindowsAdvPM = {
--PopMSG Color Scheme
cpfillpupmsga = {0.9, 0.1 , 0.1, 0.8};
cpfillpupmsgw = {-0.1, 0.1 , 0.9, 0.8};
cpfillpupmsgi = {-0.3, 0.25 , 0.25, 0.8};
-- Popup Msg Color Schema Alert
Dcpborpupmsga = {0.3, 0.1 , 0.1, 0.2};
Dcpcolpupmsga = {0.6, 0.35 , 0.3, 0.6};
Dcpfillpupbxa = {0.3, 0.1 , 0.1, -0.1};
Dcpborpupbxa = {0.3, 0.1 , 0.1, 0.2};
Dcpcolpupbxa = {0.9, 0.9 , 0.9, 0.6};
Dcpfillpupbtna = {0.3, 0.1 , 0.1, 0.1};
Dcpborpupbtna = {0.3, 0.2 , 0.1, 0.2};
Dcpcolpupbtna = {0.3, 0.8 , 0.6, 0.1};
-- Popup Msg Color Schema Warn
Dcpborpupmsgw = {0.3, 0.1 , 0.1, 0.2};
Dcpcolpupmsgw = {0.4, 0.35 , 0.3, 0.6};
Dcpfillpupbxw = {0.3, 0.1 , 0.1, -0.1};
Dcpborpupbxw = {0.3, 0.1 , 0.1, 0.2};
Dcpcolpupbxw = {0.9, 0.9 , 0.9, 0.6};
Dcpfillpupbtnw = {0.3, 0.1 , 0.1, 0.1};
Dcpborpupbtnw = {0.3, 0.2 , 0.1, 0.2};
Dcpcolpupbtnw = {0.3, 0.8 , 0.6, 0.1};
-- Popup Msg Color Schema Info
Dcpborpupmsgi = {0.3, 0.1 , 0.1, 0.2};
Dcpcolpupmsgi = {0.6, 0.35 , 0.3, 0.6};
Dcpfillpupbxi = {0.3, 0.1 , 0.1, -0.1};
Dcpborpupbxi = {0.3, 0.1 , 0.1, 0.2};
Dcpcolpupbxi = {0.9, 0.9 , 0.9, 0.6};
Dcpfillpupbtni = {0.3, 0.1 , 0.1, 0.1};
Dcpborpupbtni = {0.3, 0.2 , 0.1, 0.2};
Dcpcolpupbtni = {0.3, 0.8 , 0.6, 0.1};
};
SystemSet = {
["< separator >"] = "Perormance";
ms010ScanLoop = 5000;
ms020AdaptiveLoops = false;
ms022OpenSetWarn = 300;
ms025autoAdaptOn = 4;
["ms025autoAdaptOn < separator >"] = "Information";
ms030AddInfo = {"obspos", valuelist = {"none","obspos","objdist","homdist","meminfo"}};
ms035IconInfo = true;
ms036ShowPos = false;
ms037ShowCat = true;
ms038sumShowNames = true;
["ms038sumShowNames < separator >"] = "Finders";
ms040DefView1 = {"log", valuelist = {"resultset","log"}};
ms050DefView2 = {"log", valuelist = {"resultset","log"}};
ms055ShowScanWarnings = true;
ms060InheritFinder = true;
ms065VwSumAutoLd = true;
ms070autoScanOn = true;
ms080InclNils = false;
ms085PosDedup = false;
ms130untDecPlac = 10;
ms131fastCleanup = false;
ms132updateOpened = true;
ms136externInput = false;
["ms136externInput < separator >"] = "Commands";
ms140askForDur = false;
ms150defDur = 5;
ms151defRadMtpl=2;
ms152cmdRptSet=false;
["ms152cmdRptSet < separator >"] = "Logging";
ms160VerboseLogs = true;
ms161AlertsInLogs = true;
ms170maxSysLog = 1000;
ms180rotLog = 100;
};
};
ms170maxSysLog = tSettings.SystemSet.ms170maxSysLog;
ms180rotLog = tSettings.SystemSet.ms180rotLog
tMetaSettings = {
Windows = {
--Menu Pane Color Scheme
cp1schmenup = {"Menu Pane Color Scheme",0.01,-1,1};
--Main Window Color Scheme
cp1schmainw = {"Main Window Color Scheme",0.01,-1,1};
--Control Panel Color Scheme
cp1schcontp = {"Control Panel Color Scheme",0.01,-1,1};
cpfntcolhghlt = {"Highlighted Text Color",0.1,-1,1};
cpfntcolmainw = {"Main Window Font Color",0.01,-1,1};
cpfntcolruncmd = {"Run. Command Font Color",0.01,-1,1};
cpfntheader = {"Window Header Font"};
cpfntmsgmid = {"Message Middle Font"};
cpfntmainw = {"Main Window Font"};
cpfntmenu = {"Menu Font"};
Maxpageitems = {"Maximum Items per Page",1,10,10000};
rclHideMenu = {"Right Click Menu Hide"};
showMenuHidBtn = {"Show Menu Hide Button"};
showScrollBtn = {"Show Scroll Button"};
showTextBtn = {"Show DrawText Button"};
showVerbBtn = {"Show Verbose Button"};
showViewBtn = {"Show View Switch Button"};
showWrapBtn = {"Show Wrap Button"};
wMovWin = {"Move Window Frames"};
wMovMenu = {"Move Menu and Messages"};
};
WindowsAdv = {
cpbordon = {"Active Border Color Scheme",0.01,-1,1};
cpfillshadow = {"Shadow Color Scheme",0.01,-1,1};
CPiconH = {"Icon Height",1,22,44};
CPicor = {"Icons Orientation (experimental)"};
CPmaxH = {"Control Panel Maximum Height",1,200,800};
CPmaxW = {"Control Panel Maximum Width",1,250,800};
defgDrawtext = {"Default Show Text ON"};
defgScroll = {"Default Scroll ON"};
defgVerbose = {"Default Verbose ON"};
defgWordwrap = {"Default Wrap Lines ON"};
defMnHiding = {"Default Hiding ON"};
defMnSticky = {"Default Sticky ON"};
defzCascade = {"Default Cascade ON"};
gButtonsize = {"Button Size",1,10,24};
gButtonspace = {"Space Between Buttons",1,2,10};
gMenusize = {"Menu Size",1,10,24};
gShadowsize = {"Menu Shadow Distance",1,4,16};
gShowShadows = {"Show Menu Shadows"};
maxInfoHght = {"Initial Info Pane Height (max)",1,50,ScrY};
maxSyslWidth = {"Syslog Popup Message Width",1,10,ScrX};
msgButtonheight = {"Message Button Height",1,14,24};
msgButtonwidth = {"Message Button Width",1,24,48};
mtBtnDelay1 = {"Click Repeat Delay",0.05,0.1,1};
mtBtnDelay2 = {"Click Repeat Rate",0.01,0.01,0.1};
};
WindowsAdvMW = {
--Main Window Color Scheme
Dcpborframe =  {"Frame Border Color Delta",0.01,-1,1};
Dcpbormvbtn =  {"Top Bar Border Color Delta",0.01,-1,1};
Dcpbormwarrow =  {"Arrow Border Color Delta",0.01,-1,1};
Dcpbormwslfr =  {"Slider Frame Border Color Delta",0.01,-1,1};
Dcpbormwslider =  {"Slider Border Color Delta",0.01,-1,1};
Dcpborrzbtn =  {"Button Border Color Delta",0.01,-1,1};
Dcpcolheader = {"Window Header Color Delta",0.01,-1,1};
Dcpcolmwarrow = {"Arrow Text Color Delta",0.01,-1,1};
Dcpcolrzbtn = {"Button Text Color Delta",0.01,-1,1};
Dcpfillframe = {"Background Fill Color Delta",0.01,-1,1};
Dcpfillmwarrow = {"Arrow Fill Color Delta",0.01,-1,1};
Dcpfillmwslfr = {"Slider Frame Fill Color Delta",0.01,-1,1};
Dcpfillmwslider = {"Slider Fill Color Delta",0.01,-1,1};
Dcpfillrzbtn = {"Button Fill Color Delta",0.01,-1,1};
Dcpfillmvbtn = {"Top Bar Fill Color Delta",0.01,-1,1};
};
WindowsAdvMN = {
-- Menu Pane Color Scheme
Dcpborarrow = {"Arrow Border Color Delta",0.01,-1,1};
Dcpborbutton = {"Button Border Color Delta",0.01,-1,1};
Dcpbormenue = {"Editbox Border Color Delta",0.01,-1,1};
Dcpbormenul = {"Line Border Color Delta",0.01,-1,1};
Dcpbormenup = {"Border Color Delta",0.01,-1,1};
Dcpborvlist =  {"Value List Border Color Delta",0.01,-1,1};
Dcpcolarrow = {"Arrow Text Color Delta",0.01,-1,1};
Dcpcolbutton = {"Button Text Color Delta",0.01,-1,1};
Dcpcolmenue = {"Editbox Text Color Delta",0.01,-1,1};
Dcpcolmenul = {"Line Text Color Delta",0.01,-1,1};
Dcpcolmenup = {"Text Color Delta",0.01,-1,1};
Dcpfillarrow = {"Arrow Fill Color Delta",0.01,-1,1};
Dcpfillbutton = {"Button Fill Color Delta",0.01,-1,1};
Dcpfillmenue = {"Editbox Fill Color Delta",0.01,-1,1};
Dcpfillmenul = {"Line Fill Color Delta",0.01,-1,1};
Dcpfillmenup = {"Menu Pane Fill Color Delta",0.01,-1,1};
Dcpfillvlist = {"Value List Fill Color Delta",0.01,-1,1};
};
WindowsAdvCP = {
--Control Panel Color Scheme
Dcpfillframecp =  {"Background Fill Color Delta",0.01,-1,1};
Dcpborframecp =  {"Frame Border Color Delta",0.01,-1,1};
Dcpfilliconn = {"Icon Normal Fill Color Delta",0.01,-1,1};
Dcpboriconn = {"Icon Normal Border Color Delta",0.01,-1,1};
Dcpfilliconm = {"Icon Minimized Fill Color Delta",0.01,-1,1};
Dcpboriconm = {"Icon Minimized Border Color Delta",0.01,-1,1};
Dcpcolicon = {"Icon Text Color Delta",0.01,-1,1};
};
WindowsAdvPM = {
cpfillpupmsga = {"Alert Message Color Schema",0.01,-1,1};
cpfillpupmsgw = {"Warning Message Color Schema",0.01,-1,1};
cpfillpupmsgi = {"Info Message Color Schema",0.01,-1,1};
--Alert Message Color Scheme
Dcpborpupmsga = {"Alert Message Border",0.01,-1,1};
Dcpcolpupmsga = {"Alert Message Header",0.01,-1,1};
Dcpfillpupbxa = {"Alert Message Box Fill",0.01,-1,1};
Dcpborpupbxa = {"Alert Message Box Border",0.01,-1,1};
Dcpcolpupbxa = {"Alert Message Text",0.01,-1,1};
Dcpfillpupbtna = {"Alert Message Button Fill",0.01,-1,1};
Dcpborpupbtna = {"Alert Message Button Border",0.01,-1,1};
Dcpcolpupbtna = {"Alert Message Button Text",0.01,-1,1};
-- Popup Msg Color Schema Warn
Dcpborpupmsgw = {"Warning Message Border",0.01,-1,1};
Dcpcolpupmsgw = {"Warning Message Header",0.01,-1,1};
Dcpfillpupbxw = {"Warning Message Box Fill",0.01,-1,1};
Dcpborpupbxw = {"Warning Message Box Border",0.01,-1,1};
Dcpcolpupbxw = {"Warning Message Text",0.01,-1,1};
Dcpfillpupbtnw = {"Warning Message Button Fill",0.01,-1,1};
Dcpborpupbtnw = {"Warning Message Button Border",0.01,-1,1};
Dcpcolpupbtnw = {"Warning Message Button Text",0.01,-1,1};
-- Popup Msg Color Schema Info
Dcpborpupmsgi = {"Info Message Border",0.01,-1,1};
Dcpcolpupmsgi = {"Info Message Header",0.01,-1,1};
Dcpfillpupbxi = {"Info Message Box Fill",0.01,-1,1};
Dcpborpupbxi = {"Info Message Box Border",0.01,-1,1};
Dcpcolpupbxi = {"Info Message Text",0.01,-1,1};
Dcpfillpupbtni = {"Info Message Button Fill",0.01,-1,1};
Dcpborpupbtni = {"Info Message Button Border",0.01,-1,1};
Dcpcolpupbtni = {"Info Message Button Text",0.01,-1,1};
};
SystemSet = {
ms010ScanLoop = {"Max Loops in Scan",500,1,20000};
ms020AdaptiveLoops = {"Adaptive Loops"};
ms022OpenSetWarn = {"Open Settings Warning (sec)",10,0,86400};
ms025autoAdaptOn = {"Slowdown Tolerance (sec)",1,2,10};
ms030AddInfo = {"Info on Control Panel",valuelist = {"none","Observer's Position","Distance from Selection","Distance from Sun","Memory consumption (Kbytes)"};};
ms035IconInfo = {"Show Icon Info Letter"};
ms036ShowPos = {"Show Objects Positions"};
ms037ShowCat = {"Show Catalog Numbers"};
ms038sumShowNames = {"Show Names in Summary"};
ms040DefView1 = {"Default View for Scanner",valuelist = {"Results","Log"}};
ms050DefView2 = {"Default View for Selection Pad",valuelist = {"Records","Log"}};
ms055ShowScanWarnings = {"Show Warnings before Scan"};
ms060InheritFinder = {"Inherit Settings in Clone"};
ms065VwSumAutoLd = {"View/Summary Auto Load"};
ms070autoScanOn = {"Auto Scan ON if Edited"};
ms080InclNils = {"Include Items with No Data"};
ms085PosDedup = {"Position Deduplication"};
ms130untDecPlac = {"Maximum Decimal Places",1,1,20};
ms131fastCleanup = {"Fast Cleanup (experimental)"};
ms132updateOpened = {"Update Opened Windows"};
ms136externInput = {"External Input for Edit"};
ms140askForDur = {"Ask For Parameters"};
ms150defDur = {"Default Duration (sec)",0.1,0,86400};
ms151defRadMtpl = {"Default Distance Coeficient",0.1,0,1000};
ms152cmdRptSet={"Default Repeat Command Set"};
ms160VerboseLogs = {"Verbose Logs"};
ms161AlertsInLogs = {"Show Alerts/Warnings in Logs"};
ms170maxSysLog = {"Maximum Log Lines",10,10,10000};
ms180rotLog = {"Log Rotation Lines",10,100,1000};
};
SavesGUI = {
savename = {"Profile Name:",1};
hiname = "GUI";
};
SavesQRstars = {
savename = {"Stars Query Name:",1};
hiname = "stars query";
};
SavesQRsatellites = {
savename = {"Planets Query Name:",1};
hiname = "satellites query";
};
SavesQRdsos = {
savename = {"DSO Query Name:",1};
hiname = "deep space objects query";
};
SavesQRlocations = {
savename = {"Location Query Name:",1};
hiname = "locations query";
};
SavesVW = {
savename = {"View Name:",1};
hiname = "view";
};
SavesSUM = {
savename = {"Summary Name:",1};
hiname = "summary";
};
SavesSYS = {
savename = {"System Profile:",1};
hiname = "system profile";
};
SavesCMDS = {
savename = {"Command Set:",1};
hiname = "command set";
};
};
tDeltaSettings = {
Windows = {
--Menu Pane Color Scheme
cpfillmenup = {0.05, 0.1 , 0.1, 0.9};
cpbormenup = {0.2, 0.4 , 0.4, 0.6};
cpcolmenup = {0.4, 0.6 , 0.6, 0.9};
cpfillbutton = {0.1,0.1,0.1,0.4};
cpcolbutton = {0.4, 0.6 , 0.6, 0.9};
cpborbutton = {0.2, 0.4 , 0.4, 0.6};
cpfillmenul = {0.05, 0.1 , 0.1, 0.9};
cpbormenul = {0.2, 0.4 , 0.4, 0.6};
cpcolmenul = {0.4, 0.6 , 0.6, 0.9};
cpbormenue = {0.2, 0.4 , 0.4, 0.6};
cpfillmenue = {0.05, 0.1 , 0.1, 0.9};
cpcolmenue = {0.4, 0.6 , 0.6, 0.9};
cpborvlist =  {0.3, 0.4 , 0.35, 0.15};
cpfillvlist = {0.05, 0.1 , 0.1, 0.15};
cpfillarrow = {1,1,1,0.6};
cpborarrow = {0.2, 0.4 , 0.4, 0.6};
cpcolarrow = {0.6,0.6,0.6,0.6};
--Main Window Color Scheme
cpfillmvbtn = {0.05, 0.1 , 0.1, 0.9};
cpborframe =  {0.2, 0.4 , 0.4, 0.6};
cpfillframe = {0.05, 0.1 , 0.1, 0.9};
cpbormvbtn =  {0.2, 0.4 , 0.4, 0.6};
cpcolmwarrow = {0.4, 0.6 , 0.6, 0.9};
cpfillmwarrow = {0.05, 0.1 , 0.1, 0.9};
cpbormwarrow =  {0.2, 0.4 , 0.4, 0.6};
cpfillmwslider = {0.05, 0.1 , 0.1, 0.9};
cpbormwslider =  {0.2, 0.4 , 0.4, 0.6};
cpfillmwslfr = {0, 0, 0, 0};
cpbormwslfr =  {0.2, 0.4 , 0.4, 0.6};
cpfillrzbtn = {0.05, 0.1 , 0.1, 0.9};
cpcolrzbtn = {0.4, 0.6 , 0.6, 0.9};
cpborrzbtn =  {0.2, 0.4 , 0.4, 0.6};
--Control Panel Color Scheme
cpfillframecp = {0.05, 0.1 , 0.1, 0.9};
cpborframecp =  {0.2, 0.4 , 0.4, 0.6};
cpfilliconn = {0.8,0.8,0.8,0.6};
cpboriconn = {0.2, 0.4 , 0.4, 0.6};
cpfilliconm = {0.1, 0.1, 0.1, 0.1};
cpboriconm = {0.1, 0.3 , 0.3, 0.6};
-- Popup Msg Color Schema Alert
cpborpupmsga = {0.9, 0.1 , 0.1, 1};
cpcolpupmsga = {0.9, 0.6 , 0.4, 1};
cpfillpupbxa = {0.9, 0.1 , 0.1, 1};
cpborpupbxa = {0.9, 0.1 , 0.1, 1};
cpcolpupbxa = {0.9, 0.6 , 0.4, 1};
cpfillpupbtna = {0.9, 0.1 , 0.1, 1};
cpborpupbtna = {0.9, 0.1 , 0.1, 1};
cpcolpupbtna = {0.9, 0.6 , 0.4, 1};
-- Popup Msg Color Schema Warn
cpborpupmsgw = {0.8, 0.1 , 0.1, 1};
cpcolpupmsgw = {0.8, 0.5 , 0.3, 1};
cpfillpupbxw = {0.9, 0.1 , 0.1, 1};
cpborpupbxw = {0.9, 0.1 , 0.1, 1};
cpcolpupbxw = {0.9, 0.6 , 0.4, 1};
cpfillpupbtnw = {0.9, 0.1 , 0.1, 1};
cpborpupbtnw = {0.9, 0.1 , 0.1, 1};
cpcolpupbtnw = {0.9, 0.6 , 0.4, 1};
-- Popup Msg Color Schema Info
cpborpupmsgi = {0.7, 0.1 , 0.1, 1};
cpcolpupmsgi = {0.7, 0.5 , 0.4, 1};
cpfillpupbxi = {0.9, 0.1 , 0.1, 1};
cpborpupbxi = {0.9, 0.1 , 0.1, 1};
cpcolpupbxi = {0.9, 0.6 , 0.4, 1};
cpfillpupbtni = {0.9, 0.1 , 0.1, 1};
cpborpupbtni = {0.9, 0.1 , 0.1, 1};
cpcolpupbtni = {0.9, 0.6 , 0.4, 1};
cpcolheader = {0.6, 0.6 , 0.6, 0.9};
cpcolicon = {0.4, 0.6 , 0.4, 0.8};
};
};
lastwindow = defpos()
templates = {
GetOrbs = {"Get Satellites of Result Set","Get Locations of Result Set","Get Parents of Result Set","Summarize Result Set"};
ObsComm = {"Stop Observer","Turn Back","Speed Control","Observer Position Switch","Observer Rotation Switch","Free LUA/.celx Code","Settings Shortcuts"};
pausmenu = {"Pause/Resume","Cancel This","Cancel All"};
speedtab = {
s1_obsspeed = 0;
s3_increment = {0.01,valuelist = {0.01,0.1,1,10,100};};
s4_clutchon = true;
};
metaspeedtab = {
s1_obsspeed = {};
s3_increment = {"Increment",valuelist = {};};
s4_clutchon = {"Clutch is on"};
};
delims = {" ","*","#","I","-",":",";","|","][","]","[","}{","}","{","><",">","<",")(",")","(","/"};
equals = {" ",":",": ","=","= "," = "};
minMaxDefault = {
qr005_radius = {minv = 0;maxv = 8000000000};
qr006_luminosity = {minv = 0;maxv = 300000};
qr007_temperature = {minv = 0;maxv = 6000000};
qr008_absoluteMagnitude = {minv = -15;maxv = 40};
qr009_bolometricMagnitude = {minv = -15;maxv = 40};
qr018_oblateness = {minv = 0;maxv = 1};
qr019_albedo = {minv = 0;maxv = 1};
qr022_atmosphereHeight = {minv = 0;maxv = 100000000};
qr023_atmosphereCloudHeight = {minv = 0;maxv = 30000};
qr024_atmosphereCloudSpeed = {minv = 0;maxv = 100};
qr028_rotationPeriod = {minv = 0;maxv = 10000000000000};
qr029_orbitPeriod = {minv = 0;maxv = 4000000000000000};
qr100_dso_radius = {minv = 0;maxv = 8000000000};
qr202_size = {minv = 0;maxv = 30000};
qr203_importance = {minv = -1;maxv = 6000};
qr030_numPlanets = {minv = 0;maxv = math.huge};
qr025_Locations = {minv = 0;maxv = math.huge};
};
query = {
queryStars  = {
qr001_distance = {minv=0;maxv=2000*9.4605284e+012;};
qr002_name_str = "";
qr003_stellarClass = {{false,false,false,false,true,false,false,false,false,false,false,false,false},choicelist = {"O","B","A","F","G","K","M","R","N","S","X","W","D"}};
qr004_stellarClass_str = "";
qr005_radius = {minv=556800;maxv=835200};
qr006_luminosity = {minv=0.8;maxv=1.2};
qr007_temperature = {minv=5600;maxv=6100};
qr008_absoluteMagnitude = {minv=-8;maxv=35};
qr009_bolometricMagnitude = {minv=-10;maxv=28};
qr012_catalogNumber = {minv=0;maxv=99999999999};
qr028_rotationPeriod = {minv=20;maxv=30};
qr029_orbitPeriod = {minv=0.002;maxv=3200000000000000};
qr030_numPlanets = {minv=1;maxv=1000};
qr300_parent_str = "";
zz1_scan_fixpos = true;
zz1_scan_pure = false;
};
queryPlanets = {
qr001_distance = {minv=0;maxv=2000*9.4605284e+012};
qr002_name_str = "";
qr005_radius = {minv=637.8;maxv=63780};
qr016_type = {{false,false,false,false,false,false,false,false,false,false},choicelist = {"planet","dwarfplanet","moon","minormoon","asteroid","comet","spacecraft","diffuse","surfacefeature","invisible"}};
qr017_type_str = "";
qr018_oblateness = {minv=0;maxv=0.5};
qr019_albedo = {minv=0.05;maxv=0.9};
qr020_lifespanStart = {minv=-math.huge;maxv=math.huge};
qr021_lifespanEnd = {minv=-math.huge;maxv=math.huge};
qr022_atmosphereHeight = {minv=1;maxv=43000000};
qr023_atmosphereCloudHeight = {minv=0;maxv=200};
qr024_atmosphereCloudSpeed = {minv=0;maxv=1.5};
qr025_Locations = {minv=1;maxv=1000};
qr026_hasRings = false;
-- qr027_mass = {minv=0;maxv=7900};
qr028_rotationPeriod = {minv=0;maxv=2000};
qr029_orbitPeriod = {minv=0.002;maxv=3200000000000000};
qr030_numPlanets = {minv=1;maxv=1000};
qr300_parent_str = "";
qr302_infoURL = "";
qr999_isVisible = true;
zz1_scan_fixpos = true;
zz1_scan_pure = false;
zz1_scan_within = {"results", valuelist = {"results","descent"}};
};
queryDsos = {
qr001_distance = {minv=0;maxv=2000000*9.4605284e+012};
qr002_name_str = "";
qr008_absoluteMagnitude = {minv=-8;maxv=35};
qr016_type = {{false,false,false,false},choicelist = {"galaxy","globular","nebula","opencluster"}};
qr017_type_str = "";
qr100_dso_radius = {minv=0.01;maxv=7500000000};
qr101_hubbleType = {{false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false},choicelist = {"E0","E1","E2","E3","E4","E5","E6","E7","S0","Sa","Sb","Sc","SBa","SBb","SBc","Irr"}};
qr102_hubbleType_str = "";
qr999_isVisible = true;
zz1_scan_fixpos = true;
zz1_scan_pure = false;
};
queryLocations = {
qr001_distance = {minv=0;maxv=2000*9.4605284e+012};
qr002_name_str = "";
qr200_featureType = {{false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false},choicelist = {"city","observatory","landingsite","crater","vallis","mons","planum","chasma","patera","mare","rupes","tholus","tessera","regio","chaos","terra","astrum","corona","dorsum","fossa","catena","mensa","rima","undae","reticulum","planitia","linea","fluctus","farrum","volcano","insula","other"}};
qr201_featureType_str = "";
qr202_size = {minv=1;maxv=35000};
qr203_importance = {minv=1;maxv=5000};
qr300_parent_str = "";
qr302_infoURL = "";
zz1_scan_fixpos = true;
zz1_scan_pure = false;
zz1_scan_within = {"results", valuelist = {"results","descent"}};
};
};
metaQuery = {
zz1_scan_pure = {"Purify Results", valuelist = {"dummy"}};
zz1_scan_within = {"Scan Approach", valuelist = {"Scan Current Results","Get Result's Children"}};
zz1_scan_fixpos = {"Fixed Observer's Position"};
qr001_distance = {"Distance",1,0,math.huge,scan=true,negate=false};
qr002_name_str = {"Name",1,cprop="name",scan=false,negate=false};
qr003_stellarClass = {"Stellar Class",1,cprop="stellarClass",scan=true,negate=false};
qr004_stellarClass_str = {"Stellar Class (string)",1,scan=false,negate=false};
qr005_radius = {"Radius",1,0,8000000000,0,8000000000,cprop="radius",scan=true,negate=false};
qr006_luminosity = {"Luminosity",1,0,300000,0,300000,cprop="luminosity",scan=true,negate=false};
qr007_temperature = {"Temperature",1,0,6000000,0,6000000,cprop="temperature",scan=true,negate=false};
qr008_absoluteMagnitude = {"Absolute Magnitude",0.01,-15,40,-15,40,cprop="absoluteMagnitude",scan=false,negate=false};
qr009_bolometricMagnitude = {"Bolometric Magnitude",0.01,-15,40,-15,40,cprop="bolometricMagnitude",scan=false,negate=false};
qr012_catalogNumber = {"Default Catalog",1,0,math.huge,0,math.huge,cprop="catalogNumber",scan=false,negate=false};
qr016_type = {"Type",1,cprop="type",scan=true,negate=false};
qr017_type_str = {"Type (string)",1,scan=false,negate=false};
qr018_oblateness = {"Oblateness",0.01,0,1,0,1,cprop="oblateness",scan=true,negate=false};
qr019_albedo = {"Albedo",0.01,0,1,0,1,cprop="albedo",scan=true,negate=false};
qr020_lifespanStart = {"Lifespan Start",1,-math.huge,math.huge,-math.huge,math.huge,cprop="lifespanStart",scan=false,negate=false};
qr021_lifespanEnd = {"Lifespan End",1,-math.huge,math.huge,-math.huge,math.huge,cprop="lifespanEnd",scan=false,negate=false};
qr022_atmosphereHeight = {"Atmosphere Height",1,0,100000000,0,100000000,cprop="atmosphereHeight",scan=false,negate=false};
qr023_atmosphereCloudHeight = {"Atmosphere Cloud Height",1,0,300,0,300,cprop="atmosphereCloudHeight",scan=false,negate=false};
qr024_atmosphereCloudSpeed = {"Atmosphere Cloud Speed",1,0,10,0,10,cprop="atmosphereCloudSpeed",scan=false,negate=false};
qr025_Locations = {"Locations",1,1,math.huge,1,math.huge,cprop="locations",scan=false,negate=false};
qr026_hasRings = {"Has Rings",1,cprop="hasRings",scan=false,negate=false};
-- qr027_mass = {"",1,cprop="mass"};
qr028_rotationPeriod = {"Rotation Period",1,0,10000000000000,0,10000000000000,cprop="rotationPeriod",scan=true,negate=false};
qr029_orbitPeriod = {"Orbit Period",1,0,4000000000000000,0,4000000000000000,cprop="orbitPeriod",scan=false,negate=false};
qr030_numPlanets = {"Satellites",1,1,math.huge,1,math.huge,cprop="getchildren",scan=false,negate=false};
qr100_dso_radius = {"DSO Radius",1,0,8000000000,0,8000000000,cprop="dsoradius",scan=false,negate=false};
qr101_hubbleType = {"Hubble Type",1,cprop="hubbleType",scan=false,negate=false};
qr102_hubbleType_str = {"Hubble Type (string)",1,scan=false,negate=false};
qr200_featureType = {"Feature Type",1,cprop="featureType",scan=false,negate=false};
qr201_featureType_str = {"Feature Type (string)",1,scan=false,negate=false};
qr202_size = {"Size",1,0,30000,0,30000,cprop="size",scan=false,negate=false};
qr203_importance = {"Importance",1,-1,5000,-1,5000,cprop="importance",scan=false,negate=false};
qr300_parent_str = {"Parent",1,cprop="parent",scan=false,negate=false};
qr302_infoURL = {"Info URL",1,cprop="infoURL",scan=false,negate=false};
qr999_isVisible = {"Is Visible (in Celestia)",1,cprop="visible",scan=false,negate=false};
q_dummy = {"unspecified",1};
z_get_bodies = {"Orbiting Bodies",1};
z_get_parents = {"Parents",1};
z_transfer_parents = {"Transfer Parents",1};
z_transfer_bodies = {"Transfer Bodies",1};
z_transfer_objects = {"Transfer Objects",1};
z_get_locations = {"Locations",1};
z_transfer_locations = {"Transfer Locations",1};
z_has_bodies = {"Has Planets",1};
z_postprocess = {"Postprocess Objects",1};
};
marker = {
selshape = {"disk",valuelist = {"square","circle","disk","diamond","triangle","x","plus","filledsquare","leftarrow","rightarrow","uparrow","downarrow"};};
selcolor = {"blue",valuelist = {"lime", "red", "green", "yellow", "blue", "orange", "white", "black", "brown", "cyan", "gold", "silver"};};
refmarkParams = {
srctgt = {"objtosel",valuelist = {"objtosel","seltoobj"};};
rtype = {"body to body direction",valuelist = {"body to body direction","visible region"};};
rsize = 1000;
rcolor = {};
ropacity = 1.0;
zrtag = {"allloc",valuelist = {"allloc","allglob"};};
};
metaRefmarkParams = {
srctgt = {"From-To",valuelist = {"object to selection","selection to object"};};
rtype = {"Reference Type"};
rsize = {"Reference Size",1,0.001,math.huge};
rcolor = {"Reference Color"};
ropacity = {"Opacity",0.1,0,1};
zrtag = {"Tag (for Remove only)",valuelist = {"remove marks from the object","remove all marks from Celestia"}};
};
};
unitsConst = {
distance = {
km = 1;
ly = 9.4605284e+012;
AU = 149597870;
pc = 3.0857e+13;
mi = 1.609344;
};
duration = {
mins = 60;
hours = 3600;
};
radius = {
RSUN = 696000;
REARTH = 6378;
mi = 1.609344;
};
dso_radius = {
pc = 3.2617;
km = 9.4605284e+012;
mi = 5.87849981e+12;
};
temperature = {
Cels = 273.15;
};
luminosity = {
GW = 3.839e+020;
};
period = {
hours = 24;
years = 365;
};
atmspeed = {
ms = 1000/60;
kmh = 60;
mph = 60000/1609.344
};
obsspeed = {
ulys = 1;
lys = 0.000001;
c = (9460730.4725808/299792.458);
mis = 5912956.5453630;
kms = 9460730.4725808;
ms = 9460730472.5808;
};
angle = {
deg = math.deg(1);
arcsec = 206264.806247;
};
};
metaUnits = {
qr001_distance = {"ly",
valuelist = {
"ly","km","AU","pc","mi"
};
};
qr005_radius = {"km",
valuelist = {
"km","Rsun","Rearth","mi"
};
};
qr100_dso_radius = {"ly",
valuelist = {
"ly","pc","km","mi"
};
};
qr007_temperature = {"K",
valuelist = {
"K","C","F"
};
};
qr006_luminosity = {"xSun",
valuelist = {
"xSun","GW",
};
};
qr028_rotationPeriod = {"days",
valuelist = {
"days","hours","years"
};
};
qr029_orbitPeriod = {"days",
valuelist = {
"days","hours","years"
};
};
qr022_atmosphereHeight = {"km",
valuelist = {
"km","mi"
};
};
qr023_atmosphereCloudHeight = {"km",
valuelist = {
"km","mi"
};
};
qr024_atmosphereCloudSpeed = {"m/s",
valuelist = {
"m/s","km/h","mph",
};
};
qr020_lifespanStart = {"TDB",
valuelist = {
"TDB","Y/M/D h:m:s",
};
};
};
celcmds = {
goto = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local intpl = paramtab[2]
	obs:goto(obj,tim,intpl[1],intpl[2])
end;
gotodistance = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local dist = paramtab[2]
	local vect = paramtab[3]
	obs:gotodistance(obj,dist,tim,celestia:newvector(vect[1],vect[2],vect[3]))
end;
gotolonglat = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local dist = paramtab[2]
	local longlat = paramtab[3]
	local vect = paramtab[4]
	obs:gotolonglat(obj,longlat[1],longlat[2],dist,tim,celestia:newvector(vect[1],vect[2],vect[3]))
end;
gotolocation = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local posit = paramtab[2]
	obs:gotolocation(celestia:newposition(posit[1],posit[2],posit[3]),tim)
end;
setposition = function(obs,obj,paramtab)
	local posit = paramtab[1]
	obs:setposition(celestia:newposition(posit[1],posit[2],posit[3]))
end;
gotosurface = function(obs,obj,paramtab)
	local tim = paramtab[1]
	obs:gotosurface(obj,tim)
end;
center = function(obs,obj,paramtab)
	local tim = paramtab[1]
	obs:center(obj,tim)
end;
centerorbit = function(obs,obj,paramtab)
	local tim = paramtab[1]
	obs:centerorbit(obj,tim)
end;
mark = function(obs,obj,paramtab)
	local mcolor, mshape, msize, mopaque, mocclud = paramtab[1], paramtab[2], paramtab[3], paramtab[4], paramtab[5]
	obj:mark(mcolor, mshape, msize, mopaque, "", mocclud)
end;
unmark = function(obs,obj,paramtab)
	obj:unmark();
end;
rotate = function(obs,obj,paramtab)
	local vect = paramtab[1]
	local angle = paramtab[2]
	obs:rotate(celestia:newrotation(celestia:newvector(vect[1],vect[2],vect[3]),angle))
end;
select = function(obs,obj,paramtab)
	celestia:select(obj);
end;
follow = function(obs,obj,paramtab)
	obs:follow(obj)
end;
track = function(obs,obj,paramtab)
	obs:track(obj)
end;
untrack = function(obs,obj,paramtab)
	obs:track(nil)
end;
chase = function(obs,obj,paramtab)
	obs:chase(obj)
end;
lock = function(obs,obj,paramtab)
	obs:lock(obj)
end;
synchronous = function(obs,obj,paramtab)
	obs:synchronous(obj)
end;
orbit = function(obs,obj,paramtab,finder,parser)
	if obs.orbit then
		local tim = paramtab[1]
		local frm = paramtab[2]
		local rate = paramtab[3]
		local vect = paramtab[4]
		local vector = celestia:newvector(vect[1],vect[2],vect[3])
		local nrate = rate
		obs:setframe(celestia:newframe(frm,obj))
		local tstart = os.clock();
		local rot, frozen, telap
		local orbitParser = CPLoopPars:new({tCelPad.Parsers})
		orbitParser:init("orbitParser",1,
		function(o)
			if not frozen then
				telap = os.clock() - tstart
				nrate = rate*timedelta
				rot = celestia:newrotation(vector, nrate)
				obs:orbit(rot)
			else
				tstart = os.clock() - telap
			end;
		end,
		function(o)
			if frozen then
				return false
			else
				return ((telap >= tim) or (parser and parser.cmdtimer and parser.cmdtimer.timetoend <= 0) or (finder.paused) or (parser and not parser.cmdtimer))
			end
		end,
		function(o)
		end,
		function(o)
			if parser and parser.cmdtimer then
				if parser.cmdtimer.status == "frozen" then
					frozen = true;
				else
					frozen = false;
				end
			end
		end
		);
		orbitParser:makeBranch(finder);
	else
		cmdError(finder,parser,"command 'orbit' not supported in this Celestia version")
	end;
end;
freecmd = function(obs,obj,paramtab,finder,parser)
	local command = paramtab[1]
	finder.env = finder.env or {
	assert = assert;
	error = error;
	ipairs = ipairs;
	next = next;
	pairs = pairs;
	pcall = pcall;
	select = select;
	tonumber = tonumber;
	tostring = tostring;
	type = type;
	unpack = unpack;
	_VERSION = _VERSION;
	xpcall = xpcall;
	print = CPlog;
	celestia = celestia;
	math_dround = math_dround;
	obj = obj;
	obs = obs;
	sel = celestia:getselection();
	wait = wait;
	wlog = finder.sysLog;
	checklog = finder.checklog;
	cancelthis = finder.cancelthis;
	cancelall = finder.cancelall;
	pause = finder.pause;
	resume = finder.resume;
	};
	finder.env.math = finder.env.math or {
	abs = math.abs;
	acos = math.acos;
	asin = math.asin;
	atan = math.atan;
	atan2 = math.atan2;
	ceil = math.ceil;
	cos = math.cos;
	cosh = math.cosh;
	deg = math.deg;
	exp = math.exp;
	floor = math.floor;
	fmod = math.fmod;
	frexp = math.frexp;
	huge = math.huge;
	ldexp = math.ldexp;
	log = math.log;
	log10 = math.log10;
	max = math.max;
	min = math.min;
	modf = math.modf;
	pi = math.pi;
	pow = math.pow;
	rad = math.rad;
	random = math.random;
	sin = math.sin;
	sinh = math.sinh;
	sqrt = math.sqrt;
	tan = math.tan;
	tanh = math.tanh;
	};
	finder.env.coroutine = finder.env.coroutine or {
	create = coroutine.create;
	resume = coroutine.resume;
	running = coroutine.running;
	status = coroutine.status;
	wrap = coroutine.wrap;
	yield = coroutine.yield;
	};
	finder.env.string = finder.env.string or {
	byte = string.byte;
	char = string.char;
	find = string.find;
	format = string.format;
	gmatch = string.gmatch;
	gsub = string.gsub;
	len = string.len;
	lower = string.lower;
	match = string.match;
	rep = string.rep;
	reverse = string.reverse;
	sub = string.sub;
	upper = string.upper;
	};
	finder.env.table = finder.env.table or {
	insert = table.insert;
	maxn = table.maxn;
	remove = table.remove;
	sort = table.sort;
	};
	finder.env.io = finder.env.io or {
	read = io.read;
	write = io.write;
	flush = io.flush;
	type = io.type;
	};
	finder.env.os = finder.env.os or {
	clock = os.clock;
	difftime = os.difftime;
	time = os.time;
	};
	-- lua sandbox, thanx to http://lua-users.org/wiki/ReadOnlyTables and http://lua-users.org/wiki/SandBoxes
	local function readonlytable(tbl)
		return setmetatable({},{
		__index = tbl,
		__newindex = function(tbl, key, value)
			cmdError(finder,parser,"Attempt to modify read-only table.")
		end,
		__metatable = false
		});
	end
	local function run_sbox(ucode)
		if ucode:byte(1) == 27 then return nil, "binary bytecode prohibited" end
		local ufnc, message = loadstring(ucode)
		if not ufnc then return nil, message end
		setfenv(ufnc, finder.env)
		if finder.cmdset then
			finder.env.cmdi = parser.ik or finder.cmdset.ik;
		else
			finder.env.cmdi = parser.ik or finder.env.cmdi
		end
		finder.env.resultSet = readonlytable(finder.resultSet)
		finder.env.obj = obj or finder.env.obj;
		finder.env.obs = obs;
		finder.env.sel = celestia:getselection();
		return pcall(ufnc)
	end
	local exstat, cmdexec = run_sbox(command)
	if not exstat then
		cmdError(finder,parser,string.gsub(cmdexec,"^[\[]string \"(.*)\"[\]]","%1"))
	end
	return exstat, cmdexec
end;
cancelgoto = function(obs,obj,paramtab)
	obs:cancelgoto()
end;
setspeed = function(obs,obj,paramtab)
	local spd = paramtab[1]
	obs:setspeed(spd)
end;
setframe = function(obs,obj,paramtab)
	local frm = paramtab[1]
	obs:setframe(celestia:newframe(frm,obj))
end;
preloadtexture = function(obs,obj,paramtab)
	obj:preloadtexture()
end;
};
inputParam = {
dly = {
data = tSettings.SystemSet.ms150defDur;
meta = {"D[sec]",1,0,9999};
};
zcmdduration = {
data = tSettings.SystemSet.ms150defDur;
meta = {"Duration",1,0,86400};
describe = "Sets the time the command should take. This parameter is passed to the command and is independent from delay ('D[sec]') value.";
};
zcmddistaarc = {
data = 3;
meta = {"xR",0.1,0,math.huge};
describe = "The distance from object's center as an multiplier of its radius. If set to 0, current 'Distance' value is used.";
};
zcmddistance = {
data = 100;
meta = {"Distance",1,0,math.huge};
describe = "Defines or shows (if 'xR' parameter is other than 0) the distance from object's center.";
};
zcmdposition = {
data = {0,0,0};
meta = {"Position",0.01,-math.huge,math.huge};
describe = "The position in universal coordinates.";
};
zcmdvector = {
data = {0,1,0};
meta = {"Vector",0.1,-1,1};
describe = "The 'x','y','z' orientation vector.";
};
zcmdlonglat = {
data = {0,0};
meta = {"Long./Lat.",0.1,math_dround(-2*math.pi,2),math_dround(2*math.pi,2)};
describe = "Surface longitude and latitude coordinates";
};
zcmdintpol = {
data = {0.25,0.75};
meta = {"Start/End Interp.",0.01,0,1};
describe = "Sets the point in time (expressed as a percent number between 0 and 1)  at which the observer should begin and finish turning from the initial orientation to the final orientation.";
};
zcmdangle = {
data = 0;
meta = {"Angle",0.1,math_dround(-2*math.pi,2),math_dround(2*math.pi,2)};
describe = "The angle in which the observer should rotate.";
};
zcmdrate = {
data = 1;
meta = {"Rate",0.01,-math.huge,math.huge};
describe = "The rate of circling the object. It is the angle in which observer orbits the object in one second.";
};
zmkp1color = {
data = {};
meta = {"Marker Color"};
describe = "Sets the marker color. It offers the selection list of available colors.";
};
zmkp2shape = {
data = {};
meta = {"Marker Shape"};
describe = "Offers the selection list of available marker shapes.";
};
zmkp3size = {
data = 10;
meta = {"Marker Size",1,1,1000};
describe = "Sets the marker size.";
};
zmkp4opaque = {
data = 1;
meta = {"Opaque",0.1,0,1};
describe = "Sets opacity of the marker. 1-fully opaque, 0-fully transparent.";
};
zmkp5occlud = {
data = true;
meta = {"Occludable"};
describe = "If marker is occludable, it is hidden by objects in front of it.";
};
zcmdfreecmd = {
data = "";
meta = {"Command"};
describe = "Line for LUA (.cexl) code. In theory, its length is limited by memory only, however, the dialog is not prepared to exceed the screen width.";
};
zcmdframe = {
data = {"equatorial", valuelist = {"universal","ecliptic","equatorial","planetographic","observer","lock","chase"};};
meta = {"Frame",valuelist = {};};
describe = "Defines the reference frame.";
};
zcmdspeed = {
data = 0;
meta = {"Obs. Speed",1,-math.huge,math.huge};
describe = "Sets observer's speed. Note, that due to rounding error only 'c' and bigger units are available for comand set (unlike Observer commands, where you can go down to 'm/s').";
};
s1_obsspeed = {
data = 0;
meta = {"",1,-math.huge,math.huge};
};
};
cmdopts = {
data = {
co01startobj = nil;
co02endobj = nil;
co03repeatloop = false;
co04maxCmdHist = 10;
};
meta = {
co01startobj = {"Starting Object",1,1,math.huge};
co02endobj = {"Ending Object",1,1,math.huge};
co03repeatloop = {"Repeat Process"};
co04maxCmdHist = {"Max. Code History",1,1,20};
};
};
vwindx = {
stars = "stars";
satellites = "satellites";
dsos = "dsos";
locations = "locations";
getorbs = "satellites";
getlocs = "locations";
getpars = "stars";
};
tts = {
profile = {};
GUI = {};
QRstars = {};
QRsatellites = {};
QRdsos = {};
QRlocations = {};
VW = {};
SUM = {};
SYS = {};
CMDS = {};
};
};
templates.metaUnits.qr021_lifespanEnd = deepcopy(templates.metaUnits.qr020_lifespanStart);
templates.marker.refmarkParams.rcolor = deepcopy(templates.marker.selcolor);
templates.inputParam.zmkp1color.data = deepcopy(templates.marker.selcolor);
templates.inputParam.zmkp2shape.data = deepcopy(templates.marker.selshape);
templates.metaUnits.zcmddistance = {
"km",
valuelist = {
"km","ly","AU","pc","mi"
};
};
templates.metaUnits.zcmdduration = {
"sec",
valuelist = {
"sec","min","hour"
};
};
templates.metaUnits.zcmdangle = {
"rad",
valuelist = {
"rad","deg","arcsec"
};
};
templates.metaUnits.zcmdlonglat = deepcopy(templates.metaUnits.zcmdangle);
templates.metaUnits.zcmdrate = {
"rad/s",
valuelist = {
"rad/s","deg/s"
};
};
templates.metaUnits.zcmdspeed = {
"uly/s",
valuelist = {
"uly/s","ly/s","c",
};
};
templates.metaQuery.zcmddistance = {templates.inputParam.zcmddistance.meta[1].." (command/info)"};
templates.metaQuery.zcmdduration = {templates.inputParam.zcmdduration.meta[1].." (command)"};
templates.metaQuery.zcmdangle = {templates.inputParam.zcmdangle.meta[1].." (command)"};
templates.metaQuery.zcmdlonglat = {templates.inputParam.zcmdlonglat.meta[1].." (command)"};
templates.metaQuery.zcmdrate = {templates.inputParam.zcmdrate.meta[1].." (command)"};
templates.metaQuery.zcmdspeed = {templates.inputParam.zcmdspeed.meta[1].." (command)"};
templates.cpcmds = {
sleep = {
fnc = function() end;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'sleep' command doesn't do any action. It's meant to be used solely for the time delay controlled by '"..templates.inputParam.dly.meta[1].."' value.",
txtfnt = {"normalfont"};
sev = "i";
};
};
goto = {
fnc = templates.celcmds.goto;
args = "dly zcmdduration zcmdintpol";
describe = {
"< autowrap >",
"<-70",
"'goto' command is equivalent of Celestia's 'observer:goto(object, duration, start_interpolation, end_interpolation)'. It moves observer near the processed object in specified time using specified interpolation points.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
templates.inputParam.zcmdintpol.meta[1].."`->"..templates.inputParam.zcmdintpol.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
gotodistance = {
fnc = templates.celcmds.gotodistance;
args = "dly zcmdduration zcmddistaarc zcmddistance zcmdvector";
describe = {
"< autowrap >",
"<-70",
"'gotodistance' command is equivalent of Celestia's 'observer:gotodistance(object, distance, duration, vector:up-axis)'. Moves observer to specified distance from the processed object in duration seconds, with up-axis pointing up.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
templates.inputParam.zcmddistaarc.meta[1].."`->"..templates.inputParam.zcmddistaarc.describe;
templates.inputParam.zcmddistance.meta[1].."`->"..templates.inputParam.zcmddistance.describe;
templates.inputParam.zcmdvector.meta[1].."`->"..templates.inputParam.zcmdvector.describe.." Defines which axis points up.";
txtfnt = {"normalfont"};
sev = "i";
};
};
gotolonglat = {
fnc = templates.celcmds.gotolonglat;
args = "dly zcmdduration zcmddistaarc zcmddistance zcmdlonglat zcmdvector";
describe = {
"< autowrap >",
"<-70",
"'gotolonglat' command is equivalent of Celestia's 'observer:gotolonglat(object, longitude, latitude, distance, duration, vector:up-axis)'. Moves observer to the processed object's position above the longitude/latitude surface coordinates in duration seconds, with given distance of the object and up-axis pointing up.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
templates.inputParam.zcmddistaarc.meta[1].."`->"..templates.inputParam.zcmddistaarc.describe;
templates.inputParam.zcmddistance.meta[1].."`->"..templates.inputParam.zcmddistance.describe;
templates.inputParam.zcmdlonglat.meta[1].."`->"..templates.inputParam.zcmdlonglat.describe;
templates.inputParam.zcmdvector.meta[1].."`->"..templates.inputParam.zcmdvector.describe.." Defines which axis points up.";
txtfnt = {"normalfont"};
sev = "i";
};
};
gotolocation = {
fnc = templates.celcmds.gotolocation;
args = "dly zcmdduration zcmdposition";
describe = {
"< autowrap >",
"<-70",
"'gotolocation' command is equivalent of Celestia's 'observer:gotolocation(position, duration)'. Moves observer to defined position in defined duration time.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
templates.inputParam.zcmdposition.meta[1].."`->"..templates.inputParam.zcmdposition.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
setposition = {
fnc = templates.celcmds.setposition;
args = "dly zcmdposition";
describe = {
"< autowrap >",
"<-70",
"'setposition' command is equivalent of Celestia's 'observer:setposition(position)'. Sets the new position of the observer.",
"",
templates.inputParam.zcmdposition.meta[1].."`->"..templates.inputParam.zcmdposition.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
gotosurface = {
fnc = templates.celcmds.gotosurface;
args = "dly zcmdduration";
describe = {
"< autowrap >",
"<-70",
"'gotosurface' command is equivalent of Celestia's 'observer:gotosurface(object, duration)'. Moves observer to the surface of the given object and sets the view at the horizon.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
center = {
fnc = templates.celcmds.center;
args = "dly zcmdduration";
describe = {
"< autowrap >",
"<-70",
"'center' command is equivalent of Celestia's 'observer:center(object, duration)'. Rotates the observer view so that the target object is centered on the screen.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
centerorbit = {
fnc = templates.celcmds.centerorbit;
args = "dly zcmdduration";
describe = {
"< autowrap >",
"<-70",
"'centerorbit' command is equivalent of Celestia's 'observer:centerorbit(object, duration)'. Orbits the object used as the reference in the current frame such that the target becomes centered within duration seconds.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
rotate = {
fnc = templates.celcmds.rotate;
args = "dly zcmdvector zcmdangle";
describe = {
"< autowrap >",
"<-70",
"'rotate' command is equivalent of Celestia's 'observer:rotate(rotation)'. Rotates the observer, according the given rotation.",
"",
templates.inputParam.zcmdvector.meta[1].."`->"..templates.inputParam.zcmdvector.describe;
templates.inputParam.zcmdangle.meta[1].."`->"..templates.inputParam.zcmdangle.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
mark = {
fnc = templates.celcmds.mark;
args = "dly zmkp1color zmkp2shape zmkp3size zmkp4opaque zmkp5occlud";
describe = {
"< autowrap >",
"<-70",
"'mark' command is equivalent of Celestia's 'object:mark(color, symbol, size, opacity, label=\"\", occludable)'. Places a marker on the processed object. In this case, 'label' (fifth parameter) is always an empty string.",
"Note: If you want to change marker on already marked object, you must remove existing marker first. See 'unmark' command.",
"",
templates.inputParam.zmkp1color.meta[1].."`->"..templates.inputParam.zmkp1color.describe;
templates.inputParam.zmkp2shape.meta[1].."`->"..templates.inputParam.zmkp2shape.describe;
templates.inputParam.zmkp3size.meta[1].."`->"..templates.inputParam.zmkp3size.describe;
templates.inputParam.zmkp4opaque.meta[1].."`->"..templates.inputParam.zmkp4opaque.describe;
templates.inputParam.zmkp5occlud.meta[1].."`->"..templates.inputParam.zmkp5occlud.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
unmark = {
fnc = templates.celcmds.unmark;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'unmark' command removes marker from the processed object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
select = {
fnc = templates.celcmds.select;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'select' command is equivalent of Celestia's 'celestia:select(object)'. Sets the current selection to the processed object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
follow = {
fnc = templates.celcmds.follow;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'follow' command is equivalent of Celestia's 'observer:follow(object)'. Activates follow-mode on processed object. 'follow' is the same as setting the frame of reference to \"ecliptical\" with target as reference object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
track = {
fnc = templates.celcmds.track;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'track' command is equivalent of Celestia's 'observer:track(object)'. Sets tracking on object, i.e. always keeps the processed object centered on the screen as it moves through space.",
txtfnt = {"normalfont"};
sev = "i";
};
};
untrack = {
fnc = templates.celcmds.untrack;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'untrack' command cancels tracking mode of the processed object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
chase = {
fnc = templates.celcmds.chase;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'chase' command is equivalent of Celestia's 'observer:chase(object)'. Activates chase-mode on the processed object. Chase-mode is the same as setting the frame of reference to \"chase\" with target as reference object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
lock = {
fnc = templates.celcmds.lock;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'lock' command is equivalent of Celestia's 'observer:lock(object)'. Activate lock-mode on the axis from the current reference object to the target object. Lock-mode is the same as setting the frame of reference to 'lock' with target as target-object and the current reference object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
synchronous = {
fnc = templates.celcmds.synchronous;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'synchronous' command is equivalent of Celestia's 'observer:synchronous(object)'. Activates synchronous-mode on the processed object. Synchronous-mode is the same as setting the frame of reference to \"planetographic\" (a.k.a. \"geographic\"), with target as reference object.",
txtfnt = {"normalfont"};
sev = "i";
};
};
orbit = {
fnc = templates.celcmds.orbit;
args = "dly zcmdduration zcmdframe zcmdrate zcmdvector";
describe = {
"< autowrap >",
"<-70",
"'orbit' command circles observer around the processed object. This command is based on Celestia's 'observer:rotate(rotation)' command, used in scripted process. Unlike with other commands, cancel or pause stops orbiting immediately.",
"",
"Note: This command is available for Celestia 1.6.1 only.",
"",
templates.inputParam.zcmdduration.meta[1].."`->"..templates.inputParam.zcmdduration.describe;
templates.inputParam.zcmdframe.meta[1].."`->"..templates.inputParam.zcmdframe.describe;
templates.inputParam.zcmdrate.meta[1].."`->"..templates.inputParam.zcmdrate.describe;
templates.inputParam.zcmdvector.meta[1].."`->"..templates.inputParam.zcmdvector.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
freecmd = {
fnc = templates.celcmds.freecmd;
args = "dly zcmdfreecmd";
describe = {
"< autowrap >",
"<-80",
"'freecmd' command allows running free (sandboxed) LUA code, as in .celx scripts, including Celestia commands. Note that this gives you possibility to write loops which can cause Lua hook timeouts if they don't finish on time. Use this command with caution. Celestia's 'wait' command is not available as it is not supported in hooked code.",
"",
"The code environment is unique per window. It means, if you use global variables, they are shared within the Selection Pad amongst all command lines in the command set, but they are not accessible from other Selection Pad windows.",
"",
templates.inputParam.zcmdfreecmd.meta[1].."`->"..templates.inputParam.zcmdfreecmd.describe;
"",
"There are specific global items that can be used with free commands:",
"object 'obs'`->Observer object. In example to move observer to processed object in 15 seconds, write 'obs:goto(obj,15)'.",
"object 'sel'`->Current selection. In example to center currently selected object in 5 seconds, write 'obs:center(sel,5)'.",
"Following items are available on processed objects only (not applicable if running commands from within 'Observer Commands' menu):",
"object 'obj'`->Object, that is currently processed. In example, to print current Celestia object name and type, write 'print(obj:name()); print(obj:getinfo().type)'.",
"table 'resultSet'`->Read-only table of Celestia objects in current window. In example, to get fifth object in list and print its name, you can use 'object5 = resultSet[5]; print(object5:name())'.",
"variable 'cmdi'`->The integer, index of currently processed object. In example, to log current object's name, use 'print(resultSet[cmdi]:name())'.",
"pointer 'wlog'`->Pointer to current window log for 'print' command. If not used (in example 'print(\"your text\")', the output goes to Celestia log. To print into Selection Pad window's log, use syntax 'print(\"your text\",0,wlog)'.",
"function 'checklog()'`->Forces window log to write to a new line. If you put this command to the end of the command set, each processed object is logged to a separate line.",
"function 'cancelthis()'`->Cancels current command. Can be used in example with condition, i.e. 'if obj:getinfo().parent then obs:center(obj:getinfo().parent,5) else cancelthis() end'. This command centers to object's parent if there's any. If object does not have a parent, this command is not executed.",
"function 'cancelall()'`->Cancels all remaining commands. Can be used in example with condition, i.e. 'if obj:getinfo().type == \"moon\" then cancelall() end'. This command skips the rest of the command set (commands are not performed) if processed object is 'moon'.",
"function 'pause()'`->Pauses current command. Resume can be done manually via 'Command Set Panel' or by 'resume()' function used in pop-up menu command within the same finder (applied at any object).",
"function 'resume()'`->Resumes paused command where applicable. I.e. if command set process is running and particular command is paused (not the whole process, just one command), 'resume()' function called from pop-up menu of any object from given finder resumes the action.",
"",
"Errors in code are indicated with log entry and pop-up message. If error occures, command set process is cancelled.",
txtfnt = {"normalfont"};
sev = "i";
};
};
cancelgoto = {
fnc = templates.celcmds.cancelgoto;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'cancelgoto' command is equivalent of Celestia's 'observer:cancelgoto()'. Stops any goto or center command currently in progress. It does not stop observer's movement set by 'setspeed' command or with Observer interactive commands.",
txtfnt = {"normalfont"};
sev = "i";
};
};
setspeed = {
fnc = templates.celcmds.setspeed;
args = "dly zcmdspeed";
describe = {
"< autowrap >",
"<-70",
"'setspeed' command is equivalent of Celestia's 'observer:setspeed(speed)'. Sets the speed of the observer.",
"",
templates.inputParam.zcmdspeed.meta[1].."`->"..templates.inputParam.zcmdspeed.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
setframe = {
fnc = templates.celcmds.setframe;
args = "dly zcmdframe";
describe = {
"< autowrap >",
"<-70",
"'setframe' command is combination of Celestia's 'celestia:newframe(frame,object)' and 'observer:setframe(newframe)' commands. Sets the new frame of reference for the observer.",
"",
templates.inputParam.zcmdframe.meta[1].."`->"..templates.inputParam.zcmdframe.describe;
txtfnt = {"normalfont"};
sev = "i";
};
};
preloadtexture = {
fnc = templates.celcmds.preloadtexture;
args = "dly";
describe = {
"< autowrap >",
"<-70",
"'preloadtexture' command tries to load all textures for the object from disk into the memory of your graphic card. Don't preload more than approx. 200 objects in advance, otherwise stability issues may occure.",
"",
txtfnt = {"normalfont"};
sev = "i";
};
};
};
templates.metaspeedtab.s1_obsspeed = deepcopy(templates.inputParam.zcmdspeed.meta)
templates.metaspeedtab.s1_obsspeed[2] = templates.speedtab.s3_increment[1]
templates2 = {
popMsg = {
FirstRun = { --i
"< autowrap >",
"<-90",
"Welcome to CelPad v."..CPver..".",
"",
"Click on CelPad square (little box below this message) to bring up the Control Panel. Then right click on Control Panel to get CelPad functions menu. CelPad windows and menu panes can be dragged to any desired position on the screen and their visibility can be turned ON or OFF.",
"",
"In general, you can use left and right mouse clicks on various parts of CelPad's graphical interface to obtain some action (bring up the menu pane, run some process, hide/show GUI elements etc.). Double clicks are not implemented in this version. You can change and save CelPad's appearence or behaviour in personalized settings, editable via this graphical interface.",
"",
"Please read Help panes ('?' buttons) for detailed information about CelPad usage and settings. Make sure to follow Performance Considerations to prevent LUA hook timeouts, which are fatal and require restart of Celestia. Main Help panes are available from 'CelPad Help' menu after clicking on '?' button on Control Panel's top bar. Another detailed information can be found in context Help panes after clicking on particular menu's '?' button where available.",
"",
txtfnt = {"bigfont","normalfont"};
sev = "i";
title = "Hello World";
};
PopResetDeflt = { --w
"Reset to defaults?",
txtfnt = {"normalfont"};
sev = "w";
title = "Reset";
};
CloseSetMSG = { --w
"Settings panes are open for a long time with no activity.",
"Open settings panes cause continuous global variables",
"update which can affect overall CelPad performance.",
"",
"It is recommended to keep them open only when editing.",
"",
"Do you want to close settings panes now?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
SystemSlowMSG = { --w
"System slow, adaptive loops were automatically turned ON.",
"You can turn them OFF later in system settings.",
"",
"Warning: Do not turn them OFF while CelPad is processing.",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
slowWarnMSG = { --w
"The system is rather slow, this action",
"can result in Lua hook timeouts.",
"Are you sure you want to continue?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
ClosingCPMSG = { --w
"CelPad Closing, please wait for cleanup finish.",
"This can take some time...",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
SaveFailMSG	= { --a
"Saving/loading of ",
" profile failed!",
"Celestia cannot access CelPad profiles directory:",
"< Celestia dir >/",
"CelPad needs to save profile data for its proper operations, otherwise various",
"errors may occure. Make sure that profile directory exists and is writable for Celestia.",
txtfnt = {"bigfont","smallfont","normalfont","normalfont","smallfont"};
sev = "a";
title = "Alert";
};
SavingMSG = { --w
"Saving ",
"Please wait, this can take a few seconds...",
"Warning: Mouse clicks are disabled during the save process.",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
CPquitOK = { --a
"Are you sure you want to quit CelPad?",
txtfnt = {"bigfont"};
sev = "a";
title = "Quit";
};
nullBaseMSG = { --w
"Base scan returned no results.",
"Check distance or ",
" parameters.",
txtfnt = {"bigfont","normalfont"};
sev = "w";
title = "Warning";
};
RetainSetMSG = { --w
"No objects found.",
"Do you want to keep latest non-zero result set?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
RetainSetStgMSG = { --w
"Stage ",
" returned 0 objects.",
"Do you want to keep latest non-zero result set?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
PopMSGoverwrite = { --a
"Overwrite existing profile",
txtfnt = {"normalfont"};
sev = "a";
title = "Overwite";
};
PopMSGdelete = { --a
"Delete profile ",
txtfnt = {"normalfont"};
sev = "a";
title = "Delete";
};
noDefDelMSG = { --w
"Profile 'default' cannot be deleted.",
txtfnt = {"normalfont"};
sev = "w";
title = "Delete";
};
PopMSGOKwf = { --w
"Item cannot be picked when lines",
"are wrapped or display filtered.",
txtfnt = {"bigfont","bigfont"};
sev = "w";
title = "Warning";
};
PopMSGOKw = { --w
"Item cannot be picked",
"when lines are wrapped.",
txtfnt = {"bigfont","bigfont"};
sev = "w";
title = "Warning";
};
PopMSGnoLitem = { --w
"No log item in this area.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
PopMSGnoitem = { --w
"No item in this area.",
"Right click on top bar for menu.",
txtfnt = {"bigfont","smallfont"};
sev = "w";
title = "Warning";
};
popNoSel = { --w
"No object selected in Celestia.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
PopRstPosMSG = { --w
"This will set all windows positions to default.",
"Close all windows before continuing,",
"otherwise defaults will be overwritten",
"if you close them later.",
"",
"Reset windows positions?",
txtfnt = {"normalfont"};
sev = "w";
title = "Reset";
};
PopMSGosavpos = { --w
"Save windows positions?",
txtfnt = {"normalfont"};
sev = "w";
title = "Overwite";
};
CloseWinMSG = { --a
"Are you sure you want to close this window?",
"Closing from menu does not save the position.",
txtfnt = {"bigfont","smallfont"};
sev = "a";
title = "Alert";
};
ClearLogMSG = { --a
"Clear log '",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
ClearSetMSG = { --a
"Clear results?",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
itemPopRunMSG = { --w
"Item pop-up for ",
" already running.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
PopTgtBusy = { --w
"Target busy.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
SrcBusyMSG = { --w
"Source busy.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
noSelfCpMSG = { --w
"Cannot copy to itself.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
noTgtMSG = { --w
-- "No valid target.",
"Invalid target.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
DelItemMSG = { --a
"Remove item",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
noUrlMSG = { --w
"No Info URL for ",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
emptyUrlMSG = { --w
"Info URL empty for ",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
openUrlMSG = { --w
"This action will try to open URL",
"in your default web browser.",
"",
"Do you want to continue?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
refNotPossMSG = { --a
"Operation not possible for object type ",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
noRefSelMSG = { --w
"No object selected in Celestia.",
"Reference mark requires target or",
"source object as Celestia selection.",
txtfnt = {"bigfont","normalfont"};
sev = "w";
title = "Warning";
};
sameRefMSG = { --w
"Source and target are the same.",
"Change your selection.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
refExMSG = { --w
"Rreference mark ",
"from ",
" to ",
" updated.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
noRefMarkMSG = { --w
"Reference mark '",
"from ",
" to ",
" does not exist.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
noRefMarkAllMSG = { --w
"No reference marks on ",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
unrefAllLocMSG	= { --a
"Remove all reference marks from ",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
unrefAllGlobMSG = { --a
"Remove all reference marks from Celestia?",
"This will remove also reference marks from other pads.",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
unrefObjMSG = { --a
"Remove '",
"' ",
"reference from ",
" to ",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
CopyItemMSG = { --w
"Copy item '",
"' ?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
RmvItemMSG = { --a
"Delete item '",
"' ?",
txtfnt = {"normalfont"};
sev = "a";
title = "Delete";
};
PopMSGOKresults = { --w
"Result set present.","Scan result set instead.",
txtfnt = {"bigfont","normalfont"};
sev = "w";
title = "Warning";
};
PopMSGOKsnoresults = { --w
"Result set is empty.","Scan Celestia first.",
txtfnt = {"bigfont","normalfont"};
sev = "w";
title = "Warning";
};
PopMSGOKnoscan	= { --i
"No running scan",
"or copy.",
txtfnt = {"bigfont"};
sev = "i";
title = "Information";
};
noPauseMSG	= { --i
"No process to",
"pause or resume.",
txtfnt = {"bigfont"};
sev = "i";
title = "Information";
};
pauseQuestMSG	= { --i
" process?",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
noCopyMSG = { --i
"No running copy.",
txtfnt = {"bigfont"};
sev = "i";
title = "Information";
};
GetOrbsMSG = { --a
"Get satellites of result set objects?",
"Current result set will be replaced.",
"Note: Command is applied recursively to all extracted satellites",
"i.e. if applied to star, also satellites of all its planets, moons etc.",
"will be obtained.",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
GetLocsMSG = {  --a
"Get locations of result set?",
"Current result set will be replaced.",
"Note: Only 'satellite' type objects will be processed.",
txtfnt = {"bigfont","normalfont"};
sev = "a";
title = "Alert";
};
GetParsMSG = { --a
"Get parents of result set?",
"Current result set will be replaced.",
txtfnt = {"bigfont","normalfont"};
sev = "a";
title = "Alert";
};
PopMSGnoqr = { --w
"Query dialog must be opened",
"before saving/loading the query.",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
PopMSGOKnoresults = { --i
"Result set is empty.",
txtfnt = {"bigfont"};
sev = "i";
title = "Information";
};
noDedupMSG = { --w
"Getting objects from popup menu does not",
"use the position deduplication.",
"",
"Do you want to continue?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
toMarkMSG = { --w
"Are you sure you want",
"to mark ",
" objects?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
toUnMarkMSG = { --w
"Are you sure you want to",
"unmark ",
" objects?",
"",
"Note that unmark process will",
"run also on non-marked objects.",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
noMarkMSG = { --i
"No running marker.",
txtfnt = {"bigfont"};
sev = "i";
title = "Information";
};
CancelMarkMSG = { --a
"Cancel marking?",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
UnmarkAllMSG = { --a
"Are you sure you want to unmark all?",
"This will also clear markers from other pads.",
txtfnt = {"bigfont","smallfont"};
sev = "a";
title = "Alert";
};
adaptOnMarkMSG = { --a
"< autowrap >",
"<-65",
"This amount of objects requires adaptive settings to be turned ON to prevent Lua hook timeouts. In case of timeouts save your settings and restart Celestia.",
"Clicking 'Yes' will turn Adaptive settings ON.",
"You can turn them OFF later in Settings.",
"",
"To avoid this message next time, turn adaptive settings ON in System Settings.",
"",
"Do you want to continue?",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
toRunCmdMSG = { --w
"Are you sure you want to run",
"commands on ",
" objects?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
toRunCmdObjMSG = { --w
"Are you sure you want to run",
"command set on object '",
"' ?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
noAvailCmdsMSG = { --a
"There is no Selection Pad",
"with results.",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
noCmdsMSG = { --i
"No running command set.",
txtfnt = {"bigfont"};
sev = "i";
title = "Information";
};
cmdNoSelectMSG = { --w
"No window selected.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
CancelCmdsMSG = { --a
"Cancel running commands?",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
oneCmdMSG = { --w
"Command set panel in this",
"pad is already opened.",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
oneCmdSetMSG = { --w
"Command set in this pad",
"is already running.",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
cmdStartMSG = { --w
"Set item '","' as",
"starting point?",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
cmdNoStartMSG = { --w
"Item index (",
") is bigger",
"than current end (",").",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
cmdEndMSG = { --i
"Set item '","' as",
"ending point?",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
cmdNoEndMSG = { --w
"Item index (",
") is smaller",
"than current start (",").",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
cmdCursEndMSG = { --w
"Item index (",") is greater than ending",
"point (","). Should this be new ending point?",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
cmdCursStartMSG = { --w
"Item index (",") is less than starting",
"point (","). Should this be new starting point?",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
cmdCursMSG = { --w
"Jump on item '",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
gotoCmdMSG = { --w
"Go to item ",
txtfnt = {"bigfont"};
sev = "w";
title = "Information";
};
cmdGoto1MSG = { --a
"Sorry, it is not possible to jump",
"on the first item. Please restart",
"processing instead.",
txtfnt = {"bigfont"};
sev = "a";
title = "Error";
};
noLoadCmdMSG = { --w
"Commands cannot be loaded",
"during the process.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
toRunCmdsMSG = {
"< autowrap >",
"<-60",
"Are you sure you want to run command sets on multiple Selection Log windows?",
"Selection list: ",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
genErrMSG = {
"< autowrap >",
"<-70",
"General error",
txtfnt = {"normalfont","smallfont"};
sev = "a";
title = "Error";
};
CancelScanMSG = { --a
"Cancel running scan?",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
CancelCopyMSG = { --a
"Cancel running copy?",
txtfnt = {"bigfont"};
sev = "a";
title = "Alert";
};
ClearRunningMSG = { --w
"Target busy, cancel first.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
ClearCopyMSG = { --w
"Target busy, copying to ",
" target(s), cancel first.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
ScanCopyMSG = { --w
"Scanner busy, copy to ",
"target(s) is in progress.",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
fastClnWarnMSG  = { --a
"Change of 'Fast Cleanup' feature requires",
"restart of CelPad.",
"",
"If you click 'Yes', CelPad will restart automatically.",
"All your windows will be closed and unsaved",
"changes lost.",
"",
"Please keep in mind that 'Fast Cleanup' feature",
"is still only experimental. If you experience errors",
"or timeouts, turn it off.",
"",
"Are you sure you want to continue?",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
openNewScMSG = { --w
"Open new scanner?",
txtfnt = {"bigfont"};
sev = "w";
title = "Warning";
};
PopMSGOKniling	= { --w
"Running cleanup process.",
"Wait until cleanup finish.",
txtfnt = {"bigfont","smallfont"};
sev = "w";
title = "Warning";
};
nilToWarnMSG = { --w
"Lags during the cleanup process detected.",
"Objects pack was decreased to avoid timeouts.",
"It is possible to reset pack size back to original,",
"however, timeouts can occure.",
"",
"The safest way is leaving this dialog open",
"and let CelPad to handle the situation.",
"",
"Do you want to reset the pack size anyway?",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
noExtInputMSG = { --a
"< autowrap >",
"<-60",
"External input failed with message:",
txtfnt = {"normalfont"};
sev = "a";
title = "External Input Error";
};
emptyExtInputMSG = { --w
"< autowrap >",
"<-60",
"External input file ",
" is empty.",
txtfnt = {"normalfont"};
sev = "w";
title = "Warning";
};
convStartMSG = { --a
"< autowrap >",
"<-70",
"CelPad found previous version files in ",
" directory.",
"To preserve your saves, CelPad needs to convert old files to new version.",
"If you click 'Yes', files will be automatically converted and CelPad restarted afterwards.",
"If you click 'No', CelPad will quit.",
"Don not click anything during the conversion and do NOT quit Celestia. Conversion may take several minutes, depending on amount of your files. If you do not want to convert any files, remove *.cpsav files from your '"..profileDIR.."' directory and restart Celestia.",
"Make sure you have your old files backed up.",
"Do you want to start conversion now?",
txtfnt = {"normalfont"};
sev = "a";
title = "Conversion required";
};
convEnd1MSG = { --w
"< autowrap >",
"<-65",
"Conversion finished successfully.",
"",
"Now you can delete your old *.cpsav files from '"..profileDIR.."' directory to spare some space.",
"Make sure you have backup.",
txtfnt = {"normalfont"};
sev = "w";
title = "Conversion Finished";
};
convEnd2MSG = { --w
"< autowrap >",
"<-65",
"Conversion finished with warnings. One or more old files defined in profile were NOT found.",
"",
"Missing files will be created from currently used values.",
"",
"If you have your old files stored elsewhere, copy them into '"..profileDIR.."' directory. Then remove file 'ini_profile.cpsv1' (make sure to preserve 'ini_profile.cpsav'!) from that directory and restart Celestia. File conversion will start again.",
txtfnt = {"normalfont"};
sev = "w";
title = "Conversion Finished";
};
restartMSG = { --i
"CelPad was restarted.",
txtfnt = {"normalfont"};
sev = "i";
title = "Info";
};
FastCleanErr = { --a
"'Fast Cleanup' action caused severe errors!",
"It's strongly recommended to turn 'Fast Cleanup'",
"feature OFF and restart CelPad.",
txtfnt = {"normalfont"};
sev = "a";
title = "Alert";
};
PopSamp = {
"Message bigfont AaBbCc123",
"Message normalfont AaBbCc123",
"Message smallfont AaBbCc123",
txtfnt = {"bigfont","normalfont","smallfont"};
};
};
scanWarn = {
sslow = {
logm = "!!! warning: system slow, possibly there are too many objects in memory";
msgm = "- System slow. Check amount of objects in memory.";
};
niltotasks = {
logm = "!!! warning: cleanup lags possibility detected, cleanups will run as risky";
msgm = "- Complex queries running against large result set can cause lags during the cleanup process. To prevent timeouts caused by those lags, CelPad will reduce objects pack every time the lag is detected. Lag detection is indicated by warning pop-up message. The message offers resetting the pack back to its original size (and thus speed up the cleanup), however, the safest way is ignoring the message and leaving CelPad to handle the situation automatically.";
};
notaskscel = {
logm = "!!! warning: no tasks defined, all object of searched type will match";
msgm = "- No tasks defined, all objects will be loaded into memory.";
};
notasksrs = {
logm = "!!! warning: no tasks applied to result set";
msgm = "- No tasks defined. If applied to result set, search of identical scan type will return the same set (either performs no tasks or purify task returns all objects). If different scan type is applied, '"..templates.metaQuery.zz1_scan_pure[1].."' and / or '"..templates.metaQuery.zz1_scan_within[1].."' settings are important for scan results.";
};
large  = {
logm = "!!! warning: possibly large result set.";
msgm = "- Current scan query definition gives possibility to return large amount of objects, which will slow down your system. Try to narrow your search as much as possible.";
};
posDed = {
logm = "!!! warning: position deduplication is ON";
msgm = "- Position deduplication feature is ON, Celestia time will be stopped during the satellites or locations load. If warnings are ON, the log can be flooded with warning messages.";
};
};
};
tts = deepcopy(templates.tts)
ttl = deepcopy(templates.tts)
ttc = deepcopy(templates.tts)
bigfont = celestia:loadfont("fonts/sans14_ru.txf") or normalfont;
tCPfonts = {
smallfont = smallfont;
normalfont = normalfont;
bigfont = bigfont;
};
gVarBinds = {
gUpdate = function()
	ScrX, ScrY = celestia:getscreendimension();
	observer = celestia:getobserver();
	local timenow = os.clock();
	timedelta = timenow - (oldtime or 0);
	oldtime = timenow;
-- timedeltamax = math.max(timedelta,timedeltamax)
	if timedelta >= sysSlowRisk and timedelta < 2 then
		myCelPad:systemMsg(nil,nil,"1");
		if ms020AdaptiveLoops then
			Fuse = Fuse*0.5
		end;
	end;
	if  Fuse ~= 1 and timedelta <= sysSlowBack then
		Fuse = 1
	end;
	if #tCelPadHUD.setupPanes > 0 or not myCelPad.Initialized then
		if myCelPad.Initialized and (not myCelPad.openSetTimer) then
			myCelPad:settingsOpened()
		end;
		local wpanes = false
		for i,s in ipairs(tCelPadHUD.setupPanes) do
			if string.sub(s.objname,1,7) == "Windows" then wpanes = true; end
		end
		gVarBinds.updateGlobals(wpanes);
	end
end;
updateGlobals = function(wpanes)
	local ofclean, nfclean, oloops
	if wpanes or not myCelPad.Initialized then
		showWrapBtn = tSettings.Windows.showWrapBtn;
		showTextBtn = tSettings.Windows.showTextBtn;
		showScrollBtn = tSettings.Windows.showScrollBtn;
		showVerbBtn = tSettings.Windows.showVerbBtn;
		showViewBtn = tSettings.Windows.showViewBtn;
		showMenuHidBtn = tSettings.Windows.showMenuHidBtn;
		rclHideMenu = tSettings.Windows.rclHideMenu;
		Maxpageitems = tSettings.Windows.Maxpageitems;
		cp1schmenup = tSettings.Windows.cp1schmenup
		cp1schmainw = tSettings.Windows.cp1schmainw
		cp1schcontp = tSettings.Windows.cp1schcontp
		cpfntmenu = tCPfonts[tSettings.Windows.cpfntmenu[1]];
		cpfntmainw = tCPfonts[tSettings.Windows.cpfntmainw[1]];
		cpfntheader = tCPfonts[tSettings.Windows.cpfntheader[1]];
		cpfntmsgmid = tCPfonts[tSettings.Windows.cpfntmsgmid[1]];
		cpcolheader = tSettings.Windows.cpcolheader;
		cpfntcolhghlt = tSettings.Windows.cpfntcolhghlt;
		cpfntcolmainw = tSettings.Windows.cpfntcolmainw;
		cpfntcolruncmd = tSettings.Windows.cpfntcolruncmd;
		wMovWin = tSettings.Windows.wMovWin[1];
		wMovMenu = tSettings.Windows.wMovMenu[1];
		--Advanced
		gShadowsize = tSettings.WindowsAdv.gShadowsize;
		cpbordon = tSettings.WindowsAdv.cpbordon;
		cpfillshadow = tSettings.WindowsAdv.cpfillshadow;
		gShowShadows = tSettings.WindowsAdv.gShowShadows;
		gButtonsize = tSettings.WindowsAdv.gButtonsize;
		gButtonspace = tSettings.WindowsAdv.gButtonspace;
		msgButtonwidth = tSettings.WindowsAdv.msgButtonwidth;
		msgButtonheight = tSettings.WindowsAdv.msgButtonheight;
		mtBtnDelay1 = tSettings.WindowsAdv.mtBtnDelay1;
		mtBtnDelay2 = tSettings.WindowsAdv.mtBtnDelay2;
		gMenusize = tSettings.WindowsAdv.gMenusize;
		CPmaxW = tSettings.WindowsAdv.CPmaxW;
		CPmaxH = tSettings.WindowsAdv.CPmaxH;
		CPiconH = tSettings.WindowsAdv.CPiconH;
		CPicor = tSettings.WindowsAdv.CPicor[1];
		defMnSticky = tSettings.WindowsAdv.defMnSticky;
		defMnHiding = tSettings.WindowsAdv.defMnHiding;
		defgScroll = tSettings.WindowsAdv.defgScroll;
		defgWordwrap = tSettings.WindowsAdv.defgWordwrap;
		defgDrawtext = tSettings.WindowsAdv.defgDrawtext;
		defgVerbose = tSettings.WindowsAdv.defgVerbose;
		defzCascade = tSettings.WindowsAdv.defzCascade;
		maxInfoHght = tSettings.WindowsAdv.maxInfoHght
		maxSyslWidth = tSettings.WindowsAdv.maxSyslWidth
		--popup Message Scheme
		cpfillpupmsga = tSettings.WindowsAdvPM.cpfillpupmsga;
		cpfillpupmsgw = tSettings.WindowsAdvPM.cpfillpupmsgw;
		cpfillpupmsgi = tSettings.WindowsAdvPM.cpfillpupmsgi;
		--deltas
		--menu pane color scheme
		cpfillmenup = tDeltaSettings.Windows.cpfillmenup;
		cpbormenup = tDeltaSettings.Windows.cpbormenup;
		cpcolmenup = tDeltaSettings.Windows.cpcolmenup;
		cpfillbutton = tDeltaSettings.Windows.cpfillbutton;
		cpcolbutton = tDeltaSettings.Windows.cpcolbutton;
		cpborbutton = tDeltaSettings.Windows.cpborbutton;
		cpfillmenul = tDeltaSettings.Windows.cpfillmenul;
		cpbormenul = tDeltaSettings.Windows.cpbormenul;
		cpcolmenul = tDeltaSettings.Windows.cpcolmenul;
		cpbormenue = tDeltaSettings.Windows.cpbormenue;
		cpfillmenue = tDeltaSettings.Windows.cpfillmenue;
		cpcolmenue = tDeltaSettings.Windows.cpcolmenue;
		cpborvlist =  tDeltaSettings.Windows.cpborvlist;
		cpfillvlist = tDeltaSettings.Windows.cpfillvlist;
		cpfillarrow = tDeltaSettings.Windows.cpfillarrow;
		cpborarrow = tDeltaSettings.Windows.cpborarrow;
		cpcolarrow = tDeltaSettings.Windows.cpcolarrow;
		--Main Window Color Scheme
		cpfillmvbtn =  tDeltaSettings.Windows.cpfillmvbtn;
		cpborframe =  tDeltaSettings.Windows.cpborframe;
		cpfillframe = tDeltaSettings.Windows.cpfillframe;
		cpbormvbtn =  tDeltaSettings.Windows.cpbormvbtn;
		cpcolmwarrow = tDeltaSettings.Windows.cpcolmwarrow;
		cpfillmwarrow = tDeltaSettings.Windows.cpfillmwarrow;
		cpbormwarrow =  tDeltaSettings.Windows.cpbormwarrow;
		cpfillmwslider = tDeltaSettings.Windows.cpfillmwslider;
		cpbormwslider =  tDeltaSettings.Windows.cpbormwslider;
		cpfillmwslfr = tDeltaSettings.Windows.cpfillmwslfr;
		cpbormwslfr =  tDeltaSettings.Windows.cpbormwslfr;
		cpfillrzbtn = tDeltaSettings.Windows.cpfillrzbtn;
		cpcolrzbtn = tDeltaSettings.Windows.cpcolrzbtn;
		cpborrzbtn =  tDeltaSettings.Windows.cpborrzbtn;
		cpcolheader =  tDeltaSettings.Windows.cpcolheader;
		--Control Panel Color Scheme
		cpfillframecp =  tDeltaSettings.Windows.cpfillframecp;
		cpborframecp =  tDeltaSettings.Windows.cpborframecp;
		cpfilliconn = tDeltaSettings.Windows.cpfilliconn;
		cpboriconn = tDeltaSettings.Windows.cpboriconn;
		cpfilliconm = tDeltaSettings.Windows.cpfilliconm;
		cpboriconm = tDeltaSettings.Windows.cpboriconm;
		cpcolicon =  tDeltaSettings.Windows.cpcolicon;
		--PopMSG Color Scheme
		cpborpupmsga = tDeltaSettings.Windows.cpborpupmsga;
		cpcolpupmsga = tDeltaSettings.Windows.cpcolpupmsga;
		cpfillpupbxa = tDeltaSettings.Windows.cpfillpupbxa;
		cpborpupbxa = tDeltaSettings.Windows.cpborpupbxa;
		cpcolpupbxa = tDeltaSettings.Windows.cpcolpupbxa;
		cpfillpupbtna = tDeltaSettings.Windows.cpfillpupbtna;
		cpborpupbtna = tDeltaSettings.Windows.cpborpupbtna;
		cpcolpupbtna = tDeltaSettings.Windows.cpcolpupbtna;
		cpborpupmsgw = tDeltaSettings.Windows.cpborpupmsgw;
		cpcolpupmsgw = tDeltaSettings.Windows.cpcolpupmsgw;
		cpfillpupbxw = tDeltaSettings.Windows.cpfillpupbxw;
		cpborpupbxw = tDeltaSettings.Windows.cpborpupbxw;
		cpcolpupbxw = tDeltaSettings.Windows.cpcolpupbxw;
		cpfillpupbtnw = tDeltaSettings.Windows.cpfillpupbtnw;
		cpborpupbtnw = tDeltaSettings.Windows.cpborpupbtnw;
		cpcolpupbtnw = tDeltaSettings.Windows.cpcolpupbtnw;
		cpborpupmsgi = tDeltaSettings.Windows.cpborpupmsgi;
		cpcolpupmsgi = tDeltaSettings.Windows.cpcolpupmsgi;
		cpfillpupbxi = tDeltaSettings.Windows.cpfillpupbxi;
		cpborpupbxi = tDeltaSettings.Windows.cpborpupbxi;
		cpcolpupbxi = tDeltaSettings.Windows.cpcolpupbxi;
		cpfillpupbtni = tDeltaSettings.Windows.cpfillpupbtni;
		cpborpupbtni = tDeltaSettings.Windows.cpborpupbtni;
		cpcolpupbtni = tDeltaSettings.Windows.cpcolpupbtni;
		for i=1,4 do
			--menu pane color scheme
			tDeltaSettings.Windows.cpfillmenup[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillmenup[i];
			tDeltaSettings.Windows.cpbormenup[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpbormenup[i];
			tDeltaSettings.Windows.cpcolmenup[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolmenup[i];
			tDeltaSettings.Windows.cpfillbutton[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillbutton[i];
			tDeltaSettings.Windows.cpcolbutton[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolbutton[i];
			tDeltaSettings.Windows.cpborbutton[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpborbutton[i];
			tDeltaSettings.Windows.cpfillmenul[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillmenul[i];
			tDeltaSettings.Windows.cpbormenul[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpbormenul[i];
			tDeltaSettings.Windows.cpcolmenul[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolmenul[i];
			tDeltaSettings.Windows.cpfillmenue[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillmenue[i];
			tDeltaSettings.Windows.cpbormenue[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpbormenue[i];
			tDeltaSettings.Windows.cpcolmenue[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolmenue[i];
			tDeltaSettings.Windows.cpfillvlist[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillvlist[i];
			tDeltaSettings.Windows.cpborvlist[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpborvlist[i];
			tDeltaSettings.Windows.cpfillarrow[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillarrow[i];
			tDeltaSettings.Windows.cpborarrow[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpborarrow[i];
			tDeltaSettings.Windows.cpcolarrow[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolarrow[i];
			--Main Window Color Scheme
			tDeltaSettings.Windows.cpfillmvbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmvbtn[i];
			tDeltaSettings.Windows.cpborframe[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpborframe[i];
			tDeltaSettings.Windows.cpfillframe[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillframe[i];
			tDeltaSettings.Windows.cpbormvbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormvbtn[i];
			tDeltaSettings.Windows.cpfillmwarrow[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmwarrow[i];
			tDeltaSettings.Windows.cpcolmwarrow[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpcolmwarrow[i];
			tDeltaSettings.Windows.cpbormwarrow[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormwarrow[i];
			tDeltaSettings.Windows.cpfillmwslider[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmwslider[i];
			tDeltaSettings.Windows.cpbormwslider[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormwslider[i];
			tDeltaSettings.Windows.cpfillmwslfr[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmwslfr[i];
			tDeltaSettings.Windows.cpbormwslfr[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormwslfr[i];
			tDeltaSettings.Windows.cpfillrzbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillrzbtn[i];
			tDeltaSettings.Windows.cpcolrzbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpcolrzbtn[i];
			tDeltaSettings.Windows.cpborrzbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpborrzbtn[i];
			tDeltaSettings.Windows.cpcolheader[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpcolheader[i];
			--Control Panel Color Scheme
			tDeltaSettings.Windows.cpfillframecp[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpfillframecp[i];
			tDeltaSettings.Windows.cpborframecp[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpborframecp[i];
			tDeltaSettings.Windows.cpfilliconn[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpfilliconn[i];
			tDeltaSettings.Windows.cpboriconn[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpboriconn[i];
			tDeltaSettings.Windows.cpfilliconm[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpfilliconm[i];
			tDeltaSettings.Windows.cpboriconm[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpboriconm[i];
			tDeltaSettings.Windows.cpcolicon[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpcolicon[i];
			--PopMSG Color Scheme
			tDeltaSettings.Windows.cpborpupmsga[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpborpupmsga[i];
			tDeltaSettings.Windows.cpcolpupmsga[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpcolpupmsga[i];
			tDeltaSettings.Windows.cpfillpupbxa[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpfillpupbxa[i];
			tDeltaSettings.Windows.cpborpupbxa[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpborpupbxa[i];
			tDeltaSettings.Windows.cpcolpupbxa[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpcolpupbxa[i];
			tDeltaSettings.Windows.cpfillpupbtna[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpfillpupbtna[i];
			tDeltaSettings.Windows.cpborpupbtna[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpborpupbtna[i];
			tDeltaSettings.Windows.cpcolpupbtna[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpcolpupbtna[i];
			tDeltaSettings.Windows.cpborpupmsgw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpborpupmsgw[i];
			tDeltaSettings.Windows.cpcolpupmsgw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpcolpupmsgw[i];
			tDeltaSettings.Windows.cpfillpupbxw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpfillpupbxw[i];
			tDeltaSettings.Windows.cpborpupbxw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpborpupbxw[i];
			tDeltaSettings.Windows.cpcolpupbxw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpcolpupbxw[i];
			tDeltaSettings.Windows.cpfillpupbtnw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpfillpupbtnw[i];
			tDeltaSettings.Windows.cpborpupbtnw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpborpupbtnw[i];
			tDeltaSettings.Windows.cpcolpupbtnw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpcolpupbtnw[i];
			tDeltaSettings.Windows.cpborpupmsgi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpborpupmsgi[i];
			tDeltaSettings.Windows.cpcolpupmsgi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpcolpupmsgi[i];
			tDeltaSettings.Windows.cpfillpupbxi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpfillpupbxi[i];
			tDeltaSettings.Windows.cpborpupbxi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpborpupbxi[i];
			tDeltaSettings.Windows.cpcolpupbxi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpcolpupbxi[i];
			tDeltaSettings.Windows.cpfillpupbtni[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpfillpupbtni[i];
			tDeltaSettings.Windows.cpborpupbtni[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpborpupbtni[i];
			tDeltaSettings.Windows.cpcolpupbtni[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpcolpupbtni[i];
		end;
	end
		--System
	ofclean = ms131fastCleanup
	oloops = ms020AdaptiveLoops
	ms010ScanLoop = tSettings.SystemSet.ms010ScanLoop;
	ms020AdaptiveLoops = tSettings.SystemSet.ms020AdaptiveLoops;
	ms030AddInfo = tSettings.SystemSet.ms030AddInfo[1]
	ms035IconInfo = tSettings.SystemSet.ms035IconInfo;
	ms040DefView1 = tSettings.SystemSet.ms040DefView1;
	ms050DefView2 = tSettings.SystemSet.ms050DefView2;
	ms060InheritFinder = tSettings.SystemSet.ms060InheritFinder
	ms065VwSumAutoLd = tSettings.SystemSet.ms065VwSumAutoLd;
	ms070autoScanOn = tSettings.SystemSet.ms070autoScanOn
	ms080InclNils = tSettings.SystemSet.ms080InclNils;
	ms085PosDedup = tSettings.SystemSet.ms085PosDedup;
	ms036ShowPos = tSettings.SystemSet.ms036ShowPos
	ms037ShowCat = tSettings.SystemSet.ms037ShowCat
	ms038sumShowNames = tSettings.SystemSet.ms038sumShowNames
	ms130untDecPlac = tSettings.SystemSet.ms130untDecPlac;
	ms140askForDur = tSettings.SystemSet.ms140askForDur
	ms150defDur = tSettings.SystemSet.ms150defDur
	ms151defRadMtpl = tSettings.SystemSet.ms151defRadMtpl
	ms152cmdRptSet = tSettings.SystemSet.ms152cmdRptSet;
	ms160VerboseLogs = tSettings.SystemSet.ms160VerboseLogs;
	ms161AlertsInLogs = tSettings.SystemSet.ms161AlertsInLogs;
	ms055ShowScanWarnings = tSettings.SystemSet.ms055ShowScanWarnings
	ms170maxSysLog = tSettings.SystemSet.ms170maxSysLog
	ms180rotLog = tSettings.SystemSet.ms180rotLog;
	ms022OpenSetWarn = tSettings.SystemSet.ms022OpenSetWarn
	ms025autoAdaptOn = tSettings.SystemSet.ms025autoAdaptOn
	ms131fastCleanup = tSettings.SystemSet.ms131fastCleanup
	ms132updateOpened = tSettings.SystemSet.ms132updateOpened
	ms136externInput = tSettings.SystemSet.ms136externInput
	if ControlPanel and ofclean ~= ms131fastCleanup then
		nfclean = ms131fastCleanup;
		ms131fastCleanup, tSettings.SystemSet.ms131fastCleanup = not nfclean, not nfclean;
		if not ControlPanel.mainFrame.MSGupT["fastClnWarnMSG"] then
			local fastClnWarnMSG = PopMessage:new({tCelPadHUD.popMsgs});
			fastClnWarnMSG:init(ControlPanel.mainFrame,"fastClnWarnMSG",x,y,nil,nil,nil,"yn",
			function()
				table.insert(myCelPad.rstcmdtab,
				function()
					ms131fastCleanup, tSettings.SystemSet.ms131fastCleanup = nfclean, nfclean;
					myCelPad.nfamRest = PopMessage:new();
					myCelPad.nfamRest:init(CelPadBox,"restartMSG",x,y,nil,nil,nil,"ok",5);
					myCelPad.nfamRest:makeBranch(myCelPadHUD);
				end);
				CelPadCheck:Action()
				fastClnWarnMSG = nil;
			end,
			function()
				fastClnWarnMSG = nil;
			end
			);
			fastClnWarnMSG:makeBranch(ControlPanel);
		end;
	end;
	if ms020AdaptiveLoops ~= oloops and not ms020AdaptiveLoops then
		Fuse = 1
		for i,p in ipairs(tCelPadFinder.runningLogs) do
			if p.marker then
				CPlog("adaptive loops off, marker cancelled",0,p.sysLog)
				p.marker.cancelrq = true
			end;
		end
	end;
end;
}
