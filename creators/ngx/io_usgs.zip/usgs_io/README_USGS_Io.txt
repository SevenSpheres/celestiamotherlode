USGS Io

Celestia Addon, tested on version 1.6.1. 
To install, unzip the file (extract folder "usgs_io") into Celestia's "extras" folder. 

Alternate surface of Jupiter's moon Io, originating from USGS Astrogeology Research Program.
High resolution simple cylindrical surface maps from Galileo and both Voyager missions, showing surface appearance change during the 20+ year interval between the Voyager and Galileo missions. 

Right click on the moon and select "Alternate Surface" item.

For Celestia prepared by ngx.
ngx@zoznam.sk

Source images and detailed information:
http://astrogeology.usgs.gov/Projects/JupiterSatellites/io.html

Images Copyright:
USGS Astrogeology Science Center
http://astrogeology.usgs.gov