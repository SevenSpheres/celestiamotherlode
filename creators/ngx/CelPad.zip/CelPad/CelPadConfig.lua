--CelPadConfig.lua

celestia:log("CelPad: loading configuration ")


profileDIR = "extras/CelPad/saves/";
--following commented line is an example for putting CelPad into Lua Edu Tools' 'adds' directory.
--profileDIR = "extras/lua_edu_tools/adds/CelPad/saves/";

--Do not edit the file below this line unless you know exactly what you are doing. CelPad settings can be edited and saved using the graphical user interface.

URLstartCMD = "start \"cmd\" cmd /C start \"web\" ";
CPver = "1.0"
ScrX, ScrY = celestia:getscreendimension();
starSol = celestia:find("Sol")
Fuse = 1;
LoadLoop = 300;
DebugLog = false;
restPurgeLogs = true; --purge syslogs when restarted
timeObjRisk = 0.5;--risky timedeta before scan
postProcLimit = 1000; --minimum children for postprocessing
nilTmoRisk = {
1000000, --minimum limit of objects for warning message
4, --minimum limit of tasks for warning message
0.1, --time delta for cleanup lag detection
10, --new clean loops until cleanup pack reset
100, --minimum limit for reduction of cleanup pack
3 --steps down on nilparser entry when risky niling
}; --risky set-tasks combination
sysSlowRisk = 0.8; --system slow detection time delta in s
sysSlowBack = 0.4;
distLargeRisk = 10000000000000000; --too big distance limit for warning message in km
lrgSetRisk = 0.5; --min. rate for large result set risk
obsInfoDec = 4; --observer info distance decimals
markSetLim = {
10000, --minimum limit for ask message
30000, --minimum limit for forced adaptive
0.4, --time delta for forced adaptive
0.2 --time delta for slow system warning
}; --mark set limit 
tProfiles = {
SavesGUI = {
savename = {"default", valuelist = {"default","LETtheme","blue","ghost","heavy"}}; 
};
SavesQRstars = {
savename = {"default", valuelist = {"default","star_example_1","star_example_2"}};
};
SavesQRsatellites = {
savename = {"default", valuelist = {"default","sat_example_1","sat_example_2"}};
};
SavesQRdsos = {
savename = {"default", valuelist = {"default","dso_example_1"}};
};
SavesQRlocations = {
savename = {"default", valuelist = {"default","loc_example_1"}};
};
SavesVW = {
savename = {"default", valuelist = {"default","stars","satellites","dsos","locations"}};
};
SavesSUM = {
savename = {"default", valuelist = {"default","stars","satellites","dsos","locations","full","empty"}};
};
SavesSYS = {
savename = {"default", valuelist = {"default","slowPC","fastPC"}};
};
};
tts = {
profile = {};
GUI = {};
QRstars = {};
QRsatellites = {};
QRdsos = {};
VW = {};
SUM = {};
SYS = {};
};
tSettings = {
Windows = {
--Menu Pane Color Scheme
cp1schmenup = {0.05, 0.1 , 0.1, 0.9};
--Main Window Color Scheme
cp1schmainw = {0.05, 0.1 , 0.1, 0.9};
--Control Panel Color Scheme
cp1schcontp = {0.05, 0.1 , 0.1, 0.9};
-- highlighted text color
cpfntcolhghlt = {1,1,1,1};
--main window font color
cpfntcolmainw = {0.8, 0.8, 0.8, 0.7}; 
--menu font
cpfntmenu = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}}; 
--main window font
cpfntmainw = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}};
--window header font
cpfntheader = {"normalfont", valuelist = {"smallfont","normalfont","bigfont"}};
Maxpageitems = 100;
rclHideMenu = false;
showMenuHidBtn = false;
showScrollBtn = true;
showTextBtn = false;
showVerbBtn = true;
showViewBtn = true;
showWrapBtn = false;
wMovWin = {"movable", valuelist = {"movable","locked","holey"}};
wMovMenu = {"movable", valuelist = {"movable","locked","holey"}};
};
WindowsAdv = {
cpbordon = {0.6, 0, 0, 0.4};
cpfillshadow = {0, 0 , 0, 0.6}; 
CPiconH = 22;
CPicor = {"horizontal", valuelist = {"horizontal","vertical"};};
CPmaxH = 250;
CPmaxW = 650;
defgDrawtext = true;
defgScroll = true;
defgVerbose = false;
defgWordwrap = false;
defMnHiding = false;
defMnSticky = false;
defzCascade = false;
gButtonsize = 12;
gButtonspace = 2;
gMenusize = 12;
gShadowsize = 8;
gShowShadows = true;
maxInfoHght = 360;
maxSyslWidth = 70;
msgButtonheight = 16;
msgButtonwidth = 32;
};
WindowsAdvMW = {
--Main Window Color Scheme
Dcpfillmvbtn = {0, 0 , 0, 0};
Dcpborframe =  {0.15, 0.3 , 0.3, -0.3}; 
Dcpfillframe = {0, 0 , 0, 0}; 
Dcpbormvbtn =  {0.15, 0.3 , 0.3, -0.3}; 
Dcpfillmwarrow = {0, 0 , 0, 0};
Dcpcolmwarrow = {0.35, 0.5 , 0.5, 0};
Dcpbormwarrow =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillmwslider = {0, 0 , 0, 0};
Dcpbormwslider =  {0.15, 0.3 , 0.3, -0.3}; 
Dcpfillmwslfr = {-0.1, -0.1 , -0.1, -0.4}; 
Dcpbormwslfr =  {0.15, 0.3 , 0.3, -0.3};
Dcpfillrzbtn = {0, 0 , 0, 0};
Dcpcolrzbtn = {0.35, 0.5 , 0.5, 0};
Dcpborrzbtn =  {0.15, 0.3 , 0.3, -0.3}; 
Dcpcolheader = {0.75, 0.7 , 0.7, -0.1}; 
};
WindowsAdvMN = {
--menu pane color scheme
Dcpfillmenup = {0, 0 , 0, 0}; 
Dcpbormenup = {0.15,0.3,0.3,-0.3};
Dcpcolmenup = {0.35,0.5,0.5,0};
Dcpfillbutton = {0.15,0.2,0.2,-0.5}; 
Dcpcolbutton = {0.2,0.4,0.4,0.5};
Dcpborbutton = {0,0.2,0.2,0};
Dcpfillmenul = {0, 0 , 0, 0}; 
Dcpbormenul = {0.15, 0.3 , 0.3, -0.3}; 
Dcpcolmenul = {0.35, 0.5 , 0.5, 0}; 
Dcpfillmenue = {0, 0 , 0, 0}; 
Dcpbormenue = {0.15, 0.3 , 0.3, -0.3}; 
Dcpcolmenue = {0.35, 0.5 , 0.5, 0}; 
Dcpfillvlist = {-0.05, 0, 0, 0};
Dcpborvlist =  {0.3, 0.4 , 0.35, 0.1}; 
Dcpfillarrow = {0.15,0.2,0.2,-0.5}; 
Dcpborarrow = {0.15, 0.3 , 0.3, -0.3}; 
Dcpcolarrow = {0.35, 0.5 , 0.5, 0}; 
};
WindowsAdvCP = {
--Control Panel Color Scheme
Dcpfillframecp = {0, 0, 0, 0};
Dcpborframecp =  {0.15, 0.3 , 0.3, -0.3}; 
Dcpfilliconn = {0.25,0.3,0.3,-0.4}; 
Dcpboriconn = {-0.6, -0.4 , -0.4, 0}; 
Dcpfilliconm = {0.05, 0, 0, -0.8}; 
Dcpboriconm = {0, 0.2 , 0.2, 0.5}; 
Dcpcolicon = {0.45, 0.45 , 0.45, -0.1}; 
};
WindowsAdvPM = {
--PopMSG Color Scheme
cpfillpupmsga = {0.9, 0.1 , 0.1, 0.8}; 
cpfillpupmsgw = {-0.1, 0.1 , 0.9, 0.8};
cpfillpupmsgi = {-0.3, 0.25 , 0.25, 0.8};
-- Popup Msg Color Schema Alert
Dcpborpupmsga = {0.3, 0.1 , 0.1, 0.2}; 
Dcpcolpupmsga = {0.6, 0.35 , 0.3, 0.6};
Dcpfillpupbxa = {0.3, 0.1 , 0.1, -0.1}; 
Dcpborpupbxa = {0.3, 0.1 , 0.1, 0.2}; 
Dcpcolpupbxa = {0.9, 0.9 , 0.9, 0.6};
Dcpfillpupbtna = {0.3, 0.1 , 0.1, 0.1}; 
Dcpborpupbtna = {0.3, 0.2 , 0.1, 0.2}; 
Dcpcolpupbtna = {0.3, 0.8 , 0.6, 0.1};
-- Popup Msg Color Schema Warn
Dcpborpupmsgw = {0.3, 0.1 , 0.1, 0.2}; 
Dcpcolpupmsgw = {0.4, 0.35 , 0.3, 0.6};
Dcpfillpupbxw = {0.3, 0.1 , 0.1, -0.1}; 
Dcpborpupbxw = {0.3, 0.1 , 0.1, 0.2}; 
Dcpcolpupbxw = {0.9, 0.9 , 0.9, 0.6};
Dcpfillpupbtnw = {0.3, 0.1 , 0.1, 0.1}; 
Dcpborpupbtnw = {0.3, 0.2 , 0.1, 0.2}; 
Dcpcolpupbtnw = {0.3, 0.8 , 0.6, 0.1};
-- Popup Msg Color Schema Info
Dcpborpupmsgi = {0.3, 0.1 , 0.1, 0.2}; 
Dcpcolpupmsgi = {0.6, 0.35 , 0.3, 0.6};
Dcpfillpupbxi = {0.3, 0.1 , 0.1, -0.1}; 
Dcpborpupbxi = {0.3, 0.1 , 0.1, 0.2}; 
Dcpcolpupbxi = {0.9, 0.9 , 0.9, 0.6};
Dcpfillpupbtni = {0.3, 0.1 , 0.1, 0.1}; 
Dcpborpupbtni = {0.3, 0.2 , 0.1, 0.2}; 
Dcpcolpupbtni = {0.3, 0.8 , 0.6, 0.1};
};
SystemSet = {
ms010ScanLoop = 5000; 
ms020AdaptiveLoops = false;
ms030AddInfo = {"obspos", valuelist = {"none","obspos","objdist","homdist","meminfo"}};
ms040DefView1 = {"log", valuelist = {"resultset","log"}};
ms050DefView2 = {"log", valuelist = {"resultset","log"}};
ms060InheritFinder = true;
ms065VwSumAutoLd = true;
ms070autoScanOn = true;
ms080InclNils = false;
ms085PosDedup = false;
ms090ShowPos = false;
ms100ShowCat = true;
ms110sumShowNames = true;
ms130untDecPlac = 10;
ms140askForDur = false;
ms150defDur = 5;
ms151defRadMtpl=2;
ms160VerboseLogs = true;
ms161AlertsInLogs = true;
ms165ShowScanWarnings = true;
ms170maxSysLog = 1000;
ms180rotLog = 100;
ms190OpenSetWarn = 300;
ms200autoAdaptOn = 4;
ms300fastCleanup = false; 
ms400updateOpened = true;
};
};
ms170maxSysLog = tSettings.SystemSet.ms170maxSysLog; 
ms180rotLog = tSettings.SystemSet.ms180rotLog
tMetaSettings = {
Windows = {
--Menu Pane Color Scheme
cp1schmenup = {"Menu Pane Color Scheme",0.01,-1,1};
--Main Window Color Scheme
cp1schmainw = {"Main Window Color Scheme",0.01,-1,1};
--Control Panel Color Scheme
cp1schcontp = {"Control Panel Color Scheme",0.01,-1,1};
cpfntcolhghlt = {"Highlighted Text Color",0.1,-1,1}; 
cpfntcolmainw = {"Main Window Font Color",0.01,-1,1}; 
cpfntheader = {"Window Header Font"};
cpfntmainw = {"Main Window Font"};
cpfntmenu = {"Menu Font"};
Maxpageitems = {"Maximum Items per Page",1,10,10000};
rclHideMenu = {"Right Click Menu Hide"};
showMenuHidBtn = {"Show Menu Hide Button"};
showScrollBtn = {"Show Scroll Button"};
showTextBtn = {"Show DrawText Button"};
showVerbBtn = {"Show Verbose Button"};
showViewBtn = {"Show View Switch Button"};
showWrapBtn = {"Show Wrap Button"};
wMovWin = {"Move Window Frames"};
wMovMenu = {"Move Menu and Messages"};
};
WindowsAdv = {
cpbordon = {"Active Border Color Scheme",0.01,-1,1}; 
cpfillshadow = {"Shadow Color Scheme",0.01,-1,1}; 
CPiconH = {"Icon Height",1,22,44};
CPicor = {"Icons Orientation (experimental)"};
CPmaxH = {"Control Panel Maximum Height",1,200,800};
CPmaxW = {"Control Panel Maximum Width",1,250,800};
defgDrawtext = {"Default Show Text ON"};
defgScroll = {"Default Scroll ON"};
defgVerbose = {"Default Verbose ON"};
defgWordwrap = {"Default Wrap Lines ON"};
defMnHiding = {"Default Hiding ON"};
defMnSticky = {"Default Sticky ON"};
defzCascade = {"Default Cascade ON"};
gButtonsize = {"Button Size",1,10,24};
gButtonspace = {"Space Between Buttons",1,2,10};
gMenusize = {"Menu Size",1,10,24};
gShadowsize = {"Menu Shadow Distance",1,4,16};
gShowShadows = {"Show Menu Shadows"};
maxInfoHght = {"Initial Info Pane Height (max)",1,50,ScrY};
maxSyslWidth = {"Syslog Popup Message Width",1,10,ScrX};
msgButtonheight = {"Message Button Height",1,14,24};
msgButtonwidth = {"Message Button Width",1,24,48};
};
WindowsAdvMW = {
--Main Window Color Scheme
Dcpborframe =  {"Frame Border Color Delta",0.01,-1,1};
Dcpbormvbtn =  {"Top Bar Border Color Delta",0.01,-1,1};
Dcpbormwarrow =  {"Arrow Border Color Delta",0.01,-1,1};
Dcpbormwslfr =  {"Slider Frame Border Color Delta",0.01,-1,1};
Dcpbormwslider =  {"Slider Border Color Delta",0.01,-1,1};
Dcpborrzbtn =  {"Button Border Color Delta",0.01,-1,1};
Dcpcolheader = {"Window Header Color Delta",0.01,-1,1};
Dcpcolmwarrow = {"Arrow Text Color Delta",0.01,-1,1};
Dcpcolrzbtn = {"Button Text Color Delta",0.01,-1,1};
Dcpfillframe = {"Background Fill Color Delta",0.01,-1,1};
Dcpfillmwarrow = {"Arrow Fill Color Delta",0.01,-1,1};
Dcpfillmwslfr = {"Slider Frame Fill Color Delta",0.01,-1,1};
Dcpfillmwslider = {"Slider Fill Color Delta",0.01,-1,1};
Dcpfillrzbtn = {"Button Fill Color Delta",0.01,-1,1};
Dcpfillmvbtn = {"Top Bar Fill Color Delta",0.01,-1,1};
};
WindowsAdvMN = {
-- Menu Pane Color Scheme
Dcpborarrow = {"Arrow Border Color Delta",0.01,-1,1};
Dcpborbutton = {"Button Border Color Delta",0.01,-1,1};
Dcpbormenue = {"Editbox Border Color Delta",0.01,-1,1};
Dcpbormenul = {"Line Border Color Delta",0.01,-1,1};
Dcpbormenup = {"Border Color Delta",0.01,-1,1};
Dcpborvlist =  {"Value List Border Color Delta",0.01,-1,1};
Dcpcolarrow = {"Arrow Text Color Delta",0.01,-1,1};
Dcpcolbutton = {"Button Text Color Delta",0.01,-1,1};
Dcpcolmenue = {"Editbox Text Color Delta",0.01,-1,1};
Dcpcolmenul = {"Line Text Color Delta",0.01,-1,1};
Dcpcolmenup = {"Text Color Delta",0.01,-1,1};
Dcpfillarrow = {"Arrow Fill Color Delta",0.01,-1,1};
Dcpfillbutton = {"Button Fill Color Delta",0.01,-1,1}; 
Dcpfillmenue = {"Editbox Fill Color Delta",0.01,-1,1};
Dcpfillmenul = {"Line Fill Color Delta",0.01,-1,1};
Dcpfillmenup = {"Menu Pane Fill Color Delta",0.01,-1,1};
Dcpfillvlist = {"Value List Fill Color Delta",0.01,-1,1};
};
WindowsAdvCP = {
--Control Panel Color Scheme
Dcpfillframecp =  {"Background Fill Color Delta",0.01,-1,1};
Dcpborframecp =  {"Frame Border Color Delta",0.01,-1,1};
Dcpfilliconn = {"Icon Normal Fill Color Delta",0.01,-1,1};
Dcpboriconn = {"Icon Normal Border Color Delta",0.01,-1,1};
Dcpfilliconm = {"Icon Minimized Fill Color Delta",0.01,-1,1};
Dcpboriconm = {"Icon Minimized Border Color Delta",0.01,-1,1};
Dcpcolicon = {"Icon Text Color Delta",0.01,-1,1};
};
WindowsAdvPM = {
cpfillpupmsga = {"Alert Message Color Schema",0.01,-1,1};
cpfillpupmsgw = {"Warning Message Color Schema",0.01,-1,1};
cpfillpupmsgi = {"Info Message Color Schema",0.01,-1,1};
--Alert Message Color Scheme
Dcpborpupmsga = {"Alert Message Border",0.01,-1,1};
Dcpcolpupmsga = {"Alert Message Header",0.01,-1,1};
Dcpfillpupbxa = {"Alert Message Box Fill",0.01,-1,1};
Dcpborpupbxa = {"Alert Message Box Border",0.01,-1,1};
Dcpcolpupbxa = {"Alert Message Text",0.01,-1,1};
Dcpfillpupbtna = {"Alert Message Button Fill",0.01,-1,1};
Dcpborpupbtna = {"Alert Message Button Border",0.01,-1,1};
Dcpcolpupbtna = {"Alert Message Button Text",0.01,-1,1};
-- Popup Msg Color Schema Warn
Dcpborpupmsgw = {"Warning Message Border",0.01,-1,1};
Dcpcolpupmsgw = {"Warning Message Header",0.01,-1,1};
Dcpfillpupbxw = {"Warning Message Box Fill",0.01,-1,1};
Dcpborpupbxw = {"Warning Message Box Border",0.01,-1,1};
Dcpcolpupbxw = {"Warning Message Text",0.01,-1,1};
Dcpfillpupbtnw = {"Warning Message Button Fill",0.01,-1,1};
Dcpborpupbtnw = {"Warning Message Button Border",0.01,-1,1};
Dcpcolpupbtnw = {"Warning Message Button Text",0.01,-1,1};
-- Popup Msg Color Schema Info
Dcpborpupmsgi = {"Info Message Border",0.01,-1,1};
Dcpcolpupmsgi = {"Info Message Header",0.01,-1,1};
Dcpfillpupbxi = {"Info Message Box Fill",0.01,-1,1};
Dcpborpupbxi = {"Info Message Box Border",0.01,-1,1};
Dcpcolpupbxi = {"Info Message Text",0.01,-1,1};
Dcpfillpupbtni = {"Info Message Button Fill",0.01,-1,1};
Dcpborpupbtni = {"Info Message Button Border",0.01,-1,1};
Dcpcolpupbtni = {"Info Message Button Text",0.01,-1,1};
};
SystemSet = {
ms010ScanLoop = {"Max Loops in Scan",500,1,20000}; 
ms020AdaptiveLoops = {"Adaptive Loops"}; 
ms030AddInfo = {"Info on Control Panel",1,valuelist = {"none","Observer's Position","Distance from Selection","Distance from Sun","Memory consumption (Kbytes)"};}; 
ms040DefView1 = {"Default View for Scanner",1,valuelist = {"Results","Log"}};
ms050DefView2 = {"Default View for Selection Pad",1,valuelist = {"Records","Log"}};
ms060InheritFinder = {"Inherit Settings in Clone"};
ms065VwSumAutoLd = {"View/Summary Auto Load"};
ms070autoScanOn = {"Auto Scan ON if Edited"};
ms080InclNils = {"Include Items with No Data"}; 
ms085PosDedup = {"Position Deduplication"}; 
ms090ShowPos = {"Show Objects Positions"}; 
ms100ShowCat = {"Show Catalog Numbers"}; 
ms110sumShowNames = {"Show Names in Summary"}; 
ms130untDecPlac = {"Maximum Decimal Places",1,1,20};
ms140askForDur = {"Ask For Parameters"};
ms150defDur = {"Default Duration (sec)",0.1,0,86400};
ms151defRadMtpl = {"Default Distance Coeficient",0.1,0,1000};
ms160VerboseLogs = {"Verbose Logs"};
ms161AlertsInLogs = {"Show Alerts/Warnings in Logs"};
ms165ShowScanWarnings = {"Show Warnings before Scan"}; 
ms170maxSysLog = {"Maximum Log Lines",10,10,10000}; 
ms180rotLog = {"Log Rotation Lines",10,100,1000}; 
ms190OpenSetWarn = {"Open Settings Warning (sec)",10,0,86400};
ms200autoAdaptOn = {"Slowdown Tolerance (sec)",1,2,10};
ms300fastCleanup = {"Fast Cleanup (experimental)"};
ms400updateOpened = {"Update Opened Windows"};
};
SavesGUI = {
savename = {"Profile Name:",1};
hiname = "GUI";
};
SavesQRstars = {
savename = {"Stars Query Name:",1};
hiname = "stars query";
};
SavesQRsatellites = {
savename = {"Planets Query Name:",1};
hiname = "satellites query";
};
SavesQRdsos = {
savename = {"DSO Query Name:",1};
hiname = "deep space objects query";
};
SavesQRlocations = {
savename = {"Location Query Name:",1};
hiname = "locations query";
};
SavesVW = {
savename = {"View Name:",1};
hiname = "view";
};
SavesSUM = {
savename = {"Summary Name:",1};
hiname = "summary";
};
SavesSYS = {
savename = {"System Profile:",1};
hiname = "system profile";
};
};
tDeltaSettings = { 
Windows = {
--Menu Pane Color Scheme 
cpfillmenup = {0.05, 0.1 , 0.1, 0.9};
cpbormenup = {0.2, 0.4 , 0.4, 0.6}; 
cpcolmenup = {0.4, 0.6 , 0.6, 0.9}; 
cpfillbutton = {0.1,0.1,0.1,0.4}; 
cpcolbutton = {0.4, 0.6 , 0.6, 0.9}; 
cpborbutton = {0.2, 0.4 , 0.4, 0.6}; 
cpfillmenul = {0.05, 0.1 , 0.1, 0.9}; 
cpbormenul = {0.2, 0.4 , 0.4, 0.6}; 
cpcolmenul = {0.4, 0.6 , 0.6, 0.9}; 
cpbormenue = {0.2, 0.4 , 0.4, 0.6}; 
cpfillmenue = {0.05, 0.1 , 0.1, 0.9}; 
cpcolmenue = {0.4, 0.6 , 0.6, 0.9}; 
cpborvlist =  {0.3, 0.4 , 0.35, 0.15}; 
cpfillvlist = {0.05, 0.1 , 0.1, 0.15}; 
cpfillarrow = {1,1,1,0.6}; 
cpborarrow = {0.2, 0.4 , 0.4, 0.6}; 
cpcolarrow = {0.6,0.6,0.6,0.6}; 
--Main Window Color Scheme
cpfillmvbtn = {0.05, 0.1 , 0.1, 0.9}; 
cpborframe =  {0.2, 0.4 , 0.4, 0.6}; 
cpfillframe = {0.05, 0.1 , 0.1, 0.9}; 
cpbormvbtn =  {0.2, 0.4 , 0.4, 0.6}; 
cpcolmwarrow = {0.4, 0.6 , 0.6, 0.9};
cpfillmwarrow = {0.05, 0.1 , 0.1, 0.9};
cpbormwarrow =  {0.2, 0.4 , 0.4, 0.6}; 
cpfillmwslider = {0.05, 0.1 , 0.1, 0.9};
cpbormwslider =  {0.2, 0.4 , 0.4, 0.6};
cpfillmwslfr = {0, 0, 0, 0};
cpbormwslfr =  {0.2, 0.4 , 0.4, 0.6};
cpfillrzbtn = {0.05, 0.1 , 0.1, 0.9};
cpcolrzbtn = {0.4, 0.6 , 0.6, 0.9};
cpborrzbtn =  {0.2, 0.4 , 0.4, 0.6}; 
--Control Panel Color Scheme
cpfillframecp = {0.05, 0.1 , 0.1, 0.9}; 
cpborframecp =  {0.2, 0.4 , 0.4, 0.6}; 
cpfilliconn = {0.8,0.8,0.8,0.6};
cpboriconn = {0.2, 0.4 , 0.4, 0.6};
cpfilliconm = {0.1, 0.1, 0.1, 0.1};
cpboriconm = {0.1, 0.3 , 0.3, 0.6};
-- Popup Msg Color Schema Alert
cpborpupmsga = {0.9, 0.1 , 0.1, 1}; 
cpcolpupmsga = {0.9, 0.6 , 0.4, 1};
cpfillpupbxa = {0.9, 0.1 , 0.1, 1}; 
cpborpupbxa = {0.9, 0.1 , 0.1, 1}; 
cpcolpupbxa = {0.9, 0.6 , 0.4, 1};
cpfillpupbtna = {0.9, 0.1 , 0.1, 1}; 
cpborpupbtna = {0.9, 0.1 , 0.1, 1}; 
cpcolpupbtna = {0.9, 0.6 , 0.4, 1};
-- Popup Msg Color Schema Warn
cpborpupmsgw = {0.8, 0.1 , 0.1, 1}; 
cpcolpupmsgw = {0.8, 0.5 , 0.3, 1};
cpfillpupbxw = {0.9, 0.1 , 0.1, 1}; 
cpborpupbxw = {0.9, 0.1 , 0.1, 1}; 
cpcolpupbxw = {0.9, 0.6 , 0.4, 1};
cpfillpupbtnw = {0.9, 0.1 , 0.1, 1}; 
cpborpupbtnw = {0.9, 0.1 , 0.1, 1}; 
cpcolpupbtnw = {0.9, 0.6 , 0.4, 1};
-- Popup Msg Color Schema Info
cpborpupmsgi = {0.7, 0.1 , 0.1, 1}; 
cpcolpupmsgi = {0.7, 0.5 , 0.4, 1};
cpfillpupbxi = {0.9, 0.1 , 0.1, 1}; 
cpborpupbxi = {0.9, 0.1 , 0.1, 1}; 
cpcolpupbxi = {0.9, 0.6 , 0.4, 1};
cpfillpupbtni = {0.9, 0.1 , 0.1, 1}; 
cpborpupbtni = {0.9, 0.1 , 0.1, 1}; 
cpcolpupbtni = {0.9, 0.6 , 0.4, 1};
cpcolheader = {0.6, 0.6 , 0.6, 0.9};
cpcolicon = {0.4, 0.6 , 0.4, 0.8};
};
};
lastwindow = defpos()
templates = {
GetOrbs = {"Get Satellites of Result Set","Get Locations of Result Set","Get Parents of Result Set","Summarize Result Set"};
ObsComm = {"Stop Observer","Turn Back","Speed Control","Observer Position Switch","Observer Rotation Switch"};
speedtab = {
s1_obsspeed = 0;
s2_speedunit = {9460730472.5808,valuelist = {9460730472.5808,9460730.4725808,5912956.5453630,(9460730.4725808/299792.458),1,0.000001}};
s3_increment = {0.01,valuelist = {0.01,0.1,1,10,100};};
s4_clutchon = true;
};
delims = {" ","*","#","I","-",":",";","|","][","]","[","}{","}","{","><",">","<",")(",")","(","/"};
equals = {" ",":",": ","=","= "," = "};
minMaxDefault = {
qr005_radius = {minv = 0;maxv = 8000000000};
qr006_luminosity = {minv = 0;maxv = 300000};
qr007_temperature = {minv = 0;maxv = 6000000};
qr008_absoluteMagnitude = {minv = -15;maxv = 40};
qr009_bolometricMagnitude = {minv = -15;maxv = 40};
qr018_oblateness = {minv = 0;maxv = 1};
qr019_albedo = {minv = 0;maxv = 1};
qr022_atmosphereHeight = {minv = 0;maxv = 100000000};
qr023_atmosphereCloudHeight = {minv = 0;maxv = 30000};
qr024_atmosphereCloudSpeed = {minv = 0;maxv = 100};
qr028_rotationPeriod = {minv = 0;maxv = 10000000000000};
qr029_orbitPeriod = {minv = 0;maxv = 4000000000000000};
qr100_dso_radius = {minv = 0;maxv = 8000000000};
qr202_size = {minv = 0;maxv = 30000};
qr203_importance = {minv = -1;maxv = 6000};
qr030_numPlanets = {minv = 0;maxv = math.huge};
qr025_Locations = {minv = 0;maxv = math.huge};
};
query = {
queryStars  = {
qr001_distance = {minv=0;maxv=2000*9.4605284e+012;};
qr002_name_str = "";
qr003_stellarClass = {{false,false,false,false,true,false,false,false,false,false,false,false,false},choicelist = {"O","B","A","F","G","K","M","R","N","S","X","W","D"}}; 
qr004_stellarClass_str = "";
qr005_radius = {minv=556800;maxv=835200};
qr006_luminosity = {minv=0.8;maxv=1.2}; 
qr007_temperature = {minv=5600;maxv=6100};
qr008_absoluteMagnitude = {minv=-8;maxv=35};
qr009_bolometricMagnitude = {minv=-10;maxv=28}; 
qr012_catalogNumber = {minv=0;maxv=99999999999}; 
qr028_rotationPeriod = {minv=20;maxv=30};
qr029_orbitPeriod = {minv=0.002;maxv=3200000000000000};
qr030_numPlanets = {minv=1;maxv=1000};
qr300_parent_str = "";
zz1_scan_fixpos = true;
zz1_scan_pure = false;
};
queryPlanets = { 
qr001_distance = {minv=0;maxv=2000*9.4605284e+012};
qr002_name_str = "";
qr005_radius = {minv=637.8;maxv=63780};
qr016_type = {{false,false,false,false,false,false,false,false,false,false},choicelist = {"planet","dwarfplanet","moon","minormoon","asteroid","comet","spacecraft","diffuse","surfacefeature","invisible"}}; 
qr017_type_str = "";
qr018_oblateness = {minv=0;maxv=0.5};
qr019_albedo = {minv=0.05;maxv=0.9};
qr020_lifespanStart = {minv=-math.huge;maxv=math.huge}; 
qr021_lifespanEnd = {minv=-math.huge;maxv=math.huge}; 
qr022_atmosphereHeight = {minv=1;maxv=43000000};
qr023_atmosphereCloudHeight = {minv=0;maxv=200};
qr024_atmosphereCloudSpeed = {minv=0;maxv=1.5}; 
qr025_Locations = {minv=1;maxv=1000};
qr026_hasRings = false;
-- qr027_mass = {minv=0;maxv=7900}; 
qr028_rotationPeriod = {minv=0;maxv=2000};
qr029_orbitPeriod = {minv=0.002;maxv=3200000000000000};
qr030_numPlanets = {minv=1;maxv=1000};
qr300_parent_str = "";
qr302_infoURL = "";
qr999_isVisible = true;
zz1_scan_fixpos = true;
zz1_scan_pure = false;
zz1_scan_within = {"results", valuelist = {"results","descent"}};
};
queryDsos = { 
qr001_distance = {minv=0;maxv=2000000*9.4605284e+012};
qr002_name_str = "";
qr008_absoluteMagnitude = {minv=-8;maxv=35};
qr016_type = {{false,false,false,false},choicelist = {"galaxy","globular","nebula","opencluster"}}; 
qr017_type_str = "";
qr100_dso_radius = {minv=0.01;maxv=7500000000};
qr101_hubbleType = {{false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false},choicelist = {"E0","E1","E2","E3","E4","E5","E6","E7","S0","Sa","Sb","Sc","SBa","SBb","SBc","Irr"}};
qr102_hubbleType_str = "";
qr999_isVisible = true;
zz1_scan_fixpos = true;
zz1_scan_pure = false;
};
queryLocations = { 
qr001_distance = {minv=0;maxv=2000*9.4605284e+012};
qr002_name_str = "";
qr200_featureType = {{false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false},choicelist = {"city","observatory","landingsite","crater","vallis","mons","planum","chasma","patera","mare","rupes","tholus","tessera","regio","chaos","terra","astrum","corona","dorsum","fossa","catena","mensa","rima","undae","reticulum","planitia","linea","fluctus","farrum","volcano","insula","other"}}; 
qr201_featureType_str = "";
qr202_size = {minv=1;maxv=35000};
qr203_importance = {minv=1;maxv=5000};
qr300_parent_str = "";
qr302_infoURL = "";
zz1_scan_fixpos = true;
zz1_scan_pure = false;
zz1_scan_within = {"results", valuelist = {"results","descent"}};
};	
};
metaQuery = {
zz1_scan_pure = {"Purify Results", valuelist = {"dummy"}};
zz1_scan_within = {"Scan Approach", valuelist = {"Scan Current Results","Get Result's Children"}};
zz1_scan_fixpos = {"Fixed Observer's Position"};
qr001_distance = {"Distance",1,0,math.huge,scan=true,negate=false};
qr002_name_str = {"Name",1,cprop="name",scan=false,negate=false};
qr003_stellarClass = {"Stellar Class",1,cprop="stellarClass",scan=true,negate=false};
qr004_stellarClass_str = {"Stellar Class (string)",1,scan=false,negate=false};
qr005_radius = {"Radius",1,0,8000000000,0,8000000000,cprop="radius",scan=true,negate=false};
qr006_luminosity = {"Luminosity",1,0,300000,0,300000,cprop="luminosity",scan=true,negate=false};
qr007_temperature = {"Temperature",1,0,6000000,0,6000000,cprop="temperature",scan=true,negate=false};
qr008_absoluteMagnitude = {"Absolute Magnitude",0.01,-15,40,-15,40,cprop="absoluteMagnitude",scan=false,negate=false};
qr009_bolometricMagnitude = {"Bolometric Magnitude",0.01,-15,40,-15,40,cprop="bolometricMagnitude",scan=false,negate=false};
qr012_catalogNumber = {"Default Catalog",1,0,math.huge,0,math.huge,cprop="catalogNumber",scan=false,negate=false}; 
qr016_type = {"Type",1,cprop="type",scan=true,negate=false};
qr017_type_str = {"Type (string)",1,scan=false,negate=false};
qr018_oblateness = {"Oblateness",0.01,0,1,0,1,cprop="oblateness",scan=true,negate=false};
qr019_albedo = {"Albedo",0.01,0,1,0,1,cprop="albedo",scan=true,negate=false};
qr020_lifespanStart = {"Lifespan Start",1,-math.huge,math.huge,-math.huge,math.huge,cprop="lifespanStart",scan=false,negate=false}; 
qr021_lifespanEnd = {"Lifespan End",1,-math.huge,math.huge,-math.huge,math.huge,cprop="lifespanEnd",scan=false,negate=false}; 
qr022_atmosphereHeight = {"Atmosphere Height",1,0,100000000,0,100000000,cprop="atmosphereHeight",scan=false,negate=false};
qr023_atmosphereCloudHeight = {"Atmosphere Cloud Height",1,0,300,0,300,cprop="atmosphereCloudHeight",scan=false,negate=false};
qr024_atmosphereCloudSpeed = {"Atmosphere Cloud Speed",1,0,10,0,10,cprop="atmosphereCloudSpeed",scan=false,negate=false};
qr025_Locations = {"Locations",1,1,math.huge,1,math.huge,cprop="locations",scan=false,negate=false};
qr026_hasRings = {"Has Rings",1,cprop="hasRings",scan=false,negate=false};
-- qr027_mass = {"",1,cprop="mass"};
qr028_rotationPeriod = {"Rotation Period",1,0,10000000000000,0,10000000000000,cprop="rotationPeriod",scan=true,negate=false};
qr029_orbitPeriod = {"Orbit Period",1,0,4000000000000000,0,4000000000000000,cprop="orbitPeriod",scan=false,negate=false};
qr030_numPlanets = {"Satellites",1,1,math.huge,1,math.huge,cprop="getchildren",scan=false,negate=false}; 
qr100_dso_radius = {"DSO Radius",1,0,8000000000,0,8000000000,cprop="dsoradius",scan=false,negate=false};
qr101_hubbleType = {"Hubble Type",1,cprop="hubbleType",scan=false,negate=false};
qr102_hubbleType_str = {"Hubble Type (string)",1,scan=false,negate=false};
qr200_featureType = {"Feature Type",1,cprop="featureType",scan=false,negate=false};
qr201_featureType_str = {"Feature Type (string)",1,scan=false,negate=false};
qr202_size = {"Size",1,0,30000,0,30000,cprop="size",scan=false,negate=false};
qr203_importance = {"Importance",1,-1,5000,-1,5000,cprop="importance",scan=false,negate=false};
qr300_parent_str = {"Parent",1,cprop="parent",scan=false,negate=false};
qr302_infoURL = {"Info URL",1,cprop="infoURL",scan=false,negate=false};
qr999_isVisible = {"Is Visible (in Celestia)",1,cprop="visible",scan=false,negate=false};
q_dummy = {"unspecified",1};
z_get_bodies = {"Orbiting Bodies",1};
z_get_parents = {"Parents",1};
z_transfer_parents = {"Transfer Parents",1};
z_transfer_bodies = {"Transfer Bodies",1};
z_transfer_objects = {"Transfer Objects",1};
z_get_locations = {"Locations",1};
z_transfer_locations = {"Transfer Locations",1};
z_has_bodies = {"Has Planets",1}; 
z_postprocess = {"Postprocess Objects",1};
};
marker = {
selshape = {"disk",valuelist = {"square","circle","disk","diamond"};};
selcolor = {"blue",valuelist = {"lime", "red", "green", "yellow", "blue", "orange", "white", "black", "brown", "cyan", "gold", "silver"};};
markerParams = {
mshape = {};
mcolor = {};
msize = 10;
};
metaMarkerParams = {
mshape = {"Marker Shape",1};
mcolor = {"Marker Color",1};
msize = {"Marker Size",1,1,1000};
};
refmarkParams = {
srctgt = {"objtosel",valuelist = {"objtosel","seltoobj"};};
rtype = {"body to body direction",valuelist = {"body to body direction","visible region"};}; 
rsize = 1000;
rcolor = {};
ropacity = 1.0;
zrtag = {"allloc",valuelist = {"allloc","allglob"};};
};
metaRefmarkParams = {
srctgt = {"From-To",valuelist = {"object to selection","selection to object"};};
rtype = {"Reference Type",1};
rsize = {"Reference Size",1,0.001,math.huge};
rcolor = {"Reference Color",1};
ropacity = {"Opacity",0.1,0,1};
zrtag = {"Tag (for Remove only)",1,valuelist = {"remove marks from this object","remove all marks from Celestia"}};
};
};
unitsConst = {
distance = {
km = 1;
ly = 9.4605284e+012;
AU = 149597870; 
pc = 3.0857e+13; 
mi = 1.609344; 
};
duration = {
mins = 60;
hours = 3600;
};
radius = {
RSUN = 696000;
REARTH = 6378;
mi = 1.609344; 
};
dso_radius = {
pc = 3.2617; 
km = 9.4605284e+012;
mi = 5.87849981e+12; 
};
temperature = {
Cels = 273.15;
};
luminosity = {
GW = 3.839e+020;
};
period = {
hours = 24;
years = 365;
};
speed = {
ms = 1000/60;
kmh = 60;
mph = 60000/1609.344
};
};
metaUnits = { 
qr001_distance = {"ly",
valuelist = {
"ly","km","AU","pc","mi"
};
};
qr005_radius = {"km",
valuelist = {
"km","Rsun","Rearth","mi"
};
};
qr100_dso_radius = {"ly",
valuelist = {
"ly","pc","km","mi"
};
};
qr007_temperature = {"K",
valuelist = {
"K","C","F"
};
};
qr006_luminosity = {"xSun",
valuelist = {
"xSun","GW",
};
};
qr028_rotationPeriod = {"days",
valuelist = {
"days","hours","years"
};
};
qr029_orbitPeriod = {"days",
valuelist = {
"days","hours","years"
};
};
qr022_atmosphereHeight = {"km",
valuelist = {
"km","mi"
};
};
qr023_atmosphereCloudHeight = {"km",
valuelist = {
"km","mi"
};
};
qr024_atmosphereCloudSpeed = {"m/s",
valuelist = {
"m/s","km/h","mph",
};
};
-- qr027_mass = {"",
-- valuelist = {
-- "unit"
-- };
-- };
-- for decimals only
qr008_absoluteMagnitude = {"",
valuelist = {
""
};
};
qr009_bolometricMagnitude = {"",
valuelist = {
""
};
};
qr018_oblateness = {"",
valuelist = {
""
};
};
qr019_albedo = {"",
valuelist = {
""
};
};
};
celcmds = {
goto = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local intpl = paramtab[2]
	obs:goto(obj,tim,intpl[1],intpl[2])
end;
gotolonglat = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local dist = paramtab[2]
	local longlat = paramtab[3]
	local vect = paramtab[4]
	obs:gotolonglat(obj,longlat[1],longlat[2],dist,tim,celestia:newvector(vect[1],vect[2],vect[3]))
end;
gotolocation = function(obs,obj,paramtab)
	local tim = paramtab[1]
	local posit = paramtab[2]
	obs:gotolocation(celestia:newposition(posit[1],posit[2],posit[3]),tim)
end;
setposition = function(obs,obj,paramtab)
	local posit = paramtab[1]
	obs:setposition(celestia:newposition(posit[1],posit[2],posit[3]))
end;
gotosurface = function(obs,obj,paramtab)
	local tim = paramtab[1]
	obs:gotosurface(obj,tim)
end;
center = function(obs,obj,paramtab)
	local tim = paramtab[1]
	obs:center(obj,tim)
end;
centerorbit = function(obs,obj,paramtab)
	local tim = paramtab[1]
	obs:centerorbit(obj,tim)
end;
rotate = function(obs,obj,paramtab)
	local vect = paramtab[1]
	local angle = paramtab[2]
	obs:rotate(celestia:newrotation(celestia:newvector(vect[1],vect[2],vect[3]),angle))
end;
};
inputParam = {
zcmdduration = {
data = tSettings.SystemSet.ms150defDur;
meta = {"Duration",1,0,86400};
};
zcmddistance = {
data = 0;
meta = {"Distance",100,0.1,math.huge};
};
zcmdposition = {
data = {0,0,0};
meta = {"Position",0.01,-math.huge,math.huge};
};
zcmdvector = {
data = {0,1,0};
meta = {"Vector",1,-1,1};
};
zcmdlonglat = {
data = {0,0};
meta = {"Long./Lat.",0.01,-2*math.pi,2*math.pi};
};
zcmdintpol = {
data = {0.25,0.75};
meta = {"Start/End Interp.",0.01,0,1};
};
zcmdangle = {
data = 0;
meta = {"Angle",0.01,-2*math.pi,2*math.pi};
};
};
vwindx = {
stars = "stars";
satellites = "satellites";
dsos = "dsos";
locations = "locations";
getorbs = "satellites";
getlocs = "locations";
getpars = "stars";
};
};
templates.metaspeedtab = {
s1_obsspeed = {"Observer's Speed:",templates.speedtab.s3_increment[1],-math.huge,math.huge};
s2_speedunit = {"Speed is in:",valuelist = {"m/s","km/s","mi/s","c","uly/s","ly/s"}};
s3_increment = {"Increment:",valuelist = {};};
s4_clutchon = {"Clutch is on:"};
};
templates.marker.markerParams.mshape = deepcopy(templates.marker.selshape); 
templates.marker.markerParams.mcolor = deepcopy(templates.marker.selcolor); 
templates.marker.refmarkParams.rcolor = deepcopy(templates.marker.selcolor);
templates.metaUnits.zcmddistance = {
"km",
valuelist = {
"km","ly","AU","pc","mi"
};
};
templates.metaUnits.zcmdduration = {
"sec",
valuelist = {
"sec","min","hour"
};
};
templates.metaQuery.zcmddistance = {templates.inputParam.zcmddistance.meta[1].." (command/info)"};
templates.metaQuery.zcmdduration = {templates.inputParam.zcmdduration.meta[1].." (command)"};
templates2 = {
popMsg = {
FirstRun = { --i
"< autowrap >",
"<-90",
"Welcome to CelPad v."..CPver..".",
"",
"Click on CelPad square (little box below this message) to bring up the Control Panel. Then right click on Control Panel to get CelPad functions menu. CelPad windows and menu panes can be dragged to any desired position on the screen and their visibility can be turned ON or OFF.",
"",
"In general, you can use left and right mouse clicks on various parts of CelPad's graphical interface to obtain some action (bring up the menu pane, run some process, hide/show GUI elements etc.). Double clicks are not implemented in this version. You can change and save CelPad's appearence or behaviour in personalized settings, editable via this graphical interface.", 
"",
"Please read Help panes ('?' buttons) for detailed information about CelPad usage and settings. Make sure to follow Performance Considerations to prevent LUA hook timeouts, which are fatal and require restart of Celestia. Main Help panes are available from 'CelPad Help' menu after clicking on '?' button on Control Panel's top bar. Another detailed information can be found in context Help panes after clicking on particular menu's '?' button where available.",
"",
txtfnt = {"bigfont","normalfont"};
};
PopResetDeflt = { --w
"Reset to defaults?",
txtfnt = {"normalfont"};
};
CloseSetMSG = { --w
"Settings panes are open for a long time with no activity.",
"Open settings panes cause continuous global variables",
"update which can affect overall CelPad performance.",
"",
"It is recommended to keep them open only when editing.",
"",
"Do you want to close settings panes now?",
txtfnt = {"normalfont"};
};
SystemSlowMSG = { --w
"System slow, adaptive loops were automatically turned ON.",
"You can turn them OFF later in system settings.",
"",
"Warning: Do not turn them OFF while CelPad is processing.",
txtfnt = {"normalfont"};
};
slowWarnMSG = { --w
"The system is rather slow, this action",
"can result in Lua hook timeouts.",
"Are you sure you want to continue?",
txtfnt = {"normalfont"};
};					
ClosingCPMSG = { --w
"CelPad Closing, please wait for cleanup finish.",
"This can take some time...",
txtfnt = {"normalfont"};
};
SaveFailMSG	= { --a
"Saving/loading of ",
" profile failed!",
"Celestia cannot access CelPad profiles directory:",
"< Celestia dir >/",
"CelPad needs to save profile data for its proper operations, otherwise various",
"errors may occure. Make sure that profile directory exists and is writable for Celestia.",
txtfnt = {"bigfont","smallfont","normalfont","normalfont","smallfont"};
};
SavingMSG = { --w
"Saving ",
"Please wait, this can take a few seconds...",
"Warning: Mouse clicks are disabled during the save process.",
txtfnt = {"normalfont"};
};
CPquitOK = { --a
"Are you sure you want to quit CelPad?",
txtfnt = {"bigfont"};
};
nullBaseMSG = { --w
"Base scan returned no results.",
"Check distance or ",
" parameters.",
txtfnt = {"bigfont","normalfont"};
};
RetainSetMSG = { --w
"No objects found.",
"Do you want to keep latest non-zero result set?",
txtfnt = {"normalfont"};
};
RetainSetStgMSG = { --w
"Stage ",
" returned 0 objects.",
"Do you want to keep latest non-zero result set?",
txtfnt = {"normalfont"};
};
PopMSGoverwrite = { --a
"Overwrite existing profile",
txtfnt = {"normalfont"};
};
PopMSGdelete = { --a
"Delete profile ",
txtfnt = {"normalfont"};
};
noDefDelMSG = { --w
"Profile 'default' cannot be deleted.",
txtfnt = {"normalfont"};
};
PopMSGOKwf = { --w
"Item cannot be picked when lines",
"are wrapped or display filtered.",
txtfnt = {"bigfont","bigfont"};
};
PopMSGOKw = { --w
"Item cannot be picked",
"when lines are wrapped.",
txtfnt = {"bigfont","bigfont"};
};
PopMSGnoLitem = { --w
"No log item in this area.",
txtfnt = {"bigfont"};
};
PopMSGnoitem = { --w
"No item in this area.",
"Right click on top bar for menu.",
txtfnt = {"bigfont","smallfont"};
};
popNoSel = { --w
"No object selected in Celestia.",
txtfnt = {"bigfont"};
};
PopRstPosMSG = { --w 
"This will set all windows positions to default.",
"Close all windows before continuing,",
"otherwise defaults will be overwritten",
"if you close them later.",
"",
"Reset windows positions?",
txtfnt = {"normalfont"};
};
PopMSGosavpos = { --w
"Save windows positions?",
txtfnt = {"normalfont"};
};
CloseWinMSG = { --a
"Are you sure you want to close this window?",
"Closing from menu does not save the position.",
txtfnt = {"bigfont","smallfont"};
};
ClearLogMSG = { --a
"Clear log ",
txtfnt = {"normalfont"};
};
ClearSetMSG = { --a
"Clear results?",
txtfnt = {"normalfont"};
};
itemPopRunMSG = { --w
"Item pop-up for ",
" already running.",
txtfnt = {"bigfont"};
};
PopTgtBusy = { --w
"Target busy.",
txtfnt = {"bigfont"};
};
SrcBusyMSG = { --w
"Source busy.",
txtfnt = {"bigfont"};
};
noSelfCpMSG = { --w
"Cannot copy to itself.",
txtfnt = {"bigfont"};
};			
noTgtMSG = { --w
"No valid target.",
txtfnt = {"bigfont"};
};	
DelItemMSG = { --a
"Remove item",
txtfnt = {"bigfont"};
};				
noUrlMSG = { --w
"No Info URL for ",
txtfnt = {"normalfont"};
};
emptyUrlMSG = { --w
"Info URL empty for ",
txtfnt = {"normalfont"};
};
openUrlMSG = { --w
"This action will try to open URL",
"in your default web browser.",
"",
"Do you want to continue?",
txtfnt = {"normalfont"};
};
refNotPossMSG = { --a
"Operation not possible for object type ",
txtfnt = {"bigfont"};
};
noRefSelMSG = { --w
"No object selected in Celestia.",
"Reference mark requires target or",
"source object as Celestia selection.",
txtfnt = {"bigfont","normalfont"};
};
sameRefMSG = { --w
"Source and target are the same.",
"Change your selection.",
txtfnt = {"bigfont"};
};
refExMSG = { --w
"Rreference mark ", 
"from ",
" to ",
" updated.",
txtfnt = {"bigfont"};
};			
noRefMarkMSG = { --w
"Reference mark '",
"from ",
" to ",
" does not exist.",
txtfnt = {"bigfont"};
};
noRefMarkAllMSG = { --w
"No reference marks on ",
txtfnt = {"bigfont"};
};
unrefAllLocMSG	= { --a
"Remove all reference marks from ",
txtfnt = {"bigfont"};
};
unrefAllGlobMSG = { --a
"Remove all reference marks from Celestia?",
"This will remove also reference marks from other pads.",
txtfnt = {"bigfont"};
};
unrefObjMSG = { --a
"Remove '",
"' ",
"reference from ",
" to ",
txtfnt = {"bigfont"};
};
CopyMSG = { --w
"Copy item ",
" ?",
txtfnt = {"normalfont"};
};
PopMSGOKresults = { --w
"Result set present.","Scan result set instead.",
txtfnt = {"bigfont","normalfont"};
};			
PopMSGOKsnoresults = { --w
"Result set is empty.","Scan Celestia first.",
txtfnt = {"bigfont","normalfont"};
};	
PopMSGOKnoscan	= { --i
"No running scan",
"or copy.",
txtfnt = {"bigfont"};
};
noCopyMSG = { --i
"No running copy.",
txtfnt = {"bigfont"};
};
GetOrbsMSG = { --a
"Get satellites of result set objects?",
"Current result set will be replaced.",
"Note: Command is applied recursively to all extracted satellites",
"i.e. if applied to star, also satellites of all its planets, moons etc.",
"will be obtained.",
txtfnt = {"normalfont"};
};
GetLocsMSG = {  --a
"Get locations of result set?",
"Current result set will be replaced.",
"Note: Only 'satellite' type objects will be processed.", 
txtfnt = {"bigfont","normalfont"};
};
GetParsMSG = { --a
"Get parents of result set?",
"Current result set will be replaced.",
txtfnt = {"bigfont","normalfont"};
};
PopMSGnoqr = { --w
"Query dialog must be opened",
"before saving/loading the query.",
txtfnt = {"bigfont"};
};
PopMSGOKnoresults = { --i
"Result set is empty.",
txtfnt = {"bigfont"};
};
noDedupMSG = { --w
"Getting objects from popup menu does not",
"use the position deduplication.",
"",
"Do you want to continue?",
txtfnt = {"normalfont"};
};
toMarkMSG = { --w
"Are you sure you want",
"to mark ",
" objects?",
txtfnt = {"normalfont"};
};
toUnMarkMSG = { --w
"Are you sure you want to",
"unmark ",
" objects?",
"",
"Note that unmark process will",
"run also on non-marked objects.",
txtfnt = {"normalfont"};
};
noMarkMSG = { --i
"No running marker.",
txtfnt = {"bigfont"};
};
CancelMarkMSG = { --a
"Cancel marking?",
txtfnt = {"bigfont"};
};
UnmarkAllMSG = { --a
"Are you sure you want to unmark all?",
"This will also clear markers from other pads.",
txtfnt = {"bigfont","smallfont"};
};
adaptOnMarkMSG = { --a
"< autowrap >",
"<-65",
"This amount of objects requires adaptive settings to be turned ON to prevent Lua hook timeouts. In case of timeouts save your settings and restart Celestia.",
"Clicking 'Yes' will turn Adaptive settings ON.",
"You can turn them OFF later in Settings.",
"",
"To avoid this message next time, turn adaptive settings ON in System Settings.",
"",
"Do you want to continue?",
txtfnt = {"normalfont"};
};
CancelScanMSG = { --a
"Cancel running scan?",
txtfnt = {"bigfont"};
};
CancelCopyMSG = { --a
"Cancel running copy?",
txtfnt = {"bigfont"};
};
ClearRunningMSG = { --w
"Target busy, cancel first.",
txtfnt = {"bigfont"};
}; 
ClearCopyMSG = { --w
"Target busy, copying to ",
" target(s), cancel first.",
txtfnt = {"bigfont"};
}; 
ScanCopyMSG = { --w
"Scanner busy, copy to ",
"target(s) is in progress.",
txtfnt = {"bigfont"};
}; 
fastClnWarnMSG  = { --a
"Change of 'Fast Cleanup' feature requires",
"restart of CelPad.",
"",
"If you click 'Yes', CelPad will restart automatically.",
"All your windows will be closed and unsaved",
"changes lost.",
"",
"Please keep in mind that 'Fast Cleanup' feature",
"is still only experimental. If you experience errors",
"or timeouts, turn it off.",
"",
"Are you sure you want to continue?",
txtfnt = {"normalfont"};
}; 
openNewScMSG = { --w
"Open new scanner?",
txtfnt = {"bigfont"};
};
PopMSGOKniling	= { --w
"Running cleanup process.",
"Wait until cleanup finish.",
txtfnt = {"bigfont","smallfont"};
};
nilToWarnMSG = { --w
"Lags during the cleanup process detected.",
"Objects pack was decreased to avoid timeouts.",
"It is possible to reset pack size back to original,",
"however, timeouts can occure.",
"",
"The safest way is leaving this dialog open",
"and let CelPad to handle the situation.",
"",
"Do you want to reset the pack size anyway?",
txtfnt = {"normalfont"};
};
FastCleanErr = { --a
"'Fast Cleanup' action caused severe errors!",
"It's strongly recommended to turn 'Fast Cleanup'",
"feature OFF and restart CelPad.",
txtfnt = {"normalfont"};
};
PopSamp = {
"Message bigfont AaBbCc123",
"Message normalfont AaBbCc123",
"Message smallfont AaBbCc123",
txtfnt = {"bigfont","normalfont","smallfont"};
};
};
scanWarn = {
sslow = {
logm = "!!! warning: system slow, possibly there are too many objects in memory";
msgm = "- System slow. Check amount of objects in memory.";
};
niltotasks = {
logm = "!!! warning: cleanup lags possibility detected, cleanups will run as risky";
msgm = "- Complex queries running against large result set can cause lags during the cleanup process. To prevent timeouts caused by those lags, CelPad will reduce objects pack every time the lag is detected. Lag detection is indicated by warning pop-up message. The message offers resetting the pack back to its original size (and thus speed up the cleanup), however, the safest way is ignoring the message and leaving CelPad to handle the situation automatically.";
};
notaskscel = {
logm = "!!! warning: no tasks defined, all object of searched type will match";
msgm = "- No tasks defined, all objects will be loaded into memory.";
};
notasksrs = {
logm = "!!! warning: no tasks applied to result set";
msgm = "- No tasks defined. If applied to result set, search of identical scan type will return the same set (either performs no tasks or purify task returns all objects). If different scan type is applied, '"..templates.metaQuery.zz1_scan_pure[1].."' and / or '"..templates.metaQuery.zz1_scan_within[1].."' settings are important for scan results.";
};
large  = {
logm = "!!! warning: possibly large result set.";
msgm = "- Current scan query definition gives possibility to return large amount of objects, which will slow down your system. Try to narrow your search as much as possible.";
};
posDed = {
logm = "!!! warning: position deduplication is ON";
msgm = "- Position deduplication feature is ON, Celestia time will be stopped during the satellites or locations load. If warnings are ON, the log can be flooded with warning messages.";
};
};
};
bigfont = celestia:loadfont("fonts/sans14_ru.txf") or normalfont;
tCPfonts = {
smallfont = smallfont;
normalfont = normalfont;
bigfont = bigfont;
};
gVarBinds = {
gUpdate = function() 
	ScrX, ScrY = celestia:getscreendimension();
	observer = celestia:getobserver();
	local timenow = os.clock();
	timedelta = timenow - (oldtime or 0);
	oldtime = timenow;
-- timedeltamax = math.max(timedelta,timedeltamax)
	if timedelta >= sysSlowRisk and timedelta < 2 then
		myCelPad:systemMsg(nil,nil,"1");
		if ms020AdaptiveLoops then	
			Fuse = Fuse*0.5
		end;
	end;
	if  Fuse ~= 1 and timedelta <= sysSlowBack then 
		Fuse = 1
	end;
	if #tCelPadHUD.setupPanes > 0 or not myCelPad.Initialized then 
		if myCelPad.Initialized and (not myCelPad.openSetTimer) then
			myCelPad:settingsOpened()
		end;
		local wpanes = false
		for i,s in ipairs(tCelPadHUD.setupPanes) do
			if string.sub(s.objname,1,7) == "Windows" then wpanes = true; end
		end
		gVarBinds.updateGlobals(wpanes);
	end
end;
updateGlobals = function(wpanes)
	local ofclean, nfclean, oloops
	if wpanes or not myCelPad.Initialized then
		showWrapBtn = tSettings.Windows.showWrapBtn;
		showTextBtn = tSettings.Windows.showTextBtn;
		showScrollBtn = tSettings.Windows.showScrollBtn;
		showVerbBtn = tSettings.Windows.showVerbBtn;
		showViewBtn = tSettings.Windows.showViewBtn;
		showMenuHidBtn = tSettings.Windows.showMenuHidBtn;
		rclHideMenu = tSettings.Windows.rclHideMenu;
		Maxpageitems = tSettings.Windows.Maxpageitems;
		cp1schmenup = tSettings.Windows.cp1schmenup
		cp1schmainw = tSettings.Windows.cp1schmainw
		cp1schcontp = tSettings.Windows.cp1schcontp		
		cpfntmenu = tCPfonts[tSettings.Windows.cpfntmenu[1]];
		cpfntmainw = tCPfonts[tSettings.Windows.cpfntmainw[1]];
		cpfntheader = tCPfonts[tSettings.Windows.cpfntheader[1]];
		cpcolheader = tSettings.Windows.cpcolheader;
		cpfntcolhghlt = tSettings.Windows.cpfntcolhghlt;
		cpfntcolmainw = tSettings.Windows.cpfntcolmainw;
		wMovWin = tSettings.Windows.wMovWin[1];
		wMovMenu = tSettings.Windows.wMovMenu[1];
		--Advanced
		gShadowsize = tSettings.WindowsAdv.gShadowsize;
		cpbordon = tSettings.WindowsAdv.cpbordon;
		cpfillshadow = tSettings.WindowsAdv.cpfillshadow;
		gShowShadows = tSettings.WindowsAdv.gShowShadows;
		gButtonsize = tSettings.WindowsAdv.gButtonsize;
		gButtonspace = tSettings.WindowsAdv.gButtonspace;
		msgButtonwidth = tSettings.WindowsAdv.msgButtonwidth;
		msgButtonheight = tSettings.WindowsAdv.msgButtonheight;
		gMenusize = tSettings.WindowsAdv.gMenusize;
		CPmaxW = tSettings.WindowsAdv.CPmaxW;
		CPmaxH = tSettings.WindowsAdv.CPmaxH;
		CPiconH = tSettings.WindowsAdv.CPiconH;
		CPicor = tSettings.WindowsAdv.CPicor[1];
		defMnSticky = tSettings.WindowsAdv.defMnSticky;
		defMnHiding = tSettings.WindowsAdv.defMnHiding;
		defgScroll = tSettings.WindowsAdv.defgScroll;
		defgWordwrap = tSettings.WindowsAdv.defgWordwrap;
		defgDrawtext = tSettings.WindowsAdv.defgDrawtext;
		defgVerbose = tSettings.WindowsAdv.defgVerbose;
		defzCascade = tSettings.WindowsAdv.defzCascade;
		maxInfoHght = tSettings.WindowsAdv.maxInfoHght
		maxSyslWidth = tSettings.WindowsAdv.maxSyslWidth
		--popup Message Scheme
		cpfillpupmsga = tSettings.WindowsAdvPM.cpfillpupmsga;
		cpfillpupmsgw = tSettings.WindowsAdvPM.cpfillpupmsgw;
		cpfillpupmsgi = tSettings.WindowsAdvPM.cpfillpupmsgi;
		--deltas
		--menu pane color scheme
		cpfillmenup = tDeltaSettings.Windows.cpfillmenup;
		cpbormenup = tDeltaSettings.Windows.cpbormenup;
		cpcolmenup = tDeltaSettings.Windows.cpcolmenup;
		cpfillbutton = tDeltaSettings.Windows.cpfillbutton;
		cpcolbutton = tDeltaSettings.Windows.cpcolbutton;
		cpborbutton = tDeltaSettings.Windows.cpborbutton;
		cpfillmenul = tDeltaSettings.Windows.cpfillmenul;
		cpbormenul = tDeltaSettings.Windows.cpbormenul;
		cpcolmenul = tDeltaSettings.Windows.cpcolmenul;
		cpbormenue = tDeltaSettings.Windows.cpbormenue;
		cpfillmenue = tDeltaSettings.Windows.cpfillmenue;
		cpcolmenue = tDeltaSettings.Windows.cpcolmenue;
		cpborvlist =  tDeltaSettings.Windows.cpborvlist;
		cpfillvlist = tDeltaSettings.Windows.cpfillvlist;
		cpfillarrow = tDeltaSettings.Windows.cpfillarrow;
		cpborarrow = tDeltaSettings.Windows.cpborarrow;
		cpcolarrow = tDeltaSettings.Windows.cpcolarrow;
		--Main Window Color Scheme
		cpfillmvbtn =  tDeltaSettings.Windows.cpfillmvbtn;
		cpborframe =  tDeltaSettings.Windows.cpborframe;
		cpfillframe = tDeltaSettings.Windows.cpfillframe;
		cpbormvbtn =  tDeltaSettings.Windows.cpbormvbtn;
		cpcolmwarrow = tDeltaSettings.Windows.cpcolmwarrow;
		cpfillmwarrow = tDeltaSettings.Windows.cpfillmwarrow;
		cpbormwarrow =  tDeltaSettings.Windows.cpbormwarrow;
		cpfillmwslider = tDeltaSettings.Windows.cpfillmwslider;
		cpbormwslider =  tDeltaSettings.Windows.cpbormwslider;
		cpfillmwslfr = tDeltaSettings.Windows.cpfillmwslfr;
		cpbormwslfr =  tDeltaSettings.Windows.cpbormwslfr;
		cpfillrzbtn = tDeltaSettings.Windows.cpfillrzbtn;
		cpcolrzbtn = tDeltaSettings.Windows.cpcolrzbtn;
		cpborrzbtn =  tDeltaSettings.Windows.cpborrzbtn;
		cpcolheader =  tDeltaSettings.Windows.cpcolheader;
		--Control Panel Color Scheme
		cpfillframecp =  tDeltaSettings.Windows.cpfillframecp;
		cpborframecp =  tDeltaSettings.Windows.cpborframecp;
		cpfilliconn = tDeltaSettings.Windows.cpfilliconn;
		cpboriconn = tDeltaSettings.Windows.cpboriconn;
		cpfilliconm = tDeltaSettings.Windows.cpfilliconm;
		cpboriconm = tDeltaSettings.Windows.cpboriconm;
		cpcolicon =  tDeltaSettings.Windows.cpcolicon;
		--PopMSG Color Scheme
		cpborpupmsga = tDeltaSettings.Windows.cpborpupmsga;
		cpcolpupmsga = tDeltaSettings.Windows.cpcolpupmsga;
		cpfillpupbxa = tDeltaSettings.Windows.cpfillpupbxa;
		cpborpupbxa = tDeltaSettings.Windows.cpborpupbxa;
		cpcolpupbxa = tDeltaSettings.Windows.cpcolpupbxa;
		cpfillpupbtna = tDeltaSettings.Windows.cpfillpupbtna;
		cpborpupbtna = tDeltaSettings.Windows.cpborpupbtna;
		cpcolpupbtna = tDeltaSettings.Windows.cpcolpupbtna;
		cpborpupmsgw = tDeltaSettings.Windows.cpborpupmsgw;
		cpcolpupmsgw = tDeltaSettings.Windows.cpcolpupmsgw;
		cpfillpupbxw = tDeltaSettings.Windows.cpfillpupbxw;
		cpborpupbxw = tDeltaSettings.Windows.cpborpupbxw;
		cpcolpupbxw = tDeltaSettings.Windows.cpcolpupbxw;
		cpfillpupbtnw = tDeltaSettings.Windows.cpfillpupbtnw;
		cpborpupbtnw = tDeltaSettings.Windows.cpborpupbtnw;
		cpcolpupbtnw = tDeltaSettings.Windows.cpcolpupbtnw;
		cpborpupmsgi = tDeltaSettings.Windows.cpborpupmsgi;
		cpcolpupmsgi = tDeltaSettings.Windows.cpcolpupmsgi;
		cpfillpupbxi = tDeltaSettings.Windows.cpfillpupbxi;
		cpborpupbxi = tDeltaSettings.Windows.cpborpupbxi;
		cpcolpupbxi = tDeltaSettings.Windows.cpcolpupbxi;
		cpfillpupbtni = tDeltaSettings.Windows.cpfillpupbtni;
		cpborpupbtni = tDeltaSettings.Windows.cpborpupbtni;
		cpcolpupbtni = tDeltaSettings.Windows.cpcolpupbtni;
		for i=1,4 do
			--menu pane color scheme
			tDeltaSettings.Windows.cpfillmenup[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillmenup[i];
			tDeltaSettings.Windows.cpbormenup[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpbormenup[i];
			tDeltaSettings.Windows.cpcolmenup[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolmenup[i];
			tDeltaSettings.Windows.cpfillbutton[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillbutton[i];
			tDeltaSettings.Windows.cpcolbutton[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolbutton[i];
			tDeltaSettings.Windows.cpborbutton[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpborbutton[i];
			tDeltaSettings.Windows.cpfillmenul[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillmenul[i];
			tDeltaSettings.Windows.cpbormenul[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpbormenul[i];
			tDeltaSettings.Windows.cpcolmenul[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolmenul[i];
			tDeltaSettings.Windows.cpfillmenue[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillmenue[i];	
			tDeltaSettings.Windows.cpbormenue[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpbormenue[i];
			tDeltaSettings.Windows.cpcolmenue[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolmenue[i];
			tDeltaSettings.Windows.cpfillvlist[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillvlist[i];	
			tDeltaSettings.Windows.cpborvlist[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpborvlist[i];
			tDeltaSettings.Windows.cpfillarrow[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpfillarrow[i];
			tDeltaSettings.Windows.cpborarrow[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpborarrow[i];	
			tDeltaSettings.Windows.cpcolarrow[i] = cp1schmenup[i] + tSettings.WindowsAdvMN.Dcpcolarrow[i];
			--Main Window Color Scheme
			tDeltaSettings.Windows.cpfillmvbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmvbtn[i];
			tDeltaSettings.Windows.cpborframe[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpborframe[i];
			tDeltaSettings.Windows.cpfillframe[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillframe[i];
			tDeltaSettings.Windows.cpbormvbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormvbtn[i];
			tDeltaSettings.Windows.cpfillmwarrow[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmwarrow[i];
			tDeltaSettings.Windows.cpcolmwarrow[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpcolmwarrow[i];
			tDeltaSettings.Windows.cpbormwarrow[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormwarrow[i];
			tDeltaSettings.Windows.cpfillmwslider[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmwslider[i];
			tDeltaSettings.Windows.cpbormwslider[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormwslider[i];
			tDeltaSettings.Windows.cpfillmwslfr[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillmwslfr[i];
			tDeltaSettings.Windows.cpbormwslfr[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpbormwslfr[i];
			tDeltaSettings.Windows.cpfillrzbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpfillrzbtn[i];
			tDeltaSettings.Windows.cpcolrzbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpcolrzbtn[i];
			tDeltaSettings.Windows.cpborrzbtn[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpborrzbtn[i];
			tDeltaSettings.Windows.cpcolheader[i] = cp1schmainw[i] + tSettings.WindowsAdvMW.Dcpcolheader[i];
			--Control Panel Color Scheme
			tDeltaSettings.Windows.cpfillframecp[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpfillframecp[i];
			tDeltaSettings.Windows.cpborframecp[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpborframecp[i];
			tDeltaSettings.Windows.cpfilliconn[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpfilliconn[i];
			tDeltaSettings.Windows.cpboriconn[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpboriconn[i];
			tDeltaSettings.Windows.cpfilliconm[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpfilliconm[i];
			tDeltaSettings.Windows.cpboriconm[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpboriconm[i];
			tDeltaSettings.Windows.cpcolicon[i] = cp1schcontp[i] + tSettings.WindowsAdvCP.Dcpcolicon[i];
			--PopMSG Color Scheme
			tDeltaSettings.Windows.cpborpupmsga[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpborpupmsga[i];
			tDeltaSettings.Windows.cpcolpupmsga[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpcolpupmsga[i];
			tDeltaSettings.Windows.cpfillpupbxa[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpfillpupbxa[i];
			tDeltaSettings.Windows.cpborpupbxa[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpborpupbxa[i];
			tDeltaSettings.Windows.cpcolpupbxa[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpcolpupbxa[i];
			tDeltaSettings.Windows.cpfillpupbtna[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpfillpupbtna[i];	
			tDeltaSettings.Windows.cpborpupbtna[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpborpupbtna[i];
			tDeltaSettings.Windows.cpcolpupbtna[i] = cpfillpupmsga[i] + tSettings.WindowsAdvPM.Dcpcolpupbtna[i];
			tDeltaSettings.Windows.cpborpupmsgw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpborpupmsgw[i];
			tDeltaSettings.Windows.cpcolpupmsgw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpcolpupmsgw[i];
			tDeltaSettings.Windows.cpfillpupbxw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpfillpupbxw[i];
			tDeltaSettings.Windows.cpborpupbxw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpborpupbxw[i];
			tDeltaSettings.Windows.cpcolpupbxw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpcolpupbxw[i];
			tDeltaSettings.Windows.cpfillpupbtnw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpfillpupbtnw[i];	
			tDeltaSettings.Windows.cpborpupbtnw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpborpupbtnw[i];
			tDeltaSettings.Windows.cpcolpupbtnw[i] = cpfillpupmsgw[i] + tSettings.WindowsAdvPM.Dcpcolpupbtnw[i];
			tDeltaSettings.Windows.cpborpupmsgi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpborpupmsgi[i];
			tDeltaSettings.Windows.cpcolpupmsgi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpcolpupmsgi[i];
			tDeltaSettings.Windows.cpfillpupbxi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpfillpupbxi[i];
			tDeltaSettings.Windows.cpborpupbxi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpborpupbxi[i];
			tDeltaSettings.Windows.cpcolpupbxi[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpcolpupbxi[i];
			tDeltaSettings.Windows.cpfillpupbtni[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpfillpupbtni[i];	
			tDeltaSettings.Windows.cpborpupbtni[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpborpupbtni[i];
			tDeltaSettings.Windows.cpcolpupbtni[i] = cpfillpupmsgi[i] + tSettings.WindowsAdvPM.Dcpcolpupbtni[i];
		end;
	end	
		--System
	ofclean = ms300fastCleanup
	oloops = ms020AdaptiveLoops
	ms010ScanLoop = tSettings.SystemSet.ms010ScanLoop;
	ms020AdaptiveLoops = tSettings.SystemSet.ms020AdaptiveLoops;
	ms030AddInfo = tSettings.SystemSet.ms030AddInfo[1]
	ms040DefView1 = tSettings.SystemSet.ms040DefView1;
	ms050DefView2 = tSettings.SystemSet.ms050DefView2;
	ms060InheritFinder = tSettings.SystemSet.ms060InheritFinder
	ms065VwSumAutoLd = tSettings.SystemSet.ms065VwSumAutoLd;
	ms070autoScanOn = tSettings.SystemSet.ms070autoScanOn
	ms080InclNils = tSettings.SystemSet.ms080InclNils;
	ms085PosDedup = tSettings.SystemSet.ms085PosDedup;
	ms090ShowPos = tSettings.SystemSet.ms090ShowPos
	ms100ShowCat = tSettings.SystemSet.ms100ShowCat
	ms110sumShowNames = tSettings.SystemSet.ms110sumShowNames
	ms130untDecPlac = tSettings.SystemSet.ms130untDecPlac;
	ms140askForDur = tSettings.SystemSet.ms140askForDur
	ms150defDur = tSettings.SystemSet.ms150defDur
	ms151defRadMtpl = tSettings.SystemSet.ms151defRadMtpl
	ms160VerboseLogs = tSettings.SystemSet.ms160VerboseLogs;
	ms161AlertsInLogs = tSettings.SystemSet.ms161AlertsInLogs;
	ms165ShowScanWarnings = tSettings.SystemSet.ms165ShowScanWarnings
	ms170maxSysLog = tSettings.SystemSet.ms170maxSysLog
	ms180rotLog = tSettings.SystemSet.ms180rotLog;
	ms190OpenSetWarn = tSettings.SystemSet.ms190OpenSetWarn
	ms200autoAdaptOn = tSettings.SystemSet.ms200autoAdaptOn
	ms300fastCleanup = tSettings.SystemSet.ms300fastCleanup
	ms400updateOpened = tSettings.SystemSet.ms400updateOpened
	if ControlPanel and ofclean ~= ms300fastCleanup then
		nfclean = ms300fastCleanup;
		ms300fastCleanup, tSettings.SystemSet.ms300fastCleanup = not nfclean, not nfclean;
		if not ControlPanel.mainFrame.MSGupT["fastClnWarnMSG"] then
			local fastClnWarnMSG = PopMessage:new({tCelPadHUD.popMsgs});
			fastClnWarnMSG:init(ControlPanel.mainFrame,"fastClnWarnMSG",x,y,"Alert",nil,"a","yn",
			function()
				table.insert(myCelPad.rstcmdtab,
				function()
					ms300fastCleanup, tSettings.SystemSet.ms300fastCleanup = nfclean, nfclean;
				end);
				CelPadCheck:Action()
				fastClnWarnMSG = nil;
			end,
			function()
				fastClnWarnMSG = nil;
			end
			);
			fastClnWarnMSG:makeBranch(ControlPanel);
		end;
	end;
	if ms020AdaptiveLoops ~= oloops and not ms020AdaptiveLoops then
		Fuse = 1
		for i,p in ipairs(tCelPadFinder.runningLogs) do
			if p.marker then
				CPlog("adaptive loops off, marker cancelled",0,p.sysLog)
				p.marker.cancelrq = true
			end;
		end
	end;
end;
}
