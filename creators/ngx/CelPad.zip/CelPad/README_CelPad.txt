############
CelPad v.1.0
(c) ngx 2013
############

CelPad is plugin for Lua Edu Tools v.1.2 Beta, developed and tested on Celestia 1.6.1. 

CelPad is a tool with simple graphical interface (GUI), which searches for Celestia objets and allows to perform some commands, like 'go to' or 'mark' and others. Searches are based on defined object parameters. It is working with stars, orbiting bodies, deep space objects and locations. CelPad scans through Celestia objects by means of editable queries, which define objects' attributes that should be searched for (name, radius, type etc.). Query definitions can be saved to files on HDD for future re-use.

There are also many editable settings for GUI appearence and behaviour, as well as for other CelPad functions. You can try various settings combinations to make CelPad match your requirements. CelPad settings profiles can also be saved to files.

Refer to application Help panes ('?' buttons) for detailed usage information.


### CREDITS ###
Many thanx to:

-Creators of Lua Edu Tools - Vincent Giangiulio and Hank Ramsey - for their master code. CPBox and CPClass files are modified code from Lua Edu Tools with kind permission from Vincent Giangiulio.

-Jogad for inspiration and very good learning material in the 'slideshow' plugin.

-lua-users.org and snippets.luacode.org for some very useful functions.


### PREREQUISITIES ###

-Celestia 1.6.1. Not extensively tested on 1.6.0, but should work. Definitely, will not work on Celestia 1.5 and older. Tested only on Windows PCs.
-Lua Edu Tools 1.2 Beta8 (download from http://www.celestiamotherlode.net/creators/v_giangiulio/Lua_Edu_Tools_1.2beta8.zip)
-To save CelPad profiles, Celestia must have read/write access to its ..\extras\ directory. If saves are not permitted, CelPad will work, however settings will not be saved and unpredictable errors may occure.


### INSTALLATION ###

1. Check installation prerequisities (see bulletpoints above). Make sure 'Lua Edu Tools' are correctly installed and functional. Refer to included README_Lua_Edu_Tools.txt if needed.

2. Extract CelPad directory from CelPad.zip archive into Celestia's \extras\ directory (usually C:\Program Files\Celestia\extras\). If you want to use different directory within Celestia's \extras\ (i.e. Lua Edu Tools' '\adds\'), edit 'profileDIR' property on the beginning of 'CelPadConfig.lua' file accordingly.

3. Edit config.lua file in ...\Celestia\extras\lua_edu_tools\ directory as follows:
3.1 Find 'toolset' section (starts around line 47 in original file).
3.2 Add "CelPadBox", (including double quotes and comma) entry before "compassBox", entry, like this:
        
        "HRBox",
        "KeplerParamBox",
        "CelPadBox", -- <- CelPad checkbox entry
        --"virtualPadBox",
        "compassBox",

4. Start Celestia and check presence of CelPad's checkbox in Lua Edu Tools.

### IMPORTANT!: Sometimes, Lua Edu Tools may fail to load during the first Celestia start on slower or overloaded PCs (i.e. on some notebooks or virtual machines) after the PC's start-up. Just re-start Celestia, next starts usualy work fine.
Note: Failed load is indicated with message "attempt to perform arithmetic on global 'toolBoxHeight' (a nil value)" in Celastia log.


### GETTING STARTED: To start CelPad, click CelPad checkbox in Lua Edu Tools. Small square with 'CelPad' name will show up. Click on that square to start CelPad GUI Control Panel. Drag the square or Control Panel anywhere on the screen. Right click on Control Panel to get CelPad functions menu. Right click on CelPad square to show/hide the ControlPanel. Uncheck CelPad box (or close GUI Control Panel) for clean shutdown.
Note: After the very first start of CelPad, initial ini_profile file is created, which generates warning message in Celestia's log. That is not an error, the message can be ignored.


### PERFORMANCE NOTES (mainly for slower PCs): Please read Help panes, especially 'Performance Considerations' to avoid occurence of Lua hook timeouts and other performance problems. Timeouts occure when Lua script (or also .celx scripts) runs longer than certain time ( very short ) without contacting Celestia. This does not have to be fatal in case of CelPad, however, it leaves the system in unclear state so Celestia restart is necessary.

CelPad processing (for example scanning or marking) can be tuned to avoid timeouts. CelPad performs tasks on object packs instead of on the whole set. Bigger pack makes the process faster, but more vulnerable for timeouts. Small packs make scan safe, but longer. Try to find optimum, packs on their upper limit don't necessarily have to make overall scans faster. The more powerful is your PC, the bigger packs can be used. Slower or loaded systems should use small packs settings.


### KNOWN BUGS AND LIMITATIONS ###
(if you find new bug, please send the description to my email: ngx@zoznam.sk):

-Searching for object names can use only values returned by 'object:name()' method. Alternative names are not available in this version.

-If regular expression is used in some string search, its invalid definition will lead to whole Lua Edu Tools crash. Celestia must be restarted after.

-Re-scannings of large result sets (1 000 000+) with more complex queries increase the risk of cleanup lags, which can sometimes lead to timeouts. Although certain protecting workaround mechanism is implemented, so far I don't know how to get rid of it for good, sorry :(

-Text fields edit actions can collide with key mappings in Celestia script if such a script is running along with CelPad. In that case usually script takes priority. Editation also collides with 'a' and 'z' Celestia keys, so if you write something with 'a' or 'z' in it, observer's speed changes. 

-Numbers with long decimals may sometimes exceed display field width.

-If amount of icons in Control Panel cause panel to resize over its defined limits, icons draw will become faulty.

-If system is slow or resize is done too fast, window can stay scattered after move or resize. Press and hold top bar or resize button or some of sliders for a while, the window will recompute.

-If menu or info panes in sticky mode reach the screen edge during the Celestia window resize, they will become scattered. Press sticky button to turn sticky OFF, they will recompute.

-If message pane is in hiding mode, it can flick all over the screen for a split second when hiding past the bottom. Ugly, but harmless.

-Horizontal or vertical sliders can sometimes start flicker when window content is changed. Just drag them forward and back a bit, they will recompute.

-'Fast Cleanup' feature is still experimental and unstable, please read Help panes for more information. If you try it and you experience errors, turn it off.

-No localization in this version.


### TODO LIST ###

-bugfix
-code cleanup and optimization
-some new functions and object commands 
-localization readiness (if there's an interest...)


### PROGRAMMERS NOTE ###

CelPad code is free for non-commercial use or addon extensions, the code used from Lua Edu Tools is copyrighted the same as Lua Edu Tools.

If you decide to go public with your extensions, please don't change original files, just add yours. That would prevent mismatch in case of updates or patches. If you need inevitable change in CelPad code, please email me details.

It was one of my firsts encounters with OOP and LUA, sorry for the mess :) Many things could have been done better, however, during the final code cleanup I left some code intact (don't scratch it, it works...).

Please send bug reports, comments and suggestions, if you have some, to my email address.

Thank you!

ngx@zoznam.sk
