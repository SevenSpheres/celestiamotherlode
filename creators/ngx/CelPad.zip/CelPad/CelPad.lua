-- CelPad.lua

celestia:log("CelPad: loading chasis")

require "CPClass";

tCelPad = {
sysLog = {};
Timers = {
};
Parsers = {
};
}
CelPad = CClass {
classname = "CelPad";
superclass = CPObject;
initialized = function (this,c)
	if c ~= nil then
		this.Initialized = (c ~= false);
		return this;
	else
		return this.Initialized or false;
	end
end;
deinitialized = function (this,c)
	if c ~= nil then
		this.Deinitialized = (c ~= false);
		return this;
	else
		return this.Deinitialized or false;
	end
end;
running = function (this,c)
	if c ~= nil then
		this.Running = (c ~= false);
		return this;
	else
		return this.Running or false;
	end
end;
init_allattr = function(this)
	this.objname = "myCelPad";
	this.tCelPad = tCelPad;
	this.tCelPadFinder = tCelPadFinder;
	this.SavingMSG = {};
	this.LoadingMSG = {};
	this.SavedMSG = {};
	this.closeTab = {};
	this.rstcmdtab = this.rstcmdtab or {};
	fastCleanup = nil;
end;
Initialize = function(this)
	if not gCPload then
		require "comLib";
		require "CelPadConfig";
		require "CPBox";
		require "CelPadHUD";
		require "CelPadFinder";
		require "CelPadHELP";
		syslogInit(tCPClass.sysLog)
		syslogInit(tCelPad.sysLog);
		gCPload = true;
		CPlog("CelPad: loaded")
	end;
	startInst = #CPInstances	
	if DebugLog	then
		CPlog("CelPad DEBUG: "..#CPInstances.." instances at the start")
	end
	this:init_allattr()
	gVarBinds:gUpdate();
	myCelPadHUD = CelPadHUD:new()
	myCelPadHUD:init()
	CPlog("CelPad: GUI created as "..tostring(myCelPadHUD))
	if table_num(this.rstcmdtab) == 0 then
		this:loadCP("profile","ini");
		this:loadCP("SYS","default");
		this:loadCP("GUI","default");
	else
		for i,k in pairs(this.rstcmdtab) do
			k();
			this.rstcmdtab[i] = nil; 
		end
	end
	CPSquareWindow.Visible = true;
	this.nilfams = {};
	this:initialized(true)
	this:deinitialized(false)
	CPlog("CelPad: initialized")
end;
Deinitialize = function (this)
	this:initialized(false)
	this:deinitialized(true)	
	rmAllRefMarks()
	if ControlPanel then
		ControlPanel:wkill();
		ControlPanel = nil;
	end;
	myCelPadHUD:destruct();
	CPlog("CelPad: GUI "..tostring(myCelPadHUD).." closed")
	this.ClosingCPMSG = nil;
	this.saved = nil;
	this.sortedL, this.sortedS = nil,nil;
	this.openSetTimer = nil;
	this.systemSlowTimer = nil;
	IconsReposTimer = nil;
	this:init_allattr()
	CPSquareWindow.Visible = false;
	if restPurgeLogs then
		syslogNil(tCelPad.sysLog)
		syslogInit(tCelPad.sysLog)
		syslogNil(tCelPadHUD.sysLog)
		syslogInit(tCelPadHUD.sysLog)
		syslogNil(tCelPadFinder.sysLog)
		syslogInit(tCelPadFinder.sysLog)
		syslogNil(tCPClass.sysLog)
		syslogInit(tCPClass.sysLog)
	end;
	CPlog("CelPad: closed")
	this.closerq = nil;
	if DebugLog then
		CPlog("CelPad DEBUG: "..#CPInstances.." instances at the end")
	end
	if #CPInstances ~= startInst then 
		CPlog("CelPad Alert: inconsistent instances exit status! ("..tostring(#CPInstances).."; should be "..tostring(startInst)..")")
	end
	collectgarbage();
	if table_num(this.rstcmdtab) > 0 then
		CelPadCheck:Action()
	end
end;
CelPadUpdate = function(this)
	if this.Running then
		if not this.Initialized then
			this:Initialize();
		end;
		myCelPadHUD:updateScrRsz();
		--update timers
		for i,v in ipairs(this.tCelPad.Timers) do
			v:update();
		end;
		--update scanners
		for i,v in ipairs(this.tCelPadFinder.runningFinders) do
			v:update();
		end;
		--update logs
		for i,v in ipairs(this.tCelPadFinder.runningLogs) do
			v:update();
		end;
		--update parsers
		for i,v in ipairs(this.tCelPad.Parsers) do
			v:update();
		end;
		-- following updates
		gVarBinds:gUpdate();
		if this.closerq then 
			if ControlPanel and not this.ClosingCPMSG then
				this.ClosingCPMSG = PopMessage:new({tCelPadHUD.popMsgs});
				this.ClosingCPMSG:init(ControlPanel.mainFrame,"ClosingCPMSG",x,y,"Warning",nil,"w","ok")
				this.ClosingCPMSG:makeBranch(ControlPanel); 
				CPlog("CelPad: close request...")
			end;
			for i,v in ipairs(tCelPadFinder.runningFinders) do
				if v.feeder and not v.feeder.cancelrq then
					v.feeder.cancelrq  = true
				end
				if v.runningScan then 
					v.cancelscan = true
				end
			end;
			for i,v in ipairs(tCelPadFinder.runningLogs) do
				if v.feeder and not v.feeder.cancelrq then
					v.feeder.cancelrq  = true
				end
				if v.marker and not v.marker.cancelrq then
					v.marker.cancelrq  = true
				end
			end;
			for i,v in ipairs(tCelPad.Timers) do
				v.status = "kill"; 
			end
			if (not (this.saving or this.savingprf)) then
				local finder
				this.saved = this.saved or false
				this.sortedL = this.sortedL or false
				if not this.sortedL then
					if fastCleanup then
						table.sort(this.closeTab,function(a,b) 
							local retval
							local acond =  a.nilfam[a.famid][3]
							local bcond =  b.nilfam[b.famid][3]
							if acond == nil and bcond ~= nil then
								retval = true
							end
							return retval
						end)
					end
					this.sortedL = true
				end
				if #this.closeTab >= 1 and this.sortedL then
						finder = this.closeTab[1] 
						if not finder.closing then
							finder.wobj.closeButton:Action() 
						end;
				elseif not this.saved then
					myCelPadHUD:saveallpos()
					this.saved = true
					CPlog("CelPad: all finders closed, GUI positions saved",0,this.sysLog);
				else
					local tabs = (#tCelPadFinder.runningFinders  + #tCelPadFinder.runningLogs  + #tCelPad.Timers)
					if tabs == 0 then
						this:running(false)
					end
				end;
			end
		end;
		collectgarbage();
	else
		if not this.Deinitialized then
			this:Deinitialize()
		end
	end;
end;
firstRun = function(this)
	this.FirstRun = PopMessage:new();
	this.FirstRun:init(CelPadBox,"FirstRun",x,y,"Hello World",nil,"i","ok");
	this.FirstRun:makeBranch(myCelPadHUD); 
end;
settingsOpened = function(this)
	if ms190OpenSetWarn > 0 then
		this.openSetTimer = CPtimer:new({tCelPad.Timers});
		this.openSetTimer:init("this.openSetTimer","this.openSetTimer",ms190OpenSetWarn,"standalone",0,
		function(o)
			this.CloseSetMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
			this.CloseSetMSG:init(CPSquareWindow,"CloseSetMSG",x,y,"Warning",nil,"w","yn", 
				function()
					local paneself
					while #tCelPadHUD.setupPanes > 0 do
						paneself = tCelPadHUD.setupPanes[1]
						paneself.closebutton.Action()
					end;
					this.openSetTimer = nil;
				end,
				function()
					this.openSetTimer = nil;
				end
				);
				this.CloseSetMSG:makeBranch(myCelPadHUD); 
				this.CloseSetMSG.ynbutton.ynbuttonN.Customdraw = function(this)
				if #tCelPadHUD.setupPanes == 0 then this.Action(this); end;
			end;
		end
		);
		this.openSetTimer:makeBranch(this) 
	end
end;
systemMsg = function(this,x,y,cause,finder,lnchfnc,parser)
	if string.find(cause,"1") then 
		local setdelay = ms200autoAdaptOn or 4
		local runtask = 0
		for i,v in ipairs(this.tCelPadFinder.runningFinders) do
			runtask = runtask + (v.runningTask or 0)
		end;
		for i,v in ipairs(this.tCelPadFinder.runningLogs) do
			runtask = runtask + (v.runningTask or 0)
		end;
		if runtask > 0 and ControlPanel then
			if not this.systemSlowTimer and tSettings.SystemSet.ms020AdaptiveLoops == false then
				this.systemSlowTimer = CPtimer:new({tCelPad.Timers});
				this.systemSlowTimer:init("this.systemSlowTimer","this.systemSlowTimer",setdelay,"standalone",0,
				function(o)
					if timedelta>sysSlowRisk and tSettings.SystemSet.ms020AdaptiveLoops == false then 
						for i,v in ipairs(ControlPanel.mainFrame.popupMenus) do
							if v.objname == "SystemSlowMSG" then
								v.okbutton:Action()
							end
						end
						tSettings.SystemSet.ms020AdaptiveLoops = true;
						gVarBinds.updateGlobals();
						this.SystemSlowMSG = PopMessage:new({ControlPanel.mainFrame.popupMenus});
						this.SystemSlowMSG:init(ControlPanel.mainFrame,"SystemSlowMSG",x,y,"Warning",nil,"w","ok");
						this.SystemSlowMSG:makeBranch(ControlPanel); 
					end
					this.systemSlowTimer=nil;
				end
				);
				this.systemSlowTimer:makeBranch(this) 
			end
		end
	elseif cause == "fcerr" then
		this.FastCleanErr = PopMessage:new({ControlPanel.mainFrame.popupMenus});
		this.FastCleanErr:init(ControlPanel.mainFrame,"FastCleanErr",x,y,"Alert",nil,"a","ok");
		this.FastCleanErr:makeBranch(ControlPanel);
	else
		if string.find(cause,"nillag") then 
			finder.nilWarnMSGup = true
			finder.nilToWarnMSG = PopMessage:new({finder.oriframe.popupMenus}); 
			finder.nilToWarnMSG:init(finder.oriframe,"nilToWarnMSG",centX(finder.oriframe),centY(finder.oriframe),"Warning",nil,"w","yn",
			function()
				if finder.niling then
					if finder.alrtlogs then
						CPlog("!!! warning: cleanup loops reset when value reached "..tostring(parser.maxinloop),0,finder.sysLog)
					end
					parser.maxinloop = ms010ScanLoop*Fuse
					finder.lagcnt = 1
				end;
				finder.nilWarnMSGup = nil
			end,
			function()
				finder.nilWarnMSGup = nil
			end
			);
			finder.nilToWarnMSG:makeBranch(finder.oriframe);		
		else
			local sumlaunch
			local risksmsg = {
			"< autowrap >",
			"<-70",
			"Scan risks:"
			};
			local scanwarn = templates2.scanWarn;
			for i in string.gmatch(cause,"%w+") do
				table.insert(risksmsg,scanwarn[i].msgm)
				sumlaunch = true		
			end;
			if sumlaunch then
				table.insert(risksmsg,"")
				table.insert(risksmsg,"Are you sure you want to continue?")
				finder.scanRiskMSG = PopMessage:new({finder.oriframe.popupMenus});  
				finder.scanRiskMSG:init(finder.oriframe,"scanRiskMSG",x,y,"Warning",risksmsg,"w","yn", 
				function()
					if finder.alrtlogs then
						for i in string.gmatch(cause,"%w+") do
							CPlog(tostring(scanwarn[i].logm),0,finder.sysLog)
						end;
					end
					lnchfnc()
				end,
				function()
					CPlog("### scan aborted",0,finder.sysLog);
					finder.runReady = nil;
				end
				);
				finder.scanRiskMSG:makeBranch(finder);
			end
		end;
	end; 
end;
saveCP = function(this,what,savename,finder)
	tts[what] = {};
	local qtype ="";
	if what == "QR" then
		qtype = finder.metaQueryVal.qtype;
	end;
	local profileFile = profileDIR..savename.."_"..what..qtype..".cpsav";
	local savefile = io.open(profileFile, "w");
	if not savefile then
		CPlog("CelPad Alert: save failed, directory inaccessible!")
		this.SaveFailMSG = PopMessage:new({tCelPadHUD.popMsgs});
		this.SaveFailMSG:init(CelPadBox,"SaveFailMSG",x,y,"Alert",{
		templates2.popMsg.SaveFailMSG[1]..savename.." "..what..templates2.popMsg.SaveFailMSG[2],
		"",
		templates2.popMsg.SaveFailMSG[3],
		templates2.popMsg.SaveFailMSG[4]..profileDIR,
		"",
		templates2.popMsg.SaveFailMSG[5],
		templates2.popMsg.SaveFailMSG[6],
		txtfnt = templates2.popMsg.SaveFailMSG.txtfnt;
		},"a","ok");
		this.SaveFailMSG:makeBranch(myCelPadHUD); 
	else
		if what == "GUI" then
			tts.GUI[1] = deepcopy(tSettings.Windows);
			tts.GUI[2] = deepcopy(tSettings.WindowsAdv);
			tts.GUI[3] = deepcopy(tSettings.WindowsAdvMW);
			tts.GUI[4] = deepcopy(tSettings.WindowsAdvMN);
			tts.GUI[5] = deepcopy(tSettings.WindowsAdvCP);
			tts.GUI[6] = deepcopy(tSettings.WindowsAdvPM);
			tts.GUI[7] = deepcopy(tDeltaSettings);
		elseif string.sub(what,1,2) == "QR" then
			finder.metaQueryVal["zz1_scan_within"]["valuelist"][1] = deepcopy(templates.metaQuery.zz1_scan_within.valuelist[1])
			finder.metaQueryVal["zz1_scan_within"]["valuelist"][2] = deepcopy(templates.metaQuery.zz1_scan_within.valuelist[2])
			finder.metaQueryVal["zz1_scan_pure"]["valuelist"][1] = deepcopy(templates.metaQuery.zz1_scan_pure.valuelist[1])
			tts[what][1] = deepcopy(finder.queryVal);
			tts[what][2] = deepcopy(finder.metaQueryVal);
		elseif what == "SYS" then
			tts.SYS[1] = deepcopy(tSettings.SystemSet);
			tts.SYS[2] = deepcopy(templates.minMaxDefault);
			tts.SYS[3] = deepcopy(templates.metaUnits);
		elseif what == "profile" then
			tts.profile[1] = deepcopy(tProfiles);
			tts.profile[2] = deepcopy(lastwindow);
			this.savingprf = true;
			local iniparser = CPTabPars:new({tCelPad.Parsers})
			iniparser:init("iniparser",tts[what],LoadLoop,
			function(o)
				savefile:write("tts."..tostring(what)..tostring(o.tabindexstr).."="..tostring(o.tabvalstr)..";\n");
			end,
			function(o)
				savefile:close();
				this.savingprf = nil;
				tts.profile = nil;
				tts.profile = {};
			end,
			function(o)
			end
			);
			iniparser:makeBranch(this); 
		elseif what ~= "" then
			if finder then
				if finder[what].mtdlg then
					tts[what][1] = deepcopy(finder[what].mtdlg.menutab);
					tts[what][2] = deepcopy(finder[what].mtdlg.metatab);
				else
					tts[what][1] = deepcopy(finder[what].srctab.data);
					tts[what][2] = deepcopy(finder[what].srctab.meta);
				end;
			end;
		end;
		if what ~= "profile" then
			if string.sub(what,1,2) == "QR" and #finder.openQueries == 0 then
				return;
			else
				local msgtgt
				if finder then
					msgtgt = finder.sysLog
				end
				CPlog("saving "..tostring(tMetaSettings["Saves"..what].hiname).." '"..tostring(savename).."'",0,msgtgt or tCelPad.sysLog);
				this.SavingMSG[what] = PopMessage:new({tCelPadHUD.popMsgs});
				this.SavingMSG[what]:init(CelPadBox,"SavingMSG",x,y,"Warning",{			
				templates2.popMsg.SavingMSG[1]..tostring(tMetaSettings["Saves"..what].hiname).." '"..tostring(savename).."'.",
				templates2.popMsg.SavingMSG[2],
				templates2.popMsg.SavingMSG[3],
				txtfnt = templates2.popMsg.SavingMSG.txtfnt;
				},"w","ok");				
				this.SavingMSG[what]:makeBranch(myCelPadHUD); 
				this.SavingMSG[what].okbutton.Action = (function()
					return
					function()
					end
				end) ();		
				this.saving = true;
				local tabparser = CPTabPars:new({tCelPad.Parsers})
				tabparser:init("tabparser",tts[what],LoadLoop,
				function(o)
					local writestr = "tts."..tostring(what)..tostring(o.tabindexstr).."="..tostring(o.tabvalstr)..";\n"
					writestr = string.gsub(writestr,"1.#INF","math.huge");
					savefile:write(writestr);
				end,
				function(o)
					savefile:close();
					if this.SavingMSG[what] then
						this.SavingMSG[what]:quitpopup(CelPadBox)
						this.SavingMSG[what] = nil
					end;
					this.saving = nil;
					tts[what] = nil;
					tts[what] = {};
					this.SavedMSG[what] = PopMessage:new({tCelPadHUD.popMsgs});
					this.SavedMSG[what]:init(CelPadBox,"SavedMSG-"..tostring(what),x,y,"Info",{
					tostring(tMetaSettings["Saves"..what].hiname).." '"..tostring(savename).."' saved.",
					txtfnt = {"normalfont"};
					},"i","ok",2)
					this.SavedMSG[what]:makeBranch(myCelPadHUD); 
				end,
				function(o)
				end
				);
				tabparser:makeBranch(this); 
			end;
		end;
	end;
end;
loadCP = function(this,what,savename,finder)
	tts[what] = nil;
	tts[what] = {};
	local profileFile = profileDIR..savename.."_"..what..".cpsav";
	local savefile, msg = io.open(profileFile, "r");
	local t_ins = table.insert
	if savefile == nil then
		CPlog("CelPad Warning: file "..savename.."_"..what.." missing, creating from current values...")
		if what == "profile" then
			this:saveCP("profile","ini");
			this:firstRun()
			return "nok";
		elseif string.sub(what,1,2) == "QR" then
			this:saveCP(what,savename,finder);
			return "nok";
		elseif what ~= "" then
			this:saveCP(what,savename,finder);
			return "nok";
		end;
	end;
	if what == "GUI" then
		t_ins(tts.GUI,tSettings.Windows);
		t_ins(tts.GUI,tSettings.WindowsAdv);
		t_ins(tts.GUI,tSettings.WindowsAdvMW);
		t_ins(tts.GUI,tSettings.WindowsAdvMN);
		t_ins(tts.GUI,tSettings.WindowsAdvCP);
		t_ins(tts.GUI,tSettings.WindowsAdvPM);
		t_ins(tts.GUI,tDeltaSettings);
	elseif string.sub(what,1,2) == "QR" then
		t_ins(tts[what],finder.queryVal);
		t_ins(tts[what],finder.metaQueryVal);
		for t=1,#finder.openQueries do
		for i,v in ipairs (finder.openQueries[t].menupane.popupMenus) do
				v.closebutton:Action()
		end
		end;
	elseif what == "SYS" then
		t_ins(tts.SYS,tSettings.SystemSet);
		t_ins(tts.SYS,templates.minMaxDefault);
		t_ins(tts.SYS,templates.metaUnits);
	elseif what == "profile" then
		t_ins(tts.profile,tProfiles);
		t_ins(tts.profile,lastwindow);
		local iniparser = CPLoopPars:new({tCelPad.Parsers})
		iniparser:init("iniparser",LoadLoop,
		function(o)
			o.fline = savefile:read("*line")
			if o.fline then
				o.statloadlog2 = o.statloadlog2 or #tCelPadHUD.sysLog+1;
				loadstring(o.fline)();
			end;
		end,
		function(o)
			if o.fline then return false else
				return true
			end;
		end,
		function(o)
			savefile:close();
			this.loading = nil;
		end
		);
		iniparser:makeBranch(this); 
	elseif what ~= "" then
		if finder then
			if finder[what].mtdlg then
				t_ins(tts[what],finder[what].mtdlg.menutab);
				t_ins(tts[what],finder[what].mtdlg.metatab);
			else
				t_ins(tts[what],finder[what].srctab.data);
				t_ins(tts[what],finder[what].srctab.meta);
			end;
		end;
	end;
	if what ~= "profile" then
		local msgtgt
		if finder then
			msgtgt = finder.sysLog
		end
		CPlog("loading "..tostring(tMetaSettings["Saves"..what].hiname).." '"..tostring(savename).."'",0,msgtgt or tCelPad.sysLog);
		this.loading = true;
		local tabparser = CPLoopPars:new({tCelPad.Parsers})
		tabparser:init("tabparser",LoadLoop,
		function(o)
			o.fline = savefile:read("*line")
			if o.fline then
				loadstring(o.fline)();
			end;
		end,
		function(o)
			if o.fline then return false else
				return true
			end;
		end,
		function(o)
			savefile:close();
			if finder and finder[what] and finder[what].mtdlg then
				finder[what].mtdlg:moveItem(-1,"load")
			end;
			IconsRepos = true
			this.loading = nil;
			gVarBinds.updateGlobals(true);
		end
		);
		tabparser:makeBranch(this); 
	end;
	return "ok";
end;
deleteCP = function(this,what,savename)
	local profileFile
	if what == "QR" then
		profileFile = profileDIR..savename.."_"..what.."stars"..".cpsav";
		os.remove(profileFile);
		profileFile = profileDIR..savename.."_"..what.."satellites"..".cpsav";
		os.remove(profileFile);
		profileFile = profileDIR..savename.."_"..what.."dsos"..".cpsav";
		os.remove(profileFile);
	else
		profileFile = profileDIR..savename.."_"..what..".cpsav";
		os.remove(profileFile);
	end;
end;
}
CPtimer = CClass {
classname = "CPtimer";
superclass = CPObject;
init = function(this,objname,TimerID,delay,TimerType,seq,what)
	this.objname=objname;
	this.delay = delay;
	this.start = os.clock();
	this.what = what;
	this.TimerType = TimerType;
	this.seq = seq;
	this.TimerID = TimerID;
	this.status = "undefined";
	this.chainSTARTdone = false;
	this.chain_last = 1;
	this.reset = false;
	if this.TimerType == "chainEND" or this.TimerType == "chainSTART" then
		this.status = "queued";
		this.chain = {};
	end;
	if this.TimerType == "standalone" or this.seq == 1 then
		this.status = "active";
	end;
	this.timetoend = (this.start+this.delay)-os.clock();
end;
update = function(this)
	if this.reset then
		this.start = os.clock();
		this.reset = false;
	end;
	if this.chain_last then
		if this.status == "unfrozen" and  this.chain_last == this.seq then
			this.status = "active";
			this.delay = this.delay_next;
			this.start = os.clock();
		end;
	end;
	if this.status ~= "frozen" then
		if this.status == "active" or this.status == "execute" or this.status == "kill" then
			this.timetoend = (this.start+this.delay)-os.clock();
			this.delay_next = this.timetoend;
			if this.status == "execute" or this.status == "kill" then
				this.timetoend = 0;
			end;
			if this.TimerType == "chainSTART" then
				if this.chainSTARTdone == false then
					this:what()
					this.chainSTARTdone = true;
				end;
				if this.timetoend <= 0 and this.timetoend >= -99 then
					this = this:timerend()
				end;
			else
				if this.timetoend <= 0 and this.timetoend >= -99 then
					if this.status ~= "kill" then
						this:what()
						this = this:timerend()
					else
						this = this:timerend()
					end;
				end;
			end;
		end;
	end;
end;
timerend = function(this)
	local maxmin = maxmin
	local t_ins = table.insert
	if this.TimerType == "chainEND" or this.TimerType == "chainSTART" then
		this.chain = this.chain or {};
		for i,v in ipairs(tCelPad.Timers) do
			if v.TimerID == this.TimerID  and not (v.seq == this.seq) then
				t_ins(this.chain,v.seq);
			end;
		end;
		this.chain_max, this.chain_min = maxmin(this.chain);
		for i,v in ipairs(tCelPad.Timers) do
			if v.TimerID == this.TimerID and v.seq == this.chain_min then
				v.start = os.clock();
				v.chain_last = this.chain_min;
				v.delay_next = v.delay;
				if v.status == "queued" or v.status == "unfrozen" then
					v.status = "active";
				end;
			end;
		end;
	end;
	this:destruct();
end
};
CPTabPars = CClass {
classname = "CPTabPars";
superclass = CPObject;
init = function(this,objname,intable,scanloop,fnctodo,fnctofin,fncinloop,tabprefix,oritable)
	this.objname=objname;
	this.scanloop = scanloop
	this.maxinloop = scanloop or 0;
	this.intable = intable;
	this.oritable = oritable or intable;
	this.fnctodo = fnctodo;
	this.fnctofin = fnctofin;
	this.fncinloop = fncinloop
	this.branches = {};
	this.oldnxt = nil
	this.tabprefix = (tabprefix or "");
end;
update = function(this)
	local lcFuse = Fuse
	this.maxinloop = math.ceil(this.scanloop*lcFuse)
	this.ii = 1
	while this.ii <= this.maxinloop do
		if #this.branches == 0 then
			local k = next(this.intable,this.oldnxt)
			if k == nil or this.cancelrq then
				if this.fnctofin then this.fnctofin(this); end;
				this:quit();
				break;
			end;
			local wh = this.intable[k]
			if type(wh)=="string" then
				this.tabvalstr = "\""..wh.."\"";
			elseif type(wh)=="number" then
				this.tabvalstr = string.gsub(wh,",",".");
			else
				this.tabvalstr = wh;
			end;
			if tonumber(k) == nil then
				xk = "\""..k.."\"";
			else
				xk = k;
			end;
			if type(wh)=="table" then
				this.parser = CPTabPars:new({tCelPad.Parsers})
				this.parser:init("parserX-"..tostring(this)..":"..tostring(this.ii),wh,this.maxinloop,this.fnctodo,nil,nil,this.tabprefix.."-"..xk.."-",this.oritable)
				this.parser:makeBranch(this) 
			else
				this.tabindexstr = string.gsub(string.gsub(string.gsub(this.tabprefix,"%-%-","]["),"^%-","["),"%-$","]").."["..xk.."]"
				this.k = k
				this.wh = wh
				this.xk = xk
				this.fnctodo(this)
			end;
			this.oldnxt = k;
			this.ii = this.ii + 1
		else
			break;
		end;
	end;
	if this.fncinloop then
		this.fncinloop(this)
	end;
end;
quit = function(this)
	this.intable = nil;
	this.oritable = nil;
	this:destruct()
end;
};
CPLoopPars = CClass {
classname = "CPLoopPars";
superclass = CPObject;
init = function(this,objname,scanloop,fnctodo,fnctoxit,fnctofin,fncinloop)
	this.objname=objname;
	this.scanloop = scanloop;
	this.maxinloop = scanloop;
	this.fnctodo = fnctodo;
	this.fnctoxit = fnctoxit;
	this.fnctofin = fnctofin;
	this.fncinloop = fncinloop;
	this.tabprefix = (tabprefix or "");
end;
update = function(this)
	local lcFuse = Fuse
	if this.objname~="nilparser" then
		this.maxinloop = math.ceil(this.scanloop*lcFuse)
	end;
	this.ii = this.maxinloop
	for ii=1,this.maxinloop do
		this.fnctodo(this)
		this.ii = this.ii - 1
		if this.fnctoxit(this) or this.cancelrq then
			break; 
		end;
	end;
	if this.fncinloop then
		this.fncinloop(this)
	end;
	if this.fnctoxit(this) or this.cancelrq then
		this.fnctofin(this)
		this:quit();
	end;
end;
quit = function(this)
	this:destruct()
end;
};

celestia:log("CelPad: chasis loaded")