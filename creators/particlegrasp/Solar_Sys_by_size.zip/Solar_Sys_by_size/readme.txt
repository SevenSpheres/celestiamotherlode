--------------------------------------------------------------------------------
Solar System by Size for Celestia
Add-on by CRAIG STRAPPLE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------

Extract this archive to the extras folder of your Celestia distribution. This will automatically create a subfolder which contains the add-on data.

Start Celestia --> press "Enter" --> type in "Sol II" --> press "g" 

--------------------------------------------------------------------------------
DESCRIPTION
--------------------------------------------------------------------------------

This is a pictorial display of the 50 largest objects in the Solar System in alignment around a Solar Twin (Sol II).

The primary source of data was an article in Wikipedia. http://en.wikipedia.org/wiki/List_of_Solar_System_objects_by_size

There an inconsistency between Celestia and the article for the radii of the bodies.  I favored Celestia’s data where the discrepancy was unimportant to the overall effect, but many of the minor bodies radii are taken from straight from Wikipedia 

Files:
Solar_System_by_size.stc - adds the Star to Celestia
Solar_System_by_size.ssc - adds planets and moons to Sol II

------------------------------------------------------------------------------------
CREDITS
-------------------------------------------------------------------------------------
Bradley Kassian - For some of the data from his add-ons for the Trans-Neptunian objects 2002 TC302 and 2007_OR10.
