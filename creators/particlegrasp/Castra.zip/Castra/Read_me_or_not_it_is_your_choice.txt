
--------------------------------------------------------------------------------
DISCLAIMER
--------------------------------------------------------------------------------
This add-on is purely fiction. It was inspired by two publications:

Astronomy & Astrophysics manuscript no. fogg/nelson/aph "ON THE FORMATION OF TERRESTRIAL PLANETS IN HOT-JUPITER SYSTEMS", Submitted on 11 Oct 2006, by Martyn J. Fogg, Richard P. Nelson
http://arxiv.org/abs/astro-ph/0610314v1

The Astrophysical Journal, 660:823Y844, dated 2007 May 1, by Avi M. Mandell, Sean N. Raymond, and Steinn Sigurdsson, titled "FORMATION OF EARTH-LIKE PLANETS DURING AND AFTER GIANT PLANET MIGRATION".
http://iopscience.iop.org/0004-637X/660/1/823/fulltext

While it strives to be scientifically realistic, it is more of a mental exercise rather than a portrayal of a viable system.

Also, I offer no excuse for the double-ringed planet.  I realize, of course, doubled-ringed planets are pushing the boundaries of scientifically possibility.  They just look so darn pretty!  You can remove the fx.ssc file if you don't care for it.

--------------------------------------------------------------------------------
CREDITS
--------------------------------------------------------------------------------

All textures, except where noted, are original creations, insomuch as they are not unaltered copies.  Some textures were adapted from images found on the Internet, especially the NASA websites.  Other textures were based on existing add-ons, but were graphically manipulated.

Quartus is based on "150Ma Late Jurassic.png" from Maxim with copious cloning from Don Edwards' "Realistic Earth" and subsequent image manipulation. 

Quartus' cloud texture is 2k copy of a global cloud texture made from NCEP and MODIS. http://val.gsfc.nasa.gov/projects/modis_ncep_global_clouds/index.html

Primus is based on the full-globe map of the "Hot Jupiter" planet HD 189733b @ http://apod.nasa.gov/apod/ap070512.html and artistic interpretation based on Upsilon Andromedae B from Extrasolar Planet Guide @ http://www.extrasolar.net/startour.asp?StarCatId=&StarId=3

Sextus is combination of Jupiter's Northern Polar Regions and Saturn pictures obtained from NASA.
	http://www.nasa.gov/mission_pages/cassini/multimedia/pia07783.html
	http://www.nasa.gov/mission_pages/cassini/multimedia/pia07784.html
	http://photojournal.jpl.nasa.gov/jpeg/PIA07782.jpg

Tertius is the Australian Outback; the atmosphere is based on "The Primitive Earth and Moon" educational add-on from Frank Gregorio.

--------------------------------------------------------------------------------
BACKGROUND
--------------------------------------------------------------------------------
The Location
Back in the mid-to-late part of the 20th century, someone 'bought' me a star.  The gift, which sat for decades in its original shipping container, included the Right Ascension and declination.  Since my discovery of Celestia, I wanted to see if my star was anything special.  Unsurprisingly, neither Celestia nor SIMBAD, had anything to say about the matter.  So I took the RA and declination, which put the new star in the constellation Hercules, and added a distance of 42 (as a homage to Douglas Adams) LY.

The Planets
Originally I had intended to create a speculative add-on for the gas giant around HD 278914.  After putting the numbers in the SSC, I thought I would give a hypothetical observer a place to stand and thus, the second planet was born.  Planets three through seven were happy accidents which I wanted to leave in.

Then trouble came in the form of an episode of �The Universe� on the History Channel (TM).  According to the show, a migrating gas giant would expel any inner planets, so I let the add-on sit for a while.  Relief came when I read an article in Wikipedia about �Hot Jupiters�.  To my surprise, I stumbled upon the Mandel, et al, and Fogg. et al, publications.

The Names
I "googled" the name CASTRA and found it was Latin for "Tents".  So the planet names were Primus, Secundus, etc.  Keeping with the theme, the moons were named similarly in other languages, Protos, Deuteros, etc.  The exceptions to the naming conventions I established are the moons of Septimus.  Allowing that Sir John Herschel used his favorite author and book, I used mine.  If you haven't gathered already, the names are from the characters in "The Hitchhiker's Guide to the Galaxy" by Douglas Adams.

As to OME3 Her and 151 Her: Omega 3 is a fatty acid found in fish oil.  151 is a type of Rum from Bacardi.  I made sure there were no existing stars with those designations. 

--------------------------------------------------------------------------------
Epilogue
--------------------------------------------------------------------------------
Please let me know if you like my add-on.  I would also appreciate knowing if you do not like my add-on. I can handle criticism as long as it is well-intentioned.  That being said, the criticism doesn't have to be nice, just well intentioned.

Since most, if not all, of my work is derivative, please give me an opportunity to set things right if you feel I have somehow compromised your hard work. 

I would prefer that unaltered copies of my textures NOT be included in any existing science fiction universe e.g., �Star Trek�, �Star Wars�, �Babylon 5�, etc. I realize I lack any recourse if you chose to do so.  I would encourage you to create your own universe and populate it with your imagination, rather than with the constructs of others. 

My apologizes for any inadvertent misuse of case, gender or spelling of the proper names in any of the languages used in this add-on.  I am not fluent in any language other than English and have been told upon occasion I should consider not speaking at all.

Thank you for taking time to read this file.  I am in awe and gratitude to the incredible people who help make Celestia as amazing as it is.
