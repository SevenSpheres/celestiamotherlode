
--------------------------------------------------------------------------------
IMPERIUM ATLANTIS FOR CELESTIA
Add-on by CRAIG STRAPPLE
--------------------------------------------------------------------------------
'... And as the elders of our time choose to remain blind...' - Donovan Philips Leitch
--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------
Extract this archive to the extras folder of your Celestia distribution. This
will automatically create a subfolder which contains the add-on data.

Start Celestia and right-click Earth-->Select Alternate Surfaces--> Select Imperium Atlantis.

--------------------------------------------------------------------------------
DESCRIPTION
--------------------------------------------------------------------------------
This is a fictitious depiction of the fabled Lost Continent at the height of her glory: approximately 7 millennia “… before the Ocean drank Atlantis…”  

Recipe: 

Take “Earth18kBCE-4k.png” from “Earth 18000BCE” by Don Edwards.

Capture the North Atlantic ridge from “Earth: Topographical Surface” by Map Javier Villalobos.  Add color to taste.

Add a little color to North Africa in GIMP for favor.

Add ice from “Earth--last ice age (720x360)” from Planetary maps page by Wm. Robert Johnston @ http://www.johnstonsarchive.net/spaceart/cylmaps.html.

Shake well, serve and enjoy.


--------------------------------------------------------------------------------
LICENSE
--------------------------------------------------------------------------------
This work is licensed under the Creative Commons Attribution-Noncommercial-Share
Alike 3.0 Unported License. To view a copy of this license, either (a) visit
http://creativecommons.org/licenses/by-nc-sa/3.0/ or, (b) send a letter to
Creative Commons, 171 2nd Street, Suite 300, San Francisco, California, 94105,
USA.
