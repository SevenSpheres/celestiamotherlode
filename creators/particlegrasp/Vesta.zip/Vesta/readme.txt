--------------------------------------------------------------------------------
VESTA FOR CELESTIA
Add-on by ParticleGrasp NASA/JPL-Caltech/ULCA/MPS/DLR/IDA
--------------------------------------------------------------------------------

This is a 2K map of the asteroid Vesta based on images from the Dawn spacecraft.  
I found the picture below on http://dawn.jpl.nasa.gov/

--------------------------------------------------------------------------------
Files

vesta.ssc: adds two alternate images to the asteroid.

Vesta from Dawn: 
    http://dawn.jpl.nasa.gov/multimedia/images/PIA14703_750_equi+CL.jpg
    I removed text NASA/JPL-Caltech/ULCA/MPS/DLR/IDA

Vesta Augmented:
 merges, ineptly, the South Polar region, http://dawn.jpl.nasa.gov/multimedia/images/slide2_image.jpg with the incomplete data from above
   

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------
For PC users: 
    Extract this archive to the extras folder of your Celestia distribution. 
    This will automatically create a subfolder which contains the add-on data.

For Linux users
    You already know what to do.

Start Celestia --> press "Enter" --> type in "vesta" --> press enter -->press "g".  Once at Vesta, 
    right click and select Alternate surfaces, then select either Vesta Augmented or Vesta from Dawn.
