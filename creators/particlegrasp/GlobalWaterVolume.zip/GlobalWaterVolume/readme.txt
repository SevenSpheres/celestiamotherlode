--------------------------------------------------------------------------------
Global Water Volume FOR CELESTIA
Add-on by ParticleGrasp 
--------------------------------------------------------------------------------
Various blue spheres representing relative amounts of Earth's water in comparison
to the size of the Earth.

This Add is based upon the USGS Water Science School webpage called 
"How much water is on Earth?"
http://ga.water.usgs.gov/edu/2010/gallery/global-water-volume.html.
 
The sphere representing all of Earth's water �... includes all the 
water in the oceans, ice caps, lakes, and rivers, as well as groundwater,
atmospheric water, and even the water in you, your dog, and your tomato
plant.�

The sphere representing Liquid fresh water includes �� groundwater, lakes,
 swamp water, and rivers�
 
The sphere representing Water in lakes and rivers �� represents [the] fresh
water in all the lakes and rivers on the planet, and most of the water people
and life of earth need every day comes from these surface-water sources.�

Right click any sphere and select "Info" to be taken the USGS website. 

NOTE:
***  Celestia 1.6.0 or greater ***
FixedPosition Planetographic parameters were used to place the water spheres on surface.
--------------------------------------------------------------------------------
FILES
--------------------------------------------------------------------------------

GWVEarth.png is based on RealisticEarth-v4-4kDDS.dds by Don Edwards(I think...)

GWVEarthNormal.png is based on NASA's gebco_bathy.21601x10801.bin and processed
using tools found in nNmTools-2.0pre2

GWVH2O.png is based on a section of ocean from RealisticEarth-v4-4kDDS.dds overlaid 
with Electric Blue Marble Wallpaper found at 
http://www.burramundi.com/wp-content/uploads/2010/08/Electric-Blue-Marble_1920x1200.jpg

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------
For PC users: 
    Extract this archive to the extras folder of your Celestia distribution. 
    This will automatically create a subfolder which contains the add-on data.

For Linux users
    You already know what to do.
--------------------------------------------------------------------------------
ACKNOWLEDGEMENTS
--------------------------------------------------------------------------------

John Van Vliet was a tremendous help assisting me in understanding how to make a
NormalMap using t00fri's nmtools.  

Dr. Fridger Schrempp for his creation of the nmtool kit.  
