--------------------------------------------------------------------------------
Lord of the Rings FOR CELESTIA
Add-on by ParticleGrasp 
--------------------------------------------------------------------------------
My interpretation of the "Lord of the Rings" announcement on 26 Jan 2015 and the
massive ring system surrounding the companion of 1SWASP J140747.93-394542.6,
henceforth referred to as J1407b. The estimate of the ring system ranges from 
90-120 million kilometers.

The radius of J1407b is an average radii of six known exoplanets with a mass ~20 
times the mass of Jupiter: HN Peg b, CoRoT-3 b, 2MASS J21402931+1625183 A b, 
Kepler-39 b, GQ Lup b, and CT Cha b. The figures for the radii were taken from 
NASA's Exoplanet archive at http://exoplanetarchive.ipac.caltech.edu/index.html.

--------------------------------------------------------------------------------
FILES
--------------------------------------------------------------------------------
J1407.png texture is a modification of kstar.png in darker star textures from
'gradius_fanatic' and John Van Vliet's 4k.e31hr_B3_cr2023.png.

J1407bEmissive.png texture is a modification of the Alternative Brown Dwarf 
Texture from 'Mattrave'.

J1407bRings.png is a modification of Saturn-rings from Celestia's main 
Texture folder.

All Exomoon files are original files and the Normal map was processed using 
tools found in NmTools-2.0pre2.

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------
For PC users: 
    Extract this archive to the extras folder of your Celestia distribution. 
    This will automatically create a subfolder which contains the add-on data.

For Linux users
    You already know what to do.

Start Celestia --> press "Enter" --> type in "J1407" --> press enter -->press "g".  The system
can be explored using the standard navigation options or Lua Edu Tools Solar System Browser option.	
	
--------------------------------------------------------------------------------
REFERENCES
--------------------------------------------------------------------------------

http://www.astronomy.com/news/2012/01/scientists-discover-a-saturn-like-ring-system-eclipsing-a-sun-like-star
https://www.google.com/search?q=1SWASP+J140747.93-394542.6&oq=1SWASP+J140747.93-394542.6&aqs=chrome..69i57j69i61&sourceid=chrome&es_sm=122&ie=UTF-8#q=1SWASP+J140747.93-394542.6+SIMBAD
http://en.wikipedia.org/wiki/1SWASP_J140747.93-394542.6#J1407b
http://exoplanet.eu/catalog/1swasp_j1407_b/
https://www.google.com/search?q=J1407b&oq=J1407b&aqs=chrome..69i57&sourceid=chrome&es_sm=122&ie=UTF-8
http://www.dailygalaxy.com/my_weblog/2015/02/-lord-of-the-rings-new-analysis-shows-alien-planets-gigantic-ring-system-even-more-enormous.html#more