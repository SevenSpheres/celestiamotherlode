This Add-on is a rework of Neptune. It includes:
- 2k neptune suface texture
- 2k neptune cloud texture
- new ring texture with all neptunian rings
- specular-, bump- and cloudshadow-effects (specular effect as alternate surface)
- more realistic atmosphere using mie- and reighleigh-scattering
This is the 3rd version of my neptune-rings-addon. 
The idea was to give a better view of the rings, meanwhile I also worked on neptune itself. 
Since my 2nd version didn't appear on the Motherlode, I had time to modify the atmosphere and created a cloud-texture. Now that it's all around neptune, I renamed the addon to "Neptune Portrait".

Install: Extract the folder in the zip-file into your Celestia/extras directory.

Sources:
Texture: created by Bj�rn J�nsson; http://www.mmedia.is/~bjj/data/neptune/
Clouds: created using different voyager-images, some processed by Bj�rn J�nsson
Bumpmap: artificial, alternated surface texture.
Specular map: artificial, but processed to fit to Voyager images. 
	To view, use the alternate surface "Neptune Specular"
Rings: semi-realistic. The transparency roughly taken from real data, but exagerated.
	(see: http://en.wikipedia.org/wiki/Rings_of_Neptune ) 
	The Adams-Ring is supposed to be red. The Gaps in the Lassel-Ring are artificial. 
	I took the brightness from Voyager-images, the stars influenced the brightness. 
	I didn�t remove them to have some structure in the rings.

SSC-Files:
neptune-portrait.ssc: Changes Neptune
neptune_ring_locs.ssc: Adds the names of the missing rings to Celestia.

known bugs:
This addon uses many adwanced rendering methods Celestia is capable of. Some of them may conflict with each other:
- athmospheric light scattering appears strange with rings behind the horizon (barely visible in this case)
- cloud shadows seam to conflict with ring shadows (anyway, faint ring shadows are visible with cloudshadow on)
- sometimes the cloud shadow rendering causes neptune to be very dark. 
	It seams to depend on the harware, as it varies on different computers.
	The bug vanishes when an alternate surface is selected or cloud shadows are disabled.
	Alternatively you can turn just neptune's cloud shadows of by modifying the neptune-portrait.ssc:
	Replace the command	CloudShadowDepth 0.25	with	CloudShadowDepth 0

Brought to you by FarGetaNik