This addon contains the famous near-earth-asteroid Apophis.
After discovery, there was a small chance it would hit Earth in 2029. 
After further observations it was clear it will miss Earth by 31000 km. 
A small chance remained it would hit Earth in 2036.
Recently observational data got precise enough to rule out even this impact.
As this addon demonstrates, Apophis will miss Earth by several million kilometers.

The addon contains orbital data from 2004-2037. 
The asteroid is still visable before and afterwards by ssc elements.
The position of the asteroid should be very accurate between 2002-2044.
In these years it approaches planets quite close.
But even outside this range the orbit should roughly match the reality.

Shape and rotation derivied from recent observations.
Note: The mesh used here is roughsphere.cms from Celestia's default streched into an ellipsoid.

Install: Simply extract the zip-file into your Celestia/extras directory.

Sources: Orbital data: NASA's Horizons System
Physical data: http://sajri.astronomy.cz/pravecetal2014.pdf

Brought to you by FarGetaNik