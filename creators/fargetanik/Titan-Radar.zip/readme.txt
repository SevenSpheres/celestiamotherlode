This addon is an optical rework of Titan, featuring high-resolution radar imagery and a new atmosphere definition.

Features:
8k surface texture, based on infrared and radar imagery.
Low-contrast cloud texture, closer to Titan's actual appearance.
New atmosphere definition, changing a few parameters for a more realistic look.
Note that the textures are greyscale, colored in by an ssc command.

Sources:
Surface texture:
combination of infrared map:
http://photojournal.jpl.nasa.gov/catalog/PIA19658
and radar coverage:
https://astrogeology.usgs.gov/search/map/Titan/Cassini/Global-Mosaic/Titan_SAR_HiSAR_MosaicThru_T104_Jan2015_clon180_128ppd
Cloud texture:
combination of Celestia default texture and:
http://maps.jpl.nasa.gov/saturn.html

Install: Simply extract the zip-file into your Celestia/extras directory.

Brought to you by FarGetaNik