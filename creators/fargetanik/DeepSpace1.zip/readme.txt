This Addon contains the spacecraft Deep Space 1.
It launched in 1998 to the asteroid Braille where it flew by very close.
It's 80 km in this addon, because I couldn't aquire better orbital data.
The imagery of this asteroid is very poor due to onboard problems, hence the blurry mesh.
Next target was Borrelly, passed sucessfully in 2001. 
A texture of Borrelly can be found here: http://www.unmannedspaceflight.com/index.php?showtopic=6373&hl=borrelly
Note that Celestia's mesh for Borrelly doesn't resemble the comet, which is why the texture won't match and hence is not included.
Soon after that the spacecraft was switched off, which is when this addon stops. 
So ensure to set a time in this frame to view the spacecraft.

Install: Just extract the zip into your Celestia/extras directory.

Sources:
Orbital Data: From NASA's HORIZONS system
Mesh of Deep Space 1: http://nasa3d.arc.nasa.gov/models
Mesh of Braille: � Jack Higgins, see 
	http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=20
	http://homepage.eircom.net/~jackcelestia/minormoon_ast.htm

Brought to you by FarGetaNik