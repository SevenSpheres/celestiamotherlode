This addon updates the Pluto-System to the newest data sent by New Horizons until July 24, 2015.
The majority of the data hasn't been downlinked yet, so this is just a "first look" addon.

Features:
- 8k Pluto texture, 4k Charon texture
- sampled orbit for the pluto system running from 1900-2199 (ssc-orbit outside this timeframe)
  high sampling rate during New Horizons encounter
- updated physical and orbital parameters for Pluto-System
- moons Kerberos and Styx

Installation: Unzip into your Celestia/extras directory

Sources:
Texture: 	NASA/JPL/New Horizons, Created by Snowfall-The-Cat (not me): http://snowfall-the-cat.deviantart.com/
Orbital data: 	NASA's Horizons System, http://ssd.jpl.nasa.gov/horizons.cgi

Brought to you by FarGetaNik