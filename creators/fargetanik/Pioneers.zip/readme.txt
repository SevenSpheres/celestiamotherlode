This addon contains the Pioneer 10 and Pioneer 11 spacecraft. 

Features:
- xyzv trajectories of the Pioneer probes reffered to solar system barycenter from launch, flybys until contact lost
- cmod mesh featuring specular and normal effects
- probes are rotating while pointing towards Earth
- ssc defined hyperbolic orbits showing them leaving the solar system (far future is still inaccurate though)

Installation: Simply extract the Zip into your Celestia/extras directory.

Sources:
Orbital data: NASA's HORIZONS system: http://ssd.jpl.nasa.gov/horizons.cgi
textured Mesh: NASA's 3D resources: http://nasa3d.arc.nasa.gov/models

Brought to you by FarGetaNik