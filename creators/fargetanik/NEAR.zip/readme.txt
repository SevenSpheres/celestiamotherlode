This addon contains the NEAR-Shoemaker spacecraft and its asteroids.

Features:
NEAR trajectory from cruise to Eros until landing on the asteroid. The first few months are represented with an ssc-defined orbit, since no orbital data is avaliable from Horizons. The orbit around Eros is broken up into 3 segments, so the orbits won't cluster your screen when rendered. NEAR is rendered lying on the surface of Eros after landing.
Textured cmod mesh for NEAR including specular and normal effects.
High-resolution shape model and texture for Eros. Note that the texture does not perfectly map on the asteroid because of its highly irregular shape.
Timeline for Eros defining a sampled orbit during NEAR mission and ssc-defined orbit outside this timeframe.
Asteroid Mathilde is also included, mesh and texture are from the "Asteroid Model Replacements" addon by Jestr on the Motherlode.

Installation: Simply extract the Zip into your Celestia/extras directory.

Sources:
Orbital data: NASA's HORIZONS system: http://ssd.jpl.nasa.gov/horizons.cgi
NEAR mesh: NASA's 3D resources: http://nasa3d.arc.nasa.gov/models
Eros texture and mesh: http://space.frieger.com/asteroids/
Mathilde texture and mesh: http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=18

Brought to you by FarGetaNik