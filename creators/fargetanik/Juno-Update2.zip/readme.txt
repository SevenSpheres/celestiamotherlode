This addon contains the NASA New Frontiers spacecraft Juno.

The timeline spans over the complete mission from launch in 2011 to jovian atmosphere entry in 2021.
Juno spacecraft is shown spinning and solar arrays always facing the sun. The model also features normal and specular effects.
Trajectory updated a second time (March 2017) after NASA's change in plans for the orbital phase featuring longer orbits and overall lifetime. Juno is sheduled to remain in its current 53 day orbit for the rest of the mission, carefully avoiding Jupiter's shadow and finally plunging into its atmosphere by minuscule orbit maneuvers. Trajectory update provided by Austin.

Summary of Main Events:
2011 Aug 05 17:19:00 UTC - Launch
2013 Oct 09 19:21:23 UTC - Earth flyby (506 km)
2016 Jul 05 02:30:00 UTC - Juno's main engine activated to enter into an orbit around Jupiter (Jupiter Orbit Insertion)
2021 Jul 30 04:31:22 UTC - End of mission.  Juno descends into Jupiter's cloud tops

Note:
Juno may not actually operate until July 2021. NASA is still determining the best course of action after the stuck helium check valves forced a change to Juno's orbits around Jupiter.
https://astronomynow.com/2017/02/21/nasa-juno-spacecraft-to-remain-in-current-orbit-around-jupiter/


Installation:	Simply extract the zip-file into your Celestia/extras directory.

Sources:
Orbital data:	NASA Horizons System, http://ssd.jpl.nasa.gov/horizons.cgi
Textured model:	http://nasa3d.arc.nasa.gov/models


Brought to you by FarGetaNik and Austin