This addon contains Rosetta's comet, 67P/Churyumov�Gerasimenko.

Features:

High resolution cmod shape model:
Published on November 30, 2015: http://blogs.esa.int/rosetta/2015/11/30/new-comet-shape-model/
The model is licenced under CC BY-SA IGO 3.0
For the first time, this model includes prior unimaged regions in the south. I used the obj-model and converted it to cmod using Anim8or and the CMOD export script by S.Ball. Then I converted it to a cmod binary using cmodview in order to reduce the file size.

Note: The rotational data provided by ESA does not fit in Celestia using the respective body frame. I offset the AscendingNode by 180�, this roughly reproduces the polar nights according to Rosetta data, as well as an obliquity of more than 50�.

Sampled Orbit:
Running from 2014-2020, step size is 10 days. The comet is still rendered outside this timeframe using an ssc-defined orbit. Aquired by NASA's Horizons System, http://ssd.jpl.nasa.gov/horizons.cgi
The time spans from Rosetta's approach to the comet over the complete orbital phase, to 67P's close approach to Jupiter in 2019. For some reason, it is poorly known that 67P will get near Jupiter in 2019. It's orbit will be perturbated moderately, as this addon demonstrates. Just imagine Rosetta escaping from it's comet and visiting Jupiter... Unfortunately the solar arrays won't produce enough energy this far from the sun. Therefore, ESA decided to land on the comet in 2016 instead.

Note: Cylindrical projection doesn't work well on a duck-shaped world like 67P, hence no texture is included. The default asteroid texture of Celestia obscures the faint details on the model. I decided to use Celestia's Epimetheus texture instead, it gives subtile brightness variations on the surface. So make sure you have the default texture of Epimetheus still in your Celestia installation. If not, the comet won't look much different, anyway.

Install: Simply extract the zip-file into your Celestia/extras directory.

Brought to you by FarGetaNik