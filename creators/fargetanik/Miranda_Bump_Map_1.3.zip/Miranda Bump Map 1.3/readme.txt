This Add-on includes a semi-realistic (drawn) bump map of Miranda.

Features:
-2k bump map of Miranda
-alternative Surface including an artificial north hemisphere
-color information for Miranda
-Miranda as an ellipsoid with more accurate radius

Install: Simply extract the folder "Miranda Bump Map" into your Celestia\extras directory.

Sources: 
Textue Map (modified) by Robert Johnston http://www.johnstonsarchive.net/spaceart/cylmaps.html;
originally by NASA Voyager 2 data http://maps.jpl.nasa.gov/uranus.html

Bump Map painted with this texture as a base; heights matched with help of Dr. Schenk's 3D House of Satellites data http://stereomoons.blogspot.de/2009/09/mirandas-warning.html
NASA/JPL and Paul Schenk/Lunar and Planetary Institute, Houston