This addon contains the NASA New Frontiers-spacecraft Juno en route to Jupiter.
The timeline spans over the complete mission from launch in 2011 to jovian athmosphere entry in 2017.

Installation:	Just extract the zip-file into your Celestia/extras directory.
		Note: Juno can be found in the solar system browser at Jupiter. 
		This was necessary in order to align to solar panels always towards sun.

Sources:
Orbital data:	NASA Horizons System, http://ssd.jpl.nasa.gov/horizons.cgi
Model:		Published by NASA, http://nasa3d.arc.nasa.gov/models
		Editing was quite difficult, someone with advanced skills in modeling programs will do better.
		Anyway, it's good enough for display as the major textures are encluded, even tough without
		normal mapping.
		Modeling programs used: Blender and Anim8or. CMOD exported with script at:						http://www.lns.cornell.edu/~seb/celestia/modelling.html#4.1

Brought to you by FarGetaNik