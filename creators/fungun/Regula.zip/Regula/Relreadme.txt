Title		: Miranda Class Light Cruiser
Filename	: fcl.zip
Version		: 2.0
Date		: 9/19/2001
Author		: Rick Knox a.k.a pneumonic81
Email		: pneumonic81@apocent.com
URL		: http://www.apocent.com, http://www.apocent.com/www/dominion

Credits	
-------------	
model design	: Paramount
textures	: rick knox
mesh		: rick knox
Build time	: 4 days

Thanks to	: The SFC community

mod specs
-----------
mod		: Yes 
break 		: yes
LODs		: yes
Illumination	: yes  


Description of the Modification
-------------------------------

an original model created in studio max and converted using MOD plugin

Technical Details
-----------------
tested in SFC 2.0 
NOT tested with Mplayer


Known Bugs
----------

-none

Steps to install
----------------

1. unzip directly into the  \Assets\Models\ directory. it will create a folder called fdn

3.  Finally, open the sfbspc.txt file located in the Starfleet Command\Assets\Specs\ folder with MS Excel. 
    a.  From here you have two choices you can:
	1.  Replace the model geometry of one of the existing ships
	with the following \Assets\Models\fdn\fdn.mod
    b.  Or :
	1. you can insert the FDN stats inbetween the existing row entries of the sfbspc.txt file.
	   <<CAUTION:  This may cause some problems with the function of SFC, espically during 
	     Multiplayer and Single player campaigns>>


Copyright and Distribution Permissions
--------------------------------------
THIS PATCH IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY INTERPLAY
 TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices: 

Star Trek, Star Fleet Command, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions. 

If you use this model in any Starleet Command project please include this file. 
If you make this file available at your website or anothers please include a link to
http://starfleet.thegamers.net

Please do not modify this file or the included texture with out seeking the authors opinion.
Nothing legal here, it is just polite.

