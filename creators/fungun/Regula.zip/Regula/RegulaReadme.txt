Please visit SCIFI 3D <www.theforce.net/scifi3d/> and SCIFI-MESHES.com
for rules governing use, display of credit, and copyright information.



SPACE LAB REGULA ONE

by Rick "Hobbes" Snider
digitalhooligan2@hotmail.com (now auxiliary)
sniderrick@rogers.com
ICQ # 8473593

MAX 4 format

Source:  Primarly www.starshipmodeler.com (wicked site guys!)
         http://www.ex-astris-scientia.org/
	   Star Trek II:  The Wrath of Khan (Special Edition DVD)

The infamous spacelab where the Genesis Device was researched and developed.  

Any media using this model must be credited to the author as per regulations on www.scifi-meshes.com

THIS MODEL CAN ONLY BE DISTRIBUTED EXCLUSIVELY BY WWW.SCIFI-MESHES.COM , WWW.M-CGI.COM , AND WWW.STARTREKAUSTRALIA.COM

There is to be no public kitbashing without my express permission (don't worry, you'll see add-on kits for Starbase 357 and the office complex soon!)




Enjoy!


Hobbes  =)