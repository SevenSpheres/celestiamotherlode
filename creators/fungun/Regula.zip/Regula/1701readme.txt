====Starforce Productions NCC-1701====

Credits:
Constitution by Moonraker
Conversion by moonraker
Hardpoints By starforce2
Does not overwrite any other constitution