
� INTRODUCTION
This is a pack of 15 fictious nebulae to be used as backgrounds with some fictious systems.  By default, the nebuale are located around the stars below :

Mira34PscEtaCarAl ReschaAurilis30PscMuphridEps Eri44PscHD 220978AltairHD 4100442Psc82 EriSig6


� HOW TO USE
just drop the Fictious_Nebulae directory into your "Extras" folder.  If you wish, you can edit the ssc files to place the nebulae where you want them to be, but you must know how to do it properly.

� KNOWN PROBLEMS
There are two ways to define nebulae in Celestia.  Normally, they should be declared in some .dsc file.  But then, with tons of nebulae everywhere in space, it can slow down Celestia to a crawl and I hate that.  So I defined all the nebulae as ssc objects instead.  The FPS is much faster this way.  However, if you try to click on a background star to leave the system where's the nebula is located, you will select the nebula instead.  This is a small annoying problem and there's nothing I can do about it.  All the nebulae should be looking fine from the INSIDE only.  If you place yourself outside a nebula, you'll see it as a dull spherical bubble with an hard edge.


� LICENCE AND CREDITS
This addon is completely free of charges and may be edited as you wish, but only if it's related to Celestia and education.  You may NOT use my textures or the models for any commercial purposes.

I'll be glad to hear any opinion or critics about this addon on the Celestia forum.

I apologise for the Bad English.

  Martin Charest (known as Cham, on the Celestia forum)
  December 2007