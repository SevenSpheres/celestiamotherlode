All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.4.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Beta Rigel" -press "g" and you're on your way there.
With the many contradictions between the true Rigel and the time/distance factors seen in some of the shows, I have decided to go with Beta Rigel, shown in the Star Trek Star Charts book. Right or wrong. What else can I do ??  : )

PLANET INFO-Rigel II is the second planet of the Rigel star system. 
Lieutenant Commander Leonard McCoy of the Federation starship USS Enterprise once met a pair of scantily-clad women in a cabaret chorus line on Rigel II. In 2267, the two women were recreated from Dr. McCoy's imagination on the Shore Leave Planet in the Omicron Delta region. (TOS: "Shore Leave") 

Rigel III is the third planet of the Rigel system. 
In an unknown, alternate future timeframe, Geordi La Forge lived on Rigel III with his wife Leah Brahms and his children. (TNG: "All Good Things...") 

Rigel IV is the fourth planet of the Rigel system. 
In 2266, the Redjac entity, incarnated as "Beratis", killed several women on Rigel IV. After leaving the planet heading toward Argelius II, another murder by Redjac is committed with a knife from Rigel IV's Argus River region. (TOS: "Wolf in the Fold") 
At some time prior to 2285, the people of the Argus River region were in conflict with the planetary government. A significant legal precedent arose from the peace pact between the two parties which stated that "All beings may not be created equal yet shall be given equal opportunity and treatment under the law." (Star Trek IV: The Voyage Home)
In the 24th century, a brilliant astronomer with a fondness for the Betazoid Ambassador Lwaxana Troi resided on Rigel IV. He named a star after Lwaxana, or so she claimed in 2367. (TNG: "Half a Life")
In mid-2370, Rigel IV hosted a nearly week-long conference on hydroponics attended by Keiko O'Brien. (DS9: "The Wire") 
Rigel IV was also the site of a pergium refinery. During the Dominion War, a shipment of pergium en route to Rigel IV from the Sappora system had been destroyed by the Jem'Hadar. (DS9: "Prodigal Daughter") 

Rigel V is the fifth planet in the Rigel system, and homeworld of the Rigelians. (TOS: "Journey to Babel") 

Rigel VII is an M-class world, the seventh planet in the Rigel system. 
In 2254, a landing party from the starship USS Enterprise, led by Captain Christopher Pike, visited Rigel VII. While inside an apparently abandoned fortress, Pike and crew were attacked by the native Kaylar warriors. Three crew members, including Pike's personal yeoman, were killed. Seven more were injured (including Spock, Navigator Tyler and a ship's geologist); some of these were so severely wounded that they required treatment at the Vega Colony. Pike later regretted his decision to enter the fortress, stating that "the swords and the armor" should have alerted him to the possibility of a trap. (TOS: "The Cage", "The Menagerie, Part I", "The Menagerie, Part II") 
There is a song called "Moon over Rigel VII," apparently inspired by a large, natural satellite orbiting the planet. Captain Kirk proposed singing it around a campfire while taking shore leave at Yosemite National Park on Earth with Captain Spock and Doctor McCoy in 2287 (Star Trek V: The Final Frontier). 
During the 2360s, Kobliad fugitive Rao Vantika used a subspace shunt to access and purge everything in the active memory on Rigel VII. He would do the exact thing to starbase Deep Space 9 in 2369. (DS9: "The Passenger") 
A view of the surface of Rigel VII was depicted on several viewscreens on Deep Space 9's Promenade and replimat, (DS9: "The Muse") advertising a visit to the "spectacular castles of Rigel VII". (DS9: "What You Leave Behind")

The frozen world Rigel X is the tenth planet in the Rigel system. It is the site of a trade complex consisting of 36 levels and populated by numerous different species. 
Rigel X is home to a species of large flies and a variety of colorful butterflies. 
In 2151, the Earth starship Enterprise visited Rigel X in its search for Klaang, a Klingon who had been kidnapped from the ship by the Suliban Cabal shortly before. Klaang had previously visited Rigel X to make contact with Suliban dissident Sarin. (ENT: "Broken Bow") 
In 2161, Enterprise returned to Rigel X to help Shran rescue his daughter, Talla. (ENT: "These Are the Voyages...") Rigel X was the first and last planet visited by Enterprise. (ENT: "Broken Bow", "These Are the Voyages...") 


Credits for helping me get started, texture creations, addon creators, and
special models. 
 
Nemec.jpg--John M Dollan 
AlulaPosterior.jpg--John M. Dollan
WorldNine.jpg--John M. Dollan
remus.jpg--jestr
annunaki.jpg--ROB SANDERS
bajor3a.jpg--jestr
Bristol.jpg--John M. Dollan
Ghellhonus.jpg--John M. Dollan
io.jpg--Celestia
naboo.jpg--Jean-Marie le cosp�rec
naphidemclouds.png--ROB SANDERS
Nessos-rings.png--John M. Dollan
NovaTerra.jpg--John M. Dollan
Penglai.jpg--John M. Dollan
th_fialarclouds.png--*
geographos.jpg--(Phil Stookes),jestr
Karun.jpg,Celens.jpg--John M. Dollan
Moons for Rigel VIII--jestr (see "MoonsReadMe" file)




* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.
   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
