Title		: Miranda Class Light Cruiser
Filename	: fcl.zip
Version		: 2.0
Date		: 9/19/2001
Author		: Rick Knox a.k.a pneumonic81
Email		: pneumonic81@apocent.com
URL		: http://www.apocent.com, http://www.apocent.com/www/dominion

Credits	
-------------	
model design	: Paramount
textures	: rick knox
mesh		: rick knox
Build time	: 4 days

Thanks to	: The SFC community




Description of the Modification
-------------------------------

an original model created in studio max and converted using MOD plugin





Copyright and Distribution Permissions
--------------------------------------
THIS PATCH IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY INTERPLAY
 TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices: 

Star Trek, Star Fleet Command, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions. 

If you use this model in any Starleet Command project please include this file. 
If you make this file available at your website or anothers please include a link to
http://starfleet.thegamers.net

Please do not modify this file or the included texture with out seeking the authors opinion.
Nothing legal here, it is just polite.

