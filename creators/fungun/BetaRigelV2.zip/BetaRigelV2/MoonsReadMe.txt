I have made this addon to work with Celestia v1.3.2 pre 10 or 11 or later,just unzip to your extras folder.
You should decide which texture format you wish to use (DDS or JPG) and delete the rest in both the hires
and medres folders before starting Celestia as it may cause problems otherwise.To make the models I have 
used the standard install models,smoothed out a few of the rough edges and converted to cmod format.Any
asteroids included here that dont have a standard model are pure fiction.The textures were made from any 
existing partial ones (Phil Stookes) where possible and added some fictional data for the missing bits.
For most of them they are pure fiction,though I tried to base their colour schemes on the spectral data 
available for each,with help from Grant Hutchison.The Eros texture is Grant's also (though I changed the
 hues slightly).With Kleopatra I have changed the way the texture is mapped differently to convention to 
minimise the stretching,it is such an odd shape though it still isnt great.As we know nothing about its
surface features I figured it didnt matter.Any problems Email me jestr@ntlworld.com