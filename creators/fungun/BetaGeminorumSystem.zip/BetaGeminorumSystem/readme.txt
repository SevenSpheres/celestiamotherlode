All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Pollux" -press "g" and you're on your way there.

PLANET INFO-Pollux IV is the fourth planet in the Pollux system, which is likely in Federation space, 33.7 light years from Sol. It is a Class M world with an oxygen-nitrogen atmosphere, and an approximate age of four billion years. Considered quite ordinary, there was no contact prior to the Enterprise's visit there in 2267. 
The Enterprise visited the Pollux system on a routine survey mission that year, where it encountered a being who claimed to be the Greek god Apollo. (TOS: "Who Mourns for Adonais?") 
A view of the surface of Pollux IV was depicted on several viewscreens on Deep Space 9's promenade and replimat (DS9: "The Muse") advertising a visit to the "amazing ruins of Pollux IV". (DS9: "What You Leave Behind") 

Pollux V is the fifth planet in the Pollux system. 
Like all other planets in this system, except for Pollux IV, the planet bore no signs of intelligent life, which was considered 'strange' when the planet was examined by the USS Enterprise in 2267. (TOS: "Who Mourns for Adonais?")

Credits for texture creations, addon creators, and
special models. 
  
Anhanguera.png--kikinho
Anori.png--kikinho
Igom-clouds.png--John M. Dollan
MirenidragX.jpg--*
pentesilea.jpg--Shcuf (ALARAPH addon)
Pictavia.jpg--John M. Dollan
Caeneus.jpg--John M. Dollan

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links. 

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
