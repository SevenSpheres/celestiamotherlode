All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-
For "Starbase 39 Sierra" press "Enter"-type in  "CHI Eri" -press "g" and you're on your way there.
For "Starbase 47" press "Enter"-type in  "Mu Cet" -press "g" and you're on your way there.
For "Starbase 129" press "Enter"-type in  "Alf Uma" -press "g" and you're on your way there.
For "Starbase 157" press "Enter"-type in  "TET Eri" -press "g" and you're on your way there.
For "Starbase 214" press "Enter"-type in  "Penthara" -press "g" and you're on your way there.
For "Starbase 343" press "Enter"-type in  "BET Cae" -press "g" and you're on your way there.
For "Starbase 514" press "Enter"-type in  "EPS Boo" -press "g" and you're on your way there.
For "Starbase 718" press "Enter"-type in  "MU Ara" -press "g" and you're on your way there.
For "Starbase Deep Space 6" press "Enter"-type in  "GAM Cen A" -press "g" and you're on your way there.

This addon is part 1 of a 4 part addon. The other parts will be released on a regular schedual of about 3 months apart.
Think of this as a prelude, so to speak, the rest I will keep secret for now. You can however take an educated guess by the ships you see at the stations.
You will also have to have the "Penthara" addon for Starbase 214 to show up.

STATION INFO-
Starbase 39-Sierra is a Federation starbase administrated by Starfleet, located near the Romulan Neutral Zone.
While en route to the Neutral Zone to investigate the disapperance of several outposts, Lieutenant La Forge suggests that most of the Enterprise's personnel should be left aboard the starbase to prepare a possibly hostile encounter with Romulan forces. (TNG: "The Neutral Zone") 

Starbase 47 was a Starfleet starbase that was responsible for new starship developments during the late 24th century.
In 2328, David Trotti traveled from Gamma Towles II to Starbase 47 onboard a transport ship. This information was part of a commercial passenger manifest database recorded in Federation records reviewed by Data in 2370.(TNG: "Inheritance") 

Starbase 129 is the closest starbase to the Argus Array. 
In one of the parallel universes encountered by Lieutenant Worf in 2370, the USS Enterprise-D was heavily damaged by the Cardassians and headed to this starbase for repairs. (TNG: "Parallels") 
In 2374, Starbase 129 received and filed casualty reports from several Ninth Fleet vessels involved in fighting at the Dominion front. It is unclear if any of these officers were assigned to this station, or simply if the base recovered their bodies. (DS9: "In the Pale Moonlight") 

Starbase 157 is a Federation outpost administrated by Starfleet. 
In 2366, this base picked up the final distress call from the transport Lalo. The Lalo reported encountering an unknown, cube-shaped vessel, which was later encountered and identified by the USS Enterprise-D as a Borg ship. (TNG: "The Best of Both Worlds") 

Starbase 214 is a Federation starbase. 
Immediately after his arrest on the USS Enterprise-D, Berlinghoff Rasmussen was imprisoned on Starbase 214. (TNG: "A Matter of Time") 

Starbase 343 was a Federation starbase in operation in the 24th century. 
In 2366, the USS Enterprise-D was diverted to the starbase to transport urgently needed medical supplies to the Alpha Leonis system, postponing its rendezvous with the USS Goddard. (TNG: "The Vengeance Factor")

Starbase 514 is a Federation starbase. The SS Vico reported to Starbase 514 while conducting its mission in a black cluster in 2368. (TNG: "Hero Worship") 

Starbase 718 is a Starfleet outpost located near the Romulan Neutral Zone. In 2364, Captain Jean-Luc Picard attended a conference there. (TNG: "The Neutral Zone") 
 







Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
