Federation Civilian Mining Station

During the late 2200's and early 2300's Starfleet had a number of ageing star-bases, these star-bases were, for the most part decommissioned with some components being salvaged others being discarded.
A few star-bases were taken over by civilian authorities and reconfigured for different uses ranging from ship and crew layovers to commercial ventures.

This particular star-base was in use up until 2333 as a subspace relay station, during its decommissioning it was  was stripped of most of its high yield ventral phasers internal mechanisms but rather than being fully dismantled it was handed over to a civilian asteroid mining firm, the last Starfleet officer in command at this station before being re-designated 'Laurlin Station' was Lt Jean-Luc Picard, he was given command during its decommissioning prior to his assignment on the USS Stargazer.
Outfitted with low output impulse engines and high output SIF(structural integrity field) generators Laurlin Station is able to move between asteroid fields to carry out its mining duties.


====================================================================================================
====================================================================================================

===================== Credits ==========================


mesh - ED - bankruptstudios

textures - bankruptstudios-The Unknown

backstory - description - Hobbs

hardpoint - TiqHud 

beta testing - SF R&D  - Uss Marine
[[ SF R&D team ,  hobbs [Uss Griffin], bankruptstudios, Lionus, TiqHud ]]
ScreenShots contributed by beta testers

NOTE: this is mainly eyecandy, so enjoy Blowing it up. it has Impulse engines, so you can move it into position
for a screenshot, named in honor of Laurlin , an early HPer.

=========================================================================
--------------------------------------------------------

COPYRIGHTS
__________________________________
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Star Trek, Bridge Commander, Star Trek Deep Space Nine, Star Trek The Next
generation, Star Trek Voyager (and various logo devices used in them) are
copyright Paramount Pictures, as are the characters, related images, and sounds
from the productions.