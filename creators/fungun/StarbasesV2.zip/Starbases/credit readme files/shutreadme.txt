Shuttle Readme

This is version 2 (and I think an improvedone) of the Dock Shuttle Mk2


This is being put out as freeware, but I retain the copyrights to the design changes and the model itself
This model may NOT under any circumstances be used in a commercial production without obtaining permission from me.
This model may ONLY be downloaded from Foundation 3d (http://www.foundation3d.com) if it is found anywhere else you did not obtain it legally.

Textures by Alain Rivard.

Thanks,

 Vitrualkey08@foundation3d.com


Have Fun