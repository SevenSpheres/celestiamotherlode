All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Procyon A" -press "g" and you're on your way there.

PLANET INFO-The moon of a ringed gas giant, Andoria is the capital world of the Andorian Empire, one of the founding members of the United Federation of Planets and home to the Andorians and the Aenar.
Andoria is an ice world, with a human-breathable oxygen-nitrogen atmosphere. Andorian cities are underground and take their energy from geothermal activity. The cities are connected to each other by thousands of kilometers of tunnels.
Only during rare heatwaves will the temperature on Andoria rise above freezing, and even then only for a few weeks at a time. During mid-summer, a temperature reading of -28� is not uncommon. (ENT: "The Aenar") 
Kasidy Yates considered the mountains of Andoria as a site for a honeymoon with Benjamin Sisko in 2375. (DS9: "Strange Bedfellows") 

The Kumari was an Andorian battle cruiser that was in service with the Andorian Imperial Guard during the mid-22nd century. It was named after the first ice cutter to circumnavigate Andoria and was the first starship of her class. The Kumari was put under the command of Commander Shran in 2142. (ENT: "Babel One", "United") 




Credits for helping me get started, texture creations, addon creators, and
special models. 
  
asgardclouds.png--ROB SANDERS
asteroid7.jpg--jestr
e-bump.jpg--John M. Dollan 
gamma.jpg--*
GasGiant-Blue.jpg--Matthew Attard(maynot be used in other addons without permission. I had to get special permission to use them!)
golevka.jpg--Celestia
Khemet.jpg--John M. Dollan
PhioneIV-clouds.png--John M. Dollan
Rerinmisna.jpg--*
Sarustre.jpg--John M. Dollan
Soomwe.jpg--John M. Dollan
Tsubar.jpg--John M. Dollan
Umeridigra-clouds.png--*
vesta.jpg--jestr
Triniom.jpg--Pericapolis
nr2-clouds.png--John M. Dollan
asteroid models--Celestia

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.  

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
