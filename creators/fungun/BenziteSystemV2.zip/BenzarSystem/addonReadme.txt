All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "DEL Pav" -press "g" and you're on your way there.

PLANET INFO-Benzar is a planet located in the Benzite system, and homeworld of the Benzite civilization � a significant member of the United Federation of Planets. Benzar's atmosphere differs somewhat from class M norms, such as that before the 2370s Benzites offworld required a respiration device. (TNG: "Coming of Age"; DS9: "The Ship")
During the Dominion War, Benzar fell to the Dominion and Cardassian forces in 2374. However, the planet was later liberated by the Romulan Star Empire after it joined the war on the side of the Allies. Constable Odo expressed concerns that the Romulans would not give up control of Benzar even after the war ended, as their usual policy was to keep claimed territories. (DS9: "The Reckoning") 


Credits for helping me get started, texture creations, addon creators, and
special models. 

delpav2a.jpg--bdfd(mod)/Celestia(Io)
Hadies-clouds.png--Milosz21
moon_i.jpg--Rassilon
pallas.jpg--John M Dollan
Riss.jpg--John M Dollan
romulus2.png--jestr
watcher.jpg--*

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.
  
   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
