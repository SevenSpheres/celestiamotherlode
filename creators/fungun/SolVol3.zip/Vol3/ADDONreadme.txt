All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

You can view these items by expanding (+) different Solar System bodies.
Around Earth-Drydock, Spacedock, NCC-1701-A, a workbee, a Dock Shuttle.
Around the Moon-Copernicus Ship Yards and 2 transport ships
Around Jupiter-Jupiter Station and the USS Volga
Around Callisto-USS Antares
Around Sedna (in the ort cloud)-Relay Station 47

STATION INFO-1. Jupiter Station-The facility, or one that shared the same name, was constructed sometime prior to 2151 and was apparently used for starship repairs and maintenance work. 
In 2151, the Enterprise NX-01 planned to return to Jupiter Station to be equipped with phase cannons by the local stationed armory team. This plan, however, was rendered unnecessary, when the ship's crew managed to install the weapons on its own in only 48 hours, whereas the installation at Jupiter Station was planned to take about a week. (ENT: "Silent Enemy") 
In an alternate timeline, Commander Charles Tucker of the Enterprise mentioned that the overall rebuild of a warp coil would take three weeks at Jupiter Station. (ENT: "Twilight") 
During the mid-2360s, Tuvok was temporarily assigned to Jupiter Station where he would often write to Kathryn Janeway. (VOY: "Tuvix") 
In the 2370s, the commanding officer of Jupiter Station was a female. (DS9: "Doctor Bashir, I Presume") 
Holoprogramming Center 
By the 2360s, the station was the location of the Jupiter Station Holoprogramming Center, run by Dr. Lewis Zimmerman. (VOY: "Projections", "Life Line") 
It was on Jupiter Station where Dr. Zimmerman created the Emergency Medical Hologram program. (VOY: "The Cloud") 
Zimmerman offered Leeta a job in the caf� on the station during his visit to Deep Space 9 in 2373 to interview Julian Bashir for the template of Long-term Medical Holographic program. (DS9: "Doctor Bashir, I Presume")

2. The Copernicus Ship Yards are a starship construction facility maintained by Starfleet in orbit of Luna. Vessels constructed here included the USS Hathaway (under the auspices of the Yoyodyne Division). (TNG: "Peak Performance") 
There may be associated facilities located on the Lunar surface, as with Utopia Planitia on Mars. There was no overt reference to the shipyard in the episode, although it was included in the ship's dedication plaque photographed on the set, created by the art department. Such facilities could be orbital or be a part of Copernicus City, the birthplace of Beverly Crusher

3. Relay Station 47-A typical relay station is exclusively designed to transmit and receive several thousand subspace messages on Federation and Starfleet communication channels. As such, its exterior consists of a small crew module, a solar panel, and a large antenna farm. The magnitude of subspace communications converging toward the station can interfere with standard bioscans. 




Credits for helping me get started, texture creations, addon creators, and
special models. 
  
   
3d duckboy productions
3d.concept40.com
John M. Dollan
Don Edwards
Andy Roberts
Steve Bowers
Ivo Beckers
http://galaxistar.googlepages.com
Matt Davis
Selden Ball
Runar Thorvaldsen
Rob Sanders
Cham (from Celestia forum) 
 jestr (Celestia forum)
Pericapolis
Fridger Schrempp
pioneerxtower (J. P.)
Bruckner
Shcuf
Jean-Marie le Cosp�rec
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
