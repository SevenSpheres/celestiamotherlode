All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Vega" -press "g" and you're on your way there.

PLANET INFO-Vega IX is a planet in or near Federation space, in the Vega system. 
In the mirror universe, Vega IX was the location of a Terran colony, where Terran Empire captain James Kirk executed over 5,000 colonists in his second action as commanding officer of the ISS Enterprise. (TOS: "Mirror, Mirror") 
It is not clear if Vega IX is the location of a Human colony in the more familiar Federation universe. However, there have been numerous references to Vega colony, so it seems a likely conclusion that the colony could lie on this world in this universe as well, since we at least know there is a colony in the same system here.

Vega colony, located in the Vega system, was established in the early 22nd century, and was one of Earth's most important trade partners in the early days of human interstellar exploration. It was one of the earliest colonies established, along with the Alpha Centauri and Terra Nova colonies. It was, for many decades, located on the frontier of known space. 
Travis Mayweather was born aboard his parents' interstellar cargo ship, the ECS Horizon, halfway between Vega colony and Draylax. (ENT: "Fortunate Son") 
In 2152, Admiral Forrest speculated that an escape pod-like vessel, found by Enterprise, might have been launched by Vega colony. However, the small vessel was later discovered to be a timeship from the 31st century. (ENT: "Future Tense") 
In 2254, the USS Enterprise planned to make use of the facilities at Vega colony to replace crew killed or injured on Rigel VII and to hospitalise some of the casualties. (TOS: "The Cage") 
In an alternate timeline, Vega colony was wiped out by the Xindi following their destruction of Earth in 2154. (ENT: "Twilight") 



Credits for helping me get started, texture creations, addon creators, and
special models. 

bauci.jpg--Shcuf  
cardassiaiii.jpg--jestr
ChinookZ.jpg--John M. Dollan
dactyl.jpg--jestr
Iramaia.jpg--kikinho
Mercury.jpg--Celestia
ngc2244-katalina_iii-moon_i-clouds2.png--Rassilon
ngc2244-katalina_iii-moon_i-clouds.png--Rassilon
Pholus-clouds.png--John M. Dollan
pluto.jpg--gradius_fanatic
Ruda.jpg--kikinho
syliarClouds.jpg--*
taranis2.jpg--John M. Dollan
tundro.jpg--gradius_fanatic,Bob Hegdewood


   
* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
