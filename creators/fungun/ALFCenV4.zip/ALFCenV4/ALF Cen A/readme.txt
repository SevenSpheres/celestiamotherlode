All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "ALF Cen A" -press "g" and you're on your way there.

PLANET INFO-Alpha Centauri IV (commonly known as Velestus, Centaurus or Al Rijil IV) is the fourth planet in the Alpha Centauri star system, orbiting the primary binary pair of stars, Rigil Kentaurus and Quindar. This world is class M and is home to humanoid inhabitants, including a thriving Federation colony started by Human settlers and other Centauran cultures. (Reference book: The Worlds of the Federation; TOS novels: "Crisis on Centaurus", "Time for Yesterday")

Alpha Centauri V is the fifth planet in the Alpha Centauri star system, orbiting the primary binary pair of stars, Rigil Kentaurus and Quindar. This world is class M and is home to humanoid inhabitants. The planet has two moons. (Reference book: The Worlds of the Federation)

Centauri VII is a planet in the Alpha Centauri system.
Centauri VII was the homeworld of the artist Taranullus. Original prints of his creation lithographs were rare antique collectibles in 2269 when seen by Spock on Omega system planet Holberg 917G. The immortal Flint's collection included original works and acquisitions from his many lives; since it contained Taranullus's work, the prints were either Flint's own work or were acquired by him. (TOS: "Requiem for Methuselah") 



Credits for texture creations, addon creators, and
special models. 
  
Coast.jpg, Fetterley.jpg, Hesperides.jpg, Sanaxus.jpg--John M. Dollan  maastrichian@bresnan.net

AmaleDs3.jpg--John M. Dollan  maastrichian@bresnan.net / Anders Sandberg

bacchus.jpg, ky26.jpg, vesta.jpg, bacchus.cmod, ida.cmod, ky26.cmod, vesta.cmod--jestr

batavorum.jpg, ninurtaclouds.png--Rob Sanders

dominion.jpg, uriel.jpg-- galaxistar@gmail.com

karistatRissHadiesSmaan.jpg--Cham / John M. Dollan  maastrichian@bresnan.net / Milosz21 / gradius_fanatic

luciferDarknetRaissa.jpg-- galaxistar@gmail.com / gradius_fanatic / Shcuf, ALARAPH addon

moon05.jpg, moon40.jpg--jestr/Mod, Tim

WorldFourX.jpg--John M. Dollan  maastrichian@bresnan.net / mod, Tim

th11embla.jpg--Runar Thorvaldsen

zaphdsmanmon.jpg--CRAIG STRAPPLE / gradius_fanatic

kobayeskand.jpg--kikinho / jestr


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
