TOS Starfleet Headquarters from the Strafleet Technical Manaual.


This Starbase is balanced for the TOS Era


ARMAMENT

18 Phaser Banks
12 Photon Torpedo Tubes


INSTALLATION

Extract the data, scripts and sfx folders to your BC directory.  Click [Yes to All] when prompted.


REQUIREMENTS

Sovereign QB Description fix for the ship descriptions to show up in in QB Player Setup:
http://bridgecommander.filefront.com/file/Bridge_Commander_Universal_Tool_aka_BCSMC;97168


KNOWN BUGS

 None that I know of


CREDITS

 Mesh: GMunoz
 
 Hardpoint: GMunoz

 Textures: GMunoz

 
CONTACT 

 gmunoz@bellsouth.net


COPYRIGHTS 
__________________________________
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Star Trek, Bridge Commander, Star Trek: Deep Space Nine, Star Trek: The Next
generation, Star Trek: Voyager (and various logo devices used in them) are
copyright Paramount Pictures, as are the characters, related images, and sounds
from the productions.