VULCAN SHUTTLE FROM STAR TREK: TMP

Model Author: Atra-Hasis
Illumination: Hollis J. Wood
Date done: Nov 2001
Homepage: http://www.geocities.com/atrahasis1/index.html
Email: atrahasis1@hotmail.com



Have fun using this mod in your SFC1 or SFC2 game. If you want to include this model in a modification for another game please contact me to let me know, so we can link to each other's pages! Otherwise use for any other reason is forbidden. 

Poly count: 350



atrahasis1@hotmail.com