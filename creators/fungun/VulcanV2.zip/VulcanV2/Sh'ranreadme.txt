
Mesh - Gtea
Textures - Gtea

Kitbashing is allowed on all my models, you just need to ask!

Gav_Thomson@Hotmail.com

No copyrights were infinged in the making of these ships.

Porting to Starfleet command :Darkdrone