All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out. 

Start Celestia-press "Enter"-type in  "40 Eri A" -press "g" and you're on your way there.

PLANET INFO-Although there is no canon reference to Vulcan being located in the 40 Eridani system, it is widely considered as a fact used by Gene Roddenberry and backed by ENT: "Daedalus", in which Vulcan is mentioned as being slightly over 16 light years from Earth, the same distance between Earth and 40 Eridani A. According to text commentary by Michael and Denise Okuda for "The Forge" on the ENT Season 4 DVD, the possibility of Vulcan being located in the 40 Eridani system originated from a suggestion by novelist James Blish. When three astronomers (Sallie Baliunas, Robert Donahue, and George Nassiopoulas) who had been studying the system at Mount Wilson Observatory published a letter stating "that [the star] 40 Eridani A could support a planet with Earth-like life" and that it would "have the Sun's brightness for a planet 50 million miles away", they theorized that Vulcan could be in orbit of this star, a theory Gene Roddenberry himself supported by signing their letter.

Star Trek Star Charts confirms the location. Name of the star is listed as 40 Eridani A (Omicron 2 Ceti). There are three planets and an asteroid belt in the system. Planet I is class-B. In Star Charts this is also the classification of Mercury. Planet II, Vulcan, is class-M. Planet III, T'Khul, is class-G and has a moon. In Star Charts class-G is the classification of planets similar to Delta Vega. Vulcan and T'Khul are twin planets.

Vulcan is a Class M planet in the Vulcan system and homeworld of the humanoid Vulcans, a founding member of the United Federation of Planets. 
The planet is located "a little over" 16 light years from Earth. It has no moons, but appears to have close planetary companions. (ENT: "Home"; TOS: "The Man Trap"; TAS: "Yesteryear"; Star Trek: The Motion Picture)

The Star Trek novel Spock's World offers the explanation that the "moon" appearing in the Vulcan sky in "Yesteryear" and the original cut of Star Trek: The Motion Picture was actually the sister planet of Vulcan, called T'Khut. This theory is widespread in other non-canonical works like Star Trek Maps, Star Trek Star Charts and The Worlds of the Federation.


Credits for texture creations, addon creators, and
special models. 
  
Erebus.jpg--Milosz21
thyla.jpg--jestr
Uppsala2.png--John M. Dollan j.dollan@bresnan.net
vanuph.jpg--jestr
vulcan.png--jestr
   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
