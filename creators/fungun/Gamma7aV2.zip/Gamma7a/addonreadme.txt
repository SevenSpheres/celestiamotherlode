All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Gam Cet" -press "Enter" then press "g" and you're on your way to the Gamma 7A system itself. The system includes the dead USS Intrepid, the Space Amoeba, the Enterprise, and the shuttle Galileo.

press "Enter"-type in "SB6" press "Enter" then press "g" and you will go to the near by Starbase 6, which is where communications with the Gamma 7A system and the Intrepid were lost.

SYSTEM INFO-The Gamma 7A system was a solar system located in Sector 39J with billions of inhabitants until 2268. 
This year, while the system was investigated by the USS Intrepid, both the system and the Intrepid were attacked by the space amoeba and all life was wiped out. As contact with the system therefore ceased, nearby Starbase 6 ordered the USS Enterprise to investigate; the ship was finally able to destroy the amoeba. (TOS: "The Immunity Syndrome") 

The USS Intrepid (NCC-1631) was a Federation Constitution-class starship crewed almost entirely by Vulcans. (TOS: "The Immunity Syndrome") 
In 2267, the Intrepid was undergoing repairs in maintenance section 18 at Starbase 11. The base commander, Commodore Stone, rescheduled the Intrepid's repairs, upon giving the USS Enterprise "Priority 1" status on stardate 2947.3, after being damaged in an ion storm. (TOS: "Court Martial") 
In 2268, the Intrepid worked in conjunction with Starbase 6, in conducting a mission to investigate the loss of contact with solar system Gamma 7A in Sector 39J. While traversing that sector of space, the Intrepid encountered an unknown dark zone which was, unbeknownst at the time, slowly killing the ship's crew. 
On stardate 4307.1, Starbase 6 lost contact with the Intrepid. A rescue priority was issued to the Enterprise to investigate the loss of the Intrepid in an unknown dark zone. En route, Commander Spock telepathically sensed the crew of 400 Vulcans die. 
On stardate 4309.2, the Enterprise established that the thing which destroyed the Intrepid and the Gamma 7A system was an incredibly huge but simple cellular being whose energies are totally destructive to all known life. The crew of the Enterprise destroyed the form, which was determined to be nourishing itself for reproduction. (TOS: "The Immunity Syndrome") 

The space amoeba was a vast, space-dwelling being, single-celled organism of unknown origin, surrounded by a field of negative energy. 
The USS Enterprise encountered the space amoeba in 2268 while en route to Starbase 6, after diverting to investigate the destruction of an inhabited planet in the Gamma 7A system and the all-Vulcan starship USS Intrepid. 
The Enterprise crew discovered that the negative energy field was toxic to humanoid life. They also found that the organism would soon reproduce by cell division. In view of the danger posed by the organism and its multiplication across the galaxy, the Enterprise crew used an antimatter charge to destroy it. (TOS: "The Immunity Syndrome") 
Retrieved from "http://memory-alpha.org/en/wiki/Space_amoeba"


Credits 

asteroid11.jpg--jestr
cenote.jpg--Steve Bowers,John M Dollan
karistat.jpg--Cham

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
