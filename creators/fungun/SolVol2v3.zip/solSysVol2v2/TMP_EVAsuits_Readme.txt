
EVA Suit 

In the 2270�s Starfleet�s new EVA suits were issued to all vessels of the fleet. Capable of use in space and planet side the EVA suits consist of durable, if bulky, fully pressurised environmental suit complete with �bubble� style helm and equipped with sophisticated life support systems and miniature thrusters for minor movement in the stellar vacuum. 

These suits were also able to be attached to a thruster system which allowed short duration flight in space. This was used during the situation with the V�GER probe that was heading for earth, Commander Spock of the star ship Enterprise used the thruster pack to approach the probe. 

Some situations may have cause for security personnel to use these suits, they can be issued with or without the thruster pack but all come with at least a type 2 phaser. 

Another use of these suits was for EVA star ship diagnostic and repair duties, Engineers could use these suits to get a far closer look at exterior damage to Starships and during space dock repair and refits. 

In this pack we proudly present three TMP era EVA suits, we give you the standard �EVA suit�, the Thruster Variant �E1� in this case with a type 2 phaser for use by security personnel and the Engineering version �D1� complete with diagnostic and repair tools.

===================== Credits ==========================
Thank you Totally games for making Bridge Commander possible and
For the Patch that we use (1.1)

and Dasher42 for his Foundation mod that allows us to add more ships
  (the foundation comes bcut and in Kobayashi Maru)

USS Sovereign for BCUT - TDE (good tools) 

Kobayashi Maru -  by the KM Team - Defiant team Leader [highly recommended]

-------------------- TMPeva ---------------------

mesh - baz1701 - bankruptstudios
textures - bankruptstudios
 
back story-description - hobbs

hardpoint - TiqHud 

beta testing - SF R&D - Uss Marine
[[ SF R&D team ,  hobbs [Uss Griffin], bankruptstudios, sovereign001, GMunoz, Linous, TiqHud ]]
ScreenShots contributed by beta testers

Note: these will be in "EVA Ships" menu

=========================================================================
--------------------D1suit[enginerring]---------------------

mesh -  bankruptstudios
textures - bankruptstudios

back story-description - hobbs

hardpoint - TiqHud 

beta testing - SF R&D - Uss Marine
[[ SF R&D team ,  hobbs [Uss Griffin], bankruptstudios, sovereign001, GMunoz, Linous, TiqHud ]]
ScreenShots contributed by beta testers

Note: these will be in "EVA Ships" menu ,this suit is named in honor of a baby boy (Tyler)
                                           born to one of our team [hobbs] recently

=========================================================================
--------------------E1suit[Security]---------------------

mesh -  bankruptstudios
textures - bankruptstudios

back story-description - hobbs

hardpoint - TiqHud 

beta testing - SF R&D - Uss Marine   
[[ SF R&D team ,  hobbs [Uss Griffin], bankruptstudios, sovereign001, GMunoz, Linous, TiqHud ]]
ScreenShots contributed by beta testers

Note: these will be in "EVA Ships" menu

=========================================================================


 DO NOT EXPORT TO ANOTHER GAME WITHOUT PERMISSION from baz1701 on his TMP eva suit
asking permission of Any modeler is just a polite thing to do

BAZ1701 can be reached through BC-central as can most of SF R&D


I can be emailed at  tiqhud AT gmail Dot com   [best if emailed] , or PMed at BCC , BCS:TNG

by the installation of this Mod-ship you agree that I or anyone mentioned in this readme, can NOT be held 
responsible , for the Messing up of Your computer


COPYRIGHTS
__________________________________
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Star Trek, Bridge Commander, Star Trek Deep Space Nine, Star Trek The Next
generation, Star Trek Voyager (and various logo devices used in them) are
copyright Paramount Pictures, as are the characters, related images, and sounds
from the productions.