All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

You can view many items by expanding (+) on "Earth"-"Moon"-"Copernicus Ship Yards".

Around the Moon is Copernicus Ship Yards, it includes, 2 Transport ships, 5 Workerbees, 2 Cargobees, 3 EVA personel, a Travel Pod, and the construction of a Galaxy Class Starship.

STATION INFO-The Copernicus Ship Yards are a starship construction facility maintained by Starfleet in orbit of Luna. Vessels constructed here included the USS Hathaway (under the auspices of the Yoyodyne Division). (TNG: "Peak Performance") 
There may be associated facilities located on the Lunar surface, as with Utopia Planitia on Mars. There was no overt reference to the shipyard in the episode, although it was included in the ship's dedication plaque photographed on the set, created by the art department. Such facilities could be orbital or be a part of Copernicus City, the birthplace of Beverly Crusher.


Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
