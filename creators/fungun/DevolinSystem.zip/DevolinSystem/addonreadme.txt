All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.5.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-Here is a slight problem. The Solar System browser does not handle Barycenters very good.
                                          You can type in "Devolin"-and see the Trinary's system Barycenter and by using the Solar System browser 
                                           can go to "Devolin B"

                                         To see the rest of the addon you must press "enter", type in "Devolin A", "enter", "g" - this will take you to the
                                          binary pair Barycenter of Devolin Aa-Devolin Ab.
                                          From here press "Enter" and type in any of these destinations - Rocks1, Rocks2, Rocks3, Rocks4, Rocks5,
                                          Rocks6,  Alpha 331, Beta 671, Gamma 601, or Warbird.

Inside one of the Asteroids (if you saw the episode "The Pegasus", you'll know which one ) you will find the U.S.S. Pegasus and the Enterprise-D.   Good luck  : )

The Blackhole model and textures were a combo of Cham's and Jorge Omar Leyra's Blackhole models.

SYSTEM INFO - The Devolin system is a star system in neutral territory close to both the United Federation of Planets and the Romulan Star Empire. The system contains a great deal of ionizing radiation and contains a large asteroid field. 

In 2358, the USS Pegasus drifted into the system, having suffered heavy damage from a large explosion in Main Engineering. The ship was testing an experimental (and illegal) interphase cloaking device. Still in a phased state, the ship passed in to a large asteroid, at which point the cloak failed and the ship dephased, with around two-thirds of the ship materialising inside solid rock. The explosion, along with the hull breaches caused by the failure of the cloak, killed everyone aboard. 

In 2370 the Romulan warbird IRW Terix entered the system and discovered wreckage from the Pegasus. Starfleet learned of this and dispatched the USS Enterprise-D to locate the ship first. They were successful, but their attempts to recover the phasing cloak were hindered when the Romulans sealed the Enterprise inside the asteroid. The Enterprise was able to escape using the phasing cloak to pass through the rock. (TNG: "The Pegasus") 

Credits for helping me get started, texture creations, addon creators, and
special models. 
  
   
3d duckboy productions
3d.concept40.com
John M. Dollan
Don Edwards
Andy Roberts
Steve Bowers
Ivo Beckers
http://galaxistar.googlepages.com
Matt Davis
Selden Ball
Runar Thorvaldsen
Rob Sanders
Cham (from Celestia forum) 
 jestr (Celestia forum)
Pericapolis
Fridger Schrempp
pioneerxtower (J. P.)
Bruckner
Shcuf
Jean-Marie le Cosp�rec
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
