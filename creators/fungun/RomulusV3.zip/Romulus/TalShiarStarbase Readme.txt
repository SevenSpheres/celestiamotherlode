'''''''''''''''''''''''
''TalShiarStarbase Readme
'''''''''''''''''''''''


Title		: Tal Shiar Starbase
Version		: 1.0
Author		: Laurelin
Email		: LaurelinRuadan@Hotmail.com


Credits	
-------------	
Model design	: Maddoc Software & Laurelin
Textures	: Maddoc Software & Laurelin
Mesh		: Maddoc Software & Laurelin
Build time	: Not very long :)

Thanks to	: USS Phoenix for answering all my silly questions :) 


Known Bugs
----------
None

Copyright and Distribution Permissions
--------------------------------------
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY INTERPLAY
 TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices: 

Star Trek, Star Fleet Command, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions. 

Feel free to modify these files or the included textures with out seeking the authors opinion :)

