All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Canopus" -press "g" and you're on your way there.

PLANET INFO-Alpha Carinae II is a Class M planet in the Canopus system with two major landmasses and a number of islands. It is inhabited by an intelligent species. 
The geologist Carstairs once visited this planet while serving in the Merchant Marines on a geology survey for a mining company. 
On Stardate 4729 the USS Enterprise surveyed this planet as a test of the M-5 computer's capabilities. (TOS: "The Ultimate Computer")
Alpha Carinae III is a planet which is located in the Canopus system, in or near Federation space, several light years from the planet Lactra VII. It is known for its desert-like terrain, which is home to a type of large dinosaur. James T. Kirk visited Canopus III some time during or prior to the 2260s. 
In 2269, the crew of the USS Enterprise encountered a dinosaur in a desert environment on Lactra VII, that was very much like the dinosaurs native Canopus III. Despite initially hypothesizing that similar environments prompt similar evolution in species, it was later determined that the beast was, in fact, transplanted to the planet by the Lactrans, who terraformed the desert terrain for the beast as part of their zoo exhibit. (TAS: "The Eye of the Beholder") 
Alpha Carinae V is the fifth planet in the Canopus system and home to the creature Drella. (TOS: "Wolf in the Fold")

Credits for helping me get started, texture creations, addon creators, and
special models. 

canopus3.jpg--Tim
Diaspora2.jpg--John M. Dollan j.dollan@bresnan.net
nr2.jpg--John M. Dollan j.dollan@bresnan.net 
raissa.jpg--Shcuf,Runar Thorvaldsen
tim1010a.jpg--John M. Dollan j.dollan@bresnan.net
AdtnHippGuar.jpg-- * / John M. Dollan j.dollan@bresnan.net / kikinho
CunhaEskan.jpg-kikinho / jestr
KobaySlush.jpg--kikinho / Gradius_fanatic
ShiryPortu.jpg--kikinho / Gradius_fanatic

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.    


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
