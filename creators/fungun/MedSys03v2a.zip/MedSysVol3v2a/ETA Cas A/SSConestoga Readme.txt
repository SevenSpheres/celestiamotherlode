S.S. Conestoga

The S.S. Conestoga was Earth's first ship to colonize a planet out side the Sol system. She was launched in 2067 for colonisation of Terra Nova, an inhabitable planet which was located some twenty light years from Earth. It was planned and built only four years after Cochrane's Phoenix without help from the Vulcans and could attain a maximum speed of warp 1.3. Once the Conestoga reached the planet in 2078, the ship was dismantled in order to construct the initial dwellings of the colony and thus removed any prospect of return. 

Earth lost contact with the colonists in about 2080 and it was not until 2151 that Enterprise NX-01 was instructed to investigate. It transpired that much of the planet had been irradiated by an asteroid collision and the human survivors had been forced to seek sanctuary in subterranean tunnels. Their descendents, mutated by the radiation, continued to survive after the Enterprise survey, although relocated to an uncontaminated region of Terra Nova. 


This ship is balanced for the Pre-TOS Era


ARMAMENT

1 Dorsal Laser





CREDITS

 Mesh: GMunoz
 
 Hardpoint: GMunoz

 Textures: BankruptStudios

 Original Design: Paramount


CONTACT 

 gmunoz@bellsouth.net


COPYRIGHTS 
__________________________________
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Star Trek, Bridge Commander, Star Trek: Deep Space Nine, Star Trek: The Next
generation, Star Trek: Voyager (and various logo devices used in them) are
copyright Paramount Pictures, as are the characters, related images, and sounds
from the productions.

Do not distribute modified versions of these files without attaining permission from the 
author.  This includes mesh changes, textures, HP's, conversions, and any other modifications.
To request permission, please contact me via e-mail or PM at BCC.