All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "ETA Cas A" -press "g" and you're on your way there.

PLANET INFO-Terra Nova (or Eta Cassiopeia III) is a Class M planet located in the Eta Cassiopeia star system of the Alpha Quadrant, and is less than twenty light years from the Sol system. 
In 2078, Terra Nova became the first planet outside the Sol system to be colonized by Humans. After several years of success with the colony, Earth decided to send more colonists to the planet, which didn't meet with the approval of the Novans. Shortly after, the colony was struck by meteors which unleashed massive radiation in the planet's atmosphere. Survivors were able to escape underground, but communications with Earth were cut-off, and the colony was officially declared lost, causes unknown. 
The colonists were eventually rediscovered in 2151 by Captain Jonathan Archer and the crew of the Enterprise (NX-01). While the descendants of the colonists were initially untrusting of the Enterprise crew, they soon agreed that Earth was not responsible for the meteor strikes, and decided to work to relocate their populace to a new uncontaminated area. (ENT episode: Terra Nova). 
Logan City soon became the capital city of the colony, and following admittance into the United Federation of Planets in 2178, the planet's inhabitants increased to around 374,000 by 2376. (Reference: Star Trek: Star Charts)


Credits for helping me get started, texture creations, addon creators, and
special models. 

baccSmaan2.jpg--jestr / gradius_fanatic
ky26HopiChino.jpg--jestr / John M. Dollan j.dollan@bresnan.net 
SnoozNeuma.jpg--Milosz21 / Rob Sanders
TeleboCesar2.jpg--John M. Dollan j.dollan@bresnan.net / Milosz21  
Arcadia-clouds.png--John M. Dollan j.dollan@bresnan.net / Don Edwards
labworld3x.jpg--Anders Sandberg / John M. Dollan j.dollan@bresnan.net


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
