All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Beta Veldonna" -press "g" and you're on your way there.

PLANET INFO-The planet Betazed is an important member world of the United Federation of Planets. The current Betazed Federation ambassador is Lwaxana Troi, Daughter of the Fifth House, Holder of the Sacred Chalice of Rixx, Heir to the Holy Rings of Betazed. (TNG: "Manhunt") 

Betazed hosted the biennial Trade Agreements Conference in 2366. (TNG: "M�nage � Troi") 

The USS Enterprise-D passed fairly close to Betazed in late 2367 and diverted its course to pick up Lwaxana Troi. (TNG: "Half a Life") 

Deep Space 9 was quite far from Betazed, although a transport from the station often left for the planet. (DS9: "The Muse") 

Vash was unwelcome (persona non grata in Q's words) on Betazed. (DS9: "Q-Less") 

The University of Betazed is located on Betazed. (TNG: "Tin Man", "M�nage � Troi", "Qpid") 

Starbase G-6 is a Federation facility operated by the Federation during the 24th century. It is located near Betazed and the Sigma III system. 
In early 2364, the USS Enterprise-D dropped off Deanna Troi at Starbase G-6 for a shuttle visit home. (TNG: "Hide and Q") 



Credits for texture creations, addon creators, and
special models. 
  
gasgiantgreen--Matthew Attard(maynot be used in other addons without permission. I had to get special permission to use them!)

Artur.jpg--John M. Dollan
Baalen.jpg--John M. Dollan
Chiloque.jpg--John M. Dollan
DelNorte.jpg--John M. Dollan
Mennufarsi.jpg--John M. Dollan
seraphius.jpg--GalaxiStar universe
Teleboas.jpg--John M. Dollan
Coast-rings.png--John M. Dollan
Mennufarsi-clouds.png--John M. Dollan
andria.jpg--Shcuf
bacchus2.jpg, bacchus.jpg, dactyl.jpg, eros2.jpg, geographos.jpg, golevka.jpg, juno.jpg, ky26.jpg, mathilde.jpg, toutatis.jpg, vesta.jpg, terilian.jpg, sciattus.jpg--jestr
   
qingu2.jpg--Seth Pritchard/Texture created or edited from Solar System textures in GIMP

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
