Ol�!

Obrigado por escolher meu trabalho. espero comentarios.
 
Este modelo digital da Clydesdale � para livre uso em renderiza�oes artisticas em 3D .

� vedado o comercio deste arquivo sob qualquer meio ou midia.
Todavia, pe�o a inclus�o :
1) o nome do autor do modelo seja citada.
2) o site de origem seja citada na mesma (vvv.trekmeshes.ch).

Por exemplo:
" Clydesdale mesh: Raul Mamoru
Em: http://www.trekmeshes.ch/ "

Se possivel, envie para mim seu comentario ou a sua arte renderizada com este modelo da Clydesdale:
raul.mamoru@gmail.com

Obrigado!

********************************************************

Hello!

Thank you for choosing my work. I expect comments.
 
This digital model of the Clydesdale is free for use in artistic renderings in 3D.

It is forbidden to trade this file in any media.
However, I ask for inclusion:
1) the name of the author's model is cited.
2) the site of origin is mentioned in it.

For example:
"Clydesdale mesh: Raul Mamoru
In: http://www.trekmeshes.ch/ "

If possible, please send me your comments or your art rendered with this model of the Clydesdale:
raul.mamoru @ gmail.com

Thanks!

Sao Paulo - Brazil - South America - Earth - Area 001 - 2010

Translated by: Google