All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "GAM Tri" -press "g" and you're on your way there.

PLANET INFO-The atmosphere of its sixth planet, which was controlled by Vaal, filtered out any harmful effects from the star. The people of that planet believed that Vaal controlled their sun. (TOS: "The Apple") 

Credits for helping me get started, texture creations, addon creators, and
special models. 

zeus.jpg,zeusclouds.png--John Dollan and Steve Bowers  
Copacabana.jpg--kikinho
Eutresca.jpg--John M. Dollan 
GasGiantYellow.jpg--Matthew Attard(maynot be used in other addons without permission. I had to get special permission to use them!)
pentesilea2.jpg--Shcuf (mod Tim)
PlntTexAvmorgan2.jpg--layout,AV Morgan/colorization,Tim
Shinji.jpg--kikinho
earth-clouds.png--Celestia 

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
