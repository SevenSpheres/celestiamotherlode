All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Antares B" -press "g" and you're on your way there.
The Solar System browser in 1.4.1 does not navigate the planets of a secondary star in a binary star system.
Therefore to see the planets of Antares-B you must press "Enter" type in "Antares B-i", ii, iii, iv, or v.  Then press "g" to go to that planet.

PLANET INFO-Beta Antares IV is an inhabited planet, which had contact with the Federation in the 23rd century.
James T. Kirk stated this planet was the origin of fizzbin, a card game with absurdly complicated rules, which he invented while being trapped on Sigma Iotia II. Spock was familiar with the culture of Beta Antares IV and started to explain that there was no such game there, but was stopped short by Captain Kirk. (TOS: "A Piece of the Action") 


Credits for helping me get started, texture creations, addon creators, and
special models. 
  
Ast9.jpg--John M. Dollan
asteroid7.jpg--*
bajor7.jpg--jestr
bluemoongaseous.jpg--gradius_fanatic
bp63q1.jpg--jestr
ceres.jpg--John M. Dollan
Cunhatai.jpg--kikinho
dactyl.jpg--jestr
eros2.jpg--Celestia
errimar.jpg--jestr
gaspra.jpg--jestr
gc_moons_02.jpg--*
golevka.jpg--jestr
Guaraciaba.jpg--kikinho
ida.jpg-Celestia
juno.jpg--jestr
ky26.jpg--jestr
moon1011.jpg--*
naarm.jpg--gradius_fanatic
pallas.jpg--jestr
Pholus.jpg--John M. Dollan
Potira-rings.png--kikinho
repsilon.jpg--jestr
Sakura.jpg--kikinho
ThebesDiffuse.jpg--AVBursch
tim31.jpg--Tim
toutatis.jpg--jestr
vesta.jpg--jestr
Vinayerni.jpg--*

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.

   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
