Credits:
Designed by: Asylum
Model and textyres: Asylum

Permission policy:
Contact Asyulm before using this in your mod
Kitbashing is ok, so long as Asylum is credited
Asylum is also known as: MARKYD or MARK DAVIES
Personal use or signatures/images do not require permission or credits.

The TNG Constitution is set to the era of the New Orleans, Freedmon, and the other wolf359 ships. It has 2x fwd and 2x rear torpedo, and 11 phaserbanks (15 phaser propeties due to the saucer banks being split into 3 zones each). The ship has good speed and decent manuverability, and moderate overall stength. I gave it a spread of 6 torpedo both fwd and aft. A separate reelase will upgrade the ship to dominion war stats.
