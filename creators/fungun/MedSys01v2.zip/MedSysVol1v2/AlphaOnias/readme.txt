All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory. 

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Alpha Onias" -press "g" and you're on your way there.

PLANET INFO-Alpha Onias III was a Class M planet located in the Alpha Onias system near the Romulan Neutral Zone. Barash, a humanoid child, was hidden in a cavern by his mother after their homeworld was attacked in the mid-24th century. The cavern was equipped with neural scanners that were able to transform matter into any form imagined, so that Barash could live in safety. (TNG: "Future Imperfect")

Credits for texture creations, addon creators, and
special models. 
  
AlphasBristol.jpg--Milosz21 / John M. Dollan j.dollan@bresnan.net
Chinook2.jpg, Clarke.jpg--John M. Dollan j.dollan@bresnan.net

Copacabana3.jpg--kikinho
eros2GeogrAlepha.jpg, idaJuno.jpg--jestr 

KamuiDs3z.jpg--kikinho / Anders Sandberg
NightgemBeniDs3.jpg--John M. Dollan j.dollan@bresnan.net / kikinho / Anders Sandberg
olyxbcc.jpg--Tleilax
PolyphOlyxal.jpg--John M. Dollan j.dollan@bresnan.net / Tleilax
Umeridigra2.jpg--kikinho
World9Orpheus.jpg--John M. Dollan j.dollan@bresnan.net / Milosz21
etacar_c-moon_iii-clouds.png-- *
jotunheim-rings.png--Rob Sanders

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
