All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.4.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Badstar" -press "g" and you're on your way there.
Yes kinda weird, but, if I made into a dsc object (nebula) it shows up transparent. So I put in a star for it to orbit. Now it shows up solid.

INFO-The "Badlands", located in Sector 04-70, was a region of space along the border between the United Federation of Planets and the Cardassian Union, that are known for intense plasma storms and gravitational anomalies. For that reason, it was commonly avoided by most interstellar traffic. (DS9: "The Maquis, Part I") 

During the Cardassian occupation of Bajor, the Bajoran Resistance frequently used the Badlands as a refuge from Cardassian patrols. Because of the severely limited sensor ranges in the area, the Bajorans used echolocation techniques to navigate and detect other ships. (DS9: "Starship Down") 

Because of its strategic location inside the Demilitarized Zone between Cardassian and Federation space, the Badlands became a favorite hiding place and staging area for the Maquis during their insurrection against Cardassian control from 2370 to 2373. 

In their first major operations, the Maquis took the kidnapped Gul Dukat to a class M asteroid in the Badlands. (DS9: "The Maquis, Part I") When Thomas Riker and a Maquis cell hijacked the USS Defiant from Deep Space 9 in 2371, they piloted the Defiant to the Badlands to rendezvous with other Maquis attack ships prior to launching an assault on Cardassian space. (DS9: "Defiant") 

 
The Cardassian warship Vetar in the BadlandsAround stardate 48300, the Caretaker abducted several starships from the Badlands, including a Maquis raider piloted by Chakotay, and the Federation starship USS Voyager, which had been sent to track Chakotay. (VOY: "Caretaker") A Cardassian Galor-class warship was also abducted from the Badlands around the same time. (VOY: "The Voyager Conspiracy") 

It was never made clear, but the USS Equinox may have also been abducted from the Badlands. (VOY: "Equinox") 
Bajoran trader Razka Karn also hid out in the Badlands when the Tholians were pursuing him for some unscrupulous "business" practices. (DS9: "Indiscretion") Kasidy Yates's freighter route between Bajor and Dreon VII often took her close to the Badlands, as well. (DS9: "For the Cause") 

In the mirror universe, the Badlands were also used as a staging area by the Terran Rebellion before their capture of Terok Nor in 2372. (DS9: "Through the Looking Glass") 

After the Maquis learned that he had informed Starfleet of Michael Eddington's location, Cing'ta was marooned on a "particularly nasty" planet in the Badlands. (DS9: "For the Uniform") 

 
A map of the BadlandsWhen the Cardassian Union was annexed by the Dominion in 2373, (DS9: "By Inferno's Light") the remaining Maquis cells that managed to escape the Jem'Hadar took shelter on Athos IV, an abandoned mining colony on the edge of the Badlands. The Maquis sent a disguised distress signal, coded as a confirmation of the launch of a missile strike against Cardassia Prime, to send word to Michael Eddington that the Maquis remnant had survived. Those few survivors were rescued by Starfleet a short time later. (DS9: "Blaze of Glory") 

The Badlands remained a strategic location during the Dominion War from 2373 to 2375. Fleet movements in the region required additional escorts to guard against ambushes from inside the plasma storms. (DS9: "Waltz") In 2375, the IKS Koraga was destroyed by the Jem'Hadar near the edge of the Badlands. (DS9: "Penumbra") 

Retrieved from "http://memory-alpha.org/en/wiki/Badlands"



Credits for helping me get started, texture creations, addon creators, and
special models. 
  
   
3d duckboy productions
3d.concept40.com
John M. Dollan
Don Edwards
Andy Roberts
Steve Bowers
Ivo Beckers
http://galaxistar.googlepages.com
Matt Davis
Selden Ball
Runar Thorvaldsen
Rob Sanders
Cham (from Celestia forum) 
 jestr (Celestia forum)
Pericapolis
Fridger Schrempp
pioneerxtower (J. P.)
Bruckner
Shcuf
Jean-Marie le Cosp�rec
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
