Model:			Nova Class Federation Light Cruiser 
Modeller:		Mesh : Redragon	
			(Slight mesh modifications by Cleeve)
                        Textures: Handmade by Cleeve (www.staryards.com)

This great model was created by Redragon (Luan Ngo).

I (Cleeve) wanted a Nova for SFC3 and Redragon's was cleary the best
available, although I thought the textures could use an update, so I
remade them by hand.
The SFC3 engine also had soem problems with the model so I had to make
some modifiecations, and while I was at it I added a more accurate
bridge dome.

Have fun!

- Cleeve
www.staryards.com




*********************************************
Copyright and Distribution Permissions 
-------------------------------------- 
THIS PATCH IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY INTERPLAY TM & (C) INTERPLAY & TALDREN & PARAMOUNT PICTURES. 

Copyright notices: 

Star Trek, Star Fleet Command, Star Trek: Deep Space Nine, Star Trek: The Next Generation, Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures, as are the  characters, related images, and sound from the productions. 

LEGAL STUFF: This file is not supported or affiliated with Interplay Productions. While most who have used these files have had no problems, we will not be held accountable for any damage done to your computer by use of these files or techniques. USE AT YOUR OWN RISK! This file is freeware. It is not to be sold. 

Copyrights 
User-created missions contain source-code that is the property of Interplay Productions and Quicksilver Software. In addition, Star Trek is a property of Paramount Pictures. Star Fleet Battles is the property of ADB, Inc. You may not sell user-created missions commercially. You should respect the rights of the property owners. Missions created based on Star Fleet Battles material must be marked "Based on copyrighted material by ADB, Inc."in the documentation or mission briefing. ADB also requests that these missions not be placed on "out of network" SFB web-sites. 

SOFTWARE USE LIMITATIONS AND LIMITED LICENSE 
Any Star Trek: Starfleet Command mission (each, a "Mission", and collectively, "Missions") created using the Star Trek: Starfleet Command Mission API ("SFC Mission API") is intended solely for your personal, noncommercial home entertainment use. You may not decompile, reverse engineer, or disassemble SFC Mission API or any Mission, except as permitted by law. Interplay Entertainment Corp. ("Interplay") retains all rights and title in SFC Mission API and the Missions including all intellectual property rights embodied therein and derivatives thereof. SFC Mission API and the Missions, including, without limitation, all code, data structures, characters, images, sounds, text, screens, game play, derivative works and all other elements may not be copied (except as provided below), sold, rented, leased, distributed (except as provided below), used on pay-per-play, coin-op or other for-charge basis, or for commercial purpose. You may make copies of SFC Mission API and any Mission for your personal, noncommercial  home entertainment use and to give to friends and acquaintances on a no cost, noncommercial basis. This limited right to copy or provide public access to the SFC Mission API and the Missions expressly excludes any copying, access or distribution of SFC Mission API and the Missions on a commercial basis, including, without limitation, bundling SFC Mission API or any Mission with any other product or service, selling SFC Mission API or any Mission, and any giveaway in connection with another product or service. Any permissions granted herein are provided on a temporary basis and can be withdrawn by Interplay at any time. All rights not expressly granted herein are reserved. No technical support from either Interplay or Quicksilver Software, Inc. ("Quicksilver") shall be available  for SFC Mission API or any Mission. 

INTERPLAY AND QUICKSILVER DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, RELATING TO SFC MISSION API AND THE MISSIONS (INCLUDING WITHOUT LIMITATION, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT), AND NEITHER INTERPLAY NOR QUICKSILVER SHALL HAVE ANY RESPONSIBILITY OR LIABILITY REGARDING SFC MISSION API AND THE MISSIONS, INCLUDING, WITHOUT LIMITATION, ANY RESPONSIBILITY OR LIABILITY REGARDING USE OR OPERABILITY OF SFC MISSION API AND THE MISSIONS. YOU ASSUME ALL RISK OF LOSS IN CHOOSING TO USE SFC MISSION API AND THE MISSIONS. 

SFC Mission API and all Missions � 1999 Interplay Entertainment Corp. SFC Mission API and Star Trek: Starfleet  Command are trademarks of Interplay Entertainment Corp. All Rights Reserved. 

========================== Original Credits ==========================
Nova Class - 25th of July, 2001
3DS
------------------------------------------
Well, not really that much to know about this one 
except that the textures are from the actual CGI model 
from Voyager.
_____________________________________________________

 
_____________________________________________________
Redragon (Luan Ngo)
Star Trek: Homeworld Team
luan_ngo543@hotmail.com
Textures are from renders of the actual CGI model.
========================== Original Credits ==========================
