All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Eta Sco" -press "g" and you're on your way there.

PLANET INFO-Ivor Prime is a planet located in Federation space, and was the site of a Federation colony. It orbited the star Eta Scorpii. (ST reference: Star Trek: Star Charts) 
In 2373, the colony was destroyed by a Borg cube as it traveled on a direct course for Earth. (TNG movie: Star Trek: First Contact) 

Deep Space 5 was a Federation space station in the late 24th century which was responsible for new starship developments.
In an alternate reality visited by Worf in 2370, Deep Space 5 was the object of covert surveillance by the Cardassians along with Starbase 47, the Iadara colony and the Utopia Planitia Fleet Yards. (TNG: "Parallels") 
Deep Space 5 is located near Ivor Prime. In 2373, the station reported the destruction of the colony there by the Borg. (Star Trek: First Contact) 



Credits for helping me get started, texture creations, addon creators, and
special models.

Hopi.jpg--John M. Dollan
900a.jpg--Earth 8k (mod,Tim)
 
  
   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
