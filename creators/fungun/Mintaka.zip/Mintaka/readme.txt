All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Mintaka" -press "g" and you're on your way there.

PLANET INFO-Mintaka III is the third planet in the Mintaka system, home to a proto-Vulcan humanoid species known as the Mintakans. 
By 2366 the Federation had been covertly observing the Mintakans on the planet for several years. That year the existence of the anthropological team recording their behavior was exposed to the Mintakans when the generator powering their duck blind malfunctioned. As a result the team suffered several injuries and two fatalities, and during the course of their retrieval by the USS Enterprise the cultural contamination was worsened when several Mintakans witnessed the Federation's use of their advanced technology. (TNG: "Who Watches The Watchers") 


Credits for texture creations, addon creators, and
special models.

2vega10d.jpg--Fugazi
alephanite.jpg--jestr
dandimaclouds2.png--gradius_fanatic
Denirona-clouds.png--jestr
forseti.jpg--Rob Sanders
gaspra.jpg,ida.jpg,golevka.jpg,dactyl.jpg,juno.jpg,ky26.jpg,vesta.jpg,Mintaka II small moons--jestr
Leonidas.jpg--Milosz21 
remus.png--jestr
Ring3.png--Anders Sandberg
tartaros.jpg--Rob Sanders
vega6clouds.png--Fugazi
  
   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
