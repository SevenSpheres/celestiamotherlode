****KLINGON IMPERIAL STARBASE "LEGACY VERSION"******
****This will replace the original Klingon Imperial Star Base***

original ReadMe (NOVEMBER 2002)


Klingon Imperial StarBase
Starbase meshs by Longisland26.  textures from ST:ARMADA2.

***HIGH RES ONLY***

MODEL,TEXTURE AND HARDPOINT FILES ALTERED BY LONGISLAND26


 
ANY FEEDBACK WELCOME.


LONGISLAND26
(COOLGUYLI25@AOL.COM)


  
***CHANGES (March 2008)***

I ported My original Klingon Starbase for use in the Ultimate Universe Mod. The Textures have been completely replaced
and some minor Model changes were done.. I have now Re-Ported the base back into BC with the changes....

Starbase mesh by coolguyli27... Textures By Coolguyli27 and Bethesda Softworks

I would like to say thanks to all the amazing modders who have kept BC alive over the years...

Thanks to the K.M. team for including my stuff in there mod...

Thanks to the modders in the legacy Community ,who with there work, revived my interest in Modding...

You can check out my legacy work at LegacyFiles.com

Most of my stuff is also included in the Ultimate Universe Mod (http://www.ultimateuniversemod.net)

Please ask before Redistributing this mod in its original or altered state.


Feed back always welcome

Coolguy  (AKA LONGISLAND26)
(COOLGUYLI25@AOL.COM)

