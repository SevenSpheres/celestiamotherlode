
Version		: 1.0
Author		: Rick Knox a.k.a pneumonic81
Email		: rknox@maddocsoftware.com
URL		: http://www.apocent.com, http://www.apocent.com/www/dominion

Credits	
-------------	
model design	: paramount
textures	: rick knox
mesh		: rick knox
Build time	: 5 days

Thanks to	: The BC community




Description of the Modification
-------------------------------

an original model created in studio max and converted using SDK plugin




Copyright and Distribution Permissions
--------------------------------------
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
 TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices: 

Star Trek, Bridge Commander, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions. 

Please do not modify this file or the included texture with out seeking the authors permission.
it is just polite.

