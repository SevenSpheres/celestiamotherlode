Klingon Attack Ship

**** This mesh is for kli_a.zip ****

Author : A. "Spy" Ehlers
Mail : arehlers@optonline.net
Web Site : None

This mesh can be used to render artwork that will be published on your
personal homepage, or on the Scifi-Art Forums, as long as you give me
credit.  It is not to be used in commercial projects without my express
permission. You can not repost it on another web site without my express
permission.

Now that's over with have fun!

This Mesh is hosted by Sci-Fi Art
http://www.scifi-art.com
