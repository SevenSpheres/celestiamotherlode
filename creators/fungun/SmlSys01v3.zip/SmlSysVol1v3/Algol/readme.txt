All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Algol" -press "g" and you're on your way there.

INFO-Algol
Episode: TNG 101 - Encounter at Farpoint, Part I
The primary to the Algolian homeworld, a B-class star, is also known as Beta Persei in the old Terran Bayer classification system. 

Algolians- Episode: TNG 172 - M�nage � Troi
Origin: Algol System. A humanoid race which is distinguished physically by golden leathery skin with numerous small circular openings about the head, especially on their wide-set nostrils and atop their fluted head ridge similar to Klingons and Bolians. A native plays the culture's famed ceremonial rhythms for the reception ending the biannual trade conference at Betazed. Another native is among the delegates to the Federation Archaeological Council's annual symposium at Tagus III. Some Algolians have more muted head ridges, as seen among those on the Bajoran Space Station and Deep Space Nine, on stardates 46423.7 and 46844.3. 

Credits for texture creations, addon creators, and
special models. 
  
algol1.jpg--kikinho/gradius_fanatic
ky26moony4.jpg--jestr/Matthew (Ares) C. Johnson
shadoga2a.jpg-- */mod Tim

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.  


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
