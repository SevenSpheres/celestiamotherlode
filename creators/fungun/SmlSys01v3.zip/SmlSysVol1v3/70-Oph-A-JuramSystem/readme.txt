All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.4.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "70 Oph A" -press "g" and you're on your way there.

PLANET INFO-Miri's homeworld (Juram V) was so known because it was the home of Miri, one of the Onlies, who resided there.
This unnamed planet was a prime example of Hodgkin's Law of Parallel Planetary Development, as it appeared to be an exact duplicate of the planet Earth in composition, but the Human population died of a bacteriological experiment gone awry during the 20th century. 
The planet was discovered by the USS Enterprise in 2266, where it was discovered that most of the planet's population  all but a small group of children  had been annihilated by a virus that had been accidentally created by life prolongation experiments conducted on the planet some centuries before. (TOS: "Miri") 


Special Credit-The Earth texture for Juram V is/was included with Celestia 1.4.1.  Sorry, but I do not know who the original author is.

Credits for texture creations, addon creators, and
special models. 

Earth4k.jpg, Earth Night.jpg--John van Vliet
eros2Isik.jpg--jestr / John M. Dollan j.dollan@bresnan.net
GarmBristol.jpg--John M. Dollan j.dollan@bresnan.net 
julinisse_planet_iv-moon_ii-clouds.png--Rassilon
KenUnai.jpg--kikinho
moon.jpg--Celestia
portunaSnooze.jpg--Gradius_fanatic / Milosz21
   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
