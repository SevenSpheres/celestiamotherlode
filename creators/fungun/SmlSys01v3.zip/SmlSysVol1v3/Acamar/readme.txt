All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.4.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Acamar" -press "g" and you're on your way there.

PLANET INFO-Acamar III was the third planet in the Acamar system and homeworld of the Acamarian species. 
In 2366, it was ruled by Marouk, the Sovereign of Acamar III, as well as a planetary council. (TNG: "The Vengeance Factor")
Retrieved from "http://memory-alpha.org/en/wiki/Acamar_III"


Credits for texture creations, addon creators, and
special models. 
  
Alba1.jpg, nr2.jpg--John M. Dollan j.dollan@bresnan.net
Ast1.jpg--*
th_11embla.jpg--Runar Thorvaldsen
Vaporius.jpg--Milosz21

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
