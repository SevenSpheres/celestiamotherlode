All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "TAU Cet" -press "g" and you're on your way there.

PLANET INFO-Kaferia is the third planet in the Tau Ceti system, in Sector 004. It is home to the Kaferian insectoid civilization. (ST reference: The Worlds of the Federation) 
Humans had known of Kaferia prior to 2151. One of its more notable exports is the Kaferian apple, which would be considered a delicacy across the Alpha Quadrant in the 23rd century. (TOS episode: "Where No Man Has Gone Before"; ENT episode: "Strange New World"; ST reference: The Worlds of the Federation) 
By the 2160s, Kaferia was on Vulcan trade routes. (ST reference: Star Charts) 
Based on the sector map, Kaferia was likely one of the early Federation Members, although (The Worlds of the Federation) mentions that it is an ally, rather than a member. 
In the mid-24th century, Jean-Luc Picard and Walker Keel first met in an exotic bar located on the planet. (TNG episode: "Conspiracy") 

Tau Ceti IV is the fourth planet in the Tau Ceti system. 
During the 23rd century, the Tau Ceti city of Amber was the homeport of the 3rd class neutronic fuel carrier Kobayashi Maru, and her master Kojiro Vance. (Star Trek II: The Wrath of Khan) 



Credits for texture creations, addon creators, and
special models. 

GasGiantRed.jpg--Matthew Attard(maynot be used in other addons without permission. I had to get special permission to use them!)

2b.jpg--Runar Thorvaldsen/mod-Tim
argia.jpg--Shcuf (ALARAPH addon)
bauci.jpg--Shcuf (ALARAPH addon)
ninurtaclouds.png--Rob Sanders
Shinji.jpg--kikinho
valdrada2.jpg--Shcuf
vega10g.jpg--fugazi  
   

   

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
