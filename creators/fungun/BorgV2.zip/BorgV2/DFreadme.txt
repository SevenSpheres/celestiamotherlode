tYPE 6,9,11 DELTAFLYER

AUTHOR:Darkdrone
Mesh:ELITEFORCES2
Textures:ELITEFORCES2
Port: Darkdrone
Format :sfc.mod
Ui`s : Darkdrone
glows: Darkdrone


tYPE 6

AUTHOR:Darkdrone
Mesh:bridge commander
Textures:bridge commander
Port: Darkdrone
Format :sfc.mod
Ui`s : Darkdrone
glows: Darkdrone

Hornet fighter

AUTHOR:Darkdrone
Mesh:Taldren software
Textures:Taldren software
Port: Darkdrone
Format :sfc.mod
Ui`s : Darkdrone
glows: Darkdrone

Runabout
AUTHOR:Redragon
Mesh:Redragon
Textures:Redragon
Port: Darkdrone
Format :sfc.mod
Ui`s : Darkdrone
glows: Darkdrone




TO BE USED IN YOUR PERSONAL Use, NOT FOR COMMERCIAL USE

All other trademarks and copyrights are the property of their respective owners.

see sfc3files.com for they install faq