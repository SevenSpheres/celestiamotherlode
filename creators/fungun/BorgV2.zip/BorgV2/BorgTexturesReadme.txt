STAR TREK UNIVERSE by Star Lion
http://www.starlionfiles.50megs.com or on the Celestia Motherlode:
http://celestiamotherlode.net/catalog/fic_startrek.html

This zip file contains files originally created by StarLion and updated for Celestia 
version 1.3.2 by Jeam Tag.




Original Readme, for Celestia before 1.3.1 version:

This is beta 1 of Star Lion's Star-Trek Universe!
Just put the bmp, png, and jpg files into the medres folder.
Put all the 3ds files into the models folder.
put all of the scc files go into the extras folder.
And put the favorites.cel file in the main celestia folder.


Star Lion
