All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.4.1, 1.5.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Alf Cae" -press "g" and you're on your way there.

SYSTEM INFO-The L-374 system is a star system near the L-370 system. The system was attacked by the Doomsday machine in 2267. It had four rocky planets that were observed prior to the attack; the two outer planets were consumed as fuel by the machine before it could be destroyed by the starships USS Enterprise and USS Constellation. (TOS: "The Doomsday Machine")

L-374 I is a planet in the L-374 system, which lost two planets in the planet killer attack of 2267. 
When the crew of the badly damaged USS Constellation was unaccounted for after the planet killer's attack, Spock considered it improbable that the ship's crew had fled to L-374 I as this planet has a surface temperature of molten lead (approximately 327 �C). (TOS: "The Doomsday Machine")

L-374 II is a planet in the L-374 system, which lost two planets in the planet killer attack of 2267. 
When the crew of the badly-damaged USS Constellation was unaccounted for after the planet killer's attack, Spock considered it improbable that the ship's crew had fled to L-374 II as this planet has an atmosphere poisonous to Humans. (TOS: "The Doomsday Machine")

The M-class world L-374 III was the third planet in the L-374 system. 
In 2267, the entire crew of the Federation starship USS Constellation, consisting of 400 men and women, was beamed down to this planet for safety against the doomsday machine which was attacking the Constellation with her Captain, Commodore Matt Decker still aboard the starship trying to outrun the machine. When the Constellation was disabled, the Doomsday machine turned onto L-374 III. Severely damaged and with transporters offline, there was nothing Decker could do to save his helpless crew. 
As a result, the doomsday machine destroyed the third planet and blasted it to rubble and debris, and Decker's entire crew was killed. (TOS: "The Doomsday Machine")

The M-class world L-374 IV was the fourth planet in the L-374 system. 
In 2267, Science Officer Masada of the USS Constellation picked up scans that the planet was being broken up by what was later known as the "Doomsday machine". The captain of the Constellation, Commodore Matt Decker, ordered his crew to attack and destroy the machine. Despite their efforts, the doomsday machine destroyed the entire planet. All the inhabitants of the planet were killed. (TOS: "The Doomsday Machine")




Credits for helping me get started, texture creations, addon creators, and
special models. 
  
   
3d duckboy productions
3d.concept40.com
John M. Dollan
Don Edwards
Andy Roberts
Steve Bowers
Ivo Beckers
http://galaxistar.googlepages.com
Matt Davis
Selden Ball
Runar Thorvaldsen
Rob Sanders
Cham (from Celestia forum) 
 jestr (Celestia forum)
Pericapolis
Fridger Schrempp
pioneerxtower (J. P.)
Bruckner
Shcuf
Jean-Marie le Cosp�rec
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
