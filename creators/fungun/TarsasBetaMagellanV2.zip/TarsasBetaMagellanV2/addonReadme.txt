All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Xi Peg" -press "Enter"-press "g" and you're on your way to the Beta Magellan system OR press "Enter"-type in  "Iot Psc" press "Enter"-press "g" and you're on your way to the Tarsas system.


PLANET INFO- 1. The Beta Magellan system (also known as the Bynar system) was an inhabited star system in Federation space. The system was located near the Tarsas system. Though the system had multiple stars, the exact number are unknown. 
In 2364, after a star supernovaed in the system, the Bynar-hijacked USS Enterprise-D entered into orbit around the planet Bynaus with a complete copy of the database of the planet's main computer core. With a successful download of the duplicate database, the Bynars were averted from an extinction event. (TNG: "11001001") 

2. The Tarsas system was an inhabited star system located in Federation space. One of the closest systems to this system was the Beta Magellan system. In the 24th century, Starfleet built Starbase 74 in orbit of Tarsas III. 
The USS Enterprise-D was refitted at Starbase 74 in 2364 with minor computer upgrades to patch computer systems which had proved problematical in the past, such as the holodeck. (TNG: "11001001") 



Credits for texture creations, addon creators, and
special models.

OTS44BetaDiffuse.jpg--AVBursch
Coronus.jpg--John M. Dollan
tarsas3b.jpg---Tim Wilson
Marstons.jpg--John M. Dollan
slushy.jpg--gradius_fanatic
Supai.jpg--John M. Dollan
errai_iii-clouds2.png--*
Pacifica-clouds.png--Don Edwards
 
* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.  
   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
