All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.4.1.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "61 Uma" -press "g" and you're on your way there.

PLANET INFO-Archer IV is an M-class planet located relatively close to the Sol system in the Archer system. Named for Earth Starfleet Captain Jonathan Archer, the planet was the first M-Class, Earth-like world surveyed by the crew of the starship Enterprise in 2151.
Boasting a fertile landscape dominated by vast grasslands and snow-topped mountains, Archer IV was inhabited by a wide array of animal life, including nocturnal marsupials, scorpion-like arachnids, self-illuminating insects, and fish. The planet, however, supported no indigenous intelligent lifeforms upon its discovery. 
Initial landing parties in 2151 experienced rapidly changing weather patterns and fast-moving storms. Such inclement weather spread toxic pollen, released by the diverse fauna and flora, causing in Human and Vulcan visitors paranoia and decreased cognitive function. With no refuge from the effects of the pollen, the planet was considered to be uninhabitable. (ENT: "Strange New World", "Home")
Archer IV remained uninhabitable throughout the 22nd century. In the early 2200s, however, an antidote for the pollen was discovered. By 2267, more than seven hundred million people populated the planet. (ENT: "In a Mirror, Darkly, Part II" production art) 
In 2366, Archer IV was the destination of the Federation starship USS Enterprise-D following an investigation of a nearby radiation anomaly. (TNG: "Yesterday's Enterprise") 
In an alternate timeline, Archer IV was the site of a battle in the Second Federation-Klingon War. The Enterprise-D engaged a series of Klingon warships, the Enterprise emerging the victor. (TNG: "Yesterday's Enterprise") 
The Star Trek: Enterprise fourth season episode "In a Mirror, Darkly, Part II" revealed the connection between "Strange New World" and "Yesterday's Enterprise" through text in Jonathan Archer's personnel file. The original production artwork can be viewed at MikeSussman.net and places the Archer system at 61 Ursae Majoris.

Credits for helping me get started, texture creations, addon creators, and
special models. 
  
   
3d duckboy productions
3d.concept40.com
John M. Dollan
Don Edwards
Andy Roberts
Steve Bowers
Ivo Beckers
http://galaxistar.googlepages.com
Matt Davis
Selden Ball
Runar Thorvaldsen
Rob Sanders
Cham (from Celestia forum) 
 jestr (Celestia forum)
Pericapolis
Fridger Schrempp
pioneerxtower (J. P.)
Bruckner
Shcuf
Jean-Marie le Cosp�rec
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
