
COPYRIGHT
------------------------------------------

This package is released to you "as is", under a non-commercial share-and-share-alike Creative Commons licence.

You can see this licence in its entirety here:
http://creativecommons.org/licenses/by-nc-sa/3.0/

... What it means in practice, is that you are free to:
- Use and re-distribute this work for any non-commercial purpose
- Modify it, or any part of it, and re-distribute the result, provided that:
1) you do not charge money for it in ANY way
2) you distribute it under the SAME licence as this one, with the same provisions and permissions.

Some rights reserved. Copyright belongs to:
- Runar Thorvaldsen

- A few image files (the ra_ and ra_th_ prefixed ones) are
based on work by Rassilon (of the Celestia community).
Copyright of these  are by Rassilon and Runar Thorvaldsen,
2004 and 2007.

- A few image and CMOD files (the ec_ prefixed ones) are copyright
by Christophe Campos, 2006-2007.
They come from the Asteroid Repository at shatters.net.

- A few image and CMOD files (the ch_prefixed ones) are copyright
by Martin Charest.



CREDITS
------------------------------------------

A lot of people has helped bringing Ran III to completion. Thanks are due to:

- Christophe Campos, for creating the Hroenn planet model, and for use of the Asteroid Repository
- Martin Charest, for his wonderful solar chromosphere model, and for contributions to the Rootax skybox
- Frank Gregorio, for his serious work on the Encyclopaedia
- Rassilon, for the Mythica (Rootax) collaboration
- Ulrich Dickmann and Harald Schmidt for CELX code i have used in the many scripts


Runar Thorvaldsen, march 8. 2008.

Contact:
rthorvald@celestialmatters.org
www.celestialmatters.org





