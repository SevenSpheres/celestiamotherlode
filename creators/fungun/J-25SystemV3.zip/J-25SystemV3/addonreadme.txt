All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out. 

Start Celestia-press "Enter"-type in  "J 25" -press "g" and you're on your way there.

PLANET INFO-System J-25 was a star system with at least one M-class planet, located 7,000 light years from Federation space in the Beta Quadrant. 

The Federation starship USS Enterprise-D was transported to this system by Q in 2365. Scans revealed evidence of a previous advanced civilization on the planet, but also massive surface scarring notably similar to that detected on several Federation and Romulan outposts along the Romulan Neutral Zone in 2364, which had removed all machine elements on the planet. Shortly after the Enterprise made first contact with a Borg cube in the outskirts of the system, which was likely responsible for the destruction on the surface. (TNG: "Q Who") 

Guinan was familiar with the area of space in which System J-25 was located. 



CREDITS for texture creations, addon creators, and
special models.

Thanks to Seldon, for showing me how to figure out orbit frames. It made the double rings possible. 
  
Baalen.jpg, Orson.jpg, WelkeWuestenrose.jpg--John M Dollan j.dollan@bresnan.net

bacchus2.jpg, bacchus.jpg, castalia.jpg, eros2.jpg, gaspra.jpg, ida.jpg, juno.jpg, mathilde.jpg, toutatis.jpg, vesta.jpg--jestr
   
darknet.jpg, dandimaclouds.png--gradius_fanatic 
  
errai_b.jpg--*

Guanabara.jpg, Beni.png--kikinho

MoemaGeographos.jpg, SuzukiJuno.jpg--kikinho/jestr (mod Tim)

Rerinmisna2.jpg--*
tartaros.jpg--Rob Sanders
Eye_of_God_Nebula2.png--PapusMan
SamothraceDiffuse.png--AVBursch
shinehah_planet_v-clouds.png--Rassilon

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
