Federation StarFleet Starbase 201 v1.0
-----------------
Special Requirements : None
Created Using : 3DsMax 3.1

Original base : Starbase 201

Created by Steven Davis
"Credit where credits due." 
You can use the Mesh for images with the condition you give credit to it's creator.
Terms of Use -
By creating and displaying images with this model in any shape or form, you agree to place credit to the meshes' author along with the mesh image itself. This is the only real request i ask of you for using my public domain work. Thankyou in advance. :)

Showcased and displayed exclusively first by MCGI (Millennium Computer Generated Images) at
http://mcgi.tripod.com
and at the creators studio at
http://stes3dreload.tripod.com

Created for "Star Trek Paris2" - Fanfiction at
http://members.tripod.co.uk/paris2

Rivers3D
stesplace@hotmail.com
