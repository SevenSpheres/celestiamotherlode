All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Merak" -press "g" and you're on your way there.

PLANET INFO-Merak II was a planet in Federation space, in the Merak system. 
In 2269 the planet experienced a bacterial botanical plague. The plague was treated with a toxic ore, known as zenite, which was aquired by the USS Enterprise. (TOS: "The Cloud Minders") 
In 2370, Quark claimed that Elim Garak had a sizing scanner from Merak II. (DS9: "The Wire")


Credits for texture creations, addon creators, and
special models. 
  
Aita.jpg--John M Dollan
p1_dif.jpg--*
Poti2.jpg--kikinho
Bradbury-clouds.png--Michael Kilderry
seraphiusclouds.png--GalaxiStar universe   

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
