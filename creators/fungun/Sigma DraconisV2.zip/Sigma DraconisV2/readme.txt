All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Sig Dra" -press "g" and you're on your way there.

PLANET INFO-Sigma Draconis III is the third planet in the Sigma Draconis system. It is a moonless M-class planet, larger and more heavily populated than Sigma Draconis IV. By 2268, the planet's inhabitants had a pre-spaceflight culture with an Industrial Scale rating of B, which was equivalent to Earth in 1485, and a technological rating of 3. (TOS: "Spock's Brain")

Sigma Draconis IV is the fouth planet in the Sigma Draconis system. It is an inhabited M-class planet with two moons. By 2268, the inhabitants were a pre-spaceflight culture with an Industrial Scale rating of G, equivalent to Earth in 2030. (TOS: "Spock's Brain") 

Sigma Draconis VI is the sixth planet in the Sigma Draconis system, and one of the system's three M-class planet. The planet was several thousand years into a glacial age, with a maximum high temperature of 40� F. Only a small tropic zone existed on the planet that remained ice-free. 
Sentient life was plentiful on the planet, but on a most primitive level. According to probes, the planet had no signs of industrial development or organized civilization. The planet's primitive humanoids were picked up at irregular intervals. 
Overall, however, Sigma Draconis VI was a remarkable example of a retrograde civilization. At the peak, it was advanced beyond 23rd century Federation capabilities, but had de-evolved to primitive level, beginning 10,000 years ago when a glacial age reoccurred. An underground complex was developed for the women, while the men remained above, causing a male-female schism. This ultimately caused a cultural development which was last seen on old Earth when the Romans were warring with barbarians. 
In 2268, the USS Enterprise visited the Sigma Draconis in search of Spock's brain. Once reaching the system, Uhura detected high energy generation on the planet. 
Kirk took a gamble and beamed down to the planet's surface. Almost immediately they encountered five male humanoid natives, known as Morgs. 
The foundations for a dead and buried city were later found near a elevator built into a cave. Several hundred meters below the surface, they discovered a highly complex civilization built around the high energy generation source, based on ion power. 
This civilization was discovered to be the home to what the Morgs referred to as the "givers of pain and delight," otherwise known as the Eymorgs. 
The civilization, itself, was controlled by the Controller, which was responsible for keeping the Eymorgs alive for a period of 10,000 years, and for whom the Eymorgs lived to serve. 
Following the disconnection of the Controller (which was "powered" by Spock's brain), by the crew of the Enterprise, the Morgs and Eymorgs were force to live together once again, in a forced attempt to re-establish a civilization. (TOS: "Spock's Brain")


Credits for texture creations, addon creators, and
special models. 
  
naarm.jpg, bluemoongaseous.jpg, smaan-moon.jpg--gradius_fanatic

Amale.jpg, DelNorte.jpg, Isik.jpg, Mnesimache.jpg, Nightgem.jpg, Tamar.jpg, Pima2.jpg--John M. Dollan  maastrichian@bresnan.net

bacchus2.jpg, gaspra.jpg, golevka.jpg, kleopatra.jpg, ky26.jpg, vesta.jpg, bajor2.jpg, 
newZ2.jpg, occula.jpg--jestr

baramalGulletta.jpg--*/jestr
corCaroliX.jpg--*

daniken.jpg, germaniarum.jpg, praetorium.jpg--Rob Sanders

gamma-theon.jpg--Devil Master devilmaster@email.com
laudomia.jpg--ALARAPH addon By Shcuf

olyxad.jpg, olyxas1.jpg--Tleilax

Pericapolis.jpg--Pericapolis
pl4.jpg--Joen_meloen
rigel8f.jpg--fugazi
Erebus.png--Milosz21
Ring2.png--Anders Sandberg, asa@nada.kth.se

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.
   

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
