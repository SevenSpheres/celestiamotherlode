All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "CHI1 Ori" -press "g" and you're on your way there.

PLANET INFO-Coridan is a M-class Federation planet in the Coridan system, homeworld of the Coridans. In 2151, it had a population of over 3 billion. It is rich in valuable resources, most significantly dilithium.
In the 2150s, Coridan was known for its extensive shipyards and its advanced warp-capable vessels. However, the planet was also embroiled in a conflict between rebel forces, supported by the Andorians, and the government, backed by the Vulcans. The Vulcan agenda was to keep the planet's chancellorship stable, which in turn assured its dilithium exports to Vulcan. (ENT: "Shadows of P'Jem") 
Coridan was one of the planets in the initial Coalition of Planets, preceding that of the United Federation of Planets. (ENT: "Demons")
Over the next century, Coridan would become under-populated to the point that it could not defend its dilithium mines.
In 2267, Coridan sought admission to the United Federation of Planets. However, due to the wealth of minerals available on Coridan and the presence of illegal mining operations, Coridan's admission was a controversial subject between Tellarites and Vulcans. The Babel Conference was convened to settle the matter and ultimately approved Coridan's admission. Ambassador Sarek of Vulcan was credited with achieving the consensus towards admitting the planet to the Federation. (TOS: "Journey to Babel"; TNG: "Sarek")
During the Dominion War, Coridan's dilithium mines came under attack by the Dominion in 2374 due to their strategic importance. Gelnon left Kudak'Etan in command of the USS Defiant while he and his ship left to launch an attack on Coridan. (DS9: "In the Cards", "One Little Ship") 

Credits for helping me get started, texture creations, addon creators, and
special models. 

cor2a.jpg--jestr,mod-Tim
Vinayerni2.jpg--*
Coridan3 textures and ctx files--jestr
vega3g.jpg--fugazi
nr2-clouds.png--John M Dollan

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provided broken links.  
   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
