TCMP for Bridge Commander
By Aaron "Phaser" Gendler


/-----CONTENTS-----/
This modification package for Star Trek: Bridge Commander contains the following ships, bases, and shuttles:

    * Constitution Class
          o U.S.S. Enterprise -- "The Cage" (1st pilot episode) Variant
          o U.S.S. Enterprise -- "Where No Man Has Gone Before" (2nd pilot episode) Variant
          o U.S.S. Enterprise -- Production Version
    * Daedalus Class
          o U.S.S. Daedalus
          o U.S.S. Essex
    * Saladin Class
          o U.S.S. Saladin
    * Ptolemy Class
          o U.S.S. Ptolemy
          o U.S.S. Ptolemy - With one Mk I/II/III Cargo Pod attached
          o U.S.S. Ptolemy - With two Mk I/II/III Cargo Pods attached
          o U.S.S. Ptolemy - With one Mk IV Cargo Pod (Personnel) attached
    * Mk I/II/III Cargo Pod
    * Two Mk I/II/III Cargo Pods (attached to each other)
    * Mk IV Cargo Pod (Personnel)
    * Deep Space Station K-7
    * Type 1 "Class F" Shuttlecraft
    * Klingon D-7 Class
          o TOS Studio Model Variant
          o Greg Jein TOS Variant
    * Script Files for the K'Tinga Classes included in Klingon D-Pack (optional install)

/-----REQUIRED* MODS-----/

    * MLeo's Submenu (3.7)
        http://bridgecommander.filefront.com/file/SubMenu;68668

    * Sneaker98's MVAM Infinite (2.0)
        http://bridgecommander.filefront.com/file/MVAM_Infinite;26555

    * Sleight42's Shuttle Launch Framework (V1.2)
        http://bridgecommander.filefront.com/file/Shuttle_Launch_Framework;39370

    * NanoByte's NanoFX (2.0 [BETA])
        http://bridgecommander.filefront.com/file/NanoFX;23469 (Recommended)

*The mod is playable without these, but the ships won't launch shuttles or have MVAM capabilities.

 

/-----WARNING-----/
If you have any of the following installed, this mod will OVERRIDE them:

    * Anduril's TOS Constitution Class USS Enterprise (1.1)
        http://bridgecommander.filefront.com/file/Andurils_TOS_Constitution_class_USS_Enterprise;5450

    * Anduril's Saladin Class
        http://bridgecommander.filefront.com/file/Andurils_Saladin_Class;5462

    * CMD's Daedalus Class
        http://bridgecommander.filefront.com/file/Daedalus_class;25336

    * CMD's Type I Shuttle
        http://bridgecommander.filefront.com/file/Type_1_Shuttle;43088

    * CMD's Space Station K-7 (1.0)
        http://bridgecommander.filefront.com/file/Space_Station_K7;43560

    * Zambie Zan's D-7 (Studio & Greg Jein) Class from the Klingon D-Pack
        http://bridgecommander.filefront.com/file/Klingon_DPack;40411

    * The following for the K'Tinga Class (TMP, TNG, Romulan, & Qonos One) from Zambie Zan's Klingon D-Pack:
        http://bridgecommander.filefront.com/file/Klingon_DPack;40411

          o scripts\Custom\ships files:
                D7Ktinga.py
                D7KtingaR.py
                D7KtingaTNG.py
                D7Qonos1.py
                D7StudioRom.py

          o scripts\ships files:
                D7Ktinga.py

          o scripts\ships\Hardpoints files:
                D7KtingaHP.py

Make sure to back up any customized files from these ships, unless you want them overridden.

 

/-----INSTALLATION-----/
1) Extract the files.
2) Run the exe file and follow the on-screen prompts.
3) Enjoy!

 

/-----GENERAL INFORMATION-----/
All files necessary to use this mod are included in this rar:
    * Models
    * Textures
    * Sound Effects
    * Hardpoints
            -The .py files are included, so you can tweak the hardpoints if they aren't to your liking
    * Tactical Icons
    * Scripts\Custom\Ships files
            -The .py files are included, so if you don't like the name or location of a ship in the menu, you can easily             change it.
    * Scripts\Custom\Carriers files (for the shuttle launching from the Constitution Class, Daedalus Class, and Deep Space 
      Station K7)
    * Scripts\Custom\Autoload\MVAM files (for the Ptolemy + Variants)



/-----CREDITS-----/


Constitution + Variants:

Original Model, Textures, and Hardpoint:     	Anduril
New Model Parts: 				Phaser
New Textures and Hardpoint: 			Phaser
New Ship Description:  				Phaser
Shuttle-Launching Framework: 			Sleight42
Actual Shuttle-Launching Script: 		Online program by Defiant
Conversion:   					Mark & Starforce2



Saladin:

Original Model, Textures, and Hardpoint:     	Anduril
New Model Parts: 				Phaser
New Textures and Hardpoint: 			Genty & Phaser
New Ship Description:  				Phaser
Conversion:   					Mark, Phaser & Starforce2

 

Daedalus/Essex:

Original Model, Textures, and Hardpoint:     	CMD
Tweaked Model: 					Phaser
New Textures and Hardpoint & SFX: 		Phaser & USS Sovereign
New Ship Description:  				Phaser
Shuttle-Launching Framework: 			Sleight42
Actual Shuttle-Launching Script: 		Online program by Defiant
Conversion:   					Starforce2

 

Ptolemy Class+Variants:

Model, Textures, and Hardpoint:     		Phaser
Ship Description:  				Phaser
MVAM Scripting:					Sneaker98 & Mark
Ordering in the QB Menu:			Mleo & Phaser
Conversion:   					Mark & Phaser

 

Deep Space Station K7:

Model, Textures, and Hardpoint:     		Phaser
Ship Description:				Phaser
Shuttle-Launching Framework: 			Sleight42
Shuttle Launching Upon Destruction:		Defiant & Phaser
Conversion:   					Mark, Phaser & SF2

 

Type 1 Shuttlecraft:

Original Model, Textures, and Hardpoint:     	CMD
Tweaked Model:					Phaser
Rescaled HP:					Phaser
New Ship Description:  				Phaser
Conversion:   					Starforce2

 

Klingon D-7 Class, Studio Model:

Original Model, Textures, and Hardpoint:     	ATRA-HASIS
New Textures and Hardpoint: 			Phaser
New Ship Description:  				Phaser

 

Klingon D-7 Class, Greg Jein Variant:

Original Model, Textures, and Hardpoint:     	ATRA-HASIS
New Textures and Hardpoint: 			Phaser
New Ship Description:  				Phaser

 

Klingon K'Tinga Class (TMP, TNG, and Qonos One Variants):

Original Scripts\Custom\Ships files:    	Zambie Zan
New Scripts\Custom\Ships files:  		Phaser
New Ship Description:  				Phaser

 

K'Tinga Class (Romulan Variant):

Original Scripts\Custom\Ships files:    	Zambie Zan
New Scripts\Custom\Ships files:  		Phaser
 


Alpha Testers:
Nebula

 

Beta Testers:
Adonis, Billz (a.k.a. SuperSmeg), Cobie2, Cube, JB06, Mark, Nebula, TiqHud

 

/-----THANKS-----/

    * Adonis and MLeo, for instructing me how to on repair the '???' QB menu error.
    * Adonis, ChiefBrex, and DJ Curtis for teaching me many, many things in 3DS Max and helping me solve problems I was
      having.  I can't thank you guys enough for your patience and kindness.
    * Cube, for rescaling a draft of the Type 1 shuttle and for converting some mesh drafts from .nif to .3ds and back.
    * Defiant, for his online program that can generate shuttle-launching scripts, and for teaching me how to launch a
      shuttle from K7 once the station is destroyed.
    * Dragon, for his great tutorial on adding the shuttle-launching scripts, and for trying to help get the shuttles to 
      return properly.
    * eclipse74569, for finding a texture error on the Saladin class.
    * Mark Ward, for making the .exe file and related graphics, for getting MVAM to work on the Ptolemy, and for converting
      this readme to html.
    * ModelsPlease, for converting some mesh drafts from .nif to .3ds and back.
    * Nanobyte, for creating BCMP.  That program makes things so much easier!
    * Nebula, for being there when I needed someone off of whom I could bounce ideas, to vent frustration, and being there
      when I wanted to show off progress.
    * Starforce2, for rescaling the Type 1 shuttle, converting many, many, many draft meshes, and for providing a means with 
      which to contact StressPuppy.
    * USS Sovereign, for getting the Daedalus laser sounds to work properly and helping me get the Bridge subsystem to appear       on the Daedalus.
    * Anyone I may have forgotten (I'm sorry!).
    * A special thanks to Mr. Nick Porcino for his wonderful TOS dorsal and ventral saucer textures, which I used as a base
      for the retexture of the Constitution Class and subsequent saucers.

 

/-----DETAILS-----/

*_Constitution Class -- Production Version_*
 -Model
    * Completely new saucer section, bridge dome, impulse engines, spine, and neck.
    * Reproportioned and repositioned secondary hull, nacelles, and pylons.
    * Slightly rebuilt secondary hull (at the base of the neck).
 -Textures
    * Completely new saucer textures and glows.  This includes new hull markings, canon window locations, light scorching and
      age marks, and a new set of grid lines on the saucer.
    * Significantly reduced contrast between the hull and the grid lines/age marks, and an overall lighter shade and slightly
      different hue.  The ship now appears extremely close to how it did throughout TOS (taking into account and compensating
      for washout and the grainy quality of TOS) and in the rare appearances on later shows.

        Note:  On the original paint job of the production model, the grid lines were drawn *in pencil* on the *11 foot* 
        (*3.35 meters*) studio model, so they should /not/ be easily visible.  This retexture reflects that fact.

    * The windows on the neck and aft windows of the secondary hull of the ship have been reorganized in a canon fashion.
    * The glow on the shuttle bay door has been significantly reduced, and the glows in the surrounding areas have been
      tweaked.
    * The deflector dish and housing now has a canon hue in-game.  The dish texture has been cleaned up a little, as well.
    * Overhauled glows.  Everything, /down to which windows are lit/, now appears as they did in The Original Series and in 
      the DS9 episode "Trials and Tribble-ations".
    * Completely new bussard collector textures, glows, and animation textures.  The bussard collectors now appear somewhere
      in between how they appeared in The Original Series and the DS9 episode "Trials and Tribble-ations."  I chose not to
      recreate the exact look from TOS because that look was too grainy, and would have probably appeared somewhat cartoon
      -like in-game.  Instead, I chose a balance between the grainy, but canon look in TOS, and the crisp, but slightly over        -detailed version seen in "Trials and Tribble-ations."  I think you'll be pleased with the results!
 -Scripts
    * Tweaked hardpoint.  The phasers are no longer thick in the middle, and the phaser arcs have been tweaked a bit.  Almost
      all systems have had their hitpoints tweaked to make the Constitution Class a match for the Klingon D-7 Class included
      in this mod (modified from Zambie Zan's Klingon D-Pack).
    * Shuttle-Launching Framework has been added to this ship!  The ship can now launch four Type 1 shuttles representing the
      Enterprise's shuttles: Columbus, Copernicus, Einstein, and Galileo.  You can still use this ship even if you don't have
      the shuttle-launching framework.  You just won't be able to launch shuttles.
    * New ship description and new Tactical Display Icon.




*_Constitution Class -- "The Cage" (1st pilot) Version_*
 -Model--Based on changes from the Production Version:
    * Spikes added to the bussard collectors
    * The dome on the back of each nacelle has been replaced with a couple of protruding rectangles
    * Aft, port, and starboard navigation lights removed
    * Bridge Dome and turbolift are taller
    * Deflector dish enlarged and in-charge
    * Gap opened between intercoolers (those fins near the back of the nacelles) and the nacelles
 -Textures
    * These pretty much speak for themselves.  They now match the 1st pilot episode of TOS.  Note that there were NO lit
      windows in the first pilot.
 -Scripts--Same as Production Version



*_Constitution Class -- "Where No Man Has Gone Before" (2nd pilot) Version_*
 -Model--Based on changes from the 1st pilot Version:

    * Rectangles removed from the back of the nacelles
    * Port and starboard navigation lights added to saucer
    * Gap closed between intercoolers and back of nacelles
 -Textures
    * Again, these pretty much speak for themselves.  They now match the 2nd pilot episode of TOS.
 -Scripts--Same as Production Version



*_Saladin Class_*
 -Model
    * Completely new saucer, bridge dome, impulse engines, spine, and neck.
    * There used to be a small gap in the model between the neck and the nacelle.  This has been fixed.
 -Textures
    * Completely new textures, similar in style to that of the Constitution.  Differences include which windows are lit, the
      location of a few windows on the ventral saucer and neck, weathering, and of course, the registry.
    * Completely new glows
    * Animation have been added to the bussard collector
 -Scripts
    * Tweaked hardpoint, scaled to the Constitution.  This ship has less fire power than the Constitution, but without a
      secondary hull and only one nacelle, she has less weight to lug around then the Constitution, making her move 
      maneuverable.
    * New ship description

 

*_Daedalus Class_*
 -Model
    * The mesh error that caused the ship's shadow to appear "split" has been repaired
    * Slightly reproportioned nacelles
 -Textures
    * Much more detailed and realistic hull textures, including new  bussard collector textures
    * New glows
    * New Registry font and hull markings
 -Scripts
    * New hardpoint.  The ship now has four thin, red lasers (two forward, one port, and one starboard), and two forward
      Spatial Torpedo launchers.  The ship's power distribution systems have also been significantly modified.  Let's just
      say this ship will really bring out the game's power distribution aspect (see the ship description in-game for more
      information).
    * Unique sound effects for the lasers of the U.S.S. Daedalus
    * New ship description that appears in-game

 

*_Ptolemy Class_*
    * Nothing to say; the whole thing is new!



*_Deep Space Station K7_*
 -Model
    * Completely new model.  This model is based on the model by Greg Jein that appeared in the DS9 episode "Trials and
      Tribble-ations".
 -Textures
    * Again, completely new.  Things to note:  Detail in the shuttle bay, and the reorganized window layout in the 'core'
      area of the station; There are now 21 decks in that area, exactly as seen on-screen, with all windows placed accurately
      with respect to the model.
 -Scripts
    * Overhauled hardpoint
    * New ship description
    * This station will sometimes launch a shuttlecraft when it's about to be destroyed, just like how the Borg Cube included
      in the Kobayashi Maru mod (v.0.9.1) sometimes launches a Sphere.

 

*_Type 1 Shuttle_*
 -Model
    * Properly rescaled model (thanks to Cube)
    * Slightly cleaned up mesh
 -Scripts
    * Rescaled hardpoint to match the model
    * New ship description



*_Klingon D-7 Class -- TOS Studio Model_*
 -Textures
    * Completely revamped.  The textures now accurately reflect how the  D-7 appeared on in the original series--different 
      shades of grey with very subtle green hues.
 -Scripts
    * Overhauled hardpoint.  The ship is now a match for the Constitution Class included in this pack.
    * New ship description and new Tactical Display Icon.



*_Klingon D-7 Class -- Greg Jein Variant_*
 -Textures
    * Completely revamped.  The textures now accurately reflect how the D-7 appeared in the DS9 episode "Trials and Tribble-
      ations"--a strong green hue, a feather pattern on the dorsal hull, and a slight green engine glow.
 -Scripts
    * Overhauled hardpoint.  The ship is now a match for the Constitution Class included in this pack.
    * New ship description and new Tactical Display Icon.



*_Klingon K'Tinga Class (TMP, TNG, and Qonos One Variants)_*
 -Scripts
    * New ship description for the K'Tinga TMP and TNG variants.
    * New placement in the Quickbattle menu using MLeo's Submenu mod.



*_Klingon K'Tinga Class (Romulan Variant)_*
 -Scripts
    * New placement in the Quickbattle menu using MLeo's Submenu mod.

 

/-----LEGAL-----/
Star Trek, Star Trek: The Next Generation, Star Trek: Deep Space Nine, and Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures, as are the characters, related images, and sounds from the productions.  No one associated with the production of this mod can be held accountable for any damages the installation of this mod may incur upon your computer.  Use at your own risk.  This file is not supported or affiliated with Interplay Productions.  This file is freeware. It is not to be sold.

This mod may be distributed freely if and only if permission allowing distribution is obtained from Aaron Gendler prior to distribution, and the original archive is distributed and no part of it, including this document, is modified or missing.

Modification of any part of this mod for redistribution purposes is only allowed if approval is given by Aaron Gendler prior to distribution.

 

/-----CONTACT INFORMATION/PERMISSION-----/
Aaron Gendler (Phaser) may be contacted at the Bridge Commander Central Forums (http://bc-central.com/forums/index.php?action=profile;u=17).  He can also be reached at Aaron_Gendler@msn.com.  Permission MUST be attained from Aaron Gendler if you wish to make any modifications to this mod and release them to the community.

