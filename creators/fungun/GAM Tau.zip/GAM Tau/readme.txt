All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "GAM Tau" -press "g" and you're on your way there.

PLANET INFO-Gamma Tauri IV was the fourth planet in the Gamma Tauri system. It was the location of an unmanned Federation monitoring post, from which the Ferengi stole a T-9 energy converter in 2364. (TNG: "The Last Outpost")

Credits for texture creations, addon creators, and
special models. 
  
Adtnik.jpg--*
Condradirck.jpg--kikinho
DalRiata-clouds2a.png--John M Dollan
darwinclouds.png--Rob Sanders
lammetus2.jpg--*
Paje.jpg--kikinho
Pholus-clouds.png--John M Dollan
rigel8f.jpg--fugazi


* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
