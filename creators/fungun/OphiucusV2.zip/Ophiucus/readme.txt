All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "36 Oph A" -press "g" and you're on your way there.

PLANET INFO-Ophiucus III is the third planet of the Ophiucus system and a colony world that was being settled in the late 23rd century. Women were scarce enough that intergalactic rogue Harcourt Mudd saw an opportunity in bringing them in from other worlds. (TOS: "Mudd's Women")

Ophiucus VI is the sixth planet in the Ophiucus system. 
Harry Mudd once visited Ophiucus VI, where he conned two miners out of a year's supply of dilithium crystals using fake Federation vouchers. (TAS: "Mudd's Passion") 



Credits for texture creations, addon creators, and
special models. 
  
Hester.jpg--John M. Dollan
juno.jpg--jestr
negsoa2a.jpg--steve bowers
ophi1.jpg--*
ophi4.jpg--John Van Vliet/mod-Tim
temperance.jpg--Steve Bowers
vega2c.jpg--fugazi
vega9d.jpg--fugazi
vesta.jpg--jestr
   
* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
