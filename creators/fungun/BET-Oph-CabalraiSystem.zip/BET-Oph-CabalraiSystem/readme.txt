All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "Cebalrai" or "Bet Oph" -press "g" and you're on your way there.

PLANET INFO-Beta Ophiuchi VI is a planet located near the Great Rift. 
While dining in the capital city of one of its countries, Ileen Maisel watched dancing gelatin. (TNG novel: Intellivore)

Errigal, in the star system of 60 Ophiuchi, was a Federation planet, home to the Third Submission Colony. (TNG novel: Intellivore)  


Credits for texture creations, addon creators, and
special models. 
  
dactyl.jpg,ky26.jpg--jestr
marsclouds2k.png--Don Edwards
neumaia.jpg--Rob Sanders
olyxbca.jpg--Tleilax
Ring1.png--Anders Sandberg
syliar2.jpg--Cham
sylok.jpg--jestr
Taunton.jpg--John M. Dollan
smaan-moon.jpg--gradius_fanatic
torko.jpg--Cham   

   

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
