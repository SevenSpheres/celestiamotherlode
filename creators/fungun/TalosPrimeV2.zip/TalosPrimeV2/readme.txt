All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

***THIS ADDON CAN BE USED IN 2 WAYS.***

1-As per the info from Memory-Alpha and Memory-Beta wiki sites, it is stated that there is 11 planets in the system-5 terrestrial and 6 Gas Giants. For this you can email me for the "Talos Extras" addon. 

2-According to the Star Trek Star Charts book, there is only 5 planets, all terrestrial. If you agree with the book, then just use this addon.

I found one image from the show at Memory-Alpha. It shows a smaller system.
So I guess it's up to the individual as to what you want to use.

Start Celestia-press "Enter"-type in  "Talos Prime" -press "g" and you're on your way there.

PLANET INFO-Talos IV is a M-class planet, and the fourth of eleven worlds within the Talos star group. 
It was inhabited by the Talosians, an old and weakened race with enormous mental powers, who lived deep underground. In 2254, the planet was visited by the Federation starship USS Enterprise under the command of Captain Christopher Pike after receiving a distress call from the SS Columbia, which crash-landed there in 2236. However, the only survivor of this crash was Vina, a female Human. (TOS: "The Cage") 
Afterwards, the Federation imposed General Order 7 on the Talos system, preventing anyone from ever approaching, let alone making any form of contact with, the planet again under penalty of death. (TOS: "The Menagerie, Part I") 
In 2267, Talos IV was revisited by the Enterprise while commandeered by Spock, in order to drop Captain Pike there. Pike had been crippled by delta rays but was able to live a normal life on the planet together with Vina. (TOS: "The Menagerie, Part II")


Credits for helping me get started, texture creations, addon creators, and
special models.

Butuie.png--kikinho
bajor7.jpg--jestr
bluemoongaseous.jpg--gradius_fanatic
moon1011.jpg--*
talos4.jpg--kikinho
Unai-clouds.png--kikinho


 
* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.



   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
