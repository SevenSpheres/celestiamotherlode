All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "IOT Gem" -press "g" and you're on your way there.

PLANET INFO-Tribbles (Polygeminus grex) are small, non-intelligent lifeforms originating from Iota Geminorum IV. Known for their prodigious reproductive rate, these round, furry creatures emit cooing sounds while touched, which have a tranquilizing effect on the Human nervous system. Born pregnant, with sufficient food a single tribble can quickly increase its number exponentially through presumably asexual reproduction, bearing an average litter of ten every twelve hours. On their homeworld, tribble populations are kept in check by a large number of reptilian predators. 

Tribbles were first encountered by Humans in the early 2150s, when Denobulan doctor Phlox brought a small number aboard Enterprise NX-01 as food for his pets. (ENT: "The Breach") 
 
Kirk gets buried in tribbles in 2268The tribble was later encountered by the Federation aboard Deep Space K-7 in 2268, when Cyrano Jones brought a small number aboard to trade. However, a single tribble brought aboard the USS Enterprise quickly multiplied to 1,771,561. The tribbles were instrumental in foiling a Klingon plan to poison a shipment of quadrotriticale intended for Sherman's Planet, when tribbles that had fed on the grain were found dead. (TOS: "The Trouble with Tribbles") 

At the same time, the crew of USS Defiant, transported through time by Arne Darvin, prevented him from using a tricobalt device hidden inside a tribble to kill James T. Kirk. (DS9: "Trials and Tribble-ations") 

In order to fulfill their self-given task to hunt the tribble species to extinction, the Klingons presumably bombed Iota Geminorum IV in the late 23rd century, which suggests it might now be a part of the Klingon Empire. (DS9: "Trials and Tribble-ations") 


Credits for texture creations, addon creators, and
special models. 
  
daedalus.jpg--steve bowers / mod Tim (fungun)
DukesNessos.jpg--John M. Dollan j.dollan@bresnan.net 
Kastiel.jpg--John M. Dollan j.dollan@bresnan.net
neumann.jpg--Rob Sanders
PervaHanish.jpg--* / Seth Pritchard
SarustQuint2b.jpg--John M. Dollan j.dollan@bresnan.net / CRAIG STRAPPLE
serviBradb.jpg--jestr / Michael Kilderry

* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.  


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
