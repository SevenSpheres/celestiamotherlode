All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "ALF CrB" -press "g" and you're on your way there.

PLANET INFO-Gamma II was an uninhabited planetoid in the Gamma system in Federation space. It was used by the Federation as an automatic communications and astrogation station. Gamma II was about 11.63 light years from the M24 Alpha system. 
In 2268, Captain James T. Kirk, Lieutenant Uhura, and Ensign Pavel Chekov of the USS Enterprise beamed down to this planet to do a standard check when they were abducted by the Triskelions of M24 Alpha. (TOS: "The Gamesters of Triskelion")
 
Here is a link to what Gamma II looks like.
http://memory-alpha.org/wiki/Gamma_II


Credits for texture creations, addon creators, and
special models. 
  
--
armargast.jpg--Cham
terilianSaldana.jpg--jestr 
Reese-clouds.png--John M. Dollan j.dollan@bresnan.net
bacchSmaan.jpg--jestr / gradius_fanatic
bacchus.cmod--jestr   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
