All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Nimbus" -press "g" and you're on your way there.

PLANET INFO-Orbited by at least two moons, Nimbus III is the third planet in the Nimbus system located in the Neutral Zone. 
Nimbus III was established as a "Planet of Galactic Peace" in 2267 after the Federation-Klingon War. 
The Federation, and the Klingon and Romulan empires agreed to mutually develop the planet, perhaps in the hopes of serving as a model for a new age of peace and understanding. However, the planet proved to be an inhospitable rock, and the colonists chosen for the undertaking were among the most unscrupulous individuals in the galaxy, quickly taking to fighting amongst each other, fashioning their own crude projectile weapons when the planetary government forbade them from any weapons at all. In 2287, the Vulcan Sybok took over the planet's capital and only settlement, Paradise City, to attract a starship to take him to Sha Ka Ree. (Star Trek V: The Final Frontier) 
Nimbus III was labeled on a star chart in astrometrics aboard the USS Voyager. (VOY: "Child's Play")


Credits for texture creations, addon creators, and
special models. 
  
errimarSaldana.jpg--jestr
nimbus3b.jpg--kikinho
SanJoaquin.jpg--John M. Dollan j.dollan@bresnan.net
smamonAthena.jpg--gradius_fanatic / Milosz21
test2d.jpg--fungun(Tim)   
TellaToul-clouds.png--Milosz21 / Anders Sandberg

ceres.cmod--jestr

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
