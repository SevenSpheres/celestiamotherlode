All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "BET Oct" -press "g" and you're on your way there.

PLANET INFO-The M-class world Caldos II was the second planet in the Caldos system.
It was a Federation member and home to Caldos colony, one of the Federation's first major terraforming projects. In 2370, Beverly Crusher, chief medical officer on board the USS Enterprise-D attended the funeral of her grandmother at Caldos. (TNG: "Sub Rosa")

Credits for helping me get started, texture creations, addon creators, and
special models. 
  
   
3d duckboy productions
3d.concept40.com
John M. Dollan
Don Edwards
Andy Roberts
Steve Bowers
Ivo Beckers
http://galaxistar.googlepages.com
Matt Davis
Selden Ball
Runar Thorvaldsen
Rob Sanders
Cham (from Celestia forum) 
 jestr (Celestia forum)
Pericapolis
Fridger Schrempp
pioneerxtower (J. P.)
Bruckner
Shcuf
Jean-Marie le Cosp�rec
   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
