All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "BET Cet" -press "g" and you're on your way there.

PLANET INFO-Deneb Kaitos II is the second planet of the Deneb Kaitos system.
Sometime prior to 2266, Deneb II was the site of several murders of women committed by the Redjac entity, incarnated as "Kelsa". (TOS: "Wolf in the Fold")

23rd Century-Many of the inhabitants of Deneb IV Kaitos communicate telepathically. In at least three cases, during the 2260s, Gary Mitchell carried on long telepathic conversations with select Deneb Kaitos IV natives and scored 80% or higher on comprehension. 
During the first half of the 23rd century, a young James T. Kirk and Gary Mitchell came to this planet, where Mitchell got involved with a woman. Kirk stated that he'd been worried about Mitchell ever since that night, and Mitchell referred to the girl as a Nova, a pun suggesting the danger he was in. (TOS: "Where No Man Has Gone Before") 

The M-class world Deneb Kaitos V is the fifth planet of the Deneb Kaitos system and homeworld of the humanoid Denebians. 
In 2267, this planet still uses the death penalty for such crimes as fraud. The guilty party has the choice between death by electrocution, death by gas, death by phaser or death by hanging. (TOS: "I, Mudd") 
An Academy of Science on Deneb Kaitos V was dedicated in 2270. (TAS: "The Pirates of Orion")
  
Deneb Kaitos VI is a Class T planet in the Deneb Kaitos system. It is a failed protostar that orbits its primary at a distance of 42 AU, and it may be responsible for the lack of gas giants in the system. (Star Trek: Star Charts)

Credits for texture creations, addon creators, and
special models. 

eudossia.jpg--Shcuf, ALARAPH addon
DerbritCernun.jpg--kikinho / Cham
geographos.jpg--jestr
Dradgeworld.png--John M. Dollan j.dollan@bresnan.net
kiaro.jpg--gradius_fanatic
ky26.jpg--jestr
ninurtaclouds.png--Rob Sanders
vesta.jpg--jestr
boo.jpg, Talaxia2.jpg--Tim Wilson 
Moon models--jestr   


Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
