All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.



Start Celestia-press "Enter"-type in  "Penthara" -press "g" and you're on your way there.

---------------------------------------------------------------------------------------------------
PLANET INFO-Penthara IV is the fourth planet in the Penthara system. It was the location of a Federation colony in the 24th century that had existed on the planet for at least a century in 2368. 

The planet was tectonically very stable; no earthquakes had been registered for nearly a hundred years. More then twenty million colonists called the planet their home. One of the major settlements on Penthara IV was New Seattle. The planet was governed by a group of colony leaders who jointly decided about the fate of the colony. 

In 2368, one of the uninhabited continents of Penthara IV was struck by a type C asteroid. The impact created an enormous dust cloud (a cloud depth of twelve kilometers was measured) and massive atmospheric distortions that threatened to impose a situation similar to a nuclear winter on the planet. Only less than 20% of the normal sunlight was able to penetrate through the dust resulting in a rapid cooling of the planet surface. 

Initial forecasts predicted a temperature drop of ten to twelve �C within the first ten days after impact. A short time after the impact, two tropical rivers began to freeze, so it was time to counteract the cooling of the planet. 

In order to do so, the colony leaders requested assistance from the USS Enterprise-D. Together with leading scientist Doctor Hal Moseley, the crew developed a plan to phaser drill holes into subterranean pockets of carbon dioxide to release enough of the gas to form an envelope which would temporarily hold in the heat from the sun, effectively creating a greenhouse effect, something the colony leaders had successfully prevented from happening for decades. 

After the correct number, depth and location of bore sites was calculated, the ship's phaser was used to drill around 20 holes into the planet's crust, effectively releasing the gas. The plan seemed to work at the beginning, as the temperature drop was halted and two equatorial thermal monitoring stations even reported a rise in temperature, as desired, but after some time, enormous earthquakes were detected. 

It turned out, that the drilling had destabilized the formerly so stable tectonic plates and the mantle was collapsing around the bore sites, causing several volcanic outbreaks and more severe earthquakes, measured at between 8 and 8.5 on the Richter scale. The colony was built to be fairly earthquake-proof, but the volcanic plumes were creating new problems, as the additional dust thrown into the atmosphere only increased the problematic cloud cover and it was estimated that after some days of volcanic activity, no more sunlight would be able to reach the surface. 

Another plan was devised to remove the dust cloud from the planet's atmosphere: by ionizing the electrostatically-charged particles with the ship's phaser, the dust was converted into high-energy plasma. This plasma was then absorbed by the deflector shields of the Enterprise-D and redirected into space. 

Though there was the risk of causing a cascading exothermal inversion which would have completely burned off the planet's atmosphere, the plan worked and the colony and its millions of inhabitants were saved from a nuclear winter. The temperature rose to a normal level again, the snow stopped, and the amount of particulates in the atmosphere was identical to the amount measured before the asteroid impact. The volcanoes finally also came to a rest after some time. (TNG: "A Matter of Time") 

Penthara IV also appeared in the starchart Data and Picard were studying in stellar cartography in 2371. (Star Trek Generations) 
---------------------------------------------------------------------------------------------------

CREDITS for texture creations, addon creators, and
special models. 

baramalmoon_iiiDs3.jpg--Rassilon / Anders Sandberg
cardassiaIIBetavorum.jpg--jestr / *
dactyl.jpg, juno.jpg--jestr
rigel4aKiaroSylok.jpg--fugazi / gradius_fanatic / jestr
shinehah_planet_iii-moon_ii-clouds.png--Rassilon
swarog.jpg--Victor Dvorak
valdradaRiss.jpg--Shcuf-ALARAPH addon /  John M. Dollan maastrichian@bresnen.net
   
* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
