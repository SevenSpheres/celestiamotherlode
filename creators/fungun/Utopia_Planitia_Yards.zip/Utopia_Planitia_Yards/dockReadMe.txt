We here at the Ship Builders Project 2007 (SBP07) would like to introduce our first completed project.

- TMP DryDock (Copper COlor)
- TMP DryDock (Grey COlor)
- Generations DryDock
- Pre TNG DryDock

Mesh: Cordanilus
Textures: Cordanilus, Dr_McCoy1701A
Texture Mapping: Cordanilus
Scripting: SBP07 Team

Special Thanks to Dr_McCoy1701A for helping me out with the textures.  For adding fake bump maps to them, improving the overall look and feel to the textures.  You are amazing.

Special Thanks to the KM Team for allowing me to incorporate the Docking Script into the drydocks.

Beta Testers: SBP07 Team and Dr_McCoy1701A



Disclaimer:

This MODEL(S) is NOT MADE, DISTRIBUTED, or SUPPORTED by Activision TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Star Trek, Star Trek: The Next Generation, Star Trek: Deep Space Nine, Star Trek: Voyager
and related properties are Registered Trademarks of Paramount Pictures (A Viacom Company)
registered in the United States Patent and Trademark Office.

Star Trek:Bridge Commander was produced and distributed by Activision Inc.

This is not intended as an infringement of the owners rights.


SBP07 Email: anazonda AT hotmail DOT com
My email: cordanilus AT hotmail DOT com