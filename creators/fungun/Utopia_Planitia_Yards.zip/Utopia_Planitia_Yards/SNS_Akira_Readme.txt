Title		: SNS Akira Class
Filename	: SNS_Akira.rar
Version		: 1.0
Date		: 11.26.2003
Author		: Scotchy & Rick Knox a.k.a pneumonic81
Email		: scotchy10008@hotmail.com
URL		: (none)

Credits	
-------------	
Model Design	: Alex Jager (ILM)
Textures	: Scotchy
Mesh		: modified by Scotchy, original mesh by Rick Knox
Build time	: 5 days (original), 4 days to modify
Hardpoints      : Thunderchild
Sounds          : Paramount (Thanks to Book for his quality extraction)
Thanks to	: Rick Knox, Thunderchild, Book and the BCU Forum members.

Description of the Modification
-------------------------------

An original model created in 3dsmax by Rick Knox. Mesh modified in 3dsmax 4.1
by Scotchy with new high rez textures. Converted using SDK plugin for Max 3.1
Hardpointed by Thunderchild for maximum kickass, with canon torpedo sounds by
Book.

Based more on Akira Concepts than on the Voyager mesh from Star Trek magazine.

Technical Details
-----------------
Polycount        : 7500+
Textures         : (4) 1024x1024
                   (1) 512x512





Copyright and Distribution Permissions
--------------------------------------
THIS MODEL(S) IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY Activision
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices: 

Star Trek, Bridge Commander, Star Trek: Deep Space Nine, Star Trek: The Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright Paramount Pictures,
as are the characters, related images, and sound from the productions. 

Please do not distribute modified versions of these files without seeking permission from the 
authors, it's just polite.

