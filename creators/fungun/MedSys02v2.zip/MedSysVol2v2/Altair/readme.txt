All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "Altair" -press "g" and you're on your way there.

PLANET INFO-Altair III is the third planet in the Altair system, orbiting the star named Altair. 
When the USS Hood visited this system, Lieutenant Commander William Riker stopped Captain Robert DeSoto from transporting to the surface of Altair III with an away team, because he deemed the action as too dangerous, inappropriate for a commanding officer. (TNG: "Encounter at Farpoint", "The Pegasus") 

Altair IV is the fourth planet in the Altair system, orbiting the star named Altair. It is home to a Federation population. 
Darien Wallace was born on this planet. (TNG: "Eye of the Beholder")
In 2371, a resident of this world, one Doctor Henri Roget of the Central Hospital of Altair IV, was awarded the prestigious Carrington Award for his work in the field of medicine. (DS9: "Prophet Motive")

Altair VI is a planet in the Altair system (orbiting the star Altair), which is in or near Federation space. (TNG: "Conspiracy") 
Despite the former conflict in this system, it was well known for its excellent shore leave facilities in 2267. In the same year a new president was to be inaugurated on the planet, an event of significant importance as the Altair system had been involved in a long inter-planetary war in the years before. The inauguration would send shockwaves as far as to the Klingon Empire and therefore was attended by three Starfleet ships, including the USS Enterprise. (TOS: "Amok Time") 
In 2285, Altair VI was a part of the Kobayashi Maru simulation at Starfleet Academy; the Kobayashi Maru claimed to be nineteen periods out of Altair VI. (Star Trek II: The Wrath of Khan)
 



Credits for texture creations, addon creators, and
special models. 
  
Altair1.jpg--Shcuf ALARAPH addon / John M. Dollan j.dollan@bresnan.net / jestr   
altair_ii-moon_iiB.jpg--Rassilon
BradburyAeolus.jpg--Michael Kilderry / John M. Dollan j.dollan@bresnan.net
bright2.jpg--steve bowers
ChinookDs3x.jpg--John M. Dollan j.dollan@bresnan.net / Anders Sandberg
geographosIsik.jpg--jestr / John M. Dollan j.dollan@bresnan.net
HadiesBristol.jpg--Milosz21 / John M. Dollan j.dollan@bresnan.net
juno2.jpg--jestr
Polypoetes.jpg--John M. Dollan j.dollan@bresnan.net
rigel4bRiss.jpg--fugazi / John M. Dollan j.dollan@bresnan.net
TaranisRc3Ds5.jpg--John M. Dollan j.dollan@bresnan.net / Anders Sandberg 
Chinookw.png--John M. Dollan j.dollan@bresnan.net
Cold-clouds.png--kikinho

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
