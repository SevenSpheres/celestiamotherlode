All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly 
different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "BET Hyi" -press "g" and you're on your way there.

PLANET INFO-Planet and site of a neuropsychology seminar attended by Deanna Troi in 2369. Troi was abducted from Borka VI by the Romulan underground, who used her in a plan to help M'Ret defect to the Federation. (TNG - Face of the Enemy)

Credits for texture creations, addon creators, and
special models. 
  
aglauraPenteOlyxbcc.jpg--Shcuf ALARAPH addon / Tleilax 
arazius1clouds.png--galaxistar
KamuiHopi.jpg--kikinho / John M. Dollan maastrichian@bresnen.net
moon02.jpg--#
moon03.jpg--#
Pirithous.jpg--John M. Dollan maastrichian@bresnen.net
rigel4aKiaroVega10g.jpg--fugazi / gradius_fanatic / fugazi 
SanGabrielx.jpg--John M. Dollan maastrichian@bresnen.net
   
# - made from 2 or more textures that I did before I changed how I named the resulting file, so original author is now unknown. I apologize for this oversight on my part.

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
