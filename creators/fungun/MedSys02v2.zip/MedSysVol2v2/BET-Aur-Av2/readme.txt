All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Do not use the OpenGL 2.0 render path when viewing my addons. It is not needed and it makes the water look blocky. I do not know why. They look just fine in the other render paths and I am trying to figure it out.

Start Celestia-press "Enter"-type in  "BET Aur A" -press "g" and you're on your way there.

SYSTEM INFO-Beta Aurigae was a trinary star system located in the Beta Quadrant. 

The system contained at least seven planets. One of them, Beta Aurigae VII, was once home to the Zalkatians. (ENT short story: The Brave and the Bold - "Prelude: Discovery") 

Prior to 2225, a colony had been established in the Beta Aurigae system. In that year, a colony ship commanded by Captain Mendez headed for that colony went off course, crashing on a world the survivors later dubbed "The Frontier". (TOS short story: "The Leader") 

In 2268, an Interstellar Geophysical Conference was held on Beta Aurigae. (TOS comic: "Sweet Smell of Evil") 

In 2269 the USS Enterprise rendevoused with the USS Potemkin in the Beta Aurigae system. (TOS episode: Turnabout Intruder; comic: "Captain's Personal Log") 


Credits for texture creations, addon creators, and
special models. 
  
bajor4.jpg, bajor7.jpg, golevka.jpg, juno.jpg--jestr

betaMoema.jpg--*/kikinho-mod by Tim

GasGiant-Green2.jpg--Matthew Attard(may not be used in any other addons, I had to get special permission to use it)

Lifthrasir.jpg, Skoll.jpg, TartessosTerraformed-clouds.png--John M. Dollan maastrichian@bresnen.net

moon.jpg, uriel.jpg--Celestia

olyxbcc.jpg--Tleilax

valdradaZ2a.jpg--Shcuf/ALARAPH addon

Tella-clouds4.png--Milosz21


   
* author unknown-Original addon that this texture comes from has either been deleted or moved and any internet searches only provide broken links.

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
