All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  

This add-on was designed using Celestia 1.6.0.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

Start Celestia-press "Enter"-type in  "pi3 Ori" -press "g" and you're on your way there.

PLANET INFO-Orion was the homeworld of the Orion species. The planet's system was in the Orion sector. (TNG: "Conspiracy") 
The planet Orion once harbored a highly-advanced civilization whose history has drawn great interest from Federation historians and archaeologists alike. 
During the mid-23rd century, noted Federation archaeologist Dr. Roger Korby translated medical records from the Orion ruins that helped revolutionize modern immunization techniques and were required reading at Starfleet Academy. (TOS: "What Are Little Girls Made Of?") 
In 2269, through the assistance of the Guardian of Forever, Starfleet officers Captain James Kirk, Commander Spock and historian Lieutenant Erikson traveled to the dawn of Orion's civilization to view the planet's history unfold firsthand. (TAS: "Yesteryear") 
Devna, an Orion trapped in Elysia told Kirk that she wished to return through the time barrier and see Orion again. Kirk offered to take her back with him, but she declined, stating that she had accepted where she now was in life. (TAS: "The Time Trap") 
In 2372, Ferengi entrepreneur Quark attempted to smuggle kemocite on a highly-profitable side trip to Orion under the guise of taking his ship, Quark's Treasure, on a test flight to Earth. This proved to be unsuccessful due to sabotage. (DS9: "Little Green Men") 

Orion I is the first planet in the Orion system, location of a prestigious Institute of Cosmology. Crewman Mortimer Harren had hoped to attend the Institute of Cosmology there, and thus signed onto the USS Voyager because a year of field experience was required for admittance. (VOY: "Good Shepherd") 

Orion III was the third planet of the Orion system. 
As part of a vision quest, Tom Paris told Chakotay that word had just come in from Vegas, Mars and Orion III that the odds were 33:1 that Kid Chaos would outpoint him and 11:1 that he'd be k.o.ed by the fifth round. (VOY: "The Fight") 



Credits for helping me get started, texture creations.

Cold-clouds.png--kikinho
Daedalus-clouds.png--John Dollan and Steve Bowers  
dandima.jpg--gradius_fanatic
earth-clouds.png--Celestia
geographos.jpg--Celestia
Hephaestus.jpg--Ivo Beckers(rsanders and jmdollan)
ky26.jpg--Celestia
Nessos-rings.png--John M. Dollan
ninurtaclouds.png--ROB SANDERS
orion1.jpg--Tim
friendship.jpg--Steve Bowers
Piata.png--kikinho
Ring1.png--Anders Sandberg
vesta.jpg--Celestia
   

   
If you would rather I not use any of your textures you may email me at 
fungun@yahoo.com

Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!

Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
and with http://www.bumply.com/astro.html#1

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

 
