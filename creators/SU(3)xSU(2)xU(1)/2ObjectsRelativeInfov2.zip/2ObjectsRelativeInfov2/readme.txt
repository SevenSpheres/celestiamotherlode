********************************************************************* 
********************************************************************* 
              A script to compute and display positions and speeds
 
            Coded by SU(3)xSU(2)xU(1) as a modification of the script
            "Orbital Speeds" coded by Toti

                         Version 2: For Celestia 1.6.0 and later
********************************************************************* 
********************************************************************* 

  2 OBJECTS RELATIVE INFO for CELESTIA
  
  Displays relative Distance, Longitude and Latitude, as well as, speeds:
  Total, Radial, Transversal and Angular.
  

  INSTALATION INSTRUCTIONS:

  Unzip the file 2ObjectsRelativeInfov2.zip and copy the file 2ObjectsRelativeInfov2.celx 
  to your Celestia\Scripts folder.

  USING INSTRUCTIONS:
 
  Press Shift+P to set the currently selected object as the reference object (parent object).
  Press Shift+S to set the currently selected object as the object of interest (son object).

  Press Shift+M to mark/unmark son and parent objects.

  Press Shift+V to set observer in the optimal position and orientation
  with respect to parent and son objects.
  Press it again to allow for free rotation and movement of the observer.

  Press Shift+D to change the unit of distance.

  Press Shift+T to toggle the display of technical (non-physical) information.