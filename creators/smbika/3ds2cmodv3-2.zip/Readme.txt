Hi All,

I had wanted to contribute more to Celestia than the complaints I have posted in the forum and since I had no good ideas for add-ons and 
do not have the .NET (version 7) environment to modify the Celestia source, this seemed to be the most logical option.

I have written a Windows GUI wrapper for the 3dstocmod and cmodfix utilities that Chris Laurel has provided for converting 3ds models to the cmod 
format and subsequent tweaking thereof. The original utilites are command line and quite useful but I have become a lazy frell since my last UNIX/Linux 
gig and am too used to pressing buttons and checking boxes. Besides, the command line environment is so much friendlier in those OS's I would just as 
soon stay out of DOS.

So....this utility should fit the bill. Simply unzip the file into whatever directory you wish and take it from there. The interface is painfully simple
and includes all the parameters known for the original command line programs and tries to be as accomodating as possible. It should be serially reusable
and allow you to freely navigate to any model directories on your system. 

A few notes:

- Given this is a work in progress (meaning I have tested it but that does not mean it won't fail) - please report any errors or gotchas
to me at: smbika@aol.com.

- The output of the two commands are still directed toward temporary DOS windows when they execute and the windows may disappear way to quickly to
catch any warning or status messages they may generate. I am working on this. I know there is a utility to wrap Dos apps called QuickWin on the Code Project 
website (http://www.codeproject.com/dialog/quickwin.asp) which DOES capture and keep but this utility but still it requires manual input and command execution 
virtually identical to the original usage of the two utilities which is what I was writing away from. So, you may wanna double check any dubious results by 
just issuing the commands in the originally intended fashion to obtain these. Sorry, but as I said, I'm working on it.

- It seems that the cmodfix options -a and -b (output ascii or output binary) are not meant to be used in conjunction with the other fix-it parameters even
though this is not explicit in the readme.txt found in the cmodtools directory (http://www.shatters.net/~claurel/celestia/cmodtools/) so I have written the
app to prevent their inclusion when selecting any other options and vice versa.

- I have included the 2 dlls required for the two utilities to work - zlib.dll and libpng1.dll.

- I have made no effort (yet) to validate the smoothing angle - if you enter anything incorrect (like a non number or invalid angle) it will do what it does...
gonna fix it in the next release if one is called for.

Well, that's all the caveating I can think of at the moment. Let me know if this is of any value to you as well as any problems discovered and any improvements
you may think of...

Thanks,
Sean McGhee

Change history:

version 3-1:

(as to versions 2 and 3 - don't ask!)

- added the capability to change the output file name and location for the converted/fixed model.

- added the ability to select all fix parameters instead of making them mutually exclusive with the -a or -b switches. This was an misperception on my part as I must have been issuing the commands incorrectly from the DOS prompt and kept getting the -usage message (which is the reminder the program gives you when you are doing it wrong!)

-added tool tips - THAT was fun...

Thanks,
Sean
