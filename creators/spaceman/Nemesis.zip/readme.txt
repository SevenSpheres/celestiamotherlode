

                                                               Nemesis


   Informations: This addon will install Nemesis, a hypothetical red or brown dwarf orbiting the Sun about 50,000 to 100,000 A.U. away. This star was
   originally postulated to exist as part of a hypothesis to explain a perceived cycle of mass extinctions in the geological record, because the gravity
   of Nemesis could periodically disturbs comets in the Oort cloud, causing a large increase in the number of comets visiting the inner solar system
   with a consequential increase in impact events on Earth. This addon will add Nemesis and a fictional planetary system to make it more interesting.

   Guide: Just drop the "Nemesis.stc" and Nemesis planets.ssc" files to the "extras" folder. Then open Celestia, press ENTER, type "Nemesis" or "Death Star",
   ENTER again and G. For more informations about Nemesis, right click to Nemesis and select "info".

   Copyright and copyleft: Fell free to use my addon as you like but if you want to use my addon to create a new addon, sent me a message to let me know
   and don't forget me at the credits. Stealing somebody's hard work is not a good idea. No commercial uses please!

   Credits: I wanna thanks MKruer, Dollan and selden for their opinions about Nemesis at the shatters.net forum. Also a big thanks to the creators of
   Celestia :-)

   Warning: This addon will use only default textures from Celestia and Nemesis is a static star, no orbiting around Sun because we don't know the orbit
   of Nemesis (if Nemesis really exist). Also if you want a realistic universe with only what we know and without proposions e.t.c., just don't use it.