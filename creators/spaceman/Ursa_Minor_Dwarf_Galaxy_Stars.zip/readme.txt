

                                                               Ursa Minor Dwarf Galaxy stars


   Informations: If you have the 1.6. version of Celestia, you can put new stars beyond 16.000 light years away from the Sun. In fact, you can put stars
   at the rest of the Milky Way galaxy and at the nearest galaxies like the Andromeda Galaxy. This addon will install about 10.000 stars at the
   Ursa Minor Dwarf Galaxy. The Ursa Minor Dwarf dwarf elliptical galaxy was discovered by A.G. Wilson of the Lowell Observatory in 1954 and it is part
   of the Ursa Minor constellation and a satellite galaxy to the Milky Way. The galaxy consists mainly of older stars and there appears to be
   little to no ongoing star formation in the Ursa Minor Dwarf galaxy. This addon will allow you to explore this galaxy with plenty of stars inside it.
   However it will not add planetary systems, nebulas, binary star systems, so feel free to motificate my addon as you like :-)

   Guide: To install it, just drop the "Ursa Minor Dwarf.stc" file at the "extras" folder. Then open Celestia, press ENTER, type
   "Center of Ursa Minor Dwarf Galaxy", ENTER again and G to go directly to the galaxy. Then... explore the galaxy!

   Copyright and copyleft: Fell free to use my addon as you like. I would like to see somebody to enrich the galaxy with nebulas e.t.c. based on my
   addon :-D But please if you want yo use my addon to create a new addon, sent me a message to let me know and don't forget me at the credits.
   Stealing somebody's hard work is not a good idea.

   Credits: Special thanks to the creators of Celestia for the creating such a beatiful programm. Also special thanks to Rassilon, the creator of the
   "Globular Cluster Generator" that i use it to create this addon.

   Warning: The HIP numbers of the stars are from 90000000 to 90009999. If you have stars with HIP numbers between 90000000 and 90009999, the addon
   may not work right.