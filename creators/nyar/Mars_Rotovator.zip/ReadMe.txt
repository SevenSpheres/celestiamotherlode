nyarlath@mindspring.com

This addon represents a Rotovator (rotating orbital tether) in orbit around Mars.  I built it to simulate how such a device might look and function.  There's a lot of misinformation about rotating tethers and I wanted to simulate one to get a clearer idea of the look and feel of being literally pulled up into space by what is essentially a "cosmic winch".  As I suspected the look and feel is spectacular.  What is great is the amazingly gentle ride into orbit you get from one of these things.  Due to mating issues with the lowering 'skyhook' and rising shuttle I've had to use a strict epicycloid/hypocycloid timing ratio which gives a speed difference between the tether end and the martian surface but a real rotovator could be set to come down to the surface at 0 velocity.  This is an updated version with many additional features such as a moving service cabin and a de-orbit system with a smaller shuttle on one of the tether arms. Just ignore the shuttle when it climbs back up the tether. ;) There are a couple of inaccuracies. Since a craft released by the rotovator has 115% escape velocity it's not coming back without pilot intervention.  So I've modeled a simple circular path for a demo release/docking at one of the rotovator ends. Actually docking with the end of a moving rotovator at over escape velocity is rather risky. Better to ride down the Phobos station hanging tether and release at the end, circularize your orbit with attitude jets, dock with the central rotovator station, and then ride the rotovator tether to an appropriate jump off point. It's rather complex but very energy efficient. The total orbital energy of a ship at the Phobos hanging tether end is the same as in circular orbit at the rotovator station but I can't model that in Celestia without the trouble of a script file. So I've used an 'epicycle' device to simulate the encounters. It works at either end but I wouldn't trust the orbits anywhere but at the encounter points. The same goes for the shuttle docking between the Deimos and Phobos tethers. They will work in theory. This is my second revision and includes more shuttles and an extra elevator cabin to illustrate how a tether transportation system might work.  For more info on rotovators and other tether systems check out: http://en.wikipedia.org/wiki/Tether_propulsion or read  H. P. Moravec's 'A Non-Synchronous Orbital Skyhook' 23rd AIAA Meeting, The Industrialization of Space San Francisco, Ca., October 18-20, 1977.

Installation: To use the addon simply unzip and put the M_rotovator file in the Celestia extras subdirectory. There is a M_rotovator.ssc file with model and texture folders in it.

Some of the cabins and ships are not visible under the solar system browser, but you can always find them with the Select Object and Go To Selection commands under Navigation.
The following list may help you out:
M_Shuttle1
M_Shuttle2
M_Shuttle3
M_Shuttle4
M_Shuttle5
M_Shuttle6
M_Shuttle7
M_Shuttle8
M_Shuttle9
M_Shuttle10
M_Shuttle11
M_Cabin1
M_Cabin2

I wish to thank Thomas Guilpain (t_guilpain@hotmail.com) for the use of modified components for this addon of his Earth Space Lift addon which is posted here at Celestia Motherlode. And I also wish to thank him for his encouraging words. I wish to also thank Rob Sanders (rhas@chello.nl) for the use of the X-2010 NASDA Shuttle model and wish to thank Selden Ball, Jr. (seb+wbCINDXb@lepp.cornell.edu) amd Re(i)mbrandt(reimbrandt@freenet.de) for the use of their wonderful Chesley Bonestell style moonship and Mars passenger shuttle, all of which are posted here as addons at Celestia Motherlode. Thanks guys.

License: This addon is free to use for non-commercial entertainment purposes. Just give me and the original creaters of the models credit for our work. 

Note: 
These files are fictional, and do not represent real spacecraft.

Disclaimer:
Neither the author nor any party involved in creating, producing, or delivering this addon shall be liable for any direct, incidental, consequential, indirect or punitive damages or any damages whatsoever arising out of your access, use, or inability to use this addon, or any other errors or omissions in the content thereof. It is your responsibility to take precautions to protect yourself from trojan horses, viruses, worms or other items of a destructive nature.

nyar
