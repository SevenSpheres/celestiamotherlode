This addon is based on the 1962 MEC-1 Prototype Map of Mars, 
the last official map to show canals.  2 years later the Mariner 
flyby destroyed that dream forever.

This is the Mars Percival Lowell imagined and Edgar Burroughs
wrote about, a dying civilization struggling to bring water
from the poles to the remaining cities.  The glint of canals and irrigation ponds are all that's left of mighty oceans.  
There's another ssc file added that is intended to give this 
fantasy world a decent "hurtling" moon, in the form of a 
relocated Ceres that I've dubbed Meres.  

You can delete it if you wish for scientific accuracy.

Simply unzip and put the entire MarsRetro folder into your Celestia/extras folder.  An other approach is to copy the 
.ssc code in the mars-retro.ssc to the end of an another mars alternative surface addon such as the excellent mars-green 
addon by edawan and then simply add the three texture jpg 
files to that addon's medres subdirectory.  That gives you three alternate versions of Mars. 

Sorry about the blank poles but the MEC-1 map only goes to the 60 degree line. If anyone has a comparable map that goes to the poles please post it.  The glistening canals and martian city lights were done in paint so they're not the best quality.  Maybe someone can improve on them.  Have fun.     

