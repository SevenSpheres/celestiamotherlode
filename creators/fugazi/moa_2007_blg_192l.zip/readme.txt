To install, simply extract this entire package into your Celestia\extras directory. 

To view, just use the ENTER-TYPE NAME-ENTER method to get to MOA-2007-BLG-192L. Type in "moa-2007-blg-192l" an press "g".

MOA-2007-BLG-192L is estimated to be about six percent of our sun�s mass, which is just below the mass needed to 
trigger and sustain nuclear fusion in its core, making it a brown dwarf. This also marks the lowest mass star yet 
found to hold a planet, with �MOA-2007-BLG-192Lb� coming in at approximately 20% of the star�s mass. 
It orbits at about the same distance as Venus from our sun, but the star is so dim 
(anywhere from 3,000 to a million times fainter than our sun) that from just solar 
heating alone the planet�s atmosphere would likely be colder than the surface of Pluto. 
Astrophysicists studying the MOA-2007-BLG-192L system have crunched the numbers and offered the 
optimistic suggestion that the planet not only holds a thick atmosphere, but that it has a surface covered 
by a deep ocean heated from inside by radioactive decay. This interior heating could give the planet a 
surface temperature as balmy (in the astronomical sense) as Earth. On the flip side of the coin, MOA-2007-BLG-192Lb 
could just be a giant rock and ice version of Mercury. 
This discovery is very exciting because it implies Earth-mass planets can form around low-mass stars, which are very common.

So, I created a earth-like planet, which is nearly covered by an ocean. It has a distance of 0.62 AU from the parent star.

MOA-2007-BLG-192Lb was first mentioned in the �The Astrophysical Journal� in May 30 2008
