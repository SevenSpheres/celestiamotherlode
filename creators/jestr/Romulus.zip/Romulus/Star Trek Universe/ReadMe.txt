Unzip and place in your 'extras' folder.I have placed all my Star Trek addons in a folder 'Star Trek Universe' 
in my extras folder,and then have all the different addons (Romulus,Cardassia etc) in this folder.
The original model for the Uss Costitution was made by Jason 'Vektor' Lee (see enlosed RTF file),
the Warbird model was made by Ed Giddings (see Warbird RTF for more details),
the Warbird 2 model was made by William Burningham (converted to 3ds format by Eric Timmermans).
I have changed some or all of the original textures for these models.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Romula  
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
Any problems Email me jestr@ntlworld.com