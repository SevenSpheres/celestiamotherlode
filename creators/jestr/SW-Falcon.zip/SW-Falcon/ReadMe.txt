You will need to install Thomas Guilpain's 'Star Wars' addon first for the ssc to work
you can get it here http://members.fortunecity.com/guilpain/  look in the download section
Then its probably best to unzip this folder to extras/Starwars folder.
This model was made by Iven Connery with textures by Sebastian Hirsch and downloaded from
 www.scifi 3d.theforce.net 
Ive changed it a bit for it to work in Celestia and had some help with the textures from Martin Charest
Any problems Email me jestr@ntlworld.com