Jestrs Star Wars Basic package
==============================

This is a slightly modified and resurrected basic package of Jestrs Star Wars add-on.
It contains Tatooine, Endor and Death Star. This package is required for the most
other Star wars add-ons by Jestr.

The following modifications were mady by Ulrich Dickmann (Adirondack) in December 2012:
- correct folder structure
- fixed ssc file

Please make certain that you extract the contents of this package to the
...\Celestia\extras\ folder!

When you unzip this package using your zip program (e.g. WinZip), click on "Extract"
and select the main folder of Celestia (...\Celestia\) as the target directory.
Make sure that you activate the option to "Use subfolders" (or similar option) while
un-packing. All files will be copied into the correct Celestia subfolder(s).


You may want to fix the planet maps (they do not map to a sphere) and fix the
"Specular reflection" on the meshes (they are very shinny - mirror like).

If you have no clue how to fix this just run the add-on as it is.

