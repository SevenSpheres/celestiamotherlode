To install in Celestia-just unzip to your 'extras' folder.This model was made by Stefan Richter and came
 from Stargate3D.com website.I have made new textures for it though.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   HIP 29524  (including middle space)
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
Any problems Email me Jestr@ntlworld.com