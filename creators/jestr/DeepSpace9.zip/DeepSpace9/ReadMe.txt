Unzip and place in your 'extras' folder.This beautiful model was made by Joerg Gerlach (see enclosed
Readme for more info).
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Bajor B  (including middle space)
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
any problems Email me jestr@ntlworld.com