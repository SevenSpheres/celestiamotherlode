To install in Celestia,just unzip to your Celestia/extras
folder.Then to see it working,go to Mars,right click on
the planet and select
Alternate Surfaces-m46shaded_dds
Thanks to Mario from Space-Graphics (check out
http://www.space-graphics.com/ )for this very
beautiful texture.
Any problems email me jestr@ntlworld.com