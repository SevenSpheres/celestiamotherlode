To install in Celestia-put the models in your 'models' folder and the textures in your 'medres' folder.
Then you must edit your 'solarsys.ssc' to point to my models (I have included what I have in my 
'solarsys.ssc' to help with this).The models are made using the original math models and smoothed a bit
to remove some of the seams.The textures are made using existing textures blended with some others
to add a little (fictional)detail,to see these in Celestia-right click on the moon and choose AltSurface.
Thanks to Jens for his coloured 2k textures of Phobos and Deimos.
Any problems Email me Jestr@ntlworld.com