You will need to install Thomas Guilpain's 'Star Wars' addon first for the ssc to work
you can get it here http://members.fortunecity.com/guilpain/  look in the download section
Then its probably best to unzip this folder to extras/Starwars folder.
Unfortunately I have no clue as to who made this model I think I downloaded it from www.theforce.net/scifi3d
but none of the models on the site now look like this one-if anyone can tell me let me know.I have changed
all the textures which makes it harder to find the original author.Any problems Email me jestr@ntlworld.com