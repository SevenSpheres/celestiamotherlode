This model was made by Eric Petersen (see enclosed readme for more info) and downloaded from 
 http://wolf359a.anet-stl.com/trekmesh.html,I have altered the textures a little,I have it as 
part of my Vulcan system in Celestia.
Any problems Email me jestr@ntlworld.com