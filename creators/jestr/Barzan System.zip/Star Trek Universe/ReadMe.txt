Unzip and place in your 'extras' folder.I have placed all my Star Trek addons in a folder 'Star Trek Universe' 
in my extras folder,and then have all the different addons (Romulus,Cardassia etc) in this folder.
The USS Constitution model was originally downloaded from 
http://scifi3d.theforce.net
and was made by Jason Lee (Vektor) I have changed the textures a little.
The Voyager was made by Flat Eric,and downloaded from 
http://www.startrekaustralia.com
I have also included the ReadMe's of the original artists who made these 
lovely models,for more info read enclosed text/rtf files.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Barzan
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
any problems Email me jestr@ntlworld.com