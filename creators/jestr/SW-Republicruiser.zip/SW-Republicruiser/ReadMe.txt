You will need to install Thomas Guilpain's 'Star Wars' addon first for the ssc to work
you can get it here http://members.fortunecity.com/guilpain/  look in the download section
Then its probably best to unzip this folder to extras/Starwars folder.
This model was made by Burningham studios (I think) and downloaded from www.theforce.net/scifi3d.
I have changed the textures a little though.Any problems Email me jestr@ntlworld.com