Make sure you have my Denorios Belt addon first or the ssc will not work,then to install
just uzip to your 
  extras/Star Trek Universe/Denorios Belt   folder.The model was originally made by Skye Dodds
(see enclosed HTML file for more info),and came from the startrekaustralia.com site.I had 
to totally remake the textures though as the ones that came with it were only bump maps 
and masks,which dont show in Celestia.Hope you like it,any problems Email me jestr@ntlworld.com