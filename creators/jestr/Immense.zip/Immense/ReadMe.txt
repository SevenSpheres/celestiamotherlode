The Immense model was made by Nir Schneider(see enclosed readMe for more info),I have changed a lot of 
the textures though,and added the NXo5 model made by Floodcasso (see readMe).I have it as part of my
Vulcan System but of course you can use it how you like.Any problems Email me jestr@ntlworld.com