You will need to install Thomas Guilpain's 'Star Wars' addon first for the ssc to work
you can get it here http://members.fortunecity.com/guilpain/  look in the download section
Then its probably best to unzip this folder to extras/Starwars folder.
This model was made by Olivier Couston (Dr Jones) with textures by Jose Gonzales Pareja,it was downloaded
from www.theforce.net/scifi3d.Any problems Email me jestr@ntlworld.com