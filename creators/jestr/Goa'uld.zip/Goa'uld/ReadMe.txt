The Pyramid model was made by Stefan Richter and came from Stargate3D.com website.The mothership started
off as the Breen warship model made by Thomas Bronzwaer-downloaded from www.sfc3files.com .I have made
 new textures for them both though.Any problems Email me Jestr@ntlworld.com