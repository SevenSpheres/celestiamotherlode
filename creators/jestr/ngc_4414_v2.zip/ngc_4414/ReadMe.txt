Version2 of this addon is made to work with Celestia V1.4.0 and later.
To install in Celestia simply unzip to your 'extras' folder.
If you cannot use DDS textures you must open the 'ngc_4414.dsc' file
with your favourite text editor (eg Notepad) and comment out the

   Mesh "ngc4414_dds.cmod" line, 

and remove the # from the beginning of the

#   Mesh "ngc4414_png.cmod" line.

So your  'ngc_4414.dsc' file should now look like this

Nebula "NGC 4414"
{  
#  Mesh "ngc4414_dds.cmod"
   Mesh "ngc4414_png.cmod"
   RA 12.4408
   Dec 31.2236
   Distance 6.954e+07
   Radius 6.45e+04
   InfoURL "http://simbad.u-strasbg.fr/sim-id.pl?Ident=NGC 4414"		
}

Image courtesy of Hubble Space Telescope.
Any problems Email me jestr@ntlworld.com