If you already have my JMII DDS VT,you will have the ssc file to get this working in Celestia,just move 
JNormal DDS folder and JNormal DDS.ctx file to your
Celestia/extras/JMII DDS/textures/hires  folder,then when you right click on Earth and select AlternateSurfaces
-JMII DDS this will show the surface texture along with the normal texture (graphics card permitting).
If you have a different surface texture  then you should edit the ssc for this texture to include the line
NormalMap "JNormal DDS.ctx"
I made this VT from data available at this website 
http://edcdaac.usgs.gov/gtopo30/gtopo30.asp
I have exaggerated the height slightly (and the original data already has the height exaggerated 3 times).
Any problems Email me jestr@ntlworld.com

