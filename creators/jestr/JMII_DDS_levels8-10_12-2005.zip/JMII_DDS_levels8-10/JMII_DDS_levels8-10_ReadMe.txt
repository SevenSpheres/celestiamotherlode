I am making these tiles to go with my JMII DDS VT of Earth.
To install just unzip the level folders to your
JMII DDS/textures/hires/JMII DDS   folder (where levels 1 to 4
are kept).If you have no level folders for levels 5 to 7 then
create some (even if they are empty).Obviously there is still
work to be done tidying the transition from levels 5 to 8.
All the tiles have been compiled with the help of NeilF 
from thousands of images from Multimap.com.uk.
Any problems Email me jestr@ntlworld.com