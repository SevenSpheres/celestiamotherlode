You must first download my 'Alien Universe' addon.Then unzip this and put the 'hires' folder in your
Celestia/extras/Alien Universe/textures  folder.
Then put 'livenumrings.png' in your
Celestia/extras/Alien Universe/textures/medres folder though it might be a good idea to move the 
existing medres version first just in case your graphics card cannot handle the hires version. 
Note these are all PNG format you may have to edit 'Alien Universe.ssc' to get all to work.
Any problems Email me jestr@ntlworld.com