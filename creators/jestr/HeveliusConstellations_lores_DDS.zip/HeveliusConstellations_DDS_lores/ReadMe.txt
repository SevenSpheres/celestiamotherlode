To install in Celestia,simply unzip it to your Celestia/extras folder and turn on Nebula rendering.
These very beautiful drawings of the constellations were created by Johann Hevelius and published
in his atlas 'Uranographia' in 1690,for all of the constellations drawn see this website.
http://www.brera.unimi.it/old/HEAVENS/ATLAS/hevelius.html
The images I have used in this addon have come from the Hubble site here
http://hubblesource.stsci.edu/sources/illustrations/constellations/
as they are the largest I could find and have been 'cleaned ' for use in this kind of software.
So far though they have only done the ones in this addon-I will add more as they make them available.
Please let me know if you see any more posted on this site (see Email addres below).
To align them with the stars I have used images from this website
http://www.astrosurf.com/jwisn/constellations.htm
because they have already used the Hevelius images for the job.
Any problems,tips or suggestions Email me jestr@ntlworld.com