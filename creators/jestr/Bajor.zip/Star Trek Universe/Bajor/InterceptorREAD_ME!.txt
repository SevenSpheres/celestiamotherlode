BAJORAN INTERCEPTOR


14th, June 1999
By Brian Sayler A.K.A el'riQ
http://www.3dlinks.com/elriq/
Email: elriq@startrekmail.com

Bajoran Interceptor Mesh by el'riQ (Brian Sayler)

This mesh is based on the Bajoran Interceptor, piloted by Major Kira, in the DS9 episode where they formed a blockade of Bajoran ships standing against a fleet of ROmulan Warbirds.

Use Winzip to unzip the Max Scene into the 3dmax/scenes directory and the map files into a new folder, called Bajoran, inside the Maps directory of of Max. 
=====================================================================

Use of this model in any way is constitutes agreement with the following.

1> Any images rendered with this model will be labeled with appropriate credit to the author, Brian Sayler

2> You will not redistribute this model without this text document.

3> You will not use this model in any commercial form, or distribute it in any form without written permission from the author, Brian Sayler.



=====================================================================
THIS IS THE MOST IMPORTANT PART!!!  READ IT CAREFULLY.
  =====================================================================

These models are being distributed as FREEWARE, meaning I hold the "copyright" to my work, but am 
allowing you to use it without  charge as  long as copyright CREDIT to Paramount Communications, 
Viacom, and the author is noted in productions/animation�s using this data set.

Not one part of this data set has originated nor has been obtained in any form, direct or indirect,  in part 
or in whole, from Paramount Communications, Viacom.  They are the exclusive copyright holders to 
their original models and/or data sets and do not claim authorship to this independent work of the 
author.

USE OF THIS DATA SET CONSTITUTES THAT THE USER AGREES THAT USER CANNOT 
LEGALLY CLAIM NOR IMPLY THAT SAID DATA SET REPRESENTS IN ANY FORM THE  
ABOVE  NAMED  ENTITIES  AND  MUST  NOT  USE DATA SET TO INFRINGE DIRECTLY 
OR INDIRECTLY UPON THE RIGHTS OF THE  ABOVE  NAMED  ENTITIES NOR USE DATA 
SET FOR COMMERCIAL OR FOR-PROFIT PURPOSES.

Creation of this data set was strictly for personal, self-educational purposes and is NOT intended to 
infringe upon any original  material or concept copyright held by the above named entities.

This document MUST accompany the distribution of this  data set. This archive MUST remain 
UNALTERED during distribution.

