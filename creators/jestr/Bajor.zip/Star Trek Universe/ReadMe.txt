Unzip and place in your 'extras' folder.I have placed all my Star Trek addons in a folder 'Star Trek Universe' 
in my extras folder,and then have all the different addons (Romulus,Cardassia etc) in this folder.
The spacecraft model was not made by me but I spent some time changing it for Celestia,
for more info about it see the other enclosed text file.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Bajor
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
any problems Email me jestr@ntlworld.com