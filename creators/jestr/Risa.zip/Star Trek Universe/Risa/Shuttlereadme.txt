Type 9 Suttle by Staffan "Squapper" Norling.

You may use this model for personal  purposes. This model is NOT public domain. Its freeware and you may not sell it or in any way make any money with it. You must provide credits to the author when you're using it. Simply write "Shuttle by Staffan Norling" with small (but readable) text in the corner of your image. Send me a mail if you want to use it for other purposes, like having it downloadable on your site, etc. and we can discuss it.

Squapper@scifi-art.com


Please visit SCIFI 3D <www.theforce.net/scifi3d/>
for rules governing use, display of credit, and copyright information.