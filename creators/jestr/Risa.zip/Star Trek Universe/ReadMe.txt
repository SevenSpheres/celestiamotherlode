Unzip and place in your 'extras' folder.I have placed all my Star Trek addons in a folder 'Star Trek Universe' 
in my extras folder,and then have all the different addons (Romulus,Cardassia etc) in this folder.
The models of the starbase and the shuttle come from 
http://www.startrekaustralia.com/
The Starbase model started out as Starbase 99 mesh and was made by Cyril 'Tachy' Lefevre,
the shutttle 9 mesh was made by Staffan Norling,for more info on this read enclosed text,html files.
Martin Charest helped me with the textures for the starbase.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Risa A  (including middle space)
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
any problems Email me jestr@ntlworld.com