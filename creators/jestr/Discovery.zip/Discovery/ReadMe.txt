The original model was made by Matthew Parker and came from   www.strafe.com/2001/
but I have changed it dramatically and added some textures with help from Martin Charest.
The ssc came from Frank Gregarios 'Spacecraft from 2001' download pack,which you can find here
http://www.fsgregs.org/celestia/
Just unzip it to your extras folder.Any problems Email me jestr@ntlworld.com.