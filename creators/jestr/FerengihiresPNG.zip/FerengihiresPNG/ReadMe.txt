You must first download my 'Ferengi' addon.Then unzip this and put the 'hires' folder in your
Celestia/extras/Star Trek Universe/Ferengi/textures  folder.
Please note that most of these textures are PNG format and you will have to edit the 'Ferenginar System.ssc'
to use some of them in Celestia (and have a good graphics card/system).
Any problems Email me jestr@ntlworld.com