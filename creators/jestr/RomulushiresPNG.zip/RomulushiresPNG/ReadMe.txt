You must first download my 'Romulus' addon.Then unzip this and put the 'hires' folder in your
Celestia/extras/Star Trek Universe/Romulus/textures  folder.
Please note that these textures are all PNG format though and you will have to edit the 'Romulan Star Empire.ssc'
to use some of them in Celestia (and have a good graphics card/system).
Any problems Email me jestr@ntlworld.com