Before running Celestia after installing this addon in your extras
folder you must copy or cut the 
jpleph.dat   file from the new_horizons_dds/data folder and put it in your
Celestia/data folder,otherwise Celestia will not run.Jestr