To install in Celestia-you must first download my JestrEarth JPG addon (or equivalent JPG VT texture),
then copy the level6,level7,level8,level9,and level10 folders to your
Celestia/extras/JestrEarth JPG/textures/hires/JestrMarble JPG  folder (where levels0-5 are).
I have used images from various different sources for these levels,mostly
http://earthetc.com/imagery.aspx  for US cities
and
http://www.multimap.com/map/home.cgi?client=public&overviewmap=GB  for south UK
I hope to do the whole of UK (or as much is available at Multimap) at some point but the textures are 
huge at level10 detail and a little difficult to manipulate to fit with Blue Marble texture
(as you can see at the moment the Isle of wight is not correctly aligned with the Marble texture)
Any problems Email me jestr@ntlworld.com
