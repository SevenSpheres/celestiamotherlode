Unzip this to your Celestia 'extras' folder.I have included the Barzan.stc file is this is the star
 I have put Voyager in orbit around.If you already have my Borg+Wormhole addon,the same stc file is 
included in this so its probably better to delete this copy and put everything in the Barzan system 
in the same folder,I have also included the ReadMe of the original artist who made this lovely model,
any problems Email me jestr@ntlworld.com