To install in Celestia-simply unzip to your 'extras' folder.Image courtesy of Hubble Space Telescope.
Any problems Email me jestr@ntlworld.com