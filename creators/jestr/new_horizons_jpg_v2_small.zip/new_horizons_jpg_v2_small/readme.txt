To install in Celestia,simply unzip it to your
Celstia\extras\   folder.
You will find that during 2015 you have 2 Pluto's in Celestia,but the xyz
version is more accurate than the standard orbit definiton.
The model was created by Joseph Firestine (website-www.be3d.org )
and textured by me Jestr.
Any problems Email me jestr@ntlworld.com
