To install in Celestia-just uzip it to your extras folder.
The model was made by me Jestr using images of the craft and
instruments available on the web.The orbit data (venus express.xyz)
came from the JPL Horizons computer,though I altered it a little to
make the spacecraft orbit Venus instead of crashing into it
occasionally.I have also added labels for the different instruments
on board which should allow you to study the spacecraft easier,
if you wish.
Any problems Email me jestr@ntlworld.com