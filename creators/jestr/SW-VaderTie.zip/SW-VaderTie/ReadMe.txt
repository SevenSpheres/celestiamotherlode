You will need to install Thomas Guilpain's 'Star Wars' addon first for the ssc to work
you can get it here http://members.fortunecity.com/guilpain/  look in the download section
Then its probably best to unzip this folder to extras/Starwars folder.
This model was made by Staffan Norling and James Bassett and downloaded from www.theforce.net/scifi3d.
I have changed it slightly.Any problems Email me Jestr@ntlworld.com