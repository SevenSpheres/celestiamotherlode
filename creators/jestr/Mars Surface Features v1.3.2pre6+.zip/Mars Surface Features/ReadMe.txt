The ssc is designed to work in Celestia v1.3.2 pre6 or later and will not work with earlier versions.
To install in Celestia-just unzip to your 'extras' folder.The height of these volcanos is exaggerated
quite a bit.Ive used the Space-Graphics m46 texture to make the textures for these models,though I 
changed the hue slightly.If you want to change textures,you must match the correct part of your texture 
to mine and then make sure it has the same name and format.
Any problems Email me jestr@ntlworld.com