This model was made by Michael Powell with textures by BJ West,I had help also from Martin Charest with
the textures.The ssc comes from Frank Gregario's 'Spacecraft from 2001'addon which you can find here
http://www.fsgregs.org/celestia/
Any problems Email me jestr@ntlworld.com