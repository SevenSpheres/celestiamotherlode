This model was created by D.Proctor
Find it here
http://members.ozemail.com.au/~dproc/sulaco.htm