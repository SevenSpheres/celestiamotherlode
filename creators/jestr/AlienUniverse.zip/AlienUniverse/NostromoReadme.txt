The USCSS Nostromo Was created in Lightwave 7.5 by Lee James Medcalf (aka Lightwave7871) and was completed on 13th Dec 2002.

Original Ship design by Ron Cobb. Original filmed model by Martin J Bower. 
"The Nostromo" and all associated elements and references to the film "ALIEN" are copyright Brandywine Entertainment and 20th Century Fox (c)1977

This Model is for public use and distribution only. Images created using this object must either contain a credit to me within the image or within any accompanying text. Any use of this object for commercial use is strictly forbidden without express written permission by myself.

If you wish to contact me regarding commercial use of this object please e-mail me at : Lee.Medcalf@Turner.com or alternatively at Lee.Medcalf@Btinternet.com

I have included in this zip the generic panels targa file that is used on the model but this is exactly the same as the one included in the standard install of Lightwave and all rights to this texture are reserved and owned by Newtek Inc.

I included it incase you had deleted it or had not installed it, if this is the case please extract this file to your Images\space directory within your lightwave folder.


I hope you enjoy this model as much as I did making it.....


Lee James Medcalf
aka Lightwave7871

16/12/02
