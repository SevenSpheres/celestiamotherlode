The E1-Narcissus Was created in Lightwave 7.5 by Lee James Medcalf (aka Lightwave7871) and was completed on 19th Nov 2003

Original Ship design by Ron Cobb. Original filmed model by Martin J Bower. 
"The Narcissus" and all associated elements and references to the film "ALIEN" are copyright Brandywine Entertainment and 20th Century Fox (c)1977

This Model is for public use and distribution only. Images created using this object must either contain a credit to me within the image or within any accompanying text. Any use of this object for commercial use is strictly forbidden without express written permission by myself.

If you wish to contact me regarding commercial use of this object please e-mail me at : Lee.Medcalf@Turner.com or alternatively at Lee.Medcalf@NTLWorld.com

I hope you enjoy this model as much as I did making it and as ever thanks to all the guys at LWG3d.org for their encouragement.....


Lee James Medcalf
aka Lightwave7871

19/11/03
