Unzip and place in your 'extras' folder.
The Nostromo and Narcissus models were made by Lee James Medcalf,the Sulaco by D.Proctor,see enclosed 
text files for more details
To get there in Celestia-
1.press 'enter/return' key
2.Type in   zet2 ret  (including middle space)
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
any problems Email me jestr@ntlworld.com