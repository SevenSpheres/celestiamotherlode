This addon is made to work in Celestia v1.3.2 or later.To install in Celestia-just unzip to your 'extras' folder.
The model came from http://hubblesource.stsci.edu/sources/modelbuilders/
but I had to do a lot of work fixing holes and remade large parts of it.The textures I made myself,
except the hubsolar.jpg which was made by Terrier (Celestia forum) I think.
Any problems Email me jestr@ntlworld.com