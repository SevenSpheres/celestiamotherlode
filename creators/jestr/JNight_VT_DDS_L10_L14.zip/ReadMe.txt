If you already have my JMII DDS VT,you will have the ssc file to get this working in Celestia,just move 
JNight DDS folder and JNight DDS.ctx file to your
Celestia/extras/JMII DDS/textures/hires  folder,then when you right click on Earth and select Alternat Surfaces
-JMII DDS this will show the surface texture along with the night texture (dont forget to turn on night lights 
in the render menu).
If you have a different surface texture  then you should edit the ssc for this texture to include the line
NightTexture "JNight DDS.ctx"
I made this VT from the night texture available on Nasa's Visibleearth website,I have added some noise  to the 
lights to give them a bit more variation.
Any problems Email me jestr@ntlworld.com