Unzip and place in your 'extras' folder.I have placed all my Star Trek addons in a folder 'Star Trek Universe' 
in my extras folder,and then have all the different addons (Romulus,Cardassia etc) in this folder.
The planet textures were made from the Nasa Blue Marble by me,the models both come from 
www.startrekaustralia.com.
the klingon model was originally made by Eric Peterson,but I have changed it a little and had help 
with the textures from Martin Charest.The Klingon Klalath model was originally made by A.'Spy' Ehler
See the enclosed text files for copyright,credits,more info.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Klingon   
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
Any problems Email me jestr@ntlworld.com
