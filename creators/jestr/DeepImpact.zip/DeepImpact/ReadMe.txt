To install in Celestia just unzip to your 'extras' folder.
Make sure you have no other definitions for comet Tempel 1
,as this may cause problems.If you can't display DDS textures
you should edit the Tempel 1.ssc to point to the JPG texture 
instead.
For the best view of the explosion-goto 'Deep Impact',
set the time for 06:00:00 Jul 04 2005,rotate until you have 
comet Tempel 1-xyz in view and wait for the impact around 06:01:03.
The impactor model came from Jack Higgins website here
http://homepage.eircom.net/~jackcelestia/spacecraft_helio.htm
The orbiter model I made myself based on the cardboard cutout
model available here
http://deepimpact.jpl.nasa.gov/disczone/models.html
The xyz's came from the JPL Horizons Telnet service.
Any problems Email me jestr@ntlworld.com 