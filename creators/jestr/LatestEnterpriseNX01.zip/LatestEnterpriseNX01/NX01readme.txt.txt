Enterprise NX-01 created by Andrew Smith in Lightwave 6.5 Dec/Jan 2002

This is the controversial Enterprise design for the latest series from the Trek franchise, a design based on the Akira class cruisers from the later TNG era films.  This model comes as a DAT file as it's actually a multi-layered object, it's not some bizarre compression as far as I can work out, and will load straight into Lightwave 6.5 or greater with no trouble.

File also contains...

dreadhull.jpg
goldreflection.jpg
1701A_saucer.jpg

I reduced these from 1.5meg TGAs to save rendering memory and webspace.  As jpegs they take up much less room and the difference in quality is negligable at any decent sized render.

This design is copyright Paramount Pictures and Star Trek:Enterprise and any attempt to use this mesh for profit or gain without expressed permission of the copyright holder and the artist could lead to prosecution for copyright infringment.  For home/non-profit use only, and please give a namecheck to Andy when you use this is your work.

www.axeman3d.com
Lighting rig and setup scene added Jan 2004 by The Axeman

Author of mesh-
andy_s@bigfoot.com