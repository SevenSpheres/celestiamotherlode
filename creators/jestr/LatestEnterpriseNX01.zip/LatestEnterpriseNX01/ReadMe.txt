This model was made by Andrew Smith (see NX01readme for more details),I have had help from Martin Charest
with the textures.Any problems Email me jestr@ntlworld.com