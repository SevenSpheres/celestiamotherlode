To install in Celestia,simply unzip it to your
Celstia\extras\   folder.
The model was created by Joseph Firestine (website-www.be3d.org )
and textured by me Jestr.
Any problems Email me jestr@ntlworld.com
