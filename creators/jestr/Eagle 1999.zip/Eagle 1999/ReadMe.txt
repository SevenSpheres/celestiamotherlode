These models will only work properly in Celestiav1.3.2pre6 or later- you will have to change ssc for
 them to be in right place with earlier versions.I made the model of Plato crater but the model of the
Eagle was made by James Murphy and came from www.space1999.org,Martin Charest helped with textures. 
Any problems Email me Jestr@ntlworld.com