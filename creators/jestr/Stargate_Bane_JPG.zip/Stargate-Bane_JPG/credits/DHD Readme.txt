readme.txt


Author: Dan Huling aka "Ziroc"
Email : ziroc@tgeweb.com


Homepage Since 1993: www.tgeweb.com

Project: v1.0 Stargate Dial-Up Device (DHD)
Designed In: Truespace3 v3.1 (If I did it in TS4,  TS3 users couldn't load it)... Works fine in TS 4.0-4.3 though!
Project Start Date Nov 15, 1999
Release Date: Dec 28th, 1999


[RULES AND STUFF:]

You can use this model all you want, put it up for download, ect.. All I ask is ya give me credit, like a link to my email address (above)
and my Homepage (Also Above) Please Remember, You CANNOT sell this or put it on any type of media for resale without asking
Dan Huling aka Ziroc (ziroc@tgeweb.com).

[Comments:]

Another Day, another Model! <g>, this one was easy, just been busy these few Weeks with Xmas and all...
I'll be updating this one again soon, but its a pretty much finished product.. Not much to this one - was easy to model.

As Always, Enjoy! and treat Hamsters with Honor! (hehe)


This Mesh is Dedicated to My Cat Charly, 1980-1997 - And Chocolate, My new Cat of 2 years!