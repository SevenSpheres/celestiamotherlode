You must first download my 'Klingon' addon.Then unzip this and put the 'hires' folder in your
Celestia/extras/Star Trek Universe/Klingon/textures  folder.
Please note that most of these textures are PNG format though and you will have to edit the 'Klingon Empire.ssc'
to use some of them in Celestia (and have a good graphics card/system).
Any problems Email me jestr@ntlworld.com