You will need to install Thomas Guilpain's 'Star Wars' addon first for the ssc to work
you can get it here http://members.fortunecity.com/guilpain/  look in the download section
Then its probably best to unzip this folder to extras/Starwars folder.
This model was made by James R Bassett and used to work perfectly in Celestia.In recent versions
however the pilot has disappeared for some reason.I have altered the thickness of the windows and 
this has fixed it.Any problems Email me jestr@ntlworld.com