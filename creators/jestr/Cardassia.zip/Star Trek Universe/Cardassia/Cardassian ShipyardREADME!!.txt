Please give proper credits in either pictures or animations
that uses this mesh!
Thank You!

Also i would like to see Pictures or Animations with my 
Models, so it would be very kind if anybody who uses it may
email me :D

Model: Cardassian Dominion Shipyard V1
3ds Max 4.2

by I_E_Maverick

eMail: I_E_Maverick@gmx.de

Now go and some kickass art with my baby! :D

