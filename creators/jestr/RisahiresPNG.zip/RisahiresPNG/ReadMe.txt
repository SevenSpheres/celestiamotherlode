You must first download my 'Risa' addon.Then unzip this and put the 'hires' folder in your
Celestia/extras/Star Trek Universe/Risa/textures  folder.
Please note that these textures are all PNG format though and you will have to edit the 'Risa System.ssc'
to use some of them in Celestia (and have a good graphics card/system).
Any problems Email me jestr@ntlworld.com