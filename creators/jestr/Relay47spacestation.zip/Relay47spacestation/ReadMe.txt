This model was made by Mateen Greenway (see enclosed readme for more info),I have had help from Martin
Charest with the textures.Any problems Email me jestr@ntlworld.com