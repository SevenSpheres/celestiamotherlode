To install in Celestia,just unzip to your 'extras' folder
 but check if you already have any other Cassinis in your
'extras'.I have tried to make this fictional trajectory 
for Huygens as close to the projected targets as possible
but If anyone else can come up with a better xyz file
Email me jestr@ntlworld.com