To install in Celestia-unzip and put 'Mars m46shaded VT' folder in your 'extras' folder.
Too see it in Celestia you must right click on Earth and select
Alternate Surfaces-m46shaded JPG
it is a little slow in loading the different levels but well worth the wait.
I made this VT from Mario's beautiful 16k m46 shaded texture.The original can be found at 
http://www.space-graphics.com/m46_shaded.htm
Although at the moment there is only 8k version available,it is 180 degrees out for Celestia.I have altered the
hue ever so slightly.If you have my 'Mars Surface features' addon,this is the texture I used to make the textures
for the volcanoes.
I have included in the ssc ,a line for the inclusion of my Normal texture,it should work fine without having
 this installed,but if you download it put it in the 
Celestia/extras/Mars m46shaded VT/textures/hires  folder together with the ctx file.
Any problems Email me jestr@ntlworld.com
