
READ ME
The Cassini_Huygens descent and landing Version 1.1
------------------------------------------------------------




jestr: 19. December 2004, Version 1.0
------------------------------------------------------------
To install in Celestia,just unzip to your 'extras' folder
 but check if you already have any other Cassinis in your
'extras'.I have tried to make this fictional trajectory 
for Huygens as close to the projected targets as possible
but If anyone else can come up with a better xyz file
Email me jestr@ntlworld.com





rthorvald: 18. July 2005, Version 1.1
------------------------------------------------------------
Changes from v.1.0:

1 - Fixed all filenames and paths, now set to lowercase
2 - Re-textured the parachute
3 - Added the updated Cassini trajectory (05.05.05), by jestr
4 - Re-wrote the SSC file to eliminate duplicate spacecraft names
5 - Added the placeholder file to facilitate (4)
6 - Re-converted all models from 3ds to cmod format

Compability:
---------------
This AddOn is incompatible with the following other AddOns:
- The Cassini_Huygens descent and landing, by jestr (V.1.0)
- Postcards From Titan, by rthorvald
- Cassini-Huygens Mission XT, by Adirondack

Copyright:
---------------
Any copyright i might have to the contents of this package
is hereby transferred to jestr, without reservations.

Copyright for contents of this package by jestr, 2004 and 2005,
unless specificially stated otherwise by him.


Runar Thorvaldsen, 18.07.05
Contact: thpost@thorvaldsen.net
http://runar.thorvaldsen.net/celestia/



