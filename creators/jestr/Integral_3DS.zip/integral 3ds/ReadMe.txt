This file was downloaded from Selden Ball's wonderful Celestia Resources site here,
http://www.lns.cornell.edu/~seb/celestia/
and I have given the model a makeover and added a few textures.I have had problems 
with the 3ds version in Celestia 1.3.2 pre 11,and recommend downloading the cmod version
if you are using this version of Celestia.It seems to work fine in 1.3.2 pre8 though.
Any problems Email me jestr@ntlworld.com