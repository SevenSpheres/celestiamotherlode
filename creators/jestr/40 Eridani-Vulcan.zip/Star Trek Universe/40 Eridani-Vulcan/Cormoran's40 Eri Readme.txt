Hello

To use the 40 Eridani system, unzip the texture files into Celestia/textures/medres, and the ssc 
file into Celestia/extras

If there are any problems, please drop me a message on the Celestia Forum.

'Constructive' criticism greatly appreciated, and remember, its only my first system :o)

Best Regards,

Cormoran 