Unzip and place in your 'extras' folder.I have placed all my Star Trek addons in a folder 'Star Trek Universe' 
in my extras folder,and then have all the different addons (Romulus,Cardassia etc) in this folder.
The beautiful DS9 model was made by Joerg Gerlach but I spent some time changing it for Celestia,
for more info see the other enclosed text file.The 1701-D was made by Chris Setterington converted to 3ds by Erik Timmermans.
Dont forget to turn on Galaxy rendering to see the full beauty of the Denorios Belt.
You may wish to view it in the dark as the plasma field is not very luminous.
To get there in Celestia-
1.press 'enter/return' key
2.Type in   Denorios A   (including the middle space)
3.press 'enter' again
4.press 'G' for Goto
5.Use navigation menu to explore more.
Deep Space 9 and 1701-D,can be found orbiting Denorios C.
Any problems Email me jestr@ntlworld.com