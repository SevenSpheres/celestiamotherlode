For Celestia v1.3.2 or later.To install just unzip to your 'extras' folder.
The best way to explore these nebulae (I think) is to select the central star
from each nebulae and navigate around these.
For IC 4604-this is Rho Oph
For IC 4605-this is 22 Sco
For IC 4606-this is Antares
For Sig Sco (sh2-9?)-this is Sig Sco
I guess they're not very accurate but they look great.
Any problems Email me jestr@ntlworld.com