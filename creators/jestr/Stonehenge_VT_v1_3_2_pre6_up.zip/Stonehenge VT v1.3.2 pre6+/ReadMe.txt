Just unzip this to your 'extras' folder.If you have a JPG Earth VT texture installed you may wish 
to move the level 10 folder to your VT folder.Level 10 however will work even if you dont have an Earth
 JPG VT installed-When you are at Stonehenge,right click on Earth (not Stonehenge) and select Alternate
Surfaces-Stonehenge.The level10 tiles were made from images at www.multimap.com.This model is made for 
Celestia v1.3.2 pre 6 or later.
Any problems Email me jestr@ntlworld.com 