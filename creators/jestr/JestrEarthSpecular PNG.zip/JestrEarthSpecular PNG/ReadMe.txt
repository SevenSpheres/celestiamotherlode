If you already have my JestrMarble JPG VT,you will have the ssc file to get this working in Celestia,just move 
JestrSpecular PNG folder and JestrSpecular PNG.ctx file to your
Celestia/extras/JestrEarth JPG/textures/hires  folder,then when you right click on Earth and select Alternat Surfaces
-JestrMarble JPG this will show the surface texture along with the specular (graphics card permitting).
If you have a different surface texture  then you should edit the ssc for this texture to include the lines
SpecularTexture "JestrSpecular PNG.ctx"
SpecularColor [ 0.35 0.5 0.55 ]
SpecularPower 15.0
and move the JestrSpecular PNG folder and JestrSpecular PNG.ctx file to your hires folder.Obviously the colour 
settings are fairly subjective so change them to suit you.
This VT was made from the landcover.E.21600x21600.gz and landcover.W.21600x21600.gz files available here
ftp://mitch.gsfc.nasa.gov/pub/stockli/bluemarble/
though I made some changes by hand to match in with my texture and to uncover lots of little islands especially in the
Pacific (and Hawaii).I made a JPG version also but the file size was much the same so it didnt seem worth it.
Any problems Email me jestr@ntlworld.com
