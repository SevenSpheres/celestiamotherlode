How to install:

Place this addon into the extras folder.

then in celetsia, click go to and enter:  PK 164+31.1

any questions go to Caninegardener87@aol.com