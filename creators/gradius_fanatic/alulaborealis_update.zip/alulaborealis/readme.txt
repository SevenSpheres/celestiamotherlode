Gradius III System.

To install, simply extract this entire package into your Celestia\extras directory. 

To view, just use the ENTER-TYPE NAME-ENTER method to get to Alula Borealis, then use Celestia's Solar
System Browser under the Navigation Menu in order to view all of the objects included in this system. 

The Gradius III system, Located around the star Alula Borealis. This is home to the Gradians, a peaceful Human-like species who
are colonized on the Planet Gradius. Every century or so, the poor Gradians are attacked by an evil race, the Bacterions, who 
attempt to take over their planet, along with the rest of the entire solar system. The Gradians thus have no choice but to launch
the Vic Viper, a one man fighter ship that is capable of light speed. To rid themselves of the Bacterions invading their planet
and all of their other planetary neighbors, the Vic Viper had to be launched.

Questions, about this system, including any way you attempt to use it OTHER than in Celestia goes to caninegardener87@aol.com.

Please note that this add-on is still under development. Some models (the Vic Viper, and some of the system's unique asteroids)
have not yet been created. 