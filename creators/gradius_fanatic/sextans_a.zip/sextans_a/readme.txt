This addon adds lots of fictional stars to the dwarf galaxy Sextans A.
I have tried to arrange the blue star clusters as they appear in telescope
photos.

To install, place this addon into your "extras" folder.

Any questions go to caninegardener87@aol.com