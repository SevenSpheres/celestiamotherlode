How to install...

Place the ssc file into the the main alula borealis folder.

Place the textures into textures/medres in the alula borealis folder.

place the model file into the models folder in the alula borealis folder.


Any questions go to caninegardener87@aol.com