how to install:

This addon requires the Tandrixis galaxy addon from the motherlode.


Place this folder INTO the Tandrixis addon folder, it should still work.