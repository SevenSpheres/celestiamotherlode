How to install...

The custom template, named am0644.png goes in the MAIN models folder in the 
main Celestia directory, otherwise the addon will not work properly, 

everything else goes into the Extras folder.