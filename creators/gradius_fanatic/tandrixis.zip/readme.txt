How to Install:

This folder goes into your Extras folder in Celestia.

Any addons created for this galaxy by other users can be dropped into
The Tandrixis addon folder as well.

Any questions go to caninegardener87@aol.com