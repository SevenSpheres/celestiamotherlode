How to install:

This file goes into the extras folder in Celestia


With the latest SVN release of Celestia 1.6, it is now possible to place
stars BEYOND the 16 Kilo Light year boundary.  This addon places
20,000 fictional stars inside the Sculptor Dwarf galaxy, to go to the 
addon, simply go to Sculptor dsph that celestia renders in its 
galaxy dsc file.