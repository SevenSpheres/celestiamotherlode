Make the following changes to Solarsys.SSC in order for the addon to take effect:

Texture "saturn2.*"  add saturn2 into "medres" folder


under atmosphere, add:

CloudHeight 5
Cloudspeed 100000
CloudMap "saturnclouds.*"

Add cloudmap into "medres" folder

there is also a 2k saturn file included in case you want the enhanced colors, but not the storm