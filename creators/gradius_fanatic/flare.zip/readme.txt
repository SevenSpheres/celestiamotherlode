How to use this file:

Simply place into the main Textures folder....but not into the Medres,
hires,or lowres folders

be sure to save the original flare file that you alredy have, in case
you aren't satisfied with this one.