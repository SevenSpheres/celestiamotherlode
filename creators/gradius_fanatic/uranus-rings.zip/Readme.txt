This addon for uranus's rings belongs in the lores area of the textures folder
be sure to save the original copy of uranus's rings to another location.(in case you want to use it again later)

The rings in this addon have been edited with smoother edges and a blue-green appearance.

Problems, E-mial me at  edwardcscd@aol.com