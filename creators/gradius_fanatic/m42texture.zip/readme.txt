How to use:

This is simply a texture replacement for Praesepe's m42 addon.

The texture in the hires folder in this package is 4K, the one in medres
is 2K

Save a copy of his texture file somewhere just in case you dont like this
one, and place the image from this package in the m42/textures/medres folder
instead.

questions go to caninegardener87@aol.com