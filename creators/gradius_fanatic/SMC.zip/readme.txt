How to install:

The SMC folder goes into the Extras folder, and adds 500,000 stars to
the SMC galaxy, questions go to caninegardener87@aol.com