How to install...


Place the dsc file and the folders into the Sextans A star folder, which should
be in the Extras folder.

Remember that this nebula addon requires a pretty fast computer for it to run
smoothly.

questions go to caninegardener87@aol.com