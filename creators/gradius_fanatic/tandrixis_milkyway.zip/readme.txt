How to install:

This addon requires the Tandrixis galaxy addon

and this folder goes into the Tandrixis addon folder.