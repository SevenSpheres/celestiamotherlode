This is a fictional planet system located near the 3D M20 addon that was 
made by Bob Hegdewood and me.


How to install:

This folder should be extracted into the Extras folder.