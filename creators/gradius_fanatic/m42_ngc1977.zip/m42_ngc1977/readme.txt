How to install:

simply add this folder into the Extras folder in Celestia


NOTE:  a pretty fast computer is required for this addon!

Questions go to caninegardener87@aol.com