How to install:

this addon goes into the Extras folder in Celestia.

Any questions go to caninegardener87@aol.com