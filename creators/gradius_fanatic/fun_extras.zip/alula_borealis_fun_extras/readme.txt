These files are for amusement purposes only, and are Music files of the
worlds in the game, and can also serve for exploring the Gradius III
system in Celestia. Credits go to the Original music files
on the site:  www.laurasmidiheaven.com 
All i did was fix them not to sound so hard 
and make them sound more sci-fi.  

And the Video clips are of the game itself, played by expert gamers, and
give you the chance to see the Gradius III game that inspired this addon.