Instructions:

Just extract into "medres" folder, but be sure to save original texture first, just in case you're not satisfied with this texture.