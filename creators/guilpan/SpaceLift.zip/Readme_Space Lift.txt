Thomas Guilpain
t_guilpain@hotmail.com

Description : 
Here is the model of a space lift, a 550m wide orbital station at a geostationary orbit (36000 kms) linked to the Earth by 36 lifts of 1000 kms long and with a diameter of 50m. Each section are bound to the others by a small station which might be used to correct the orbit of the space lift.
The reason why I split the lift into 36 parts is that I like it best to be able to look at the Earth from different altitudes and feel as if you were really going at 36000 km above its surface. The other reason is that using a cylinder 720000 times longer than its diameter caused some instabilities in Celestia, it was shaked and you can still see this by looking at the intersection between the stations and the lifts (toggle wireframe mode ctrl+w) but it is not so strong anymore. 

Copyright : The wheels that can be seen at each part of the main station were inspired by Kubrick's "Space Odyssey" and the two "Mars Express" spaceships by some Starwars spacecraft I found on the Scifi3D site (www.theforce.net/scifi3d). I also found the main part of the textures on this site and I just renamed and resized them.


Install :
unzip the file into your Celestia directory

It will install the following files :
Celestia\extras\Space Lift.ssc
Celestia\models\Station.ssc
Celestia\models\Palier.ssc
Celestia\models\Tube.ssc
Celestia\textures\medres\dcs_02.jpg
Celestia\textures\medres\iss-mc1.jpg
Celestia\textures\medres\Stat_01.jpg
Celestia\textures\medres\Stat_02.jpg
Celestia\textures\medres\Stat_03.jpg
Celestia\textures\medres\Stat_04.jpg
Celestia\textures\medres\Stat_05.jpg
Celestia\textures\medres\Stat_06.jpg
Celestia\textures\medres\Stat_07.jpg
Celestia\textures\medres\Stat_08.jpg
Celestia\textures\medres\Stat_09.jpg
Celestia\textures\medres\Stat_10.jpg
Celestia\textures\medres\Stat_11.jpg

