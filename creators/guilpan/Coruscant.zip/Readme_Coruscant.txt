Thomas Guilpain
t_guilpain@hotmail.com

Description : 
The file starwars.zip contains textures and ssc file for the Starwars planet Coruscant. All its orbital elements are fictitious and I made it orbit the planet HD 143761 also known as Rho Crb.

Copyrights : 
These Coruscant textures are properties of Topa (of Scifi3D). All I did was to rearrange some textures under Photoshop to gave them a more detailed look. 
I found all these textures on the Scifi3D site (www.theforce.net/scifi3d) and they kindly gave me the permission to release these textures for Celestia, so if you like them please take a look to their other resources, they got tons of great stuff !

Install :
unzip the file into your Celestia directory

It will install the following files :

Celestia\textures\medres\Coruscant.jpg
Celestia\textures\medres\coruscantnight.jpg