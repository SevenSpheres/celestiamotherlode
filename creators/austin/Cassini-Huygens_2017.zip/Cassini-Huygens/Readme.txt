Update to Jestr's Cassini-Huygens Addon
=======================================


Description
-----------

Jestr created a wonderful model for both the Cassini spacecraft and Huygens probe.  The trajectory data for both of these objects, however, needed to be updated as the latest update to Cassini-Huygens has not been done in 6 years on the Celestia Motherlode website.  Jestr's addon with the models for both Cassini and Huygens may be found here:

http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=604

A brief summary of what this update provides:
 o  True replacement of Celestia's default Celestia-Huygens as nothing has been changed in Celestia's "Solar System Browser".
 o  The latest (as of May 2017) trajectory data for Cassini and Huygens.
 o  Each of Cassini's missions around Saturn are depicted with its own timeline.
 o  Cassini's trajectory ends at the exact moment Cassini hits Saturn's cloud tops.
 o  Much improved and fairly accurate animation of Huygens' descent and landing on Titan - including its rotating speed and directions.
 o  Cassini's trajectory optimized to give a very accurate position at the moment of many moon and Saturn flybys (read more below).



Development of Cassini's Trajectory
-----------------------------------

First, a special script was created to optimize Cassini's trajectory to within a relatively small margin of error.  Almost one million data points were analyzed to produce an efficient trajectory containing less than 20,000 data points for all of Cassini's nearly 20 years of operation.  At moments when the trajectory requires more data points (when the spacecraft takes a dramatic turn), the XYZV file contains enough data points to ensure a proper depiction of the trajectory at that moment.  When the spacecraft is traveling in a relatively straight course, far fewer data points are used.

Second, Cassini's flybys of Saturn's moons and Saturn itself were carefully analyzed.  Each moment was calculated, and the data point for that particular exact moment was included in the XYZV file.

For the following 17 moons, the exact moment Cassini came within 100,000 km from the moon was included in the XYZV files (a total of 497 points for all these moons):
Atlas, Calypso, Dione, Enceladus, Epimetheus, Helene, Iapetus, Janus, Mimas, Pandora, Pan, Phoebe, Prometheus, Rhea, Telesto, Tethys, Titan

For the following 6 moons, a few really close flybys of interest were found and included in the XYZV files (A total of 12 points):
Aegaeon, Daphnis, Hyperion, Methone, Pallene, Polydeuces

Also, for the last 22 orbits of Saturn (typically known as Cassini's "Grand Finale"), the exact moments Cassini makes its closest approaches to Saturn were also included in the last XYZV file.  For each orbit, data points for both the closest geocentric and geodetic height above Saturn were included.

All of the above described helps provide a very accurate depiction of Cassini's trajectory while keeping the data size to a reasonable level.



Instructions
------------

1. Find Celestia's "extras" directory which may be found in one of these two locations here in Windows:
      C:\Program Files\Celestia\extras\
      C:\Program Files (x86)\Celestia\extras\
2. Open the "Cassini-Huygens.zip" file and extract the "Cassini-Huygens" folder to inside Celestia's "extras" directory.
3. Done!



How to Use
----------

1. Start Celestia.
2. Under the "Navigation" top menu choice, select "Solar System Browser".
3. Find and select "Cassini" from the list.  (Or, may choose to select "Huygens" listed below "Cassini".)
4. Click the "Go To" button.
5. Click the "OK" button.



Fixing Huygens Detachment Location
----------------------------------

The main audience for this addon update is for the novice Celestia user using the 1.6.1 version of Celestia.  Simply following the instructions above on a default installation of Celestia will provide a wonderful experience.  However, there is one drawback.  Cassini's flyby distances and times for the moons of Saturn will not be so accurate.  This is due to the need to update the orbits for the moons.  Advanced users are encouraged to update the orbits for the moons of Saturn to get a more accurate depiction of Cassini's trajectory in relation to the moons.

However, one issue will be created if Titan's orbit is updated.  The detachment of Huygens will not be depicted very well.  This is due to Cassini's orbit is in reference to Saturn, while Huygens' orbit is in reference to Titan.  At the moment of its detachment from Cassini, Huygens may immediately be placed very far (maybe over 1000 km) away.  Instructions are included with this update to possibly help bring Huygens back to Cassini at the moment of detachment.  The process is very quick and easy.

Navigate to the "...\Celestia\extras\Cassini-Huygens\data\" directory, and find the "Huygens_Update.zip" file.  Within this ZIP file, find the simple instructions to replace one of the existing XYZV files.

Please note that this replacement of an existing XYZV file is not necessary.  It should only be done if the user wishes to improve the depiction of Huygens' detachment after updating Titan's orbit.



Summary of Main Events*
----------------------

>>> Cassini Main Events <<<

1997 Oct 15 09:26:09   Launch
1998 Apr 26 13:44:41   Venus flyby #1 (287 km)
1999 Jun 24 20:30:03   Venus flyby #2 (689 km)
1999 Aug 18 03:28:25   Earth flyby   (1200 km)
2000 Dec 30 10:04:22   Jupiter flyby (9,723,400 km)
2004 Jul 01 02:38:26   Enter Saturn's orbit
                       Begin "Primary Mission" (1st of 4 Saturn timelines)
                       Closest approach to Saturn until the final orbits in 2017 (19,960 km)
2004 Dec 25 02:00:00   Detachment of Huygens
2008 Jul 01 00:00:00   Begin "Equinox Mission" (2nd of 4 Saturn timelines)
2010 Oct 01 00:00:00   Begin "Solstice Mission" (3rd of 4 Saturn timelines)
2016 Nov 29 00:00:00   Begin "Final Phase of Solstice Mission" - AKA "The Proximal Orbits" (4th of 4 Saturn timelines)
2017 Sep 15 10:49:09   End of mission (Cassini enters Saturn's cloud tops)

>>> Huygens Main Events <<<

1997 Oct 15 09:26:09   Launched with Cassini
2004 Dec 25 02:00:00   Detachment from Cassini
2005 Jan 14 09:05:53   Enter into Titan's atmosphere
2005 Jan 14 09:10:23   Main parachute deployed
2005 Jan 14 09:10:53   Heat shield removed
2005 Jan 14 09:19:06   Huygens momentarily stops rotating before changing its rotation direction
2005 Jan 14 09:25:21   Main parachute separates and drogue parachute deployed
2005 Jan 14 11:24:21   Landing on Titan**

* All times in Celestia UTC.
  All distances are the distances reported by the default installation of Celestia.
  (Flyby time and distances may differ from actual values.)
**  Landing event based on NASA's ephemeris data which differs from the actual landing time of 11:38:11 UTC.
    Therefore, the actual landing site may differ than where it is depicted in Celestia.



Credits
-------

All credit for the models for both Cassini and Huygens goes to Jestr.
The model:   http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=604
The creator: http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=5

Trajectory source (JPL HORIZONS):
  http://ssd.jpl.nasa.gov/horizons.cgi

Huygens timeline and rotation references:
  https://www.nature.com/nature/journal/v438/n7069/full/nature04347.html

All other credit goes to NASA, JPL, European Space Agency, Italian Space Agency and others for their amazing work in creating and operating the real Cassini-Huygens spacecraft and probe!


-Austin
2017 May 24
