This is the Catenia System
It contains 6 planets, of which 1 is a double-planet, and two asteroid belts.
if you are afraid of this star ruining your perfect sky, dont worry.
Catenia is a fictional sun-like star placed some 150.6 lightyears from earth, in constellation Leo.
-
INSTALL:
copy this folder into your "celestia/extra" folder
and unzip it (or the other way around; doesn't really matter)
-
I hope you like it
-
If you wish to comment on this solar system, please i'd love to hear some critics (good or bad) on my work
-
This add-on may only be used with celestia software and is free to distribute.
If you wish to use this add-on in any other way than using celestia; please contact me:
joaquim-uruoca@hotmail.com or joaquim.filho56@gmail.com (I'm from Brazil)
(no spam please!!!!)