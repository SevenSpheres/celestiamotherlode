Este � o Sistema Catenia
Ele cont�m 6 planetas, dos quais 1 � um planeta duplo, e dois cintur�es de aster�ides.
Se voc� tem medo desta estrela atrapalhar seu c�u perfeito, n�o se preocupe.
Catenia � uma fict�cia estrela semelhante ao Sol a 150,6 anos-luz da Terra, na constela��o de Le�o.
-
INSTALA��O:
Copie esta pasta em "Celestia/extras"
e descompacte-a (ou o contr�rio, realmente n�o importa)
-
Espero que goste
-
Se voc� deseja comentar sobre este sistema solar, por favor, eu gostaria muito de ouvir algumas cr�ticas (boas ou m�s) sobre o meu trabalho
-
Este add-on s� pode ser utilizado com o software Celestia e est� livre para distribuir.
Se voc� quiser usar este add-on de qualquer outra forma usando o Celestia, por favor entre em contato comigo:
joaquim-uruoca@hotmail.com ou joaquim.filho56@gmail.com
(spam n�o, por favor!!!!)