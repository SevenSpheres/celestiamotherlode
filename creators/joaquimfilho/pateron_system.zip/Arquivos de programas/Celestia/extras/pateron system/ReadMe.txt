This is the Pateron System
It contains  1 double-planet and 1 double satelite.
If you are afraid of this star ruining your perfect sky, dont worry.
Pateron is placed some 25.5 lightyears from earth, in constellation Taurus.
-
INSTALL:
copy this folder into your "celestia/extra" folder
and unzip it (or the other way around; doesn't really matter)
-
I hope you like it
-
If you wish to comment on this solar system, please do as it is my first and i'd love to hear some critics (good or bad) on my work
-
This add-on may only be used with celestia software and is free to disribute.
If you wish to use this add-on in any other way than using celestia; please contact me:
joaquim-uruoca@hotmail.com or joaquim.filho56@gmail.com (I'm brazilian)
(no spam please!!!!)