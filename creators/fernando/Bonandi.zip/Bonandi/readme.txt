NEW PLANET FOR OUR SOLAR SYSTEM

by Fernando Casal, 2006.


Description:
This add-on contains a totally fictional new planet called Bonandi and its 2 moons, Naxis and aranus.
It is located between Mars and Jupiter.
Bonandi has a ring like Saturn but it is a small planet and it resembles the inner planets: Mercury, Venus, Earth and Mars. 
Bonandi has a green surface and an atmosphere. It suggests the existence of some type of "life". 
There is a small moon (Naxis) that gravitates inside the planets ring and it has a purple surface...
The larger moon (Aranus) gravitates outside the planets ring and has a big inclination...


I am working in a way to explain how this planet appeared in our solar system...





I HOPE YOU LIKE IT!





Installation: Extract this archive into the "extras" directory of your Celestia installation.

Contact: In case of problems with this add-on, contact me on (fernandocasal@netcabo.pt).

Textures: All textures are based on others in the Celestia Motherlode.

