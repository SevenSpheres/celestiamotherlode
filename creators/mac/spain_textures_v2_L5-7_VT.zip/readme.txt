Spain textures for Celestia v.2
-------------------------------

- Install instructions

Unzip this file in BlueMarble DDS dir, where dirs level0 to level10 are (BlueMarble DDS is on extras directory).

Textures created from satellite images of
http://visibleearth.nasa.gov/

- New features of this version v.2

Fixed the light displacement of the entire map that caused spec and night maps not to be shown properly with this textures
Added level 5 textures

You can use this freely for all kind of non-commercial activities.
If you use them for non-personal purposes, I would thank you if you let me know that. Just curious for seeing what could be the use of them.

Mac
celestia@mp-labs.com
www.mp-labs.com/celestia