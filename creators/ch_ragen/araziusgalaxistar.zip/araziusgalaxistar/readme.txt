######################################################################

The Arazius System

######################################################################

To Install:
Simply unzip in the extras/addons/ folder, load celestia, type Arazius and go.

######################################################################

This is an older system I made a while ago but is still pretty neat.

Arazius is a fictional star system around a G class star from the Tycho Catalogue, the star
lies about 117 ly from polaris.

The Arazius system is a a somewhat strange system with a gas giant and a terrestrial planet
located very close to the star. An asteroid belt lies outside Arazius II, 
and a terrestrial planet on the outside edge of the belt.  Theory is planet II migrated 
inwards pushing planet I in with it.  Afterwards with the leftover material in
the once bigger asteroid belt, planet III formed.  Two larger gas giants lie beyond planet III.

#####################################################################

This addon is for the GalaxiStar universe, for more information on GalaxiStar go to
http://galaxistar.googlepages.com

######################################################################

Please send me your comments:
galaxistar@gmail.com

and visit my site:
http://galaxistar.googlepages.com