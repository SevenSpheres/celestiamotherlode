######################################################################

The Orion's Paradise System

######################################################################

To Install:
Simply unzip in the extras/addons/ folder, load celestia, and type Orion's Paradise.

######################################################################

These are all 2k jpg textures, I reduced the quality in order to make the files smaller.
Go to my website if you want the high quality png files.

#####################################################################

This addon is for the GalaxiStar universe, for more information on GalaxiStar go to
http://galaxistar.googlepages.com

######################################################################

Orion's Paradise is a fictional star system near the Orion Nebula (M42).

The system was orginally going to be the Xi Pegasi system but I moved it out next to the
Orion Nebula to give it a cooler look.

######################################################################

Please send me your comments:
galaxistar@gmail.com

and visit my site:
http://galaxistar.googlepages.com