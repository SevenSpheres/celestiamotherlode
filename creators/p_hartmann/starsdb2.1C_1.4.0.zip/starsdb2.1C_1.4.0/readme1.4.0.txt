Conversion for Celestia 1.4.0 by Grant Hutchison

Directly converted from Pascal Hartmann's original stars.dat file
(Version 2.1 C) for Celestia 1.3.2 and earlier.

Additional processing:
Two duplicate stars removed, index numbers 118322 and 33672726.
Hip 114110 removed, since this "star" is an artefact. (See 
http://www.rssd.esa.int/SA-general/Projects/Hipparcos/catalog-errors.html)
Three stars were encountered with parallax = 0, implying an
infinite distance. These were suppressed during conversion.

Total number of stars remaining in converted file:
2072867

Grant Hutchison, September 2005


