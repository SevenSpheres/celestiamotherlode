
Fantasy Coloured Mars Texture 4k(4096*2048), size 1.4 MB

Before Proceeding you should backup (rename) your existing Mars texture from the
"C:\program files\celestia\textures\medres\ -the default installation directory
or from your current installation path
  
Just change the name of the existing file with a "old" or any prefixes -->old-mars.jpg
so that the current mars texture will be available to you to replace this one, if you doesn't like this one 

To install the Texture , just unzip into the the "celestia" installation directory
the texture will be automatically placed in textures-->medres directory

Original Texture From www.openuniverse.org of Ra�l Alonso 

Texture Edited By Adarsh.K
www.bluespace4u.com

