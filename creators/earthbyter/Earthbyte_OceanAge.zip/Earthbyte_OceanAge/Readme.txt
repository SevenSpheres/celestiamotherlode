Put the "Earthbyte_OceanAge" folder into your Celestia's "extras" folder.

Drop a copy of "OceanAge.cel" into CelestiaResources/scripts.

To run, open Celestia and either 1/ drag and drop "OceanAge.cel" straight into Celestia window, or 2/ in Celestia select the "File" dropdown menu, select "Scripts" and choose "OceanAge.cel".

Enjoy

Patrice for Earthbyte Research Group at the University of Sydney

Earthbyte.org