New Horizons

Attached are these files:

horizons.ssc   >   (put this file in the extras folder)
horizons.xys   >   (put this file in the data folder)
horizons.3ds   >   (put this file in the models folder)
Readme1st.txt  >   (it's this file)

This is the 1st revision of the model drawn by hand in AutoCad.
I fixed the colours a bit and resized the craft to its proper size in Celestia.
I also changed the starting date to Jan. 17 2006.

Any questions about it, I would be glad to answer them.

email:rns@mts.net
