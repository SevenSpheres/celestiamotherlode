--***************************************************************************
--***************************************************************************
--                         A tiny B-Spline library
--                    
-- 
--                            Coded by Toti
--                       For Celestia 1.3.2 and later 
--            
--***************************************************************************
--***************************************************************************

function buildNonUniformKnotsList(stepFunction, totalLength, tableEntries, curveOrder)
-- builds a table of non-uniform knots: step size is given by [stepFunction]
    local knotsLST    = {}

    local knots       = tableEntries + curveOrder 

    -- build the non-uniform knot vector:
    knotsLST[0]        = 0
    for i = 1, knots do
        if i <= curveOrder then
            knotsLST[i]        = 0
        elseif i > tableEntries then
            knotsLST[i]        = totalLength + 1
        else
            knotsLST[i]    = knotsLST[i-1] + stepFunction(i) 
        end
    end
    return knotsLST
end

function buildUniformKnotList(tableEntries, curveOrder)
-- builds a table of uniform knots: 
    local knotList    = {}

    local knots       = tableEntries + curveOrder 

    -- build the uniform knot vector:
    for i = 1, knots do
        if i <= curveOrder then
            knotList[i]        = 0
        elseif i > tableEntries then
            knotList[i]        = 1
        else
            knotList[i]        = i/knots
        end
    end
    return knotList
end

function N(K, i, ord, elapTime)
-- returns the blending factor for [elapTime] position along the curve, using [K] as knotList. Uses recursion:
    local blend, k1, k2
    if ord == 1 then                                        -- definition 1st case
        if K[i] <= elapTime and elapTime < K[i+1] then
            blend    = 1
        else
            blend    = 0
        end
    else
        k1    = i+ord-1
        k2    = i+ord

        if  K[k1] == K[i] and K[k2] == K[i+1] then                -- be careful with 'division by zero' errors 
                                                                  -- at the extremes
            blend    = 0
        elseif K[k1] == K[i] then
            blend    = (K[k2] - elapTime)  / (K[k2] - K[i+1]) * N(K, i+1, ord-1, elapTime)
        elseif K[k2] == K[i+1] then
            blend    = (elapTime - K[i]) / (K[k1] - K[i]) * N(K, i, ord-1, elapTime)
        else                                                -- definition 2nd case
            blend    = (elapTime - K[i]) / (K[k1] - K[i]) * N(K, i, ord-1, elapTime) + (K[k2] - elapTime) / 
                  (K[k2] - K[i+1]) *  N(K, i+1, ord-1, elapTime)
        end
    end
    return blend
end

function getSpline(knotList, ptsTable, elapTime, curveOrder)
-- returns the B-Spline value for [elapTime] position in [knotLST] knot vector:

    local splinedRecord        = {}

    -- hack: initialize our splined record:
    for k, v in pairs(ptsTable[1]) do
        splinedRecord[k]    = 0
    end

    -- and fill it with the blended data:
    for i, t in pairs(ptsTable) do
        -- let's pass 'curveOrder' as a parameter because of recursion:
        local blending    = N(knotList, i, curveOrder, elapTime)
        for k, v in pairs(t) do
            splinedRecord[k]    = splinedRecord[k] + v * blending 
        end
    end
    return splinedRecord
end
