STAR TREK UNIVERSE by Star Lion
http://www.starlionfiles.50megs.com or on the Celestia Motherlode:
http://celestiamotherlode.net/catalog/fic_startrek.html

This zip file contains files originally created by StarLion and updated for Celestia 
version 1.3.2 by Jeam Tag.

Install:
Place the folder "StarTrek" anywhere inside the Celestia extras directory.  
For more info about how to install Celestia add-ons please see 
http://www.lns.cornell.edu/~seb/celestia/addon-intro.html

To find the crafts and worlds:
- Orbiting the Earth: Entreprise-E & Space dock + Entreprise-A  
In extrasolar systems : 
Press return, type the name of the star, press reutrn again to select and "g" to go to.
- Around Vega, Borg Worlds: city-planet and moon, many Cubes, activated Shield, Cracked Moon with Borg Sph�re,
USS Voyager and Delta Shuttle orbiting this moon.
- Around Alsafi�: DS-9 Station, orbiting a little Wormhole


Original Readme, for Celestia before 1.3.1 version:

This is beta 1 of Star Lion's Star-Trek Universe!
Just put the bmp, png, and jpg files into the medres folder.
Put all the 3ds files into the models folder.
put all of the scc files go into the extras folder.
And put the favorites.cel file in the main celestia folder.

All of the Zip files in the "3ds Files" folder contain the models 
that My Star Trek Univers will use, the sub-folders contain split zip files, 
to un-zip these files download them all into the same directory, then you can unzip them with Winzip.

In the "SSC Files" folder you will find the Zip file that contains all of the ssc files that my Star Trek Univers.

And in the "Texturs" folder you will find the zip files that contain all of the textures necessary to run my 
Star Trek Univers properly.
Star Lion
