This is the Spacedock as seen in Star Trek III: The Search for Spock. Added are more ships in dock to give it a feel of a busy port. 
Included are spacedock shuttles flying about in the interior. Yes I know they all have the number 38 and this is because the mesh itself had the number and not a texture. 

To install: Unzip addon into your extras folder and select Spacedock in the solar system browser. Each ship in spacedock is a satellite instead of being part of the dock model. This is so you can select and view each ship or shuttle individually. 
There are two reference points labeled "0" and "1" They are the center points the dock shuttles orbit around. 

Thanks goes to Selden, tr00fi  and fungun for helping me out in regards to adding models to celestia. 


Credits. 

Spacedock mesh and textures by X_TheUnknown_X

USS Enterprise, Constitution class refit and USS Excelsior mesh and textures by WileyCoyote

USS Akiyazi and USS Oberth mesh and textures by Adonis

USS Hood and USS Dauntless by Lord Schtupp

USS Azumi mesh and textures by Zambie Zan. 
Azumi registry by Gina Ling

Spacedock shuttles by virtualkey08 and reused by me from fungun's Star Trek at Home Vol. 1

This addon is free to use by anyone. If you reuse any of the models in your addons please give proper credit to the authors. :)





Enjoy! 