Add-on: Tiangong 1 Space Laboratory Ver 1.0
============================================

This is a Celestia add-on. You can see Tiangong with this add-on in Celestia.

=Introduction=

Tiangong 1 is the primary form of the future space station of China. As in the movie Gravity, the Chinese Space Station will be called Tiangong. Of course, this add-on will not show you the "future" Tiangong in the movie Gravity, but a quite simply one, which is now orbiting above.

=How to use it?=

1. You should unzip this zip file first. That means you'll have to get an unzipping program. If you are using Windows XP or higher, the "explorer" can work as an unzipping program.
2. Unzip the "tiangong" folder to wherever you like (e.g. your desktop). If you do not know how to do this, simplily drag and drop it on the desktop.
3. Copy the folder to your add-on (usually the "extras") folder. Cut or Copy the folder you have just unzipped. Then, open your "Celestia\extras" folder which is located at "C:\Program Files" most of the time. Paste. 
4. Launch your Celestia, and that's finished.

=How to see it?=

1. Launch your Celestia.
2. Press "Enter".
3. Insert "Tiangong 1".
4. Press "Enter" again.
5. Press "g" for goto.
6. Now you can see the Tiangong.

=Rather Important=

1.This add-on requires Celestia 1.6.1 or higher.
2.As Tiangong was launched at "2011 9 29 13:16:03.507, UTC", you won't be able to see it before that. So, set your time "2011 9 29 13:16:03.507, UTC" or later. To do this, pull down the "Time" menu at the top and then adjust the time.
3.This add-on should not be used to predict the exact position of Tiangong. The orbit data is only approximately correct in a few days. Besides, Celestia defines the earth as a sphere, while the real shape of the earth is more complex.

=Author=

3D Model, Textures and Solar System Catalog (SSC file) by Hanghang0713, some rights reserved. Everyone is allowed to modify this add-on.
Contact me: hanghang0713@hotmail.com
Or:@hanghang0713 on Baidu

=Credits=
TLE source: http://celestrak.com/NORAD/elements/noaa.txt
Transformed into SSC format by using Grant Hutchison's spreadsheet. Available here: http://www.lepp.cornell.edu/~seb/celestia/hutchison/spreadsheets.html#2

=Enjoy!=
Hope you can enjoy this add-on. This is a kind of rough model. I'll improve it if possible in the future.