# MARS EXPRESS (2003- ) ESA

1/ 
Cruise Trajectory by Jack Higgins 
http://homepage.eircom.net/~jackcelestia/files/marsexpress.zip

2/ Model by JLeboutet
http://j.leboutet.free.fr/celestia/models/marsexpress.zip
With the two orbital trajectories of positioning that the probe borrowed to begin its work

3/ Infos:
(French)Nirgal: http://www.nirgal.net/mars_express.html
ESA: http://sci.esa.int/science-e/www/area/index.cfm?fareaid=9
3D Link: http://mex3d.free.fr/

(Like the author underlined it on the forum, it misses the connection between cruising and the orbits, 
but nobody has answered, IIRC)
