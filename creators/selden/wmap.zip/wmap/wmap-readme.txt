This Addon adapts two of the WMAP Microwave Sky maps (produced by the "NASA/WMAP Science Team") for use with Celestia v1.3.0 or later.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

This Addon displays the combined microwave map projected onto the inside of a sphere with a radius of about 13.8GLY. This is just slightly larger than the diameter of the observable universe, assuming a Hubble constant of 72 km/sec/Mpc.

Since the Q-band microwave map is dominated by radiation from our local Milky Way galaxy, it is projected onto the inside of a sphere with a radius of about 65K LY. This corresponds to the apparent extent of the disk of molecular hydrogen associated with our galaxy.


This Addon contains the Deep Space Catalog "wmap.dsc", which specifies both the Background and Q-Band objects. You may want to remove one of these declarations in order to minimize visual confusion.

If you look closely, you'll see a seam along 180 degrees of longitude. After many attempts to get rid of it, I just gave up. There seem to be some off-by-1 scaling errors in the tool I've been using to convert the WMAP Aitoff projections into simple cylindrical maps. They are very difficult to compensate for. 
===============================


See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
9 March 2004

===============================
Acknowledgements:

This DSC catalog file was generated from the WMAP image "The Microwave Sky" created by the "NASA/WMAP Science Team". See the Web page http://map.gsfc.nasa.gov/m_or.html for more information.

The maps were converted from Aitoff/Hammer projections to simple cylindrical projections using the freeware program "Iris" v4.12 by Christian Buil. See the Web page http://astrosurf.com/buil/ for more information.
