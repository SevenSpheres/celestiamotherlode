SDSS DR2 v2

This Addon for Celestia displays the locations of 243,673 selected galaxies from the Sloan Digital Sky Survey, second data release, with improved z precision. 

v1 of this addon only included 78,055 galaxies, with more limited z precision. Spurious alignments were visible in v1 due to the binning effects caused by that lack of precision.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

For convenience of observation, so the voids and walls can be easily seen, this Addon consists of the Deep Space Catalog "sdss-dr2-galaxies.dsc", which specifies 6 different model files. 

Three "fans" of the sky have been observed near the southern galactic pole
sdss-dr2-fan-s1.cmod  (15610 galaxies north of +5 degrees declination)
sdss-dr2-fan-s2.cmod  (21220 galaxies between +5 and -4 degrees declination)
sdss-dr2-fan-s3.cmod  (23305 galaxies south of -4 degrees declination)

Two "fans" of the sky have been observed near the northern galactic pole
sdss-dr2-fan-n1.cmod  (86015 galaxies between +5 and -5 degrees of declination)
sdss-dr2-fan-n2.cmod  (97523 galaxies north of +5 degrees declination)

Quasars in all of the fans which were included in the Galaxy category
sdss-dr2-0-360-qsos.cmod ( 8701 Quasars in all 5 fans)

You must have Celestia v1.3.2 prerelease 3 or later in order to be able to use CMOD model files.

===============================
Viewing the survey:

Unlike when one uses a separate model for each body, displaying tens of thousands of points that are part of the same model is highly efficient. Realtime changes of viewpoint are easy.

You can disable any or all of the models by inserting a "comment character" (#) in front of any of the Mesh declarations. When all of them are enabled, the voids and walls are hard to distinguish, since there are so many foreground and bacdkground galaxies. When only a few Meshes are enabled, it's easier to see them against the black background.


The HTML file ViewSDSSgalaxies.html provides several Cel:// URLs
to view the distribution of galaxies. It takes you to a distant viewpoints many Light Years away, looking toward the Sun.

No rights are asserted.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
8 April 2004

===============================
Acknowledgements:

This DSC catalog was generated from dsv files created using the SDSS SkyServer's Java applet.

The major constraints were redshift confidence >0.2 and 0.001 < z < 1. 

See the SDSS credits page at http://cas.sdss.org/dr2/en/credits/
