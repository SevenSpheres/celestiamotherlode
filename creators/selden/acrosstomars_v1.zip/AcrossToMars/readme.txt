Across To Mars -- Illustrating Bonestell in Celestia

by S. Ball (c) March, 2006
All rights reserved.
===========================

This Addon for Celestia displays some models and situations based on 
paintings by Chesley Bonestell.

If you restore this Zip file into Celestia's Extras directory, it should
recreate all of the directories and files necessary for it to work with
Celestia v1.4.1 or later.

The included HTML (Web) file contains Cel:// URLs which should take you
to viewpoints which are similar to some of Chesley Bonestsll's
paintings. They are not identical: getting all of the details exactly
the same would require much more effort.

Background
==========

In 1947, Wernher von Braun wrote a book titled "Das Mars Projekt." An English edition, "The Mars Project," was published in 1953 and a reprint is readily available.

In 1952 Colliers Magazine hosted a symposium on space flight, the results of which were published in their magazine. Spacecraft were designed by Wernher von Braun and illustrated by Chesley Bonestell and others.

Those spacecraft designs also were published in several books, some of which were "Across the Space Frontier," "The Conquest of Space," "The Conquest of the Moon," and "The Exploration of Mars."

Physical dimensions for many of those designs were published in the book "Spaceship Handbook" by Jack Hagerty and Jon C. Rogers.

This Addon consists of my interpretations of some of these spacecraft
and situations. 

One of the models, the RM-1, resembles a spacecraft which was designed 
by Disney for a TV special. I've included it because it was pictured
in the book "The Exploration of Mars" as the recovery craft used to 
fetch the explorers from HEO to LEO.

Credit
======

The models were created using Anim8or, a 3D design program by Steve
Glanville. Visit http://www.anim8or.com/ for more information.

The following books were used as references.

    * von Braun, W., The Mars Project, Illini Books Press, University of Illinois Press, USA, 1991
    * Ley, W., The Conquest of Space, Viking, New York,1949
    * von Braun, W., et al., Across the Space Frontier, Viking, New York, 1952
    * von Braun, W. et al., The Conquest of the Moon, Viking, New York, 1953
    * Ley, W., von Braun, W., The Exploration of Mars, Viking, New York, 1960
    * Miller, R., Durant, F. C. III, The Art of Chesley Bonestell, Donning, Norfolk, 1983
    * Hagerty,J., Rogers, J.,Spaceship Handbook, ARA Press, 2001 

This Addon was designed for use with Celestia v1.4.1 or later.
Celestia, an open-source realtime 3D astronomical visualization program,
was created by Chris Laurel with assistance by many others.
Visit http://www.shatters.net/celestia/ for more information.

The models were translated from 3DS into Celestia's CMOD format 
using utilities provided by Chris Laurel.


Limitations
===========

The models are quite simple and "low poly." I'm sure you can create
better ones.

The trajectories from Earth to Mars and return are fake. Although 
they have some of the appropriate characteristics, and arrive and 
depart on reasonable dates near the oppositions of 1965 and 1967, 
they are distorted circles rather than ellipses. 
 
Copyright and license
=====================

This Addon for Celestia was created by Selden Ball and is
copyright (c) March, 2006. All rights reserved.

This Addon may be freely redistributed for educational purposes.
All models and documents were created entirely by the author.
They may not be used for any commercial benefit without explicit
written permission by the author.

S. Ball
March 29, 2006
http://www.lepp.cornell.edu/~seb/
