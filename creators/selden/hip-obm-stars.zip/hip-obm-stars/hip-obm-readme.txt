This Addon shows the distribution of the positions of 69 O, 7101 B, and 3366 M stars listed in the Hipparcos catalog.

hip-o.stc is a star catalog that can be used with Celestia v1.3.0 or later.
If you unzip this archive into your "extras" folder, the star catalog will go into the right place.

The intent was to see if there is any obvious indication of the local galactic arm in the distribution of stellar positions. Since there were very few O stars in the sample, type B stars were presumed to be the best tracers of regions of recent stellar formation.
Type M stars were included just to see what the difference in their distribution might be.

This sample does not include stars which have errors in their parallax values estimated to be greater than 75% of the values of the parallaxes themselves.

The selected stars were given an AbsMag of -13 to make them clearly visible at inter-galactic distances. Brighter values tended to hide their spacial distribution.

Personal observations: 

B stars restrict themselves to the plane of the galaxy. There are essentially none to the galactic north and south of us, unlike the M stars. Their over-all distribution also seems to be an ellipsoid with its long axis approximately tangent to a circle around the center of the Milky Way. It seems likely to me that this effect is due to the relative density of bright stars within the local arm.

It also seems clear to me that the extremes of the distribution of the positions of stars seen in Celestia, which make it almost spherical, are due to errors in the measurement of the stars' parallaxes, not because those stars actually are that far away.


--Selden Ball 10Mar04

Acknowledgements:


This DSC catalog file was generated from the Vizier catalog "I/239  The Hipparcos and Tycho Catalogues (ESA 1997)"

See also http://astro.estec.esa.nl/Hipparcos/site-guide.html
and the Proceedings from the Hipparcos Venice '97 symposium
at http://astro.estec.esa.nl/Hipparcos/venice.html


