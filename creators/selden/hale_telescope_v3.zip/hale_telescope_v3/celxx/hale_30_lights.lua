--  lights on/off

-- ==========================================================
-- low lights

LowLightsOff = function ()
	local obj = celestia:find("Sol/Earth/200in/hale_dome_base_low_lights")
	obj:setvisible(false)
	local obj = celestia:find("Sol/Earth/200in/hale_low_lights")
	obj:setvisible(false)
	local obj = celestia:find("Sol/Earth/200in/hale_low_dome_lights")
	obj:setvisible(false)
end
LowLightsOn = function ()
	local obj = celestia:find("Sol/Earth/200in/hale_dome_base_low_lights")
	obj:setvisible(true)
	local obj = celestia:find("Sol/Earth/200in/hale_low_lights")
	obj:setvisible(true)
	local obj = celestia:find("Sol/Earth/200in/hale_low_dome_lights")
	obj:setvisible(true)
end


-- ==========================================================

cmds.HLLOFF = LowLightsOff
cmds.Hale_Low_Lights_Off = LowLightsOff
cmds.HLLON = LowLightsOn
cmds.Hale_Low_Lights_On = LowLightsOn

-- ==========================================================
-- high lights on/off

HighLightsOff = function ()
	local obj = celestia:find("Sol/Earth/200in/hale_high_lights")
	obj:setvisible(false)
end
HighLightsOn = function ()
	local obj = celestia:find("Sol/Earth/200in/hale_high_lights")
	obj:setvisible(true)
end


-- ==========================================================

cmds.HHLOFF = HighLightsOff
cmds.Hale_High_Lights_Off = HighLightsOff
cmds.HHLON = HighLightsOn
cmds.Hale_High_Lights_On = HighLightsOn

-- ==========================================================

-- pilot lights

PilotLightsOff = function ()
	local obj = celestia:find("Sol/Earth/200in/hale_pilot_lights")
	obj:setvisible(false)
end
PilotLightsOn = function ()
	local obj = celestia:find("Sol/Earth/200in/hale_pilot_lights")
	obj:setvisible(true)
end


-- ==========================================================

cmds.HPLOFF = PilotLightsOff
cmds.Hale_Pilot_Lights_Off = PilotLightsOff
cmds.HPLON = PilotLightsOn
cmds.Hale_Pilot_Lights_On = PilotLightsOn

