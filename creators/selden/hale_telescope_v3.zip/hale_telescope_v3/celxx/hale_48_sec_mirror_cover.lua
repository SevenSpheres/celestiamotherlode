-- functions to set cover open/close parameters
-- cover opening angle corresponds to mirror tilt angle

--======================================================
-- rotation functions for mirror cover
--======================================================
SecCoverRot = function ( date, numPanel, mirror )

  	local Angle
	if (mirror == "Cass" )
	then Angle = math.rad(180) + cassUp.ThNow*1.1
	elseif (mirror == "Coude" )
	then Angle = math.rad(180) + coudeUp.ThNow*1.1
	elseif (mirror == "Coude2" )
	then Angle = math.rad(180) -coude2Up.ThNow*1.1
	end

-- orient around local axis according to position around mirror
	q_rotateY = celestia:newrotation( zAxis, -numPanel * math.pi/4.0 )

-- current opening angle
	local q_rotate_now = celestia:newrotation( yAxis, Angle)

-- combine opening angle with orientation around mirror
	q_rotate = q_rotate_now  *q_rotateY
 	return q_rotate
end

-- ==========================================================
-- CoverRotate -- rotate mirror cover

SecCoverRotateProto = {
	Panel = 0,
	Mirror = "Cass",
}

-- constructor method

function SecCoverRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function SecCoverRotateProto:orientation(tjd)

	local qNow = SecCoverRot( tjd, self.Panel, self.Mirror )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function SecCoverRotate(sscvals)

	return SecCoverRotateProto:new(sscvals)

end
