-- hale_1.lua
-- A Lua Module to help control the model of the Hale Telescope
-- � Selden Ball, September, 2007. All rights reserved. 
--
-- functions to set Storage door parameters

  SDClosed = 0
  SDOpen   = 0.0041

SDT0 = {}
SDT1 = {}
  SDT0[1] = 1e18 
  SDT1[1] = 0 
  SDT0[2] = 1e18 
  SDT1[2] = 0 
  SDT0[3] = 1e18 
  SDT1[3] = 0 

SDX0 = {}
SDX1 = {}
  SDX1[1] = SDClosed 
  SDX0[1] = SDClosed 
  SDX1[2] = SDClosed 
  SDX0[2] = SDClosed 
  SDX1[3] = SDClosed 
  SDX0[3] = SDClosed 

SDV = {}
  SDV[1] = 0.0 
  SDV[2] = 0.0 
  SDV[3] = 0.0

OpenStorageDoor1 = function (mydate)
	SDX0[1] = SDClosed
	SDX1[1] = SDOpen
        SDV[1] = (SDX1[1] - SDX0[1])/ dT
	SDT0[1] = mydate
	SDT1[1] = mydate+dT
end

CloseStorageDoor1 = function (mydate)
	SDX0[1] = SDOpen
	SDX1[1] = SDClosed
        SDV[1] = (SDX1[1] - SDX0[1])/ dT
	SDT0[1] = mydate
	SDT1[1] = mydate+dT
end

OpenStorageDoor2 = function (mydate)
	SDX0[2] = SDClosed
	SDX1[2] = SDOpen
        SDV[2] = (SDX1[2] - SDX0[2])/ dT
	SDT0[2] = mydate
	SDT1[2] = mydate+dT
end

CloseStorageDoor2 = function (mydate)
	SDX0[2] = SDOpen
	SDX1[2] = SDClosed
        SDV[2] = (SDX1[2] - SDX0[2])/ dT
	SDT0[2] = mydate
	SDT1[2] = mydate+dT
end

OpenStorageDoor3 = function (mydate)
	SDX0[3] = SDClosed
	SDX1[3] = SDOpen
        SDV[3] = (SDX1[3] - SDX0[3])/ dT
	SDT0[3] = mydate
	SDT1[3] = mydate+dT
end

CloseStorageDoor3 = function (mydate)
	SDX0[3] = SDOpen
	SDX1[3] = SDClosed
        SDV[3] = (SDX1[3] - SDX0[3])/ dT
	SDT0[3] = mydate
	SDT1[3] = mydate+dT
end
