-- labels for telescope components

LabelsX = 1e18

RevealLabels = function (mydate)
	LabelsX = 0
end

HideLabels = function (mydate)
	LabelsX = 1e18
end
