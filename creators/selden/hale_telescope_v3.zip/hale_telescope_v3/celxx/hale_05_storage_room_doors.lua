
-- open /close storage room doors

DoorPos = function ( NDoor, date )

-- default SD position is last x
	local SDPos = SDXNow[NDoor]

     if (date < SDT0[NDoor])
	then
	SDPos = SDX0[NDoor]
     elseif (date < SDT1[NDoor]) 
	then
	SDPos = SDX0[NDoor] + SDV[NDoor]*(date-SDT0[NDoor])
     else
	SDPos = SDX1[NDoor]
      end

	SDXNow[NDoor] = SDPos
 
-- current opening position
 	return SDPos
end

MoveStorageRoomDoor = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,0,DoorPos(self.params.NDoor,tjd)
	end

return orbit
end
