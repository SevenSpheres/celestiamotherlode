-- ---------------------------------------
-- Motion control for overhead door
-- ---------------------------------------

-- table of motion parameters

OverheadDoor = {}
InitMoveTable(OverheadDoor,0,0.008)

-- ---------------------------------------
-- movement initialization functions

OpenOverheadDoor = function()
	MoveToP1(OverheadDoor,mydate)
end

CloseOverheadDoor = function (mydate)
	MoveToP0(OverheadDoor,mydate)
end

StopOverheadDoor = function (mydate)
	MoveStop(OverheadDoor,mydate)
end

-- ---------------------------------------
-- movement commands

 cmds.Hale_Open_Overhead_Door = OpenOverheadDoor
 cmds.HOOD                 = OpenOverheadDoor
 cmds.Hale_Close_Overhead_Door = CloseOverheadDoor
 cmds.HCOD                 = CloseOverheadDoor
 cmds.Hale_Stop_Overhead_Door = StopOverheadDoor
 cmds.HSOD                 = StopOverheadDoor

-- ---------------------------------------
-- motion method

MoveOverheadDoor = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,0,MoveNow(OverheadDoor,tjd)
	end

return orbit
end

