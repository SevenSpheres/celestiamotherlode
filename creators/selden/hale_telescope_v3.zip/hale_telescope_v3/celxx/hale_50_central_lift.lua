-- ---------------------------------------
-- Motion control for central lift
-- ---------------------------------------

-- table of motion parameters

CentralLift = {}
InitMoveTable(CentralLift,0,0.00297)

-- ---------------------------------------
-- movement initialization functions

RaiseCentralLift = function()
	MoveToP1(CentralLift,mydate)
end

LowerCentralLift = function (mydate)
	MoveToP0(CentralLift,mydate)
end

StopCentralLift = function (mydate)
	MoveStop(CentralLift,mydate)
end

-- ---------------------------------------
-- movement commands

 cmds.Hale_Raise_Central_Lift = RaiseCentralLift
 cmds.HRCL                 = RaiseCentralLift
 cmds.Hale_Lower_Central_Lift = LowerCentralLift
 cmds.HLCL                 = LowerCentralLift
 cmds.Hale_Stop_Central_Lift = StopCentralLift
 cmds.HSCL                 = StopCentralLift

-- ---------------------------------------
-- motion method

MoveCentralLift = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,0,MoveNow(CentralLift,tjd)
	end

return orbit
end
