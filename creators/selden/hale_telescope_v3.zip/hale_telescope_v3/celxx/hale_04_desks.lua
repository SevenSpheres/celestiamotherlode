-- telescope control desks

-- display decrements view counter so that
-- the next frame displays desk contols
-- this is an attempt to give the button a chance to turn green
-- before the desk appears

Demo_view = 3
Control_view = 3

RevealDemoDesk = function (mydate)
	Demo_view = 2

end

HideDemoDesk = function (mydate)
	Demo_view = 3

end

RevealControlDesk = function (mydate)
	Control_view = 2

-- visibility of surface image is opposite of actual controls
--	local obj = celestia:find("Sol/Earth/200in/hale_control_desk_surface" )
--	obj:setvisible(false)
end

HideControlDesk = function (mydate)
	Control_view = 3
-- visibility of surface image is opposite of actual controls
--	local obj = celestia:find("Sol/Earth/200in/hale_control_desk_surface" )
--	obj:setvisible(true)
end

-- =========================================================
 cmds.Hale_Hide_Demo_Desk = HideDemoDesk
 cmds.HHDDSK                 = HideDemoDesk
 cmds.Hale_Reveal_Demo_Desk = RevealDemoDesk
 cmds.HRDDSK                 = RevealDemoDesk

 cmds.Hale_Hide_Control_Desk = HideControlDesk
 cmds.HHCDSK                 = HideControlDesk
 cmds.Hale_Reveal_Control_Desk = RevealControlDesk
 cmds.HRCDSK                 = RevealControlDesk

-- =========================================================
-- Controls on demo desk
-- =========================================================

-- hide/reveal telescope control desks
-- don't reveal them until both flags are set

SeeDemo = function ()
	if (Demo_view == 0)
          then return 0
	end

	if (Demo_view < 3)
  	 then Demo_view = Demo_view -1; return 1e18
	end

	return 1e18
end


DisplayDemoDesk = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)

		return SeeDemo(tjd), 0, 0
	end

return orbit
end

-- =========================================================
-- Controls on control desk
-- =========================================================

SeeControl = function ()
	if (Control_view == 0)
          then return 0
	end

	if (Control_view < 3)
  	 then Control_view = Control_view -1; return 1e18
	end

	return 1e18
end


DisplayControlDesk = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)

		return SeeControl(tjd), 0, 0
	end

return orbit
end

-- =========================================================
-- fake control desk surface image
-- =========================================================
SeeCtl = function ()
	if (Control_view == 0)
          then return 1e18
	end

	if (Control_view < 3)
  	 then return 0
	end

	return 0
end

CtlDeskSurface = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return SeeCtl(tjd), 0, 0
	end

return orbit
end
