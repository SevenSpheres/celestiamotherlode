-- functions to set Coude Axis Flat 5M raise/lower parameters

CoudeFlat5M = {}
InitMoveTable(CoudeFlat5M,math.rad(45)-math.rad(180),math.rad(0)-math.rad(180))

CoudeFlat5Mirror = {}
InitMoveTable(CoudeFlat5Mirror,math.rad(-45)-math.rad(180),math.rad(30)-math.rad(180))

RaiseCoudeFlat5M = function (mydate)
	MoveToP0(CoudeFlat5M,mydate)
	MoveToP0(CoudeFlat5Mirror,mydate)
end

LowerCoudeFlat5M = function (mydate)
	MoveToP1(CoudeFlat5M,mydate)
	MoveToP1(CoudeFlat5Mirror,mydate)
end

StopCoudeFlat5M = function (mydate)
	MoveStop(CoudeFlat5M,mydate)
	MoveStop(CoudeFlat5Mirror,mydate)
end
-- ==========================================================

 cmds.Hale_Coude_Flat5M_Down = LowerCoudeFlat5M
 cmds.HCF5MDOWN              = LowerCoudeFlat5M
 cmds.Hale_Coude_Flat5M_Off  = StopCoudeFlat5M
 cmds.HCF5MOFF              = StopCoudeFlat5M
 cmds.Hale_Coude_Flat5M_Up = RaiseCoudeFlat5M
 cmds.HCF5MUP              = RaiseCoudeFlat5M

-- ==========================================================

-- CoudeFlat5M up/down

CoudeFlat5MRot = function ( date )

 	local Angle = CoudeFlat5M.PosPrev
     	if (date < CoudeFlat5M.T0) then Angle =  CoudeFlat5M.Pos0
     	elseif (date < CoudeFlat5M.T1)
      	  then	Angle = CoudeFlat5M.PosPrev + CoudeFlat5M.V*(date-CoudeFlat5M.TPrev)
	else Angle =  CoudeFlat5M.Pos1
      	end
	CoudeFlat5M.TPrev = date
	CoudeFlat5M.PosPrev = Angle

 	return  zPi * celestia:newrotation( xAxis, Angle)
end

-- ==========================================================
-- CoudeFlat5MRotate -- rotate mirror CoudeFlat5M

CoudeFlat5MRotateProto = { } -- no args

-- constructor method

function CoudeFlat5MRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function CoudeFlat5MRotateProto:orientation(tjd)

	local qNow = CoudeFlat5MRot( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CoudeFlat5MRotate(sscvals)

	return CoudeFlat5MRotateProto:new(sscvals)

end

-- ==========================================================

-- CoudeFlat5Mirror up/down

CoudeFlat5MirrorRot = function ( date )

 	local Angle = CoudeFlat5Mirror.PosPrev
     	if (date < CoudeFlat5Mirror.T0) then Angle =  CoudeFlat5Mirror.Pos0
     	elseif (date < CoudeFlat5Mirror.T1)
      	  then	Angle = CoudeFlat5Mirror.PosPrev + CoudeFlat5Mirror.V*(date-CoudeFlat5Mirror.TPrev)
	else Angle =  CoudeFlat5Mirror.Pos1
      	end
	CoudeFlat5Mirror.TPrev = date
	CoudeFlat5Mirror.PosPrev = Angle

 	return  zPi * celestia:newrotation( xAxis, Angle)
end


-- ==========================================================
-- CoudeFlat5MirrorRotate -- rotate mirror CoudeFlat5Mirror

CoudeFlat5MirrorRotateProto = { } -- no args

-- constructor method

function CoudeFlat5MirrorRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function CoudeFlat5MirrorRotateProto:orientation(tjd)

	local qNow = CoudeFlat5MirrorRot( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CoudeFlat5MirrorRotate(sscvals)

	return CoudeFlat5MirrorRotateProto:new(sscvals)

end

