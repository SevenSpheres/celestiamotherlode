-- Focus distance
--==================================================================
-- revised functional design for switch and controlled devices
-- use just one module file for a specific device:
-- specify globals and command functions
-- update the cmds table 
-- define associated Scripted function(s)
--==================================================================

-- functions to set focus distance parameters

FocusInOut = {}

FocusInOut.T0 = 1e18
FocusInOut.T1 = 0
FocusInOut.TPrev = 0

FocusInOut.In   = -1.5
FocusInOut.Out   = 1.5

FocusInOut.Pos0 =   FocusInOut.Out
FocusInOut.Pos1 =   FocusInOut.In
FocusInOut.PosNow = -0.1

FocusInOut.V = 0

InFocus = function (mydate)

--celestia:flash("InFocus")

	FocusInOut.Pos0 = FocusInOut.PosNow
	FocusInOut.Pos1 = FocusInOut.In
        FocusInOut.V = (FocusInOut.In - FocusInOut.Out)/ (dT)
	FocusInOut.T0 = mydate
	local sf = math.abs((FocusInOut.In-FocusInOut.PosNow)/(FocusInOut.In-FocusInOut.Out))
	FocusInOut.T1 = mydate+dT*sf
	FocusInOut.TPrev = mydate

end

OutFocus = function (mydate)
--celestia:flash("OutFocus")

	FocusInOut.Pos0 = FocusInOut.PosNow
	FocusInOut.Pos1 = FocusInOut.Out
        FocusInOut.V = (FocusInOut.Out - FocusInOut.In)/ (dT)
	FocusInOut.T0 = mydate
	local sf = math.abs((FocusInOut.PosNow-FocusInOut.Out)/(FocusInOut.In-FocusInOut.Out))
	FocusInOut.T1 = mydate+dT*sf
	FocusInOut.TPrev = mydate

end

StopFocus = function (mydate)
--celestia:flash("StopFocus")

	FocusInOut.Pos1 = FocusInOut.PosNow
	FocusInOut.Pos0 = FocusInOut.PosNow
	FocusInOut.T0 = 1e18
	FocusInOut.T1 = mydate
	FocusInOut.TPrev = mydate
        FocusInOut.V = 0.0

end

--==================================================================
-- now that the functions are defined, one can
-- specify the commands which invoke those functions 
--==================================================================

cmds.Hale_Focus_In     = InFocus
cmds.HFCIN             = InFocus
cmds.Hale_Focus_Out    = OutFocus
cmds.HFCOUT            = OutFocus
cmds.Hale_Focus_Stop   = StopFocus
cmds.HFCSTOP           = StopFocus


--==================================================================
-- Below are the Scripted Functions which specify the object's orientation
-- using the values set by the command functions above.
--==================================================================
-- Focus dial positioning function used for Focus distance
-- maybe someday there will be an object that's moved the Focus distance
--==================================================================

Focus_Ctl_Move = function(date)

	local FocusInOutPos

     if (date < FocusInOut.T0)
	then
	FocusInOutPos = FocusInOut.Pos0
     elseif (date < FocusInOut.T1)
      then
	FocusInOutPos = FocusInOut.PosNow + FocusInOut.V*(date-FocusInOut.TPrev)
     else
	FocusInOutPos = FocusInOut.Pos1
      end

	FocusInOut.TPrev = date
	FocusInOut.PosNow = FocusInOutPos

     local Angle = 2.0*math.pi*(FocusInOut.PosNow /4.0)
     return  yPi*celestia:newrotation( zAxis, Angle)

end

--==================================================================
-- Scripted Focus_Ctl_Angle function
--==================================================================

Focus_Ctl_Angleproto =
{
   Period    = 1,
}

-- constructor method
function Focus_Ctl_Angleproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Focus_Ctl_Angleproto:orientation(tjd)

	local qNow = 	Focus_Ctl_Move(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Focus_Ctl_Angle(sscvals)
   -- create a new Focus_Ctl_Angle rotation object
   return Focus_Ctl_Angleproto:new(sscvals)
end
-- =====================================================
-- move prime focus assembly to match 
-- =====================================================
pfcFocus = function()
	return FocusInOut.PosNow * 0.0000254
end

AdjustFocus = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,0,pfcFocus(tjd)
	end

return orbit
end
