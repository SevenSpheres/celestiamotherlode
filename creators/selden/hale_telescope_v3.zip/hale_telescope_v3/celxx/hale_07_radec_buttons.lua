-- buttons near right spinner knob
-- control telescope's radec movements

ItsSlow = (1296000.0/(dT*3600))*second
ItsSlew = (1296000.0/(dT*2))*second

RADecMotion = {
HBSLEW = true,
HBSET = false,
HBSLOW = false,
-- #sec/sec: 360 degrees (1,296,000 sec) in dT (10) seconds
SlewSpeed = ItsSlew,
SetSpeed  = (1296000.0/(dT*60))*second,
SlowSpeed = ItsSlow,
StopSpeed = 0.0,
MoveSpeed = ItsSlew,  -- default is to move fast
MoveRASpeed = ItsSlew,
MoveDecSpeed = ItsSlew/10,
MoveRATSpeed = ItsSlew*30,
MoveDecTSpeed = ItsSlew*30,
HDNORTH = false,
HDSOUTH = false,
HDSTOP = true,
HRAEAST = false,
HRAWEST = false,
HRASTOP = true,
}

MoveDecNorth = function ()
	RADecMotion.HDNORTH = true
	RADecMotion.HDSOUTH = false
	RADecMotion.HDSTOP = false
	RADecMotion.MoveDecSpeed = RADecMotion.MoveSpeed/3
end

MoveDecSouth = function ()
	RADecMotion.HDNORTH = false
	RADecMotion.HDSOUTH = true
	RADecMotion.HDSTOP = false
	RADecMotion.MoveDecSpeed = RADecMotion.MoveSpeed/3
end

MoveDecStop = function ()
	RADecMotion.HDNORTH = false
	RADecMotion.HDSOUTH = false
	RADecMotion.HDSTOP = true
	RADecMotion.MoveDecSpeed = RADecMotion.StopSpeed
end

MoveRAEast = function ()
	RADecMotion.HRAEAST = true
	RADecMotion.HRAWEST = false
	RADecMotion.HRASTOP = false
	RADecMotion.MoveRASpeed = RADecMotion.MoveSpeed
end

MoveRAWest = function ()
	RADecMotion.HRAEAST = false
	RADecMotion.HRAWEST = true
	RADecMotion.HRASTOP = false
	RADecMotion.MoveRASpeed = RADecMotion.MoveSpeed
end

MoveRAStop = function ()
	RADecMotion.HRAEAST = false
	RADecMotion.HRAWEST = false
	RADecMotion.HRASTOP = true
	RADecMotion.MoveRASpeed = RADecMotion.StopSpeed
end


MoveSlewSpeed = function ()
	RADecMotion.MoveSpeed = RADecMotion.SlewSpeed
	RADecMotion.MoveRASpeed = RADecMotion.SlewSpeed
	RADecMotion.MoveDecSpeed = RADecMotion.SlewSpeed/3
	RADecMotion.MoveRATSpeed = RADecMotion.SlewSpeed*30
	RADecMotion.MoveDecTSpeed = RADecMotion.SlewSpeed*30
end
MoveSetSpeed = function ()
	RADecMotion.MoveSpeed = RADecMotion.SetSpeed
	RADecMotion.MoveRASpeed = RADecMotion.SetSpeed
	RADecMotion.MoveDecSpeed = RADecMotion.SetSpeed/10
	RADecMotion.MoveRATSpeed = RADecMotion.SetSpeed*30
	RADecMotion.MoveDecTSpeed = RADecMotion.SetSpeed
end
MoveSlowSpeed = function ()
	RADecMotion.MoveSpeed = RADecMotion.SlowSpeed
	RADecMotion.MoveRASpeed = RADecMotion.SlowSpeed
	RADecMotion.MoveDecSpeed = RADecMotion.SlowSpeed/10
	RADecMotion.MoveRATSpeed = RADecMotion.SlowSpeed*30
	RADecMotion.MoveDecTSpeed = RADecMotion.SlowSpeed
end
MoveStopSpeed = function ()
	RADecMotion.MoveSpeed = RADecMotion.StopSpeed
	RADecMotion.MoveRASpeed = RADecMotion.StopSpeed
	RADecMotion.MoveDecSpeed = RADecMotion.StopSpeed
	RADecMotion.MoveRATSpeed = RADecMotion.StopSpeed
	RADecMotion.MoveDecTSpeed = RADecMotion.StopSpeed
end

---------------------------------------
-- translate selected object into action function
---------------------------------------
cmds.HBSLEW = MoveSlewSpeed
cmds.HBSET = MoveSetSpeed
cmds.HBSLOW = MoveSlowSpeed
cmds.HBSTOP = MoveStopSpeed

cmds.HDNORTH = MoveDecNorth
cmds.HDSOUTH = MoveDecSouth
cmds.HDSTOP = MoveDecStop

cmds.HRAEAST = MoveRAEast
cmds.HRAWEST = MoveRAWest
cmds.HRASTOP = MoveRAStop
