-- contents of prime focus cage
-- none or one at a time

LFCFoVX = 0

LFCX = 1e18
primeObsX = 0 -- default instrument
LaunchTelX = 1e18

-- hide all prime instruments

HidePFI = function (mydate)
	LFCX = 1e18
	primeObsX = 1e18
	LaunchTelX = 1e18
end

-- Large Format Camera

-- LFC fov anytime 
HideLFCFoV = function (mydate)
	LFCFoVX = 1e18
end
RevealLFCFoV = function (mydate)
	LFCFoVX = 0
end

-- camera
HideLFC = function (mydate)
	LFCX = 1e18
end
RevealLFC = function (mydate)
	LFCX = 0
	primeObsX = 1e18
	LaunchTelX = 1e18
end

-- an observer at the prime focus
HidePrimeObs = function (mydate)
	primeObsX = 1e18
end
RevealPrimeObs = function (mydate)
	LFCX = 1e18
	primeObsX = 0
	LaunchTelX = 1e18
end

-- laser launch telescope
HideLaunchTel = function (mydate)
	LaunchTelX = 1e18
end
RevealLaunchTel = function (mydate)
	LFCX = 1e18
	primeObsX = 1e18
	LaunchTelX = 0
end
