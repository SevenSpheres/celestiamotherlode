-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
-- coude bridge
--==================================================================
-- ThreePoleLamp functions: demo version
-- functions for actual switches will test related hardware states
--==================================================================

ThreePoleLampStateTop08 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- Top on light visible if bridge is down
	if ( MoveNearTh(Bridge.PosPrev,Bridge.Down) and (State == "on"))
	then return 0
	elseif ( not MoveNearTh(Bridge.PosPrev,Bridge.Down) and (State == "on"))
	then return 1e18

-- Top off light visible if bridge is not down
	elseif ( not MoveNearTh(Bridge.PosPrev,Bridge.Down) and (State == "off"))
	then return 0
	elseif ( MoveNearTh(Bridge.PosPrev,Bridge.Down) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop08 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop08(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot08 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- Bot on light visible if bridge is up
	if ( MoveNearTh(Bridge.PosPrev,Bridge.Up) and (State == "on"))
	then return 0
	elseif ( not MoveNearTh(Bridge.PosPrev,Bridge.Up) and (State == "on"))
	then return 1e18

-- Bot off light visible if bridge is not up
	elseif ( not MoveNearTh(Bridge.PosPrev,Bridge.Up) and (State == "off"))
	then return 0
	elseif ( MoveNearTh(Bridge.PosPrev,Bridge.Up) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot08 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot08(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end
	return orbit
end
