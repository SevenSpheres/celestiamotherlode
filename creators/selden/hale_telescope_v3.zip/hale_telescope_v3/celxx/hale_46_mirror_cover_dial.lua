-- Mirror Cover dial aka aperture dial
--==================================================================
-- control values
-- uses angle of one of the mirror covers

--==================================================================
-- positioning function used by MCover Degree positioning
--==================================================================

MCover_Ctl_Move = function(date)

  local Angle = (-coverAnglePrev[00] - 0.1047163267949 + math.rad(90.0))*3.68
  return  yPi*celestia:newrotation( zAxis, Angle)
end

--==================================================================
-- MCover_Angle functions
--==================================================================
-- hours function calculates positions
-- minutes and seconds just follow along
--==================================================================
MCover_Ctl_Angleproto =
{
   Period    = 1,
}

-- constructor method
function MCover_Ctl_Angleproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function MCover_Ctl_Angleproto:orientation(tjd)

	local qNow = 	MCover_Ctl_Move(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function MCover_Ctl_Angle(sscvals)
   -- create a new MCover_Ctl_Angle rotation object
   return MCover_Ctl_Angleproto:new(sscvals)
end
