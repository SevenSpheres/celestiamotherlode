-- functions to set HorizCwt raise/lower parameters

HorizCwt = {}
HorizCwt.T0 = 1e18
HorizCwt.T1 = 0

HorizCwt.Down = math.rad(135.0)
HorizCwt.P0 = HorizCwt.Down

HorizCwt.Up = math.rad(-137)
HorizCwt.P1 = HorizCwt.Up

HorizCwt.TPrev = 1e18
HorizCwt.PosPrev = math.rad(70)
HorizCwt.Pos0 = HorizCwt.PosPrev
HorizCwt.Pos1 = HorizCwt.PosPrev

HorizCwt.V = 0


RaiseHorizCwt = function (mydate)
	MoveToP1(HorizCwt,mydate)
celestia:flash("Raise")
end

LowerHorizCwt = function (mydate)
	MoveToP0(HorizCwt,mydate)
celestia:flash("Lower")
end

StopHorizCwt = function (mydate)
	MoveStop(HorizCwt,mydate)
celestia:flash("Stop")
end
-- ==========================================================

 cmds.Hale_Horiz_Cwt_50 = LowerHorizCwt
 cmds.HHCWT50              = LowerHorizCwt
 cmds.Hale_Horiz_Cwt_Off  = StopHorizCwt
 cmds.HHCWTOFF              = StopHorizCwt
 cmds.Hale_Horiz_Cwt_40 = RaiseHorizCwt
 cmds.HHCWT40              = RaiseHorizCwt

-- ==========================================================

-- HorizCwt up/down

HorizCwtRot = function ( date )

 	local Angle = HorizCwt.PosPrev
     	if (date < HorizCwt.T0) then Angle = HorizCwt.Pos0
     	elseif (date < HorizCwt.T1)
      	  then	Angle = HorizCwt.PosPrev + HorizCwt.V*(date-HorizCwt.TPrev)
	else Angle = HorizCwt.Pos1
      	end
	HorizCwt.TPrev = date
	HorizCwt.PosPrev = Angle

 	return  yPi * celestia:newrotation( yAxis, Angle)
end

-- ==========================================================
-- HorizCwtRotate -- rotate mirror HorizCwt

HorizCwtRotateProto = { } -- no args

-- constructor method

function HorizCwtRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function HorizCwtRotateProto:orientation(tjd)

	local qNow = HorizCwtRot( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function HorizCwtRotate(sscvals)

	return HorizCwtRotateProto:new(sscvals)

end

