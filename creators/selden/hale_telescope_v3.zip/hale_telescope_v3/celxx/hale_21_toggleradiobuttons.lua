--==================================================================
--==================================================================
-- ToggleRadioButton functions: switches among N states
--==================================================================
ToggleRadioState = function(BRadio,ButtonName,ButtonMove,BOff,BOn,BIState,BIMove,date)
   local todo = nil
   local sel = celestia:getselection()

	local BIS = BIState
	if (BIS == nil) then BIS = "off" end
	local BIM = BIMove
	if (BIM == nil) then BIM = 0 end

   if (sel:name() == ButtonName)  
   then
--	this button selected. Is it in the list?
	  if (TableOfButtons[ButtonName] == ButtonName )
          then
--	in list =yes: change button state (nil == off)
	    if (TableOfValues[ButtonName] == "on")
	    then 
		todo = cmds[BOff]; if todo then todo(date) end
	 	 TableOfValues[ButtonName] = "off"
	  	TableOfPositions[ButtonName] = 0
	    else
		todo = cmds[BOn]; if todo then todo(date) end
	 	 TableOfValues[ButtonName] = "on"
	  	TableOfPositions[ButtonName] = ButtonMove
	    end

-- 	this button is selected
--	make sure all other members of this radio set are off
	  for j,r in pairs(TableOfButtons) do
	     if (TableOfRadios[j] == BRadio and TableOfButtons[j] ~= ButtonName)
	     then
		TableOfValues[j] = "off"  
		TableOfPositions[j] = 0
	     end
	  end -- for j,r loop

-- 	selected and found in list: restore previous selection 
	  celestia:select(TableOfSelections[ButtonName])
  	  return TableOfPositions[ButtonName]
	 end

--	button selected but not in list: add it
--	this also means no previous selection known!!
--	(and this probably can't actually happen)

	TableOfRadios[ButtonName] = BRadio
	TableOfButtons[ButtonName] = ButtonName
	TableOfValues[ButtonName] = BIS
	TableOfPositions[ButtonName] = BIM

-- 	restore selection (i.e.set to nil) and position button
	celestia:select(TableOfSelections[ButtonName])
	return TableOfPositions[ButtonName]
   else 

-- this button is not selected
--	is it already known?
	if (TableOfButtons[ButtonName] == ButtonName )
          then
--	 known:
--	 record actual selection for later
	   TableOfSelections[ButtonName] = sel
-- 	 and return this button's current position
	   return TableOfPositions[ButtonName]
	  end 

--	not selected, but not in list: add it
--	celestia:flash("new:"..ButtonName)
	TableOfRadios[ButtonName] = BRadio
	TableOfButtons[ButtonName] = ButtonName

	TableOfValues[ButtonName] = BIS
	TableOfPositions[ButtonName] = BIM

	TableOfSelections[ButtonName] = sel
-- 	 and return this button's current position
	return TableOfPositions[ButtonName]
   end
   return 0 -- can't get here
end

--======================================================
-- ScriptedOrbit function 
--======================================================
ToggleRadioButton = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
-- intermediate values just to keep function call line short
		return 0,0, ToggleRadioState(
				self.params.ButtonRadio,
				self.params.ButtonName,
				self.params.ButtonMove,
				self.params.ButtonOff,
				self.params.ButtonOn,
				self.params.InitialState,
				self.params.InitialMove,
				tjd)
	end

return orbit
end
