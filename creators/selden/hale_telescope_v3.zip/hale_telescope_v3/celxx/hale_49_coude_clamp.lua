-- enable coude crane clamp

CoudeClamp = {}
CoudeClamp.Opened = "false"

OpenClamp = function (mydate)
CoudeClamp.Opened = "true"
CoudeFlatDownX = 0
local obj = celestia:find("Sol/Earth/hale_telescope/hale_coude_crane")
 obj:setvisible(false)
 obj = celestia:find("Sol/Earth/hale_telescope/hale_coude_crane_noflat")
 obj:setvisible(true)
 obj = celestia:find("Sol/Earth/200in/hale_coude_flat")
 obj:setvisible(true)
 obj = celestia:find("Sol/Earth/200in/hale_coude_flat_yoke")
 obj:setvisible(true)
 obj = celestia:find("Sol/Earth/200in/hale_coude_flat_base")
 obj:setvisible(true)
end

CloseClamp = function (mydate)
CoudeClamp.Opened = "false"
CoudeFlatDownX = 1e18
local obj = celestia:find("Sol/Earth/hale_telescope/hale_coude_crane")
 obj:setvisible(true)
 obj = celestia:find("Sol/Earth/hale_telescope/hale_coude_crane_noflat")
 obj:setvisible(false)
 obj = celestia:find("Sol/Earth/200in/hale_coude_flat")
 obj:setvisible(false)
 obj = celestia:find("Sol/Earth/200in/hale_coude_flat_yoke")
 obj:setvisible(false)
 obj = celestia:find("Sol/Earth/200in/hale_coude_flat_base")
 obj:setvisible(false)
end
--==================================================================
-- now that the functions are defined, one can
-- specify the commands which invoke those functions 
--==================================================================

cmds.Hale_Crane_Remove_Flat     = CloseClamp
cmds.HCRF = CloseClamp

cmds.Hale_Crane_Place_Flat     = OpenClamp
cmds.HCPF = OpenClamp

cmds.Hale_Crane_Stop_Flat     = CloseClamp
cmds.HCSF = CloseClamp
