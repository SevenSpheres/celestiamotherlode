--Clocks
--==================================================================
--RA Clock
--==================================================================
-- RA_Hours functions
--==================================================================
RA_HoursState = function(BName)

	local Angle = math.rad(prevRA)
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
RA_Hoursproto =
{
   Period    = 1,
}

-- constructor method
function RA_Hoursproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Hoursproto:orientation(tjd)

	local qNow = 	RA_HoursState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Hours(sscvals)
   -- create a new RA_Hours rotation object
   return RA_Hoursproto:new(sscvals)
end
--==================================================================
-- RA_Minutes functions
--==================================================================
RA_MinutesState = function(BName)

	local Angle = math.rad((prevRA*24.0))
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
RA_Minutesproto =
{
   Period    = 1,
}

-- constructor method
function RA_Minutesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Minutesproto:orientation(tjd)

	local qNow = 	RA_MinutesState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Minutes(sscvals)
   -- create a new RA_Minutes rotation object
   return RA_Minutesproto:new(sscvals)
end
--==================================================================
-- RA_Seconds functions
--==================================================================
RA_SecondsState = function(BName)

	local Angle = math.rad((prevRA*1440.0))
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
RA_Secondsproto =
{
   Period    = 1,
}

-- constructor method
function RA_Secondsproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Secondsproto:orientation(tjd)

	local qNow = 	RA_SecondsState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Seconds(sscvals)
   -- create a new RA_Seconds rotation object
   return RA_Secondsproto:new(sscvals)
end
