-- Button display functions

-- every button must have a unique name,
-- even those which are members of a radio button set
TableOfButtons = {}
TableOfValues = {}
TableOfPositions = {}
TableOfSelections = {}
-- name of the RadioSet to which the button belongs, if it does
TableOfRadios = {}

--==================================================================
-- ToggleButton functions: switches between 2 states: 0 (or nil) & 1 
--==================================================================
ToggleState = function(ButtonName,ButtonMove,BOff,BOn,date)

   if (sameSel) then return TableOfPositions[ButtonName] end
   local sel = selP

   local todo = nil

   if (sel:name() == ButtonName)  
   then
--	this button selected. Is it known? i.e. initialized?
	  if (TableOfButtons[ButtonName] == ButtonName )
          then
--	initialized: toggle button state
	    if (TableOfValues[ButtonName] == "on")
	    then 
		TableOfValues[ButtonName] = "off"
		TableOfPositions[ButtonName] = 0
		todo = cmds[BOff]; if todo then todo(date) end
	    else 
		TableOfValues[ButtonName] = "on"
		TableOfPositions[ButtonName] = ButtonMove
		todo = cmds[BOn]; if todo then todo(date) end
	    end

-- 	initialized: restore previous selection and move button
	     celestia:select(TableOfSelections[ButtonName])
  	     return TableOfPositions[ButtonName]
        end -- if known

--	button selected but not known: add it
--	(this also means no previous selection known)
--	("selected but not known" probably can't actualy happen)

	TableOfButtons[ButtonName] = ButtonName
-- (later: initialize with values from SSC entry)
	TableOfValues[ButtonName] = "off"
	TableOfPositions[ButtonName] = 0
	todo = cmds[BOff]; if todo then todo(date) end

-- 	restore selection (i.e.set to nil) and position button
	celestia:select(TableOfSelections[ButtonName])
	return TableOfPositions[ButtonName]
   else 

-- the most common state
-- this button is not selected
--	already known?
	if (TableOfButtons[ButtonName] == ButtonName )
	then
--	  in list =yes:
--	  record actual selection for later
	   TableOfSelections[ButtonName] = sel
-- 	  and return this button's current position
	   return TableOfPositions[ButtonName]
	else
--	not selected and not known: add it
--	celestia:flash("new:"..ButtonName)
	  TableOfButtons[ButtonName] = ButtonName
-- (later: initialize with values from SSC entry)
	  TableOfValues[ButtonName] = "off"
	  TableOfPositions[ButtonName] = 0
	  TableOfSelections[ButtonName] = sel
-- 	  and return this button's current position
	  return TableOfPositions[ButtonName]
        end
   end
   return 0 -- can't get here
end

--======================================================
-- ScriptedOrbit function 
--======================================================
ToggleButton = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return 0, 0, ToggleState(
			  self.params.ButtonName,
			  self.params.ButtonMove,
			  self.params.ButtonOff,
			  self.params.ButtonOn,
			  tjd)

	end

return orbit
end
--======================================================
--======================================================
-- place lamp corresponding to master button's state
--======================================================
LampState = function (ButtonName,LampN,date)
--	celestia:flash(" Lamp: test")
--	master button in list?
	if (TableOfButtons[ButtonName] == ButtonName )
          then
--	 a known button: is it in this Lamp's state?
	   if (TableOfValues[ButtonName] == LampN)
	    then 
--		celestia:flash("Lamp: me")
	    	return 0
	    else 
--		celestia:flash("Lamp: notme")
	   	return 1e18
	   end
	  end

-- wtf? button not known: place Lamp far away
--	celestia:flash("unknown")
	return 1e18
end
--======================================================
-- ScriptedOrbit function
--======================================================
DisplayLamp = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		local LampX = LampState(
			self.params.ButtonName,
			self.params.LampN,
			tjd)
		return LampX, 0, 0
	end

return orbit
end
--==================================================================
--==================================================================
-- RadioButton functions: switches among N states
--==================================================================
RadioState = function(BRadio,ButtonName,ButtonMove,BOff,BOn,BIState,BIMove,date)
   if (sameSel) then return TableOfPositions[ButtonName] end
   local sel = selP
   local todo = nil

	local BIS = BIState
	if (BIS == nil) then BIS = "off" end
	local BIM = BIMove
	if (BIM == nil) then BIM = 0 end

   if (sel:name() == ButtonName)  
   then
--	this button selected. Is it in the list?
	  if (TableOfButtons[ButtonName] == ButtonName )
          then
--	in list =yes: change button state only from off to on
	    if (TableOfValues[ButtonName] == "off")
	    then 
		todo = cmds[BOn]; if todo then todo(date) end
	    end

-- this button is selected, so the state of this selected button is on
-- these could be inside the if, but I'm being paranoid

--	make sure all other members of this radio set are off
	  for j,r in pairs(TableOfButtons) do
	     if (TableOfRadios[j] == BRadio and TableOfButtons[j] ~= ButtonName)
	     then
		TableOfValues[j] = "off"  
		TableOfPositions[j] = 0
	     end
	  end -- for j,r loop

-- 	selected and found in list: restore previous selection and move button
	  TableOfValues[ButtonName] = "on"
	  TableOfPositions[ButtonName] = ButtonMove
	  celestia:select(TableOfSelections[ButtonName])
  	  return TableOfPositions[ButtonName]
	 end

--	button selected but not in list: add it
--	this also means no previous selection known!!
--	(and this probably can't actually happen)

	TableOfRadios[ButtonName] = BRadio
	TableOfButtons[ButtonName] = ButtonName
	TableOfValues[ButtonName] = BIS
	TableOfPositions[ButtonName] = BIM

-- 	restore selection (i.e.set to nil) and position button
	celestia:select(TableOfSelections[ButtonName])
	return TableOfPositions[ButtonName]
   else 

-- this button is not selected
--	is it already known?
	if (TableOfButtons[ButtonName] == ButtonName )
          then
--	 known:
--	 record actual selection for later
	   TableOfSelections[ButtonName] = sel
-- 	 and return this button's current position
	   return TableOfPositions[ButtonName]
	  end 

--	not selected, but not in list: add it
--	celestia:flash("new:"..ButtonName)
	TableOfRadios[ButtonName] = BRadio
	TableOfButtons[ButtonName] = ButtonName

	TableOfValues[ButtonName] = BIS
	TableOfPositions[ButtonName] = BIM

	TableOfSelections[ButtonName] = sel
-- 	 and return this button's current position
	return TableOfPositions[ButtonName]
   end
   return 0 -- can't get here
end

--======================================================
-- ScriptedOrbit function 
--======================================================
RadioButton = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return 0, 0,  RadioState(
				 self.params.ButtonRadio,
				 self.params.ButtonName,
				 self.params.ButtonMove,
				 self.params.ButtonOff,
				 self.params.ButtonOn,
				 self.params.InitialState,
				 self.params.InitialMove,
				 tjd)
	end

return orbit
end
