--==================================================================
--==================================================================
-- ToggleSwitch functions: rotates among several positions
--==================================================================
TableOfSwitchRotations = {}

ToggleSwitchState = function(BName,BMove,BOff,BOn,date)
	if (samePos) then return  TableOfSwitchRotations[BName] end

	local z = ToggleState(BName,BMove,BOff,BOn,date)
	local Angle = math.rad(225-2*TableOfPositions[BName])
	TableOfSwitchRotations[BName] = zPi*celestia:newrotation( xAxis, Angle)
 	return  TableOfSwitchRotations[BName]
end


--==================================================================
ToggleSwitchproto =
{
   Amplitude = 0,
   Period    = 1,
}

-- constructor method
function ToggleSwitchproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function ToggleSwitchproto:orientation(tjd)

	local SName = self.ButtonName
	local SMove = self.ButtonMove
	local SOn = self.ButtonOn
	local SOff = self.ButtonOff

--s = "tog"
--celestia:flash(s)

	local qNow = 	ToggleSwitchState(SName,SMove,SOff,SOn,tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function ToggleSwitch(sscvals)
   -- create a new ToggleSwitch rotation object
   return ToggleSwitchproto:new(sscvals)
end
