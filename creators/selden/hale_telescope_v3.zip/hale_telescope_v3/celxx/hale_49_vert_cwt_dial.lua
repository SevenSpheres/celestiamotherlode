-- functions to set VertCwt raise/lower parameters

VertCwt = {}
VertCwt.T0 = 1e18
VertCwt.T1 = 0

VertCwt.Down = math.rad(179.0)
VertCwt.P0 = VertCwt.Down

VertCwt.Up = math.rad(-179)
VertCwt.P1 = VertCwt.Up

VertCwt.TPrev = 1e18
VertCwt.PosPrev = 0
VertCwt.Pos0 = 0
VertCwt.Pos1 = 0

VertCwt.V = 0


RaiseVertCwt = function (mydate)
	MoveToP1(VertCwt,mydate)
end

LowerVertCwt = function (mydate)
	MoveToP0(VertCwt,mydate)
end

StopVertCwt = function (mydate)
	MoveStop(VertCwt,mydate)
end
-- ==========================================================

 cmds.Hale_Vertical_Cwt_Down = LowerVertCwt
 cmds.HVCWTDWN              = LowerVertCwt
 cmds.Hale_Vertical_Cwt_Off  = StopVertCwt
 cmds.HVCWTOFF              = StopVertCwt
 cmds.Hale_Vertical_Cwt_Up = RaiseVertCwt
 cmds.HVCWTUP              = RaiseVertCwt

-- ==========================================================

-- VertCwt up/down

VertCwtRot = function ( date )

 	local Angle = VertCwt.PosPrev
     	if (date < VertCwt.T0) then Angle = VertCwt.Pos0
     	elseif (date < VertCwt.T1)
      	  then	Angle = VertCwt.PosPrev + VertCwt.V*(date-VertCwt.TPrev)
     	else Angle = VertCwt.Pos1
      	end
	VertCwt.TPrev = date
	VertCwt.PosPrev = Angle

 	return  yPi * celestia:newrotation( yAxis, Angle)
end

-- ==========================================================
-- VertCwtRotate -- rotate mirror VertCwt

VertCwtRotateProto = { } -- no args

-- constructor method

function VertCwtRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function VertCwtRotateProto:orientation(tjd)

	local qNow = VertCwtRot( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function VertCwtRotate(sscvals)

	return VertCwtRotateProto:new(sscvals)

end

