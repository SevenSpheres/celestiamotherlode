-- functions to hide/reveal Pulpit controls
-- update

PulpitX = 1e18

HidePulpit = function (mydate)
	PulpitX = 1e18
end
RevealPulpit = function (mydate)
	PulpitX = 0
end

-- ==========================================================

 cmds.Hale_Reveal_Pulpit = RevealPulpit
 cmds.HRPULPIT = RevealPulpit
 cmds.Hale_Hide_Pulpit = HidePulpit
 cmds.HHPULPIT = HidePulpit

-- ==========================================================

-- hide/reveal telescope control pulpit controls

DisplayPulpit = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return PulpitX, 0, 0
	end

return orbit
end

