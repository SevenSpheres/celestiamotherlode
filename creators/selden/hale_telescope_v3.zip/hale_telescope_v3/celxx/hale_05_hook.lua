
-- move overhead crane's hook

HookX = function ( date )

-- default Hook position is last x
	local HookPos = Hook.X1

     if (date >= Hook.T0) and (date <= Hook.T1)
      then
	HookPos = Hook.X0 + Hook.V*(date-Hook.T0)
	Hook.Xprv = HookPos
      end
 
-- current crane position
 	return HookPos
end


MoveHook = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0, 0, HookX(tjd)
	end

return orbit
end
