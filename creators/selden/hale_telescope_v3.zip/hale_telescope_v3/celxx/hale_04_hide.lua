--======================================================
-- motion functions
-- mostly used to hide models far, far away
-- (could add a level of indirection and have just 1 function)
--======================================================
DisplayTelescope = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return telescopeX, 0, 0
	end

return orbit
end

-- Cassegrain Focus Cage
DisplayCFC = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return CFCX, 0, 0
	end

return orbit
end

-- Prime Focus Cage
DisplayPFC = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return PFCX, 0, 0
	end

return orbit
end

-- Lores Prime Focus Cage
DisplayLoresPFC = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return loresPFCX, 0, 0
	end

return orbit
end


DisplayLoresTelescope = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return lorestelescopeX, 0, 0
	end

return orbit
end

DisplayPlinth = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return plinthX, 0, 0
	end

return orbit

end 
DisplayLoresPlinth = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return loresplinthX, 0, 0
	end

return orbit
end

DisplayYoke = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return yokeX, 0, 0
	end

return orbit
end
DisplayLoresYoke = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return loresyokeX, 0, 0
	end

return orbit
end

--============================================================
-- hide/reveal laser target, track and emitter
--============================================================
DisplayTarget = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return laserTargetX, 0, 0
	end

return orbit
end
--============================================================
-- hide/reveal laser beams
--============================================================
DisplayLaser = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return laserBeamX, 0, 0
	end

return orbit
end

--============================================================
-- axial coude mirror near base of yoke
--============================================================
 
  DisplayCoudeYokeMirror = function (sscvals)
 
        local orbit = {}
        orbit.boundingRadius = 1e-4

        function orbit:position (tjd)
                return coudeYokeMirrorX, 0, 0
        end
 
  return orbit
  end

 
  DisplayCoudeMirror0 = function (sscvals)
 
        local orbit = {}
        orbit.boundingRadius = 1e-4

        function orbit:position (tjd)
 --               return coudeMirror0X, -0.00223,  -0.00082
                  return coudeMirror0X, -0.0024 ,  -0.00082
        end
 
  return orbit
  end

  DisplayCoudeMirror90 = function (sscvals)
 
        local orbit = {}
        orbit.boundingRadius = 1e-4

        function orbit:position (tjd)
                return coudeMirror90X, 0, 0
        end
 
  return orbit
  end

--============================================================
-- other devices to hide/restore
--============================================================
require ("hale_04_cables")
require ("hale_04_coudeflatdown")
require ("hale_04_primefocusinstruments")
require ("hale_04_cassfocusinstruments")
require ("hale_04_labels")
require ("hale_04_desks")
