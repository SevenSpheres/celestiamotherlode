-- hale_44_sidereal_clocks
-- display ra of meridian
-- = ra of hale telescope position as seen from earth's center

--======================================
-- telescope's RA as seen by Earth

SID_hour = function (date)
	local sel = celestia:find("Sol/Earth/hale_position")
	local vp = celestia:find("Sol/Earth")

-- for verification: the stowed telescope target is approximately overhead
--	local vp = celestia:find("Sol/Earth/hale_position")
--	local sel = celestia:find("Sol/Earth/stow_telescope")

	local prevRA,prevDecl  = pkg.get_ra_dec (vp,sel)
	return prevRA/15.0
end

--==================================================================
SID_HoursState = function(date)

	local Angle = -(2.0*SID_hour(date)*(2*math.pi/24.0))
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
SID_Hoursproto =
{
   Period    = 1,
}

-- constructor method
function SID_Hoursproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function SID_Hoursproto:orientation(tjd)

	local qNow = 	SID_HoursState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function SID_Hours(sscvals)
   -- create a new SID_Hours rotation object
   return SID_Hoursproto:new(sscvals)
end

--==================================================================
--==================================================================
-- Sidereal Time_Minutes functions
--==================================================================

SID_MinutesState = function(date)

	local Angle = -SID_hour(date)* 2.0*math.pi

 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
SID_Minutesproto =
{
   Period    = 1,
}

-- constructor method
function SID_Minutesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function SID_Minutesproto:orientation(tjd)

	local qNow = 	SID_MinutesState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function SID_Minutes(sscvals)
   -- create a new SID_Minutes rotation object
   return SID_Minutesproto:new(sscvals)
end
--==================================================================
--==================================================================
-- Sidereal Time_Seconds functions
--==================================================================

SID_SecondsState = function(date)

	local Angle = -SID_hour(date)* 2.0*math.pi*60.0

 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
SID_Secondsproto =
{
   Period    = 1,
}

-- constructor method
function SID_Secondsproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function SID_Secondsproto:orientation(tjd)

	local qNow = 	SID_SecondsState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function SID_Seconds(sscvals)
   -- create a new SID_Seconds rotation object
   return SID_Secondsproto:new(sscvals)
end
