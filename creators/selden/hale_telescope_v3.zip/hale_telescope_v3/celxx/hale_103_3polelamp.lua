-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
--==================================================================
-- ThreePoleLamp functions: demo version
-- functions for actual switches will test related hardware states
--==================================================================

ThreePoleLampStateTop03 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- up on light visible if coude2 up

	if ((coude2Up.ThNow == coude2Up.Up) and (State == "on"))
	then return 0
	elseif ( (coude2Up.ThNow ~= coude2Up.Up) and (State == "on"))
	then return 1e18

-- up off light visible if coude2 not up
	elseif ( (coude2Up.ThNow ~= coude2Up.Up) and (State == "off"))
	then return 0
	elseif ( (coude2Up.ThNow == coude2Up.Up) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop03 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop03(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot03 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- down on light visible if coude2 down
	if ((coude2Up.ThNow == coude2Up.Down) and (State == "on"))
	then return 0
	elseif ( (coude2Up.ThNow ~= coude2Up.Down) and (State == "on"))
	then return 1e18

-- down off light visible if coude2 not down
	elseif ( (coude2Up.ThNow ~= coude2Up.Down) and (State == "off"))
	then return 0
	elseif ( (coude2Up.ThNow == coude2Up.Down) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot03 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot03(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end
