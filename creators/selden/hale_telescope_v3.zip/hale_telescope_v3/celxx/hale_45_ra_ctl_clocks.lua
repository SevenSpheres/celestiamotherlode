-- RA manual control Clocks
--==================================================================
-- control values
-- RA_Ctl_Angle = Manual_RA_Angle
RA_Ctl_T0 = nil

--==================================================================
-- positioning function used by all RA control clock positioning routines
--==================================================================

RA_Ctl_Move = function(date)

-- velocity = table of spin speed [knob name] * button speed factor
-- theta = theta0 + velocity * time

-- left spinner knob speed
  local v1 = TableOfSpinSpeed["Knob_SpinLeft"]/10.*RADecMotion.MoveRASpeed
-- right button speed
  local v = RADecMotion.MoveRASpeed
  local v2
  if (RADecMotion.HRAEAST) 
   then v2 = - v
  elseif (RADecMotion.HRAWEST) 
   then v2 = v
  else v2 = 0
  end

  local delta_time
  if (RA_Ctl_T0) 
   then delta_time = date - RA_Ctl_T0 
   else delta_time = 0
  end

  local delta_angle = (v1+v2) * delta_time
  local Angle = Manual_RA_Angle + delta_angle
  RA_Ctl_T0 = date
  Manual_RA_Angle = Angle

  return  yPi*celestia:newrotation( zAxis, Angle)
end

--==================================================================
-- RA_Hours functions
--==================================================================
-- hours function calculates positions
-- minutes and seconds just follow along
--==================================================================
RA_Ctl_Hoursproto =
{
   Period    = 1,
}

-- constructor method
function RA_Ctl_Hoursproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Ctl_Hoursproto:orientation(tjd)

	local qNow = 	RA_Ctl_Move(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Ctl_Hours(sscvals)
   -- create a new RA_Ctl_Hours rotation object
   return RA_Ctl_Hoursproto:new(sscvals)
end


--==================================================================
-- RA_Minutes functions
--==================================================================
-- hours function calculates positions
-- minutes and seconds just follow along
--==================================================================
RA_Minute_Rot = function ()
  return  yPi*celestia:newrotation( zAxis, Manual_RA_Angle*24)
end

RA_Ctl_Minutesproto =
{
   Period    = 1,
}

-- constructor method
function RA_Ctl_Minutesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Ctl_Minutesproto:orientation(tjd)

	local qNow = 	RA_Minute_Rot()
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Ctl_Minutes(sscvals)
   -- create a new RA_Ctl_Minutes rotation object
   return RA_Ctl_Minutesproto:new(sscvals)
end


--==================================================================
-- RA_Seconds functions
--==================================================================
-- hours function calculates positions
-- minutes and seconds just follow along
--==================================================================
RA_Second_Rot = function ()
  return  yPi*celestia:newrotation( zAxis, Manual_RA_Angle*1440.0)
end

RA_Ctl_Secondsproto =
{
   Period    = 1,
}

-- constructor method
function RA_Ctl_Secondsproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Ctl_Secondsproto:orientation(tjd)

	local qNow = 	RA_Second_Rot()
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Ctl_Seconds(sscvals)
   -- create a new RA_Ctl_Seconds rotation object
   return RA_Ctl_Secondsproto:new(sscvals)
end
