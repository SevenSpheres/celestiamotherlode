-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
--==================================================================
-- ThreePoleLamp functions: demo version
-- functions for actual switches will test related hardware states
--==================================================================

ThreePoleLampStateTop07 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up, center, down
-- determined by state of associated radio button set

	if ((TableOfValues[Up] == "on") and (State == "on"))
	then return 0
	elseif ( (TableOfValues[Up] == "off") and (State == "on"))
	then return 1e18
	elseif ( (TableOfValues[Up] == "off") and (State == "off"))
	then return 0
	elseif ( (TableOfValues[Up] == "on") and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop07 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop07(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot07 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

	if ((TableOfValues[Down] == "on") and (State == "on"))
	then return 0
	elseif ( (TableOfValues[Down] == "off") and (State == "on"))
	then return 1e18
	elseif ( (TableOfValues[Down] == "off") and (State == "off"))
	then return 0
	elseif ( (TableOfValues[Down] == "on") and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot07 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot07(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end
