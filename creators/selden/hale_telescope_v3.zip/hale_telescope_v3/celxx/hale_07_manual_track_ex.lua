------------------
-- functions for buttons to execute manual RA & Dec values

RA_Ctl_Angle = nil
Manual_RA_Angle = 0
Dec_Ctl_Angle = nil
Manual_Dec_Angle = 0

RAEx = function ()
-- celestia:flash("Track Manual RA")
	RA_Ctl_Angle = Manual_RA_Angle
end

RAExOff = function ()
end

DecEx = function ()
-- celestia:flash("Track Manual Dec")
	Dec_Ctl_Angle = Manual_Dec_Angle
end

DecExOff = function ()
end


-----------------------------------------------
--telescope manual tracking execution

-- left spinner knob, left control button states
 cmds.HRAEX = RAEx
 cmds.Hale_RA_Execute = RAEx
 cmds.HRAEXOFF = RAExOff
 cmds.Hale_RA_Execute_Off = RAExOff

-- left spinner knob, right control button states
 cmds.HDECEX = DecEx
 cmds.Hale_Dec_Execute = DecEx
 cmds.HDECEXOFF = DecExOff
 cmds.Hale_Dec_Execute_Off = DecExOff

-----------------------------------------------
