-- telescope control desks

-- display function only sets 0 true of 1 is true
-- then (next frame) displays desk contols because both are true
-- this is an attempt to give the button a chance to turn green
-- before the desk appears

Demo_view = 3
Control_view = 3

RevealDemoDesk = function (mydate)
	Demo_view = 2
end

HideDemoDesk = function (mydate)
	Demo_view = 3

end

RevealControlDesk = function (mydate)
	Control_view = 2

end

HideControlDesk = function (mydate)
	Control_view = 3
end

