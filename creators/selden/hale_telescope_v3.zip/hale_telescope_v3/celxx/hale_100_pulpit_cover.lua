-- open/close pulpit cover
-- update
--==================================================================
-- revised functional design for switch and controlled devices
-- use just one module file for a specific device:
-- specify globals and command functions
-- update the cmds table 
-- define associated Scripted function(s)
--==================================================================

-- functions to set pulpit cover position parameters

OCPulpitCover = {}
OCPulpitCover.T0 = 1e18
OCPulpitCover.T1 = 0

OCPulpitCover.Down = 0
OCPulpitCover.P0 = OCPulpitCover.Down

OCPulpitCover.Up = math.rad(180)
OCPulpitCover.P1 = OCPulpitCover.Up

OCPulpitCover.Pos0 = OCPulpitCover.Down
OCPulpitCover.Pos1 = OCPulpitCover.Down

OCPulpitCover.TPrev = 1e18
OCPulpitCover.PosPrev = 0

OCPulpitCover.V = 0


RaiseOCPulpitCover = function (mydate)
	MoveToP1(OCPulpitCover,mydate)
end

LowerOCPulpitCover = function (mydate)
	MoveToP0(OCPulpitCover,mydate)
end

StopOCPulpitCover = function (mydate)
	MoveStop(OCPulpitCover,mydate)
end

--==================================================================
-- now that the functions are defined, one can
-- specify the commands which invoke those functions 
--==================================================================

cmds.Hale_Pulpit_Cover_Close     = LowerOCPulpitCover
cmds.HPCCLS              = LowerOCPulpitCover
cmds.Hale_Pulpit_Cover_Open    = RaiseOCPulpitCover
cmds.HPCOPEN            = RaiseOCPulpitCover
cmds.Hale_Pulpit_Cover_Stop   = StopOCPulpitCover
cmds.HPCSTOP            = StopOCPulpitCover

--==================================================================
-- Scripted PCover_Ctl_Angle function
--==================================================================

Pulpit_Cover_Move = function(date)

 	local Angle
	if (date < OCPulpitCover.T0)
	 then Angle = OCPulpitCover.Pos0
     	elseif (date < OCPulpitCover.T1)
      	  then	Angle = OCPulpitCover.PosPrev + OCPulpitCover.V*(date-OCPulpitCover.TPrev)
	else Angle = OCPulpitCover.Pos1
      	end
	OCPulpitCover.TPrev = date
	OCPulpitCover.PosPrev = Angle

 	return  yPi * celestia:newrotation( xAxis, Angle)

end

Pulpit_Cover_Angleproto =
{
   Period    = 1,
}

-- constructor method
function Pulpit_Cover_Angleproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Pulpit_Cover_Angleproto:orientation(tjd)

	local qNow = 	Pulpit_Cover_Move(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Pulpit_Cover_Angle(sscvals)
   -- create a new Cover_Ctl_Angle rotation object
   return Pulpit_Cover_Angleproto:new(sscvals)
end
