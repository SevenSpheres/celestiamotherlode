-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
-- coude yoke axis flat 5m
--==================================================================
-- ThreePoleLamp functions
--==================================================================

ThreePoleLampStateTop09 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up = p0 , center, down = p1
-- determined by state of associated radio button set


-- Top on light visible if flat is up
	if ( MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P0) and (State == "on"))
	then return 0
	elseif ( not MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P0) and (State == "on"))
	then return 1e18

-- Top off light visible if bridge is not down
	elseif ( not MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P0) and (State == "off"))
	then return 0
	elseif ( MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P0) and (State == "off"))
	then return 1e18
	end

-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop09 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop09(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot09 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up = p0 , center, down = p1
-- determined by state of associated radio button set

-- Bot on light visible if flat is down
	if ( MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P1) and (State == "on"))
	then return 0
	elseif ( not MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P1) and (State == "on"))
	then return 1e18

-- Bot off light visible if bridge is not down
	elseif ( not MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P1) and (State == "off"))
	then return 0
	elseif ( MoveNearTh(CoudeFlat5M.PosPrev,CoudeFlat5M.P1) and (State == "off"))
	then return 1e18
	end

-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot09 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot09(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end
