--======================================
-- overhead crane hook cables
--======================================

CableX = function (CableN, date)

-- determine distance between hook and crane
-- i.e. distance between Sol/Earth/hale_hook and ../hale_overhead_crane

-- if closer than this segment's length, 
-- hide this cable segment far away
-- all shorter cable lengths are drawn *shrug*

 local cable_len = 0.0125/(2^CableN) 

 local hook = celestia:find("Sol/Earth/hale_hook")
 local pos_hook = hook:getposition()
 local crane = celestia:find("Sol/Earth/hale_overhead_crane")
 local pos_crane = crane:getposition()
 local dist = pos_hook:distanceto(pos_crane)

--s = "cable_len = "..cable_len..", dist = "..dist
--s = "CableN = "..CableN

--c = collectgarbage("count")
--s = "lua mem usage = "..c
--celestia:flash(s,1)

 if ( dist < cable_len)
  then return 1e18
  else return 0
 end

end


DisplayCable = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals 
	orbit.boundingRadius = 5e18

	function orbit:position (tjd)
--local scn  = sscvals.CableNumber
--celestia:flash("DisplayCable"..scn,1)

		return CableX(sscvals.CableNumber, tjd), 0, 0
	end

return orbit
end
