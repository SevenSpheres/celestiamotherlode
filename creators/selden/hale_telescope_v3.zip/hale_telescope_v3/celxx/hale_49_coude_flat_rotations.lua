--==============================================
-- functions to set coude mirror 90 deg cass rotation parameters

mirror90 = {}
mirror90.T0 = 1e18
mirror90.T1 = 0
mirror90.TPrev = 0

mirror90.South = math.rad(90.0+90.0)
mirror90.East   = math.rad(0.0+90.0)

-- default position is facing south through the frame's gap
mirror90.Th0 = mirror90.South
mirror90.Th1 = mirror90.East
mirror90.ThNow = mirror90.South

mirror90.V = 0

CWMirror90 = function (mydate)
	mirror90.Th0 = mirror90.ThNow
	mirror90.Th1 = mirror90.South 
        mirror90.V = (mirror90.South - mirror90.East)/ dT
	mirror90.T0 = mydate
	local sf = math.abs((mirror90.South-mirror90.ThNow)/(mirror90.South-mirror90.East))
	mirror90.T1 = mydate+dT*sf
	mirror90.TPrev = mydate
end

StopMirror90 = function (mydate)
	mirror90.Th0 = mirror90.ThNow
	mirror90.Th1 = mirror90.ThNow
        mirror90.V = 0
	mirror90.T0 = mydate
	mirror90.T1 = mydate
	mirror90.TPrev = mydate
end

CCWMirror90 = function (mydate)
	mirror90.Th0 = mirror90.ThNow
	mirror90.Th1 = mirror90.East
        mirror90.V = (mirror90.East - mirror90.South)/ dT
	mirror90.T0 = mydate
	local sf = math.abs((mirror90.ThNow-mirror90.East)/(mirror90.South-mirror90.East))
	mirror90.T1 = mydate+dT*sf
	mirror90.TPrev = mydate
end
--=======================================
 cmds.Hale_CW_Coude_Mirror90 = CWMirror90
 cmds.HCWM90              = CWMirror90
 cmds.Hale_Stop_Coude_Mirror90 = StopMirror90
 cmds.HSTOPM90              = StopMirror90
 cmds.Hale_CCW_Coude_Mirror90 = CCWMirror90
 cmds.HCCWM90              = CCWMirror90
--=======================================

-- object (coude mirror90, elevator) rotation about Y axis

CoudeRotY = function ( date )

	local Angle = mirror90.ThNow
     	if ((date > mirror90.T0) and (date <= mirror90.T1))
      	then
	  Angle = mirror90.ThNow + mirror90.V*(date-mirror90.TPrev)
      	end

	mirror90.ThNow = Angle
	mirror90.TPrev = date

	return celestia:newrotation( yAxis, Angle)
end
-- ==========================================================
-- mirror90Rotate -- rotate coude mirror90

mirror90RotateProto = { } -- no args

-- constructor method

function mirror90RotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

 	o.period = 1

	return o
end

-- orientation function

function mirror90RotateProto:orientation(tjd)

	local qNow = CoudeRotY( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function Mirror90Rotate(sscvals)

	return mirror90RotateProto:new(sscvals)

end
