-- cassegrain instruments

AOX = 0  -- default instrument
COX = 1e18
TripleSpecX = 1e18
DoubleSpecX = 1e18

-- ==========================================================
-- hide all Cass instr
-- ==========================================================
HideCI = function (mydate)
	COX = 1e18
AOX = 1e18
CSX = 1e18
TripleSpecX = 1e18
DoubleSpecX = 1e18
end


-- ==========================================================
-- Adaptive optics
-- ==========================================================

HideAO = function (mydate)
	AOX = 1e18
end

RevealAO = function (mydate)
	AOX = 0
COX = 1e18
TripleSpecX = 1e18
DoubleSpecX = 1e18
end

AOLightX = 1e18
HideAOLight = function (mydate)
	AOLightX = 1e18
end

RevealAOLight = function (mydate)
	AOLightX = 0
end

-- ==========================================================
-- Cass Observer
-- ==========================================================

HideCO = function (mydate)
	COX = 1e18
end

RevealCO = function (mydate)
	COX = 0
AOX = 1e18
TripleSpecX = 1e18
DoubleSpecX = 1e18

-- hide cass cage, too
CFCX = 1e18

end

-- ==========================================================
-- Cass Double Spectrograph
-- ==========================================================

HideDS = function (mydate)
DoubleSpecX = 1e18
end

RevealDS = function (mydate)
DoubleSpecX = 0
COX = 1e18
AOX = 1e18
TripleSpecX = 1e18

end



-- ==========================================================
--- PHARO FoV
-- ==========================================================

PHAROFoVX = 0

-- LFC fov anytime 
HidePHAROFoV = function (mydate)
	PHAROFoVX = 1e18
end
RevealPHAROFoV = function (mydate)
	PHAROFoVX = 0
end
--======================================
-- Cass Triple-Spectrometer

Hide3S = function (mydate)
	TripleSpecX = 1e18
end

Reveal3S = function (mydate)
	TripleSpecX = 0
COX = 1e18
AOX = 1e18
DoubleSpecX = 1e18
end

-- ------------------------
-- cass instr selection commands
-- ------------------------

 cmds.Hale_Hide_Cass_Instr = HideCI
 cmds.HHCI                 = HideCI

 cmds.Hale_Hide_Cass_Obs = HideCO
 cmds.HHCO                 = HideCO
 cmds.Hale_Reveal_Cass_Obs = RevealCO
 cmds.HRCO                 = RevealCO

 cmds.Hale_Hide_Double_Spect = HideDS
 cmds.HHDS                 = HideDS
 cmds.Hale_Reveal_Double_Spect = RevealDS
 cmds.HRDS                 = RevealDS

 cmds.Hale_Hide_AO = HideAO
 cmds.HHAO                 = HideAO
 cmds.Hale_Reveal_AO = RevealAO
 cmds.HRAO                 = RevealAO
 cmds.Hale_Hide_AOLight = HideAOLight
 cmds.HHAOL                 = HideAOLight
 cmds.Hale_Reveal_AOLight = RevealAOLight
 cmds.HRAOL                 = RevealAOLight

 cmds.Hale_Hide_PHARO_FOV = HidePHAROFoV
 cmds.HHPAFOV                 = HidePHAROFoV
 cmds.Hale_Reveal_PHARO_FOV = RevealPHAROFoV
 cmds.HRPAFOV                 = RevealPHAROFoV

cmds.HH3S = Hide3S
cmds.Hale_Hide_TripleSpec = Hide3S
cmds.HR3S = Reveal3S
cmds.Hale_Reveal_TripleSpec = Reveal3S

--======================================
-- Cass Triple-Spectrometer
--======================================
DisplayTripleSpec = function (sscvals)

	local orbit = {}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4
	orbit.period = 1
	function orbit:position (tjd)
-- s = "TripleSpecX = "..TripleSpecX
-- celestia:flash(s)
		return TripleSpecX, 0, 0
	end

return orbit
end


--======================================
-- Cass Double-Spectrometer
--======================================
DisplayDoubleSpec = function (sscvals)

	local orbit = {}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4
	orbit.period = 1
	function orbit:position (tjd)
		return DoubleSpecX, 0, 0
	end

return orbit
end

DisplayStoredDoubleSpec = function (sscvals)

	local orbit = {}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4
	orbit.period = 1
	function orbit:position (tjd)
		return DoubleSpecX-1e18, 0, 0
	end

return orbit
end

--======================================
-- Observer at Cass focus
--======================================
DisplayCO = function (sscvals)

	local orbit = {}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4
	orbit.period = 1
	function orbit:position (tjd)
		return COX, 0, 0
	end

return orbit
end

--======================================
-- ChairStand under Observer at Cass focus
--======================================
COStandPosition = function (myobs,date)

	local obs = celestia:find(myobs)
	local earth = celestia:find("Sol/Earth")
	local obs_pos = obs:getposition(date)
	local earth_pos = earth:getposition(date)

-- assumes spherical earth.
	local EarthRadius = 6378.140
	local AltitudeOfObservatoryFloor = EarthRadius + 1.7511 --1.75717551435
	dist = obs_pos:distanceto(earth_pos)-AltitudeOfObservatoryFloor
-- s = "dist = "..dist
-- celestia:flash(s)

return -dist

end

DisplayCOStand = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4
--	orbit.period = 1

	function orbit:position (tjd)

	local MyObs = self.params.Observer
		return 0,0,COStandPosition(MyObs,tjd)
--		return 0, 0, 0
	end

return orbit
end

DisplayCOStandCyl = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4
	orbit.period = 1

	function orbit:position (tjd)

	local MyObs = self.params.Observer
		return 0,0,COStandPosition(MyObs,tjd)/2.0
	end

return orbit
end


--======================================
-- Adaptive optics optical bench
--======================================
DisplayAO = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return AOX, 0, 0
	end

return orbit
end


--======================================
-- Adaptive optics light paths
--======================================
DisplayAOLight = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return AOLightX, 0, 0
	end

return orbit
end

--======================================
-- PHARO Field of View
--======================================
DisplayPHAROFoV = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return PHAROFoVX, 0, 0
	end

return orbit
end
