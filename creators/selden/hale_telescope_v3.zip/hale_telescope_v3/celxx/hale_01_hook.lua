-- hale_01_hook.lua
-- A Lua Module to help control the model of the Hale Telescope
-- � Selden Ball, December, 2007. All rights reserved. 
--
-- ==========================================================
-- the variables here are all globals: preserved between screen refreshes

-- functions to set overhead crane hook parameters

Hook = {}
Hook.T0 = 1e18
Hook.T1 = 0
Hook.V = 0

Hook.Up    =  0.0007
Hook.Down  = -0.021
Hook.X1 = Hook.Up
Hook.X0 = Hook.Up
Hook.Xprv = Hook.Up

DownHook = function (mydate)
	Hook.X0 = Hook.Xprv
	Hook.X1 = Hook.Down
        Hook.V = (Hook.Down - Hook.Up)/  (2*dT)
	Hook.T0 = mydate
	Hook.T1 = mydate+( (2*dT) *math.abs((Hook.Down-Hook.Xprv)/(Hook.Down-Hook.Up)))
--	Hook.T1 = mydate+( (2*dT))
end

UpHook = function (mydate)
	Hook.X0 = Hook.Xprv
	Hook.X1 = Hook.Up
        Hook.V = (Hook.Up - Hook.Down)/  (2*dT)
	Hook.T0 = mydate
	Hook.T1 = mydate+( (2*dT) *math.abs((Hook.Xprv-Hook.Up)/(Hook.Down-Hook.Up)))
--	Hook.T1 = mydate+( (2*dT))
end

StopHook = function (mydate)
	Hook.X0 = Hook.Xprv
	Hook.X1 = Hook.Xprv
        Hook.V = 0
	Hook.T0 = mydate
	Hook.T1 = mydate
end
