
--======================================================
-- place lamp corresponding to telescope position:
-- light lamp when telescope is close to tracked position
--======================================================
TDLampState = function (LampN,date)

	local deltaRA = math.abs(prevRA - desiredRA)
	local deltaDecl = math.abs(prevDecl - desiredDecl)
	local distance = deltaRA + deltaDecl

	local onoff = "off"
	if (distance < 1e-5) 
	 then onoff = "on"
	end

	 if (onoff == LampN)
	    then return 0
	    else return 1e18
	 end
end



--======================================================
DisplayTDLamp = function (sscvals)

	local orbit = {}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		 return TDLampState(self.params.LampN,tjd), 0, 0
	end

return orbit
end
