
--============================================================
-- photons
--============================================================

  PhotonPos = function ( PhotonN, PathN, date )
 
        local PhotonZPos;
        local PhotonXPos = PhotonPath.X0[PathN] + PhotonPath.R(PathN,date)* math.sin( math.pi*PhotonN/2.0)
 	local PhotonYPos = 0
-- s = " photon "..PnotonN..', path '..PathN
-- celestia:flash(s)

      if (date < PhotonPath.T0) -- photons not moving yet
        then PhotonZPos = 1e32 -- PhotonPath.Z0[PathN]
       elseif (date < PhotonPath.T1)
        then  -- photons moving
	    PhotonZPos = PhotonPath.Z0[PathN] + PhotonPath.Vz[PathN]*(date-PhotonPath.T0)
	 if PhotonPath.Vy[PathN] ~= 0 then -- hack for coude-bridge
	    PhotonYPos = PhotonPath.Y0[PathN] + PhotonPath.Vy[PathN]*(date-PhotonPath.T0)
	 elseif PhotonPath.Vx[PathN] ~= 0 then -- hack for cass-coude
	    PhotonZPos = PhotonXPos
	    PhotonXPos = PhotonPath.X0[PathN] + PhotonPath.Vx[PathN]*(date-PhotonPath.T0)
	  end
        else  -- photons move again
	  PhotonPath.T0 = date
	  PhotonPath.T1 = date + PhotonPath.dT
       end

       PhotonYPos = PhotonYPos + PhotonPath.R(PathN,date)* math.cos( math.pi*PhotonN/2.0)

 -- current photon position
        return PhotonXPos, PhotonYPos, PhotonZPos
  end
 
 
  DisplayPhoton = function (sscvals)
 
        local orbit = {}
        orbit.params = sscvals
        orbit.boundingRadius = 1e3
 
        function orbit:position (tjd)
 
--                return PhotonPos (sscvals.Photon, sscvals.Path, tjd)
                return PhotonPos (self.params.Photon, self.params.Path, tjd)
        end
 
return orbit
end

--============================================================
-- the light paths
--============================================================


DisplayLight1 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return primeX, 0, 0
	end

return orbit
end
DisplayLight2 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return cassX, 0, 0
	end

return orbit
end
-- part of coude path relative to telescope
DisplayLight42 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return coudeTelX, 0, 0
	end

return orbit
end

-- standard coude relative to yoke
DisplayLight43 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return coudeX, 0, 0
	end

return orbit
end

-- relative to yoke
DisplayLight53 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return bridgeCoudeX, 0, 0
	end

return orbit
end

DisplayLight32 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return cassCoudeX, 0, 0
	end

return orbit
end


-- incoming light
DisplayLight0 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return inX, 0, 0
	end

return orbit
end
