------------------
-- sidereal/tracking toggle and rotary switch #682 functions
-- state of SidTrk used to select manual target or Celestia target selection
--

-- telescope tracking toggle switch functions

TrackingState = "Select"
TrackingSwitch = "Select"

SidTrk = {}
SidTrk.state = "Select"
SidTrk.RAOff = nil
SidTrk.SidOff = nil
SidTrk.DecOff = nil

TrackOffPos = function ()
	local sel = celestia:find("Sol/Earth/hale_position")
	local vp = celestia:find("Sol/Earth")
	local ra,dec = pkg.get_ra_dec (vp,sel)
	return ra,dec
end


TrackSel = function ()
	TrackingSwitch = "Select"
	TrackingState = SidTrk.state
end

-- not used any more; left so lua code doesn't break
TrackManual = function ()
	TrackingSwitch = "Manual"
	TrackingState = "Manual"
	if (SidTrk.state ~= "Select")
	 then TrackingState = SidTrk.state
	 else 	TrackingState = "Manual"
	end

end

TrackOff = function (mydate)
	TrackingSwitch = "Off"
	if (SidTrk.state ~= "Select")
	 then TrackingState = SidTrk.state
	 else 	
		TrackingState = "Off"

-- if not tracking, set RA & Dec params to current location
-- (if SidTrk.state already was off, these values already were set)
		SidTrk.RAOff = prevRA
		SidTrk.SidOff,SidTrk.DecOff = TrackOffPos()
	end
end

-----------------------------------------------
--telescope tracking control

 cmds.Hale_Tracking_Manual = TrackManual
 cmds.HTMAN = TrackManual
 cmds.Hale_Tracking_Off = TrackOff
 cmds.HTOFF = TrackOff
 cmds.Hale_Tracking_Selected = TrackSel
 cmds.HTSEL = TrackSel
-----------------------------------------------
-- telescope tracking rotary switch functions

SidTrkTrack = function ()
	SidTrk.state = "Select"
	TrackingState = TrackingSwitch
end

SidTrkOff = function ()
	SidTrk.saved = SidTrk.state
	SidTrk.state = "Off"
	TrackingState = "Off"

-- and set RA & Dec params to current location

	SidTrk.RAOff = prevRA
	SidTrk.SidOff,SidTrk.DecOff = TrackOffPos()
end

-- not on switch: used by Trip buttons
SidTrkOn = function ()

	SidTrk.state = SidTrk.saved
	TrackingState = SidTrk.state

-- and set RA & Dec params to current location

	SidTrk.RAOff = prevRA
	SidTrk.SidOff,SidTrk.DecOff = TrackOffPos()
end

-- "sidereal" = "manual"
SidTrkSid = function ()
	SidTrk.state = "Manual"
	TrackingState =  "Manual"
end

-- ==========================================================

cmds.HSTSID = SidTrkSid
cmds.Hale_SidTrk_Sidereal = SidTrkSid
cmds.HSTOFF = SidTrkOff
cmds.Hale_SidTrk_Off = SidTrkOff
cmds.HSTON = SidTrkOn
cmds.Hale_SidTrk_On = SidTrkOn
cmds.HSTTRK = SidTrkTrack
cmds.Hale_SidTrk_Tracking = SidTrkTrack

-- ==========================================================
-- see hale_07_tracking.lua for orientation routines
