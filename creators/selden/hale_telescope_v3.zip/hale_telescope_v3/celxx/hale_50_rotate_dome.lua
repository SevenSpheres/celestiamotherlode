-- ---------------------------------------
-- Motion control for dome top
-- ---------------------------------------

-- table of motion parameters

DomeTop = {}
InitMoveTable(DomeTop,math.rad(-179.9),math.rad(179.9))
DomeTop.Pos0 = 0
DomeTop.Pos1 = 0
DomeTop.PosPrev = 0

-- ---------------------------------------
-- movement initialization functions

RightDomeTop = function()
	MoveToP1(DomeTop,mydate)

-- also force windscreen down: 
-- the windscreen model tracks the telescope's target
-- not the dome

 local obj = celestia:find("Sol/Earth/200in/hale_windscreen_model")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_up")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_down")
 obj:setvisible(true)
 local obj = celestia:find("Sol/Earth/200in/hale_WindScreen_down")
 obj:setvisible(true)
end

LeftDomeTop = function (mydate)
	MoveToP0(DomeTop,mydate)
 local obj = celestia:find("Sol/Earth/200in/hale_windscreen_model")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_up")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_down")
 obj:setvisible(true)
 local obj = celestia:find("Sol/Earth/200in/hale_WindScreen_down")
 obj:setvisible(true)
end

StopDomeTop = function (mydate)
	MoveStop(DomeTop,mydate)
 local obj = celestia:find("Sol/Earth/200in/hale_windscreen_model")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_up")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_down")
 obj:setvisible(true)
 local obj = celestia:find("Sol/Earth/200in/hale_WindScreen_down")
 obj:setvisible(true)
end

-- ---------------------------------------
-- movement commands

-- Dome Rotation switch 61
cmds.HDRLEFT = LeftDomeTop
cmds.Hale_DomeRotation_Left  = LeftDomeTop
cmds.HDRSTOP = StopDomeTop
cmds.Hale_DomeRotation_Stop = StopDomeTop
cmds.HDRRIGHT = RightDomeTop
cmds.Hale_DomeRotation_Right = RighDomeTop

-- ---------------------------------------
-- motion method

DomeRot = function (date)
	local Angle = MoveNow (DomeTop,date)
	return  yPi*celestia:newrotation( yAxis, Angle)
end

-- ==========================================================
-- RotateDome left or right

RotateDomeProto = { } -- no args

-- constructor method

function RotateDomeProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

 	o.period = 1

	return o
end

-- orientation function

function RotateDomeProto:orientation(tjd)

	local qNow = DomeRot( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function RotateDome(sscvals)

	return RotateDomeProto:new(sscvals)

end

