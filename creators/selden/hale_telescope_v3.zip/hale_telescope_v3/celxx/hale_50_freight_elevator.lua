-- ---------------------------------------
-- Motion control for freight elevator
-- ---------------------------------------

-- ==================================================
-- cage
-- ==================================================
-- table of motion parameters

FreightElevator = {}
InitMoveTable(FreightElevator,0,-0.013)

-- ---------------------------------------
-- movement initialization functions

DownFreightElevator = function()
	MoveToP1(FreightElevator,mydate)
end

UpFreightElevator = function (mydate)
	MoveToP0(FreightElevator,mydate)
end

StopFreightElevator = function (mydate)
	MoveStop(FreightElevator,mydate)
end

-- ---------------------------------------
-- movement commands

 cmds.Hale_Up_Freight_Elevator = UpFreightElevator
 cmds.HUFE                 = UpFreightElevator
 cmds.Hale_Down_Freight_Elevator = DownFreightElevator
 cmds.HDFE                 = DownFreightElevator
 cmds.Hale_Stop_Freight_Elevator = StopFreightElevator
 cmds.HSFE                 = StopFreightElevator

-- ---------------------------------------
-- motion method

MoveFreightElevator = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,0,MoveNow(FreightElevator,tjd)
	end

return orbit
end


-- ==================================================
-- upper door
-- ==================================================
-- table of motion parameters

FreightElevatorUpperDoor = {}
InitMoveTable(FreightElevatorUpperDoor,0,1.0)

-- ---------------------------------------
-- movement initialization functions

OpenFreightElevatorUpperDoor = function()
	MoveToP1(FreightElevatorUpperDoor,mydate)
end

CloseFreightElevatorUpperDoor = function (mydate)
	MoveToP0(FreightElevatorUpperDoor,mydate)
end

StopFreightElevatorUpperDoor = function (mydate)
	MoveStop(FreightElevatorUpperDoor,mydate)
end

-- ---------------------------------------
-- movement commands

 cmds.Hale_Open_Freight_Elevator = OpenFreightElevatorUpperDoor
 cmds.HOFEUD                 = OpenFreightElevatorUpperDoor
 cmds.Hale_Close_Freight_Elevator = CloseFreightElevatorUpperDoor
 cmds.HCFEUD                 = CloseFreightElevatorUpperDoor
 cmds.Hale_Stop_Freight_Elevator = StopFreightElevatorUpperDoor
 cmds.HSFEUD                 = StopFreightElevatorUpperDoor

-- ---------------------------------------
-- motion method

MoveFreightElevatorUpperDoor = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,self.params.Distance*MoveNow(FreightElevatorUpperDoor,tjd),0
	end

return orbit
end


-- ==================================================
-- lower door
-- ==================================================
-- table of motion parameters

FreightElevatorLowerDoor = {}
InitMoveTable(FreightElevatorLowerDoor,0,1.0)

-- ---------------------------------------
-- movement initialization functions

OpenFreightElevatorLowerDoor = function()
	MoveToP1(FreightElevatorLowerDoor,mydate)
end

CloseFreightElevatorLowerDoor = function (mydate)
	MoveToP0(FreightElevatorLowerDoor,mydate)
end

StopFreightElevatorLowerDoor = function (mydate)
	MoveStop(FreightElevatorLowerDoor,mydate)
end

-- ---------------------------------------
-- movement commands

 cmds.Hale_Open_Freight_Elevator = OpenFreightElevatorLowerDoor
 cmds.HOFELD                 = OpenFreightElevatorLowerDoor
 cmds.Hale_Close_Freight_Elevator = CloseFreightElevatorLowerDoor
 cmds.HCFELD                 = CloseFreightElevatorLowerDoor
 cmds.Hale_Stop_Freight_Elevator = StopFreightElevatorLowerDoor
 cmds.HSFELD                 = StopFreightElevatorLowerDoor

-- ---------------------------------------
-- motion method

MoveFreightElevatorLowerDoor = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0,self.params.Distance*MoveNow(FreightElevatorLowerDoor,tjd),0
	end

return orbit
end
