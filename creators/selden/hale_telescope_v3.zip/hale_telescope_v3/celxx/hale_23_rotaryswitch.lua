-- Rotary Switch control

-- direction to point rotary knob
TableOfRotaryPos = {}

--==================================================================
--==================================================================
-- RotaryButton functions: switches among N states
--==================================================================
RotaryState = function(BRadio,ButtonName,ButtonMove,BOff,BOn,BIState,BIMove,date)
   if (sameSel) then return TableOfPositions[ButtonName] end
   local todo = nil
   local sel = selP

	local BIS = BIState
	if (BIS == nil) then BIS = "off" end
	local BIM = BIMove
	if (BIM == nil) then BIM = 0 end

   if (sel:name() == ButtonName)  
   then
--	this button selected. Is it in the list?
	  if (TableOfButtons[ButtonName] == ButtonName )
          then
--	in list =yes: change button state only from off to on
	    if (TableOfValues[ButtonName] == "off")
	    then 
		TableOfRotaryPos[BRadio] = ButtonMove
		todo = cmds[BOn]; if todo then todo(date) end
	    end

-- this button is selected, so the state of this selected button is on
-- these could be inside the if, but I'm being paranoid

--	make sure all other members of this radio set are off
	  for j,r in pairs(TableOfButtons) do
	     if (TableOfRadios[j] == BRadio and r ~= ButtonName)
	     then
		TableOfValues[j] = "off"  
		TableOfPositions[j] = 0
	     end
	  end -- for j,r loop

-- 	selected and found in list: restore previous selection and move button
	  TableOfValues[ButtonName] = "on"
	  TableOfPositions[ButtonName] = ButtonMove
	  celestia:select(TableOfSelections[ButtonName])
  	  return TableOfPositions[ButtonName]
	 end

--	button selected but not in list: add it
--	this also means no previous selection known!!
--	(and this probably can't actually happen)

	TableOfRadios[ButtonName] = BRadio
	TableOfButtons[ButtonName] = ButtonName
	TableOfRotaryPos[BRadio] = ButtonMove
	TableOfValues[ButtonName] = BIS
	TableOfPositions[ButtonName] = BIM

-- 	restore selection (i.e.set to nil) and position button
	celestia:select(TableOfSelections[ButtonName])
	return TableOfPositions[ButtonName]
   else 

-- this button is not selected
--	is it already known?
	if (TableOfButtons[ButtonName] == ButtonName )
          then
--	 known:
--	 record actual selection for later
	   TableOfSelections[ButtonName] = sel
-- 	 and return this button's current position
	   return TableOfPositions[ButtonName]
	  end 

--	not selected, but not in list: add it

--	celestia:flash("new:"..ButtonName)
	TableOfRadios[ButtonName] = BRadio
	TableOfButtons[ButtonName] = ButtonName

	TableOfValues[ButtonName] = BIS
	TableOfPositions[ButtonName] = BIM
	if (BIS == "on") then TableOfRotaryPos[BRadio] = ButtonMove end

	TableOfSelections[ButtonName] = sel
-- 	 and return this button's current position
	return TableOfPositions[ButtonName]
   end
   return 0 -- can't get here
end


--======================================================
--======================================================
-- ScriptedOrbit function 
--======================================================
RotaryButton = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
-- intermediate values just to keep function call line short
		local BRadio=self.params.ButtonRadio
		local BName=self.params.ButtonName
		local BMove =self.params.ButtonMove
		local BOn =self.params.ButtonOn
		local BIS = self.params.InitialState
		local BIM = self.params.InitialMove
		RotaryState(BRadio,BName,BMove,BOff,BOn,BIS,BIM,tjd)
-- buttonmove = angle of central rotary switch

-- rotary switch's buttons don't move
		return 0, 0, 0
	end

return orbit
end

--==================================================================
RotarySwitchStateVal = {}
--==================================================================
-- RotarySwitch functions
--==================================================================
RotarySwitchState = function(BName)
-- desired angle set by which RotaryButton was selected
--s = BName
--celestia:flash(s)
   if (sameSel) then  	return  RotarySwitchStateVal[BName] end

	local AngleD =((360.0/8.0)*TableOfRotaryPos[BName])
	local Angle = math.rad(AngleD)
	RotarySwitchStateVal[BName] = yPi*celestia:newrotation( yAxis, Angle)
 	return  RotarySwitchStateVal[BName]
end


--==================================================================
RotarySwitchproto =
{
   Period    = 1,
}

-- constructor method
function RotarySwitchproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RotarySwitchproto:orientation(tjd)

	local SName = self.ButtonRadio
	local qNow = 	RotarySwitchState(SName)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RotarySwitch(sscvals)
   -- create a new RotarySwitch rotation object
   return RotarySwitchproto:new(sscvals)
end
