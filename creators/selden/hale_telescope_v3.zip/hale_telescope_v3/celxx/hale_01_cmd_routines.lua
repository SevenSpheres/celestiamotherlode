-- hale_1.lua
-- A Lua Module to help control the model of the Hale Telescope
-- � Selden Ball, September, 2007. All rights reserved. 
--
-- ==========================================================
-- the variables here are all globals: preserved between screen refreshes
-- most probably should be table elements, not individual variables.

second =  0.11574074051168E-04

minute = 60 * second
  hour = 60 * minute
   day = 24 * hour -- dam well better be 1.0000 (tested: it is)

-- arbitrary duration for all movements. For some it's too slow, for others it's too fast.
dT = 10*second

xAxis = celestia:newvector( 1, 0, 0)
yAxis = celestia:newvector( 0, 1, 0)
zAxis = celestia:newvector( 0, 0, 1)
  xPi = celestia:newrotation( xAxis, math.pi)
  yPi = celestia:newrotation( yAxis, math.pi)
  yPi2 = celestia:newrotation( yAxis, -math.pi/2)
  yR0 = celestia:newrotation( yAxis, 0)
  zPi = celestia:newrotation( zAxis, math.pi)
--====================================================================
-- command functions
--====================================================================

require ("hale_01_ocrane")
require ("hale_01_hook")
require ("hale_01_pf")
require ("hale_01_cass_instr")
require ("hale_01_cfd")
require ("hale_01_tracking")
require ("hale_01_labels")

require ("hale_01_storage_room_doors")
require ("hale_01_elevator")
require ("hale_01_right_spinner_buttons")


-- ------------------------
-- generic motion functions
-- ------------------------

InitMoveTable = function (obj,first,last)
	obj.T0 = 1e18
	obj.T1 = 0

	obj.P0 = first
	obj.P1 = last

	obj.Pos0 = first
	obj.Pos1 = first

	obj.TPrev = 1e18
	obj.PosPrev = first

	obj.V = 0
end


MoveToP1 = function (obj,mydate)
	obj.Pos0 = obj.PosPrev
	obj.Pos1 = obj.P1
	obj.V = (obj.P1-obj.P0)/dT
	obj.T0 = obj.TPrev
	local sf = math.abs((obj.P1-obj.PosPrev)/(obj.P1-obj.P0))
	obj.T1 = obj.TPrev+dT*sf
end

MoveToP0 = function (obj,mydate)
	obj.Pos0 = obj.PosPrev
	obj.Pos1 = obj.P0
	obj.V = (obj.P0-obj.P1)/dT
	obj.T0 = obj.TPrev
	local sf = math.abs((obj.P0-obj.PosPrev)/(obj.P1-obj.P0))
	obj.T1 = obj.TPrev+dT*sf
end

MoveStop = function (obj,mydate)
	obj.Pos0 = obj.PosPrev
	obj.Pos1 = obj.PosPrev
	obj.V = 0
	obj.T0 = mydate
	obj.T1 = mydate
	obj.TPrev = mydate
end

MoveNearTh = function (p1,p2)
	local delta = math.rad(1)
	if (math.abs(p1-p2) < delta)
	 then return true
	 else return false
	end
end

MoveNow = function (obj,date)
 	local pos
	if (date < obj.T0)
	 then pos = obj.Pos0
     	elseif (date < obj.T1)
      	  then	pos = obj.PosPrev + obj.V*(date-obj.TPrev)
	else pos = obj.Pos1
      	end
	obj.TPrev = date
	obj.PosPrev = pos
	return pos
end

-- functions to set door parameters

Door = {}
DoorT0 = 1e18
DoorT1 = 0

DoorClosed = 0
DoorOpen   = 0.0046
DoorX1 = DoorClosed
DoorX0 = DoorClosed

OpenDoor = function (mydate)
	DoorX0 = DoorClosed
	DoorX1 = DoorOpen
        DoorV = (DoorX1 - DoorX0)/ dT
	DoorT0 = mydate
	DoorT1 = mydate+dT
end

CloseDoor = function (mydate)
	DoorX0 = DoorOpen
	DoorX1 = DoorClosed
        DoorV = (DoorX1 - DoorX0)/ dT
	DoorT0 = mydate
	DoorT1 = mydate+dT
end



  -- functions to set Photon flight data
 
  PhotonPath    =  {}
  PhotonPath.X0 =  {}
  PhotonPath.X1 =  {}
  PhotonPath.Y0 =  {}
  PhotonPath.Y1 =  {}
  PhotonPath.Z0 =  {}
  PhotonPath.Z1 =  {}
  PhotonPath.Vx  =  {}
  PhotonPath.Vy  =  {}
  PhotonPath.Vz  =  {}
  PhotonPath.R0 =  {}
  PhotonPath.R1 =  {}
  PhotonPath.Vr =  {}

  PhotonPath.T0 = 1e18
  PhotonPath.T1 = 0
  PhotonPath.dT = dT

  PhotonPreset    =  {}
  PhotonPreset.X0 =  {}
  PhotonPreset.X1 =  {}
  PhotonPreset.Y0 =  {}
  PhotonPreset.Y1 =  {}
  PhotonPreset.Z0 =  {}
  PhotonPreset.Z1 =  {}
  PhotonPreset.Vx  =  {}
  PhotonPreset.Vy  =  {}
  PhotonPreset.Vz  =  {}
  PhotonPreset.R0 =  {}
  PhotonPreset.R1 =  {}
  PhotonPreset.Vr =  {}

  PhotonPreset.T0 = 1e18
  PhotonPreset.T1 = 0
  PhotonPreset.dT = dT

-- controlled paths of photons are numbered 0-5
-- could be any of the light segments

-- initialize displayed paths
-- 0-3 relative to telescope
-- 4-6 relative to yoke

initPhotonPaths = function ()
 for i = 0,6 do
  PhotonPath.X0[i] = 0
  PhotonPath.X1[i] = 0
  PhotonPath.Y0[i] = 0
  PhotonPath.Y1[i] = 0
  PhotonPath.Z0[i] = 0
  PhotonPath.Z1[i] = 0
  PhotonPath.Vx[i] = 0
  PhotonPath.Vy[i] = 0
  PhotonPath.Vz[i] = 0
  PhotonPath.R0[i] = 0
  PhotonPath.R1[i] = 0
  PhotonPath.Vr[i] = 0
 end
end

initPhotonPaths()

-- ensure all presets are predefined
-- although not all indices will be used
 for i = 0,55 do
  PhotonPreset.X0[i] = 0
  PhotonPreset.X1[i] = 0
  PhotonPreset.Y0[i] = 0
  PhotonPreset.Y1[i] = 0
  PhotonPreset.Z0[i] = 0
  PhotonPreset.Z1[i] = 0
  PhotonPreset.Vx[i] = 0
  PhotonPreset.Vy[i] = 0
  PhotonPreset.Vz[i] = 0
  PhotonPreset.R0[i] = 0
  PhotonPreset.R1[i] = 0
  PhotonPreset.Vr[i] = 0
end

-- numeric indices are for individual fragments of the light paths
--  0 = incoming to primary, 1 = primary to prime focus, 
-- 21 = cass from primary to 2ndary, 22 = cass from 2ndary to fp
-- 32 = cass from 2ndary to coude, 33 = cass from coude to trunion
--      34 = cass from trunion to fp
-- 42 = coude from 2ndary to coude mirror, 43 from coude to fp
-- 53 = coude from coude to bridge, 54 from bridge to yoke, 55 yoke to fp

--  0 = incoming to primary, 1 = primary to prime focus, 
  PhotonPreset.Z0[0] =  0.027
  PhotonPreset.Z1[0] = -0.0042
  PhotonPreset.Vz[0] = (PhotonPreset.Z1[0] - PhotonPreset.Z0[0])/ (PhotonPreset.dT)
  PhotonPreset.R0[0] = 0.0019
  PhotonPreset.R1[0] = 0.0019
  PhotonPreset.Vr[0] =  0

-- 1 = prime focus path
  PhotonPreset.Z0[1] = -0.0042
  PhotonPreset.Z1[1] =  0.0102
  PhotonPreset.Vz[1] = (PhotonPreset.Z1[1] - PhotonPreset.Z0[1])/ (PhotonPreset.dT)
  PhotonPreset.R0[1] = 0.0019
  PhotonPreset.R1[1] = 0.0000
  PhotonPreset.Vr[1] = (PhotonPreset.R1[1] - PhotonPreset.R0[1])/ (PhotonPreset.dT)
 
--============================================================= 
-- 21 = cass from primary to 2ndary, 22 = cass from 2ndary to fp
  PhotonPreset.Z0[21] = -0.0042
  PhotonPreset.Z1[21] = 0.007
  PhotonPreset.Vz[21] = (PhotonPreset.Z1[21] - PhotonPreset.Z0[21])/ (PhotonPreset.dT)
  PhotonPreset.R0[21] = 0.0019
  PhotonPreset.R1[21] = 0.00035
  PhotonPreset.Vr[21] = (PhotonPreset.R1[21] - PhotonPreset.R0[21])/ (PhotonPreset.dT)
 
  PhotonPreset.Z0[22] = 0.007
  PhotonPreset.Z1[22] = -0.0055
  PhotonPreset.Vz[22] = (PhotonPreset.Z1[22] - PhotonPreset.Z0[22])/ (PhotonPreset.dT)
  PhotonPreset.R0[22] = 0.00035
  PhotonPreset.R1[22] = 0.0
  PhotonPreset.Vr[22] = (PhotonPreset.R1[22] - PhotonPreset.R0[22])/ (PhotonPreset.dT)
 
--============================================================= 
-- 32 = cass from 2ndary to coude, 33 = cass from coude to trunion
-- 34 = cass from trunion to fp
  PhotonPreset.Z0[32] = 0.007
  PhotonPreset.Z1[32] = 0.0
  PhotonPreset.Vz[32] = (PhotonPreset.Z1[32] - PhotonPreset.Z0[32])/ (PhotonPreset.dT)
  PhotonPreset.R0[32] = 0.00035
  PhotonPreset.R1[32] = 0.00017
  PhotonPreset.Vr[32] = (PhotonPreset.R1[32] - PhotonPreset.R0[32])/ (PhotonPreset.dT)
 
-- relative to yoke: -x
  PhotonPreset.Z0[33] = 0.0
  PhotonPreset.Z1[33] = 0.0
  PhotonPreset.Vz[33] = 0.0

  PhotonPreset.X0[33] = 0.0
  PhotonPreset.X1[33] = -0.00442
  PhotonPreset.Vx[33] = (PhotonPreset.X1[33] - PhotonPreset.X0[33])/ (PhotonPreset.dT)
  PhotonPreset.R0[33] = 0.00017
  PhotonPreset.R1[33] = 0.00005
  PhotonPreset.Vr[33] = (PhotonPreset.R1[33] - PhotonPreset.R0[33])/ (PhotonPreset.dT)
 
-- relative to yoke: z again
  PhotonPreset.X0[34] = -0.00442
  PhotonPreset.X1[34] = -0.00442
  PhotonPreset.Vx[34] =  0.0

  PhotonPreset.Z0[34] =  0.0 
  PhotonPreset.Z1[34] = -0.0016
  PhotonPreset.Vz[34] = (PhotonPreset.Z1[34] - PhotonPreset.Z0[34])/ (PhotonPreset.dT)
  PhotonPreset.R0[34] = 0.00005
  PhotonPreset.R1[34] = 0.00000
  PhotonPreset.Vr[34] = (PhotonPreset.R1[34] - PhotonPreset.R0[34])/ (PhotonPreset.dT)
--============================================================= 
-- 42 = coude from 2ndary to coude mirror, 43 from coude to fp
  PhotonPreset.Z0[42] = 0.007
  PhotonPreset.Z1[42] = 0.0
  PhotonPreset.Vz[42] = (PhotonPreset.Z1[42] - PhotonPreset.Z0[42])/ (PhotonPreset.dT)
  PhotonPreset.R0[42] = 0.00035
  PhotonPreset.R1[42] = 0.0002
  PhotonPreset.Vr[42] = (PhotonPreset.R1[42] - PhotonPreset.R0[42])/ (PhotonPreset.dT) 
-- relative to yoke
  PhotonPreset.Z0[43] = 0.0
  PhotonPreset.Z1[43] = -0.0165
  PhotonPreset.Vz[43] = (PhotonPreset.Z1[43] - PhotonPreset.Z0[43])/ (PhotonPreset.dT)
  PhotonPreset.R0[43] = 0.0002
  PhotonPreset.R1[43] = 0.00000
  PhotonPreset.Vr[43] = (PhotonPreset.R1[43] - PhotonPreset.R0[43])/ (PhotonPreset.dT)
 
-- 52 = coude from 2ndary to coude mirror: use 42 instead (see below)
-- 53 = coude from coude to bridge, 54 from bridge to yoke, 55 yoke to fp
-- relative to yoke
  PhotonPreset.Y0[53] = 0.0
  PhotonPreset.Y1[53] = 0.0035
  PhotonPreset.Vy[53] = (PhotonPreset.Y1[53] - PhotonPreset.Y0[53])/ (PhotonPreset.dT)
  PhotonPreset.Z0[53] = 0.0
  PhotonPreset.Z1[53] = -0.0067
  PhotonPreset.Vz[53] = (PhotonPreset.Z1[53] - PhotonPreset.Z0[53])/ (PhotonPreset.dT)
  PhotonPreset.R0[53] = 0.0002
  PhotonPreset.R1[53] = 0.00013
  PhotonPreset.Vr[53] = (PhotonPreset.R1[53] - PhotonPreset.R0[53])/ (PhotonPreset.dT)
 
-- 54 = bridge to yoke
  PhotonPreset.Y0[54] = 0.0035
  PhotonPreset.Y1[54] = 0.0
  PhotonPreset.Vy[54] = (PhotonPreset.Y1[54] - PhotonPreset.Y0[54])/ (PhotonPreset.dT)
  PhotonPreset.Z0[54] =  -0.0067
  PhotonPreset.Z1[54] =  -0.008
  PhotonPreset.Vz[54] = (PhotonPreset.Z1[54] - PhotonPreset.Z0[54])/ (PhotonPreset.dT)
  PhotonPreset.R0[54] = 0.00013
  PhotonPreset.R1[54] = 0.00007
  PhotonPreset.Vr[54] = (PhotonPreset.R1[54] - PhotonPreset.R0[54])/ (PhotonPreset.dT)
 
-- 55 = yoke to fp
  PhotonPreset.Y1[55] = 0.0
  PhotonPreset.Y1[55] = 0.0
  PhotonPreset.Vy[55] = 0.0

  PhotonPreset.Z0[55] = -0.008
  PhotonPreset.Z1[55] = -0.013
  PhotonPreset.Vz[55] = (PhotonPreset.Z1[55] - PhotonPreset.Z0[55])/ (PhotonPreset.dT)
  PhotonPreset.R0[55] = 0.00007
  PhotonPreset.R1[55] = 0.00000
  PhotonPreset.Vr[55] = (PhotonPreset.R1[55] - PhotonPreset.R0[55])/ (PhotonPreset.dT)


-- radius of photon beam 
PhotonPath.R = function ( N, mydate)
	-- return r = r0 + v*t
	return PhotonPath.R0[N] + PhotonPath.Vr[N]*(mydate-PhotonPath.T0)
end

-- set parameters of photon group i to show it in path j
-- this function only works if defined *after* all the presets are done???

SetPhoton = function (i,j)
  PhotonPath.X0[i] = PhotonPreset.X0[j]
  PhotonPath.X1[i] = PhotonPreset.X1[j]
  PhotonPath.Y0[i] = PhotonPreset.Y0[j]
  PhotonPath.Y1[i] = PhotonPreset.Y1[j]
  PhotonPath.Z0[i] = PhotonPreset.Z0[j]
  PhotonPath.Z1[i] = PhotonPreset.Z1[j]
  PhotonPath.Vx[i] = PhotonPreset.Vx[j]
  PhotonPath.Vy [i] = PhotonPreset.Vy[j]
  PhotonPath.Vz [i] = PhotonPreset.Vz[j]

  PhotonPath.R0[i] = PhotonPreset.R0[j]
  PhotonPath.R1[i] = PhotonPreset.R1[j]
  PhotonPath.Vr[i] = PhotonPreset.Vr[j]

end

-- place them all far away when not visible
HidePhotons = function (mydate)
	for i = 0,6 do
	  PhotonPath.X0[i] = 1e18
	  PhotonPath.Y0[i] = 1e18
	  PhotonPath.Z0[i] = 1e18
	end
        PhotonPath.T0 = 1e18
        PhotonPath.T1 = -1e18

end

--  0 = incoming to primary, 1 = primary to prime focus, 
-- 21 = cass from primary to 2ndary, 22 = cass from 2ndary to fp
-- 32 = cass from 2ndary to coude, 33 = cass from coude to trunion
--      34 = cass from trunion to fp
-- 42 = coude from 2ndary to coude mirror, 43 from coude to fp
-- 53 = coude from coude to bridge, 54 from bridge to yoke, 55 yoke to fp

--  0 = incoming to primary, 1 = primary to prime focus, 
 FlyPhoton1 = function (mydate)
	HidePhotons ()
	SetPhoton (0, 0)
	SetPhoton (1, 1)
        PhotonPath.T0 = mydate
        PhotonPath.T1 = mydate + PhotonPath.dT
  end

--  0 = incoming to primary,
-- 21 = cass from primary to 2ndary, 22 = cass from 2ndary to fp
 FlyPhoton2 = function (mydate)
	HidePhotons ()
	SetPhoton (0,0)
	SetPhoton (1,21)
	SetPhoton (2,22)
        PhotonPath.T0 = mydate
        PhotonPath.T1 = mydate + PhotonPath.dT
      end

--  0 = incoming to primary,
-- 21 = cass from primary to 2ndary
-- 32 = cass from 2ndary to coude, 33 = cass from coude to trunion
-- 34 = cass from trunion to fp
 FlyPhoton3 = function (mydate)
	HidePhotons ()
        PhotonPath.T0 = mydate
        PhotonPath.T1 = mydate + PhotonPath.dT
	SetPhoton (0,0)
	SetPhoton (1,21)
	SetPhoton (2,32)
	SetPhoton (3,33)
-- 4-6 relative to yoke
	SetPhoton (4,34)
  end
 
-- standard straight coude
--  0 = incoming to primary,
-- 21 = cass from primary to 2ndary
-- 42 = coude from 2ndary to coude mirror, 43 from coude to fp
 FlyPhoton4 = function (mydate)
	HidePhotons ()
        PhotonPath.T0 = mydate
        PhotonPath.T1 = mydate + PhotonPath.dT
	SetPhoton (0,0)
	SetPhoton (1,21)
	SetPhoton (2,42)
-- 4-6 relative to yoke
	SetPhoton (4,43)
end

-- bent coude using bridge mirror
--  0 = incoming to primary,
-- 21 = cass from primary to 2ndary
-- 42 = coude from 2ndary to coude mirror
-- 53 = coude from coude to bridge, 54 from bridge to yoke, 55 yoke to fp
 FlyPhoton5 = function (mydate)
	HidePhotons ()
        PhotonPath.T0 = mydate
        PhotonPath.T1 = mydate + PhotonPath.dT
	SetPhoton (0,0)
	SetPhoton (1,21)
	SetPhoton (2,42)
-- 4-6 relative to yoke
	SetPhoton (4,53)
	SetPhoton (5,54)
	SetPhoton (6,55)
end


--===================================
-- functions to hide/reveal models
--===================================

-- the plinth supporting the yoke

plinthX = 0
loresplinthX = 1e18

HidePlinth = function (mydate)
	loresplinthX = 1e18
	plinthX = 1e18
end
RevealPlinth = function (mydate)
	loresplinthX = 1e18
	plinthX = 0
end
RevealLoresPlinth = function (mydate)
	loresplinthX = 0
	plinthX = 1e18
end

-- the yoke supporting the telescope

yokeX = 0
loresyokeX = 1e18
HideYoke = function (mydate)
	yokeX = 1e18
	loresyokeX = 1e18
end
RevealYoke = function (mydate)
	yokeX = 0
	loresyokeX = 1e18
end

RevealLoresYoke = function (mydate)
	yokeX = 1e18
	loresyokeX = 0
end

-- the prime focus cage

PFCX = 0
loresPFCX = 1e18

HidePFC = function (mydate)
	PFCX = 1e18
	loresPFCX = 1e18
end
RevealPFC = function (mydate)
	PFCX = 0
	loresPFCX = 1e18
end

RevealLoresPFC = function (mydate)
	PFCX = 1e18
	loresPFCX = 0
end

-- the cassegrain focus cage

CFCX = 0
loresCFCX = 1e18

HideCFC = function (mydate)
	CFCX = 1e18
	loresCFCX = 1e18
end
RevealCFC = function (mydate)
	CFCX = 0
	loresCFCX = 1e18
end

-- the telescope itself

telescopeX = 0
lorestelescopeX = 1e18

HideTelescope = function (mydate)
	telescopeX = 1e18
	lorestelescopeX = 1e18
end
RevealTelescope = function (mydate)
	telescopeX = 0
	lorestelescopeX = 1e18
end

RevealLoresTelescope = function (mydate)
	telescopeX = 1e18
	lorestelescopeX = 0
	PFCX = 1e18
	loresPFCX = 0
end


-- hiding the laser target, track and prime focus emitter
laserTargetX = 0
HideTarget = function (mydate)
	laserTargetX = 1e18
end
RevealTarget = function (mydate)
	laserTargetX = 0
end


-- hiding the laser beam
laserBeamX = 1e18
HideBeam = function (mydate)
	laserBeamX = 1e18
end
RevealBeam = function (mydate)
	laserBeamX = 0
end


-- hiding mirrors

coudeYokeMirrorX=1e18
HideCoudeYokeMirror = function (mydate)
	coudeYokeMirrorX = 1e18
end
RevealCoudeYokeMirror = function (mydate)
	coudeYokeMirrorX = 0
end

-- exchange the central coude flat models
coudeMirror0X=0
coudeMirror90X=1e18
CoudeFlatDownX=1e18

HideCoudeMirror0 = function (mydate)
	coudeMirrorDecX=1e18
end

RevealCoudeMirror0 = function (mydate)
	coudeMirror0X = 0
	coudeMirror90X = 1e18
	CoudeFlatDownX=1e18

end

HideCoudeMirror90 = function (mydate)
	coudeMirror90X = 1e18
end

RevealCoudeMirror90 = function (mydate)
	coudeMirror90X = 0
	coudeMirror0X = 1e18
	CoudeFlatDownX=1e18
end

HideCoudeFlatDown = function (mydate)
	CoudeFlatDownX=1e18
end
RevealCoudeFlatDown = function (mydate)
	CoudeFlatDownX=0
	coudeMirror0X = 1e18
	coudeMirror90X = 1e18
end


--========================
-- pieces of light paths

inX = 1e18
primeX = 1e18
cassX = 1e18
cassCoudeX = 1e18
coudeTelX = 1e18
bridgeCoudeX = 1e18
coudeX = 1e18

HideLight = function (mydate)
        inX = 1e18
	primeX = 1e18
	cassX = 1e18
	cassCoudeX = 1e18
	coudeX = 1e18
	coudeTelX = 1e18
	bridgeCoudeX = 1e18
end

RevealLight1 = function (mydate)
	HideLight(mydate)
	primeX = 0
	inX = 0
end

-- this is the cassegrain light path, not the cassegrain mirror
RevealLight2 = function (mydate)
	HideLight(mydate)
	cassX = 0
	inX = 0
end

-- pieces of coude light paths
RevealLight3 = function (mydate)
	HideLight(mydate)
	coudeTelX = 0
	cassCoudeX = 0
	inX = 0
end
RevealLight4 = function (mydate)
	HideLight(mydate)
	coudeTelX = 0
	coudeX = 0
	inX = 0
end
RevealLight5 = function (mydate)
	HideLight(mydate)
	coudeTelX = 0
	bridgeCoudeX = 0
	inX = 0
end


--==============================================
-- functions to set cass 2ndary raise/lower parameters
cassUp = {}
cassUp.RotY =   yPi
cassUp.T0 = 1e18
cassUp.T1 = 0
cassUp.TPrev = 0

cassUp.Up   = math.rad( 0.0)
cassUp.Down = math.rad(90.0)

-- default position is up out of the way
cassUp.Th0 = cassUp.Up
cassUp.Th1 = cassUp.Down
cassUp.ThNow = cassUp.Up
cassUp.V = 0

LowerCassUp = function (mydate)
	cassUp.Th0 = cassUp.ThNow
	cassUp.Th1 = cassUp.Down 
        cassUp.V = (cassUp.Down - cassUp.Up)/ dT
	cassUp.T0 = mydate
	local sf = math.abs((cassUp.Down-cassUp.ThNow)/(cassUp.Down-cassUp.Up))
	cassUp.T1 = mydate+dT*sf
	cassUp.TPrev = mydate
end

RaiseCassUp = function (mydate)
	cassUp.Th0 = cassUp.ThNow
	cassUp.Th1 = cassUp.Up
        cassUp.V = (cassUp.Up - cassUp.Down)/ dT
	cassUp.T0 = mydate
	local sf = math.abs((cassUp.Up-cassUp.ThNow)/(cassUp.Down-cassUp.Up))
	cassUp.T1 = mydate+dT*sf
	cassUp.TPrev = mydate
end

StopCassUp = function (mydate)
	cassUp.Th0 = cassUp.ThNow
	cassUp.Th1 = cassUp.ThNow
        cassUp.V = 0
	cassUp.T0 = mydate
	cassUp.T1 = mydate
	cassUp.TPrev = mydate
end

--==============================================
-- functions to set coude 2ndary raise/lower parameters (3 mirror config)

coudeUp = {}
coudeUp.RotY =   yPi2
coudeUp.T0 = 1e18
coudeUp.T1 = 0
coudeUp.TPrev = 0

coudeUp.Up   = math.rad( 0.0)
coudeUp.Down = math.rad(90.0)

-- default position is up out of the way
coudeUp.Th0 = coudeUp.Up
coudeUp.Th1 = coudeUp.Down
coudeUp.ThNow = coudeUp.Up
coudeUp.V = 0

LowerCoudeUp = function (mydate)
	coudeUp.Th0 = coudeUp.ThNow
	coudeUp.Th1 = coudeUp.Down 
        coudeUp.V = (coudeUp.Down - coudeUp.Up)/ dT
	coudeUp.T0 = mydate
	local sf = math.abs((coudeUp.Down-coudeUp.ThNow)/(coudeUp.Down-coudeUp.Up))
	coudeUp.T1 = mydate+dT*sf
	coudeUp.TPrev = mydate
end

RaiseCoudeUp = function (mydate)
	coudeUp.Th0 = coudeUp.ThNow
	coudeUp.Th1 = coudeUp.Up
        coudeUp.V = (coudeUp.Up - coudeUp.Down)/ dT
	coudeUp.T0 = mydate
	local sf = math.abs((coudeUp.Up-coudeUp.ThNow)/(coudeUp.Down-coudeUp.Up))
	coudeUp.T1 = mydate+dT*sf
	coudeUp.TPrev = mydate
end

StopCoudeUp = function (mydate)
	coudeUp.Th0 = coudeUp.ThNow
	coudeUp.Th1 = coudeUp.ThNow
        coudeUp.V = 0
	coudeUp.T0 = mydate
	coudeUp.T1 = mydate
	coudeUp.TPrev = mydate
end
--==============================================
-- functions to set coude2 2ndary raise/lower parameters (5 mirror config)

coude2Up = {}
coude2Up.RotY =   yR0
coude2Up.T0 = 1e18
coude2Up.T1 = 0
coude2Up.TPrev = 0

coude2Up.Up   = math.rad( 0.0)
coude2Up.Down = -math.rad(90.0)

-- default position is up out of the way
coude2Up.Th0 = coude2Up.Up
coude2Up.Th1 = coude2Up.Down
coude2Up.ThNow = coude2Up.Up
coude2Up.V = 0

LowerCoude2Up = function (mydate)
	coude2Up.Th0 = coude2Up.ThNow
	coude2Up.Th1 = coude2Up.Down 
        coude2Up.V = (coude2Up.Down - coude2Up.Up)/ dT
	coude2Up.T0 = mydate
	local sf = math.abs((coude2Up.Down-coude2Up.ThNow)/(coude2Up.Down-coude2Up.Up))
	coude2Up.T1 = mydate+dT*sf
	coude2Up.TPrev = mydate
end

RaiseCoude2Up = function (mydate)
	coude2Up.Th0 = coude2Up.ThNow
	coude2Up.Th1 = coude2Up.Up
        coude2Up.V = (coude2Up.Up - coude2Up.Down)/ dT
	coude2Up.T0 = mydate
	local sf = math.abs((coude2Up.Up-coude2Up.ThNow)/(coude2Up.Down-coude2Up.Up))
	coude2Up.T1 = mydate+dT*sf
	coude2Up.TPrev = mydate
end

StopCoude2Up = function (mydate)
	coude2Up.Th0 = coude2Up.ThNow
	coude2Up.Th1 = coude2Up.ThNow
        coude2Up.V = 0
	coude2Up.T0 = mydate
	coude2Up.T1 = mydate
	coude2Up.TPrev = mydate
end
--==============================================
-- functions to set crane raise/lower parameters

crane = {}
crane.T0 = 1e18
crane.T1 = 0

crane.Down = math.rad(90.0)
crane.Up   = math.rad( 0.0)

-- default position is up out of the way
crane.Th0 = crane.Up
crane.Th1 = crane.Down
crane.ThNow = crane.Up
crane.V = 0

LowerCrane = function (mydate)
	crane.Th0 = crane.ThNow
	crane.Th1 = crane.Down 
        crane.V = (crane.Down - crane.Up)/ dT
	crane.T0 = mydate
	local sf = math.abs((crane.Down-crane.ThNow)/(crane.Down-crane.Up))
	crane.T1 = mydate+dT*sf
	crane.TPrev = mydate
end

RaiseCrane = function (mydate)
	crane.Th0 = crane.ThNow
	crane.Th1 = crane.Up
        crane.V = (crane.Up - crane.Down)/ dT
	crane.T0 = mydate
	local sf = math.abs((crane.Up-crane.ThNow)/(crane.Down-crane.Up))
	crane.T1 = mydate+dT*sf
	crane.TPrev = mydate
end

StopCrane = function (mydate)
	crane.Th0 = crane.ThNow
	crane.Th1 = crane.ThNow
        crane.V = 0
	crane.T0 = mydate
	crane.T1 = mydate
	crane.TPrev = mydate
end

--==============================================
-- functions to set coude mirror raise-lower rotation parameters

mirror = {}
mirror.T0 = 1e18
mirror.T1 = 0

mirror.Down = math.rad(90.0)
mirror.Up   = math.rad( 0.0)

-- default position is up out of the way
mirror.Th1 = mirror.Down
mirror.Th0 = mirror.Up
mirror.V = 0

LowerMirror = function (mydate)
	LowerCrane(mydate)
coudeMirror0X=0
coudeMirror90X=1e18
CoudeFlatDownX = 1e18
	mirror.Th0 = mirror.Up
	mirror.Th1 = mirror.Down 
        mirror.V = (mirror.Th1 - mirror.Th0)/ dT
	mirror.T0 = mydate
	mirror.T1 = mydate+dT
end

RaiseMirror = function (mydate)
	RaiseCrane(mydate)
coudeMirror0X=0
coudeMirror90X=1e18
CoudeFlatDownX = 1e18
	mirror.Th0 = mirror.Down
	mirror.Th1 = mirror.Up
        mirror.V = (mirror.Th1 - mirror.Th0)/ dT
	mirror.T0 = mydate
	mirror.T1 = mydate+dT
end

-- functions to set elevator in/out rotation parameters

Elevator = {}
Elevator.T0 = 1e18
Elevator.T1 = 0

Elevator.Extended    = math.rad(-90.0)
Elevator.Retracted   = math.rad(0)--( 26.0)

Elevator.Th0 = Elevator.Retracted
Elevator.Th1 = Elevator.Extended
Elevator.V = 0

ExtElev = function (mydate)
	Elevator.Th0 = Elevator.Retracted
	Elevator.Th1 = Elevator.Extended 
        Elevator.V = (Elevator.Th1 - Elevator.Th0)/ dT
	Elevator.T0 = mydate
	Elevator.T1 = mydate+dT
end

RetrElev = function (mydate)
	Elevator.Th0 = Elevator.Extended
	Elevator.Th1 = Elevator.Retracted
        Elevator.V = (Elevator.Th1 - Elevator.Th0)/ dT
	Elevator.T0 = mydate
	Elevator.T1 = mydate+dT
end


