-- coude flat declination rotation functionality
-- when in auto, angle = 0.5*decl

CFDAngle = 0
CFDRot45 = yPi * celestia:newrotation( xAxis, 0.0) 

CFDRotX = function(date)

-- s = "CoudeFlatState: "..CoudeFlatState..", ctrl= "..ControlCoudeFlatState..", CFDAngle: "..CFDAngle
-- celestia:flash(s)


 	local Angle; 

-- 0 = 45 degree angle; decl = 0

-- 45 points straight out (beyond lower limit
-- when decl = 90

-- -45 points straight up (beyond upper limit)
-- when decl = -90

	  Angle = math.rad(-90)
	if (CoudeFlatState == "off")
	then
	  Angle =  CFDAngle
	elseif (CoudeFlatState == "auto")
	then
	  Angle =  math.rad(prevDecl/2.0)
	elseif (CoudeFlatState == "45")
	then
	  Angle = 0
	elseif (CoudeFlatState == "manual")
	then
	 if (ControlCoudeFlatState == "control")
	 then
	  Angle  = math.rad(TableOfSpinPos["Knob_SpinLeft"]/10.0)
	 else
	  Angle = CFDAngle
	 end
	end
--s = CoudeFlatState..": "..ControlCoudeFlatState
	
	CFDAngle = Angle
	CFDRot = yPi * celestia:newrotation( xAxis, Angle) 
 	return  CFDRot
end

-- ==========================================================
-- CoudeFlatRotate -- rotate coude mirror

CoudeFlatRotateProto = { } -- no args

-- constructor method

function CoudeFlatRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

 	o.period = 1

	return o
end

-- orientation function

function CoudeFlatRotateProto:orientation(tjd)

	local qNow = CFDRotX(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CoudeFlatRotate(sscvals)

	return CoudeFlatRotateProto:new(sscvals)

end
