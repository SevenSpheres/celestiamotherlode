-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
--==================================================================
-- ThreePoleLamp functions: demo version
-- functions for actual switches will test related hardware states
--==================================================================

ThreePoleLampStateTop05 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up, center, down
-- determined by state of associated radio button set
-- up on light visible if clamp closed

	if ( (CoudeClamp.Opened=="false") and (State == "on"))
	then return 0
	elseif ( (CoudeClamp.Opened=="true") and (State == "on"))
	then return 1e18

-- up off light visible if clamp open
	elseif ( (CoudeClamp.Opened=="true") and (State == "off"))
	then return 0
	elseif ( (CoudeClamp.Opened=="false") and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop05 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop05(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot05 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- down on light visible if clamp open

	if ( (CoudeClamp.Opened=="true") and (State == "on"))
	then return 0
	elseif ( (CoudeClamp.Opened=="false") and (State == "on"))
	then return 1e18

-- down off light visible if clamp closed
	elseif ( (CoudeClamp.Opened=="false") and (State == "off"))
	then return 0
	elseif ( (CoudeClamp.Opened=="true") and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot05 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot05(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end
