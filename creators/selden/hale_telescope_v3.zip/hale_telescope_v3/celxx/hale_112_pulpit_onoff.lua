-- functions to turn pulpit on and off
-- update

Pulpit = {}
Pulpit.OnOff = "Missing"

HidePulpitOnOff = function (state)
	Pulpit.OnOff = "Missing"
end

RevealPulpitOnOff = function (state)
-- pulpit controls require mirror cover to be closed!
	if (cover.ThNow > math.rad (83)) then Pulpit.OnOff = "Locked" end
end

-- ==========================================================

 cmds.Hale_PulpitOn = RevealPulpitOnOff
 cmds.HPON = RevealPulpitOnOff
 cmds.Hale_PulpitOff = HidePulpitOnOff
 cmds.HPOFF = HidePulpitOnOff

-- ==========================================================

PulpitOnOffX = function(state)
	if (state == "Locked" and Pulpit.OnOff == "Locked")
         then return 0
	elseif (state == "Open" and Pulpit.OnOff == "Open")
	 then return 0
	else return 1e18
	end
end

-- hide/reveal telescope control pulpit

DisplayPulpitOnOff = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return PulpitOnOffX(self.params.State), 0, 0
	end

return orbit
end
