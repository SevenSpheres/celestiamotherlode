-- functions to set Bridge raise/lower parameters

Bridge = {}
Bridge.T0 = 1e18
Bridge.T1 = 0

Bridge.Down = math.rad(90.0)-math.rad(180)
Bridge.P0 = Bridge.Down

Bridge.Up = math.rad(-20) -math.rad(180)
Bridge.P1 = Bridge.Up

Bridge.Th1 = Bridge.Up
Bridge.Th0 = Bridge.Down

Bridge.TPrev = 1e18
Bridge.PosPrev = Bridge.Down

Bridge.V = 0


RaiseBridge = function (mydate)
	MoveToP1(Bridge,mydate)
end

LowerBridge = function (mydate)
	MoveToP0(Bridge,mydate)
end

StopBridge = function (mydate)
	MoveStop(Bridge,mydate)
end
-- ==========================================================

 cmds.Hale_Lower_Bridge = LowerBridge
 cmds.HLBR              = LowerBridge
 cmds.Hale_Stop_Bridge  = StopBridge
 cmds.HSBR              = StopBridge
 cmds.Hale_Raise_Bridge = RaiseBridge
 cmds.HRBR              = RaiseBridge

-- ==========================================================

-- Bridge up/down

BridgeRot = function ( date )

 	local Angle = Bridge.PosPrev
     	if ((date > Bridge.T0) and (date <= Bridge.T1))
      	  then	Angle = Bridge.PosPrev + Bridge.V*(date-Bridge.TPrev)
      	end
	Bridge.TPrev = date
	Bridge.PosPrev = Angle

 	return  zPi * celestia:newrotation( xAxis, Angle)
end

-- ==========================================================
-- BridgeRotate -- rotate mirror Bridge

BridgeRotateProto = { } -- no args

-- constructor method

function BridgeRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function BridgeRotateProto:orientation(tjd)

	local qNow = BridgeRot( tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function BridgeRotate(sscvals)

	return BridgeRotateProto:new(sscvals)

end

