-- control coude flat when down
-- only one at a time: auto, manual, fixed 45

-- states determined by pulpit switch

CoudeFlatPulpit = "off"

CoudeFlatPulpitOff = function()
	CoudeFlatPulpit = "off"
	CoudeFlatState = "off"
end
CoudeFlatPulpit45 = function()
	CoudeFlatPulpit = "45"
	CoudeFlatState = "45"
end
CoudeFlatPulpitDesk = function()
	CoudeFlatPulpit = "desk"
	CoudeFlatState = "auto"
end


-- states determined by desk switch

CoudeFlatState = "off"

CoudeFlatAuto = function()
	if (CoudeFlatPulpit == "desk")
	then CoudeFlatState = "auto"
	else CoudeFlatState = CoudeFlatPulpit
	end
end
CoudeFlat45 = function()
	if (CoudeFlatPulpit == "desk")
	then CoudeFlatState = "45"
	else CoudeFlatState = CoudeFlatPulpit
	end
end
CoudeFlatManual = function()
	if (CoudeFlatPulpit == "desk")
	then CoudeFlatState = "manual"
	else CoudeFlatState = CoudeFlatPulpit
	end
end


-- left spinner knob button #1 states

ControlCoudeFlatState = "ignore"

ControlCoudeFlat = function()
	ControlCoudeFlatState = "control"
end
IgnoreCoudeFlat = function()
	ControlCoudeFlatState = "ignore"
end
