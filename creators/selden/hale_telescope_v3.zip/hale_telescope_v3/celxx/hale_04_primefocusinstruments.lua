-- Prime Focus Instruments

-- Large Format camera
-- Laser Launch Telescope
-- Observer

-- the camera itself
DisplayLFC = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return LFCX, 0, 0
	end

return orbit
end

-- its Field of View
DisplayLFCFoV = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return LFCFoVX, 0, 0
	end

return orbit
end

-- hale laser launch telescope in pf cage
DisplayLaunchTel = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return LaunchTelX, 0, 0
	end

return orbit
end

--======================================
-- an observer at the prime focus
--======================================
DisplayPrimeObs = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return primeObsX, 0, 0
	end

return orbit
end
