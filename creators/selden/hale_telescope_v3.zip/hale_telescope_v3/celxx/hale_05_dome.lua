--============================================================
-- dome: domeX used for doors, too.

domeX = 0

HideDome = function (mydate)
	domeX = 1e18
end
RevealDome = function (mydate)
	domeX = 0
end

baseX = 0
HideBase = function (mydate)
	baseX = 1e18
end
RevealBase = function (mydate)
	baseX = 0
end

domeInternalX = 1e18

HideDomeInternal = function (mydate)
	domeInternalX = 1e18

-- things to hide with interior:
-- freight elevator cage
-- freight elevator doors
-- storage room doors

	local obj

obj = celestia:find("Sol/Earth/200in/hale_freight_elevator")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_storage_room_door_1_model")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_storage_room_door_2_model")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_storage_room_door_3_model")
obj:setvisible(false)

obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_left_1")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_left_2")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_right_1")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_right_2")
obj:setvisible(false)

obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_left_1")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_left_2")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_right_1")
obj:setvisible(false)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_right_2")
obj:setvisible(false)

end


RevealDomeInternal = function (mydate)
	domeInternalX = 0

-- things to hide with interior:
-- freight elevator cage
-- storage room doors
	local obj
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_storage_room_door_1_model")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_storage_room_door_2_model")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_storage_room_door_3_model")
obj:setvisible(true)

obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_left_1")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_left_2")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_right_1")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_upper_door_right_2")
obj:setvisible(true)

obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_left_1")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_left_2")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_right_1")
obj:setvisible(true)
obj = celestia:find("Sol/Earth/200in/hale_freight_elevator_lower_door_right_2")
obj:setvisible(true)


end
--============================================================

 cmds.Hale_Hide_Base = HideBase
 cmds.HHB                 = HideBase
 cmds.Hale_Reveal_Base = RevealBase
 cmds.HRB                 = RevealBase

 cmds.Hale_Hide_Dome = HideDome
 cmds.HHD                 = HideDome
 cmds.Hale_Reveal_Dome = RevealDome
 cmds.HRD                 = RevealDome

 cmds.Hale_Hide_Dome_Internal = HideDomeInternal
 cmds.HHDI                 = HideDomeInternal
 cmds.Hale_Reveal_Dome_Internal = RevealDomeInternal
 cmds.HRDI                 = RevealDomeInternal


--============================================================

-- display the rotatable dome
--============================================================

DisplayDome = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return domeX, 0, 0
	end

return orbit
end

--============================================================
-- display the rotatable internal structure
--============================================================

DisplayDomeInternal = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return domeInternalX, 0, 0
	end

return orbit
end

--============================================================
-- display the bare floor when not showing the interior
--============================================================

DisplayDomeInternalFloor = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		if (domeInternalX == 0)
		 then
		   return 1e13, 0, 0
		 else
		   return 0, 0, 0
		end
	end

return orbit
end


--============================================================
-- display the nonrotatable base
--============================================================

DisplayBase = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return baseX, 0, 0
	end

return orbit
end

--============================================================
-- display other innards (ideally, these shouldn't be here)
--============================================================
require ("hale_05_ocrane")
require ("hale_05_hook")
