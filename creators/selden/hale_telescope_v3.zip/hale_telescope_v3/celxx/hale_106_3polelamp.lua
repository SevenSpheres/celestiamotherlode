-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
--==================================================================
-- ThreePoleLamp functions: demo version
-- functions for actual switches will test related hardware states
--==================================================================

nearby = function(x1, x2)
	local delta = math.rad(0.5)
	if (math.abs(x1-x2) < delta) 
	 then return true
	 else return false
	end
end

ThreePoleLampStateTop06 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- up on light visible if pointed east
	if ( nearby(mirror90.ThNow,mirror90.East) and (State == "on"))
	then return 0
	elseif ( not nearby(mirror90.ThNow,mirror90.East) and (State == "on"))
	then return 1e18

-- up off light visible if not pointed east
	elseif ( not nearby(mirror90.ThNow,mirror90.East) and (State == "off"))
	then return 0
	elseif ( nearby(mirror90.ThNow,mirror90.East) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop06 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop06(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot06 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- down on light visible if pointed south
	if ( nearby(mirror90.ThNow,mirror90.South) and (State == "on"))
	then return 0
	elseif ( not nearby(mirror90.ThNow,mirror90.South) and (State == "on"))
	then return 1e18

-- down off light visible if not pointed south
	elseif ( not nearby(mirror90.ThNow,mirror90.South) and (State == "off"))
	then return 0
	elseif ( nearby(mirror90.ThNow,mirror90.South) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot06 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot06(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end
