-- Coude Flat down

IsCoudeFlatDown = function (date)

-- display CoudeFlatDown model
-- if crane clamps are open
-- ignore state of rotation toward east trunion for now
	if (CoudeClamp.Opened == "true")
	  then 
	   CoudeFlatDownX = 0
	   coudeMirror0X = 1e18
	  else
	   CoudeFlatDownX = 1e18
	   coudeMirror0X = 0
	end
	return CoudeFlatDownX   
end

-- the flst
DisplayCoudeFlatDown = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)

		return IsCoudeFlatDown(tjd), 0, 0
	end

return orbit
end

-- Coude Flat down lamp

-- the illuminated lamp model is shown when the flat is down

DisplayCFDLamp = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals -- ignored for now
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
-- s = self.params.LampN.." and "..CoudeFlatDownX
-- celestia:flash(s)
	   if (self.params.LampN == "on")
	    then return CoudeFlatDownX, 0, 0
	    else
                if (CoudeFlatDownX > 1e17) 
		  then return 0, 0, 0
		  else return 1e18, 0 ,0
		end
	   end
	end

return orbit
end
