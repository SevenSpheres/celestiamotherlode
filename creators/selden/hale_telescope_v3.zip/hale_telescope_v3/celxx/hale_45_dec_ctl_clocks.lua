-- Declination manual control Clocks
--==================================================================
-- control values
-- manual angle -> current angle in hale_07_manual_track_ex.lua
-- Dec_Ctl_Angle = Manual_Dec_Angle
Dec_Ctl_T0 = nil

--==================================================================
-- positioning function used by Dec Degree positioning
-- min and sec just use a fraction of the degree position
--==================================================================

Dec_Ctl_Move = function(date)

-- velocity = table of spin speed [knob name] * button speed factor
-- theta = theta0 + velocity * time

  local v1 = TableOfSpinSpeed["Knob_SpinRight"]/100.*RADecMotion.MoveDecSpeed
  local v = RADecMotion.MoveDecSpeed
  local v2

  if (RADecMotion.HDSOUTH)
   then v2 = - v
  elseif (RADecMotion.HDNORTH) 
   then v2 = v
  else v2 = 0
  end

  local delta_time
  if (Dec_Ctl_T0) 
   then delta_time = date - Dec_Ctl_T0 
   else delta_time = 0 end

  local delta_angle = (v1+v2) * delta_time
  local Angle = Manual_Dec_Angle + delta_angle
  Dec_Ctl_T0 = date
  Manual_Dec_Angle = Angle

  return  yPi*celestia:newrotation( zAxis, Angle)
end

--==================================================================
-- Dec_Degrees functions
--==================================================================
-- hours function calculates positions
-- minutes and seconds just follow along
--==================================================================
Dec_Ctl_Degreesproto =
{
   Period    = 1,
}

-- constructor method
function Dec_Ctl_Degreesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Dec_Ctl_Degreesproto:orientation(tjd)

	local qNow = 	Dec_Ctl_Move(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Dec_Ctl_Degrees(sscvals)
   -- create a new Dec_Ctl_Degrees rotation object
   return Dec_Ctl_Degreesproto:new(sscvals)
end


--==================================================================
-- Dec_Minutes functions
--==================================================================
-- Degrees function calculates positions
-- minutes and seconds just follow along
--==================================================================
Dec_Minute_Rot = function ()
  return  yPi*celestia:newrotation( zAxis, Manual_Dec_Angle*360)
end

Dec_Ctl_Minutesproto =
{
   Period    = 1,
}

-- constructor method
function Dec_Ctl_Minutesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Dec_Ctl_Minutesproto:orientation(tjd)

	local qNow = 	Dec_Minute_Rot()
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Dec_Ctl_Minutes(sscvals)
   -- create a new Dec_Ctl_Minutes rotation object
   return Dec_Ctl_Minutesproto:new(sscvals)
end


--==================================================================
-- Dec_Seconds functions
--==================================================================
-- hours function calculates positions
-- minutes and seconds just follow along
--==================================================================
Dec_Second_Rot = function ()
  return  yPi*celestia:newrotation( zAxis, Manual_Dec_Angle*21600.0)
end

Dec_Ctl_Secondsproto =
{
   Period    = 1,
}

-- constructor method
function Dec_Ctl_Secondsproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Dec_Ctl_Secondsproto:orientation(tjd)

	local qNow = 	Dec_Second_Rot()
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Dec_Ctl_Seconds(sscvals)
   -- create a new Dec_Ctl_Seconds rotation object
   return Dec_Ctl_Secondsproto:new(sscvals)
end
