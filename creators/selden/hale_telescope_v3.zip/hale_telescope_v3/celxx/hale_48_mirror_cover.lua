-- functions to set cover open/close parameters

cover = {}
cover.T0 = 1e18
cover.T1 = 0

cover.ThOpen = math.rad( 0.0) -- open
cover.ThClosed = math.rad(84.0) -- closed = default

cover.P0 = cover.ThClosed
cover.P1 = cover.ThOpen

cover.Pos0 = cover.ThClosed
cover.Pos1 = cover.ThOpen

cover.TPrev = 1e18
cover.PosPrev = cover.ThClosed

cover.V = 0

-- -------------------------------
OpenCover = function (mydate)
	MoveToP1(cover,mydate)
end

CloseCover = function (mydate)
	MoveToP0(cover,mydate)
end

StopCover = function (mydate)
	MoveStop(cover,mydate)
end

--======================================================
-- command table entries for mirror cover control
--======================================================

 cmds.Hale_Open_Cover  = OpenCover
 cmds.HOC              = OpenCover
 cmds.Hale_Close_Cover = CloseCover
 cmds.HCC              = CloseCover
 cmds.Hale_Stop_Cover  = StopCover
 cmds.HSC              = StopCover

--======================================================
-- rotation functions for mirror cover
--======================================================
coverAnglePrev = {}
coverQPrev = {}

coverRot = function ( date, numPanel )

  	local Angle
	if (date < cover.T0)
	  then Angle = cover.Pos0
     	elseif (date < cover.T1)
      	  then	Angle = cover.PosPrev + cover.V*(date-cover.TPrev)
	else Angle = cover.Pos1
 	end

	cover.TPrev = date
	cover.PosPrev = Angle

	if (Angle == coverAnglePrev[numPanel])
	then return coverQPrev[numPanel] end

	coverAnglePrev[numPanel] = Angle

-- orient around Y axis according to position around mirror
	q_rotateY = celestia:newrotation( yAxis, numPanel * math.pi/8.0 )

-- current opening angle
	local q_rotate_now = celestia:newrotation( xAxis, Angle)

-- combine opening angle with orientation around mirror
	q_rotate = q_rotate_now  *q_rotateY
	coverQPrev[numPanel] = q_rotate
 	return q_rotate
end

-- ==========================================================
-- CoverRotate -- rotate mirror cover

CoverRotateProto = {
	Panel = 0,
}

-- constructor method

function CoverRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function CoverRotateProto:orientation(tjd)

	local qNow = coverRot( tjd, self.Panel )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CoverRotate(sscvals)

	return CoverRotateProto:new(sscvals)

end
