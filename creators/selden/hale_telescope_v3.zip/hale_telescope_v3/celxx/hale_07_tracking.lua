-- hale_07_tracking.lua
-- hale telescope target tracking routines

-- the xyz to RA,Dec routines were taken from Lua Edu's celutil.lua
-- Thanks, Vincent!

--- all other code � Selden Ball, October, 2007. All rights reserved. 

-- useful constants:
pkg = {
	LOOK  = celestia:newvector(0,0,-1);
	XAxis = celestia:newvector(1,0,0);
	YAxis = celestia:newvector(0,1,0);
	ZAxis = celestia:newvector(0,0,1);
	Second = 1.0/(24.0*60*60)
}

-- Transform coordinates from cartesian to polar 
pkg.transform_xyz2rtp = function (x,y,z)
  local r = math.sqrt(x*x + y*y + z*z)
  local theta = math.atan(math.sqrt(x*x + y*y)/z)
  local phi   = math.atan2(y,x)
  return r,theta,phi
end


-- Return current Ra, Dec for selection
pkg.get_ra_dec = function (vp, sel)

  local base_rot = celestia:newrotation(celestia:newvector(1,0,0), -math.rad(23.4392911))
  local rot = vp:getposition():orientationto(sel:getposition(), pkg.LOOK) * base_rot

  local look = rot:transform(pkg.LOOK):normalize()
  local r,theta,phi = pkg.transform_xyz2rtp(look.x, look.z, look.y)
  local phi = math.mod(720 - math.deg(phi), 360)
  local theta = math.deg(theta)
  if theta > 0 then
    theta = 90 - theta
  else
    theta = (-90 - theta)
  end
  return phi, theta
end

pkg.isHale = function (sel)
	local selName = string.lower(sel:name())
	local pointHale = string.match(selName,"hale")
	local pointCtl = string.match(selName,"ctl_")
	local isMe = (pointHale ~= nil) or (pointCtl ~= nil)
	 if (isMe) then return true end

	local tel =  celestia:find("Sol/Earth/Hale_Position")
	local tel_pos = tel:getposition()
	local sel_pos = sel:getposition()
	local dist = sel_pos:distanceto(tel_pos)

	if (dist < 0.5) then return true 
	else return false
	end

end

--======================================
-- yoke's current RA

prevRA  = nil
prevRAt = nil
prevRArot = nil

desiredRA = nil

-- RA set by control desk 

RA_Ctl_Angle = 0


getRAq = function (vp,date)

-- commands are handled by their own object
-- but this helps telescope movement be smoother
	hale_cmd()

-- set initial pointing values immediately
	if (prevRA == nil)
	then  
	   sel = celestia:find("Sol/Earth/stow_telescope")
	   local prevDecl
	   prevRA,prevDecl  = pkg.get_ra_dec (vp,sel)
	   prevRAt = date
	   desiredRA = prevRA

	   local rad_ra = math.rad(prevRA)
	   RA_Ctl_Angle = rad_ra

	   local q_rotate1 = celestia:newrotation(pkg.YAxis,-rad_ra)	
	   local q_rotate2 = celestia:newrotation(pkg.YAxis, math.rad(-90))
	   local q_rotate = q_rotate1 * q_rotate2
	   prevRArot = q_rotate
	   return q_rotate.w, q_rotate.x, q_rotate.y, q_rotate.z
	end

	local sel = celestia:getselection()

-- most of the time will be spent pointing at the same thing
-- so don't need to recalculate it

	if (sel == selP and desiredRA == prevRA)
	then
	   prevRAt = date
	   return prevRArot.w, prevRArot.x, prevRArot.y, prevRArot.z
	end

-- must not call getposition (in get_ra_dec)
--  if selecting movable part of self
-- this causes an infinite loop
-- instead return previous orientation

-- temp hack for reverse time
	if ( date < prevRAt)
	then
	   prevRAt = date
	   desiredRA = prevRA
	   return prevRArot.w, prevRArot.x, prevRArot.y, prevRArot.z
	end

-- set bounds on math
	if     (prevRA < 0.0)   then prevRA = 360.0 + prevRA
	elseif (prevRA > 360.0) then prevRA = prevRA - 360.0 end

-- determine target
--	local destinationRA0,dec = pkg.get_ra_dec (vp,sel)
	local destinationRA0 = 0

	if (TrackingState == "Select")
	 then 
--  track the object which has been selected by Celestia

	   if (pkg.isHale(sel))
--  but not if it's part of the telescope
	   then
	      prevRAt = date
	      desiredRA = prevRA
	      return prevRArot.w, prevRArot.x, prevRArot.y, prevRArot.z
	   end

	   destinationRA0,dec = pkg.get_ra_dec (vp,sel)

	elseif (TrackingState == "Manual")
--  track the RA,Dec which has been selected by manual controls on desk

	 then destinationRA0 = math.deg(RA_Ctl_Angle)

	else 
-- (TrackingState == "Off"): point to RA changing with time

-- telescope's orientation is specified in equatorial coordinates
-- which change as Earth rotates in RA, so need to keep updating it 
-- when telescope "doesn't move"

	   destinationRA0 = SidTrk.RAOff + (TrackOffPos()-SidTrk.SidOff)
	end


--	local v = 18.0/second
	local v = RADecMotion.MoveRATSpeed
	local stepAngle = v * (date-prevRAt)

-- find closest dest: avoid rotating > 180 degrees
	if (destinationRA0 - prevRA > 180) 
	then destinationRA0 = destinationRA0 - 360
	elseif (prevRA - destinationRA0 > 180) 
	then destinationRA0 = destinationRA0 + 360 
	end


-- take baby steps toward target
	if (math.abs(destinationRA0 - prevRA) > stepAngle) then 
	  local thisStep = stepAngle
	  if (destinationRA0 < prevRA) then thisStep = - stepAngle end
	  destinationRA = prevRA +thisStep
	else destinationRA = destinationRA0
	end


-- 	s = "prevRA = "..prevRA..", stepAngle = "..stepAngle..", destinationRA0 = "..destinationRA0..", destinationRA = "..destinationRA
-- 	celestia:flash(s,1)


-- all was being done in degrees. Celestia wants radians
	local rad_ra = math.rad(destinationRA)

	local q_rotate1 = celestia:newrotation(pkg.YAxis,-rad_ra)	
	local q_rotate2 = celestia:newrotation(pkg.YAxis, math.rad(-90))
	local q_rotate = q_rotate1 * q_rotate2

-- keep track of where we are now: 
-- most of the time will be spent pointing at the same thing
-- so don't need to recalculate it

	prevRA = math.fmod(destinationRA,360)
	prevRAt = date
	prevRArot = q_rotate

-- set manual destination to current destination 
-- so telescope doesn't move immediately when switching to Manual mode

	if (TrackingState ~= "Manual") then RA_Ctl_Angle = rad_ra end

	return q_rotate.w, q_rotate.x, q_rotate.y, q_rotate.z

end

-- motion functions per Celestia's documentation

YokeRAproto =
 { 
	Viewpoint = "Sol/Earth/hale_yoke",
	Period = 1,
 }

-- constructor method

function YokeRAproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

--   o.period = o.Period

   return o
end


-- The orientation function. 

function YokeRAproto:orientation(tjd)

	local myVP = celestia:find(self.Viewpoint)

   -- return a quaternion representing the current orientation
	return getRAq(myVP,tjd)
end

function YokeRA(sscvals)
   -- create a new rotation object
   return YokeRAproto:new(sscvals)
end

--================================================
-- telescope tube's declination angle

prevDecl  = nil
prevDeclT = nil
prevDeclrot = nil

-- manual control declination
-- Dec_Ctl_Angle = nil -- inited in 07_hale_manual_track_ex.lua

desiredDecl = nil

getDeclq = function (vp, date)


-- if no initial values yet, set to default target immediately
	if (prevDecl == nil)
	  then
	   local sel = celestia:find("Sol/Earth/stow_telescope")
	   local ra,dec = pkg.get_ra_dec (vp,sel)
	   prevDecl  = dec
	   desiredDecl = dec
	   prevDeclT = date
	   local rad_dest = math.rad(dec)
	   Dec_Ctl_Angle = rad_dest

	   local q_rotate2 = celestia:newrotation(pkg.YAxis, math.pi)
	   local q_rotate1 = celestia:newrotation(pkg.XAxis,rad_dest)
	   local q_rotate = q_rotate1  * q_rotate2
	   prevDeclrot = q_rotate
	   return q_rotate.w, q_rotate.x, q_rotate.y, q_rotate.z
	end

	if (TrackingState == "Off")
	then
-- Earth doesn't rotate in Dec, so don't need to change it
	   prevDeclT = date
	   desiredDecl = prevDecl
	   Dec_Ctl_Angle = math.rad(prevDecl)
	   return prevDeclrot.w, prevDeclrot.x, prevDeclrot.y, prevDeclrot.z
	end

-- determine current selection
	local sel = celestia:getselection()

-- most of the time will be spent pointing at the same thing
-- so don't need to recalculate it

	if (sel == selP and desiredDecl == prevDecl)
	then
	   prevDeclT = date
	   return prevDeclrot.w, prevDeclrot.x, prevDeclrot.y, prevDeclrot.z
	end

-- temp hack for reversed time
	if ( date < prevDeclT) 
	then
	   prevDeclT = date
	   desiredDecl = prevDecl
	   return prevDeclrot.w, prevDeclrot.x, prevDeclrot.y, prevDeclrot.z
	end


-- determine dec of current target

	if (TrackingState == "Select")
	 then 

	   if (pkg.isHale(sel))
	   then
-- must not call getposition (in get_ra_dec)
--  if selecting movable part of self
-- because this causes an infinite loop
-- instead return previous orientation

	      prevDeclT = date
	      desiredDecl = prevDecl
	      return prevDeclrot.w, prevDeclrot.x, prevDeclrot.y, prevDeclrot.z
	   end

		ra,destination = pkg.get_ra_dec (vp,sel)

	elseif (TrackingState == "Manual")
	 then
		destination = math.deg(Dec_Ctl_Angle)
	else 
--              stop here now (but this test has already been done)
	   prevDeclT = date
	   desiredDecl = prevDecl
	   return prevDeclrot.w, prevDeclrot.x, prevDeclrot.y, prevDeclrot.z
	end

	desiredDecl = destination

	local v = RADecMotion.MoveDecTSpeed
	local stepAngle = v * (date-prevDeclT)

	if (math.abs(destination - prevDecl ) > stepAngle) then 
-- 	  only go partway: 
	  local thisStep = stepAngle
	  if (destination  < prevDecl ) then thisStep = - stepAngle end
	  destination  = prevDecl  +thisStep
	end

-- keep angle in range
	if (destination < -90.0)   
	  then destination = math.abs(destination+90.0) - 90.0
	elseif (destination > 90.0)
	  then destination = 90.0 - (destination-90.0) 
	end


--	s = "prev = "..prevDecl..", dest = "..destination.." = "..dec
--	celestia:flash(s,1)

	local rad_dest = math.rad(destination)

	local q_rotate2 = celestia:newrotation(pkg.YAxis, math.pi)
	local q_rotate1 = celestia:newrotation(pkg.XAxis,rad_dest)
	local q_rotate = q_rotate1  * q_rotate2

-- most of the time will be spent pointing at the same thing
-- so remember new orientation so it doesn't have to be recalculated

	prevDecl = destination
	prevDeclT = date
	prevDeclrot = q_rotate

-- set manual decl to current decl so telescope doesn't move
-- when switching to Manual mode
	if (TrackingState ~= "Manual")
	 then
	    Dec_Ctl_Angle = rad_dest
	 end

	return q_rotate.w, q_rotate.x, q_rotate.y, q_rotate.z
end

TelescopeDeclproto =
 { 
	Viewpoint = "Sol/Earth/Hale_position",
	Period = 1,
 }

-- constructor method

function TelescopeDeclproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

--   o.period = o.Period

   return o
end


-- The orientation function. 

function TelescopeDeclproto:orientation(tjd)

	local myVP = celestia:find(self.Viewpoint)

   -- return a quaternion representing the orientation
	return getDeclq(myVP,tjd)
end

function TelescopeDecl(sscvals)
   -- create a new rotation object
	return TelescopeDeclproto:new(sscvals)
end
