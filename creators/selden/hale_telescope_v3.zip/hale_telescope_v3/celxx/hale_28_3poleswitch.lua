-- controls appearance of 3 pole switches

--==================================================================
--==================================================================
-- ThreePoleSwitch functions
--==================================================================

ThreePoleSwitchState = function(ThreePSw,Up,Center,Down,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

	local theta

	if ( TableOfValues[Up] == "on")
	then theta = -45

	elseif ( TableOfValues[Center] == "on" )
	then theta = 0

	else -- down must be on
	theta = 45
	end

	return  yPi*celestia:newrotation( xAxis, math.rad(theta))

end


--==================================================================
ThreePoleSwitchproto =
{
   Period    = 1,
}

-- constructor method
function ThreePoleSwitchproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function ThreePoleSwitchproto:orientation(tjd)


	local qNow = 	ThreePoleSwitchState(
			self.ButtonRadio,
			self.ButtonUp,
			self.ButtonCenter,
			self.ButtonDown,
			tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function ThreePoleSwitch(sscvals)
   -- create a new ThreePoleSwitch rotation object
   return ThreePoleSwitchproto:new(sscvals)
end
--==================================================================
--==================================================================
-- ThreePoleRSwitch functions
--==================================================================

ThreePoleRSwitchState = function(ThreePSw,Up,Center,Down,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

	local theta

	if ( TableOfValues[Up] == "on")
	then theta = -45

	elseif ( TableOfValues[Center] == "on" )
	then theta = 0

	else -- down must be on
	theta = 45
	end

	return  yPi*celestia:newrotation( yAxis, math.rad(theta))

end


--==================================================================
ThreePoleRSwitchproto =
{
   Period    = 1,
}

-- constructor method
function ThreePoleRSwitchproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function ThreePoleRSwitchproto:orientation(tjd)

	local qNow = 	ThreePoleRSwitchState(
			self.ButtonRadio,
			self.ButtonUp,
			self.ButtonCenter,
			self.ButtonDown,
			tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function ThreePoleRSwitch(sscvals)
   -- create a new ThreePoleRSwitch rotation object
   return ThreePoleRSwitchproto:new(sscvals)
end
