--======================================================
-- rotation functions
--======================================================
-----------------------------------------------------------------
-- object (coude or cass) rotation about x axis

ObjRotXY = function (obj, date )

	local Angle; 
	if     (date < obj.T0) 
	  then  Angle = obj.Th0
     	elseif (date < obj.T1)
      	  then	Angle = obj.Th0 + obj.V*(date-obj.T0)
	else    Angle = obj.Th1
      	end

	obj.ThNow = Angle
	obj.TPrev = date

	return obj.RotY * celestia:newrotation( xAxis, Angle)
end

-----------------------------------------------------------------
-- object (coude or cass) rotation about y axis

ObjRotYZ = function (obj, date )

	local Angle; 
	if     (date < obj.T0) 
	  then  Angle = obj.Th0
     	elseif (date < obj.T1)
      	  then	Angle = obj.Th0 + obj.V*(date-obj.T0)
	else    Angle = obj.Th1
      	end

	obj.ThNow = Angle
	obj.TPrev = date

	return obj.RotY * celestia:newrotation( zAxis, Angle)
end

-----------------------------------------------------------------
-- object (coude mirror90, elevator) rotation about Y axis

ObjRotY = function (obj, date )

	local Angle; 
	if     (date < obj.T0) 
	  then  Angle = obj.Th0
     	elseif (date < obj.T1)
      	  then	Angle = obj.Th0 + obj.V*(date-obj.T0)
	else    Angle = obj.Th1
      	end

	obj.ThNow = Angle
	obj.TPrev = date

	return yPi * celestia:newrotation( yAxis, Angle)
end

-----------------------------------------------------------------
-- object (crane, mirror or elevator) rotation about X axis

ObjRotX = function (obj, date )

	local Angle; 
	if     (date < obj.T0) 
	  then  Angle = obj.Th0
     	elseif (date < obj.T1)
      	  then	Angle = obj.Th0 + obj.V*(date-obj.T0)
	else    Angle = obj.Th1
      	end

	obj.ThNow = Angle
	obj.TPrev = date

	return yPi * celestia:newrotation( xAxis, Angle)
end


-- ==========================================================
-- cassUpRotate -- rotate mirror cassUp -- cassegrain secondary mirror

cassUpRotateProto = { } -- no args

-- constructor method

function cassUpRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function cassUpRotateProto:orientation(tjd)

	local qNow = ObjRotXY( cassUp, tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CassUpRotate(sscvals)

	return cassUpRotateProto:new(sscvals)

end



-- ==========================================================
-- coudeUpRotate -- rotate mirror coudeUp -- coude secondary

coudeUpRotateProto = { } -- no args

-- constructor method

function coudeUpRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function coudeUpRotateProto:orientation(tjd)

	local qNow = ObjRotYZ( coudeUp, tjd )

	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CoudeUpRotate(sscvals)

	return coudeUpRotateProto:new(sscvals)

end



-- ==========================================================
-- coude2UpRotate -- rotate mirror coud2eUp -- 2nd coude secondary

coude2UpRotateProto = { } -- no args

-- constructor method

function coude2UpRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function coude2UpRotateProto:orientation(tjd)

	local qNow = ObjRotXY( coude2Up, tjd )

	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function Coude2UpRotate(sscvals)

	return coude2UpRotateProto:new(sscvals)

end



-- ==========================================================
-- craneRotate -- rotate mirror crane

craneRotateProto = { } -- no args

-- constructor method

function craneRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

	o.period = 1

	return o
end

-- orientation function

function craneRotateProto:orientation(tjd)

	local qNow = ObjRotX( crane, tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function CraneRotate(sscvals)

	return craneRotateProto:new(sscvals)

end


-- ==========================================================
-- mirrorRotate -- rotate coude mirror flat up and down from stowed posn.

mirrorRotateProto = { } -- no args

-- constructor method

function mirrorRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

 	o.period = 1

	return o
end

-- orientation function

function mirrorRotateProto:orientation(tjd)

	local qNow = ObjRotX( mirror, tjd )
-- 
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function MirrorRotate(sscvals)

	return mirrorRotateProto:new(sscvals)

end

-- ==========================================================
-- ElevatorRotate -- rotate Elevator
-- (not how it works: the elevator has a fixed orientation)
-- ( this routine is no longer used)

ElevatorRotateProto = { } -- no args

-- constructor method

function ElevatorRotateProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

 	o.period = 1

	return o
end

-- orientation function

function ElevatorRotateProto:orientation(tjd)

	local qNow = ObjRotY( Elevator, tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function ElevatorRotate(sscvals)

	return ElevatorRotateProto:new(sscvals)

end


-- ==========================================================
-- ElevatorRaiseLower -- Raise/lower Elevator

ElevatorRaiseLowerProto = { } -- no args

-- constructor method

function ElevatorRaiseLowerProto:new(o)
	o = o or {}
	setmetatable (o, self)
	self.__index = self

 	o.period = 1

	return o
end

-- orientation function

function ElevatorRaiseLowerProto:orientation(tjd)

	local qNow = ObjRotX( ElevatorUpDown, tjd )
	return qNow.w, qNow.x, qNow.y, qNow.z

end

-- create new rotation object

function ElevatorRaiseLower(sscvals)

	return ElevatorRaiseLowerProto:new(sscvals)

end

require("hale_03_cfd")
