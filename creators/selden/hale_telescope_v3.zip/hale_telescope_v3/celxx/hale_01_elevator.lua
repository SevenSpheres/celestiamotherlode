-- functions to set elevator up/down rotation parameters

ElevatorUpDown = {}

ElevatorUpDown.Override = false

ElevatorUpDown.T0 = 1e18
ElevatorUpDown.T1 = 0

ElevatorUpDown.Up     = math.rad( -79)
ElevatorUpDown.Down   = math.rad( -4.7)

ElevatorUpDown.Th0 =   ElevatorUpDown.Down
ElevatorUpDown.Th1 =   ElevatorUpDown.Up
ElevatorUpDown.ThNow = ElevatorUpDown.Down

ElevatorUpDown.V = 0

DoUpElev = function (mydate)
	ElevatorUpDown.Th0 = ElevatorUpDown.ThNow
	ElevatorUpDown.Th1 = ElevatorUpDown.Up
        ElevatorUpDown.V = (ElevatorUpDown.Up - ElevatorUpDown.Down)/ (2*dT)
	ElevatorUpDown.T0 = mydate
	local sf = math.abs((ElevatorUpDown.Up-ElevatorUpDown.ThNow)/(ElevatorUpDown.Up-ElevatorUpDown.Down))
	ElevatorUpDown.T1 = mydate+2*dT*sf
end

DoDownElev = function (mydate)
	ElevatorUpDown.Th0 = ElevatorUpDown.ThNow
	ElevatorUpDown.Th1 = ElevatorUpDown.Down
        ElevatorUpDown.V = (ElevatorUpDown.Down - ElevatorUpDown.Up)/ (2*dT)
	ElevatorUpDown.T0 = mydate
	local sf = math.abs((ElevatorUpDown.ThNow-ElevatorUpDown.Down)/(ElevatorUpDown.Up-ElevatorUpDown.Down))
	ElevatorUpDown.T1 = mydate+2*dT*sf

end

DoStopElev = function (mydate)
	ElevatorUpDown.Th1 = ElevatorUpDown.ThNow
	ElevatorUpDown.Th0 = ElevatorUpDown.ThNow
	ElevatorUpDown.T0 = 1e18
	ElevatorUpDown.T1 = mydate
        ElevatorUpDown.V = mydate
end

UpElev = function (mydate)


	if ( not ElevatorUpDown.Override ) then DoUpElev(mydate) end
end

StopElev = function (mydate)
	if ( not ElevatorUpDown.Override ) then DoStopElev(mydate) end
end

DownElev = function (mydate)
	if ( not ElevatorUpDown.Override ) then DoDownElev(mydate) end
end

--------------------------------------------------------------
-- master control desk pfe override
--------------------------------------------------------------

MCDPFEOverride = function (mydate)
	ElevatorUpDown.Override = true
	local obj = celestia:find("Sol/Earth/200in/Lamp_371_on")
	obj:setvisible(true)
	obj = celestia:find("Sol/Earth/200in/Lamp_371_off")
	obj:setvisible(false)
end

MCDPFEOverrideMid = function (mydate)
	ElevatorUpDown.Override = false
	local obj = celestia:find("Sol/Earth/200in/Lamp_371_on")
	obj:setvisible(false)
	obj = celestia:find("Sol/Earth/200in/Lamp_371_off")
	obj:setvisible(true)
end

MCDPFEOverrideDefeat = function (mydate)
	ElevatorUpDown.Override = false
	local obj = celestia:find("Sol/Earth/200in/Lamp_371_on")
	obj:setvisible(false)
	obj = celestia:find("Sol/Earth/200in/Lamp_371_off")
	obj:setvisible(true)
end

--------------------------------------------------------------
-- master control desk pfe control
--------------------------------------------------------------

MCDPFEUp = function (mydate)
if (not ElevatorUpDown.Override) then s = "false" else s = "true" end
celestia:flash(s)
	if (ElevatorUpDown.Override) then DoUpElev(mydate) end
end

MCDPFEStop = function (mydate)
	if (ElevatorUpDown.Override) then DoStopElev(mydate) end
end

MCDPFEDown = function (mydate)
	if (ElevatorUpDown.Override) then DoDownElev(mydate) end
end
