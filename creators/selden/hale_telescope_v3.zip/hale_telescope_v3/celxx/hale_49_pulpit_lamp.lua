-- Pulpit Lamp on/off


PulpitLampOn = function (mydate)
local obj = celestia:find("Sol/Earth/200in/hale_pulpit_lamp_lit")
 obj:setvisible(true)
      obj = celestia:find("Sol/Earth/200in/hale_pulpit_lamp_dark")
 obj:setvisible(false)

if (Pulpit.OnOff == "Locked") then Pulpit.OnOff = "Open" end

end

PulpitLampOff = function (mydate)
local obj = celestia:find("Sol/Earth/200in/hale_pulpit_lamp_lit")
 obj:setvisible(false)
      obj = celestia:find("Sol/Earth/200in/hale_pulpit_lamp_dark")
 obj:setvisible(true)

 if (Pulpit.OnOff == "Open")  then Pulpit.OnOff = "Locked"  end

end

--==================================================================
-- now that the functions are defined, one can
-- specify the commands which invoke those functions 
--==================================================================

cmds.Hale_Pulpit_Lamp_Lit = PulpitLampOn
cmds.HPLL                 = PulpitLampOn
cmds.Hale_Pulpit_Lamp_Off = PulpitLampOff
cmds.HPLO                 = PulpitLampOff

