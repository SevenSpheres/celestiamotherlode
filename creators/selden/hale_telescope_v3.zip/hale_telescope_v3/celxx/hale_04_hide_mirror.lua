-- hide/reveal primary mirror and its cell

-- define hide/reveal functions

Reveal_Primary_Mirror = function (mydate)
 local obj = celestia:find("Sol/Earth/hale_telescope/hale_primary_mirror")
 obj:setvisible(true)
end
Hide_Primary_Mirror = function (mydate)
 local obj = celestia:find("Sol/Earth/hale_telescope/hale_primary_mirror")
 obj:setvisible(false)
end


Reveal_Primary_Mirror_Cell = function (mydate)
 local obj = celestia:find("Sol/Earth/hale_telescope/hale_mirror_cell")
 obj:setvisible(true)
end
Hide_Primary_Mirror_Cell = function (mydate)
 local obj = celestia:find("Sol/Earth/hale_telescope/hale_mirror_cell")
 obj:setvisible(false)
end

-- add command interpreter table entries

cmds.Hale_Reveal_Primary_Mirror = Reveal_Primary_Mirror
cmds.Hale_Hide_Primary_Mirror = Hide_Primary_Mirror
cmds.Hale_Reveal_Primary_Mirror_Cell = Reveal_Primary_Mirror_Cell
cmds.Hale_Hide_Primary_Mirror_Cell = Hide_Primary_Mirror_Cell

cmds.HRPM = Reveal_Primary_Mirror
cmds.HHPM = Hide_Primary_Mirror
cmds.HRPMC = Reveal_Primary_Mirror_Cell
cmds.HHPMC = Hide_Primary_Mirror_Cell
