--Clocks
--==================================================================
--Dec Clock
--==================================================================
-- Dec_Degrees functions
--==================================================================
Dec_DegreesState = function(BName)

	local Angle = math.rad(prevDecl)
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
Dec_Degreesproto =
{
   Period    = 1,
}

-- constructor method
function Dec_Degreesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Dec_Degreesproto:orientation(tjd)

	local qNow = 	Dec_DegreesState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Dec_Degrees(sscvals)
   -- create a new Dec_Degrees rotation object
   return Dec_Degreesproto:new(sscvals)
end
--==================================================================
-- Dec_Minutes functions
--==================================================================
Dec_MinutesState = function(BName)

	local posAngle = math.abs(prevDecl)
	local int,frac = math.modf(posAngle)
	local Angle = (frac*2*math.pi) *6
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
Dec_Minutesproto =
{
   Period    = 1,
}

-- constructor method
function Dec_Minutesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Dec_Minutesproto:orientation(tjd)

	local qNow = 	Dec_MinutesState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Dec_Minutes(sscvals)
   -- create a new Dec_Minutes rotation object
   return Dec_Minutesproto:new(sscvals)
end
--==================================================================
-- Dec_Seconds functions
--==================================================================
Dec_SecondsState = function(BName)

	local posAngle = math.abs(prevDecl)
	local int,frac = math.modf(posAngle)
	local Angle = (frac*120*math.pi) *6
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
Dec_Secondsproto =
{
   Period    = 1,
}

-- constructor method
function Dec_Secondsproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function Dec_Secondsproto:orientation(tjd)

	local qNow = 	Dec_SecondsState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function Dec_Seconds(sscvals)
   -- create a new Dec_Seconds rotation object
   return Dec_Secondsproto:new(sscvals)
end
