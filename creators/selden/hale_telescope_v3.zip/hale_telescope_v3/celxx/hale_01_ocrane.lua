-- hale_01_ocrane.lua
-- A Lua Module to help control the model of the Hale Telescope
-- � Selden Ball, December, 2007. All rights reserved. 
--
-- ==========================================================
-- the variables here are all globals: preserved between screen refreshes

-- functions to set overhead crane parameters

OCrane = {}
OCrane.T0 = 1e18
OCrane.T1 = 0
OCrane.V = 0

OCrane.Back = -0.008
OCrane.Fwd   = 0.00147
OCrane.X1 = OCrane.Back
OCrane.X0 = OCrane.Back
OCrane.Xprv = OCrane.Back

FwdOCrane = function (mydate)
	OCrane.X0 = OCrane.Xprv
	OCrane.X1 = OCrane.Fwd
        OCrane.V = (OCrane.Fwd - OCrane.Back)/ dT
	OCrane.T0 = mydate
	OCrane.T1 = mydate+(dT *math.abs((OCrane.Fwd-OCrane.Xprv)/(OCrane.Fwd-OCrane.Back)))
--	OCrane.T1 = mydate+(dT)
end

BackOCrane = function (mydate)
	OCrane.X0 = OCrane.Xprv
	OCrane.X1 = OCrane.Back
        OCrane.V = (OCrane.Back - OCrane.Fwd)/ dT
	OCrane.T0 = mydate
	OCrane.T1 = mydate+(dT *math.abs((OCrane.Xprv-OCrane.Back)/(OCrane.Fwd-OCrane.Back)))
--	OCrane.T1 = mydate+(dT)
end

StopOCrane = function (mydate)
	OCrane.X0 = OCrane.Xprv
	OCrane.X1 = OCrane.Xprv
        OCrane.V = 0
	OCrane.T0 = mydate
	OCrane.T1 = mydate
end
