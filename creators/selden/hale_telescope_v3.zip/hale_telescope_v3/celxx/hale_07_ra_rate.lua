--======================================================
-- display velocity in RA on RA RATE meter
--======================================================

--======================================================
-- adjust scale of RA RATE meter values
--======================================================


RARateMeter = {
	HRA300 = false,
	HRAAUTO = true,
	HRA3000 = false,
	RAPrev = 0,
	RANow = 0,
	TPrev = 0,
	TNow = 0,
	PosNow = 0,
}

RARate_300 = function ()
	RARateMeter.HRA300 = true
	RARateMeter.HRAAUTO = false
	RARateMeter.HRA3000 = false
end

RARate_Auto = function ()
	RARateMeter.HRA300 = false
	RARateMeter.HRAAUTO = true
	RARateMeter.HRA3000 = false
end

RARate_3000 = function ()
	RARateMeter.HRA300 = false
	RARateMeter.HRAAUTO = false
	RARateMeter.HRA3000 = true
end

---------------------------

cmds.Hale_RARate_300 = RARate_300
cmds.HRA300 =  RARate_300
cmds.Hale_RARate_Auto =  RARate_Auto
cmds.HRAAUTO =  RARate_Auto
cmds.Hale_RARate_3000 =  RARate_3000
cmds.HRA3000 =  RARate_3000

-----------------------------
-- RA Rate Meter Needle rotation
-----------------------------
RA_Rate_Meter_Move = function(mydate)

-- 50 = -50
-- 35 = ~0
-- -50 = 300 or 3000
-- i.e. 100 degrees = 350 (3500) sec/hr

-- measured in degrees
	local deltaRA = prevRA - RARateMeter.RAPrev
	local deltaT = ( mydate - RARateMeter.TPrev)
	local r = (10/35)*(deltaRA/deltaT)
	local mr = r
	if (RARateMeter.HRA300) then  mr = r*10 end
	if (RARateMeter.HRAAUTO and (r < 100) and (r > -55)) 
         then  mr = r*10 end
--[[
s = "r = "..r..", mr ="..mr
celestia:flash(s)

s1 = "dra=ra-pra: "..deltaRA.." = "..prevRA.." - "..RARateMeter.RAPrev
s2 = "dt=t-t0: "..deltaT.." = "..mydate.." - "..RARateMeter.TPrev
s3 = "mr = s*dra/dt: "..mr.." = "..(10/35).."*"..deltaRA.."/"..deltaT
celestia:flash(s1.."\n"..s2.."\n"..s3)
--]]

	local Angle = -(math.rad(mr)-math.rad(35))

	RARateMeter.RAPrev = prevRA
	RARateMeter.TPrev = mydate

     return  yPi*celestia:newrotation( zAxis, Angle)

end
-----------------------------

RA_Rate_Meterproto =
{
   Period    = 1,
}

-- constructor method
function RA_Rate_Meterproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function RA_Rate_Meterproto:orientation(tjd)

	local qNow = 	RA_Rate_Meter_Move(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function RA_Rate_Meter(sscvals)
   -- create a new RA_Rate_Meter rotation object
   return RA_Rate_Meterproto:new(sscvals)
end
