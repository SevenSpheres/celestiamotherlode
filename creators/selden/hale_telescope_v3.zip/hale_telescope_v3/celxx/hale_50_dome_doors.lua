-- ---------------------------------------
-- Motion control for dome doors
-- ---------------------------------------

-- table of motion parameters

DomeDoors = {}
InitMoveTable(DomeDoors,0,0.0046)

-- ---------------------------------------
-- movement initialization functions

OpenDomeDoors = function()
	MoveToP1(DomeDoors,mydate)
end

CloseDomeDoors = function (mydate)
	MoveToP0(DomeDoors,mydate)
end

StopDomeDoors = function (mydate)
	MoveStop(DomeDoors,mydate)
end

-- ---------------------------------------
-- movement commands

 cmds.Hale_Open_Dome_Doors = OpenDomeDoors
 cmds.HODD                 = OpenDomeDoors
 cmds.Hale_Close_Dome_Doors = CloseDomeDoors
 cmds.HCDD                 = CloseDomeDoors
 cmds.Hale_Stop_Dome_Doors = StopDomeDoors
 cmds.HSDD                 = StopDomeDoors

-- ---------------------------------------
-- motion function

-- open /close doors

DoorX = function ( date )
	return MoveNow(DomeDoors,date), 0, 0
end

-- ---------------------------------------
-- motion methods

DisplayDoor1 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return (domeX+DoorX(tjd)), 0, 0
	end

return orbit
end

DisplayDoor2 = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return (domeX-DoorX(tjd)), 0, 0
	end

return orbit
end
