--==================================================================
--Pacific Standard Time Clock
--==================================================================
-- Pacific Standard Time_Hours functions
--==================================================================
PST_hour = function(date)
	local h = {} 
	h = celestia:tdbtoutc(date)
	local pst_time = (h.hour+h.minute/60.0+h.seconds/3600.0) -8.0
	return pst_time
end


PST_HoursState = function(date)

	local Angle = -(2.0*PST_hour(date)*(2*math.pi/24.0))
 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
PST_Hoursproto =
{
   Period    = 1,
}

-- constructor method
function PST_Hoursproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function PST_Hoursproto:orientation(tjd)

	local qNow = 	PST_HoursState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function PST_Hours(sscvals)
   -- create a new PST_Hours rotation object
   return PST_Hoursproto:new(sscvals)
end

--==================================================================
--==================================================================
-- Pacific Standard Time_Minutes functions
--==================================================================

PST_MinutesState = function(date)

	local Angle = -PST_hour(date)* 2.0*math.pi

 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
PST_Minutesproto =
{
   Period    = 1,
}

-- constructor method
function PST_Minutesproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function PST_Minutesproto:orientation(tjd)

	local qNow = 	PST_MinutesState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function PST_Minutes(sscvals)
   -- create a new PST_Minutes rotation object
   return PST_Minutesproto:new(sscvals)
end
--==================================================================
--==================================================================
-- Pacific Standard Time_Seconds functions
--==================================================================

PST_SecondsState = function(date)

	local Angle = -PST_hour(date)* 2.0*math.pi*60.0

 	return  yPi*celestia:newrotation( zAxis, Angle)
end


--==================================================================
PST_Secondsproto =
{
   Period    = 1,
}

-- constructor method
function PST_Secondsproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function PST_Secondsproto:orientation(tjd)

	local qNow = 	PST_SecondsState(tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function PST_Seconds(sscvals)
   -- create a new PST_Seconds rotation object
   return PST_Secondsproto:new(sscvals)
end
