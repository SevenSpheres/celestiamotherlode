-- hale_1.lua
-- A Lua Module to help control the model of the Hale Telescope
-- � Selden Ball, September, 2007. All rights reserved. 
--
-- functions to set Storage door parameters

  SDClosed = 0
  SDOpen   = 0.0041

SDT0 = {}
SDT1 = {}
  SDT0[1] = 1e18 
  SDT1[1] = 0 
  SDT0[2] = 1e18 
  SDT1[2] = 0 
  SDT0[3] = 1e18 
  SDT1[3] = 0 

SDX0 = {}
SDXNow = {}
SDX1 = {}

  SDX1[1] = SDClosed 
  SDXNow[1] = SDClosed 
  SDX0[1] = SDClosed 

  SDX1[2] = SDClosed 
  SDXNow[2] = SDClosed 
  SDX0[2] = SDClosed 

  SDX1[3] = SDClosed 
  SDXNow[3] = SDClosed 
  SDX0[3] = SDClosed 

SDV = {}
  SDV[1] = 0.0 
  SDV[2] = 0.0 
  SDV[3] = 0.0

OpenStorageDoor = function (NDoor,mydate)
	SDX0[NDoor] = SDXNow[NDoor]
	SDX1[NDoor] = SDOpen
        SDV[NDoor] = (SDOpen - SDClosed)/ dT
	local sf = math.abs((SDOpen-SDXNow[NDoor])/(SDOpen-SDClosed))
	SDT0[NDoor] = mydate
	SDT1[NDoor] = mydate+dT*sf
end

StopStorageDoor = function (NDoor,mydate)
	SDX0[NDoor] = SDXNow[NDoor]
	SDX1[NDoor] = SDXNow[NDoor]
	SDT0[NDoor] = 1e18
	SDT1[NDoor] = 0
        SDV[NDoor] = 0
end

CloseStorageDoor = function (NDoor,mydate)
	SDX0[NDoor] = SDXNow[NDoor]
	SDX1[NDoor] = SDClosed
        SDV[NDoor] = (SDClosed - SDOpen)/ dT
	SDT0[NDoor] = mydate
	local sf = math.abs((SDXNow[NDoor]-SDClosed)/(SDOpen-SDClosed))
	SDT1[NDoor] = mydate+dT*sf
end
------------------------------------------
OpenStorageDoor1 = function (mydate)
	OpenStorageDoor(1,mydate)
end

StopStorageDoor1 = function (mydate)
	StopStorageDoor(1,mydate)
end

CloseStorageDoor1 = function (mydate)
	CloseStorageDoor(1,mydate)
end
------------------------------------------
OpenStorageDoor2 = function (mydate)
	OpenStorageDoor(2,mydate)
end

StopStorageDoor2 = function (mydate)
	StopStorageDoor(2,mydate)
end

CloseStorageDoor2 = function (mydate)
	CloseStorageDoor(2,mydate)
end
------------------------------------------
OpenStorageDoor3 = function (mydate)
	OpenStorageDoor(3,mydate)
end

StopStorageDoor3 = function (mydate)
	StopStorageDoor(3,mydate)
end

CloseStorageDoor3 = function (mydate)
	CloseStorageDoor(3,mydate)
end
------------------------------------------
