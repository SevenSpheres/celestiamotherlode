-- hide/reveal telescope labels
DisplayLabels = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
		return LabelsX, 0, 0
	end

return orbit
end
