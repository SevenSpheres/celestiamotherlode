-- raise or lower windscreen: just controls its visibility for now

RaiseWindScreen = function (mydate)
 local obj = celestia:find("Sol/Earth/200in/hale_windscreen_model")
 obj:setvisible(true)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_up")
 obj:setvisible(true)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_down")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/hale_WindScreen_down")
 obj:setvisible(false)
end

LowerWindScreen = function (mydate)
 local obj = celestia:find("Sol/Earth/200in/hale_windscreen_model")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_up")
 obj:setvisible(false)
 local obj = celestia:find("Sol/Earth/200in/WindScreen_ctl_needle_down")
 obj:setvisible(true)
 local obj = celestia:find("Sol/Earth/200in/hale_WindScreen_down")
 obj:setvisible(true)
end
--==================================================================
-- now that the functions are defined, one can
-- specify the commands which invoke those functions 
--==================================================================

-- wind screen switch 63
cmds.HWSUP = RaiseWindScreen
cmds.Hale_WindScreen_Up  = RaiseWindScreen
cmds.HWSSTOP = LowerWindScreen
cmds.Hale_WindScreen_Stop = LowerWindScreen
cmds.HWSDOWN = LowerWindScreen
cmds.Hale_WindScreen_Down = LowerWindScreen
