Scripted Lua functions controlling the model of 
the 200" Hale Telescope on Palomar Mountain
v2.0

by Selden Ball � December, 2007.
All rights reserved.
============================

These lua functions control the movable pieces of the hale telescope Addon

Note that this code should not be used as a model for object-oriented programming practice.
I'm sure many of the functions could be rewritten as a single combined function with object prefixes,
but I'm an ex-Fortran programmer to whom such things do not come naturally.

  hale_control.lua 
The container module:
It pulls in other modules which do the work.
Lua treats the code as if the various modules' text were sequential
as listed in this module.
Additional modules were created later as separate files for ease of debugging.

   hale_01_cmd_routines 
the parameter setting routines 
which set times, bounds and velocities as defined for specific commands
and used by ScriptedOrbit and ScriptedRotation functions for the various models

   hale_02_cmd_processor 
compares the selected object with its table of objects which corresopnd to commands
and calls the appropriate parameter setting routine if the selected object is a command

   hale_03_rotations 
Celestia ScriptedRotation functions for most of the models
which cause them to move relative to the telescope

   hale_04_hide 
Celestia ScriptedOrbit functions to hide most of the models 
by placing them 1e18 units away (usually in X)

   hale_05_dome 
hide/reveal ScriptedOrbit functions for the dome top and bottom

   hale_06_photons_and_paths
hide/reveal ScriptedOrbit functions for the light paths and the "photons"

   hale_07_tracking
The ScriptedRotation routines which cause the Yoke and Telescope 
to track the selected object in Right Ascension & Declination respectively.

Thanks to Vincent for letting me use the RA & Dec routines from the LuaEdu package!
 
   hale_08_laser 
hide/reveal ScriptedOrbit functions for the components of the artificial star laser
(used by the adaptive optics when no bright star is near the object being observed.)

s. ball
December, 2007

