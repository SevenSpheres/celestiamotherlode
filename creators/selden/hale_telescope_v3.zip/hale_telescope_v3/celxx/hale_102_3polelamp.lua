-- controls appearance of pulpit 3 pole switch lamps

--==================================================================
--==================================================================
-- ThreePoleLamp functions: demo version
-- functions for actual switches will test related hardware states
--==================================================================

ThreePoleLampStateTop02 = function(ThreePSw,Up,Center,Down,State,date)

-- 3 positions: up, center, down
-- determined by state of associated radio button set


-- up on light visible if coude up

	if ((coudeUp.ThNow == coudeUp.Up) and (State == "on"))
	then return 0
	elseif ( (coudeUp.ThNow ~= coudeUp.Up) and (State == "on"))
	then return 1e18

-- up off light visible if coude not up
	elseif ( (coudeUp.ThNow ~= coudeUp.Up) and (State == "off"))
	then return 0
	elseif ( (coudeUp.ThNow == coudeUp.Up) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end


--==================================================================

ThreePoleLampTop02 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateTop02(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end

--==================================================================
--==================================================================
ThreePoleLampStateBot02 = function(ThreePSw,Up,Center,Down,State,date)
-- 3 positions: up, center, down
-- determined by state of associated radio button set

-- down on light visible if coude down
	if ((coudeUp.ThNow == coudeUp.Down) and (State == "on"))
	then return 0
	elseif ( (coudeUp.ThNow ~= coudeUp.Down) and (State == "on"))
	then return 1e18

-- down off light visible if coude not down
	elseif ( (coudeUp.ThNow ~= coudeUp.Down) and (State == "off"))
	then return 0
	elseif ( (coudeUp.ThNow == coudeUp.Down) and (State == "off"))
	then return 1e18
	end
-- can't get here ...riiiiight...
	return 0
end

--==================================================================

ThreePoleLampBot02 = function (sscvals)

	local orbit = {}
	orbit.params = sscvals
	orbit.boundingRadius = 1e0

	function orbit:position (tjd)
	local XNow = 	ThreePoleLampStateBot02(
			self.params.ButtonRadio,
			self.params.ButtonUp,
			self.params.ButtonCenter,
			self.params.ButtonDown,
			self.params.LampN,
			tjd)
		return XNow, 0, 0
	end

	return orbit
end
