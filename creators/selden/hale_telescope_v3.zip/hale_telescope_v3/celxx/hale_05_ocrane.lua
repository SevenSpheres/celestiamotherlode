
-- move overhead crane

OCraneX = function ( date )

-- default OCrane position is last x
	local OCranePos = OCrane.X1

     if (date >= OCrane.T0) and (date <= OCrane.T1)
      then
	OCranePos = OCrane.X0 + OCrane.V*(date-OCrane.T0)
	OCrane.Xprv = OCranePos
      end
 
-- current crane position
 	return OCranePos
end


MoveOCrane = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0, OCraneX(tjd), 0
	end

return orbit
end
