-- hale_08_laser.lua
-- moves laser trolley
-- up and down the telescope
-- as its declination changes


HaleDiam    = 0.0024
TrackLength = 0.0048
TrackMax = TrackLength - 0.0018
prevTargetPos = nil

laserTargetZ = function ( date )

-- Target moves with Telescope. Don't give a dam about the date

-- z position = diam of telescope * tan (decl) (see laser_target_pos.bmp)
-- oops but lessened by RA

	local TargetPos = 0

	if (prevDecl == nil or prevRA == nil) then return 0 end
	if ((prevRA == desiredRA) and (prevDecl == desiredDecl))
	then return prevTargetPos end

-- avoid tan going infinite
	if     (prevDecl <(0.0-89)) then TargetPos =  TrackLength
	elseif (prevDecl > 89) then TargetPos = (0.0 -TrackLength)
	else 
		local rd = math.rad(prevDecl)
		local ra = math.rad(prevRA)

	 TargetPos =  - HaleDiam * math.tan(rd)  --* ( math.sin(-ra))
	end

--	shift center to correspond to center of laser pointing limits
-- 	-11.6 = Diphda in south to +65.2 = Dubhe in north
	TargetPos = TargetPos - 0.0007

--	limit max travel
	if     (TargetPos >  TrackMax) then TargetPos =  TrackMax
	elseif (TargetPos < (0.0-TrackLength)) then TargetPos = (0.0-TrackLength)
	end

-- current opening position
	prevTargetPos = TargetPos

 	return TargetPos
end

MoveTarget = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e3

	function orbit:position (tjd)
		return 0, 0, laserTargetZ(tjd)
	end

return orbit
end
