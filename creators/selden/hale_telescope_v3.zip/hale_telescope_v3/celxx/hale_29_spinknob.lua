-- Spinner Knob control

-- these are defined in 01 so can be accessed by other controls
 TableOfSpinPos = {}
 TableOfSpinSpeed = {}

--==================================================================
--==================================================================
-- SpinButton functions: changes spin speed of associated SpinKnob
-- does not select any command
-- knob's speed value is used by switches which select commands
--==================================================================
SpinState = function(SKnob,ButtonName,ButtonMove,BOff,BOn,BIState,BIMove,date)

   if (sameSel) then return 0 end
   local sel = selP

	local BIS = BIState
	if (BIS == nil) then BIS = "off" end
	local BIM = BIMove
	if (BIM == nil) then BIM = 0 end

   if (sel:name() == ButtonName)  
   then
--	this button selected. Is it in the list?
	  if (TableOfButtons[ButtonName] == ButtonName )
          then
--	in list =yes: change speed value
	    if (ButtonMove == 0) 
	     then
 	      TableOfSpinSpeed[SKnob] = 0
	     else
	      TableOfSpinSpeed[SKnob] = TableOfSpinSpeed[SKnob] - ButtonMove
             end
	   TableOfValues[ButtonName] = "on"
--	s = "speed="..TableOfSpinSpeed[SKnob]
--	celestia:flash(s)
-- 	selected and found in list: restore previous selection and move button
	  celestia:select(TableOfSelections[ButtonName])
  	  return 0
	 end

--	button selected but not in list: add it
--	this also means no previous selection known!!
--	(and this probably can't actually happen: 
--	 when the SSC object is first processed by Celestia, 
--	 no buttons can possibly have been selected)

	TableOfRadios[ButtonName] = SKnob
	TableOfButtons[ButtonName] = ButtonName
	TableOfSpinSpeed[SKnob] = ButtonMove
	TableOfSpinPos[SKnob] = 0 -- ?? prob'ly can't hurt
	TableOfValues[ButtonName] = BIS

-- 	restore selection (i.e.set to nil) and position button
	celestia:select(TableOfSelections[ButtonName])
	return 0
   else 

-- this button is not selected
--	is it already known?
	if (TableOfButtons[ButtonName] == ButtonName )
          then
--	 known:
--	 record actual selection for later
	   TableOfSelections[ButtonName] = sel
	   TableOfValues[ButtonName] = "off"
	   return 0
	  end 

--	not selected, but not in list: add it
--	(probably where all buttons are added)
--	celestia:flash("new:"..ButtonName..":"..SKnob)
	TableOfRadios[ButtonName] = SKnob
	TableOfButtons[ButtonName] = ButtonName
	TableOfSpinSpeed[SKnob] = 0 -- ?? prob'ly can't hurt
	TableOfSpinPos[SKnob] = 0 -- ?? prob'ly can't hurt
	TableOfValues[ButtonName] = BIS
	TableOfSelections[ButtonName] = sel
	return 0
   end
   return 0 -- can't get here
end


--======================================================
--======================================================
-- ScriptedOrbit function 
--======================================================
SpinButton = function (sscvals)

	local orbit = {sscvals}
	orbit.params = sscvals 
	orbit.boundingRadius = 1e-4

	function orbit:position (tjd)
-- intermediate values just to keep function call line short
		local SKnob=self.params.ButtonRadio
		local BName=self.params.ButtonName
		local BMove =self.params.ButtonMove
		local BOn =self.params.ButtonOn
		local BIS = self.params.InitialState
		SpinState(SKnob,BName,BMove,BOff,BOn,BIS,BIM,tjd)

-- spin knob's buttons don't move
		return 0, 0, 0
	end

return orbit
end



--==================================================================
--==================================================================
-- SpinKnob functions
--==================================================================

SpinKnobState = function(SKnob,date)
-- desired angle set by speed 
-- actual angle doesn't matter, only to give impression of speedy rotation

	if (TableOfSpinPos[SKnob] ==nil) then TableOfSpinPos[SKnob] =0 end
	local dt = TableOfSpinSpeed[SKnob]
	TableOfSpinPos[SKnob] = TableOfSpinPos[SKnob] +dt*5
	local theta = TableOfSpinPos[SKnob]

	return  yPi*celestia:newrotation( yAxis, math.rad(theta))

end


--==================================================================
SpinKnobproto =
{
   Period    = 1,
}

-- constructor method
function SpinKnobproto:new(o)
   o = o or {}  -- create table if one not provided
   setmetatable(o, self)
   self.__index = self

   -- set the period to whatever value was specified in the ssc file;
   -- slightly confusing because Celestia is case sensitive--period must
   -- be lowercase, but the field from the ssc file is capitalized.
   o.period = o.Period

   return o
end

-- The orientation function.

function SpinKnobproto:orientation(tjd)


	local SName = self.ButtonRadio
	local qNow = 	SpinKnobState(SName,tjd)
	return qNow.w, qNow.x, qNow.y, qNow.z

end

function SpinKnob(sscvals)
   -- create a new SpinKnob rotation object
   return SpinKnobproto:new(sscvals)
end
