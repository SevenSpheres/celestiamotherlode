--====================================================================
-- command processor
--====================================================================
-- called from telescope orientation function
-- as early as possible in per-frame processing
-- otherwise there are brief visual glitches as one thing changes
-- but others don't

-- previous selection: restore immediately after recognizing command

selP = nil
sameSel = false

-- table of commands:
-- command text (name of selected object) = command function:

cmds = {
-- cass 2ndary
 Hale_Lower_Cass = LowerCassUp,
 HLCA              = LowerCassUp,
 Hale_Raise_Cass = RaiseCassUp,
 HRCA              = RaiseCassUp,
 Hale_Stop_Cass = StopCassUp,
 HSCA              = StopCassUp,

-- coude 2ndary (3 mirror config)
 Hale_Lower_Coude  = LowerCoudeUp,
 HLCD              = LowerCoudeUp,
 Hale_Raise_Coude  = RaiseCoudeUp,
 HRCD              = RaiseCoudeUp,
 Hale_Stop_Coude = StopCoudeUp,
 HSCD              = StopCoudeUp,

-- 2nd coude 2ndary (5 mirror config)
 Hale_Lower_Coude2  = LowerCoude2Up,
 HLCD2              = LowerCoude2Up,
 Hale_Raise_Coude2  = RaiseCoude2Up,
 HRCD2              = RaiseCoude2Up,
 Hale_Stop_Coude2 = StopCoude2Up,
 HSCD2              = StopCoude2Up,

-- Central coude flat

 Hale_Lower_Crane = LowerCrane,
 HLCR              = LowerCrane,
 Hale_Raise_Crane = RaiseCrane,
 HRCR              = RaiseCrane,
 Hale_Stop_Crane = StopCrane,
 HSCR              = StopCrane,

 Hale_Lower_Mirror = LowerMirror,
 HLM              = LowerMirror,
 Hale_Raise_Mirror = RaiseMirror,
 HRM              = RaiseMirror,

-- control of angle of central coude flat
 Hale_Coude_Flat_Auto = CoudeFlatAuto,
 HCFA = CoudeFlatAuto,
 Hale_Coude_Flat_Manual = CoudeFlatManual,
 HCFMAN = CoudeFlatManual,
 Hale_Coude_Flat_45 = CoudeFlat45,
 HCF45 = CoudeFlat45,

 Hale_Control_Coude_Flat_Down = ControlCoudeFlat,
 HCCFD = ControlCoudeFlat,
 Hale_Ignore_Coude_Flat_Down = IgnoreCoudeFlat,
 HICFD = IgnoreCoudeFlat,

 Hale_Coude_Flat_Pulpit_45 = CoudeFlatPulpit45,
 HCFP45 = CoudeFlatPulpit45,
 Hale_Coude_Flat_Pulpit_Off = CoudeFlatPulpitOff,
 HCFPOFF = CoudeFlatPulpitOff,
 Hale_Coude_Flat_Pulpit_Desk = CoudeFlatPulpitDesk,
 HCFPDESK = CoudeFlatPulpitDesk,

-- ------

 Hale_Up_Elevator = UpElev,
 HUE              = UpElev,
 Hale_Down_Elevator = DownElev,
 HDE              = DownElev,
 Hale_Stop_Elevator = StopElev,
 HSE              = StopElev,

 Hale_Control_Desk_Elevator_Override = MCDPFEOverride,
 HCDEO              = MCDPFEOverride,
 Hale_Control_Desk_Elevator_Override_Mid = MCDPFEOverrideMid,
 HCDEOMID              = MCDPFEOverrideMid,
 Hale_Control_Desk_Elevator_Override_Defeat = MCDPFEOverrideDefeat,
 HCDEOD              = MCDPFEOverrideDefeat,

 Hale_Control_Desk_Up_Elevator = MCDPFEUp,
 HCDUE              = MCDPFEUp,
 Hale_Control_Desk_Down_Elevator = MCDPFEDown,
 HCDDE              = MCDPFEDown,
 Hale_Control_Desk_Stop_Elevator = MCDPFEStop,
 HCDSE              = MCDPFEStop,


 Hale_Hide_Labels = HideLabels,
 HHLBL                 = HideLabels,
 Hale_Reveal_Labels = RevealLabels,
 HRLBL                 = RevealLabels,

 Hale_Hide_Telescope = HideTelescope,
 HHT                 = HideTelescope,
 Hale_Reveal_Telescope = RevealTelescope,
 HRT                 = RevealTelescope,

 Hale_Hide_PFC = HidePFC,
 HHPFC                 = HidePFC,
 Hale_Reveal_LoresPFC = RevealLoresPFC,
 HRLPFC                 = RevealLoresPFC,
 Hale_Reveal_PFC = RevealPFC,
 HRPFC                 = RevealPFC,

 Hale_Reveal_Lores_Telescope = RevealLoresTelescope,
 HRLT                 = RevealLoresTelescope,

 Hale_Hide_CFC = HideCFC,
 HHCFC                 = HideCFC,
 Hale_Reveal_CFC = RevealCFC,
 HRCFC                 = RevealCFC,

 Hale_Hide_Plinth = HidePlinth,
 HHP                 = HidePlinth,
 Hale_Reveal_Plinth = RevealPlinth,
 HRP                 = RevealPlinth,
 Hale_Reveal_Lores_Plinth = RevealLoresPlinth,
 HRLP                 = RevealLoresPlinth,

 Hale_Hide_Yoke = HideYoke,
 HHY                 = HideYoke,
 Hale_Reveal_Yoke = RevealYoke,
 HRY                 = RevealYoke,
 Hale_Reveal_Lores_Yoke = RevealLoresYoke,
 HRLY                 = RevealLoresYoke,

 Hale_Hide_Laser_Target = HideTarget,
 HHLTR                   = HideTarget,
 Hale_Reveal_Laser_Target = RevealTarget,
 HRLTR                     = RevealTarget,


 Hale_Hide_Laser_Beam = HideBeam,
 HHLB                   = HideBeam,
 Hale_Reveal_Laser_Beam = RevealBeam,
 HRLB                     = RevealBeam,


 Hale_Hide_LFCFOV = HideLFCFoV,
 HHLFCFOV                 = HideLFCFoV,
 Hale_Reveal_LFCFOV = RevealLFCFoV,
 HRLFCFOV                 = RevealLFCFoV,

 Hale_Hide_Prime_Focus_Instr = HidePFI,
 HHPFI                 = HidePFI,

 Hale_Hide_LFC = HideLFC,
 HHLFC                 = HideLFC,
 Hale_Reveal_LFC = RevealLFC,
 HRLFC                 = RevealLFC,

 Hale_Hide_LaunchTel = HideLaunchTel,
 HHLLT                 = HideLaunchTel,
 Hale_Reveal_LaunchTel = RevealLaunchTel,
 HRLLT                 = RevealLaunchTel,

 Hale_Open_Storage_Door1 = OpenStorageDoor1,
 HOSD1                 = OpenStorageDoor1,
 Hale_Close_Storage_Door1 = CloseStorageDoor1,
 HCSD1                 = CloseStorageDoor1,
 Hale_Stop_Storage_Door1 = StopStorageDoor1,
 HSSD1                 = StopStorageDoor1,

 Hale_Open_Storage_Door2 = OpenStorageDoor2,
 HOSD2                 = OpenStorageDoor2,
 Hale_Close_Storage_Door2 = CloseStorageDoor2,
 HCSD2                 = CloseStorageDoor2,
 Hale_Stop_Storage_Door2 = StopStorageDoor2,
 HSSD2                 = StopStorageDoor2,

 Hale_Open_Storage_Door3 = OpenStorageDoor3,
 HOSD3                 = OpenStorageDoor3,
 Hale_Close_Storage_Door3 = CloseStorageDoor3,
 HCSD3                 = CloseStorageDoor3,
 Hale_Stop_Storage_Door3 = StopStorageDoor3,
 HSSD3                 = StopStorageDoor3,

 Hale_Forward_Overhead_Crane = FwdOCrane,
 HFOC = FwdOCrane,
 Hale_Back_Overhead_Crane    = BackOCrane,
 HBOC = BackOCrane,
 Hale_Stop_Overhead_Crane    = StopOCrane,
 HSOC = StopOCrane,

 Hale_Up_Hook = UpHook,
 HUH = UpHook,
 Hale_Down_Hook = DownHook,
 HDH = DownHook,
 Hale_Stop_Hook = StopHook,
 HSH = StopHook,

 Hale_Hide_PrimeObs = HidePrimeObs,
 HHPO                 = HidePrimeObs,
 Hale_Reveal_PrimeObs = RevealPrimeObs,
 HRPO                 = RevealPrimeObs,

 Hale_Hide_Coude_Yoke_Mirror = HideCoudeYokeMirror,
 HHCYM                 = HideCoudeYokeMirror,
 Hale_Reveal_Coude_Yoke_Mirror = RevealCoudeYokeMirror,
 HRCYM                 = RevealCoudeYokeMirror,

 Hale_Hide_Coude_Flat_Down = HideCoudeFlatDown,
 HHCFD                 = HideCoudeFlatDown,
 Hale_Reveal_Coude_Flat_Down0 = RevealCoudeFlatDown,
 HRCFD                 = RevealCoudeFlatDown,

 Hale_Hide_Coude_Mirror90 = HideCoudeMirror90,
 HHCM90                 = HideCoudeMirror90,
 Hale_Reveal_Coude_Mirror90 = RevealCoudeMirror90,
 HRCM90                 = RevealCoudeMirror90,

 Hale_Hide_Coude_Mirror = HideCoudeMirror0,
 HHCM0                 = HideCoudeMirror0,
 Hale_Reveal_Coude_Mirror = RevealCoudeMirror0,
 HRCM0                 = RevealCoudeMirror0,

-- had to resort to numbers to keep the lights & photons straight

 Hale_Hide_Photons = HidePhotons,
 HHPH                 = HidePhotons,
 Hale_Fly_Photons1 = FlyPhoton1,
 HFPH1                 = FlyPhoton1,
 Hale_Fly_Photons2 = FlyPhoton2,
 HFPH2                 = FlyPhoton2,
 Hale_Fly_Photons3 = FlyPhoton3,
 HFPH3                 = FlyPhoton3,
 Hale_Fly_Photons4 = FlyPhoton4,
 HFPH4                 = FlyPhoton4,
 Hale_Fly_Photons5 = FlyPhoton5,
 HFPH5                 = FlyPhoton5,

 Hale_Hide_Light = HideLight,
 HHL                 = HideLight,
 Hale_Reveal_Light1 = RevealLight1,
 HRL1                 = RevealLight1,
 Hale_Reveal_Light2 = RevealLight2,
 HRL2                 = RevealLight2,
 Hale_Reveal_Light3 = RevealLight3,
 HRL3                 = RevealLight3,
 Hale_Reveal_Light4 = RevealLight4,
 HRL4                 = RevealLight4,
 Hale_Reveal_Light5 = RevealLight5,
 HRL5                 = RevealLight5,

-- text messages because .cel print didn't seem to work
-- (it does)
 Hale_Msg1 = Message1,
 Hale_Msg2 = Message2,
 Hale_Msg3 = Message3,
 Hale_Msg4 = Message4,
 Hale_Msg5 = Message5,
 Hale_Msg6 = Message6,
 Hale_Msg7 = Message7,
 }

hale_cmd = function (this_date)

  local sel = celestia:getselection()
  if (sel == selP) then sameSel = true; return 0 end
  sameSel = false

  local sname = sel:name()

    todo = cmds[sname]
    if todo then 
	todo(this_date)
    	if (selP ~= nil) then celestia:select(selP) end -- restore previous selection

--  	local s = "Hale command:  name= "..sname
-- 	celestia:flash(s)
	return 1
    end

-- This selection is not recognized as a command: 
-- save it for reversion after next command

	selP = sel
	return 0
end

------------- scripted orbit which invokes the command processor

Hale_Command_Processor = function (sscvals)

	local orbit = {}
	orbit.boundingRadius = 1e5

	
	function orbit:position (tjd)
		hale_cmd(tjd)
		return 0, 0, 0
	end

return orbit
end
