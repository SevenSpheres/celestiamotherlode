#! /usr/bin/sh -x
#
# must be done in Addons directory containing only hale_telescope
rm -rf hale_telescope
svn co file:///cygdrive/c/repository/trunk hale_telescope
rm -rf *.zip 
rm -rf hale_telescope/.svn
rm -rf hale_telescope/*.sh
rm -rf hale_telescope/hale_telescope_v241/.svn
rm -rf hale_telescope/hale_telescope_v241/cmods
rm -rf hale_telescope/hale_telescope_v241/*~
rm -rf hale_telescope/hale_telescope_v241/*NO
rm -rf hale_telescope/hale_telescope_v241/\#*
rm -rf hale_telescope/hale_telescope_v241/celxx/.svn
rm -rf hale_telescope/hale_telescope_v241/celxx/*~
rm -rf hale_telescope/hale_telescope_v241/celxx/\#*
rm -rf hale_telescope/hale_telescope_v241/hale_commands/.svn
rm -rf hale_telescope/hale_telescope_v241/models/.svn
rm -rf hale_telescope/hale_telescope_v241/models/*~
rm -rf hale_telescope/hale_telescope_v241/models/\#*
rm -rf hale_telescope/hale_telescope_v241/models/*tmp*
rm -rf hale_telescope/hale_telescope_v241/models/*.cmod_m*
rm -rf hale_telescope/hale_telescope_v241/models/*.exe
rm -rf hale_telescope/hale_telescope_v241/models/*.an8
rm -rf hale_telescope/hale_telescope_v241/models/*.jpg
rm -rf hale_telescope/hale_telescope_v241/models/*.png
rm -rf hale_telescope/hale_telescope_v241/models/*.sh
rm -rf hale_telescope/hale_telescope_v241/models/*.f
rm -rf hale_telescope/hale_telescope_v241/models/a.exe
rm -rf hale_telescope/hale_telescope_v241/models/*.db
rm -rf hale_telescope/hale_telescope_v241/scripts/.svn
rm -rf hale_telescope/hale_telescope_v241/scripts/*~
rm -rf hale_telescope/hale_telescope_v241/scripts/\#*
rm -rf hale_telescope/hale_telescope_v241/textures/.svn
rm -rf hale_telescope/hale_telescope_v241/textures/medres/.svn
rm -rf hale_telescope/hale_telescope_v241/textures/medres/*.db
rm -rf hale_telescope/hale_telescope_v241/textures/medres/*~
rm -rf hale_telescope/hale_telescope_v241/textures/medres/\#*
rm -rf hale_telescope/hale_telescope_v241/textures/medres/*tmp*
rm -rf hale_telescope/hale_telescope_v241/textures/medres/circle*
rm -rf hale_telescope/hale_telescope_v241/textures/medres/e2*.jpg
rm -rf hale_telescope/hale_telescope_v241/textures/medres/l0*.jpg
rm -rf hale_telescope/hale_telescope_v241/textures/medres/lot*.jpg
#
cd hale_telescope
mv hale_telescope_v241 hale_telescope_v3
cd hale_telescope_v3
#cat *.ssc >all.txt
#rm *.ssc
#mv all.txt hale_telescope.ssc
cd ..
zip -r ../hale_telescope_v3.zip *
cd ..
