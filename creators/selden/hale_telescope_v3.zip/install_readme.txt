Installation Requirements
=========================

This Addon is designed for use with Celestia v1.6.0 or later. 
It mostly works with Celestia v1.5.1.
It will not work with earlier versions of Celestia.

If you restore from this Zip file into Celestia's Extras directory, it
should recreate all of the directories and files necessary for this
Addon to function.

Please read the accompanying readme for details about use of this Addon.

Copyright
=========

This Addon, its models and accompanying documents were created
by Selden Ball for use with Celestia and are
copyright � 2008. All rights reserved.

License
=======

This Addon may be freely redistributed for educational purposes 
so long as all of the provided files are included.

This Addon may not be used for any commercial benefit 
without explicit written permission from the author.

Selden Ball
http://www.lepp.cornell.edu/~seb/
