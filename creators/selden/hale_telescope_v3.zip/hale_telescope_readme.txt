The 200" Hale Telescope on Palomar Mountain
Official V3 release
An Addon for Celestia.

Copyright � 2008 Selden Ball 
All rights reserved.
================================

This Addon provides an interactive model of the 200" Hale Telescope 
and its dome on a digital elevation model of Palomar Mountain.

This Addon is designed for use with Celestia v1.6.0 or later,
although most of it will work with v1.5.1.

(It doesn't crash under v1.5.1, but some controls do nothing 
 and some components are visible when they should not be: 
 the central Coud� flat, for example.)

If you restore this Zip file into Celestia's Extras directory, it should
recreate all of the directories and files necessary for it to work with
Celestia v1.6.0 or later.

After installing this Addon, start by viewing the HTML file
hale_telescope_v3.html
It includes Cel:// URLs which will take you to interesting viewpoints
around the telescope, including its control desks.

The Scripts folder includes several scripts which demonstrate
some of the functions of the telescope.

Warnings
========

1. This Addon does not cohabitate happily with other Addons
which make extensive use of ScriptedOrbit and ScriptedRotation
functions. Its scripts use many conflicting global values.

2. This Addon disables the CustomRotation of the Earth so that
the Addon's Cel:// URLs will function properly. I did not have the 
time or will power to update the URLs for v1.6. 
To restore the Earth's CustomRotation, edit hale.ssc to comment
out or delete the Modify "Earth" declaration. It's at the very
beginning.

Performance
===========

The telescope's models and scripts are numerous, large and complex.
Celestia pauses for several seconds to load them when the telescope
first comes into view. Please be patient.

While running, I get about 15-20 frames/second on a rather fast
system.  It may run much more slowly for you. A low resolution version
of the model of the telescope is included. Selecting that may help.
It doesn't make any noticable difference on my computer, though.

Most of the observatory's internal structures are hidden by default.
This seems to improve the framerate by about 30% on my computer.  They
can be enabled by selecting the "Interior" button in the left-most
column on the Demo Desk.

Functions
=========

New for v3: 

1. 3D control desks have been added which control the telescope and
its associated equipment. Things happen when you select their buttons
or switches.

 + The Demo desk controls demonstration effects: 
    light paths, photons, labels, visibility of components, etc.
 + the control desk and pulpit have controls for the movement of 
   various telescope components, including manual control of the 
   telescope's pointing direction in RA and Dec.
 + brief HTML reference manuals for the controls are included
 + the elevators, overhead crane and some doors include their own control panels

2. Various models have been added or improved

 + improved appearances of various elements of the models
 + mannequins are posed in various locations
 + added visitors' gallery
 + added equipment elevators
 + added equipment storage rooms
 + added AO laser
 + added observer at Cassegrain focus
__________________________________________________

All v2.0 functionality is still available in v3:

The included SSC catalogs and Scripted Orbits and Rotations 
cause the telescope to track the currently selected object 
and the dome to turn with it.

The field-of-view images represent what can be seen by 
the Palomar Large Format Camera described at
http://www.astro.caltech.edu/observatories/palomar/lfc/lfc.html
and by the PHARO (Palomar High Angular Resolution Observer) camera
described at 
http://astrosun2.astro.cornell.edu/research/projects/PHARO//pharo.html

The included HTML (Web) file hale_telescope_v3.html contains Cel://
URLs which will take you to viewpoints around the telescope.

The control desks in the observatory and the scripts included in the
scripts subdirectory can be used to configure the telescope for
observation and to display the various paths that light takes through
the telescope.

Textual control commands are implemented which enable you to move some
of the components of the telescope and of the observatory.  Scripts
invoking the individual commands are in the folder hale_commands.
(The commands themselves are defined as OpenCluster deep space objects
in 00_hale_commands.dsc)

To give a telescope control command while Celestia is running, 
you can click on a switch on one of the consoles,
select one of the one-line scripts in the directory hale_commanad,
or type a command directly to Celestia in the form

[return]command[return] 

where "command" is the name of one of the objects defined in hale_commands.dsc

( This last is exactly the same method that you could use 
  to select for viewing any astronomical object in Celestia.)

If you type a recognized command, the Hale control scripts will promptly 
start executing it (and reselect the previously selected object).
Any object selection which is not recognized by the control scripts
will be ignored by them and will be left for Celestia to select.

All of the commands are either multi-word strings starting with "Hale_"
or their 3-5 character synonyms starting with the letter "H".

__________________________________________________

Hale Telescope Controls
(These lists of functions are incomplete.)

Buttons on the Demo desk separately hide or reveal
  + labels for major components of the telescope
  + the dome and its base
  + interior fixtures of the dome
  + low or high resolution versions of 
    the telescope's plinth, yoke and optical assembly
  + the laser system sometimes used with the adaptive optics
  + any of the five light paths and animated photons along them
  + an observer taking pictures at the prime focus
  + the large format camera
  + the laser launch telescope sometimes used with the adaptive optics
  + several different instruments at the Cassegrain focus

Switches and knobs on the Control Desk
  + control the telescope's orientation
  + open and close the dome's doors
  + raise and lower the cover of the primary mirror
  + control the dome's orientation, either tracking the telescope or 
    rotating relative to the telescope. (I didn't make it a
    completely separate rotation.)

Switches on the Pulpit Desk
  + raise and lower the Cassegrain and Coud� secondary mirrors
  + raise and lower the central Coud� flat and its crane
  + rotate the central Coud� flat to direct the Cassegrain light path
    through the East trunnion into the East arm 
    for observing with the East Eschelle Spectrograph.
  + raise and lower the Coud� Bridge which is needed 
    when using the Coud� light path to observe objects
    which have a Declination greater than +50 degrees. 

Note: Commands are *not* available to raise and lower the windscreen.
Its motions are defined using static Reference Frame directives in its
SSC catalog and are not controlled by Lua scripts. In other words, it
automatically follows the telescope.  Manual control will have to wait
for a future version of this Addon.

Separate controls on some devices
  + raise, lower and stop the prime-focus elevator
  + move the overhead crane backward and forward
  + raise, lower and stop the crane's main hook
  + open and close storage room doors
  + open and close the outside overhead door


Operational Notes
=================

Although the URLs on the Web page "hale_telescope_v3.html"
will take you to reasonable locations, in many cases
you'll find your view blocked by the observatory dome.

To see the telescope through the dome, you must 
type some commands in the form [return]command[return] 
or select appropriate buttons on the "Demo Desk"

You could either
 + open the dome doors and then peer inside
 command:   Hale_Open_Dome_Doors
      or    HODD
or
 + hide the dome entirely
 command:   Hale_Hide_Dome
      or    HHD
            HRD to restore

and you'll probably want to
 + hide the internal support structure
 command:   Hale_Hide_Dome_Internal
      or    HHDI
            HRDI to restore

You also can use some of the URLs on the Web page to go inside the
dome.

Accuracy Limitations
====================

This Addon is representational rather than realistic.
References for many of its components are limited or unavailable,
and my interpretations of the ones I have are often mistaken.
As a result, the models of the telescope and its dome are incomplete,
many details have been omitted, and some aren't quite right.

If you can provide reference pictures for missing or incorrect details,
the author would be delighted to make appropriate improvements!

Some of the known defects are

 - The low-polygon models of the telescope, yoke and plinth don't exactly
match the high-polygon versions.

 - The model of the mountaintop is relatively low resolution and
doesn't exactly follow the topographic contours.

 - The telescope and dome turn continuously despite the time of day:
The yoke and optical tube turn to orienations which are impossible for
the real telescope.  Appropriate motion limits will have to wait for a
future version of this Addon.

 - In order for the telescope's operation to be visible, the sun needs
to be up, so the scripts show the telescope moving during Celestia's
daytime.  Normally the real telescope's dome would be closed during
the day in order to provide a constant temperature, ensuring the
stability of the shape of the primary mirror.

Functional Limitations
======================

The SSC catalogs and Scripted motion Lua modules were developed 
using Celestia compiled from developmental source code for v1.6.0.
Some of the functions cannot work with earlier versions of the program, 
and may need to be modified for use with later versions.

The telescope tracking and control functions were written with
the assumption that time is monotonically increasing. In other words,
they won't work right if time is reversed. Strange things happen.

In order for the "H" commands to work, Celestia must be Following 
or in SynchOrbit around Hale_Position or some other telescope component.

In V2.0 when the telescope model was pointed down toward the Earth, 
(not a valid telescope configuration, of course!)
some of Celestia's orientation calculations failed because the axes 
of some of the coordinate systems became parallel to one another. 
This caused the dome to abruptly tilt. This problem has been fixed 
in v3 by orienting the dome so that it is not quite horizontal, but
the tilt is so slight that it isn't noticable.

The large number of objects and the associated ScriptedRotation and
ScriptedOrbit functions cause Celestia to run slowly. Hiding the
control desks and the dome's interior (which are the defaults) and
displaying the low resolution models can help somewhat.

The dome and its interior fixtures rotate unrealistically fast when the
telescope is pointing near the zenith.

The declination limits of the telescope's optical tube model are not
enforced. For example, it'll happily point toward the south pole,
going into the south pillar. When that happens, the laser light beams
will still point toward the trolley, too, penetrating through "solid"
materials.

The algorithm for the laser trolley position is not accurate.
As a result, the laser beam from the Coud� room sometimes
misses the hole in the yoke.

Credits
=======

Surface textures of Neptune and Uranus were derived from
adaptive optics pictures taken by, and are used with the permission of,
Don Banfield (Cornell). Credits: Don Banfield (Cornell), 
PHARO Team (Cornell), and PALAO Team (JPL).

Of course, none of this would work without Celestia :)
http://www.shatters.net/celestia/
The scripted control functions are written in Lua.
http://www.lua.org/
The Lua functions used to orient the telescope make use of routines
adapted (with permission) from the Lua Edu Tools for Celestia. Thanks, Vincent!
http://vincent.gian.club.fr/celestia/Lua_Edu_Tools.zip
 
Thanks to Steve Popovich for helping debug the Addon under Linux.

The models included in this Addon were created using Anim8or, 
a free 3D design program written for Windows by Steve Glanville. 
Visit http://www.anim8or.com/ for more information.

The designs of the models were based on 

1. photographs provided by Scott Kardel, Palomar Public Affairs Coordinator

2. photographs provided by several members of Cornell astronomy 
research groups, including Don Banfield, George Gull, and Chuck Henderson.

3. pictures and movies on the Palomar Web site at 
http://www.astro.caltech.edu/palomar/ )

4. photographs of the telescope's construction found on the Web in
the Caltech Institute Archives at http://archives.caltech.edu/ 

5. drawings of the telescope by Russell Porter as published in 
_Photographic Giants of Palomar_, Fassero and Porter, Westernlore Press (1947)

and on information found in the books

6. _The Perfect Machine: Building the Palomar Telescope_
by Ronald Florence, Harper-Collins Publishers (1994) 

7. _Palomar, The World's Largest Telescope_
by Helen Wright, The MacMillan Company (1954)

8. _The Glass Giant of Palomar_
by David O. Woodbury, Dodd, Meade & Company (1940)

and on information found in the articles

9. "Optics of the 200-Inch Hale Telescope"
by John A. Anderson, 1948pasp 60 221A

10. "Engineering Aspects of the 200-Inch Hale Telescope"
by Bruce Rule, 1948pasp 60 225

(pasp = Proceedings of the Astronomical Society of the Pacific)

The following Web sites also provided useful information:
http://www.astro.caltech.edu/palomar/200inch/lfc/index.html
http://www.astro.caltech.edu/observatories/palomar/lfc/lfc.html
http://ao.jpl.nasa.gov/
http://astrosun2.astro.cornell.edu/research/projects/PHARO//pharo.html
and other Web sites too numerous to mention.

The "7.5 minute" DEM and topographic maps that this Addon uses
were originally created by the USGS. 
DEM models were obtained from http://geogdata.csun.edu/
Topographic maps were obtained from http://archive.casil.ucdavis.edu/

They were translated into Celestia's CMOD format using 
3DEM and a home-grown Fortran program.
ImageMagick and netpbm were used to crop, scale and translate
the topo map and other images into JPEG format. 3DEM, ImageMagick and 
netpbm are freely available. Visit their Web sites at
http://www.visualizationsoftware.com/3dem.html
http://www.imagemagick.org/ 
and 
http://netpbm.sourceforge.net/


Copyright and license
=====================

This Addon, its models and accompanying documents
were created by Selden Ball for use with Celestia and are
copyright � 2008. All rights reserved.

License: 
This Addon may be freely redistributed for educational purposes 
so long as all of the provided files are included.

This Addon may not be used for any commercial benefit 
without explicit written permission from the author.

Selden Ball
http://www.lepp.cornell.edu/~seb/
