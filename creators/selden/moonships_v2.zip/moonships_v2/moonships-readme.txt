This is v2 of a "Moonships" Addon.
It has been modified for use with Celestia v1.4.1 and later

Here are models of cargo and passenger versions of a moonship. 
They're based on designs by Chesley Bonestell, Werner 
von Braun and Willy Ley of the 1950s, but differ slightly from 
those original designs.

The original 3DS models were created by Re(i)mbrandt.
They were revised slightly and converted to CMOD format by Selden.

Restore this Zip archive into your Extras/Addons folder,
so that files are restored into directories as they are in the archive.

The Cel:// URLs in the HTML file will take you to viewpoints near the 
two spacecraft.

This Celestia Addon is copyright by Re(i)mbrandt and Selden.
It may be used only for non-commercial purposes.
Any other use requires permission from both authors.
For more information, contact either 
Re(i)mbrandt at reimbrandt@freenet.de
or
Selden at seb1@cornell.edu


April, 2005

Updated by Selden on February 2, 2009 
so it works with Celestia v1.5.1 and v1.6.
