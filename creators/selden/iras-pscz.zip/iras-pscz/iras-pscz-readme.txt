This Addon displays the locations of 16159 galaxies from the PSCz catalog (Saunders, et. al. 2000) when used with Celestia v1.3.2pre3 or later.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

This Addon consists of the Deep Space Catalog "iras-pscz.dsc", which specifies the model file "iras-pscz_z.cmod". It includes a commented-out reference to the model file "iras-pscz_r-r.cmod". The "_z" model uses distances as determined from spectrographic recessional velocities measured by IRAS. "Finger of God" effects are plainly visible in clusters of galaxies. The "_r-r" model uses distances determined by Rowan-Robinson (1988) and included in the PSCz catalog. Galaxies in the same cluster usually are all shown at the same distance. Each of the 235 clusters of galaxies listed in the PSCz catalog have been given a unique random color. However, no attempt was made to provide distinctively different colors to clusters which are near one another.

You must have Celestia v1.3.2 prerelease 3 or later in order to be able to use CMOD model files.

===============================
Viewing the survey:

The HTML file ViewIRASgalaxies.html provides several Cel:// URLs
to view the distribution of galaxies. They take you to various distant viewpoint, 25 Giga Light Years away, looking toward the Sun.

No rights are asserted.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
24 March 2004

===============================
Acknowledgements:

This DSC catalog was generated from a copy of the catalog
"VII/221   PSCz catalog   (Saunders+, 2000)" downloaded fro VizeR.




