This is the "Sloan Digital Sky Survey Data Release 1" 
catalog of Quasars adapted for use with Celestia v1.3.2pre3 or later.

This Addon contains a single Deep Space Catalog for Celestia:

quasars-cmod.dsc

This catalog file specifies the model file quasars.cmod.
This is a "Celestia Model" containing the xyz  locations of 16713 QSOs. 
(QSO = Quasi Stellar Object = Quasar)
Each QSO is represented by a single dot in space.

You must have Celestia v1.3.2 prerelease 3 or later
in order to be able to use CMOD files.

===============================
Viewing the Quasars 

Unlike when one uses separate models for each body, despite the large 
number of objects involved, Celestia lets you change your viewpoint 
in realtime.

ViewQuasars.dsc

ViewQuasars.dsc provides a distant viewpoint which lets one see
an overview of the distribution. After going to this location,
you should turn and look toward the sun. You can do this
by typing the three keyboard commands H C F
and then you can use the mouse or keyboard to change your viewpoint.

ViewQuasars.html

The HTML file ViewQuasars.html provides a Cel:// URLs
to view the Quasars. It takes you to a distant viewpoint,
35 Giga Light Years away, looking toward the Sun.
Then you can use the mouse or keyboard to change your viewpoint.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
21 Feb 2004

===============================
Acknowledgements:

These catalog files were generated from the catalog
J/AJ/126/2579   SDSS quasar catalog. II. First data release (Schneider+, 2003)
downloaded from the Visier catalog server.

How to cite the usage of VizieR

The prefered reference for the usage of VizieR is the following paper:
Ochsenbein F., Bauer P., Marcout J., 2000, A&AS 143, 221 

Acknowledging SDSS: Non-Commercial Use
Non-commercial scientific and technical publications using SDSS data should include the following acknowledgment: 

Funding for the creation and distribution of the SDSS Archive has been provided by the Alfred P. Sloan Foundation, the Participating Institutions, the National Aeronautics and Space Administration, the National Science Foundation, the U.S. Department of Energy, the Japanese Monbukagakusho, and the Max Planck Society. The SDSS Web site is http://www.sdss.org/. 

The SDSS is managed by the Astrophysical Research Consortium (ARC) for the Participating Institutions. The Participating Institutions are The University of Chicago, Fermilab, the Institute for Advanced Study, the Japan Participation Group, The Johns Hopkins University, Los Alamos National Laboratory, the Max-Planck-Institute for Astronomy (MPIA), the Max-Planck-Institute for Astrophysics (MPA), New Mexico State University, University of Pittsburgh, Princeton University, the United States Naval Observatory, and the University of Washington.
