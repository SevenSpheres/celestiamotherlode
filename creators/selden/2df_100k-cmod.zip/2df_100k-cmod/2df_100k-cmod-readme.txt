This is v2 of the adaptation of "2df 100K data release of 31 January 2001" catalog of galaxies' redshifts for use with Celestia v1.3.2pre3 or later.


This Addon contains a single Deep Space Catalog for Celestia:

2df_100k-cmod.dsc

This catalog file specifies the model file "2df_100k.cmod"

This is a "Celestia Model" containing the xyz locations of 
93843 galaxies and QSOs. Each object is represented by a single dot in space.

You must have Celestia v1.3.2 prerelease 3 or later in order to be able to use CMOD files.

===============================
Viewing the galaxies:

Unlike when one uses separate models for each body, displaying points that are part of the same model is highly efficient. Realtime changes of viewpoint are easily managed.

View2df_100k.dsc

View2df_100k.dsc provides a distant viewpoint which lets one see
an overview of the distribution. After going to this location,
you should turn and look toward the sun. You can do this
by typing the three keyboard commands H C F
Then you can use the mouse, keyboard or joystick to change your viewpoint.

View2df_100k.html

The HTML file View2df_100k.html provides a Cel:// URL
to view the distribution of galaxies. It takes you to a distant viewpoint, 7 Giga Light Years away, looking toward the Sun.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
22 Feb 2004

===============================
Background:

A major problem was found with v1 and corrected in v2: the sign of objects' declination was being ignored. As a result, all of the galaxies were drawn north of the equator. Actually, most of the observations included in the 2dF catalog were of galaxies that are south of the equator. 

V2 includes an enhancement: the points representing galaxies are colored depending on which observation strip they are in. The Southern Galactic Pole strip is colored yellow, The Northern is blue and objects in random fields are red. Of course, you can edit the model file to choose colors more to your liking.

Coloring the galaxies revealed a problem that exists in the catalog: there are 5155 objects which seem to have spuriously small redshifts. Many of these objects also are placed in the wrong places on the sky. 

Using Celestia to find these objects is left as an exercise for the student :-)
===============================
Acknowledgements:

This catalog file was generated from the catalog
VII/226   The 2dF Galaxy Redshift Survey 100k Data Release   (2dFGRS Team, 2001)
downloaded from the Visier catalog server.

How to cite the usage of VizieR

The prefered reference for the usage of VizieR is the following paper:
Ochsenbein F., Bauer P., Marcout J., 2000, A&AS 143, 221 

For details about the 2dF survey of galactic redshifts,
visit the Web page http://magnum.anu.edu.au/~TDFgg/

