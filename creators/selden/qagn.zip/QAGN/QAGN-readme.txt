This Addon adapts the catalog "Quasar & Active Galactic Nuclei (11th ed) Veron et al., December 2003" for use with Celestia v1.3.2pre3 or later.

The 11th edition catalog includes entries from the 2dF Quasar catalog and the first data release of the Sloan catalog, as well as previous catalogs.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

This Addon displays the locations of 15066 active galactic nuclei, 401 BL Lac objects, and 49820 QSOs (and others). They are color coded by the type of object: red = QSO, yellow though near white = Seyfert galaxies, cyan = BL Lacertae objects. Consult the CMOD files for the precise details of color assignments to the various categories.

This Addon consists of the Deep Space Catalog "qagn.dsc", which specifies the three model files "qsos.cmod", "bllac.cmod" and "agn.cmod".

You must have Celestia v1.3.2 prerelease 3 or later in order to be able to use CMOD model files.

===============================
Viewing the QSOs:

Unlike when one uses a separate model for each body, displaying tens of thousands of points that are part of the same model is highly efficient. Realtime changes of viewpoint are easy.

The HTML file ViewQSOs.html provides a Cel:// URL
to view the distribution of galaxies. It takes you to a distant viewpoint, 25 Giga Light Years away, looking toward the Sun.

No rights are asserted.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
6 March 2004

===============================
Acknowledgements:

This DSC catalog file was generated from the catalog file
VII/235            Quasars and Active Galactic Nuclei (11th Ed.)  (Veron+, 2003)
at
 http://vizier.u-strasbg.fr/viz-bin/ftp-index?VII/235 

For more information, see the abstract of the paper by Vernon et al. at
http://simbad.u-strasbg.fr/cgi-bin/cdsbib?2003A%26A...412..399V