This Addon displays the locations of 78055 selected galaxies from the Sloan Digital Sky Survey, second data release, with Celestia v1.3.2pre3 or later.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

This Addon consists of the Deep Space Catalog "sdss-2dr-galaxies.dsc", which specifies the model file "sdss-2dr-galaxies.cmod".

You must have Celestia v1.3.2 prerelease 3 or later in order to be able to use CMOD model files.

===============================
Viewing the survey:

Unlike when one uses a separate model for each body, displaying tens of thousands of points that are part of the same model is highly efficient. Realtime changes of viewpoint are easy.

The HTML file ViewSDSSgalaxies.html provides a Cel:// URL
to view the distribution of galaxies. It takes you to a distant viewpoint, 25 Giga Light Years away, looking toward the Sun.

No rights are asserted.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
24 March 2004

===============================
Acknowledgements:

This DSC catalog was generated from a dsv file created using the SDSS SkyServer Spectro Query Server form at
http://cas.sdss.org/dr2//en/tools/search/SQS.asp

The major constraints were redshift confidence >0.2, r < 2 and at least one of all of the various target flags which contained the word "galaxy".

See the SDSS credits page at http://cas.sdss.org/dr2/en/credits/
