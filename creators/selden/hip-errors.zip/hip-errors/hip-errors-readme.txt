This Addon displays the errors in the distances measured by the Hipparcos satellite, for use with Celestia v1.3.2pre3 or later.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

Lines with lengths corresponding to the standard error in the parallaxes are drawn for six ranges of errors in the Hipparcos parallax measurements. They are color coded by the size of the errors relative to the distances. Standard errors of less than 5% of the measured distance are green. They shade toward the red for errors between 5-10%, 10-20%, 20-40% and greater than 40% of the measured distance. 

This Addon includes a combined Deep Space Catalog, "hip-errors.dsc", which specifies all six different CMOD model files for simultaneous viewing. The six models are specified in the DSC catalog in an order which allows all of them to be visible at the same time. 

This Addon also contains individual DSC catalogs, one for each of the error ranges. As supplied, the names of the individual catalog files all end in "NO." As a result, Celestia doesn't recognize them as DSC catalogs and doesn't draw them. In order to view the individual error ranges you can either edit hip-errors.dsc or rename the other files one at a time to remove the "NO."

The six CMOD files are as follows: 
  6113 stars in hip-05-errors.cmod    ( 263(*) <  6113 < 111842 ) (green)
 14750 stars in hip-5-10-errors.cmod  ( 6376   < 14750 <  97092 ) (yellow-green)
 28567 stars in hip-10-20-errors.cmod (21126   < 28567 <  68525 ) (yellow)
 32732 stars in hip-20-40-errors.cmod (49693   < 32732 <  35793 ) (orange)
 34677 stars in hip-40-errors.cmod   ( 82425   < 34677 <   1116 beyond 60KLY) (red)
  1009 stars in hip-60K-errors.cmod ( 117102   <  1009 <    107(*) w/infinite errors) (blue; which is not red :) )

 for a total of 118218 stars in the main Hipparcos catalog.
----
 (*) - 263 stars have a parallax of 0 specified, while another 107 have disproportionately large errors. The error bars for these 380 objects are not drawn.

===============================
Viewing the errors:

Unlike when one uses a separate model for each body, displaying more than 100 thousand points that are part of the same model is highly efficient. Realtime changes of viewpoint are easy.

The HTML file ViewErrors.html provides several Cel:// URLs
to view the distribution of errors. They can take you to several distant viewpoints, at distances appropriate to the sizes of the various distributions of error bars. One of the viewpoints provides a close-up view of HIP 400.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html

Selden Ball
5 March 2004

===============================
Acknowledgements:

This DSC catalog file was generated from the Vizier catalog "I/239  The Hipparcos and Tycho Catalogues (ESA 1997)"

See also http://astro.estec.esa.nl/Hipparcos/site-guide.html
and the Proceedings from the Hipparcos Venice '97 symposium
at http://astro.estec.esa.nl/Hipparcos/venice.html


