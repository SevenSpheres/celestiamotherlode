This is the "Sloan Digital Sky Survey Data Release 1" 
catalog of Quasars adapted for use with Celestia.

This Addon contains two Deep Space Catalogs for Celestia:

sdss-dr1-qso-named.dsc
sdss-dr1-qso-dots.dsc

These two catalog files each list the locations of the same 16713 QSOs.
(QSO = Quasi Stellar Object = Quasar)

sdss-dr1-qso-named.dsc includes their formal names and locations.

sdss-dr1-qso-dots.dsc has replaced all of the quasars' formal names
by a single dot (period). 

No models or surface textures are specified or included, except for testing.
The extreme distances involved cause individual models to be invisible.

===============================
Viewing the Quasars 

Because of the large number of objects involved, Celestia runs
frustratingly slowly.

If you load sdss-dr1-qso-dots.dsc and enable "Label Galaxies", you'll see an
overview of the distribution. However, the positions aren't exactly right.

If you load sdss-dr1-qso-named.dsc, run the script MarkQuasars.cel
and enable markers (but not labels), you'll see an overview of the 
distribution with somewhat more accuracy. However, running the
Mark script can take quite a while.

ViewQuasars.dsc

ViewQuasars.dsc provides a distant viewpoint which lets one see
an overview of the distribution. After going to this location,
you should turn and look toward the sun (H C F).

ViewQuasars.html

The HTML file ViewQuasars.html provides two Cel:// URLs
to view the Quasars. They take you to a distant viewpoint
and enable either labels or markers.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
15 Feb 2004

===============================
Acknowledgements:

These catalog files were generated from the catalog
J/AJ/126/2579   SDSS quasar catalog. II. First data release (Schneider+, 2003)
downloaded from the Visier catalog server.

How to cite the usage of VizieR

The prefered reference for the usage of VizieR is the following paper:
Ochsenbein F., Bauer P., Marcout J., 2000, A&AS 143, 221 

Acknowledging SDSS: Non-Commercial Use
Non-commercial scientific and technical publications using SDSS data should include the following acknowledgment: 

Funding for the creation and distribution of the SDSS Archive has been provided by the Alfred P. Sloan Foundation, the Participating Institutions, the National Aeronautics and Space Administration, the National Science Foundation, the U.S. Department of Energy, the Japanese Monbukagakusho, and the Max Planck Society. The SDSS Web site is http://www.sdss.org/. 

The SDSS is managed by the Astrophysical Research Consortium (ARC) for the Participating Institutions. The Participating Institutions are The University of Chicago, Fermilab, the Institute for Advanced Study, the Japan Participation Group, The Johns Hopkins University, Los Alamos National Laboratory, the Max-Planck-Institute for Astronomy (MPIA), the Max-Planck-Institute for Astrophysics (MPA), New Mexico State University, University of Pittsburgh, Princeton University, the United States Naval Observatory, and the University of Washington.
