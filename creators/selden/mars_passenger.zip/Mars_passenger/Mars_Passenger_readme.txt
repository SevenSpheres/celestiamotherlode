Restore this Addon folder into Celestia's Extras (or Addons) folder 
to view a somewhat simplified model of the Mars Passenger ship designed
by Wernher von Braun and Chesley Bonestell in the 1950s. Descriptions
of the expedition were published in Collier's Magazine, which proposed
that a fleet of 10 of these, along with 3 landers, be sent to Mars.

The 7.8MB model used by this Addon, mars_passenger.cmod, 
requires Celestia v1.3.2 or later. 

This Addon may be redistributed freely for use with Celestia, but
it may not be used for any commercial gain.

Acknowledgements:

This model was designed using illustrations by Chesley Bonestell 
as seen in the books
 _The Exploration of Mars_, by Willy Ley and Wernher von Braun, The Viking Press (1956)
and
 _Worlds Beyond: the Art of Chesley Bonestell_, 
    edited by Ron Miller & Frederick C. Durant III, Donning (1983)

Dimensions were obtained from drawings by Jon C. Rogers as seen in the book
 _Spaceship Handbook_, by Jack Hagerty and Jon C. Rogers, ARA Press (2001)


Selden Ball
June, 2005





