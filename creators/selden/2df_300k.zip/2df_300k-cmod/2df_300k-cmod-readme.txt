This Addon adapts the "2dF Galactic Redshift Survey" final data release (Colless et al, 2003) for use with Celestia v1.3.2pre3 or later.

If you restore this Zip archive into your Addons (or extras) folder, it should create its files in all the necessary sub-directories.

This Addon displays the locations of 229103 galaxies and QSOs.They are color coded by which of three surveys included them. (blue = northern galactic survey, yellow = southern and red = random.)

Unlike the 100k release which contained z values with a resolution of 0.000001,
the 2dF final release catalog specifies redshifts with a z resolution of 0.0001. 
This causes problems for the objects with small redshifts. Objects which have negative redshifts in the 2dF catalog are not included in this Addon, but objects with small redshifts, mostly stars, were left in. 

This Addon consists of the Deep Space Catalog 2df_300k-cmod.dsc, which specifies the model file "2df_300k.cmod".
You must have Celestia v1.3.2 prerelease 3 or later in order to be able to use CMOD files.

===============================
Viewing the galaxies:

Unlike when one uses a separate model for each body, displaying hundreds of thousands of points that are part of the same model is highly efficient. Realtime changes of viewpoint are easy.

The HTML file View2df_300k.html provides a Cel:// URL
to view the distribution of galaxies. It takes you to a distant viewpoint, 7 Giga Light Years away, looking toward the Sun.

See also http://www.lns.cornell.edu/~seb/celestia/catalogs.html


Selden Ball
5 March 2004

===============================
Acknowledgements:

This catalog file was generated from the catalog file "best_observations.idz" by Matthew Colless, et al. 30 June, 2003.

It was downloaded from the 2dFGRS Web site at http://magnum.anu.edu.au/~TDFgg/Public/Release/SpecCat/index.html

For details of the 2dF survey of galactic redshifts,
visit the Web page http://magnum.anu.edu.au/~TDFgg/