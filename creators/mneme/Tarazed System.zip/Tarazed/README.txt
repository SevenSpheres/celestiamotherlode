Namaste.

This is the Tarazed system, the primary setting for the upcoming novels The Dream of Tarazed and The Fires of Tarazed.  The system contains 19 fictional planets around the star Tarazed (gamma Aquilae), 39 moons around those, and one planet around the semi-fictional star Tarazed-B.

To install, extract this zip file to your Celestia directory.  Ensure that the .ssc files are in Celestia/extras/Tarazed.

http://comm.tarazedi.com/viewforum.php?f=59 gives additional information on the universe in which this add-on is set.

Thank you for your interest.

-Victor "Mneme" Sheckels

