
LLL        OOOOOOOOO  LLL           AAA
LLL        OOOOOOOOO  LLL          AA AA
LLL        OOO   OOO  LLL         AA   AA
LLL        OOO   OOO  LLL        AAAAAAAAA
LLLLLLLLL  OOOOOOOOO  LLLLLLLLL  AA     AA
LLLLLLLLL  OOOOOOOOO  LLLLLLLLL  AA     AA


This archive contains image files part of the LOLA Science Team release of virtual textures (VTs) for the Celestia program (shatters.net/celestia).
The altimetry data were collected by the Lunar Orbiter Laser Altimeter (LOLA) onboard the Lunar Reconnaissance Orbiter (LRO), between July 2009 and January 2011.
The Gridded Data Records (GRDs) released by the LOLA Science Team on the Planetary Data System (PDS, geosciences.wustl.edu) were the source used in this release for the original basemap.
The various tiles composing the VT were formed with the tools developped by Fridger Schrempp (F-TexTools, http://www.celestialmatters.org/?q=node/31).

We hope you enjoy seeing the Moon in a different way!


LOLA Science Team
NASA Goddard Space Flight Center




Installation
============

You should unzip the archive, preserving this structure, into the "extras" directory of your Celestia installation.
Make sure you download and uncompress the lower-level ZIP files first.

The "extras" directory in which you need to uncompress the LOLA VTs differs depending on your platform.
- on MacOSX, you cannot directly access the contents of the latest version of Celestia (1.6) . In Finder, when in the Applications directory, you will need to right-click on the "Celestia" icon and select "Show Package Contents". If it does not exist, create an "extras" directory in "/Applications/Celestia.app/Contents/Resources/CelestiaResources/"
- on Windows, the "extras" directory should be directly below your chosen installation path (e.g., "C:\Program Files\Celestia\extras\"). However, with the latest Windows OS versions, the "Program Files" directories are protected, so you will need to confirm every copy/unzip command to the "extras" directory. If you haven't installed Celestia yet, we'd recommend installing it in another directory (e.g., "C:\Celestia").
- if you use Linux, you can probably figure it out.



Release Information
===================

The full release contains various archives. 

  MoonNormalTopoMap_LOLA_level012.zip
  MoonTopoMap_LOLA_level3.zip
  MoonTopoMap_LOLA_level4.zip
  MoonTopoMap_LOLA_level5.zip
  MoonNormalMap_LOLA_level3.zip
  MoonNormalMap_LOLA_level4.zip
  MoonNormalMap_LOLA_level5.zip

If you choose to install several packages, you may have to overwrite pre-existing files (readme.txt, some .ssc files).


For more information, contact lolahelp@gmail.com 
(please describe your issues with some detail) 



