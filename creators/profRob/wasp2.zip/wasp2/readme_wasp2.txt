Installation

Included in the zip file are

wasp2star.stc                 star file
wasp2planet.ssc               solar system file
kstar.jpg                     texture file for a K star
jupiterpurple.jpg             texture file for the planet
readme_wasp2.txt              this file

You should be able to unzip the file in your extras folder,
and all the files will appear in a wasp2 folder.

The name of the star is "WASP-2"  and the name of its planet is
"b"


Astrophysical Notes for WASP-2

WASP-2 was one of the first transiting planetary systems discovered by
the "Wide angle search for transiting planets" and announced by Collier
Cameron et al. 2007, Monthly Notices of the Royal Astronomical Society,
Vol. 375, p.951. (see http://www.superwasp.org )

The star itself has a K1 spectral type, a radius of 0.807 times that of
the sun, estimated from its spectral type, and a mass of 0.803 times
the mass of the sun. From the transit (eclipses) of the planet in front
of the star, it has been deduced that the planetary radius is
1.043+/-0.029 times that of Jupiter, the orbital period is 2.152 days,
the orbital radius is 0.03033 astronomical units, and that the
inclination of the orbital plane to our line of sight to the star is
84.81+/-0.17 degrees (Southworth et al. 2010, Monthly Notices of the
Royal Astronomical Society, Vol. 408, p.1680). The planetary mass is
about 0.85 times that of Jupiter.

WASP-2b, as the planet is correctly known, is an example of a "hot
Jupiter". It orbits so close to its parent star that its "surface"
temperature (as it is a gas giant there would be no solid surface)
would be about 1000 Celsius. At these temperatures the planet
appearance may be dominated by clouds of titanium/vanadium
oxides. Because it orbits so close, the planet is probably tidally
locked so it presents the same face to the star at all times. This
would likely cause big temperature differences and high wind speeds in
the atmosphere.

The origin of "hot Jupiters" is becoming better understood. They must
have migrated from somewhere further out in the system and been dragged
in by the protoplanetary disc. However, that cannot be the whole story
for WASP-2. The orbital rotation axis is significantly misaligned with
the rotation axis of its star (there is an angle of about 150 degrees
between the orbital axis and a projection of the stellar rotation axis
onto the plane of the sky, deduced via the "Rossiter-Mclaughlin effect"
- Triaud et al. 2010, Astronomy and Astrophysics, Vol.524, A25). The
rotation period of the star is as yet unknown, but probably shorter
than 40 days, based on rotational broadening observed in its spectral
lines. This simulation assumes a rotation period of 34 days. You can
see that the planet almost orbits in retrograde fashion, indicating
that it is likely to have undergone significant dynamical encounters
with other planets during the course of its life.

The stellar and planetary radii, orbital period, epoch, radius and
inclination come from Southworth et al. (2010, MNRAS, 408, p.1680).

The orientation of the orbit is deduced from data presented in Triaud
et al. (2010, A&A, 524, A25).

The appearance of the planet is largely speculation, but the purple
colour may be expected from molecules likely to be in its atmosphere
at such temperatures.

Rob Jeffries, Keele University, 24 April, 2011.
