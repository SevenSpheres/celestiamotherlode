Copy moon_normal.jpg to your hires folder.

Add normalmap line to Moon in solarsys.ssc.
Remove bumpmap info by adding a # infront of those lines.



"Moon" "Sol/Earth"
{
	NormalMap "moon_normal.*"
	#BumpMap "moonbump.*"
	#BumpHeight 0.3
}