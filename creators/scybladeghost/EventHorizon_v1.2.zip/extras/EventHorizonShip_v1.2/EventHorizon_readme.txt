Event Horizon Ship for Celestia. 1.3  /   Feb,09 2005
By ScyBladeghost (John Victor Ivan)
http://www.bladeghost.homestead.com

The EVENT HORIZON is from the movie of the same name by Paramount Pictures 1997.
all rights reserved.

After creating the interior of this movie for a game level as a mod for aliens vs. predator 1 ge,
back in 2001,it felt incomplete so I decides to construct the exterior of the ship as well. having created both the interior and exterior I believe it would make a neat game, however I havent found a decent game platform for that,as I would like to include bump mapping.

 I have made an alpha test level of the EH in UT2004 with int/ext, as like the movie. even more work....we'll see how that goes.

The rights to Event Horizon movie belongs to paramount pictures, so this mesh I created is being
distrubuted FREE of any charge.

*****Installation:
     for celestia, 
just unzip  folder and place the EventHorizonShip folder into the extras or extras/addons folder in celestia, goto neptune and right click select satelites and select the EH and hit the 'G' key to goto the ship.

Hope you all like it.

enjoy, and Thanks for celestia.and everyone in the community for any and all help offered with celestia.  

Thanks!

 JV   (Scy)  :)

