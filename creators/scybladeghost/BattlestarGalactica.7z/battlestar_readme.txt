this addon goes in the extras folder in the addon folder, locate the star rigel and go to its satelites.

Have fun 
JV