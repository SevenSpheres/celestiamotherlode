
           LEXX    3DS  By Johnny Victor            (ScyBladeghost)

                                 
                     I made this model from scratch from a 
                     mickey mouse on a stick to this nicely
                     high detail model of the Lexx as I could.
                     for celestia 'its by the star agena.  I made
                     it all in 3ds so no textures are needed ,
                     however your welcome to do with it as you
                     please  I have built my own model to share
                     with all but its not my design or idea, it was just a
                     picture challange I made for myself and built
                     to enjoy and share.   'In celestia the lexx folder
                     goes in a 'extras folder in the root dir, if not there
                     create an extras folder and place the lexx folder
                     there, find the star agena and the lexx is a sattellite.
                     Remember to press the 'G key to go to the lexx after selecting it
                     and add a bookmark .  enjoy!  Hope you like it.

                     Happy modelling and celesting, may all your
                     games be fun and all your art be great!  :)       

                       JV     /_\..............October 21, 2005