Upbringer Universe
-------------------------------------
Version 1.0
Seth Pritchard
Designed using Celestia 1.5 and 1.6
Textures created or edited from Solar System textures in GIMP
http://upbringer.webs.com
seth.p@live.com


Installation
-------------------------------------
Simply drag and drop the add-on folder into your "extras" folder. All textures and models are self-contained.


History
-------------------------------------
Upbringer is a personal hard sci-fi project I started back in the 10th grade. The goal was to create a realistic view of space travel, exobiology, and astrophysics. Being an avid fan of Science Fiction, I was always let down at the (sometimes) appearent dissregard for the laws of nature (large windows on spacecraft, Spacecraft making sharp turns, FTL (with the possible exception of wormholes), anti-gravity, etc). So I was inspired to create a setting that was grounded by all the laws of physics yet still presented a stunning and captivating story. This project is to become the basis of a novel (possibly a series of novels), using Celestia to help define the setting of the story.

This add-on contains 10 fictional exoplanets orbiting the real star 82 Eridani. The 4th planet, Tiamat, is an Earth-like world covered in a vast and diverse alien ecosystem. It is also the site of relatively recent human colonization with relativistic rockets. The human societies on Tiamat are completely isolated from Earth, and must learn to adapt and survive on an alien world on their own. The biology on Tiamat is more advanced than that of Earth's, having had almost an additional 1.5 billion years of evolutionary potential over Earth-life.

Aknowledgements
-------------------------------------
I try to create as many original textures as I can, but a large portion of the textures used here were made by editing together various textures Celestia uses for the solar system. Others were made by using pieces of textures found on the internet. If you regoinze any textures here as one of your own, please contact me so I can give you aknowledgemnts. All textures here may be used for non-commercial purposes so long as their soruce is cited.