SDO - Solar Dynamics Observatory
Add-on for Celestia 1.6.0 by BrianJ

INSTALLATION
To install this add-on, simply extract the package to your Celestia/extras/ directory.

USE
To view the spacecraft, just use Celestia's ENTER-TYPE NAME-ENTER method to locate "SDO".
Timeline: 12 Feb 2010 - 12 Feb 2015

INFO
NASA's new Solar observatory, launched into an inclined geostationary orbit on 11th Feb 2010.

"The Solar Dynamics Observatory is the first mission to be launched for NASA's Living With a Star (LWS) Program, a program designed to understand the causes of solar variability and its impacts on Earth. SDO is designed to help us understand the Sun's influence on Earth and Near-Earth space by studying the solar atmosphere on small scales of space and time and in many wavelengths simultaneously."

SDO web page:
http://sdo.gsfc.nasa.gov/


ADD-ON NOTES
The spacecraft antennas are modelled as a separate component and will (aproximately) track the Earth.
