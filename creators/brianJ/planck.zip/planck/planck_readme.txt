# Planck Mission Timeline
# 
# Launch May 14, 2009 
# Nominal end of mission August, 2012 

INSTALLATION
To install this add-on, simply extract the package to your Celestia/extras/ directory.

USE
To view the spacecraft, just use Celestia's ENTER-TYPE NAME-ENTER method to locate Planck.
Make sure the date is set between 13:42:00 UTC, 14th May 2009 and 13:42:00 UTC, 3rd August 2012.

SCRIPT "planck_fov.cel"
The script will place the observer just in front of Planck's primary mirror, looking along the FOV line-of-sight.
To run the "planck_fov.cel" script, from the Celestia window tool-bar select "File" -> "Open Script" and navigate to  /extras/planck/planck_fov.cel.

ADD-ON INFO
Planck uses a "lissajous" orbit around the Sun-Earth L2 point. The .xyz trajectory file used in this add-on was extracted from JPL Horizons data, in an Earth-centered reference frame. Sample rate is every 3 hours. the .ssc file included will maintain Planck's solar panel pointed toward the Sun, while the spacecraft rotates at 1rpm as it scans the sky. This add-on also includes an aproximation of Planck's field of view 

DISABLING THE "FIELD OF VIEW" DISPLAY
To remove the Planck "field of view" display, simply delete the file:
Celestia/Extras/planck/planck_fov.ssc

MISSION INFO
More information about the mission can be found here:
http://www.esa.int/SPECIALS/Planck/index.html
http://sci.esa.int/science-e/www/area/index.cfm?fareaid=17
http://www.rssd.esa.int/index.php?project=planck

This add-on was created by BrianJ , June 9th 2009
You can contact me via the Celestia forum at http://www.shatters.net/forum/

With thanks to Selden, BrainDeadBob and ElChristou

The files in this add-on may be used and redistributed for non-commercial purposes only.