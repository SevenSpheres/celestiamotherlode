ENVISAT
Add-on for Celestia 1.6.0 by BrianJ

INSTALLATION
To install this add-on, simply extract the package to your Celestia/extras/ directory.

USE
To view the spacecraft, just use Celestia's ENTER-TYPE NAME-ENTER method to locate Envisat.
Available from 1 March 2002 02:00 UTC - 31 December 2013 24:00 UTC

INFO
Envisat is ESA's largest Earth observation satellite. Launched on an Ariane5 rocket from Kourou Spaceport on 2nd March 2002. Envisat uses a Sun-synchronous orbit - it's orbital plane remains the same relative to the Earth-Sun line, enabling Envisat to pass over the equator at the same local time(10.00AM) every orbit.

Envisat web page:
http://www.esa.int/SPECIALS/Operations/SEMOZY8L6VE_0.html

Info about Sun-sychronous orbits:
http://en.wikipedia.org/wiki/Sun-synchronous_orbit

ADD-ON NOTES
Add-on includes a sun-tracking solar panel for Envisat named "EnvisatSolarPanel".
To simulate the precession of Envisat's orbital plane, Envisat is configured to orbit an invisible object named "EnvisatOrbitFocus" placed at the centre of the Earth.
