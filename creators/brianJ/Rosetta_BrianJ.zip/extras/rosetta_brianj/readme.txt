ESA probe "Rosetta"
===================

by BrianJ (model & textures) and Chris Laurel (ssc & xyzv).
BodyFrame code by Elchristou.
SSC modified and add-on packaged by Ulrich Dickmann (Adirondack)
for the Celestia Motherlode (January 13, 2010) with permission
by BrianJ and Chris Laurel.

Requires Celestia 1.6.0 or later!


+----------------------------------------------------------------------+
| -> Deutsche Anleitung weiter unten (german instructions follow below)|
+----------------------------------------------------------------------+


Brian's model packaged with a trajectory for Rosetta and orbits for Steins,
Lutetia, and comet 67P/Churyumov-Gerasimenko (xyzv).
Start date: 2004-Mar-02 09:26:21 / End date: 2014-May-24 00:00
Tolerance: 1 km

This version will only work with Celestia 1.6.0+ because it uses xyzv files for the
trajectories of the spacecraft and the comet. It also uses multiple names for the
asteroids (e.g. Lutetia and 21 Lutetia), which only works in 1.6.0+.

The trajectories for Rosetta and Churyumov-Gerasimenko were generated from SPICE kernels
using the spice2xyzv tool. Chris could have simply included the SPICE kernels, but that
would increase the package size considerably, and the additional accuracy would only be
useful for spacecraft operations people. The included trajectories should be accurate
to within 1km. The Keplerian elements for Steins and Lutetia were produced by HORIZONS.
They are the osculating elements for the time of the Rosetta fly-bys of these objects.
Chris verified that the time of closest approach to Steins is dead on.

Note that this add-on covers the Rosetta mission only up until the approach to the comet.
Chris wasn't able to find the SPICE kernel for the comet orbit phase of the mission, 
though the readme at NAIF suggests that it exists already.


Content of the ZIP-file:
------------------------
SolarSystemCatalog for Rosetta by Chris Laurel (rosetta.ssc),
info file by Ulrich Dickmann (readme.txt),
trajectory files by Chris Laurel (67p.xyzv and rosetta.xyzv),
Rosetta model by BrianJ (rosetta.3ds),
and the texture files by BrianJ (philae.jpg, rosetta_foil.jpg, rosetta_solpanel.jpg).


Installation:
-------------

When you unzip this package using your zip program (e.g. WinZip), click on "Extract"
and select the main folder of Celestia (...\Celestia\) as the target directory.
Make sure that you activate the option to "Use subfolders" (or similar option) while un-packing.
All (or the selected) files will be copied into the correct Celestia extras-subfolders.


How to find Rosetta:
--------------------
Run Celestia and press <ENTER>, type 'Rosetta' and press <ENTER> again.
Press <G> to goto Rosetta. Please note that Rosetta will only appear within the time period of
2004-Mar-02 09:26:21 until 2014-May-24 00:00.

Have fun,
Adirondack



---------------------------------------------------------------------



Deutsch (German):
=================

Brian's Modell inkl. der Flugbahn f�r Rosetta und den Bahndaten f�r Steins,
Lutetia und den Kometen 67P/Churyumov-Gerasimenko (xyzv).
Startdatum: 2. M�rz 2004 09:26:21 / Enddatum: 24. Mai 2014 00:00
Toleranz: 1 km

Dieses Add-On funktioniert nur mit Celestia 1.6.0+, da es XYZV-Dateien f�r die Flugbahnen
der Raumsonde und den KOmeten verwendet. Au�erdem werden mehrere Namen f�r die Asteroiden
verwendet, was nur mit Celestia 1.6.0+ funktioniert.
Die Flugbahnen f�r Rosetta und Churyumov-Gerasimenko wurden aus den sog. SPICE-Kernels
der NAIF (http://naif.jpl.nasa.gov/naif/index.html) mittels des Konvertierungstools
spiece2xyzv generiert. Chris h�tte auch schlicht die SPICE Kernels selbst intergrieren
k�nnen, aber das h�tte den Datenumfang erheblich gesteigert und die zus�tzliche Genauig-
keit w�re nur f�r Mitarbeiter der Weltraumbeh�rden von Interesse gewesen, die tats�chlich
die Raumsonde steuern. Die im Add-On enthaltenen Flugbahnen d�rften nur eine Abweichungs-
toleranz von 1 km besitzen. Die Kepler-Elemente f�r Steins und Lutetia wurden ermittelt
�ber HORIZONS (http://ssd.jpl.nasa.gov/?horizons).

Beachten Sie, dass dieses Add-On nur die Rosetta-Mission bis zur Ann�herung an den
Kometen abdeckt. Chris konnte leider keine SPICE Kernels f�r die Umrundung des Kometen
durch Rosetta finden, obwohl die NAIF diese angeblich vorh�lt.


Inhalt des ZIP-Archivs:
-----------------------
SolarSystemCatalog f�r Rosetta von Chris Laurel (rosetta.ssc),
Infodatei von Ulrich Dickmann (readme.txt),
Bahndatendateien von Chris Laurel (67p.xyzv und rosetta.xyzv),
Rosetta-Modell von BrianJ (rosetta.3ds),
und die Texturen von BrianJ (philae.jpg, rosetta_foil.jpg, rosetta_solpanel.jpg).


Installation:
-------------

Klicken Sie in Ihrem Entpackprogramm (z.B. WinZip) auf "Extrahiere" und w�hlen das
Hauptverzeichnis von Celestia (...\Celestia\) als Ziel aus. Aktivieren Sie die Option
"Pfadangaben verwenden" (in anderen Entpackprogrammen hei�t diese  Option �hnlich)
und starten den Entpackvorgang.
Alle (oder die von Ihnen ausgew�hlten) Dateien werden dann in die richtigen Unter-
verzeichnisse in ...Celestia\extras\ entpackt.


Wie man Rosetta findet:
-----------------------
Run Celestia and press <ENTER>, type 'Rosetta' and press <ENTER> again.
Press <G> to goto Rosetta. Please note that Rosetta will only appear within the time period of
2004-Mar-02 09:26:21 until 2014-May-24 00:00.

