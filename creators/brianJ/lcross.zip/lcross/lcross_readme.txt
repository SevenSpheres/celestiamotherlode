LCROSS add-on for Celestia 1.5.1
by BrianJ 29/06/09

INSTALLATION
To install this add-on, simply extract the package to your Celestia/extras/ folder.


USE
To view the spacecraft, just use Celestia's ENTER-TYPE NAME-ENTER method.

Spacecraft Names		Available

LCROSS(with Centaur)	18 June 2009, 22:16:54 UTC      - 09 October 2009 01:59:00 UTC
Centaur(with LCROSS)	18 June 2009, 22:16:54 UTC      - 09 October 2009 01:59:00 UTC

LCROSS(free flight)		09 October 2009 01:59:00 UTC -  09 October 2009 11:34:55 UTC
Centaur(free flight)		09 October 2009 01:59:00 UTC -  09 October 2009 11:34:42 UTC

Centaur(ejecta plume)		09 October 2009 11:34:42 UTC - 09 October 2009 11:36:42 UTC


MISSION TIMELINE
Launch aboard AtlasV (with LRO) 18 June 2009, 21:32:01 UTC
Lunar gravity assist begins 23 June 2009, 09:00 UTC (aprox)
LCROSS - Centaur seperation 09 October 2009, 02:00:00 UTC (aprox)
LCROSS 12m/s braking maneuver 09 October 2009, 03:00:00 UTC (aprox)
Centaur impacts lunar surface, South Pole 09 October 2009, 11:30:00 UTC (+/- 30mins) 


SCRIPTS
Three .celx scripts are included.
From the Celestia window tool-bar select "File" -> "Open Script" and navigate to  /extras/lcross

"expand_ejecta_plume.celx"
This script will cause the Centaur(ejecta plume) to expand from 0km->6km->0km during 120secs after Centaur impact.

"view_impact_from_hawaii.celx"
This script will place you on top of Mauna Kea, Hawaii, 30secs before Centaur impact. View tracks the impact site, field of view 1/8 degree.
The script also causes the Centaur(ejecta plume) to expand from 0km -> 6km ->0km height during 120secs.

"view_impact_from_lcross.celx"
This script will place you beside the LCROSS spacecraft, 30secs before Centaur impact. View tracks the impact site, field of view 15 degrees.
The script also causes the Centaur(ejecta plume) to expand from 0km -> 6km -> 0km height during 120secs, with a brief impact flash at the start.


INFO
LCROSS .xyz trajectory from JPL Horizons (Pre-launch nominal trajectory - ends 530km above Lunar surface)
Centaur(free flight) .xyz trajectory created in Orbiter Spaceflight Simulator

More info about the mission:
http://lcross.arc.nasa.gov/