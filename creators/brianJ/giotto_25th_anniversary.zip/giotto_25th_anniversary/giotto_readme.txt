GIOTTO
Add-on for Celestia 1.6.0 by BrianJ


WHAT'S IN THIS ADD-ON?
Giotto spacecraft model and associated .ssc and .xyzv trajectory files. 
An .ssc file to modify comet 1P/Halley and add comet 26P/Grigg-Skjellerup.


INSTALLATION
To install this add-on, simply extract the package to your Celestia/extras/ directory.


USE
To view the spacecraft, just use Celestia's ENTER-TYPE NAME-ENTER method to locate Giotto.
Available from 1985 Jul 03 14:23 UTC -- 2016  March 03 12:48 UTC


INFO
Launched: Kourou CSG, 1985 Jul 02, on an Ariane1 launcher. Heliocentric orbit injection occured on 1986 Jul 03.
Europe's first deep space mission, first close-up images of a comet nucleus including Comet Halley, first spacecraft to encounter two comets and first deep space mission to change orbit by returning to Earth for a gravity assist.


TIMELINE		Date		Alt.
Launch			1985 Jul 02
Comet Halley flyby		1986 Mar 14	~596km
Earth flyby 1		1990 Jul 02
Comet Grigg-Skjellerup flyby	1992 Jul 10	~190km
Earth flyby 2		1999 Jul 01


LINKS
http://sci.esa.int/science-e/www/area/index.cfm?fareaid=15
http://nssdc.gsfc.nasa.gov/planetary/giotto.html
http://en.wikipedia.org/wiki/Giotto_mission
http://multimedia.esa.int/Videos/1986/01/Giotto



ADD-ON NOTES
The trajectory data for this add-on was reconstructed using Orbiter Spaceflight Simulator. It includes the 1999 Earth flyby trajectory data from JPL Horizons.

The spacecraft model consists of 2 parts - the main body (spin stablized at 15rpm) and the HGA assembly (de-spun, Earth tracking around Z axis).

The included "comets.ssc" contains data for the orbits of 1P/Halley and 26P/Grigg-Skjellerup at the time of their respective flybys.