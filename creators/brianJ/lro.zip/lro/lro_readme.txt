LRO add-on for Celestia 1.6.0
by BrianJ

INSTALLATION
Unzip into your Celestia/extras/ folder

USE
Select "LRO" using Celestia's ENTER-TYPE NAME-ENTER function.
LRO is available from 28 June 2009 until 28 June 2011.

ADD-ON NOTES
The add-on shows LRO in an aproximation of its science orbit.

Every 6 months, LRO will perform a 180 deg yaw to keep the solar-panel on the sunward side of the spacecraft.

The LRO solar panel is a seprate spacecraft component object and will track the Sun.

LRO will maintain a nadir pointing attitude.