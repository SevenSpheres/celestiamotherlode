
====--ABOUT--====

This is a repackaging of Bob Hegwood's Tour of Venus (V3.01, August 12, 2008).

The original ReadMe file can be found in this same file, renamed ReadMe.orig.

The purpose of this repackaging was to make it simpler to extract and install under non-Windows systems.  The trouble with the original zip file was that, under non-Windows systems, the paths were written into the filenames when read or extracted from the zip file.  I've gone through the files, corrected the filenames and put them into the correct paths.  I've also gotten rid of the \scripts folder, as it seemed superfluous... feel free to create it again if you'd like.



====--INSTALLATION--====

Just extract this file to your Celestia folder.  In Ubuntu linux, it's installed under:

/usr/share/celestia

From what I understand, it's that way for a lot of other linux distros as well.  Under Windows, it's under:

C:\Program Files\Celestia

For other operating systems... you're on your own, sorry.  I have no idea where it'd be installed.


Note:  Chances are, you're not running as a super-user, which you need to be to install to the /usr/share/celestia directory... or any directory not within your /home directory, for that matter.

If you already know how to super-user your way around the system, awesome.  If you don't, then here are a couple methods:

Open a terminal (Under Applications > Accessories > Terminal).  Navigate to the directory that you downloaded this file to (Popular defaults are ~/Downloads, or ~/Desktop).  Technically you don't need to, but I like to, just to double-check the file exists.

After you've done that, the quick way to extract it is by typing:

sudo unzip -d /usr/share/celestia ~/Desktop/venustour-nix.zip

You will be prompted for your password, so go ahead and type it.  Assuming you're in the sudoers file (you should be, if not, talk to your administrator or log in to that account), everything will work just fine.

Another method (in Ubuntu, or any OS with File-Roller installed) is to type:

sudo file-roller

Once the program starts, just open the archive and extract it to its proper directory (/usr/share/celestia by default in Ubuntu).


====--FILES--====

Following is a list of every file in the archive.  Pretty much everything without an extension is a directory.

.:
extras
ReadMe.orig
ReadMe.txt
venustour.cel

./extras:
venusexpress
venus_tour

./extras/venusexpress:
data
models
textures
venusexpress.ssc

./extras/venusexpress/data:
venusexpress.xyz

./extras/venusexpress/models:
label.3ds
venusexpress.3ds

./extras/venusexpress/textures:
medres

./extras/venusexpress/textures/medres:
blckgrey.jpg
bronze2.jpg
darkgrey.jpg
gold.jpg
litegrey.jpg
offwite.jpg
screw.jpg
stanless.jpg
tiles2.jpg
tiles.jpg
vebdetal.jpg
ve_foil2.jpg
ve_plate.jpg
vewplate.jpg

./extras/venus_tour:
textures
venus_tour.ssc

./extras/venus_tour/textures:
medres

./extras/venus_tour/textures/medres:
venusnormal_tour.jpg
venussurface_tour.jpg
venus_tour.jpg


====--ETC./CREDITS--====

Just to reiterate, I did none of the actual work involved with this tour, or any of the models or textures, etc.  I simply repackaged it.  To find contact information for Bob Hegwood, take a look at the ReadMe.orig file.  There are also other credits and various bits of information of note in there, so give it a read.

If you feel like contacting me for whatever reason, I can be reached at:

x.seeks@gmail.com

