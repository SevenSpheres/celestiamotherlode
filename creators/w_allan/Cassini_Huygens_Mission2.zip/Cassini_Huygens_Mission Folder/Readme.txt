This script is an update of a previous script re-written to utilize Jack Higgins' (aka Jestr's) models of Cassini and Huygens including the models of Huygens as it descends to Titan. It works well on an iMac G4 running OSX 10.2.8 with Celestia 1.3.2 provided the celestia.cfg file is edited (see the accompanying document "Cassini_Update.rtf") to use Jestr's *.ssc files. 

I originally wrote this script for my sister's fifth grade class. The intent was to show what it would look like to travel along with Cassini/Huygens and to demonstrate how long and difficult the mission was. For instance, it took over 7 years to reach Saturn, 3 of which were spent getting out of the inner solar system. This time was needed in order to use gravitational assists from Venus (twice) and Earth (once) to propel the spacecraft to the outer solar system. The script shows both close-ups of the planets Cassini/Huygens encountered and the trajectory followed. It also shows the descent of Huygens to Titan thanks to Jestr and Toti. 

It is divided into 3 parts:
Part 1 - CasHuy1.cel -Launch to 1999 - encounters with Venus and Earth (6 min.)
Part 2 - CasHuy2.cel -Trajectory view to show gravitational assists to Jupiter (3 min.)
Part 3 - CasHuy3.cel -Arrival at Saturn with close-up of rings and Huygens descent to Titan (12 min.)

-produced by "Maine" aka Walter Allan (wallan@maine.rr.com)
	July 10, 2005