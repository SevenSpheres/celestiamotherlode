An add-on modelling a scene from Tintin's "Explorers on the Moon".
Tx to ElChristou who kindly provided the rocket model and the model + texture for Adonis. Selden and many others provided welcome encouragements and advice for my first project


Place the entire haddock_tintin_rocket folder in your "Extras" directory by unzipping the folder.

lukr