32k Earth Texture (VT) for Celestia
-----------------------------------

Nightlights
===========

Fileformat: DDS
Changes to original data:
  Added 1800 black lines at the top, and 3600 at the bottom
  Rescaled to 32768x16384, etc.
  Multiplied values in each tile with 2.5, then multiplied with the color #f0edcf
  
Raw Data Files:
  2000_human_settlements_version1.tar
 Downloaded from:
  http://dmsp.ngdc.noaa.gov/html/download_world_change_pair.html
