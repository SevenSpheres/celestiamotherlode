32k Earth Texture (VT) for Celestia
-----------------------------------

Specmap
=======

Fileformat: DDS
Changes to original data:
  Mapped index 0 to white, everything else to black,
  then rescaled to 32768x16384
  
Raw Data Files:
  landcover.E.21600x21600.gz
  landcover.W.21600x21600.gz
 Downloaded from:
  ftp://mitch.gsfc.nasa.gov/pub/stockli/bluemarble/

Credits for data files:
  -------------------------------------------------------------------------------
  Author: 
    Reto St�ckli, NASA/Goddard Space Flight Center, stockli@cyberlink.ch
    
    Address of correspondance:
    Reto St�ckli                    Phone:  +41 (0)1 271 8463
    NASA GSFC/ SSAI                 Email:  stockli@cyberlink.ch
    Landenbergstr. 16a              Web:    http://visibleearth.nasa.gov
    8037 Z�rich Switzerland                 http://earthobservatory.nasa.gov

  Supervisors: 
    Fritz Hasler and David Herring, NASA/Goddard Space Flight Center
  
  Funding:
    This project was realized under the SSAI subcontract 2101-01-027 (NAS5-01070)
  -------------------------------------------------------------------------------

