32k Earth Texture (VT) for Celestia
-----------------------------------

Normalmap
=========

Fileformat: JPG
Problems:  
  DDS files would offer better performance, but produce ugly artifacts.
  PNG files would offer even better quality, but are to big.
  Using 16-Bit colordepth produces artifacts, so use 32 Bit!
Changes to original data:
  Processed each tile with modified Chris Laurel's nm16 tool:
    Downloaded from http://www.shatters.net/~claurel/normalmap/
    Replaced line 36 (in readS16) by:
        return ((((unsigned int) c[0] << 8) | (unsigned int) c[1])) * (1.0f / 65535.0f);
    Processed level5 using bumpheight 160, level 4 with 80, ..., level 0 with 5
    converted to JPG using "convert -quality 75 -sampling-factor 1x1"
  
Raw Data Files:
  topo.bathymetry.W.21600x21600.gz
  topo.bathymetry.E.21600x21600.gz
 Downloaded from:
  ftp://mitch.gsfc.nasa.gov/pub/stockli/bluemarble/

Credits for data files:
  -------------------------------------------------------------------------------
  Author: 
    Reto St�ckli, NASA/Goddard Space Flight Center, stockli@cyberlink.ch
    
    Address of correspondance:
    Reto St�ckli                    Phone:  +41 (0)1 271 8463
    NASA GSFC/ SSAI                 Email:  stockli@cyberlink.ch
    Landenbergstr. 16a              Web:    http://visibleearth.nasa.gov
    8037 Z�rich Switzerland                 http://earthobservatory.nasa.gov

  Supervisors: 
    Fritz Hasler and David Herring, NASA/Goddard Space Flight Center
  
  Funding:
    This project was realized under the SSAI subcontract 2101-01-027 (NAS5-01070)
  -------------------------------------------------------------------------------

