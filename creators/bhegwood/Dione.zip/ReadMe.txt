The original texture came from resources which can be located in Doctor
Schrempp's texture tools tutorial which can be located on the Celestial
Matters Forum at:
http://forum.celestialmatters.org/viewtopic.php?t=224

The image from which the final texture came from can be located at the
NASA Cassini FTP website which is located at:
http://pdsimg.jpl.nasa.gov/data/cassini/cassini_orbiter/coiss_3003/data/images/

I have merely followed Dr. Schrempp's tutorials in order to create this 
very pleasing (at least to me) final texture for use in Celestia.

Many thanks to Dr. Schrempp for making these tutorials available for us
Brain-Dead users.

I would also like to thank Gradius Fanatic for all of his help with these
textures. He provided the fictional data which is used within the overall
image in order to complete the final textures. He also finally taught me
how to use the Gimp in order to modify a texture, and I am deeply grateful
for his help here. ;-) 

If you have any problems with this add-on, I am Brain-Dead Bob, and I can
be reached at bhegwood@woh.rr.com.

I know that you can use the modify directive, and that you can create
this add-on as an item in the extras folder within Celestia, but I simply
do not like doing that. I want this installation of Dione to be permanent
on my machine, so I have done the following to install the texture:

Before you start, please make backup copies of your solarsys.ssc file,
your current Dione texture file, and your current Dione Limit of Knowledge
file if you have one.

Next, replace the SSC file data for Dione in your solarsys.ssc file with 
the following code:

# ----------------------------------------------------------------------
"Dione" "Sol/Saturn"
{
	Texture				"Dione.jpg"
	Radius				559

	CustomOrbit			"dione"
	EllipticalOrbit
	{
	Period				2.736915
	SemiMajorAxis			377400
	Eccentricity			0.0022
	Inclination			0.02
	MeanAnomaly			310
	}

	UniformRotation
	{
	Inclination			0.0
	MeridianAngle			317.1
	}

	Albedo				0.7
}

AltSurface "Limit of Knowledge" "Sol/Saturn/Dione"
{
	Texture				"DioneLOK.jpg"
}
# ----------------------------------------------------------------------

Finally, copy the enclosed textures, Dione.jpg and DioneLOK.jpg to your
Celestia\textures\medres directory.