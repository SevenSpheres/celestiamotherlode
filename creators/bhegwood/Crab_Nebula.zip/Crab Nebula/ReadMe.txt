Installation Instructions
-------------------------
Unzip the contents of this file into your extras folder.

The M1 Star Catalog uses Hipparcos numbers from 333340 to 333381. In order to avoid conflict with other star definition addons, and to have a correct and realistic view of the Nebula's nearby stars, please check your other star catalog numbers for duplicates (any Hipparcos number can work if not already used).

Enjoy the Crab Nebula !

Killeen (Besancon, France)

Please note that I (Bob Hegwood) have modified Killeen's original model
so that it is displayed as a true 3d image now. Simply extract the contents of this add-on 
to your extras directory in order to install this model. If you have Killeen's original
2d Billboard model already installed on your system, please remove it before you add this 
version of the Crab Nebula.

To view in Celestia, simply use the ENTER-TYPE NAME-ENTER method to get to the "Crab Nebula."

Thanks, Brain-Dead Bob
bhegwood@woh.rr.com