##################################################
# Revised Celestia Pyramids Add-on by Brain-Dead #
# Bob Hegwood. 16 September 2008.                #
#                                                #
# Please note that this add-on is a revision to  #
# Dr. Diane Neisius' original Pyramid add-on     #
# which was created on 10/7 2006.                #
#                                                #
# The original model with revisions is used here #
# with Diane's (aka Medusa's) permission.        #
##################################################

To install, simply drop the unzipped Pyramids folder into your
Celestia\extras folder. If you have a high-resolution virtual
texture package installed, you may also wish to copy the 
optional textures included into levels 6 through 9 of your current
high-resolution texture installation.

This little add-on places the three great pyramids at the proper
locations on the Earth in Egypt. Please note that the sizes and
locations for these pyramids has been altered in order to get the models
correctly aligned on the world map used within Celestia. See the SSC
file in order to adjust these parameters if necessary in order to align
correctly on your system.

Please also note that - if you are already using a Virtual Texture
package to display your Earth, I have also included high-resolution 
textures for the land area surrounding the Pyramids in levels 6
through 9. These are optional, and are not needed in order to display
the Pyramids in Celestia. They do offer a more pleasing view when
installed however. See enclosed screen shot. If you don't need these
textures, simply delete the OptionalHiResTiles folder from this add-on.

These textures are revised versions of kinderino's DDS textures which
can be found on the motherlode at:

http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=439

I have simply revised these to adjust the lighting, and to reformat and re-size
the textures to 1024 x 1024 PNG files. If you use these textures in your 
installation, please note that they may not be compatible with your current
texture package if it is in a different format, or if they use different tile
sizes.

Thanks, Brain-Dead Bob Hegwood

Visit my web site at: http://home.woh.rr.com/bhegwood/