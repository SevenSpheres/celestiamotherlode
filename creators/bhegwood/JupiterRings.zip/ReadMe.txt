*************************************************************************************
* JupiterRings.png - Version 2.0 - For use with Celestia 1.4.1 or later.            *
*                                                                                   *
* This add-on supplies ONLY the visible portion of Jupiter's Rings. To view the     * 
* ENTIRE ring system, I would suggest downloading John van Vliet's complete         *
* Jupiter Rings package from the Motherlode.                                        *
*                                                                                   *
* To perform the installation, simply follow the instructions below.                *
*                                                                                   *
* 1. First, simply unzip the JupiterRings.png, into your                            *
*    Program Files\Celestia\textures\medres directory.                              * 
*                                                                                   *
* 2. Next, simply copy the enclosed JupiterRings.ssc file to your Celestia\extras   *
*    directory.                                                                     *
*                                                                                   *
* Credits: ___________________________________________________________________      *
*                                                                                   *
* JupiterRings.png - Author: Praesepe                                               *
*                    Revisions: Bob Hegwood - Resized to 1024 x 32, smoothed a wee  *
*                               bit, and played with brightness/contrast.           *   
*          ___________________________________________________________________      *
*                                                                                   *
*                                                                                   *
* Questions or comments? Send them to me at the following email address:            *
*                                                                                   *
* bhegwood@woh.rr.com                                                               *
*                                                                                   *
* Visit my Celestia web page at: http://home.woh.rr.com/bhegwood/                   *
*                                                                                   *
*************************************************************************************