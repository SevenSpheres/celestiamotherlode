Tour of Venus V3.01 By Bob Hegwood on 12 August 2008.

Please unzip all directories and files to your \extras\ directory in your Celestia installation.

When you unzip this package using your zip program (e.g. WinZip), click on "Extract"
and select the main folder of Celestia (...\Celestia\) as the target directory.
Make sure that you activate the option to "Use subfolders" (or similar option) while un-packing.
All (or the selected) files will be copied into the correct Celestia subfolder(s).

You will find the cel-script in the \scripts\ directory.
The new textures of Venus will reside in the directory \extras\venus_tour\ and its sub-directories.
The VenusExpress files will reside in the directory \extras\venusexpress\ and its sub-directories.

You DO NOT have to change anything in your basic installation!

If you want to get rid of the Venus-Tour simply delete the following folders in extras:
venus_tour\
venusexpress\

To delete the script itself, just delete the venoustour.cel file in your scripts directory.
CAUTION: Do not delete the entire \scripts\ folder! Only the file 'venustour.cel' !

Please note that, with John Van Vliet's permission, I have used his 4k Venus textures in order to produce
this tour. I have slightly modified John's original surface texture simply to add a very slight bit of color
in order to depict the locations on Venus as accurately as I can.

Please note that this tour was designed specifically for use with John's textures. It will probably work
okay with other Venus textures, but John's depict the locations I'm using far better than any other textures
at this point. You can find more of John's add-ons at the Motherlode by visiting this link:

http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=10

Please also note that the Venus Express model is used here with Jestr's permission. Thanks very much my
friend!

Also, many thanks to Ulrich "Adirondack" Dickmann for all of his encouragement, and all of the things he
does every day in order to keep the Motherlode up and running. Some of us really DO appreciate this service,
Ulrich! Thanks very much also to Ulrich for explaining how to package this add-on! I really AM Brain-Dead.

Take care, Brain-Dead Bob Hegwood

Visit my NEW web site at: http://home.woh.rr.com/bhegwood/ or send e-mail comments to bhegwood@woh.rr.com.