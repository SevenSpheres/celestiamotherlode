Virtual Textures for Dummies Read Me file...

In order to view this guide, you need to have the free Adobe Reader
software installed on your machine.

This software can be downloaded freely from:
http://get.adobe.com/reader/

Simply install the Adobe Reader software if you need to, and then open
the vtForDummys.pdf file using the Adobe Reader.

Thanks, Brain-Dead Bob