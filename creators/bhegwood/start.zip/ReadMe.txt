Please just copy the included start.cel file to your main Celestia directory.

Please note that you may wish to make a backup copy of your current start.cel
file before copying the enclosed file to the main Celestia directory. This is
just in case you don't like the way in which MY start CEL works.

Thanks, Bob