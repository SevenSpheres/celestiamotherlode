*************************************************************************************
* Comet.zip - Version 1.1 - For use with Celestia 1.4.0 Pre5 or later.              *
*                                                                                   *
* This zip file contains an alternative texture for use in defining and viewing     *
* your comets.	Please note that this version of the comet texture is based on Paul  *
* Roberts' original texture, which has been heavily modified to remove seams and    *
* to add some more detail.											    *
*************************************************************************************

Detailed Installation Intructions:

1) Simply copy the enclosed comet.jpg file to your
   C:\Program Files\Celestia\textures\medres directory.
2) EDIT your SSC files which describe any comets you may have on your system so that
   the texture statements point to the new texture as shown:
   
   Texture "comet.jpg" 
   
*************************************************************************************
*          ___________________________________________________________________      *
*                                                                                   *
*                                                                                   *
* Questions or comments? Send them to me at the following email address:            *
*                                                                                   *
* bhegwood@woh.rr.com                                                               *
*                                                                                   *
* Visit my Celestia web page at: http://home.woh.rr.com/bhegwood/                   *
*                                                                                   *
*************************************************************************************