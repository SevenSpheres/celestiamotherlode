This file simply contains four different asteroid textures for use with various
of the asteroids within Celestia. I have simply taken the original Celestia
asteroid texture, and modified it a bit to accommodate my needs. Depending on
which asteroid I'm trying to modify at the moment, I'll need one of these 
textures as described below. I have found other packages with varying asteroid
brightnesses and/or colors, but the ones I have found involve too many defects
for normal usage. In other words, if you offset the images, you can see where
the edges do not line up correctly, and you can also see lines where the two
sides of the textures meet. I created this very simple file to overcome these
problems. You already KNOW that I ain't that bright, but even *I* can create a 
texture where the edges are aligned correctly.

This file contains:

asteroid.jpg		-	The original Celestia asteroid texture.
asteroidbright.jpg	-	A brighter asteroid texture.
asteroiddark.jpg	-	A darker asteroid texture.
asteroidmedium.jpg	-	A medium-brightness asteroid texture.

Any problems? Send E-mail me to me at: bhegwood@woh.rr.com