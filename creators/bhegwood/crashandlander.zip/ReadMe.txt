Brain-Dead Bob's Spacecraft Landing and Crash Sites on the surface of other planets and moons.
These add-ons accurately depict the locations of real Lunar, Venusian and Martian landing and
crash sites.

First of all, let me just publicly thank Martin Charest (Cham) for his spectacular work
on the location and identification of most of these spacecraft and crash sites. Martin
has - as accurately as possible - set the coordinates for almost all of the objects contained 
within this add-on. He is also responsible for all of the original 3ds flag models which were 
originally used within. I have modified all of the original 3ds files in order to use simple
ASCII cmod files so that anyone can change the textures used very easily. I have also created
my own crash site models which were based upon Martin's original 3ds files.
Your work here is VERY much appreciated Martin.

Next, I have to give proper credit where that credit is due for other parts of this add-on.
Jack Higgins is the original author of all of the Lunar spacecraft which are depicted with
3ds models. The only thing I have done to them is to insure compatibility with all operating
systems (I hope!) Although we haven't heard from Jack in a while, his web site is still up
and running as of today (20 June 2008) and I downloaded all Lunar models from Jack's site. 

To install these add-ons, simply extract the entire file to a temporary directory somewhere on
your machine, and then copy or move each folder to Celestia\extras, or to an extras sub-directory
named according to your own preferences. Each of the folders included in this zip file is
self-contained, meaning that it can be placed anywhere in the Celestia\extras directory and still
operate as it should. This add-on was created on a Windows Vista system, but should be compatible
with all other systems as far as I am able to determine this situation right now. 

Thanks, Brain-Dead Bob

E-Mail:   bhegwood@woh.rr.com
Website:  http://home.woh.rr.com/bhegwood/