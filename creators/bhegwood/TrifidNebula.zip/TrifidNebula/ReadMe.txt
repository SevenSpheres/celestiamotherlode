This add-on was originally created by Killen in Besancon, France.
I (and Gradius_Fanatic) have modified the 3ds file so that the
add-on now uses a fully-3D representation of the M20 planetary
nebula via a cmod file.

To install, simply unzip the contents of this file into your extras
folder.

Note from Killen concerning the STC file used to represent a number
of stars in and around this planetary nebula:

"The M20 & M21 Star Catalogs use Hipparcos numbers from 333500 to 333684.
In order to avoid conflict with other star definition addons, and have a
correct and realistic view of the Nebula's nearby stars, please check
your other star catalog numbers for duplicates. Any Hipparcos number can
work if not already used. Enjoy the Trifid Nebula !
Killeen (Besancon, France)"

All modifications to this add-on by Brain-Dead Bob Hegwood and
Gradius_Fanatic on 8 Feb 2009.