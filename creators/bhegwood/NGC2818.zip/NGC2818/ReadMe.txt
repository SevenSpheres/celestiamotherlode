This is a fully-3D representation of the planetary nebula, NGC 2818.
To install, extract this add-on to your Celestia extras directory.
To locate within Celestia, simply use the ENTER-Type Name-ENTER method
to locate NGC 2818. The central star can also be located using the same
method to find "NGC 2818 Central."
 
This add-on is as accurate as I can make it, and I'd like to give many thanks to 
Selden E. Ball, Jr. for his help with the angle and axis measurements.
The image of the planetary nebula comes from the Astronomy Picture of the Day web site which is located at:
http://apod.nasa.gov/apod/ap090122.html

The following explanatory text also comes directly from this web site:
"NGC 2818 is a beautiful planetary nebula, the gaseous shroud of a dying sun-like star. It could well offer a glimpse of the future that awaits our own Sun after spending another 5 billion years or so steadily using up hydrogen at its core, and then finally helium, as fuel for nuclear fusion. Curiously, NGC 2818 seems to lie within an open star cluster, NGC 2818A, that is some 10,000 light-years distant toward the southern constellation Pyxis (the Compass). At the distance of the star cluster, the nebula would be about 4 light-years across. But accurate velocity measurements show that the nebula's own velocity is very different from the cluster's member stars. The result is strong evidence that NGC 2818 is only by chance found along the line of sight to the star cluster and so may not share the cluster's distance or age. The Hubble image is a composite of exposures through narrow-band filters, presenting emission from nitrogen, hydrogen, and oxygen atoms in the nebula as red, green, and blue hues."

Thanks, Brain-Dead Bob 