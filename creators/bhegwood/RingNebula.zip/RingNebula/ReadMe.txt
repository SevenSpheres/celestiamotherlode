 Install instructions
++++++++++++++++++++++

Unzip into your extras directory.

by AstroBoy

Please note that I (Bob Hegwood) have modified AstroBoy's original model
so that it is displayed as a true 3d image now. Simply extract the contents of this add-on 
to your extras directory in order to install this model. If you have Killeen's original
2d Billboard model already installed on your system, please remove it before you add this 
version of the Ring Nebula.

To view in Celestia, simply use the ENTER-TYPE NAME-ENTER method to get to the "Ring Nebula."

Thanks, Brain-Dead Bob
bhegwood@woh.rr.com