Please note I have modified my Mars clouds definitions because of the information I found at 
http://www.space.com/scienceastronomy/060828_mars_clouds.html

The actual MarsClouds.png file was originally created by John Van Vliet, and I have simply
modified it to suit my own tastes. Many thanks, John! John also wishes me to remind you that
these clouds are fictitious, but please be aware that I have tried to insure accuracy by
reviewing real Mars cloud images, and by relying on scientific observations made by the
current bevy of Mars orbiters.

To install this texture, extract this zip file to any temporary directory on your system,
then copy the MarsClouds.png file to your Celestia\textures\medres directory.
Next, open up the MarsClouds.ssc file included in this package using your favorite text
editor, and then copy the code in its entirety.
Finally, open your solarsys.ssc file and replace ONLY the atmosphere portion of your Mars
definition.
NOTE: This version has been modified to remove the MieScaleHeight parameters. These caused
      a deformity when rendering the clouds using version 1.5.1 final, so I have now revised
      the SSC code included herein.   

Thanks, Brain-Dead Bob

Note: If you have any problems with this add-on, or if you wish to report some error, please
just send an e-mail to me at: bhegwood@woh.rr.com

You already know where my web site is, but just in case you have forgotten it, go to:
http://home.woh.rr.com/bhegwood/