Virtual Textures for Dummies Read Me file...

To install this facility, please just extract this zip file to 
your Celestia\extras directory.

In order to view the associated guide, you need to have the free 
Adobe Reader software installed on your machine.

Simply install the Adobe Reader software if you need to, and then open
the vtForDummys.pdf file using the Adobe Reader.
This software can be downloaded freely from:
http://get.adobe.com/reader/

Thanks, Brain-Dead Bob