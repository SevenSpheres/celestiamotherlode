*************************************************************************************
*                                                                                   *
*                    MarsTour.cel V2.0 - Last Revision 5-23-04                      *            *                                                                                   *
*                                                                                   *
* The Mars script requires that you have the mars_locs2.ssc file installed in your  *
* Program Files\Celestia\extras directory. This file has also been included in this *
* package for your convenience. Simply unzip the MarsTour.cel file into your main   *
* Celestia directory, and unzip the mars_locs2.ssc file into your Celestia\extras   *
* directory. By the way, if you already have Mr. Hutchison's mars_locs2.ssc file in *
* your extras directory, then there is NO need to install this version of the Mars  *
* Locations SSC file.                                                               *
*                                                                                   *
* NOTE: If you don't wish to see *all* of Mars' locations displayed                 *
*       while running this script, select "Render" from Celestia's menu             *
*       taskbar. Then select "Locations" and uncheck the "Label Features"           *
*       box. Right now, there's no way to do this from within a script.             *        
*       If you like, you can also press SHIFT and "&" to do the same                *
*       thing.                                                                      *
*                                                                                   *
*       This script was written for use with Celestia V1.3.2 Pre8                   *
*                                                                                   *
* Further information: I also have another zip file available on my web site which  *
* includes some really spectacular texture maps for Mars, Phobos, Deimos and the    *
* clouds of Mars. They have NOT been included in this file simply because this      *
* package was created only to distribute updates to the MarsTour.cel script file.   *
*                                                                                   *
* If you'd rather install the COMPLETE MarsTour Package, which includes the new     *
* texture maps designed for this script, then please disregard this package and     *
* download the Mars Textures/Locations package, which is also located on my site.   *
*                                                                                   *
*                                                                                   *
* To perform the installation of THIS script follow the instructions below.         *
*                                                                                   *
* 1. First, simply unzip the MarsTour.cel file to your Program Files\Celestia       *
*    directory.                                                                     *
* 2. Second, unzip the mars_locs2.ssc file to your Program Files\Celestia\extras    *
*    directory. Remember, you do NOT need this file if you already have Mr.         *
*    Hutchison's mars_locs2.ssc file in your Program Files\Celestia\extras          *
*    directory.                                                                     *
* 3. Third, unzip the marsmoons2.ssc file to your Program Files\Celestia\extras    *
*    directory. Remember, you do NOT need this file if you already have Mr.         *
*    Hutchison's marsmoons2.ssc file in your Program Files\Celestia\extras          *
*    directory.                                                                     *
*                                                                                   *
*    That's all for now, Take care, and Enjoy! - Bob                                *
*                                                                                   *
* Credits: ________________________________________________________________________ *
*                                                                                   *
* mars_locs2.ssc - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
* marsmoons2.ssc - Author: Grant Hutchison                                          *
* Original script- Author: Alan Federman, Revisions: Selden E. Ball, Jr.            *
* MarsTour.cel   - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
*                                                                                   *
*          ________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Questions or comments? Send them to me at the following email address:            *
*                                                                                   *
* bobhegwood@earthlink.net                                                          *
*                                                                                   *
* Visit my Celestia web page at: http://home.earthlink.net/~bobhegwood              *
*                                                                                   *
*************************************************************************************