Mercury Tour V3.01 By Bob Hegwood on 10 April 2008.

Please unzip all contents so that you end up with the following folder
structure under your Celestia\extras directory in Windows:

The main Celestia\extras\mercurytour directory will contain
this ReadMe.txt file, the mariner10.ssc file, the mercury4k.ssc file,
and the mercurytour.cel file.

mercurytour\models\ will contain the mariner10.3ds file.

mercurytour\textures\medres\ will contain the mariner10solar.jpg file, the
mercury4k.jpg file, and the mercurynorm4k.jpg file.

Please note that with John Van Vliet's permission, I have used his 4k
Mercury textures in order to produce this tour. I have slightly modified
John's original files to offset them by a mere 6 pixels to the right in
order to depict the locations on Mercury as accurately as I can.

Please note that this tour was designed specifically for John's textures.
It will probably work okay with other Mercury textures, but John's depict
the locations I'm using far better than any other textures at this point.
You can find more of John's add-ons at the Motherlode by visiting this link:

http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=10

Please also note that the mariner10.3ds file is used with Terrier's permission.
Terrier's site can be found at the following location:

http://terriercelestia.sphosting.com/INDEX.htm

Also, many thanks to Ulrich "Adirondack" Dickmann for all of his encouragement,
and all of the things he does every day in order to keep the Motherlode up and
running. Some of us really DO appreciate this service, Ulrich!

Take care, Brain-Dead Bob Hegwood

Visit my NEW web site at: http://home.woh.rr.com/bhegwood/