* Earth Launch *

A Celestia .CEL script for simulating a space flight from launch at
ground level to Earth orbit, and beyond.  It shows the view from an
imaginary spacecraft lifting off the Earth.

You can freely use this script for any purpose, provided you give me
credit.

Paolo Amoroso -- amoroso@mclink.it
August 23, 2005

See also:

  Space flight from launch to Earth orbit and beyond (.CEL)
  http://www.shatters.net/forum/viewtopic.php?t=7275

Requires Celestia 1.3.2 or later.  Best viewed in full screen mode
(Alt+ENTER).  It looks better with good Earth textures.  If the
textures are too large, expect jerky movements.


INSTALLATION AND USE

Save the file earth-launch.cel anywhere on your file system.  From
Celestia, run the script by opening it with the "Open Script..."
command of the "File" menu.
