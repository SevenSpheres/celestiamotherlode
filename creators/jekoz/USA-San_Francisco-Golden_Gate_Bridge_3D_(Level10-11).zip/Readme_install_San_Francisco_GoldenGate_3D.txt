
This Celestia add-on was made for all to use and it is free for any non-commercial use.
Send comments or suggestions to Jekoz in Celestia's forum or mail to: jekoz@jekoz.net
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Installation:  
 
-Install on "64K Jestr Earth Mark II (VT/DDS)" or similar

-Install "Jekoz" San Francisco "Virtual Texture" (USA_San_Francisco_Level7_to_11.zip)

-Extract the content of this .zip file into a "TEMP" folder

-Copy the "level10" & "level11" folder directly into the folder of Your main Earth "Virtual Texture" set, if the system ask to overwrite some file click on "YES".

-Copy the folder "Goldengate" to Your Celestia's "Extras" folder.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


SPECIAL THANKS, FOR THE "GOLDENGATE 3D" to JESTR!!!! :DDD


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Images Sources:

The main photos or base pictures that i use to make this add-on come from these web sites:

http://www.satimagingcorp.com/

http://www.spaceimaging.com/


Term of Use of this image:

Credit: Space Imaging

[cut]
Permission is granted to electronically copy, publish in hard copy and broadcast these first international
high-resolution CARTERRA(TM) image chips if proper attribution to Space Imaging is provided.
[cut]
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The use of this add-on is only for educational or informational purposes.