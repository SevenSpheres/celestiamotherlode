
This Celestia add-on was made for all to use and it is free for any non-commercial use.
Send comments or suggestions to Jekoz in Celestia's forum or mail to: jekoz@jekoz.net
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Installation:  
 
-Install on "64K Jestr Earth Mark II (VT/DDS)" or similar

-I suggest to install my Texture only AFTER you have installed this other "close-ups" add-ons:

     + "USA: California "  by Jdou
 
Look at Celestia Motherlode (http://www.celestiamotherlode.net/catalog/earthcloseup.php) for download.

-Extract the zip file directly into the folder of Your main Earth "Virtual Texture" set, if the system ask to overwrite some file click on "YES".


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Images Sources:

The main photos or base pictures that i use to make this add-on come from these web sites:

http://www.satimagingcorp.com/

http://www.spaceimaging.com/


Term of Use of this image:

Credit: Space Imaging

[cut]
Permission is granted to electronically copy, publish in hard copy and broadcast these first international
high-resolution CARTERRA(TM) image chips if proper attribution to Space Imaging is provided.
[cut]
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The use of this add-on is only for educational or informational purposes.