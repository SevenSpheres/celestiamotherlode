CASSINI-HORIZONS

This is a complete ephemeris for the Cassini spacecraft relative to Sol between
its launch and its projected Saturnian atmospheric re-entry date in 2017, as
computed by NASA JPL. The parameters for this data export are detailed below.
In short, it describes a full state vector for the spacecraft for every two
hours of flight.

INSTALLATION

Simply extract the folder containing this file into the "extras/" subfolder of
your Celestia installation.

This will update Celestia's built-in Saturn-centered Cassini trajectory with a
complete Sol-centered one.

The "cassini.xyzv" file can be used alone to update your favorite Cassini model
addon with more current ephemerides, as well.

LICENSE

The data from which this addon was derived are a work of NASA, freely available
to the public by means of HORIZONS.

Any rights I might have to everything else in this package, I hereby release
into the public domain.

M. Raymond Vaughn, 2011-02-28
m.raymond.vaughn@gmail.com

*******************************************************************************
 Revised: Oct 7, 2009    Cassini Spacecraft (interplanetary) / (Sun)       -82
                               http://saturn.jpl.nasa.gov/
 NOTE:
  Cassini navigation is solving for Saturn system parameters (satellite and
  planet center, for example) on a daily basis. Therefore, there is a dynamical
  mis-match between the Cassini trajectory here and the standard DE405 
  planetary ephemeris Horizons uses. 

  Positions of Cassini relative to Saturn and it's moons output by Horizons 
  could be a few dozen to a few hundred km different here than in the system 
  model Cassini navigation is solving for.  Eventually, the Saturn system model
  will be fully updated in Horizons, but it is currently too soon for that.
 
 SPACECRAFT PHYSICAL CHARACTERISTICS:
  Power at Saturn        = ~660 Watts      Data storage           = 4 Gbits
  Star catalog           = 3700 stars      Engineering Subsys     = 12
  Height                 = 6.8 m           Engineering computers  = 26
  Primary s/w language   = Ada             Parts count            > 100000
  Transmitter power      = 19 Watts (RF)   Main engine thrust     = 445 Newtons
  Data Rate at Saturn    = 140000 bits/s   # of telemetry measurs = 11000
  Orbiter Instruments    = 12              Huygens Instruments    = 6
  Total sensors          = 66              Radar power            = 108 Watts
  Fuel mass              = 3132 kg

 ATTITUDE CONTROL:
  Attitude control     = 3-axis stabil.    Pointing accuracy      = 2.0 mrad
  Pointing Stability   = 0.036 mrad/5-sec

 SPACECRAFT TRAJECTORY:
  Trajectories provided by the Navigation Team (concatenated here): 
   000331R_SK_LP0_V1P32       1997-OCT-15 09:28 to 1998-MAY-28 21:23
   000331B_SK_V1P32_V2P12     1998-MAY-28 21:23 to 1999-JUL-06 16:01
   000331R_SK_V2P12_EP15      1999-JUL-06 16:01 to 1999-AUG-19 02:00
   010420R_SCPSE_EP1_JP83     1999-AUG-19 02:00 to 2001-MAR-07 12:00
   010423_SK_JP67_SP0         2001-MAR-07 12:00 to 2002-APR-11 00:00
   020425B_SK_SM812_T45       2002-APR-11 00:00 to 2003-JAN-01 12:00
   030201AP_OPK_SM546_T45     2003-JAN-01 12:00 to 2004-MAY-01 12:00
   040622AP_OPK_04122_08222   2004-MAY-01 12:00 to 2004-OCT-01 12:00
   041001AP_SK_04275_08222    2004-OCT-01 12:00 to 2004-NOV-24 00:00
   041210AP_OPK_04329_08189   2004-NOV-24 00:00 to 2005-APR-29 00:59
   050720AP_SCPSE_05119_08222 2005-APR-29 00:59 to 2006-MAR-23 00:00
   060323AP_SCPSE_06082_08222 2006-MAR-23 00:00 to 2006-DEC-22 05:00
   070209AP_SCPSE_06356_08222 2006-DEC-22 05:00 to 2007-SEP-18 12:00
   070918AP_SCPSE_07261_10191 2007-SEP-18 12:00 to 2008-MAY-17 01:30
   080806AP_SCPSE_08138_10182 2008-MAY-17 01:30 to 2009-JUL-17 15:53
   090721AP_SCPSE_09198_17265 2009-JUL-17 15:53 to 2009-SEP-05 02:49
   091005AP_SCPSE_09248_17265 2009-SEP-05 02:49 to 2017-SEP-22 00:00
*******************************************************************************
 
 
*******************************************************************************
Ephemeris / WWW_USER Mon Feb 28 18:03:26 2011  Pasadena, USA     / Horizons    
*******************************************************************************
Target body name: Cassini Spacecraft (-82)        {source: 091005AP_SK_09248_17265.}
Center body name: Sun (10)                        {source: DE405}
Center-site name: BODY CENTER
*******************************************************************************
Start time      : A.D. 1997-Oct-15 09:27:11.5724 CT 
Stop  time      : A.D. 2017-Sep-22 00:00:00.0000 CT 
Step-size       : 120 minutes
*******************************************************************************
Center geodetic : 0.00000000,0.00000000,0.0000000 {E-lon(deg),Lat(deg),Alt(km)}
Center cylindric: 0.00000000,0.00000000,0.0000000 {E-lon(deg),Dxy(km),Dz(km)}
Center radii    : 696000.0 x 696000.0 x 696000.0 k{Equator, meridian, pole}    
Output units    : KM-S                                                         
Output format   : 02
Reference frame : ICRF/J2000.0                                                 
Output type     : GEOMETRIC cartesian states
Coordinate systm: Ecliptic and Mean Equinox of Reference Epoch                 
*******************************************************************************
JDCT ,   , X, Y, Z, VX, VY, VZ,
*******************************************************************************
*******************************************************************************
Coordinate system description:

  Ecliptic and Mean Equinox of Reference Epoch

    Reference epoch: J2000.0
    xy-plane: plane of the Earth's orbit at the reference epoch
    x-axis  : out along ascending node of instantaneous plane of the Earth's
              orbit and the Earth's mean equator at the reference epoch
    z-axis  : perpendicular to the xy-plane in the directional (+ or -) sense
              of Earth's north pole at the reference epoch.

Symbol meaning  

    JDCT     Epoch Julian Date, Coordinate Time
      X      x-component of position vector (km)                               
      Y      y-component of position vector (km)                               
      Z      z-component of position vector (km)                               
      VX     x-component of velocity vector (km/sec)                           
      VY     y-component of velocity vector (km/sec)                           
      VZ     z-component of velocity vector (km/sec)                           

Geometric states/elements have no aberration corrections applied.

 Computations by ...
     Solar System Dynamics Group, Horizons On-Line Ephemeris System
     4800 Oak Grove Drive, Jet Propulsion Laboratory
     Pasadena, CA  91109   USA
     Information: http://ssd.jpl.nasa.gov/
     Connect    : telnet://ssd.jpl.nasa.gov:6775  (via browser)
                  telnet ssd.jpl.nasa.gov 6775    (via command-line)
     Author     : Jon.Giorgini@jpl.nasa.gov
*******************************************************************************