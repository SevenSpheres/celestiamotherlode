Large Stars
by Joey Pelobel

This simple addon includes an .stc file which includes several large red and blue (super)giant stars.
Sources are included as comments within the .stc file.

To install, simply move the .stc file into your "extras" folder.

This is based on the "Largest Stars" addon, kindly created by LukeCEL, licensed under the Public Domain.