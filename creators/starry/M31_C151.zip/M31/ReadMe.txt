To install in Celestia simply unzip to your 'extras' folder.
Image courtesy of Hubble Space Telescope.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Summary: The Andromeda Galaxy M31 for Celestia 1.5.1. 
Description: This is modified version of original add-on by Jestr. Adapted for Celestia 1.5.1.: location and size of the object matches this in newer release of Celestia. If you replace old add-on with this one you will no longer see TWO different renderings of the Galaxy. Image from Hubble Telescope superimposed on Celestia 3D model gives pretty much cool effect in this particular case, better than with some other similar add-ons and seems to work well with this respect. 
To select original Celestia model type "M 31"
To select add-on object type "+M31"
Please note, this add-on requires manual tweaking to work on Linux since some filenames have the wrong cases, and the add-on utilizes a Billboard 2D model in order to display Celestia's now built-in 3D version of the galaxy. 
Created by: Jestr, jestr@ntlworld.com.
Modified by: Starry (Tomasz Malyszek), tmark4@yahoo.com
