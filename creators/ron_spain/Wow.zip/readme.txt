
In this archive is a Celestia script about the Wow! Signal, still the best candidate for an alien signal. Opening that file should show a presentation assuming you have downloaded and installed Celestia.

Author: Ron Spain
http://rspain.zxq.net
