1. To install this just take the "mimas.cmod" file and copy it into your "models" folder.
	a. The default directory is "C:\Program Files\Celestia\models".

2. Then copy this "Mesh "mimas.cmod"" into your "solarsys.ssc" under "Mimas" "Sol/Saturn".
	a. The file is in "C:\Program Files\Celestia\data".

3. Start Celestia and go to Mimas.