***HD 85512 b***

leifgiering@gmail.com

Made by Leif Giering on 12-28-2011
Surface texture is 100% my work.
Cloud texture is a copy of 'venuslike.jpg' that I modified.
About half of the info about the planet is true, the other half being my personal guess.

LICENSE:
You may do whatever you want to the files, however, if you decide to put any of my work on public, please give me credit.

INSTALLATION:
Just unzip this file into your 'extras' directory.

*****************