-- French translation of the Lua Edu Tools.
-- Vincent <vince.gian@free.fr>
-- Localization revision: Apr 26, 2009

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools activés";
	["Lua Edu Tools disabled"] = "Lua Edu Tools désactivés";

-- timeBox
	h = "h"; -- SI symbol for "hour"
	["Rate:"] = "Ratio :";
	["time stopped"] = "temps arrêté";
	["(paused)"] = "(en pause)";
	["Set Time"] = "Régler le Temps";
	["Current Time"] = "Temps actuel";
	Jan = "Jan";
	Feb = "Fév";
	Mar = "Mar";
	Apr = "Avr";
	May = "Mai";
	Jun = "Juin";
	Jul = "Juil";
	Aug = "Août";
	Sep = "Sep";
	Oct = "Oct";
	Nov = "Nov";
	Dec = "Déc";

-- lightBox
	["Ambient Light Level:"] = "Lumière Ambiante :";

-- magnitudeBox
	["Magnitude limit:"] = "Magnitude limite :";
	["AutoMag at 45°:"] = "AutoMag à 45° :";
	A = "A"; 	-- AutoMag Button

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Gain de Luminosité :";

-- renderBox
	["Set Render Options"] = "Options d'Affichage";
	["Show:"] = "Afficher :";
	["Guides:"] = "Guides :";
	["Orbits / Labels:"] = "Orbites / Noms :";
	Galaxies = "Galaxies";
	["Globulars"] = "Amas globulaires";
	["Open Clusters"] = "Amas ouverts";
	Nebulae = "Nébuleuses";
	Stars = "Étoiles";
	Planets = "Planètes";
	Atmospheres = "Atmosphères";
	["Cloud Maps"] = "Nuages";
	["Cloud Shadows"] = "Ombre des Nuages";
	["Ring Shadows"] = "Ombres des Anneaux";
	["Eclipse Shadows"] = "Ombres des Éclipses";
	["Night Maps"] = "Lumières Nocturnes";
	["Comet Tails"] = "Queues des Comètes";
	Orbits = "Orbites";
	["Partial Trajectories"] = "Trajectoires Partielles";
	Markers = "Marqueurs";
	Constellations = "Constellations";
	Boundaries = "Limites des Constell.";
	["Equatorial Grid"] = "Grille Équatoriale";
	["Horizontal Grid"] = "Grille Horizontale";
	["Galactic Grid"] = "Grille Galactique";
	["Ecliptic Grid"] = "Grille Écliptique";
	["Ecliptic"] = "Ligne Écliptique";
	["Smooth Lines"] = "Anticrénelage";
	Automag = "Magnitudes Auto.";
	["Dwarf Planets"] = "Planètes naines";
	Moons = "Lunes";
	["Minor Moons"] = "Lunes mineures";
	Asteroids = "Astéroïdes";
	Comets = "Comètes";
	Spacecraft = "Astronefs";
	["Constell. in Latin"] = "Constell. en Latin";
	Locations = "Points de Repère";
	["Star Style"] = "Style des étoiles";
	["Texture Resolution"] = "Résolution des textures";

-- obsModeBox
	--["Goto Sun"] = "Aller au Soleil";
	["Goto"] = "Aller à";
	["Follow"] = "Suivre";
	["Sync Orbit"] = "Orbite Sync";
	["Track"] = "Pister";
	["Follow "] = "Suivre ";
	["Sync Orbit "] = "Orbite Sync ";
	["Track "] = "Pister ";
	["Chase "] = "Chasser ";
	["Lock "] = "Bloquer ";
	["Free flight"] = "Vol libre";
	Sol = "Soleil";
	["Milky Way"] = "Voie Lactée";

-- SolarSytemBox
	["Solar System Browser"] = "Navigateur de Syst. Sol.";
	Star = "Étoile";
	["Other bodies orbiting"] = "Autres objets en orbite autour de";
	["Bodies orbiting"] = "Objets en orbite autour de";

-- fovBox
	["FOV:"] = "CdV :";

-- addsBox
	["Set Addon Visibility"] = "Visibilité des Addons";
	["Addon Visibility:"] = "Visibilité des Addons :";
	["Minimum Feature Size:"] = "Taille Min. des Repères :";
	["Label Features"] = "Afficher les Repères";
	["Asteroid Belt"] = "Ceinture d'Astéroïdes";
	["Dying Sun"] = "Mort du Soleil";
	["Atmosphere Composition"] = "Composition de l'Atmosphère";
	["Political Borders"] = "Frontières Politiques";
	["Meteorite Impacts"] = "Impacts de Météorites";
	["Earth Volcanoes"] = "Volcans de la Terre";
	["Earthquakes"] = "Tremblements de Terre";
	["Large Scale Universe"] = "Structure de l'Univers";
	["Galactic Center"] = "Centre Galactique";

-- infoBox
	["More Info"] = "Plus d'Info";

-- coordinatesBox
	Coordinates = "Coordonnées";
	["RA:"] = "AD :";
	["Dec:"] = "Déc :";
	--["Distance to Earth:"] = "Distance de la Terre :";
	["Ecl. Long:"] = "Long écl. :";
	["Ecl. Lat:"] = "Lat écl. :";
	["Gal. Long:"] = "Long gal. :";
	["Gal. Lat:"] = "Lat gal. :";
	ly = "al";
	AU = "ua";
	km = "km";
	m = "m";

-- distanceBox
	Distances = "Distances";

-- MagnificationBox
	Magnification = "Magnification";
	["Planets Magnified"] = "Planètes magnifiées";
	["Moons Magnified"] = "Lunes magnifiées";
	["Earth and Moon Magnified"] = "Terre et Lune magnifiées";
	["Magnification disabled"] = "Magnification désactivée";

-- virtualPadBox
	["Virtual Pad"] = "Pad Virtuel";

-- compassBox
	Compass = "Boussole";
	S = "S";
	W = "O";
	N = "N";
	E = "E";
	["Az:"] = "Az:";
	["Elev:"] = "Élév:";
	["planetarium mode"] = "mode planétarium";
	["navigation mode"] = "mode navigation";
	["Alt-azimuth mode enabled"] = "Mode Alt-Azimuthal activé";

}