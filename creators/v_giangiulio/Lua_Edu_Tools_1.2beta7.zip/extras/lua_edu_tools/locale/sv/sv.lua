-- Swedish translation of the Lua Edu Tools.
-- Anders Pamdal <anders@pamdal.se>
-- Localization revision: Sep 6, 2009

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools aktiverat";
	["Lua Edu Tools disabled"] = "Lua Edu Tools inaktiverat";

-- timeBox
	h = "t"; -- SI symbol för "timme"
	["Rate:"] = "Ratio :";
	["time stopped"] = "tid stoppad";
	["(paused)"] = "(pausad)";
	["Set Time"] = "Justera tid";
	["Current Time"] = "Aktuell tid";
	Jan = "Jan";
	Feb = "Feb";
	Mar = "Mar";
	Apr = "Apr";
	May = "Maj";
	Jun = "Jun";
	Jul = "Jul";
	Aug = "Aug";
	Sep = "Sep";
	Oct = "Okt";
	Nov = "Nov";
	Dec = "Dec";

-- lightBox
	["Ambient Light Level:"] = "Belysning :";

-- magnitudeBox
	["Magnitude limit:"] = "Ljusstyrkesgräns :";
	["AutoMag at 45°:"] = "AutoLjus vid 45° :";
	A = "A";

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Galaxljusförstärkning:";

-- renderBox
	["Set Render Options"] = "Renderingsval";
	["Show:"] = "Visa :";
	["Guides:"] = "Guider:";
	["Orbits / Labels:"] = "Omloppsbanor / Etiketter :";
	Planets = "Planeter";
	Stars = "Stjärnor";
	Galaxies = "Galaxer";
	Nebulae = "Nebulosor";
	["Open Clusters"] = "Öppna kluster";
	Orbits = "Omloppsbanor";
	Markers = "Markeringar";
	Constellations = "Stjärnbilder";
	Boundaries = "Stjärnbildsgränser";
	["Night Maps"] = "Natttexturer";
	["Cloud Maps"] = "Molntexturer";
	Atmospheres = "Atmosfärer";
	["Comet Tails"] = "Kometsvansar";
	["Eclipse Shadows"] = "Förmörkelse skuggor";
	["Ring Shadows"] = "Ringskuggor";
	Automag = "Auto-Ljusstyrka";
	["Smooth Lines"] = "Mjuka linjer";
	Moons = "Månar";
	Asteroids = "Asteroider";
	Comets = "Kometer";
	Spacecraft = "Rymdfarkoster";
	["Constell. in Latin"] = "Stjärnbilder på latin";
	Locations = "Platser";
	["Star Style"] = "Stjärnstil";
	["Texture Resolution"] = "Texturupplösning";
	["Globulars"] = "Stjärnhopar";
	["Minor Moons"] = "Mindre månar";
	["Dwarf Planets"] = "Dvärgplaneter";
	["Cloud Shadows"] = "Molnskuggor";
	["Equatorial Grid"] = "Ekvatoriskt rutnät";
	["Horizontal Grid"] = "Horizontala rutnät";
	["Galactic Grid"] = "Galaktiska rutnät";
	["Ecliptic Grid"] = "Eliptiska rutnät";
	["Ecliptic"] = "Eliptisk";
	["Partial Trajectories"] = "Partiella banor";

-- obsModeBox
	--["Goto Sun"] = "Gå till sol";
	["Goto"] = "Gå till";
	["Follow"] = "Följ";
	["Sync Orbit"] = "Synk omlo.";
	["Track"] = "Spåra";
	["Follow "] = "Följ ";
	["Sync Orbit "] = "Synk omlo. ";
	["Track "] = "Spåra ";
	["Chase "] = "Jaga ";
	["Lock "] = "Lås ";
	["Free flight"] = "Friflygning";
	Sol = "Sol";
	["Milky Way"] = "Vintergatan";

-- SolarSytemBox
	["Solar System Browser"] = "Solsystemsutforskare";
	Star = "Stjärna";
	["Other bodies orbiting"] = "Andra kroppar i omloppsbana runt";
	["Bodies orbiting"] = "Kroppar i omloppsbana";

-- fovBox
	["FOV:"] = "FOV :";

-- addsBox
	["Set Addon Visibility"] = "Sätt tilläggsaktivering";
	["Addon Visibility:"] = "Tilläggsaktivering:";
	["Minimum Feature Size:"] = "Minsta storlek på funktion:";
	["Label Features"] = "Etiketter";
	["Asteroid Belt"] = "Asteroidbälte";
	["Dying Sun"] = "Döende sol";
	["Atmosphere Composition"] = "Atmosfärsammansättning";
	["Political Borders"] = "Politiska gränser";
	["Meteorite Impacts"] = "Meteorit kratrar";
	["Earth Volcanoes"] = "Vulkaner";
	["Earthquakes"] = "Jordbävningar";
	["Large Scale Universe"] = "Storskaligt Universum";
	["Galactic Center"] = "Galaktiskt Center";

-- infoBox
	["More Info"] = "Mer info";

-- measureBox
	Measure = "Mått";
	["Geocentric coordinates:"] = "Geocentriska koordinater:";
	["RA:"] = "RA :";
	["Dec:"] = "Dec :";
	["Distance to Earth:"] = "Avstånd till jorden :";
	ly = "lå";
	AU = "ua";
	km = "km";
	m = "m";

-- distanceBox
	Distances = "Avstånd";

-- MagnificationBox
	Magnification = "Förstoring";
	["Planets Magnified"] = "Förstorade planeter";
	["Moons Magnified"] = "Förstorade månar";
	["Earth and Moon Magnified"] = "Förstorad jord och måne";
	["Magnification disabled"] = "Förstoring avaktiverad";

-- virtualPadBox
	["Virtual Pad"] = "Virtuell platta";

-- compassBox
	Compass = "Kompass";
	S = "S";
	W = "V";
	N = "N";
	E = "Ö";
	["Az:"] = "Az:";
	["Elev:"] = "Elev:";
	["planetarium mode"] = "planetariums läge";
	["navigation mode"] = "navigations läge";
	["Alt-azimuth mode enabled"] = "Läge Alt-Azimuthal aktivt";

}
