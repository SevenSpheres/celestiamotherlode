-- German translation of the Lua Edu Tools.
-- Ulrich Dickmann aka Adirondack <celestia-deutsch@gmx.net>
-- Localization revision: Sept 11, 2009

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools aktiviert";
	["Lua Edu Tools disabled"] = "Lua Edu Tools abgeschaltet";

-- timeBox
	h = "h"; -- SI symbol for "hour"
	["Rate:"] = "Rate:";
	["time stopped"] = "Zeit angehalten";
	["(paused)"] = "(Pause)";
	["Set Time"] = "Zeit einstellen";
	["Current Time"] = "Aktuelle Zeit";
	Jan = "Jan";
	Feb = "Feb";
	Mar = "Mrz";
	Apr = "Apr";
	May = "Mai";
	Jun = "Jun";
	Jul = "Jul";
	Aug = "Aug";
	Sep = "Sep";
	Oct = "Okt";
	Nov = "Nov";
	Dec = "Dez";

-- lightBox
	["Ambient Light Level:"] = "Streulicht:";

-- magnitudeBox
	["Magnitude limit:"] = "Magnituden-Grenze:";
	["AutoMag at 45°:"] = "AutoMag bei 45° :";
	A = "A"; 	-- AutoMag Button

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Galaxien-Helligkeit:";

-- renderBox
	["Set Render Options"] = "Anzeige-Optionen";
	["Show:"] = "Zeige :";
	["Guides:"] = "Hilfslinien:";
	["Orbits / Labels:"] = "Orbits / Bezeichnungen :";
	Planets = "Planeten";
	Stars = "Sterne";
	Galaxies = "Galaxien";
	Nebulae = "Nebel";
	["Open Clusters"] = "Offene Sternhaufen";
	Orbits = "Umlaufbahnen";
	Markers = "Markierungen";
	Constellations = "Sternbilder";
	Boundaries = "Sternbildgrenzen";
	["Night Maps"] = "Nachttexturen";
	["Cloud Maps"] = "Wolken";
	Atmospheres = "Atmosphären";
	["Comet Tails"] = "Kometenschweife";
	["Eclipse Shadows"] = "Finsternisschatten";
	["Ring Shadows"] = "Ringschatten";
	Automag = "Auto-Magnitude";
	["Smooth Lines"] = "Glattere Umlaufbahnen";
	Moons = "Monde";
	Asteroids = "Asteroiden";
	Comets = "Kometen";
	Spacecraft = "Raumschiffe";
	["Constell. in Latin"] = "Sternbilder in Latein";
	Locations = "Bezugspunkte u. Orte";
	["Star Style"] = "Aussehen der Sterne";
	["Texture Resolution"] = "Auflösung der Texturen";
	["Globulars"] = "Kugelsternhaufen";
	["Minor Moons"] = "Kleine Monde";
	["Dwarf Planets"] = "Zwergplaneten";
	["Cloud Shadows"] = "Wolkenschatten";
	["Equatorial Grid"] = "Equatoriales Gradnetz";
	["Horizontal Grid"] = "Horizontales Gradnetz";
	["Galactic Grid"] = "Galaktisches Gradnetz";
	["Ecliptic Grid"] = "Ekliptikales Gradnetz";
	["Ecliptic"] = "Ekliptik";
	["Partial Trajectories"] = "Partielle Flugbahnen";

-- obsModeBox
	--["Goto Sun"] = "Gehe zur Sonne";
	["Goto"] = "Gehe zu";
	["Follow"] = "Folgen";
	["Sync Orbit"] = "Sync. Orbit";
	["Track"] = "Beobachten";
	["Follow "] = "Folgen ";
	["Sync Orbit "] = "Sync. Orbit ";
	["Track "] = "Beobachten ";
	["Chase "] = "Verfolgen ";
	["Lock "] = "Verbinden ";
	["Free flight"] = "Freier Flug";
	Sol = "Sonne";
	["Milky Way"] = "Milchstraße";

-- SolarSytemBox
	["Solar System Browser"] = "Sonnensystem-Browser";
	Star = "Stern";
	["Other bodies orbiting"] = "Umrundende Körper für";
	["Bodies orbiting"] = "Umrundende Körper für";

-- fovBox
	["FOV:"] = "FOV :";

-- addsBox
	["Set Addon Visibility"] = "Addon Sichtbarkeit";
	["Addon Visibility:"] = "Addon  Sichtbarkeit einstellen:";
	["Minimum Feature Size:"] = "Minimale Größe der Merkmale:";
	["Label Features"] = "Beschriftungen der Merkmale anzeigen";
	["Asteroid Belt"] = "Hauptgürtel";
	["Dying Sun"] = "Sterbende Sonne";
	["Atmosphere Composition"] = "Zusammensetzung der Atmosphäre";
	["Political Borders"] = "Politische Grenzen";
	["Meteorite Impacts"] = "Meteoriteneinschläge";
	["Earth Volcanoes"] = "Vulkane auf der Erde";
	["Earthquakes"] = "Erdbeben";
	["Large Scale Universe"] = "Struktur des Universums";
	["Galactic Center"] = "Galaktisches Zentrum";

-- infoBox
	["More Info"] = "Mehr Infos";

-- measureBox
	Measure = "Koordinaten";
	["Geocentric coordinates:"] = "Geozentrische Koordinaten:";
	["RA:"] = "Rektaszension:";
	["Dec:"] = "Deklination:";
	["Distance to Earth:"] = "Entfernung zur Erde:";
	ly = "LJ";
	AU = "AE";
	km = "km";
	m = "m";

-- distanceBox
	Distances = "Entfernungen";

-- MagnificationBox
	Magnification = "Vergrößerung";
	["Planets Magnified"] = "Planeten vergrößert";
	["Moons Magnified"] = "Monde vergrößert";
	["Earth and Moon Magnified"] = "Erde und Mond vergrößert";
	["Magnification disabled"] = "Vergrößerung abgeschaltet";

-- virtualPadBox
	["Virtual Pad"] = "Blickrichtung";

-- compassBox
	Compass = "Kompass";
	S = "S";
	W = "W";
	N = "N";
	E = "O";
	["Az:"] = "Az:";
	["Elev:"] = "Alt:";
	["planetarium mode"] = "Planetarium-Modus";
	["navigation mode"] = "Navigationsmodus";
	["Alt-azimuth mode enabled"] = "Alt-Azimut-Modus aktiviert";

}