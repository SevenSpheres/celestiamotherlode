-- luahookinit.lua

require "lua_edu_tools";

celestia:setluahook(lua_edu_tools);
