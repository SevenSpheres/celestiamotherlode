-- Define the Title of the star set.
HR_Title[1] = "Reference stars"

-- Define whether star labels are displayed or not.
HR_LabelOn[1] = true

-- Define the list of star names.
HR_stars_t[1] =
{
    "Sol",
    "Aldebaran",
    "Altair",
    "Antares",
    "Bellatrix",
    --"Betelgeuse",
    "Canopus",
    "Deneb",
    "Polaris",
    "Pollux",
    "Proxima",
    "Rigel",
    --"Sirius A",
    "Sirius B",
    "Vega"
}
