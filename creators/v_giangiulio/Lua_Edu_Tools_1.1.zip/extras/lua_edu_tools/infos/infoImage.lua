infoImage =
{
-- Image filenames for Sol:
Sol1 = "../images/image_Sol1.jpg";
Sol2 = "../images/image_Sol2.jpg";
Sol3 = "../images/image_Sol3.jpg";
Sol4 = "../images/image_Sol4.jpg";

-- Image filenames for Mercury:
--Mercury1 = "../images/image_Mercury1.jpg";

-- Image filenames for Venus:
--Venus1 = "../images/image_Venus1.jpg";

-- Image filenames for the Earth:
--Earth1 = "../images/image_Earth1.jpg";

-- Image filenames for the Moon:
Moon1 = "../images/image_Moon1.jpg";

-- Image filenames for Mars:
Mars1 = "../images/image_Mars1.jpg";

-- Image filenames for Jupiter:
--Jupiter1 = "../images/image_Jupiter1.jpg";

-- Image filenames for Saturn:
Saturn1 = "../images/image_Saturn1.jpg";

-- Image filenames for Titan:
Titan1 = "../images/image_Titan1.jpg";

-- Image filenames for the Milky Way:
-- Note: The string 'Milky Way' contains a space, so
-- we have to write ["Milky Way1"] instead of Milky Way1.
["Milky Way1"] = "../images/image_MilkyWay1.jpg";

-- Add your own Image filenames here :
----------------------------------------------
-- Name_of_object_followed_by_image_index = "image_filename";
----------------------------------------------
-- Note: Use ["Name of object followed by image index"] if the name contains any spaces.
-- The path is relative to the "tools" folder.
}