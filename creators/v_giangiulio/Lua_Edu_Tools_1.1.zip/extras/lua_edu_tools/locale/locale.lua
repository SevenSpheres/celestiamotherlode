require "config"

lang_country_code =
	{
	-- Language codes:
		English = "en",
		French = "fr",
		German = "de",
		Italian = "it",
		Portuguese = "pt",
		Russian = "ru",
		Spanish = "es",
		Swedish = "sv",
	-- Country codes:
		Brazil = "BR",
		["United States"] = "US",
	}

-- Set English as the default language.
lang = "en";

-- Get language setting from 'config.lua'.
if language == "system_default" then
	-- Get the system locale (doesn't work properly on Mac OS-X).
  loc = os.setlocale("", "collate");
else
	-- Use language set in 'config.lua'.
  loc = language;
end

-- On Windows, the system locale output doesn't correspond to the ISO 639-1
-- standard for languages and the ISO 3166 standard for countries.
-- So, we have to convert the system locale output to the repsective ISO codes.
pos_ = string.find(loc, "_");
posdot = string.find(loc, "%.");
if pos_ then
	langsubstr = string.sub(loc, 1, pos_-1);
	if string.len(langsubstr) > 2 then
		langsubstr = lang_country_code[langsubstr];
	end
	if posdot then
		countrysubstr = string.sub(loc, pos_+1, posdot-1);
		if string.len(countrysubstr) > 2 then
			countrysubstr = lang_country_code[countrysubstr];
		end
	else
		countrysubstr = string.sub(loc, pos_+1, -1);
	end
	if langsubstr then
		lang = langsubstr;
		if countrysubstr and string.lower(countrysubstr) ~= langsubstr then
			-- Take the country code into account when it is present in the locale output.
			lang = langsubstr.."_"..countrysubstr;
			if not(pcall( function() require (lang) end )) then
				-- Don't take the country code into account when no localization is found.
				lang = langsubstr;
			end
		end
	end
else
	lang = language;
end

-- Set the numeric category to the system locale.
-- Only works with Lua 5.1.
if _VERSION == "Lua 5.1" then
	os.setlocale("", "numeric");
end

if pcall( function() require (lang) end ) then
	-- Define a localization function if 'lang.lua' is found.
	_ = function(string)
		if loc_str[string] then
			-- Return translated string if it exists.
			return loc_str[string];
		else
			-- Return default string if there is no translation available.
			return string;
		end
	end
else
	-- The function will return the default string if 'lang.lua' is not found.
   _ = function(string)
		return string;
	end
end

-- Use the localized version for infoText if 'infoText_lang.lua' is found.
infoTextLang = "infoText".."_"..lang;
if not(pcall( function() require (infoTextLang) end )) then
	-- Otherwise, use the default infoText.
	if not(pcall( function() require ("infoText") end )) then
		infoText = {};
	end
end

getlocalname = function(obj)
  if not(empty(obj)) then
    objlocalname = obj:localname();
    if objlocalname == "?" then 
      if obj:name() == "Sol" then
        -- Sol is not localized in Celestia; use localization from 'lang.lua'.
        objlocalname = _("Sol");
      elseif obj:name() == "Milky Way" then
        -- Milky Way is not localized in Celestia; use localization from 'lang.lua'.
        objlocalname = _("Milky Way");
      elseif obj:type() == "star" then
        -- Display star names using Bayer code (Greek Letters Abbreviation).
        -- Use replaceGreekLetterAbbr() function defined in 'textlayout.lua'.
        objlocalname = replaceGreekLetterAbbr(obj:name());
      else
        objlocalname = obj:name();
      end
    end
  end
	return objlocalname
end