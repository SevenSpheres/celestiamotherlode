-- Russian translation of the Lua Edu Tools.
-- Sergey Leonov <leserg@ua.fm>
-- Localization revision: Jan 05, 2008

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools включена";
	["Lua Edu Tools disabled"] = "Lua Edu Tools отключена";

-- timeBox
	h = "ч"; -- SI symbol for "hour"
	["Rate:"] = "Множитель:";
	["time stopped"] = "время остановлено";
	["(paused)"] = "(пауза)";
	["Set Time"] = "Установка времени";
	["Current Time"] = "Текущее время";
	Jan = "янв";
	Feb = "фев";
	Mar = "мар";
	Apr = "апр";
	May = "май";
	Jun = "июн";
	Jul = "июл";
	Aug = "авг";
	Sep = "сен";
	Oct = "окт";
	Nov = "ноя";
	Dec = "дек";

-- lightBox
	["Ambient Light Level:"] = "Рассеянный свет:";

-- magnitudeBox
	["Magnitude limit:"] = "Предел величины:";
	["AutoMag at 45°:"] = "Автовелич.при 45°:";
	A = "A"; 	-- AutoMag Button

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Светимость галактик:";

-- renderBox
	["Set Render Options"] = "Настройки просмотра";
	["Show:"] = "Показывать :";
	["Orbits:"] = "Орбиты :";
	["Labels:"] = "Названия :";
	Planets = "Планеты";
	Stars = "Звезды";
	Galaxies = "Галактики";
	Nebulae = "Туманности";
	["Open Clusters"] = "Звездные скопления";
	Orbits = "Орбиты";
	Markers = "Метки";
	Constellations = "Созвездия";
	Boundaries = "Границы созвездий";
	Grid = "Координатную cетку";
	["Night Maps"] = "Свет ночной стороны";
	["Cloud Maps"] = "Облачный покров";
	Atmospheres = "Атмосферу";
	["Comet Tails"] = "Хвосты комет";
	["Eclipse Shadows"] = "Тени затмений";
	["Ring Shadows"] = "Тени на кольцах";
	Automag = "Автовеличина";
	["Smooth Lines"] = "Сглаживание";
	Moons = "Спутники";
	Asteroids = "Астероиды";
	Comets = "Кометы";
	Spacecraft = "Космич. корабл.";
	Invisibles = "Невидимое";
	["Constell. in Latin"] = "Созвездия на латинице";
	Locations = "Местоположения";
	["Star Style:"] = "Стиль звезд:";
	Points = "Точки";
	["Fuzzy Points"] = "Размытые точки";
	["Scaled Discs"] = "Диски";

-- obsModeBox
	["Goto Sun"] = "Идти к Солнцу";
	["Goto Selection"] = "Идти к объекту";
	["Follow Selection"] = "Набл. за объектом";
	["Track Selection"] = "Следить за объектом";
	["Follow"] = "Наблюдение";
	["Sync Orbit"] = "Синх. вращение";
	["Chase"] = "Сопровождение";
	["Lock"] = "Захват";	
	["Track"] = "Слежение";
	["Free flight"] = "Свободный полет";
	Sol = "Солнце";
	["Milky Way"] = "Млечный путь";

-- SolarSytemBox
	["Solar System Browser"] = "Каталог Солн. систем.";
	Star = "Звезда";
	["Other bodies orbiting"] = "Другие объекты";
	["Bodies orbiting"] = "Орбитальные объекты";

-- fovBox
	["FOV:"] = "FOV:";

-- asteroidBeltBox
	["Asteroid Belt"] = "Пояс астероидов";

-- infoBox
	["More Info"] = "Справка";

-- measureBox
	Measure = "Координаты";
	["Geocentric coordinates:"] = "Геоцентрические координаты:";
	["RA:"] = "Прямое восхождение:";
	["Dec:"] = "Склонение:";
	["Distance to Earth:"] = "Расстояние до Земли:";
	ly = "свет.лет";
	AU = "а.е.";
	km = "км";
	m = "м";

-- distanceBox
	Distances = "Расстояния";

-- MagnificationBox
	Magnification = "Увеличение";
	["Planets Magnified"] = "Увеличение планет";
	["Moons Magnified"] = "Увеличение спутников";
	["Earth and Moon Magnified"] = "Увеличение Земли и Луны";
	["Magnification disabled"] = "Увеличение отключено";

-- virtualPadBox
	["Virtual Pad"] = "Управление";

-- compassBox
	Compass = "Компас";
	S = "Ю";
	W = "З";
	N = "С";
	E = "В";
	["Az:"] = "Аз:";
	["Elev:"] = "Скл:";
	["planetarium mode"] = "Планетарий";
	["navigation mode"] = "Навигация";
	["Alt-azimuth mode enabled"] = "Включен режим Высота-Азимут";

}