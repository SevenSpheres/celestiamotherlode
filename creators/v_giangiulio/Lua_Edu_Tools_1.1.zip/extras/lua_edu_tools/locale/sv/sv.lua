-- Translator : Anders Pamdal <anders@pamdal.se>

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools aktiverat";
	["Lua Edu Tools disabled"] = "Lua Edu Tools inaktiverat";

-- timeBox
	h = "t"; -- SI symbol för "timme"
	["Rate:"] = "Ratio :";
	["time stopped"] = "tid stoppad";
	["(paused)"] = "(pausad)";
	["Set Time"] = "Justera Tid";
	["Current Time"] = "Aktuell Tid";
	Jan = "Jan";
	Feb = "Feb";
	Mar = "Mar";
	Apr = "Apr";
	May = "Maj";
	Jun = "Jun";
	Jul = "Jul";
	Aug = "Aug";
	Sep = "Sep";
	Oct = "Okt";
	Nov = "Nov";
	Dec = "Dec";

-- lightBox
	["Ambient Light Level:"] = "Belysning :";

-- magnitudeBox
	["Magnitude limit:"] = "Ljusstyrkesgräns :";
	["AutoMag at 45°:"] = "AutoLjus vid 45° :";
	A = "A";

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Galaxljusförstärkning:";

-- renderBox
	["Set Render Options"] = "Renderingsval";
	["Show:"] = "Visa :";
	["Orbits:"] = "Omloppsbanor :";
	["Labels:"] = "Etiketter :";
	Planets = "Planeter";
	Stars = "Stjärnor";
	Galaxies = "Galaxer";
	Nebulae = "Nebulosor";
	["Open Clusters"] = "Öppna kluster";
	Orbits = "Omloppsbanor";
	Markers = "Markeringar";
	Constellations = "Stjärnbilder";
	Boundaries = "Stjärnbildsgränser";
	Grid = "Rutnätsraster";
	["Night Maps"] = "Natt texturer";
	["Cloud Maps"] = "Moln texturer";
	Atmospheres = "Atmosfärer";
	["Comet Tails"] = "Kometsvansar";
	["Eclipse Shadows"] = "Förmörkelse skuggor";
	["Ring Shadows"] = "Ring skuggor";
	Automag = "Auto-Ljusstyrka";
	["Smooth Lines"] = "Mjuka linjer";
	Moons = "Månar";
	Asteroids = "Asteroider";
	Comets = "Kometer";
	Spacecraft = "Rymdfarkoster";
	Invisibles = "Osynliga";
	["Constell. in Latin"] = "Stjärnbilder på latin";
	Locations = "Platser";
	["Star Style:"] = "Stjärn Stil:";
	Points = "Prickar";
	["Fuzzy Points"] = "Suddiga Prickar";
	["Scaled Discs"] = "Skalade Skivor";

-- obsModeBox
	["Goto Sun"] = "Gå till Sol";
	["Goto Selection"] = "Gå till Vald";
	["Follow Selection"] = "Följ Vald";
	["Track Selection"] = "Spåra Vald";
	["Follow"] = "Följ";
	["Sync Orbit"] = "Synka Omloppsbana";
	["Chase"] = "Jaga";
	["Lock"] = "Lås";	
	["Track"] = "Spåra";
	["Free flight"] = "Friflygning";
	Sol = "Sol";
	["Milky Way"] = "Vintergatan";

-- SolarSytemBox
	["Solar System Browser"] = "Solsystemsutforskare";
	Star = "Stjärna";
	["Other bodies orbiting"] = "Andra kroppar i omloppsbana runt";
	["Bodies orbiting"] = "Kroppar i omloppsbana";

-- fovBox
	["FOV:"] = "FOV :";

-- asteroidBeltBox
	["Asteroid Belt"] = "Asteroidbälte";

-- infoBox
	["More Info"] = "Mer Info";

-- measureBox
	Measure = "Mått";
	["Geocentric coordinates:"] = "Geocentriska koordinater:";
	["RA:"] = "RA :";
	["Dec:"] = "Dec :";
	["Distance to Earth:"] = "Avstånd till Jorden :";
	ly = "lå";
	AU = "ua";
	km = "km";
	m = "m";

-- distanceBox
	Distances = "Avstånd";

-- MagnificationBox
	Magnification = "Förstoring";
	["Planets Magnified"] = "Förstorade Planeter";
	["Moons Magnified"] = "Förstorade Månar";
	["Earth and Moon Magnified"] = "Förstorad Jord och Måne";
	["Magnification disabled"] = "Förstoring avaktiverad";

-- virtualPadBox
	["Virtual Pad"] = "Virtuell Platta";

-- compassBox
	Compass = "Kompass";
	S = "S";
	W = "V";
	N = "N";
	E = "Ö";
	["Az:"] = "Az:";
	["Elev:"] = "Elev:";
	["planetarium mode"] = "planetariums läge";
	["navigation mode"] = "navigations läge";
	["Alt-azimuth mode enabled"] = "Läge Alt-Azimuthal aktivt";

}
