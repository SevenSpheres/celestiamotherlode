-- German translation of the Lua Edu Tools.
-- Ulrich Dickmann aka Adirondack <celestia-deutsch@gmx.net>
-- Localization revision: Feb 17, 2008

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools aktiviert";
	["Lua Edu Tools disabled"] = "Lua Edu Tools abgeschaltet";

-- timeBox
	h = "h"; -- SI symbol for "hour"
	["Rate:"] = "Rate:";
	["time stopped"] = "Zeit angehalten";
	["(paused)"] = "(Pause)";
	["Set Time"] = "Zeit einstellen";
	["Current Time"] = "Aktuelle Zeit";
	Jan = "Jan";
	Feb = "Feb";
	Mar = "Mrz";
	Apr = "Apr";
	May = "Mai";
	Jun = "Jun";
	Jul = "Jul";
	Aug = "Aug";
	Sep = "Sep";
	Oct = "Okt";
	Nov = "Nov";
	Dec = "Dez";

-- lightBox
	["Ambient Light Level:"] = "Streulicht:";

-- magnitudeBox
	["Magnitude limit:"] = "Magnituden-Grenze:";
	["AutoMag at 45°:"] = "AutoMag bei 45° :";
	A = "A"; 	-- AutoMag Button

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Galaxien-Helligkeit:";

-- renderBox
	["Set Render Options"] = "Anzeige-Optionen";
	["Show:"] = "Zeige :";
	["Orbits:"] = "Orbits :";
	["Labels:"] = "Bezeichnungen :";
	Planets = "Planeten";
	Stars = "Sterne";
	Galaxies = "Galaxien";
	Nebulae = "Nebel";
	["Open Clusters"] = "Offene Sternhaufen";
	Orbits = "Umlaufbahnen";
	Markers = "Markierungen";
	Constellations = "Sternbilder";
	Boundaries = "Sternbildgrenzen";
	Grid = "Himmelsraster";
	["Night Maps"] = "Nachttexturen";
	["Cloud Maps"] = "Wolken";
	Atmospheres = "Atmosphären";
	["Comet Tails"] = "Kometenschweife";
	["Eclipse Shadows"] = "Finsternisschatten";
	["Ring Shadows"] = "Ringschatten";
	Automag = "Auto-Magnitude";
	["Smooth Lines"] = "Glattere Umlaufbahnen";
	Moons = "Monde";
	Asteroids = "Asteroiden";
	Comets = "Kometen";
	Spacecraft = "Raumschiffe";
	Invisibles = "Unsichtbares";
	["Constell. in Latin"] = "Sternbilder in Latein";
	Locations = "Bezugspunkte u. Orte";
	["Star Style:"] = "Aussehen der Sterne:";
	Points = "Punkte";
	["Fuzzy Points"] = "Unscharfe Punkte";
	["Scaled Discs"] = "Skalierte Scheiben";

-- obsModeBox
	["Goto Sun"] = "Gehe zur Sonne";
	["Goto Selection"] = "Gehe zur Auswahl";
	["Follow Selection"] = "Auswahl folgen";
	["Track Selection"] = "Auswahl beobachten";
	["Follow"] = "Folgen: ";
	["Sync Orbit"] = "Synchr. Orbit ";
	["Chase"] = "Verfolgen";
	["Lock"] = "Verbinden";	
	["Track"] = "Beobachten: ";
	["Free flight"] = "Freier Flug";
	Sol = "Sonne";
	["Milky Way"] = "Milchstraße";

-- SolarSytemBox
	["Solar System Browser"] = "Sonnensystem-Browser";
	Star = "Stern";
	["Other bodies orbiting"] = "Umrundende Körper für";
	["Bodies orbiting"] = "Umrundende Körper für";

-- fovBox
	["FOV:"] = "FOV :";

-- asteroidBeltBox
	["Asteroid Belt"] = "Hauptgürtel";

-- infoBox
	["More Info"] = "Mehr Infos";

-- measureBox
	Measure = "Koordinaten";
	["Geocentric coordinates:"] = "Geozentrische Koordinaten:";
	["RA:"] = "Rektaszension:";
	["Dec:"] = "Deklination:";
	["Distance to Earth:"] = "Entfernung zur Erde:";
	ly = "LJ";
	AU = "AE";
	km = "km";
	m = "m";

-- distanceBox
	Distances = "Entfernungen";

-- MagnificationBox
	Magnification = "Vergrößerung";
	["Planets Magnified"] = "Planeten vergrößert";
	["Moons Magnified"] = "Monde vergrößert";
	["Earth and Moon Magnified"] = "Erde und Mond vergrößert";
	["Magnification disabled"] = "Vergrößerung abgeschaltet";

-- virtualPadBox
	["Virtual Pad"] = "Blickrichtung";

-- compassBox
	Compass = "Kompass";
	S = "S";
	W = "W";
	N = "N";
	E = "O";
	["Az:"] = "Az:";
	["Elev:"] = "Alt:";
	["planetarium mode"] = "Planetarium-Modus";
	["navigation mode"] = "Navigationsmodus";
	["Alt-azimuth mode enabled"] = "Alt-Azimut-Modus aktiviert";

}