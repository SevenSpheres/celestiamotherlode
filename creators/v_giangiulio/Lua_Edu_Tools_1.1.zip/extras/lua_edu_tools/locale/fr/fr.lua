-- French translation of the Lua Edu Tools.
-- Vincent <vince.gian@free.fr>
-- Localization revision: Jan 05, 2008

loc_str =
{

-- Lua_edu_tools
	["Lua Edu Tools enabled"] = "Lua Edu Tools activés";
	["Lua Edu Tools disabled"] = "Lua Edu Tools désactivés";

-- timeBox
	h = "h"; -- SI symbol for "hour"
	["Rate:"] = "Ratio :";
	["time stopped"] = "temps arrêté";
	["(paused)"] = "(en pause)";
	["Set Time"] = "Régler le Temps";
	["Current Time"] = "Temps actuel";
	Jan = "Jan";
	Feb = "Fév";
	Mar = "Mar";
	Apr = "Avr";
	May = "Mai";
	Jun = "Juin";
	Jul = "Juil";
	Aug = "Août";
	Sep = "Sep";
	Oct = "Oct";
	Nov = "Nov";
	Dec = "Déc";

-- lightBox
	["Ambient Light Level:"] = "Lumière Ambiante :";

-- magnitudeBox
	["Magnitude limit:"] = "Magnitude limite :";
	["AutoMag at 45°:"] = "AutoMag à 45° :";
	A = "A"; 	-- AutoMag Button

-- galaxyLightBox
	["Galaxy Light Gain:"] = "Gain de Luminosité :";

-- renderBox
	["Set Render Options"] = "Options d'Affichage";
	["Show:"] = "Afficher :";
	["Orbits:"] = "Orbites :";
	["Labels:"] = "Noms :";
	Planets = "Planètes";
	Stars = "Étoiles";
	Galaxies = "Galaxies";
	Nebulae = "Nébuleuses";
	["Open Clusters"] = "Amas ouverts";
	Orbits = "Orbites";
	Markers = "Marqueurs";
	Constellations = "Constellations";
	Boundaries = "Limites des Constell.";
	Grid = "Grille";
	["Night Maps"] = "Lumières Nocturnes";
	["Cloud Maps"] = "Nuages";
	Atmospheres = "Atmosphères";
	["Comet Tails"] = "Queues des Comètes";
	["Eclipse Shadows"] = "Ombres des Éclipses";
	["Ring Shadows"] = "Ombres des Anneaux";
	Automag = "Magnitudes Auto.";
	["Smooth Lines"] = "Anticrénelage";
	Moons = "Lunes";
	Asteroids = "Astéroïdes";
	Comets = "Comètes";
	Spacecraft = "Astronefs";
	Invisibles = "Invisibles";
	["Constell. in Latin"] = "Constell. en Latin";
	Locations = "Points de Repères";
	["Star Style:"] = "Style des étoiles :";
	Points = "Points";
	["Fuzzy Points"] = "Points flous";
	["Scaled Discs"] = "Échelle de disques";

-- obsModeBox
	["Goto Sun"] = "Aller au Soleil";
	["Goto Selection"] = "Aller à la Sélection";
	["Follow Selection"] = "Suivre la Sélection";
	["Track Selection"] = "Pister la Sélection";
	["Follow"] = "Suivre";
	["Sync Orbit"] = "Orbite Synchro";
	["Chase"] = "Chasser";
	["Lock"] = "Bloquer";	
	["Track"] = "Pister";
	["Free flight"] = "Vol libre";
	Sol = "Soleil";
	["Milky Way"] = "Voie Lactée";

-- SolarSytemBox
	["Solar System Browser"] = "Navigateur de Syst. Sol.";
	Star = "Étoile";
	["Other bodies orbiting"] = "Autres objets en orbite autour de";
	["Bodies orbiting"] = "Objets en orbite autour de";

-- fovBox
	["FOV:"] = "CdV :";

-- asteroidBeltBox
	["Asteroid Belt"] = "C. Astéroïdes";

-- infoBox
	["More Info"] = "Plus d'Info";

-- measureBox
	Measure = "Mesures";
	["Geocentric coordinates:"] = "Coordonnées géocentriques :";
	["RA:"] = "AD :";
	["Dec:"] = "Déc :";
	["Distance to Earth:"] = "Distance de la Terre :";
	ly = "al";
	AU = "ua";
	km = "km";
	m = "m";

-- distanceBox
	Distances = "Distances";

-- MagnificationBox
	Magnification = "Magnification";
	["Planets Magnified"] = "Planètes magnifiées";
	["Moons Magnified"] = "Lunes magnifiées";
	["Earth and Moon Magnified"] = "Terre et Lune magnifiées";
	["Magnification disabled"] = "Magnification désactivée";

-- virtualPadBox
	["Virtual Pad"] = "Pad Virtuel";

-- compassBox
	Compass = "Boussole";
	S = "S";
	W = "O";
	N = "N";
	E = "E";
	["Az:"] = "Az:";
	["Elev:"] = "Élév:";
	["planetarium mode"] = "mode planétarium";
	["navigation mode"] = "mode navigation";
	["Alt-azimuth mode enabled"] = "Mode Alt-Azimuthal activé";

}