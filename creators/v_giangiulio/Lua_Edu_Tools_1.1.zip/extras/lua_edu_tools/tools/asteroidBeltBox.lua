require "locale";

----------------------------------------------
-- Set initial values
----------------------------------------------
cAsteroidBelt = ctext;
asteroid_belt_first_tick = true;

asteroidBelt1 = celestia:find("Sol/Asteroid Belt 1")
asteroidBelt2 = celestia:find("Sol/Asteroid Belt 2")

asteroidBelt1:setradius(1e-5)
asteroidBelt2:setradius(1e-5)

----------------------------------------------
-- Set up and Draw the boxes
---------------------------------------------
asteroidBeltBox = CXBox:new()
	:init(0, 0, 0, 0)
	--:bordercolor({1, 1, 0, 1})
	--:fillcolor({1,1,0,.2})
	:movable(false)
	:attach(screenBox, width, height, 0, 0);

asteroidBeltBox.Customdraw = 
	function(this)
		textlayout:setfont(normalfont);
		textlayout:setfontcolor(cAsteroidBelt);
		textlayout:setpos(this.lb+25, this.tb-14);
		textlayout:println(_("Asteroid Belt"));
	end;

asteroidBeltCheck = CXBox:new()
		:init(0, 0, 0, 0)
		:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:textpos("center")
		:movetext(0, 9)
		:text("")
		:movable(false)
		:active(true)
		:attach(asteroidBeltBox, 100, 4, 35, 5)

asteroidBeltCheck.Customdraw =
	function(this)
		-- Set the initial state of the check-box from 'config.lua'.
		if asteroid_belt_first_tick and enable_asteroid_belt then
			asteroidBeltCheck.Action();
		end
		asteroid_belt_first_tick = false;
	end

asteroidBeltCheck.Action = (function()
		return
			function()
				asteroidBeltVisible = not(asteroidBeltVisible);
				if asteroidBeltVisible then
					asteroidBelt1:setradius(1.2e10);
					asteroidBelt2:setradius(1.3e10);
					asteroidBeltCheck.Text = "x";
				else
					asteroidBelt1:setradius(1e-5);
					asteroidBelt2:setradius(1e-5);
					asteroidBeltCheck.Text = "";
				end
			end
		end) ();