require "locale";

----------------------------------------------
-- Set initial values
----------------------------------------------
measureFrameWidth, measureFrameHeight = 200, 40;

cMeasure = ctext;
measure_first_tick = true;

----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
measureBox = CXBox:new()
	:init(0, 0, 0, 0)
	--:bordercolor({1, 1, 0, 1})
	--:fillcolor({1,1,0,.2})
	:movable(false)
	:attach(screenBox, width, height, 0, 0);

measureBox.Customdraw =
	function(this)
		textlayout:setfont(normalfont);
		textlayout:setfontcolor(cMeasure);
		textlayout:setpos(this.lb+25, this.tb-14);
		textlayout:println(_("Measure"));
	end;

measureCheck = CXBox:new()
		:init(0, 0, 0, 0)
		:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:textpos("center")
		:movetext(0, 9)
		:text("")
		:movable(false)
		:active(true)
		:attach(measureBox, 100, 4, 35, 5)

measureCheck.Customdraw =
	function(this)
		-- Set the initial state of the check-box from 'config.lua'.
		if measure_first_tick and enable_measure then
			measureCheck.Action();
		end
		measure_first_tick = false;

		if selection then
			if newselection then
				-- Get Distance to Earth, RA, and Dec.
				local sel = celestia:getselection();
				local dist_to_earth = celutil.get_dist_to_earth(sel);
				if dist_to_earth < 0 then
					disableCheckBox(measureCheck);
					cMeasure = cchetextoff;
				else
					enableCheckBox(measureCheck);
					cMeasure = ctext;
				end
			end
		else
			disableCheckBox(measureCheck);
			cMeasure = cchetextoff;
		end
	end

measureCheck.Action = (function()
		return
			function()
				measureFrame.Visible = not(measureFrame.Visible);
				if measureFrame.Visible then
					measureCheck.Text = "x";
				else
					measureCheck.Text = "";
				end
			end
		end) ();

measureFrame = CXBox:new()
	:init(0, 0, 0, 0)
	--:fillcolor({.2,.2,.6,.4})
	--:bordercolor({1,0,0,1})
	:movable(false)
	:clickable(true)
	:visible(false)
	:attach(screenBox, 0, height-measureFrameHeight-200, width-measureFrameWidth, 200)

measureFrame.Customdraw =
	function(this)
		if selection then
			local sel = celestia:getselection();
			local obs = celestia:getobserver();
			-- Get Distance to Earth, RA, and Dec.
			local dist_to_earth = celutil.get_dist_to_earth(sel);
			if dist_to_earth >= 0 then
				-- Display Distance to Earth, RA, and Dec.
				local ra,dec = celutil.get_ra_dec(sel);
				ra_str = format:deghms(ra);
				dec_str = format:degdms(dec);
				dist_to_earth_str = format:km(dist_to_earth);
				textlayout:setfont(normalfont);
				textlayout:setlinespacing(normalfont:getheight());
				textlayout:setfontcolor({0.7, 0.7, 1, 1});
				textlayout:setpos(this.lb, this.tb-10);
				textlayout:println(_("Geocentric coordinates:"));
				textlayout:println(_("RA:")..' '..ra_str);
				textlayout:println(_("Dec:")..' '..dec_str);
				textlayout:println(_("Distance to Earth:")..' '..dist_to_earth_str);
			end
		end
		measureFrame:attach(screenBox, 0, height-measureFrameHeight-200, width-measureFrameWidth, 200);
	end;