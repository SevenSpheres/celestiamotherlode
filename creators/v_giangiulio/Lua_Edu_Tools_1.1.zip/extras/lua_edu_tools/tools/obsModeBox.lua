require "locale";

----------------------------------------------
-- Define local function
----------------------------------------------
local getObsMode = function()
	local obs = celestia:getobserver();
	local obsCoordSys = obs:getframe():getcoordinatesystem();
	local obj = obs:getframe():getrefobject();
	return obsCoordSys, obj;
end

----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
obsModeBox = CXBox:new()
	:init(0, 0, 0, 0)
	--:bordercolor({1, 1, 0, 1})
	--:fillcolor({1,1,0,.2})
	:movable(false)
	:attach(screenBox, width, height, 0, 0);

obsModeBox.Customdraw =
	function(this)
		-- Display the observer Frame of reference.
		local obsCoordSys, obj = getObsMode();
		if not(empty(obj)) then
			objname = getlocalname(obj);
			if obsCoordSys == "ecliptic" then
				obsMode = _("Follow")..' '..objname;
			elseif obsCoordSys == "planetographic" or obsCoordSys == "bodyfixed" then
				obsMode = _("Sync Orbit")..' '..objname;
			elseif obsCoordSys == "chase" then
				obsMode = _("Chase")..' '..objname;
			elseif obsCoordSys == "lock" then
				obsMode = _("Lock")..' '..objname..' -> '..getlocalname(obs:getframe():gettargetobject());
			else
				obsMode = _("Free flight");
			end
		else
			obsMode = _("Free flight");
		end
		textlayout:setfont(normalfont);
		textlayout:setfontcolor(ctext);
		textlayout:setpos(this.lb+7, this.tb-21);
		textlayout:println(obsMode);
	end;

gotoSunButton = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	--:fillcolor({1,1,0,.2})
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 6)
	:text(_("Goto Sun"))
	:movable(false)
	:active(true)
	:attach(obsModeBox, 8, 90, 8, 30)

gotoSunButton.Action = (function()
	return
		function()
			local obs = celestia:getobserver();
			local sun = celestia:find("Sol");
			celestia:select(sun);
			obs:follow(sun);
			obs:goto(sun);
		end
	end) ();

gotoSelButton = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	--:fillcolor({1,1,0,.2})
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 6)
	:text(_("Goto Selection"))
	:movable(false)
	:active(true)
	:attach(obsModeBox, 8, 70, 8, 50)

gotoSelButton.Action = (function()
	return
		function()
			local obs = celestia:getobserver();
			local sel = celestia:getselection();
			if not(empty(sel)) then
				obs:follow(sel);
				obs:goto(sel);
			end
		end
	end) ();

followButton = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	--:fillcolor({1,1,0,.2})
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 6)
	:text(_("Follow Selection"))
	:movable(false)
	:active(true)
	:attach(obsModeBox, 8, 50, 8, 70)

followButton.Action = (function()
	return
		function()
			local obs = celestia:getobserver();
			local sel = celestia:getselection();
			if not(empty(sel)) then
				obs:follow(sel);
			end
		end
	end) ();

synchOrbButton = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	--:fillcolor({1,1,0,.2})
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 6)
	:text(_("Sync Orbit"))
	:movable(false)
	:active(true)
	:attach(obsModeBox, 8, 30, 8, 90)

synchOrbButton.Action = (function()
	return
		function()
			local obs = celestia:getobserver();
			local sel = celestia:getselection();
			if selection then
				obs:synchronous(sel);
			end
		end
	end) ();

trackButton = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	--:fillcolor({1,1,0,.2})
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 6)
	:text(_("Track Selection"))
	:movable(false)
	:active(true)
	:attach(obsModeBox, 8, 10, 8, 110)

trackButton.Customdraw =
	function(this)
		local obs = celestia:getobserver();
		if trackedObj ~= obs:gettrackedobject() then
			-- Status of 'Track' function has changed.
			trackedObj = obs:gettrackedobject();
			if not(empty(trackedObj)) then
				-- Some objects may have long names; let's limit the
				-- number of chars to respect the width of the 'Track' button.
				trackedObjName = limitStrWidth(getlocalname(trackedObj), normalfont, 120-normalfont:getwidth(_("Track")));
				trackButton.Text = _("Track")..' '.._(trackedObjName);
				trackButton.Bordercolor = cbubordon;
				trackButton.Fillcolor = {cbubordon[1]*2/3, cbubordon[2]*2/3, cbubordon[3]*2/3, cbubordon[4]/2};
			else
				trackButton.Text = _("Track Selection");
				trackButton.Bordercolor = cbubordoff;
				trackButton.Fillcolor = nil;
			end
		end
	end;

trackButton.Action = (function()
	return
		function()
			local obs = celestia:getobserver();
			local sel = celestia:getselection();
			if not(empty(trackedObj)) or (empty(trackedObj) and empty(sel)) then
				-- Stop tracking the current tracked object.
				obs:track(nil);
			else
				-- Track the current selection.
				obs:track(sel);
			end
		end
	end) ();