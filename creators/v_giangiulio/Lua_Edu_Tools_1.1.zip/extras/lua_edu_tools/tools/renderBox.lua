require "locale";

----------------------------------------------
-- Define local functions
----------------------------------------------
local setLabelElementName = function(str)
	if str == "Constell. in Latin" then
		strl = "i18nconstellations";
	else
		strl = string.lower(string.gsub(str, " ", ""));
	end
	return strl;
end

local setRenderElementName = function(str)
	strr = string.lower(string.gsub(str, " ", ""));
	return strr;
end

local setCheckBoxText = function(box, k, flag)
	if flag then
		box[k].Text = "x";
	else
		box[k].Text = "";
	end
end

local makeClassBox = function(classBox, k, v, leftOffset)
	classBox = CXBox:new()
		:init(0, 0, 0, 0)
		--:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:movetext(0, 8)
		:text(_(v))
		:movable(false)
		:attach(renderFrame, leftOffset+15, renderFrameHeight-25-(20*k), renderFrameWidth-leftOffset-100, 14+(20*k))
end

local makeCheckBox = function(checkBox, k, leftOffset)
	checkBox[k] = CXBox:new()
		:init(0, 0, 0, 0)
		:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:textpos("center")
		:movetext(0, 9)
		:text("")
		:movable(false)
		:active(true)
		:attach(renderFrame, leftOffset, renderFrameHeight-25-(20*k), renderFrameWidth-leftOffset-11, 14+(20*k))
end

local setStarStyleRadioButtons = function(s)
	starStyleRadioButton1.Text = "";
	starStyleRadioButton2.Text = "";
	starStyleRadioButton3.Text = "";
	if s == "point" then
		starStyleRadioButton1.Text = "x";
	elseif s == "fuzzy" then
		starStyleRadioButton2.Text = "x";
	elseif s == "disc" then
		starStyleRadioButton3.Text = "x";
	end
end

----------------------------------------------
-- Set initial values
----------------------------------------------
-- Set the height of the Render Options window.
local nrender = table.getn(renderclass);
local norbit = table.getn(orbitclass);
local nlabel = table.getn(labelclass);
local nmax = math.max(nrender, norbit, nlabel);
renderFrameWidth, renderFrameHeight = 430, 40 + (20 * nmax);
if math.abs(nrender - nlabel) < 5 then
	renderFrameHeight = renderFrameHeight + 20 * (5 - math.abs(nrender - nlabel));
end

renderLeftOffset = 20;
orbitLeftOffset = 180;
labelLeftOffset = 290;
if nrender < nlabel then
	starStyleLeftOffset = renderLeftOffset - 5;
else
	starStyleLeftOffset = labelLeftOffset - 5;
end

renderCheckBox = {};
orbitCheckBox = {};
labelCheckBox = {};
rendertable = {};
orbittable = {};
labeltable = {};

----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
renderBox = CXBox:new()
	:init(0, 0, 0, 0)
	--:bordercolor({1, 1, 0, 1})
	--:fillcolor({1,1,0,.2})
	:movable(false)
	:attach(screenBox, width, height, 0, 0);

setRenderButton = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	--:fillcolor({1,1,0,.2})
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 6)
	:text(_("Set Render Options"))
	:movable(false)
	:active(true)
	:attach(renderBox, 8, 4, 8, 3)

setRenderButton.Action = (function()
	return
		function()
			renderFrame.Visible = not(renderFrame.Visible);
			if renderFrame.Visible then
				renderFrame:orderfront();
				setRenderButton.Bordercolor = cbubordon;
				setRenderButton.Fillcolor = {cbubordon[1]*2/3, cbubordon[2]*2/3, cbubordon[3]*2/3, cbubordon[4]/2};
			else
				setRenderButton.Bordercolor = cbubordoff;
				setRenderButton.Fillcolor = nil;
			end
		end
	end) ();

renderFrame = CXBox:new()
	:init(0, 0, 0, 0)
	:fillcolor(csetbofill)
	--:bordercolor(cbubordoff)
	:movable(false)
	:visible(false)
	:attach(screenBox, (width-renderFrameWidth)/2+50, height-renderFrameHeight-2, (width-renderFrameWidth)/2-50, 2);

renderFrame.Customdraw =
	function(this)
		-- We start displaying the text on the second tick in order to
		-- hide a possible uggly resizing of the box during the first tick.
		if render_firstTickDone then
			textlayout:setfont(normalfont);
			textlayout:setfontcolor(ctext);
			textlayout:setpos(this.lb+renderLeftOffset, this.tb-20);
			textlayout:println(_("Show:"));
			textlayout:setpos(this.lb+orbitLeftOffset, this.tb-20);
			textlayout:println(_("Orbits:"));
			textlayout:setpos(this.lb+labelLeftOffset, this.tb-20);
			textlayout:println(_("Labels:"));
		else
			render_firstTickDone = true;
		end
		renderFrame:attach(screenBox, (width-renderFrameWidth)/2, height-renderFrameHeight-2, (width-renderFrameWidth)/2, 2);
	end;

renderCloseButton = CXBox:new()
	:init(0, 0, 0, 0)
	--:fillcolor(csetbofill)
	:bordercolor(cbubordoff)
	:textfont(normalfont)
	:textcolor(cclotext)
	:textpos("center")
	:movetext(0, 9)
	:text("x")
	:movable(false)
	:active(true)
	:attach(renderFrame, renderFrameWidth-13, renderFrameHeight-13, 2, 2);

renderCloseButton.Action = (function()
	return
		function()
			setRenderButton.Action();
		end
	end) ();

for k, v in ipairs(renderclass) do

	makeClassBox(renderClassBox, k, v, renderLeftOffset);
	makeCheckBox(renderCheckBox, k, renderLeftOffset);

local vv, kk = v, k;

	renderCheckBox[k].Customdraw =
		function(this)
			vr = setRenderElementName(vv);
			renderFlag = celestia:getrenderflags()[vr];
			setCheckBoxText(renderCheckBox, kk, renderFlag)
		end;

	renderCheckBox[k].Action = (function()
		return
			function()
				vr = setRenderElementName(vv);
				renderFlag = celestia:getrenderflags()[vr];
				renderFlag = not(renderFlag);
				rendertable[vr] = renderFlag;
				celestia:setrenderflags(rendertable);
			end
		end) ();
	end

for k, v in ipairs(orbitclass) do

	if v == "Spacecraft" then
		makeClassBox(orbitClassBox, k, v, orbitLeftOffset);
	else
		makeClassBox(orbitClassBox, k, v.."s", orbitLeftOffset);
	end
	makeCheckBox(orbitCheckBox, k, orbitLeftOffset);

local vv, kk = v, k;

	orbitCheckBox[k].Customdraw =
		function(this)
			orbitFlag = celestia:getorbitflags()[vv];
			setCheckBoxText(orbitCheckBox, kk, orbitFlag);
		end;

	orbitCheckBox[k].Action = (function()
		return
			function()
				orbitFlag = celestia:getorbitflags()[vv];
				orbitFlag = not(orbitFlag);
				orbittable[vv] = orbitFlag;
				celestia:setorbitflags(orbittable);
			end
		end) ();

	end

for k, v in ipairs(labelclass) do

	makeClassBox(labelClassBox, k, v, labelLeftOffset)
	makeCheckBox(labelCheckBox, k, labelLeftOffset)

local vv, kk = v, k;

	labelCheckBox[k].Customdraw =
		function(this)
			vl = setLabelElementName(vv);
			labelFlag = celestia:getlabelflags()[vl];
			if vv == "Constell. in Latin" then
				setCheckBoxText(labelCheckBox, kk, not(labelFlag))
			else
				setCheckBoxText(labelCheckBox, kk, labelFlag)
			end
		end;

	labelCheckBox[k].Action = (function()
		return
			function()
				vl = setLabelElementName(vv);
				labelFlag = celestia:getlabelflags()[vl];
				labelFlag = not(labelFlag);
				labeltable[vl] = labelFlag;
				celestia:setlabelflags(labeltable);
			end
		end) ();
	end

starStyleBox = CXBox:new()
	:init(0, 0, 0, 0)
	--:bordercolor({1, 1, 0, 1})
	--:fillcolor({1,1,0,.2})
	:movable(false)
	:attach(renderFrame, starStyleLeftOffset, 4, renderFrameWidth - starStyleLeftOffset - 100 , renderFrameHeight - 4 - 90);

starStyleBox.Customdraw =
	function(this)
		textlayout:setfont(normalfont);
		textlayout:setfontcolor(ctext);
		textlayout:setpos(this.lb+5, this.tb-16);
		textlayout:println(_("Star Style:"));
		textlayout:setpos(this.lb+25, this.tb-39);
		textlayout:println(_("Points"));
		textlayout:setpos(this.lb+25, this.tb-59);
		textlayout:println(_("Fuzzy Points"));
		textlayout:setpos(this.lb+25, this.tb-79);
		textlayout:println(_("Scaled Discs"));

		if starStyle ~= celestia:getstarstyle() then
			starStyle = celestia:getstarstyle();
			setStarStyleRadioButtons(starStyle);
		end
	end;

starStyleRadioButton1 = CXBox:new()
		:init(0, 0, 0, 0)
		:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:textpos("center")
		:movetext(0, 9)
		:text("")
		:movable(false)
		:active(true)
		:attach(starStyleBox, 5, 90-30-11, 100-5-11, 30)

starStyleRadioButton2 = CXBox:new()
		:init(0, 0, 0, 0)
		:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:textpos("center")
		:movetext(0, 9)
		:text("")
		:movable(false)
		:active(true)
		:attach(starStyleBox, 5, 90-50-11, 100-5-11, 50)

starStyleRadioButton3 = CXBox:new()
		:init(0, 0, 0, 0)
		:bordercolor(cbubordoff)
		--:fillcolor({1,1,0,.2})
		:textfont(normalfont)
		:textcolor(cbutextoff)
		:textpos("center")
		:movetext(0, 9)
		:text("")
		:movable(false)
		:active(true)
		:attach(starStyleBox, 5, 90-70-11, 100-5-11, 70)

starStyleRadioButton1.Action = (function()
		return
			function()
				celestia:setstarstyle("point");
			end
		end) ();

starStyleRadioButton2.Action = (function()
		return
			function()
				celestia:setstarstyle("fuzzy");
			end
		end) ();

starStyleRadioButton3.Action = (function()
		return
			function()
				celestia:setstarstyle("disc");
			end
		end) ();

setStarStyleRadioButtons();
