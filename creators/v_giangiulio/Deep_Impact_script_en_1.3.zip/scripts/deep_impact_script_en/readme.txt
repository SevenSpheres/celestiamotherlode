**********************************************************************
* 		Tempel 1 / Deep Impact : the encounter
* 
* 		Original Scripts v1.3 by Vincent Giangiulio
* 		Jan 2006
* 		contact : vince.gian@free.fr
***********************************************************************

The script is divided into 3 parts :
	- CHAPTER 1		: TEMPEL 1 				(about 4' 30)
	- CHAPTER 2		: DEEP IMPACT		(about 3' 00)
	- CHAPTER 3		: THE ENCOUNTER	(about 4' 30)
The whole script is about 12 minutes long

---------------------------------------------------------------------------
1- INSTALLING THE PACKAGE
---------------------------------------------------------------------------

************************************************************************************************************************************
You must have the Deep Impact addon by Jestr. You can download it on the Celestia Motherlode website :
http://celestiamotherlode.net/catalog/spacecraft.php
- There might be a bug in the comet's orbit : to delete it, you can open the original Temple1.xyz file with your favorite text editor (Notepad, ...) and delete the last line. (The Temple 1.xyz file is in your "Celestia/extras/......./DeepImpact/data" folder)
************************************************************************************************************************************

- Unzip the Deep_Impact_script_en_1.3.zip file into your main Celestia folder (it won't delete any of your existing script files)
	for Windows/winzip users:	-> Copy the Deep_Impact_script_en_1.3.zip file and paste it into your main Celestia folder
											-> Right-click on the file
											-> Choose the "Extract here" option

- Desactivate all the XXXXX.ssc file concerning Tempel 1 and other comets like the DIRL_comets.ssc file. You can put these files in an extras_no folder or simply rename them in  XXXXXXX.ssc.no.

---------------------------------------------------------------------------
2- RUNNING THE SCRIPT
---------------------------------------------------------------------------

- Run Celestia
- Open the "Celestia/scripts/deep_impact_script_en/DEEP_IMPACT.celx" file from the "File>Open Script..." Menu

- No more need to set the rendering orbits options since the "celestia:setorbitflags{}" celx command does it for you :-)

---------------------------------------------------------------------------
3- EDITING THE TEXTURES LOADING TIME
---------------------------------------------------------------------------

There is a "loading textures function" with a preview at the beginning of the script (since meshes have also to be loaded, the preloadtex function is not sufficient for many graphic cards). You can increase (or decrease) the loading time of the textures by editing the DEEP_IMPACT.celx file. You can open it  with your favorite text editor (Notepad, ...) and modify the number after the "duration" command in the "Textures loading"  part :

	print { origin "bottomleft"  row -5  column 1  duration XX
	...
	...
	wait { duration XX }

---------------------------------------------------------------------------
4- Licences
---------------------------------------------------------------------------

You can modify and use this script as you want. You only have to keep these references in your readme.txt file :

Original script by Vincent GIANGIULIO : vince.gian@free.fr
Deep Impact Addon  by Jestr : jestr@ntlworld.com
Information about the Deep Impact mission : 
	http://deepimpact.umd.edu/
	
The commercial use of the original or modified script is not allowed.

@+
Vincent