Install instructions

Unzip into Celestia extras directory.

Look for "RCW 79"

JLL


Image Credit:  E. Churchwell (Univ. Wisconsin-Madison) et al., JPL-Caltech, NASA 
http://www.spitzer.caltech.edu/Media/mediaimages/sig/sig05-001.shtml


Texture optimisation by Andrea and ElChristou

Nebula description and Stars positions based on
# Triggered massive-star formation on the borders of Galactic Hii regions ?
# II. Evidence for the collect and collapse process around RCW 79
# A. Zavagno1, L. Deharveng1, F. Comer�on2, J. Brand3, F. Massi4, J. Caplan1, and D. Russeil1
# 1 Laboratoire d'Astrophysique de Marseille, 2 place Le Verrier, 13248 Marseille Cedex 4, France
# 2 European Southern Observatory, Karl-Schwarzschild-Strasse 2, D-85748 Garching, Germany
# 3 INAF-Istituto di Radioastronomia, Via Gobetti 101, 40129 Bologna, Italy
# 4 INAF-Osservatorio Astrofisico di Arcetri, Largo E. Fermi, 5, 50125 Firenze, Italy
# 
