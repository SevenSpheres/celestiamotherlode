Install instructions

Unzip into Celestia extras directory.

Look for "M2-9"

JLL

Textures are based on Images from : 
Bruce Balick (University of Washington), 
Vincent Icke (Leiden University, The Netherlands), 
Garrelt Mellema (Stockholm University), 
and NASA
http://hubblesite.org/newscenter/newsdesk/archive/releases/1997/38/
