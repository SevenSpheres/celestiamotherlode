Install instructions

Unzip into Celestia extras directory.

Look for "ETA car"

JLL

The image from wich the texture was created is from NASA

NGC3372 credit 
"National Optical Astronomy Observatory/Association of Universities for Research in Astronomy/National Science Foundation"

STC and DSC based on Selden's one.