Install instructions

Unzip into Celestia extras directory.

Look for "M57"

JLL

Image Credit:  	 NASA and The Hubble Heritage Team (STScI/AURA)

DSC based on AstroBoy's one