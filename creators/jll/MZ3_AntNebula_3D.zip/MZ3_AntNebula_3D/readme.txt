Install instructions

Unzip into Celestia extras directory.

Look for "MZ3 center"

JLL


Object Name:  	Mz 3; Menzel 3, The "Ant Nebula"
Object Description: 	Planetary Nebula
Position (J2000): 	
	R.A. 16h 17m 17.35s
	Dec. -51� 59' 00"
Constellation: 	Norma
Distance: 	About 900 pc (3000 light-years)
Dimensions: 	The object is roughly 1 arcminute or 0.5 pc (1.6 light-years) long. 

ImageCredit:  	NASA, ESA and The Hubble Heritage Team (STScI/AURA)

3D specifications : 
based on Miguel Santander Garc�a's work "The Multiple Outflows of Mz3"
ASYMMETRIC PLANETARY NEBULAE III 
http://www.astro.washington.edu/balick/APN/APN_talks_posters.html
