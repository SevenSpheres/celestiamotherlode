Install instructions

Unzip into Celestia extras directory.

Look for "Helix"

JLL

The image from wich the texture was created is a from NASA
NASA, ESA, C.R. O'Dell (Vanderbilt University), M. Meixner and P. McCullough (STScI)

Object Name:  Helix Nebula, NGC 7293    
Object Description:  Planetary Nebula    
Position (J2000):  R.A. 22h 29m 48.20s
Dec. -20� 49' 26.0" 
Constellation: Aquarius 
Distance: About 650 light-years (200 parsecs) 
Dimensions: The image is roughly 27 arcminutes (5.1 light-years or 1.6 parsecs) across.

 