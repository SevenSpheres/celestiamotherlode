Install instructions

Unzip into Celestia extras directory.

Look for "He 2-104 center/He 2-104 Nebula"

JLL




http://ircatalog.gsfc.nasa.gov/cio/browse/14browsen.html

NAME              RA             DEC    LAMBDA    FLUX  BEAM  BIBLIO      IRAS     IRAS  IRAS
                h  m  s        o  '  "                                    NAME     FLUX  CODE
HE2- 104       14 08 33      -51 12 19

1 pc = 3.26 ly.

Distance 800 pc = 2608 ly
Diameter 0.41 pc = 1.3366 ly
1�=4min 1'=4s 1"=0.07 s
24h d'ascension droite=360 degres
1 h d'ascension droite=15 degres
1 minute d'ascension droite=15'
1 seconde d'ascension droite=15"


http://www.hs.uni-hamburg.de/DE/Ins/Per/Kohoutek/kohoutek/He2-104/He2-104p/He2-104p.html

Abstract:
The nebula He 2-104 (RA1950=14h08m33.5s, D1950= -51o12'19.1'', PK 315+9o1, PN G 315.4+09.4), 
known as the Southern Crab since the discovery of its large bipolar structure by Schwarz et al.(1989), 
originally discovered in 1964 by Henize (1967) and classified also as a symbiotic star (SS, Allen, 1984).

Image Credits: 
Romano Corradi, Instituto de Astrofisica de Canarias, Tenerife, Spain; 
Mario Livio, Space Telescope Science Institute, Baltimore, Md.; 
Ulisse Munari, Osservatorio Astronomico di Padova-Asiago, Italy; 
Hugo Schwarz, Nordic Optical Telescope, Canarias, Spain; 
and NASA