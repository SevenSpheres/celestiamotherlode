AUTHOR:
=======

Boxx (aka Box, Boxie...) bo.mars@free.fr (c) Copyright 2008
Mars-POV Project = http://mars-pov.frenchboard.com/portal.htm

IMPORTANT NOTE:
---------------
There is a funny surprise hidden somewhere onto this 3D terrain !
If you find it, send me a nice point of view of it (CTRL+INS then paste the "cel://" link into an e-mail to me).
If you are not lazy but you really cannot find it, ask for a clue and you will get one... maybe ;)


How to Install and Use:
=======================

- After unzipping, simply copy the "(LVL4)_9_8" folder as a subfolder of "extra" in Celestia
- Run Celestia, then go to Mars
- If you really do not see the added model, look for "ChandorChasma(L4_9_8)", select it and play!
(tested on Celestia 1.5.1 with Win-XP/SP2 + NVIDIA, more details if needed with bug report)

CREDITS:
========

- Relief = MOLA/NASA Data : megt00n270hb.img
- Textures LVL4 : Virtual Texture (VT) by John van Vliet (Celestia fellow) http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=240
- Textures LVL7 by Cartrite (Celestia fellow)http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=133
> THEMIS Data : (NASA/JPL/Arizona State University)
> THEMIS Public Data Releases, Planetary Data System node, Arizona State University, <http://themis-data.asu.edu>
- 3D surprise taken on a www.archibase.net, free unsigned 3DS model modified by me !
