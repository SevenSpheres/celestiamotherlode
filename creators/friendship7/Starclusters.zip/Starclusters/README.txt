To install, move the folder to the "extras" directory. To uninstall, simply delete the folder installed. This addon represents 8 star clusters including Pismis 24, 1806-20, and Trumpler 16. Note: This was designed and created using Celestia 1.6.0., so it may not work on other Celestia versions.

Star Cluster info:

Trumpler 14: 
 Stars: 38
 Hypergiants: 2
 Radius: 4 ly
 Distance: 8550
 Constellation: Carina

Trumpler 16: 
 Stars: 18
 Hypergiants: 2
 Radius: 4 ly
 Distance: 8545
 Constellation: Carina

Pismis 24: 
 Stars: 19
 Hypergiants: 2
 Radius: 5 ly
 Distance: 8150
 Constellation: Scorpius

Collinder 469: 
 Stars: 25
 Hypergiants: 0
 Radius: 5.5 ly
 Distance: 10000
 Constellation: Sagittarius
 
Markarian 38: 
 Stars: 15
 Hypergiants: 0
 Radius: 6 ly
 Distance: 10000
 Constellation: Sagittarius

1806-20: 
 Stars: 19
 Hypergiants: 3
 Radius: 5.5 ly
 Distance: 39000
 Constellation: Sagittarius

Quintuplet Cluster: 
 Stars: 40 (roughly)
 Hypergiants: 5+
 Radius: 5 ly
 Distance: 27000
 Constellation: Sagittarius

Central Star Cluster: 
 Stars: About 35 included
 Hypergiants: 1?
 Radius: 3-4 ly
 Distance: 27000
 Constellation: Sagittarius