
Simply unzip this zip file into your extras or Addons directory. Linux users, place file in /usr/share/celestia/extras

This add-on contains data of a model of the recently discovered system orbiting around TAU Cet.

Rev. 1.0 - 01/19/2013
First revision.

References:
- en.wikipedia.org/wiki/Tau_Ceti

David P.
