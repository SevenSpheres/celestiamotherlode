The Proxima Centauri Solar System - by Michael Kilderry

HOW TO INSTALL AND USE:
(Note that these instructions are written for installing this addon onto the Windows version of Celestia, and that the steps may differ for other systems eg Linux, OSX etc.)

1. Unzip Proxima1.zip into Celestia's extras folder. (I think it's called the CelestiaResources directory on Mac computers)

2. Run Celestia.

3. Go to the star Proxima Centauri by hitting the enter key to make a search box appear and type in 'Proxima'. Hit enter again to make the search box dissapear and then press G to go to that location.

4. Windows users can now use the Solar System Browser (located under the Navigation panel) to go to any world they want in this addon. Mac users will have to use the search box again by pressing enter like before and typing in the names of any of the following worlds:

Arctarcticus
Aresca
Asjuill
Dat
Demeter
Dis
Epi
Gelidian
Haperak
Kankymede
Kretus
Lunarcticus
Radia
Starlight
Sulcia
Unterra

After typing in any of the above names hit the enter key to make the search box dissapear again and then press the G key to go to the location.

 * * *

I hope the instructions were clear enough.
This addon was designed for Celestia 1.4.0 pre6, it should run on earlier versions though.

OTHER ADDONS BY ME:

The Lera Solar System - My first addon attempt, available for download on the Celestia Motherlode.

PLANNED FUTURE ADDONS:

Proxima Centauri: Aurora and Poseidon - An extension to this addon, including two gas giants and their retinue of moons

Rigel Kenaturus A&B - Another fictional solar system, although this addon may be moved to a different binary star system, as there are already two other addons based around this particular binary system.

2k Textures For Several Large KBO's - Will include textures for Ixion, Varuna, Orcus and 2002 AW197 and possibly more.

 * * *

You can also visit my addons forum at:

http://www.phpbbserver.com/phpbb/index.php?mforum=mkcelestia

You can discuss any of my addons here, and I plan on putting up more information about them here when I get the chance.

Well, that's about it, enjoy my addons!

- Michael 
