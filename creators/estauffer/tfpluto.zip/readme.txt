Installation: Simply Unzip or copy/paste to the celestia "extras" folder. That's it!

Version 1.3
Added Normal Map.
Adjusted atmosphere parameters.
Changed cloud map.
Fixed filenames.
Changed city names to something more generic.
Colorized the night map.
Adjusted colors of the main texture.
Streamlined the appearance of the SSC code in the main SSC file.

Version: 1.2
Changed surface maps.
Made the night map appear less urbanized and added city location names.
Took advantage of the new atmosphere code.

Version: 1.1
Attempted to fix directory problems.

Version: 1.0
Initial Release.

Legal: Credit for the night map goes to Thomas Guilpain and the people at
www.theforce.net/scifi3d.

Contact me at tornadorip1984@yahoo.com if you need help or have any questions,
comments, or criticisms. :)