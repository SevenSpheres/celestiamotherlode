Installation:
Unzip the "earthrng" folder into the "extras" directory in the main "celestia" folder.
That's it!

Notes:
Should be compatible with celestia 1.4.0 and beyond. Feel free to edit the earthrng.ssc
file to switch to the other set of rings provided with the default rings.

Version:
1.2
Increased transparancy of rings by 2%.
Adjusted the main rings to better reflect Earth's Roche Limit.
Randomized some of the numbers.

1.1
Added detail to the rings.
Applied transparency to the whole of the ring system, not just part of it, for greater
realism.

1.0
Initial Release

Legal:
Public Domain.

Questions, comments?
Email me: tornadorip1984@yahoo.com