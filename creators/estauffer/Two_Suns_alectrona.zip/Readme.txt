Installation: Unzip to default celestia/extra's directory. that's it!

For Advanced Users: If you have other addons that are in the Sol system
	that you want to port over to this addon's new Sol system, here's
	what you can do:
		Navigate to the addon you want to port.
		Open your addon's .ssc file with a text editing program.
		Select ALL of the text and copy it to the clipboard.
		Unselect the text and go to the very bottom.
		Make a few new empty lines, and then paste the copied data
			(Optionally, you can create a divider line consisting
			of #'s to differentiate between the addon in Sol and
			the new one in this system)
		Change all "Sol" entries in the new text to "SSB2"
			(If your text editing program has a mass "find and
			replace" feature, you can paste your text into an empty
			text file, use the find-and-replace to change all "Sol"
			to "SSB2". If it gives you the option to match case
			and/or whole word only, use those to minimize errors)
		Save the edits.
	This method allows you to have your addon in BOTH the Sol system
		And this new system without having to copy/past your entire
		addon into the alectrona folder. :)
		This method works best if you have a dedicated folder for
		all addons that affect the default Sol system.

Details: A second sun orbiting Sol.

Version 2.0
Revamped the second sun:
* Changed Name
* New Spectral Type
* New AbsMag value
* Modified orbit
	The new specs for the second sun were obtained from an online
		calculator where, through trial and error, the best
		COMBINED Mass/Luminosity of the two suns that would
		preserve the Orbit times of all the objects in the system
		even though the SemiMajorAxes were increased to reflect
		the new Habitable Zone.
Increased the distance of the system in light years from Sol from
	1.05 to 2.1, to eliminate overlap with default Sol system.


Version 1.1
Changed orbit distance and orbit time of Apollo
Changed Apollo's spectral type slightly
Added Secondary Solar System containing realistic star orbit model
	next to the default Solar system, 1.05 light years away,
	close enough to maintain the basic shape of constellations,
	yet far enough to minimize overlapping. It is in the
	constellation of Opiuchus. (Cassini and Galileo couldn't
	be included due to an apparent glitch in celestia.)

Version 1.0
Initial release

Legal: This addon uses V2 of the GNU General Public License.