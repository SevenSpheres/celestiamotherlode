Installation:
Unzip the "DEL Tri" folder into the "extras" folder in the main "celestia" folder.
That's it!

------------------------------------------------------------------------------

Additional installation for advanced Celestia users (skip this part if you do not
know how to edit Celestia files. This is completely OPTIONAL! It is not required
that you do this.)
(UPDATE: As of version 1.2 of this addon, the .stc included now has the fictional
	names for the two stars, at the end of the multiple names list for each
	star. This "additional installation" is really just for those who want to
	see the fictional names show up as the default names when they press "b"
	to toggle star labels in Celestia. The old values are included.)
(UPDATE 2: As of version 1.3, the star info is in a separate file called
	"deltri_stars.txt".)

Go into the "data" folder in the main "celestia" folder, and save a copy of the
"spectbins.stc" file in a easy to remember location. Now open the original
"spectbins.stc" file in a basic text edition program, such as notepad or wordpad
(in windows). Use the "find" feature to locate the information about the "DEL Tri"
system. Delete the information about that solar system, taking care not to delete
any other information, and copy and paste ALL of the information provided in the
"deltri_stars.txt" file into the "spectbins.stc" file where the old information
once was (do not copy the dotted lines, and don't forget to comment out ( # ) or
delete the "deltri.stc" file in the "deltri" folder).

------------------------------------------------------------------------------


Notes:
Designed for Celestia 1.6.1, but may be compatible with Celestia 1.5.0, and
maybe a few later versions.

Since this add-on was designed with OpenGL 2.0 in mind, the textures for Belle
Hades may seem a bit dark. This is intentional, since the OpenGL 2.0 Mie atmospheres
perform a "brightening" effect on the planet's textures (day-side only).

Also, the normal maps were made using the GIMP's normal map plugin, which, due
to a limitation, does not account for spherical texture mapping. As a result,
the normal maps will render incorrectly at the poles, but will still work in Celestia.
My apologies for any inconvenience.

Synopsis:
The Delta Trianguli system was formed about 1.9 billion years ago, and has four
planets, one of which is habitable, named Belle Hades. Belle Hades is a small
world that has astonishingly managed to evolve complex life and a civilization
in a much shorter time frame than Earth. For a long time, Belle Hades was oppressed
by a secret, brutal alien regime, until finally, against all odds, they managed
to team up with Earth and overthrow the aliens. Now Belle Hades is a free planet,
and is looking forward to peaceful relations with Earth.


Legal:
This add-on will now be licensed for private use only.
Credit for Belle Hades' night map goes to Thomas Guilpain and the people at
www.theforce.net/scifi3d.

Contact me at tornadorip1984@yahoo.com if you need help or have any questions,
comments, or criticisms. :)