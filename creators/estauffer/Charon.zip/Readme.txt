This is my depiction of pluto's moon, Charon.

Copy (ctrl+c) and paste (ctrl+v) the folder into the Extras directory.


I authorize that this product may be distributed free of charge, and non-commercially. If you wish
to use any part of this product for your own creations, please let me know RIGHT DOWN TO THE LETTER
what you plan to do with it. You wouldn't want to steal other people's hard work now, would you? ;-)
If so, don't forget to feel guilty about it every time you go to bed. :-)


Questions, comments?
Email me: tornadorip1984@yahoo.com