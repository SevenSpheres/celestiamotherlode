Installation:
Simply unzip the Nova Selene folder to the celestia "Extras" directory. That's it!

Version:
1.0

Legal:
I hereby release this under the terms of V3 of the GNU General Public License.