How to install:

- go to Program Files/Celestia/extras and export Boliverius Alvera Sagittarii over to
extras, then you are done



Start Celestia, and have fun to explore the gigantic solar system with over 50 objects
to explore




This is v1 of Boliverius Alvera Sagittarii