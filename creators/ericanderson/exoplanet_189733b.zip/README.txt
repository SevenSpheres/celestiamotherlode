To install this addon, just copy the zip-file into the Celestia folder "extras/addons" and unzip it there.  

Regards,
Eric Anderson
