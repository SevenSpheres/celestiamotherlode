Mu Ara v1.1
-----------



My vision of Mu Ara system, based on what we know about Mu Ara
system so far.

-----------------------------------------------------------------


From what we know, Mu Ara has three planets: two gas giants and 
one huge, rocky inner planet.

- Mu Ara B is a gas giant of mass about 1.67 Jupiters, it belongs 
to class of gas giants dubbed "Water Cloud Jovians" 
(check out the www.extrasolar.net to find out what it is). 
Its orbit is eccentric. I named it "Perun" after the highest 
slavic god. It has two (fictional) habitable moons called "Jurata" 
(Slavic Goddess of spring) and Swarog (God of fire).
(hint: Watch the Jurata entering Perun's shadow every day)


- Mu Ara C, named Kupalo, is about twice as heavy as Perun. It 
belongs to "Ammonia Cloud Jovians" class of gas giants.
Note that the northern hemisphere is darker than the southern one,
that's caused by the bigger inclination of its axis resulting in 
"seasons" on Kupalo. Its orbit is also very eccentric.


- Mu Ara D, dubbed Khors, is rocky planet belonging to the 
"Hot Super Earth" class. Its orbit is very close to the Mu Ara sun
and its temperature is reaching 1000 �K. It has dense atmosphere 
created by perpetual heavy vulcanism. You can see whole seas of
molten lava from the orbit, glowing in the dark side of planet.


------------------------------------------------------------------


Some of the textures used on planets in Mu Ara systems are modified
textures of another planets from Arc Builder or Star Trek universe.

------------------------------------------------------------------

Installation: Just copy the "Mu Ara" folder into your "extras" 
folder. In Celestia, type "Mu Ara" and press enter.

------------------------------------------------------------------
------------------------------------------------------------------


Changes in version 1.1:
-----------------------

- new Perun's moon (Swarog) added
- new specular map for Jurata added
