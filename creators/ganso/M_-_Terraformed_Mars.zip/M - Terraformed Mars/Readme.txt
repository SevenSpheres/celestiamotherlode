2006, 11/09, 15:25
Murilo G. Rocha Produtions
All rights reserved.

INSTALLING
----------

Just extract the contents of this zip file in your extras directory.
After this, lauch Celestia and see Mars. It will be green and with oceans, and
it will have sunlights in the sea (specular texture).

CONTENTS
--------

This file contains:
Texture 1 - Texture map for Mars
Texture 2 - BumpMap
Texture 3 - Specular texture
TXT files - this file
SSC file  - the file that modify the Mars.

Observation: This is the Medium-Res version. Soon, I'll publish the versions Low-Res and
High-Res.

LISCENCE
--------

Free to use as you wish, but you can't modify it, and you can't use my textures in your
creations or any other event.

Thanks for download this.