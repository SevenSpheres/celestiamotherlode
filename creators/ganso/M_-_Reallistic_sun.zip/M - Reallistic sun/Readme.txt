2006, Murilo G. Rocha Produtions - All rights reserved.

REALLISTIC SUN DESCRIPTION
--------------------------

Thanks for download my addon. All my addons have realism, because I think
that all the people want it in an addon. Thinking that I can put more realism in Sun,
I designed this addon, where I made a texture for the sun, and add a golden luminous circle
around the sun, to representate it's luminosity. Combined with the flare texture, it gene-
rates a semi-real vision of this incandescent sphere. Enjoy this addon. I hope you like.

LISCENCE AND INFORMATION
------------------------

This addon is free to use as you wish, but you can't republish it or use my texture
in your creations.

Thanks you, Celestia team, this is the best 3d planetary I ever seen.