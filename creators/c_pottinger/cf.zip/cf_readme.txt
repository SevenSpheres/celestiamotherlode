cf.celx - view comparison tool V1.00.00 ReadMe by Clive Pottinger

>> Purpose:
Have you ever wondered how big Betelgeuse is in comparison to Sol?  Or how the orbits of the planets of epsilon Eridani compare with the orbits of our system's planets?

Even though Celestia is arguably the best available tool for seeing these far away sites, it does not readily provide a sense of scale when viewing them.  Zooming to Barnard's Star will show you the star, but doesn't let you see how small it would look next to Sol.  Yes, the relative radius is shown in Celestia's information text, but, especially for those just beginning to delve into astronomy, "seeing" the difference is much more educational than just reading it.

The cf script is meant to allow you to quickly see such differences and similarities.  It works by monitoring the current view that Celestia is showing of an object and showing the same view, from the same angle and distance, of a reference object.  It has a few other abilities that are covered below.

>> Installation:
The cf script requires no special installation.  Simply execute it as you would any script.

>> Operation:
Perhaps the best way to explain cf is to just jump right in.  So let's go...

** The Viewing Mode
a) Start Celestia

b) Select Render->View Options... and set Orbits on as well as selecting Orbits for Moons and Planets.  Click OK

c) Press Ctl-D to have just a single window open.

d) Press 5 and G to select and goto Jupiter.

e) Select File->Open Script... and select the cf.celx file
At this point a new screen should appear.  If the user preferences have not been changed, then the new screen should show Earth from the same angle, distance and field of view as that of Jupiter.  You know can see the size of Jupiter in comparison to the Earth.

f) Use the END and HOME keys to change the distance from Jupiter until the view is from between 2.5 to 3.5 million km.  Now right-click on Jupiter and holding down the mouse button, manoeuvre until you are "above" one of Jupiter's poles (the orbits of the moons should be close to circular).
Notice that while you were doing this, the view of Earth was also changing.  From your new vantage point it becomes clear that the orbit of Io is just slightly larger than the orbit of the Moon.

g) Press 9 and G to select and goto Pluto.  Again, use the END and HOME keys until the view is approximately 50,000 km from Pluto.  You should now have good idea of the size of Pluto compared to Earth.

Note: when you first arrived at Pluto, the message "Too close to Sol/Earth" probably appeared.  This is because the distance of the observer from the centre of Pluto was around 4000 km.  The reference view was trying to match this, but 4000 km from the centre of the Earth is still 2000 km under the surface.  The reference view will always try to remain outside of the reference body.

h) Right-click on the reference view (the one showing Earth).
Notice that the message "Reference view is active view: cannot compare positions appears".  cf tries to always show how the reference object looks in relation to the selected object in the active view.  Right-clicking on the reference view made it the active view and made it impossible for cf to generate a meaningful comparison view.

i) Right-click on the other view (the one showing Pluto).  The error message should disappear.

Up until now, we have been using cf in the Viewing Mode.  Next we will explore using the Menu mode to change cf's settings.

** Changing the reference view:
cf will work with any number of views open (as long as there are more than one).  You may not always like the view that cf chooses to be the reference view.  You can change which view is the reference view as follows:
a) Press the accent grave (`) key to activate the menu. 
Depending on the current state of cf, different options will appear.  The first one we will work with is changing the reference view.

b) Press S to switch active views.  One of the views will now begin zooming in and out.  This indicates which view cf will use as the reference view.

c) Press S again and the next view will begin zooming in and out.  Repeatedly pressing S will cause to cf to cycle through all the open views.

d) Press S until the window you wish to use as the reference window is zooming.  At this point you may either:
   - press ` to leave the menu.  The view that was last zooming will remain the reference view.
   - press ENTER to set the desired view as the reference view, but remain in the menu system.
   
** Changing the reference object:
By default, cf compares the active view to a view of Earth.  However, cf is by no means limited to just comparing things to Earth.  There are two ways to alter this.  One way is to change the default entry in the script: this is covered later.  The second is to use th menu.

a) If you are still in the cf menu, exit by pressing `.

b) Press H and G to select and goto Sol.

c) Enter the Menu Mode by pressing `.

d) Press X to make Sol the reference object.
Pressing X in the menu makes whichever object is Celestia's selected object become cf's reference object.

e) Press ` to exit the menu and return to the Viewing Mode.

f) Press ENTER, then betel, press TAB and then ENTER and, finally, G.  This will select the star Betelgeuse and travel to it.

g) Right-click on the active view (the one showing Betelgeuse) and manoeuvre the mouse until the reference view shows the solar system from "above" (the orbits should look almost circular).

h) Use the END and HOME keys until the active view is around 40 au from the star.  At this distance it becomes clear just how large Betelgeuse is.

** Freezing and Unfreezing the reference vector:
Normally, cf's reference view moves around the reference object in the same way the active view is moving around the selected object.  However, in some cases this may not be the desired behaviour.  For instance, the previous example provided us with a good comparison of size of Betelgeuse to the solar system.  If we wanted to compare other stars to the Sun and solar system, each time we selected and travelled to a new star, we would have to repeat step g) from above until we could see the orbits of the planets correctly.

Freezing the reference vector avoids this by forcing cf to maintain the same angle relative to the reference object.  The distance will still change to match the distance of the active view from the selected object.

a) If you are not still in the configuration showing Betelgeuse and the solar system from "above", then repeat the steps from "Changing the reference object").

b) Enter the Menu Mode by pressing `.

c) Press V to freeze the reference vector.

d) Press ` to exit the menu and return to the Viewing Mode.

e) Enter ENTER, then ant, press TAB and then ENTER and, finally, G.  This will select the star Antares and travel to it.
Note that the reference view has maintained the same relative angle to the solar system; we are still looking "down" on the Sol and the planets.

f) Enter ENTER, then pola, press TAB and then ENTER and, finally G.  This will select the star Polaris and travel to it.
Again, the reference view is still looking "down" at Sol.

g) Enter the Menu Mode by pressing '.

h) Press V to unlock the reference vector.

i) Press ` to exit the menu and return to the Viewing Mode.

j) Enter ENTER, then 2 lac, press TAB and then ENTER and, finally, G.  This will select the star 2 Lac and travel to it.
Note that the reference view is unlocked and our view of the solar system now matches our orientation to 2 Lac (almost edge-on to the ecliptic).

** Freezing and Unfreezing the reference range:
Normally, cf's reference view moves so that it is the same distance from the reference object as the active view is from the selected object.  As with the reference vector, this may not be the desired behaviour.  For instance, in the previous examples we were using the orbits of the solar system's planets as a handy "size" reference as we went from star to star.  In this example we would like to use them as an "orientation" reference as we move around the galaxy.

Freezing the reference vector avoids this by forcing cf to maintain the same angle relative to the reference object.  The distance will still change to match the distance of the active view from the selected object.

a) If you are not still in the configuration showing Betelgeuse and the solar system from "above", then repeat the steps from "Changing the reference object").

b) Enter ENTER, then milk, press TAB and then ENTER and, finally G.  This will select the Milky Way and travel outwards so we can view it.
Note that the reference view also shows the Milky Way from afar.  It is actually showing us the solar system from as far away as the active view is from the centre of the galaxy.  This isn't very useful though.

c) Press H to select Sol and G to travel to it.

d) Use the END and HOME keys until the active view is around 100 au from the sun.

b) Enter the Menu Mode by pressing `.

c) Press R to freeze the reference range.

d) Press ` to exit the menu and return to the Viewing Mode.

e) Again, press ENTER, then milk, press TAB and then ENTER and, finally G.
Note that this time the reference view does not change its distance from the sun.

f) Use the END and HOME keys until the entire Milky Way is visible in the active view.

g) Hold down the SHIFT key and press any of the arrow keys to orbit around the Milky Way.
Notice that the view of the solar system also changes orientation, but not distance.  This provides a method of seeing how the galaxy is oriented as compared to the solar system (or visa versa).

h) Enter the Menu Mode by pressing '.

i) Press R to unlock the reference vector.

j) Press ` to exit the menu and return to the Viewing Mode.

** Exiting cf
At any time, either in the Viewing Mode or the Menu Mode, you may press Q to exit cf.  When cf starts it remembers many of the user selected settings and will restore them when you exit.

** Changing the defaults
The cf script has a number default values that are easily altered to accomodate your tastes.  To change these, open the cf.celx script using your favourite editor.  At the top of the script are a set of assignments to variables prefixed with CF_.  These are:

CF_SPLIT = { "direction", percent }
	- determines the manner in which cf will split the screen if only one view is open.  
	- direction is one of v, or h, in quotes.  This indicats if the screen should be split vertically or horizontally.
	- percent is a value from .1 to .9 and indicates how much of the screen should be given to the newly created view.

CF_REFERENCE = "objectname"
	- determines the default object to be used as the reference object.
	- objectname should be given in the format [parent/]...object (e.g. "Moon", "Earth/Moon", "Sol/Earth/Moon")
	
CF_LABEL_PRESETS = { labelflags }
	- determines the defaults for which objects should be labelled in Celestia.
	- accepts any setting valid for use with the Celx method setlabelflags().
	- any settings not specifically included are not changed by cf.
	- has no effect unless CF_USE_PRESETS is set to true

CF_ORBIT_PRESETS = { orbitflags }
	- determines the defaults for which orbits should be shown in Celestia.
	- accepts any setting valid for use with the Celx method setorbitflags().
	- any settings not specifically included are not changed by cf.
	- has no effect unless CF_USE_PRESETS is set to true
           
CF_RENDER_PRESETS = { orbitflags }
	- determines the defaults for which objects should be shown in Celestia.
	- accepts any setting valid for use with the Celx method setrenderflags().
	- any settings not specifically included are not changed by cf.
	- has no effect unless CF_USE_PRESETS is set to true
	
CF_RENDER_FLAGS = setting
	- controls whether CF_LABEL_PRESET, CF_ORBIT_PRESETS and CF_RENDER_PRESETS are used by cf.
	- valid values for setting are true or false.

Hopefully, these activities have shown you how to operate cf and given you some ideas as to how you can utilise it for your own needs.  If you have any questions about its operation, notice any problems or have suggestions for improvements, please feel free to contact the author using the information below.

>> Contact:

The author, Clive Pottinger, can be contacted at cpmy@sympatico.ca.  He also checks the Celestia Forum at least once a week.

Copyright (C) 2005, Clive Pottinger
The cf script and readme file may be freely distributed and used.  Excerpts and modification to excerpts may
also be freely distributed and used as long as the original copyright is quoted or the original author acknowledged.
The cf script or code derived directly from the script may not be sold or used for commercial purposes.
