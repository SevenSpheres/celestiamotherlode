Celx Visual Guide V1.132.1 ReadMe by Clive Pottinger

>> Purpose:

The Celx Visual Guide is a didactic script that will allow the user to observe the effects of executing the various methods available to Celx scripts.  The Guide is meant to compliment the documentation already available on Celx scripting, not to replace them.  Hopefully, the code examples and visual demonstrations present in the Guide will serve as yet another way to understand some of Celestia's trickier concepts.

The Guide grew out of the author's own attempts to learn Celx scripting by writing small scripts to test one concept or another.  As more and more 'test' scripts were written, the idea of a single large script to demonstrate the usage of each function in Celx arose.  It is the author's hope that this script will prove as useful a learning and reference tool to others as creating it has been as a learning experience.

However, there are a few things the Guide is NOT:
     It is not a tutorial for creating scripts.
     It does not cover Lua programming or object oriented programming.
     It does not cover the mathematical concepts used by Celestia and in astronomy.
     It is not perfect - but your comments and suggestions can help (see Contact below).

Many thanks to Harald Schmidt, Tim McMahon, Don Goyette, Selden Ball and the others who created the documentation and examples that the Guide is based on.  And, of course, to all the creators and contributors to Celestia - the finest and most engrossing simulation ever made.


>> Installation:

The Guide can be extracted and placed in any directory accessible to the Celestia program.  No special set up is required.  

However, if you wish to quickly access the Guide on a regular basis, you may want to set the Guide up as the demo script by performing the following steps:
     1) Open the file celestia.cfg using any standard editor.
	  2) Find the line that begins 'DemoScript' - if you have not changed this before, it should read 
	       'DemoScript "demo.cel"'
	  3) Insert an octothorpe (#) at the start of the line
	  4) Add a new line that reads 'DemoScript "x"' where x is the directory and file name of the Guide.  e.g.
	       'DemoScript "scripts/Celx_Visual_Guide_v1.132.1.celx"'
You should now be able to access the Guide simply by pressing 'd' while running Celestia.

Uninstalling the Guide is simply a matter of deleting the Celx_Visual_Guide_v1.132.1.celx file.  If you had set the Guide up as the default demo, then open celestia.cfg, delete the 'DemoScript' line referring to the Guide, and remove the octothorpe from the original line.


>> Menus:

The Guide has two methods of finding information.  The first is through a menu system that is presented whenever the Guide is accessed.  

Menus are always presented with instructions at the top of the page, followed by a short title and then a list of selectable entries.  The currently selected entry is shown in capital letters.  Entries proceeded by a + sign indicate submenus.  A - sign indicates a method or topic of discussion.

While a menu is displayed, the following keys can be used:
     TAB:              Selects the next entry in the list.
     SHIFT + TAB:      Selects the previous entry in the list.
     RETURN:           Activate the currently selected entry.
     SPACE:            Activate the currently selected entry.
     BACKSLASH (\):    Go back to the previous menu (except on the main menu).
     PERIOD:           Switch to Direct Entry Mode (see below).
     ACCENT GRAVE (`): Toggle Celestia's display (handy when stars and other objects make it hard to read the text).
     
Entries can also be selected by entering the first letter of the entry's title (after the + and - signs).  If more than one entry starts with the same letter, then each time that letter is pressed, the next qualifying entry will be selected.

Celestia will treat any other key that is pressed as a control command.


>> Menu Structure:

Because of the large number of methods and topics covered by the Guide, it was necessary to organise the entries in some consistent fashion.  The author chose to do so by first dividing the entries according to the programming objects that they relate to.  Still, both the celestia and observer menus needed to be subdivided.  Each of these is subdivided as
     Properties (pairs of methods that allow specific settings to be read and set),
     Read only properties (methods that only allow settings to read),
     Other categories (e.g. goto methods).

The author is aware that this arrangement may not be the most intuitive, especially for beginners, and is open to suggestions on how to improve the ordering of the methods and topics.

The menus for each of the programming objects also have one or two of the following:
     1) An entry discussing the programming object, what it represents and how it can be used.
     2) A submenu of any methods that can be used to create a object of that type.
Currently the discussions of the programming objects can only be accessed by the menu system; they are not available through the Direct Entry Mode.


>> Direct Entry Mode:

Direct Entry is the second method that the Guide provides to access its demonstrations.  Direct Entry can be activated from any menu by pressing the PERIOD key (.).  Once activated, the user is presented with a BACKSLASH prompt.  By simply typing the name of a method, the user can go directly to that method's demonstration.

As the user presses a key, all entries that begin with the letters entered will appear as a list.  This is NOT a menu; using the TAB and ENTER keys will not select an entry, as they did in the Menu system.  This list is only there to let the user know which entries have qualified so far.  The user must continue to enter letters until only one entry appears.  At this point the user may press ENTER to see the demonstration.

Note: if the use presses a letter that does not match any of the qualifying entries, that keystroke will be handled by 

Celestia (i.e. treated as a Celestia control key).

If, at any point, there are too many qualifying entries to be displayed, the user may see an additional entry at the bottom of the list that may look like this:
     get... [m o p r s t x y z]
This indicates that there are other entries that qualify for the "s" that user has typed in, and that the next letter for these entries are m, o, p, r, s, t, x, y and z.  In other words, in addition to any of the selections shown in the list, there are also entries that start with "getm", "geto", etc., so pressing one of these letters will also further qualify the selections.

Note: the opening and closing parentheses are considered letters in Direct Mode and are sometimes significant.  For example, if the user enters "getobserver", two entries are shown:
     getobserver()
     getobservers()
To select the second entry, the user should press "s", but to select the first the user must enter "(".

An additional feature of Direct Mode is the autofill function.  When autofill is on and the user pauses for more than 1.5 seconds then Direct Entry will automatically enter the sequence of letters common to all qualified entries (if there is a common sequence), as if the user typed them in.  For example, if the user has entered "ge" and then paused, the Guide will recognise that all entries that begin with "ge" have "t" as the next letter.  After 1.5 seconds, the Guide will automatically add the "t" to the user's selection.

Autofill can be toggled on or off using the PERIOD (.) key while in Direct Mode.

The BACKSPACE key can be used to remove entered letters from the selection (or if there are no letters entered, BACKSPACE will return the user to the Menu system).

The BACKSLASH key can be used at any time to exit Direct Mode and return to the Menu system.

Note: The ACCENT GRAVE key mentioned above is also accessible in Direct Mode.


>> Contact:

The author, Clive Pottinger, can be contacted at cpmy@sympatico.ca.  He also checks the Celestia Forum at least once a week.

The comments at the top of the script include a list of known problems and items for improvement.  If you have any idea on how to rectify any of these items, or anything else related to the Guide, please feel free to send an e-mail or post a message.

Thank you and I hope the Celx Visual Guide proves useful.

Copyright (C) 2005, Clive Pottinger
The Visual Celx Guide and readme file may be freely distributed and used.  Excerpts and modification to excerpts may also be freely distributed and used as long as the original copyright is quoted or the original author acknowledged.  The Guide or code derived directly from the Guide may not be sold or used for commericial purposes.
