The archive contains an SSC file describing the orbit for 3554 Amun 
Near-Earth asteroid. 

3554 Amun (1986 EB) is an M-type Aten asteroid and Venus-crosser. It was 
discovered on 4 March 1986 by Carolyn and Eugene Shoemaker at Mount Palomar 
Observatory. Its estimated diameter is 2.5 kilometres, making it one of the 
smallest known M-type asteroids. However, its mineral content could be worth 
$20 trillion.

To install, simply copy the SSC file into Celestia's "extras" folder.

