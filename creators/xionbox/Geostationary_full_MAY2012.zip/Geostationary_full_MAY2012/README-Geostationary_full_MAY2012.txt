==========
= README =
==========

Package:
Geostationary_full_MAY2012

== Information ==
This is an update of Thomas Guilpain's list of geostationary satellites. The model and texture are identical, only
the list of satellites and their positions has been updated.

This package also includes a script to generate your own update from NORAD's TLE list. For licence reasons, it is
not possible to include this raw list in the package. More information here: http://www.celestrak.com/NORAD/elements/ .

Note that this package uses each satellite's common name (e.g. SES-4) per default instead of the international identifier (e.g. 12007A).
By re-running the script, you can select if you prefer to have the common name or the international identifier.

This package is designed to work with Celestia 1.6.

== Installation ==
Extract the whole archive into your Celestia extras' directory (e.g. C:\Program Files\Celestia\extras).

== Note ==
If you have the SDO add-on installed, you may want to edit the Geostationary_full.ssc file to remove SDO from the list.
To do so , open the file in a text editor and search for 'SDO' (or '10005A' if you are using the international identifier).
Then simply remove that entry from the file. Finally, restart Celestia.

== Contact information ==
Christopher Rabotin xionbox33418@gmail.com