(Description from the Motherlode)
This addon is part of Project Sisyphus, so all addons part of it will have a similar description.

Welcome to Barnard's Star!
This addon adds Barnard's Star b, an rocky exoplanet.
Here, its potrayed as an cloudy desert planet with an dark blue atmosphere.
Keep in mind that the files in this addon have alternating letters, so if you are going to use this addon on Linux, rename the files to be caps-only (eg. FILENAME.EXT), or no caps (eg. filename.ext).

(README Part)
The data for this addon was taken from Hungry4info/Sirius_Alpha's Exoplanet Catalog.
The visuals for Barnard's Star b was done by myself.

To install this addon, you just need to extract the zip file into your extras folder.