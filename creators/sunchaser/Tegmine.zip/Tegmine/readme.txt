This is an add-on for Celestia 1.6 for the star Tegmine, Zeta Cancri, or whatever else it may be called.
I've added the C, D and E components of this system, plus a 3 planet system around A.  While I'm sure 
there are many errors I've made in the creation of this add-on, I still am very proud of it.

Some  thoughts and "thank yous" on this add-on...the orbits, rotations, sizes, etc. were calculated out by
AstroSynth (sample version) so the names seem, well, odd.  
Further credits...
First and foremost...the credits for the following textures...
Cotralege Mu....Saturn (courtesy Celestia)
Cotralege Mu 12 Geographos model, Hyperion texture
Other moons...Enceladus  (all courtesy of Celestia)
Whomever made the texture "Bianca.jpg"  I thank you.  It looks really nice on one of the moons.
Likewise to the creator of "marsclouds"
Thanks to Spiral Graphics for use of their texture on the first planet.
Many thanks to GIMP and its creators, without which very little of this would have been possible...

To install:  Unzip the contents in your Extras directory in Celestia.  
To view...start Celestia, <enter> type "Tegmine A" <enter> and go to the star like you would anywhere else...
All navigation commands apply.

