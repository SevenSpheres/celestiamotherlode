*************************************************************************************
*                                                                                   *
*                    MarsTour.cel V2.0 - Last Revision 5-23-04                      *            *                                                                                   *
*                                                                                   *
* The Mars script requires that you have the mars_locs2.ssc file installed in your  *
* Program Files\Celestia\extras directory. This file has been included in this      *
* package for your convenience. Simply unzip the MarsTour.cel file into your main   *
* Celestia directory, and unzip the location ssc files into your extras directory.  *
* By the way, if you already have Mr. Hutchison's mars_locs2.ssc and marsmoons2.ssc *
* files in your extras directory, then there is NO need to install these versions   *
* of the Mars Locations SSC files.                                                  *
*                                                                                   *
* NOTE: If you don't wish to see *all* of Mars' locations displayed                 *
*       while running this script, select "Render" from Celestia's menu             *
*       taskbar. Then select "Locations" and uncheck the "Label Features"           *
*       box. Right now, there's no way to do this from within a script.             *        
*       If you like, you can also press SHIFT and "&" to do the same                *
*       thing.                                                                      *
*                                                                                   *
*       This script was written for use with Celestia V1.3.2 Pre8                   *
*                                                                                   *
* Further information:                                                              *            *                                                                                   *
* I have included new textures for Mars and both of Mars moons; Phobos and          *
* Deimos. I've also provided an improved texture for the Mars Clouds. Now you do    *
* NOT need all of these textures to run the MarsTour script, but believe me, the    *
* new textures are well worth taking the time to install. To perform the            *
* installation of these files, simply follow the instructions below.                *
*                                                                                   *
* 1. First, simply unzip the mars.jpg, phobos,jpg, deimos.jpg and MarsClouds.png    *
*    files into the directory shown here: Program Files\Celestia\textures\medres    *
*    Please note that these file will REPLACE your default Celestia textures, so    *
*    you may first wish to make backups of your CURRENT files in case you like them *
*    better than you do these textures. That's doubtful, but you never know.        *
*                                                                                   *
* 2. Next, modify your solarsys.ssc file in order to make use of the new            *
*    cloud texture. Simply use Notepad (or it's equivalent) to modify your          *
*    solarsys.ssc file (Located in the Program Files\Celestia\data directory) as    *
*    follows:                                                                       *
*                                                                                   *
*    Under the "Mars" "Sol" heading - and within the Atmosphere section, add        *
*    (or replace) the following lines:                                              *
*                                                                                   *
*               CloudHeight 10                                                      *
*               CloudSpeed 70                                                       *
*               CloudMap "MarsClouds.png"                                           *
*                                                                                   *
* 3. That's all folks! You should save your work and run the new MarsTour           *
*    script.                                                                        *
*                                                                                   *
* 4. Sorry, one other note: Since I have no idea what the actual Mars               *
*    cloudspeed should be set at, I've simply guessed at the speed used             *
*    in the code above. Almost every CloudSpeed value I've seen for Mars            *
*    has been set to zero, but this just cannot be correct. If you've               *
*    ever seen the sandstorms and Martian clouds through a telescope,               *
*    then you know as well as I do that the clouds on Mars really move at           *
*    quite a pace. If you know the *correct* CloudSpeed value for Mars,             *
*    Please send me an e-mail with the pertinent information.                       *
*                                                                                   * 
*    That's all for now, Take care, and Enjoy! - Bob                                *
*                                                                                   *
* Credits: ________________________________________________________________________ *
*                                                                                   *
* mars.jpg       - Author: Praesepe                                                 *
*	           Website:                                                         *
*                  http://www.la-guarida.com/Celestia/index_archivos/slide0001.htm  *
* phobos.jpg     - Author:  Jens (Jim) Meyer                                        *
*                  Website: http://home.arcor.de/jimpage/mars.html                  *
*                  Revisions: Bob Hegwood - Resized to 1024 x 512.                  *
* deimos.jpg     - Author:  Jens (Jim) Meyer                                        *
*                  Website: http://home.arcor.de/jimpage/mars.html                  *
*                  Revisions: Bob Hegwood - Resized to 1024 x 512.                  *
* MarsClouds.png - Author:  Jens (Jim) Meyer                                        *
*                  Website: http://home.arcor.de/jimpage/mars.html                  *
*                  Revisions: Bob Hegwood - Converted from DDS and then resized to  *
*                                           1024 x 512.                             *
* mars_locs2.ssc - Author: Grant Hutchison                                          *
*                  Website: http://www.lns.cornell.edu/~seb/celestia/hutchison/     *
* marsmoons2.ssc - Author: Grant Hutchison                                          *
* MarsTour.cel   - Author: Bob Hegwood                                              *
*                  Website: http://home.earthlink.net/~bobhegwood                   *
*                                                                                   *
*          ________________________________________________________________________ *
*                                                                                   *
*                                                                                   *
* Questions or comments? Send them to me at the following email address:            *
*                                                                                   *
* bobhegwood@earthlink.net                                                          *
*                                                                                   *
* Visit my Celestia web page at: http://home.earthlink.net/~bobhegwood              *
*                                                                                   *
*************************************************************************************