--    This addon to Lua Edu Tools runs a script that compares stars of different sizes next to each other and to the sun, using the multiview feature of Celestia.
--  Please read the read-me file in the addon for credits

StarSizeComparison =
{
    objects = { "StarSizeComparison" },
    script = "ZonEnSterrenOmvangVergelijk2_NL_2012.celx"
}
