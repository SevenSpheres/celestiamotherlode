-- Moon Rise/Set

MoonRiseSet_loc_str = {
   --["Moon Rise/Set"] = "Sorgere/Tramontare della Luna";
   ["Moon Rise/Set"] = "Sorgere/Tramon. della Luna";
   ["Longitude:"] = "Longitudine:";
   ["Latitude:"] = "Latitudine:";
   ["Date:"] = "Data:";
   ["Azimuth:"] = "Azimut:";
   ["Moonrise at:"] = "La Luna sorge alle:";
   ["Moonset at:"] = "La Luna cala alle:";
   ["Moon DOWN all day."] = "La Luna è GIÙ tutto il giorno.";
   ["Moon UP all day."] = "La Luna e SU tutto il giorno.";
   ["NO Moonrise this date."] = "La Luna NON sorge.";
   ["NO Moonset this date."] = "La Luna NON tramonta.";
   ["Invalid location in config file."] = "Percorso non valido nel file di config.";
   [" Jan "] = " Gen ";
   [" Feb "] = " Feb ";
   [" Mar "] = " Mar ";
   [" Apr "] = " Apr ";
   [" May "] = " Mag ";
   [" Jun "] = " Giu ";
   [" Jul "] = " Lug ";
   [" Aug "] = " Ago ";
   [" Sep "] = " Set ";
   [" Oct "] = " Ott ";
   [" Nov "] = " Nov ";
   [" Dec "] = " Dic ";
   ["Script"] = "Script";
}
