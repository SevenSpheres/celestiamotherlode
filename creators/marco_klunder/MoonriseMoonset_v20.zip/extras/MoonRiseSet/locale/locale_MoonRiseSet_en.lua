-- Moon Rise/Set

MoonRiseSet_loc_str = {
   ["Moon Rise/Set"] = "Moon Rise/Set";
   ["Longitude:"] = "Longitude:";
   ["Latitude:"] = "Latitude:";
   ["Date:"] = "Date:";
   ["Azimuth:"] = "Azimuth:";
   ["Moonrise at:"] = "Moonrise at:";
   ["Moonset at:"] = "Moonset at:";
   ["Moon DOWN all day."] = "Moon DOWN all day.";
   ["Moon UP all day."] = "Moon UP all day.";
   ["NO Moonrise this date."] = "NO Moonrise this date.";
   ["NO Moonset this date."] = "NO Moonset this date.";
   ["Invalid location in config file."] = "Invalid location in config file.";
   [" Jan "] = " Jan ";
   [" Feb "] = " Feb ";
   [" Mar "] = " Mar ";
   [" Apr "] = " Apr ";
   [" May "] = " May ";
   [" Jun "] = " Jun ";
   [" Jul "] = " Jul ";
   [" Aug "] = " Aug ";
   [" Sep "] = " Sep ";
   [" Oct "] = " Oct ";
   [" Nov "] = " Nov ";
   [" Dec "] = " Dec ";
   ["Script"] = "Script";
}
