-- Moon Rise/Set

MoonRiseSet_loc_str = {
   ["Moon Rise/Set"] = "Maan Opkomst/Ondergang";
   ["Longitude:"] = "Lengtegraad:";
   ["Latitude:"] = "Breedtegraad:";
   ["Date:"] = "Datum:";
   ["Azimuth:"] = "Azimut:";
   ["Moonrise at:"] = "Maan opkomst om:";
   ["Moonset at:"] = "Maan ondergang om:";
   ["Moon DOWN all day."] = "Maan is de hele dag ONDER.";
   ["Moon UP all day."] = "Maan is de hele dag OP.";
   ["NO Moonrise this date."] = "GEEN Maan opkomst deze dag.";
   ["NO Moonset this date."] = "GEEN Maan ondergang deze dag.";
   ["Invalid location in config file."] = "Ongeldige locatie in config bestand.";
   [" Jan "] = " jan ";
   [" Feb "] = " feb ";
   [" Mar "] = " mrt ";
   [" Apr "] = " apr ";
   [" May "] = " mei ";
   [" Jun "] = " jun ";
   [" Jul "] = " jul ";
   [" Aug "] = " aug ";
   [" Sep "] = " sep ";
   [" Oct "] = " okt ";
   [" Nov "] = " nov ";
   [" Dec "] = " dec ";
   ["Script"] = "Script";
}
