-- Moon Rise/Set

MoonRiseSet_loc_str = {
   ["Moon Rise/Set"] = "Lever/Coucher de la Lune";
   ["Longitude:"] = "Longitude:";
   ["Latitude:"] = "Latitude:";
   ["Date:"] = "Date:";
   ["Azimuth:"] = "Azimut:";
   ["Moonrise at:"] = "Lever de la Lune à :";
   ["Moonset at:"] = "Coucher de la Lune à :";
   ["Moon DOWN all day."] = "Lune COUCHÉE toute la journée.";
   ["Moon UP all day."] = "Lune LEVÉE toute la journée.";
   ["NO Moonrise this date."] = "PAS de lever de la Lune cette date.";
   ["NO Moonset this date."] = "PAS de coucher de la Lune cette date.";
   ["Invalid location in config file."] = "Emplacement non valide dans le fichier de configuration.";
   [" Jan "] = " jan ";
   [" Feb "] = " fév ";
   [" Mar "] = " mar ";
   [" Apr "] = " avr ";
   [" May "] = " mai ";
   [" Jun "] = " juin ";
   [" Jul "] = " juil ";
   [" Aug "] = " août ";
   [" Sep "] = " sep ";
   [" Oct "] = " oct ";
   [" Nov "] = " nov ";
   [" Dec "] = " déc ";
   ["Script"] = "Script";
}
