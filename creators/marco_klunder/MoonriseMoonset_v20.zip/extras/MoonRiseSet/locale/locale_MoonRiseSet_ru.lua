-- Moon Rise/Set

MoonRiseSet_loc_str = {
   ["Moon Rise/Set"] = "Восходы/Закаты Луны";
   ["Longitude:"] = "Долгота:";
   ["Latitude:"] = "Широта";
   ["Date:"] = "Дата:";
   ["Azimuth:"] = "Азимут:";
   ["Moonrise at:"] = "Восход Луны в:";
   ["Moonset at:"] = "Закат Луны в:";
   ["Moon DOWN all day."] = "Луны нет в небе весь день.";
   ["Moon UP all day."] = "Луна в небе весь день.";
   ["NO Moonrise this date."] = "Восхода Луны на эту дату не существует.";
   ["NO Moonset this date."] = "Заката Луны на эту дату не существует.";
   ["Invalid location in config file."] = "Неверная локация в конфигурационном файле.";
   [" Jan "] = " Янв ";
   [" Feb "] = " Фев ";
   [" Mar "] = " Мар ";
   [" Apr "] = " Апр ";
   [" May "] = " Май ";
   [" Jun "] = " Июн ";
   [" Jul "] = " Июл ";
   [" Aug "] = " Авг ";
   [" Sep "] = " Сен ";
   [" Oct "] = " Окт ";
   [" Nov "] = " Ноя ";
   [" Dec "] = " Дек ";
   ["Script"] = "Сценарий";
}
