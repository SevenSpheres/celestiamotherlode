-- Moon Rise/Set

MoonRiseSet_loc_str = {
   ["Moon Rise/Set"] = "Mond Aufgang/Untergang";
   ["Longitude:"] = "Längengrad:";
   ["Latitude:"] = "Breitengrad:";
   ["Date:"] = "Datum:";
   ["Azimuth:"] = "Azimut:";
   ["Moonrise at:"] = "Mondaufgang am:";
   ["Moonset at:"] = "Monduntergang am:";
   ["Moon DOWN all day."] = "Mond ganztägig UNTER Horizont.";
   ["Moon UP all day."] = "Mond ganztägig ÜBER Horizont.";
   ["NO Moonrise this date."] = "KEIN Mondaufgang an diesem Datum.";
   ["NO Moonset this date."] = "KEIN Monduntergang an diesem Datum.";
   ["Invalid location in config file."] = "Ungültiger Speicherort in Config-Datei.";
   [" Jan "] = " Jan ";
   [" Feb "] = " Feb ";
   [" Mar "] = " Mrz ";
   [" Apr "] = " Apr ";
   [" May "] = " Mai ";
   [" Jun "] = " Jun ";
   [" Jul "] = " Jul ";
   [" Aug "] = " Aug ";
   [" Sep "] = " Sep ";
   [" Oct "] = " Okt ";
   [" Nov "] = " Nov ";
   [" Dec "] = " Dez ";
   ["Script"] = "Skript";
}
