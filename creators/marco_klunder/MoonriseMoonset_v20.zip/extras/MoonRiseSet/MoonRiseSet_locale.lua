
require "config"

lang_country_code =
    {
    -- Language codes:
        English = "en",
        Dutch = "nl",
        French = "fr",
        German = "de",
        Italian = "it",
        Portuguese = "pt",
        Russian = "ru",
        Spanish = "es",
        Swedish = "sv",
    -- Country codes:
        Brazil = "BR",
        ["United States"] = "US",
    }

-- Set English as the default language.
lang = "en";

-- Get language setting from 'config.lua' ( if exists! )
if type(language)=="string" and string.find(language, "^%l%l_?%u?%u?$") then
	-- Use language set in 'config.lua'.
	loc = language
else
    -- Get the system locale (doesn't work properly on Mac OS-X).
  loc = os.setlocale("", "collate")
end

-- On Windows, the system locale output doesn't correspond to the ISO 639-1
-- standard for languages and the ISO 3166 standard for countries.
-- So, we have to convert the system locale output to the repsective ISO codes.
pos_ = string.find(loc, "_");
posdot = string.find(loc, "%.");
if pos_ then
    langsubstr = string.sub(loc, 1, pos_-1);
    if string.len(langsubstr) > 2 then
        langsubstr = lang_country_code[langsubstr];
    end
    if posdot then
        countrysubstr = string.sub(loc, pos_+1, posdot-1);
        if string.len(countrysubstr) > 2 then
            countrysubstr = lang_country_code[countrysubstr];
        end
    else
        countrysubstr = string.sub(loc, pos_+1, -1);
    end
    if langsubstr then
        lang = langsubstr;
        if countrysubstr and string.lower(countrysubstr) ~= langsubstr then
            -- Take the country code into account when it is present in the locale output.
            lang = langsubstr.."_"..countrysubstr;
            if not(pcall( function() require (lang) end )) then
                -- Don't take the country code into account when no localization is found.
                lang = langsubstr;
            end
        end
    end
else
    lang = language;
end

-- Set the numeric category to the system locale.
-- Only works with Lua 5.1.
if _VERSION == "Lua 5.1" then
    os.setlocale("", "numeric");
end

_ = function(string)
	if loc_str[string] then
		-- Return translated string if it exists.
		return loc_str[string];
	else
		-- Return default string if there is no translation available.
		return string;
	end
end

if loc_str == nil then loc_str = {} end

