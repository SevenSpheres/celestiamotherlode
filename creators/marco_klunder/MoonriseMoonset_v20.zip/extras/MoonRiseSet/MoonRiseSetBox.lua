----------------------------------------------
-- Set initial values
----------------------------------------------

if lua_edu_tools and lang ~= "en"
	then require "locale" 
	else require "MoonRiseSet_locale"
end

if pcall( function() require ("locale_MoonRiseSet_"..lang) end ) then
	for engl, transl in pairs(MoonRiseSet_loc_str) do
		loc_str[engl]=transl
	end
end

require "MoonRiseSet_config" 
   
--
--	Some constants, variables and useful unit conversions:
--

--Plug-in box dimension and initial position
local sx, sy = celestia:getscreendimension()
local oldsx, oldsy = 0, 0
local lspace = normalfont:getheight() + 1
local boxW1, boxH1 = 210, lspace * 10 + 8                  -- display width texts 210 pixels, display height = 10 lines + some margin
local posX1, posT1 = sx/2 + 220, 2                         -- near the top, 220 pixels left of the middle of the screen.
local boxW2 = 80                                           -- display width variables
local boxW3 = 80                                           -- display width of the script button

-- Constants
local p1=math.rad(180)
local p2=2*p1
local dr=p1/180
local k1=15*dr*1.0027379
local zone0=0
local script_MoonRiseSet = false
local uly_to_km = 9460730.4725808

-- Internationalization strings
local text_MoonRiseSet      = _("Moon Rise/Set")
local text_longitude        = _("Longitude:")
local text_latitude         = _("Latitude:")
local text_date             = _("Date:")
local text_azimuth          = _("Azimuth:")
local text_moonrise_at      = _("Moonrise at:")
local text_moonset_at       = _("Moonset at:")
local text_moondown         = _("Moon DOWN all day.")
local text_moonup           = _("Moon UP all day.")
local text_nomoonrise       = _("NO Moonrise this date.")
local text_nomoonset        = _("NO Moonset this date.")
local text_invalid_location = _("Invalid location in config file.")
local text_month1           = _(" Jan ")
local text_month2           = _(" Feb ")
local text_month3           = _(" Mar ")
local text_month4           = _(" Apr ")
local text_month5           = _(" May ")
local text_month6           = _(" Jun ")
local text_month7           = _(" Jul ")
local text_month8           = _(" Aug ")
local text_month9           = _(" Sep ")
local text_month10          = _(" Oct ")
local text_month11          = _(" Nov ")
local text_month12          = _(" Dec ")
local text_script           = _("Script")

local monthname={text_month1, text_month2,  text_month3,  text_month4,
                 text_month5, text_month6,  text_month7,  text_month8,
                 text_month9, text_month10, text_month11, text_month12}
local display1_text1a, display1_text2a, display1_text3a, display1_text4a, display1_text5a, display1_text6a, display2_text4a, display2_text5a, display2_text6a
local display1_text1b, display1_text2b, display1_text3b, display1_text4b, display1_text5b, display1_text6b, display2_text4b, display2_text5b, display2_text6b
local MRS_obs, MRS_earth, MRS_orig_ambient, MRS_orig_renderflags, MRS_static_date, MRS_tdb_juliandate, MRS_static, Old_MRS_long_earth, Old_MRS_lat_earth
local MRS_script, MRS_obs_pos, MRS_earth_pos, MRS_obs_earth, MRS_distance

-- Personalize
local display_MoonRiseSet = MoonRiseSet_visible or false
local text_color = MoonRiseSet_color or {0.2, 0.6, 0.9, 0.9}
local fill_color = MoonRiseSet_fillcolor or {0.3, 0.3, 0.3, 0.3}
local shortcut = MoonRiseSet_shortcut or "P"

local MRS_long_earth = MRMS_long_earth or nil                           -- Longitude in degrees
local MRS_lat_earth  = MRMS_lat_earth or nil                            -- Latitude in degrees
local MRS_location_name = MRMS_location_name or ""                      -- Fill in your own location name between the 2 quotes, belonging to your longlat position

local MRS_MoonRiseSet_Showlocation = MoonRiseSet_Showlocation or false  -- Determine if you want Celestia to display the location
                                                                        -- for which the Sunnrise and Sunset will be calculated.

local MRS_date_Year = MRMS_date_Year or nil                             -- Year
local MRS_date_Month = MRMS_date_Month or nil                           -- Month
local MRS_date_Day = MRMS_date_Day or nil                               -- Day

local MRS_ambient = MoonRiseSet_Ambient or 0.05

-- Determine if a predefined date is used
if MRS_date_Year ~= nil and MRS_date_Month ~= nil and MRS_date_Day ~= nil then
   MRS_static_date = true
   MRS_tdb_juliandate = celestia:utctotdb(MRS_date_Year, MRS_date_Month, MRS_date_Day, 12)
else
   MRS_static_date = false
end

-- Determine if a static location is used
if MRS_long_earth ~= nil and MRS_lat_earth ~= nil and MRS_location_name ~= "" then
   MRS_static = true
   -- Test/adjust Longitude and Latitude
   if MRS_lat_earth < -90 then
      MRS_lat_earth = -90
   elseif MRS_lat_earth > 90 then
      MRS_lat_earth = 90
   end
   if MRS_long_earth <= -360 or MRS_long_earth>=360 then
      MRS_long_earth = 0
   end
   if MRS_long_earth<0 then
      MRS_long_earth=MRS_long_earth+360
   end
   if MRS_long_earth>180 then
      MRS_long_earth=MRS_long_earth-360
   end
else
   MRS_static = false
   Old_MRS_long_earth = nil
   Old_MRS_lat_earth = nil
end
																		
-- Test if valid loacal timezone, otherwise UTC will be used.
local MRS_test = false
for MRS_i, value in ipairs(MRS_local_timezone_table) do
   if MRS_local_timezone_table[MRS_i] == MRS_local_timezone then
      MRS_test = true
   end
end
if not MRS_test then
   MRS_local_timezone="UTC"
end
local local_offset = MRS_offset[MRS_local_timezone]

---------------------
-- local functions --
---------------------

local toggleMoonRiseSetDisplay = function()
   MoonRiseSetFrame.Visible = not MoonRiseSetFrame.Visible
   MoonRiseSetFrame2.Visible = MoonRiseSetFrame.Visible
   MoonRiseSetFrame3.Visible = MoonRiseSetFrame.Visible
   MoonRiseSetFrame4.Visible = MoonRiseSetFrame.Visible
   MoonRiseSetFrame:orderfront() 
   if MoonRiseSetFrame.Visible then
      MRS_orig_renderflags = celestia:getrenderflags()
      MRS_orig_ambient=celestia:getambient()
      MRS_obs = celestia:getobserver()
      MRS_earth = celestia:find("Sol/Earth")
      celestia:setambient(MRS_ambient)
      MRS_earth:unmark()
      celestia:setrenderflags{markers=true}
      if not MRS_MoonRiseSet_Showlocation then
         MRS_obs:gotodistance(MRS_earth, 4*MRS_earth:radius(), 0.0)
         MRS_obs:synchronous(MRS_earth)
      end
      if MRS_static_date then
         celestia:settime(MRS_tdb_juliandate)
      end
   else
      MRS_earth:unmark()
      celestia:setrenderflags{markers=MRS_orig_renderflags.markers}
      celestia:setambient(MRS_orig_ambient)
   end
end

local function sign(value)
   -- Returns the sign of the parameter value.
   -- Returns 1 if the value is greater than zero, zero if equal to zero and -1 if negative.
   if value > 0 then
      return 1
   elseif value < 0 then
      return -1
   else
      return 0
   end
end

local MRS_get_long_lat = function (MRS_get_long_lat_observer, MRS_source)
   -- Return longitude and latitude for the observer on the MRS_source object
   local f = MRS_source:getinfo().oblateness
   if f == nil then
      f = 0
   end
   local u_pos = MRS_get_long_lat_observer:getposition()
   local e_frame = celestia:newframe("bodyfixed", MRS_source)
   local e_pos = e_frame:to(u_pos)
   local lambda = -math.atan2(e_pos.z, e_pos.x);
   local beta = math.pi / 2 - math.atan2(math.sqrt(e_pos.x * e_pos.x + e_pos.z * e_pos.z), e_pos.y)
   local phi = math.atan2(math.tan(beta), (1 - f))
   local long = math.deg(lambda)
   local lat = math.deg(phi)
   return long, lat
end

local function MoonRiseSet_location()
   local MRS_obs_temp=celestia:getobserver()
   if MRS_static then
      -- Static location
	   return true
   else
      -- Dynamic location
      local actual_selection = celestia:getselection()
      MRS_location_name = ""
      local locationbased = false
      if actual_selection:type() == "location" then
         local parent_object = actual_selection:getinfo().parent
         if parent_object:name() == "Earth" then
            MRS_location_name = actual_selection:localname()
            if MRS_location_name == "?" then
               MRS_location_name = actual_selection:name()
            end
            MRS_obs_temp:setframe(celestia:newframe("universal"))
            local now = celestia:gettime()
            local pos_actual_selection = actual_selection:getposition(now)
            local pos_earth = MRS_earth:getposition(now)
            local u_pos = pos_earth + 4*(pos_actual_selection - pos_earth)
            local f = MRS_earth:getinfo().oblateness
            if f == nil then
               f = 0
            end
            local e_frame = celestia:newframe("bodyfixed", MRS_earth)
            local e_pos = e_frame:to(u_pos)
            local lambda = -math.atan2(e_pos.z, e_pos.x);
            local beta = math.pi / 2 - math.atan2(math.sqrt(e_pos.x * e_pos.x + e_pos.z * e_pos.z), e_pos.y)
            local phi = math.atan2(math.tan(beta), (1 - f))
            MRS_long_earth = math.deg(lambda)
            MRS_lat_earth = math.deg(phi)
            locationbased = true
         end
      end
      if not locationbased then
         MRS_long_earth, MRS_lat_earth = MRS_get_long_lat(MRS_obs_temp, MRS_earth)
      end
      return true
   end
end

local function MoonRiseSet_calculate()
   local i, L, M, F, D, N, G, V, U, W, A5, D7, R5, Z1, C, Z, M8, W8, A0, D0, test_MRS_nr
   local C0, P, A, A2, B, D1, D2, C7, L0, L2, H0, H1, H2, H3, H7, V0, V1, V2, text, E, M3, T3, N7, AZ
   local HH_UTC_1st, MM_UTC_1st, AZ_1st, text_1st, HH_UTC_2nd, MM_UTC_2nd, AZ_2nd, text_2nd
   local tdb2, tdb2_local, local_dt, year_local_2nd, month_local_2nd, day_local_2nd, HH_local_2nd, MM_local_2nd
   local tdb1, tdb1_local, year_local_1st, month_local_1st, day_local_1st, HH_local_1st, MM_local_1st
   local actual_tdbtime, ut = {}, year_UTC, month_UTC, day_UTC, g, d1, f, j, s, a, j3, t, tt, t0, S
   local ra_moon1, dec_moon1, dist_moon1, ra_moon2, dec_moon2, dist_moon2, ra_moon3, dec_moon3, dist_moon3

   -- Get the Calendar date from Celestia --> JD
   actual_tdbtime = celestia:gettime()
   ut = celestia:tdbtoutc(actual_tdbtime)
   year_UTC  = ut.year
   month_UTC = ut.month
   day_UTC   = ut.day
   -- NO "1583: Calendar reform" issue in Celestia (according original BASIC program)
   d1=math.floor(day_UTC)
   f=day_UTC-d1-0.5
   j=-math.floor(7*(math.floor((month_UTC+9)/12)+year_UTC)/4)
   s=sign(month_UTC-9)
   a=math.abs(month_UTC-9)
   j3=math.floor(year_UTC + s*math.floor(a/7))
   j3=-math.floor((math.floor(j3/100) + 1)*3/4)
   j=j + math.floor(275*month_UTC/9) + d1 + j3
   j=j + 1721029 + 367*year_UTC
   if f<0 then
      f=f+1
      j=j-1
   end
   -- Julianday 2451545 = 1-1-2000 12:00
   t=(j-2451545) + f
   -- tt = centuries from 1900.0
   tt=t/36525 + 1
   -- Local Sidereal Time at 0h zone time
   t0=t/36525
   S=24110.5 + 8640184.813*t0
   S=S + 86636.6*zone0 + 86400*MRS_long_earth/360
   S=S/86400
   S=S-math.floor(S)
   t0=S*360*dr

   t=t+zone0
   -- Position loop
   for i=1,3 do
      -- Fundamental arguments
      L=0.606434 + 0.03660110129*t
      M=0.374897 + 0.03629164709*t
      F=0.259091 + 0.03674819520*t
      D=0.827362 + 0.03386319198*t
      N=0.347343 - 0.00014709391*t
      G=0.993126 + 0.00273777850*t
      L=L-math.floor(L)
      M=M-math.floor(M)
      F=F-math.floor(F)
      D=D-math.floor(D)
      N=N-math.floor(N)
      G=G-math.floor(G)
      L=L*p2
      M=M*p2
      F=F*p2
      D=D*p2
      N=N*p2
      G=G*p2
      V=0.39558*math.sin(F+N)
      V=V + 0.08200*math.sin(F)
      V=V + 0.03257*math.sin(M - F - N)
      V=V + 0.01092*math.sin(M + F + N)
      V=V + 0.00666*math.sin(M - F)
      V=V - 0.00644*math.sin(M + F - 2*D + N)
      V=V - 0.00331*math.sin(F - 2*D + N)
      V=V - 0.00304*math.sin(F - 2*D)
      V=V - 0.00240*math.sin(M - F - 2*D - N)
      V=V + 0.00226*math.sin(M + F)
      V=V - 0.00108*math.sin(M + F - 2*D)
      V=V - 0.00079*math.sin(F - N)
      V=V + 0.00078*math.sin(F + 2*D + N)
      U=1 - 0.10828*math.cos(M)
      U=U - 0.01880*math.cos(M - 2*D)
      U=U - 0.01479*math.cos(2*D)
      U=U + 0.00181*math.cos(2*M - 2*D)
      U=U - 0.00147*math.cos(2*M)
      U=U - 0.00105*math.cos(2*D - G)
      U=U - 0.00075*math.cos(M - 2*D + G)
      W=0.10478*math.sin(M)
      W=W - 0.04105*math.sin(2*F + 2*N)
      W=W - 0.02130*math.sin(M - 2*D)
      W=W - 0.01779*math.sin(2*F + N)
      W=W + 0.01774*math.sin(N)
      W=W + 0.00987*math.sin(2*D)
      W=W - 0.00338*math.sin(M - 2*F - 2*N)
      W=W - 0.00309*math.sin(G)
      W=W - 0.00190*math.sin(2*F)
      W=W - 0.00144*math.sin(M + N)
      W=W - 0.00144*math.sin(M - 2*F - N)
      W=W - 0.00113*math.sin(M + 2*F + 2*N)
      W=W - 0.00094*math.sin(M - 2*D + G)
      W=W - 0.00092*math.sin(2*M - 2*D)
      -- Compute RA, DEC, DIST
      S=W/math.sqrt(U - V*V)
      A5=L + math.atan(S/math.sqrt(1 - S*S))
      S=V/math.sqrt(U)
      D7=math.atan(S/math.sqrt(1 - S*S))
      R5=60.40974*math.sqrt(U)
      if i==1 then
         ra_moon1=A5
         dec_moon1=D7
         dist_moon1=R5
      elseif i==2 then
         ra_moon2=A5
         dec_moon2=D7
         dist_moon2=R5
      else
         ra_moon3=A5
         dec_moon3=D7
         dist_moon3=R5
      end
      t=t+0.5
   end

   if ra_moon2<=ra_moon1 then
      ra_moon2=ra_moon2+p2
   end
   if ra_moon3<=ra_moon2 then
      ra_moon3=ra_moon3+p2
   end

   -- Zenith dist.
   Z1=dr*(90.567 - 41.685/dist_moon2)
   S=math.sin(MRS_lat_earth*dr)
   C=math.cos(MRS_lat_earth*dr)
   Z=math.cos(Z1)
   M8=0
   W8=0

   A0=ra_moon1
   D0=dec_moon1
   test_MRS_nr=0
   for C0=0,23 do
      P=(C0 + 1)/24
      -- 3-point interpolation
      A=ra_moon2 - ra_moon1
      B=ra_moon3 - ra_moon2 - A
      F=ra_moon1 + P*(2*A + B*(2*P - 1))
      A2=F
      -- 3-point interpolation
      A=dec_moon2 - dec_moon1
      B=dec_moon3 - dec_moon2 - A
      F=dec_moon1 + P*(2*A + B*(2*P - 1))
      D2=F
      -- Test an hour for an event
      L0=t0 + C0*k1
      L2=L0 + k1
      if A2<A0 then
         A2=A2 + 2*math.rad(180)
      end
      H0=L0 - A0
      H2=L2 - A2
      -- Hour angle
      H1=(H2 + H0)/2
      -- Declination, at half hour
      D1=(D2 + D0)/2
      if C0<=0 then
         V0=S*math.sin(D0) + C*math.cos(D0)*math.cos(H0) - Z
      end
      V2=S*math.sin(D2) + C*math.cos(D2)*math.cos(H2) - Z
      if sign(V0)<sign(V2) or sign(V0)>sign(V2) then
         V1=S*math.sin(D1) + C*math.cos(D1)*math.cos(H1) - Z
         A=2*V2 - 4*V1 + 2*V0
	      B=4*V1 - 3*V0 - V2
         D=B*B - 4*A*V0
         if D>=0 then
            D=math.sqrt(D)
            if V0<0 and V2>0 then
               text=text_moonrise_at
               M8=1
            end
            if V0>0 and V2<0 then
               text=text_moonset_at
               W8=1
            end
            E=(-B + D)/(2*A)
            if E>1 or E<0 then
               E=(-B - D)/(2*A)
            end
            T3=C0 + E + 1/120
		      -- Round off
            H3=math.floor(T3)
		      M3=math.floor((T3 - H3)*60)
		      if H3<0 then
		         H3=H3+24
            end
            H7=H0 + E*(H2 - H0)
            N7=-math.cos(D1)*math.sin(H7)
            D7=C*math.sin(D1) - S*math.cos(D1)*math.cos(H7)
            AZ=math.atan(N7/D7)/dr
            if D7<0 then
               AZ=AZ + 180
            end
            if AZ<0 then
               AZ=AZ + 360
            end
            if AZ>360 then
               AZ=AZ - 360
            end
            if test_MRS_nr==0 then
               HH_UTC_1st=H3
               MM_UTC_1st=M3
               AZ_1st=AZ
               text_1st=text
               test_MRS_nr=1
               --celestia:log("Time1 = " .. HH_UTC_1st .. MM_UTC_1st .. AZ_1st)
            else
               HH_UTC_2nd=H3
               MM_UTC_2nd=M3
               AZ_2nd=AZ
               text_2nd=text
               test_MRS_nr=2
               --celestia:log("Time2 = " .. HH_UTC_2nd .. MM_UTC_2nd .. AZ_2nd)
            end
         end
      end
      A0=A2
      D0=D2
      V0=V2
   end

   -- Display
   if M8==0 and W8==0 then
      if V2<0 then
         display1_text1a = MRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", MRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", MRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display1_text5a = text_moondown
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = ""
         display2_text4b = ""
         display2_text5a = ""
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      end
      if V2>0 then
         display1_text1a = MRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", MRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", MRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display1_text5a = text_moonup
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = ""
         display2_text4b = ""
         display2_text5a = ""
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      end
   else
      if M8==0 then
         tdb2=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb2_local=tdb2+local_offset
         local_dt=celestia:tdbtoutc(tdb2_local)
         year_local_2nd=local_dt.year
         month_local_2nd=local_dt.month
         day_local_2nd=local_dt.day
         HH_local_2nd=local_dt.hour
         MM_local_2nd=local_dt.minute
         display1_text1a = MRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", MRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", MRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display1_text5a = text_nomoonrise
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = text_date
         display2_text4b = day_local_2nd .. monthname[month_local_2nd] .. year_local_2nd
         display2_text5a = text_1st
         display2_text5b = string.format("%02i:%02i ", HH_local_2nd, MM_local_2nd) .. MRS_local_timezone
         display2_text6a = text_azimuth
         display2_text6b = string.format("%5.2f°", AZ_1st)
      elseif W8==0 then
         tdb1=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb1_local=tdb1+local_offset
         local_dt=celestia:tdbtoutc(tdb1_local)
         year_local_1st=local_dt.year
         month_local_1st=local_dt.month
         day_local_1st=local_dt.day
         HH_local_1st=local_dt.hour
         MM_local_1st=local_dt.minute
         display1_text1a = MRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", MRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", MRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_local_1st .. monthname[month_local_1st] .. year_local_1st
         display1_text5a = text_1st
         display1_text5b = string.format("%02i:%02i ", HH_local_1st, MM_local_1st) .. MRS_local_timezone
         display1_text6a = text_azimuth
         display1_text6b = string.format("%5.2f°", AZ_1st)
         display2_text4a = text_date
         display2_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display2_text5a = text_nomoonset
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      else
         tdb1=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb1_local=tdb1+local_offset
         local_dt=celestia:tdbtoutc(tdb1_local)
         year_local_1st=local_dt.year
         month_local_1st=local_dt.month
         day_local_1st=local_dt.day
         HH_local_1st=local_dt.hour
         MM_local_1st=local_dt.minute
         tdb2=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_2nd, MM_UTC_2nd)
         tdb2_local=tdb2+local_offset
         local_dt=celestia:tdbtoutc(tdb2_local)
         year_local_2nd=local_dt.year
         month_local_2nd=local_dt.month
         day_local_2nd=local_dt.day
         HH_local_2nd=local_dt.hour
         MM_local_2nd=local_dt.minute
         display1_text1a = MRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", MRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", MRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_local_1st .. monthname[month_local_1st] .. year_local_1st
         display1_text5a = text_1st
         display1_text5b = string.format("%02i:%02i ", HH_local_1st, MM_local_1st) .. MRS_local_timezone
         display1_text6a = text_azimuth
         display1_text6b = string.format("%5.2f°", AZ_1st)
         display2_text4a = text_date
         display2_text4b = day_local_2nd .. monthname[month_local_2nd] .. year_local_2nd
         display2_text5a = text_2nd
         display2_text5b = string.format("%02i:%02i ", HH_local_2nd, MM_local_2nd) .. MRS_local_timezone
         display2_text6a = text_azimuth
         display2_text6b = string.format("%5.2f°", AZ_2nd)
      end
   end
end



----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
MoonRiseSetBox = CXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
    :attach(screenBox, sx, sy, 0, 0);

--
-- Box to show the Moon Rise/Set variables
--

MoonRiseSetFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text(text_MoonRiseSet)
    :movetext(-5,4)
    :fillcolor(fill_color)
    :movable(true)
    :clickable(false)
    :visible(display_MoonRiseSet)
    :attach(screenBox, posX1, sy-posT1-boxH1, sx-boxW1-posX1, posT1)

-- Variable area
MoonRiseSetFrame2 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("")
    :movetext(-5,4)
    :movable(false)
    :clickable(true)
    :visible(display_MoonRiseSet)
    :attach(MoonRiseSetFrame, boxW1-boxW2, 0, 0, 0)

-- Script button
MoonRiseSetFrame3 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text(text_script)
    :textpos("center")
    :fillcolor(fill_color)
    :movetext(0, 8)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(display_MoonRiseSet)
    :attach(MoonRiseSetFrame, boxW1/2-boxW3/2, 2, boxW1/2-boxW3/2, boxH1-lspace-2)

-- Close button
MoonRiseSetFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("x")
    :textpos("center")
    :fillcolor(fill_color)
    :movetext(0, 10)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(display_MoonRiseSet)
    :attach(MoonRiseSetFrame, boxW1-10, boxH1-10, 0, 0)
  
MoonRiseSetFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*2+2)
   MRS_obs=celestia:getobserver()
   if MoonRiseSet_location() then
      -- Valid static location or dynamic calculation determined by Celestia
      if MRS_MoonRiseSet_Showlocation and (Old_MRS_long_earth ~= MRS_long_earth or Old_MRS_lat_earth ~= MRS_lat_earth or MRS_static) then
         -- Display the location for which the Moonnrise and Moonset will be calculated.
         Old_MRS_long_earth = MRS_long_earth
         Old_MRS_lat_earth = MRS_lat_earth
         MRS_obs:gotolonglat(MRS_earth, math.rad(MRS_long_earth), math.rad(MRS_lat_earth), 4*MRS_earth:radius(), 0.0)
      end
      MRS_obs:synchronous(MRS_earth)
      -- Test possibility if script is running (by observer position) with different ambient light level.
      MRS_obs_pos = MRS_obs:getposition()
      MRS_earth_pos = MRS_earth:getposition()
      MRS_obs_earth = MRS_obs_pos - MRS_earth_pos
      MRS_distance = MRS_obs_earth:length() * uly_to_km
      if MRS_distance <= (MRS_earth:radius() + 10) or (MRS_distance >= 4.04 * MRS_earth:radius() and MRS_distance <= 4.06 * MRS_earth:radius()) then
         MRS_script = true
      else
         MRS_script = false
      end
      -- Reset ambient light level if necessary, except when script is running
      if math.abs(celestia:getambient() - MRS_ambient) > 0.01 and not MRS_script  then
         MRS_orig_ambient=celestia:getambient()
         celestia:setambient(MRS_ambient)
      end
      -- Reset markers if turned off and mark location on Earth
      local MRS_renderflags = celestia:getrenderflags()
      if not MRS_renderflags.markers then
         celestia:setrenderflags{markers=true}
      end
      MRS_earth:unmark()
      if MRS_MoonRiseSet_Showlocation then
         MRS_earth:mark("red", "diamond", 10, 1, MRS_location_name, false)
      else
         MRS_earth:mark("yellow", "plus", 10, 1, "", false)
      end
      -- Calculate Moonrise and Moonset times for this date, including their Azimuth and show Title line items in the box.
      MoonRiseSet_calculate()
      textlayout:println(display1_text1a)
      textlayout:println(display1_text2a)
      textlayout:println(display1_text3a)
      textlayout:println(display1_text4a)
      textlayout:println(display1_text5a)
      textlayout:println(display1_text6a)
      textlayout:println(display2_text5a)
      textlayout:println(display2_text6a)
   else
      -- Invalid static location entered in the configuration file.
      textlayout:println(text_invalid_location)
   end  
   -- Check changed screen dimensions and reposition the box if necessary
   oldsx, oldsy = sx, sy
   sx, sy = celestia:getscreendimension()
   if sx ~= oldsx or sy ~= oldsy then
      posX1, posT1 = sx/2 + 220, 2
      MoonRiseSetFrame:attach(screenBox, posX1, sy-posT1-boxH1, sx-boxW1-posX1, posT1)
   end
end

-- Show Calculated line items, all aligned in a separate box, attached to the primary box.
MoonRiseSetFrame2.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*2+2)
   textlayout:println(display1_text1b)
   textlayout:println(display1_text2b)
   textlayout:println(display1_text3b)
   textlayout:println(display1_text4b)
   textlayout:println(display1_text5b)
   textlayout:println(display1_text6b)
   textlayout:println(display2_text5b)
   textlayout:println(display2_text6b)
   MoonRiseSetFrame2:attach(MoonRiseSetFrame, boxW1-boxW2, 0, 0, 0)
end

-- Script button
MoonRiseSetFrame3.Customdraw = function(this)
    MoonRiseSetFrame3:attach(MoonRiseSetFrame, boxW1/2-boxW3/2, 3, boxW1/2-boxW3/2, boxH1-lspace-2)
end

-- Close button
MoonRiseSetFrame4.Customdraw = function(this)
    MoonRiseSetFrame4:attach(MoonRiseSetFrame, boxW1-10, boxH1-10, 0, 0)
end

--
-- Box in the Toolkit of Lua_Edu_Tools to select/deselect the application (instead of [key shortcut]).
--

if lua_edu_tools then
   MoonRiseSetSwitch = CXBox:new()
       :init(0, 0, 0, 0)
       :bordercolor(cbubordoff)
       :textfont(normalfont)
       :textcolor(cbutextoff)
       :textpos("center")
       :movetext(0, 8)
       :text(text_MoonRiseSet)
       :movable(false)
       :active(true)
       :attach(MoonRiseSetBox, 8, 4, 8, 3)

   MoonRiseSetSwitch.Action = (function()
        return
            function()
                display_MoonRiseSet = not display_MoonRiseSet;
                if display_MoonRiseSet then
                   MoonRiseSetSwitch.Bordercolor=cbubordon
                   MoonRiseSetSwitch.Fillcolor = {cbubordon[1]*2/3, cbubordon[2]*2/3, cbubordon[3]*2/3, cbubordon[4]/2}
                   MRS_orig_renderflags = celestia:getrenderflags()
                   MRS_orig_ambient=celestia:getambient()
                   MRS_obs = celestia:getobserver()
                   MRS_earth = celestia:find("Sol/Earth")
                   celestia:setambient(MRS_ambient)
                   MRS_earth:unmark()
                   celestia:setrenderflags{markers=true}
                   if not MRS_MoonRiseSet_Showlocation then
                      MRS_obs:gotodistance(MRS_earth, 4*MRS_earth:radius(), 0.0)
                      MRS_obs:synchronous(MRS_earth)
                   end
                   if MRS_static_date then
                      celestia:settime(MRS_tdb_juliandate)
                   end
                   MoonRiseSetFrame.Visible = true
                   MoonRiseSetFrame2.Visible = true
                   MoonRiseSetFrame3.Visible = true
                   MoonRiseSetFrame4.Visible = true
                   MoonRiseSetFrame:orderfront() 
                else
                   MoonRiseSetSwitch.Bordercolor=cbubordoff
                   MoonRiseSetSwitch.Fillcolor = nil
                   MRS_earth:unmark()
                   celestia:setrenderflags{markers=MRS_orig_renderflags.markers}
                   celestia:setambient(MRS_orig_ambient)
                   MoonRiseSetFrame.Visible = false
                   MoonRiseSetFrame2.Visible = false
                   MoonRiseSetFrame3.Visible = false
                   MoonRiseSetFrame4.Visible = false
                end
            end
        end) ();
else
   keymap[shortcut] = toggleMoonRiseSetDisplay
end

-- Script button
MoonRiseSetFrame3.Action = (function()
     return
         function()
             script_MoonRiseSet = not script_MoonRiseSet
             if script_MoonRiseSet then
                celestia:runscript("../../scripts/MoonriseMoonset_20.celx")
                script_MoonRiseSet = not script_MoonRiseSet
             end
         end
     end) ();

-- Close button
MoonRiseSetFrame4.Action = (function()
     return
         function()
             if lua_edu_tools then
                MoonRiseSetSwitch.Bordercolor=cbubordoff
                MoonRiseSetSwitch.Fillcolor = nil
             end
             display_MoonRiseSet = not display_MoonRiseSet;
             MRS_earth:unmark()
             celestia:setrenderflags{markers=MRS_orig_renderflags.markers}
             celestia:setambient(MRS_orig_ambient)
             MoonRiseSetFrame.Visible = false
             MoonRiseSetFrame2.Visible = false
             MoonRiseSetFrame3.Visible = false
             MoonRiseSetFrame4.Visible = false
         end
     end) ();
