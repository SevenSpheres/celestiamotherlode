-------------------------------------------------------------
-- Configuration file for Constellations Plug-in addon.
-- Change the values to customize the tool.
-- If an item is not defined, a default value will be used.
-------------------------------------------------------------

-------------------------------------------------------------
-- Launching key with lua_plugins.
-- If not defined, the default is "/".
-- No effect in lua_edu_tools.
-------------------------------------------------------------
Constellations_shortcut="/"

-------------------------------------------------------------
-- Indicate if the Constellations tool is visible at startup.
-------------------------------------------------------------
Constellations_visible = false

-------------------------------------------------------------
-- Indicate if the Constellations labels must be shown.
-------------------------------------------------------------
Constellation_Labels = true
--Constellation_Labels = false

-------------------------------------------------------------------------------------------------------
-- Define colors of elements of the Graphical Interface
-- Colors are defined using {Red, Green, Blue, Alpha} color code where
-- Red, Green, Blue and Alpha are decimal values between 0 and 1.
-------------------------------------------------------------------------------------------------------
Constellations_cbutextoff = {0.8, 0.9, 0.9, 0.8}     -- unactivated button text color
Constellations_cbubordoff = {0.2, 0.4 , 0.4, 0.9}    -- unactivated button border color
Constellations_csetbofill = {0.3, 0.5 , 0.5, 0.3}    -- setting box filling color
