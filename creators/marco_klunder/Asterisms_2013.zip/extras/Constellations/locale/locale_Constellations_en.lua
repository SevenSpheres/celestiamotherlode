-- Constellations

Constellations_loc_str = {
   ["Constellations"] = "Constellations";
   ["Default"] = "Default";
   ["Western (Wiki)"] = "Western (Wiki)";
   ["Francais (Wiki)"] = "French (Wiki)";
   ["Polski (Wiki)"] = "Polish (Wiki)";
   ["Chandra"] = "Chandra";
   ["Chinese"] = "Chinese";
   ["Indigenous Brazilian"] = "Indigenous Brazilian";
   ["Sami"] = "Sami";
   ["Norse"] = "Norwegian";
   ["IAU"] = "IAU";
   ["Hawaiian"] = "Hawaiian";
   ["Asterisms"] = "Asterisms";
   ["Constellation Aliases"] = "Constellation Aliases";
   ["Large Seasonal Asterisms"] = "Large Seasonal Asterisms";
   ["Asterisms in Orion"] = "Asterisms in Orion";
   ["Sword of Orion"] = "Sword of Orion";
   ["Belt of Orion"] = "Belt of Orion";
   ["Butterfly of Orion"] = "Butterfly of Orion";
   ["Venus Mirror"] = "Venus Mirror";
   ["Heavenly G"] = "Heavenly G";
   ["Asterisms in Hercules"] = "Asterisms in Hercules";
   ["Keystone"] = "Keystone";
   ["Hercules' Club"] = "Hercules' Club";
   ["Butterfly of Hercules"] = "Butterfly of Hercules";
   ["Asterisms in Ursa Major"] = "Asterisms in Ursa Major";
   ["Horse and Rider"] = "Horse and Rider";
   ["Bier"] = "Bier";
   ["Big Dipper"] = "Big Dipper";
   ["Pointers"] = "Pointers";
   ["Asterisms in Aquarius"] = "Asterisms in Aquarius";
   ["Y of Aquarius"] = "Y of Aquarius";
   ["Water Jar"] = "Water Jar";
   ["Other Asterisms"] = "Other Asterisms";
}
