-- Constellations

Constellations_loc_str = {
   ["Constellations"] = "Costellazioni";
   ["Default"] = "Standard";
   ["Western (Wiki)"] = "Ovest (Wiki)";
   ["Francais (Wiki)"] = "Francese (Wiki)";
   ["Polski (Wiki)"] = "Polacco (Wiki)";
   ["Chandra"] = "Chandra";
   ["Chinese"] = "Cinese";
   ["Indigenous Brazilian"] = "Indigeni Brasiliani";
   ["Sami"] = "Sami";
   ["Norse"] = "Norvegese";
   ["IAU"] = "UAI";
   ["Hawaiian"] = "Hawaiano";
   ["Asterisms"] = "Asterismi";
   ["Constellation Aliases"] = "Costellazione Alias";
   ["Large Seasonal Asterisms"] = "Grande Asterismi Stagionale";
   ["Asterisms in Orion"] = "Asterismi in Orion";
   ["Sword of Orion"] = "Spada di Orione";
   ["Belt of Orion"] = "Cintura di Orione";
   ["Butterfly of Orion"] = "Farfalla di Orion";
   ["Venus Mirror"] = "Specchio di Venere";
   ["Heavenly G"] = "G Celeste";
   ["Asterisms in Hercules"] = "Asterismi in Hercules";
   ["Keystone"] = "Fulcro";
   ["Hercules' Club"] = "La Clava di Hercules";
   ["Butterfly of Hercules"] = "Farfalla o Hercules";
   ["Asterisms in Ursa Major"] = "Asterismi nell'Orsa Maggiore";
   ["Horse and Rider"] = "Cavallo e Cavaliere";
   ["Bier"] = "Bier";
   ["Big Dipper"] = "Grande Carro";
   ["Pointers"] = "Puntatori";
   ["Asterisms in Aquarius"] = "Asterismi in Acquario";
   ["Y of Aquarius"] = "Y dell'Acquario";
   ["Water Jar"] = "Pentola di Acqua";
   ["Other Asterisms"] = "Altri Asterismi";
}
