-- Constellations

Constellations_loc_str = {
   ["Constellations"] = "Sternbilder";
   ["Default"] = "Standard";
   ["Western (Wiki)"] = "Westlich (Wiki)";
   ["Francais (Wiki)"] = "Französisch (Wiki)";
   ["Polski (Wiki)"] = "Polnisch (Wiki)";
   ["Chandra"] = "Chandra";
   ["Chinese"] = "Chinese";
   ["Indigenous Brazilian"] = "Indigene Brasilianisch";
   ["Sami"] = "Sami";
   ["Norse"] = "Norwegisch";
   ["IAU"] = "IAU";
   ["Hawaiian"] = "Hawaiianisch";
   ["Asterisms"] = "Asterismus";
   ["Constellation Aliases"] = "Sternbild-Aliase";
   ["Large Seasonal Asterisms"] = "Große Saisonale Asterismus";
   ["Asterisms in Orion"] = "Asterismus im Orion";
   ["Sword of Orion"] = "Schwert des Orion";
   ["Belt of Orion"] = "Gürtel des Orion";
   ["Butterfly of Orion"] = "Schmetterling von Orion";
   ["Venus Mirror"] = "Venus-Spiegel";
   ["Heavenly G"] = "Himmlische G";
   ["Asterisms in Hercules"] = "Asterismus in Herkules";
   ["Keystone"] = "Eckstein";
   ["Hercules' Club"] = "Die Keule des Herkules";
   ["Butterfly of Hercules"] = "Schmetterling von Herkules";
   ["Asterisms in Ursa Major"] = "Asterismus in Großer Bär";
   ["Horse and Rider"] = "Pferd und Reiter";
   ["Bier"] = "Bier";
   ["Big Dipper"] = "Großer Wagen";
   ["Pointers"] = "Zeiger";
   ["Asterisms in Aquarius"] = "Asterismus im Wassermann";
   ["Y of Aquarius"] = "Y Wassermann";
   ["Water Jar"] = "Wasser Topf";
   ["Other Asterisms"] = "Andere Asterismus";
}
