-- Constellations

Constellations_loc_str = {
   ["Constellations"] = "Sterrenbeelden";
   ["Default"] = "Standaard";
   ["Western (Wiki)"] = "Westers (Wiki)";
   ["Francais (Wiki)"] = "Frans (Wiki)";
   ["Polski (Wiki)"] = "Pools (Wiki)";
   ["Chandra"] = "Chandra";
   ["Chinese"] = "Chinees";
   ["Indigenous Brazilian"] = "Inheems Braziliaans";
   ["Sami"] = "Sami";
   ["Norse"] = "Noors";
   ["IAU"] = "IAU";
   ["Hawaiian"] = "Hawaiaans";
   ["Asterisms"] = "Asterismen";
   ["Constellation Aliases"] = "Sterrenbeelden Aliassen";
   ["Large Seasonal Asterisms"] = "Grote Seizoen Asterismen";
   ["Asterisms in Orion"] = "Asterismen in Orion";
   ["Sword of Orion"] = "Zwaard van Orion";
   ["Belt of Orion"] = "Gordel van Orion";
   ["Butterfly of Orion"] = "Vlinder in Orion";
   ["Venus Mirror"] = "Venus Spiegel";
   ["Heavenly G"] = "Hemelse G";
   ["Asterisms in Hercules"] = "Asterismen in Hercules";
   ["Keystone"] = "Hoeksteen";
   ["Hercules' Club"] = "Knuppel van Hercules";
   ["Butterfly of Hercules"] = "Vlinder in Hercules";
   ["Asterisms in Ursa Major"] = "Asterismen in Grote Beer";
   ["Horse and Rider"] = "Paard en Ruiter";
   ["Bier"] = "Bier";
   ["Big Dipper"] = "Steelpan";
   ["Pointers"] = "Aanwijzers";
   ["Asterisms in Aquarius"] = "Asterismen in Waterman";
   ["Y of Aquarius"] = "Y in Waterman";
   ["Water Jar"] = "Water Pot";
   ["Other Asterisms"] = "Overige Asterismen";
}
