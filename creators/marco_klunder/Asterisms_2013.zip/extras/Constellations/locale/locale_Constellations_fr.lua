-- Constellations

Constellations_loc_str = {
   ["Constellations"] = "Constellations";
   ["Default"] = "Standard";
   ["Western (Wiki)"] = "Occidental (Wiki)";
   ["Francais (Wiki)"] = "Français (Wiki)";
   ["Polski (Wiki)"] = "Polonais (Wiki)";
   ["Chandra"] = "Chandra";
   ["Chinese"] = "Chinois";
   ["Indigenous Brazilian"] = "Indigène Brésilien";
   ["Sami"] = "Sami";
   ["Norse"] = "Norvégien";
   ["IAU"] = "UAI";
   ["Hawaiian"] = "Hawaïen";
   ["Asterisms"] = "Astérismes";
   ["Constellation Aliases"] = "Constellation Alias";
   ["Large Seasonal Asterisms"] = "Grands Astérismes Saisonniers";
   ["Asterisms in Orion"] = "Astérismes dans Orion";
   ["Sword of Orion"] = "Épée d'Orion";
   ["Belt of Orion"] = "Ceinture d'Orion";
   ["Butterfly of Orion"] = "Papillon d'Orion";
   ["Venus Mirror"] = "Miroir de Vénus";
   ["Heavenly G"] = "G Céleste";
   ["Asterisms in Hercules"] = "Astérismes dans Hercules";
   ["Keystone"] = "Pierre Angulaire";
   ["Hercules' Club"] = "La massue d'Hercule";
   ["Butterfly of Hercules"] = "Papillon d'Hercule";
   ["Asterisms in Ursa Major"] = "Astérismes en Grande Ourse";
   ["Horse and Rider"] = "Cheval et Cavalier";
   ["Bier"] = "Bière";
   ["Big Dipper"] = "Grande Casserole";
   ["Pointers"] = "Pointeurs";
   ["Asterisms in Aquarius"] = "Astérismes en Verseau";
   ["Y of Aquarius"] = "Y du Verseau";
   ["Water Jar"] = "Pot de l'Eau";
   ["Other Asterisms"] = "Autres Astérismes";
}
