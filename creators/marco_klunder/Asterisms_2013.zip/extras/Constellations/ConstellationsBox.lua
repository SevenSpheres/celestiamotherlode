----------------------------------------------
-- Set initial values
----------------------------------------------

if lua_edu_tools and lang ~= "en"
	then require "locale" 
	else require "Constellations_locale"
end

if pcall( function() require ("locale_Constellations_"..lang) end ) then
	for engl, transl in pairs(Constellations_loc_str) do
		loc_str[engl]=transl
	end
end

require "Constellations_config" 
   
--
--	Some constants, variables and useful unit conversions:
--

--Plug-in box dimension and initial position
local sxC, syC = celestia:getscreendimension()
local sxA, syA = sxC, syC
local sxO, syO = sxC, syC
local sxUM, syUM = sxC, syC
local sxAq, syAq = sxC, syC
local oldsxC, oldsyC = 0, 0
local oldsxA, oldsyA = oldsxC, oldsyC
local oldsxO, oldsyO = oldsxC, oldsyC
local oldsxUM, oldsyUM = oldsxC, oldsyC
local oldsxAq, oldsyAq = oldsxC, oldsyC
local number_const_series = 11
local number_asterism_series = 7
local number_Orion_asterisms = 5
local number_UrsaMajor_asterisms = 4
local number_Aquarius_asterisms = 2
local lspace = normalfont:getheight() + 1
local boxW1, boxH1 = 190, lspace*(number_const_series+3) + 4         -- display width, display height
local posX1, posT1 = sxC/2 - boxW1/2, 2                              -- near the top, in the middle of the screen
local posX1a, posT1a = posX1, posT1                                  -- Remember initial position  
local boxW2, boxH2 = 190, lspace*(number_asterism_series+3) + 4      -- display width, display height
local posX2, posT2 = posX1, posT1                                    -- Remember initial position  
--local posX2, posT2 = sxA/2 - boxW2/2, 2                            -- near the top, in the middle of the screen
local boxW3, boxH3 = 190, lspace*(number_Orion_asterisms+3) + 4      -- display width, display height
local posX3, posT3 = posX1, posT1                                    -- Remember initial position  
--local posX3, posT3 = sxO/2 - boxW3/2, 2                            -- near the top, in the middle of the screen
local boxW4, boxH4 = 190, lspace*(number_UrsaMajor_asterisms+3) + 4  -- display width, display height
local posX4, posT4 = posX1, posT1                                    -- Remember initial position  
--local posX4, posT4 = sxUM/2 - boxW4/2, 2                           -- near the top, in the middle of the screen
local boxW5, boxH5 = 190, lspace*(number_Aquarius_asterisms+3) + 4   -- display width, display height
local posX5, posT5 = posX1, posT1                                    -- Remember initial position  
--local posX5, posT5 = sxAq/2 - boxW5/2, 2                           -- near the top, in the middle of the screen

-- Constants

-- Internationalization strings
local text_Constellations           = _("Constellations")
local text_Constellation_series0    = _("Default")
local text_Constellation_series1    = _("Western (Wiki)")
local text_Constellation_series2    = _("Francais (Wiki)")
local text_Constellation_series3    = _("Polski (Wiki)")
local text_Constellation_series4    = _("Chandra")
local text_Constellation_series7    = _("Chinese")
local text_Constellation_series8    = _("Indigenous Brazilian")
local text_Constellation_series9    = _("Sami")
local text_Constellation_series10   = _("Norse")
local text_Constellation_series11   = _("IAU")
local text_Constellation_series12   = _("Hawaiian")
local text_Asterisms                = _("Asterisms")
-- Constellation aliases
local text_Constellation_Aliases    = _("Constellation Aliases")
-- Large seasonal asterisms
local text_Large_Seasonal_Asterisms = _("Large Seasonal Asterisms")
-- Asterisms in Orion
local text_Asterisms_In_Orion       = _("Asterisms in Orion")
local text_Asterism14               = _("Sword of Orion")
local text_Asterism15               = _("Belt of Orion")
local text_Asterism16               = _("Butterfly of Orion")
local text_Asterism17               = _("Venus Mirror")
local text_Asterism18               = _("Heavenly G")
-- Asterisms in Hercules
local text_Asterisms_In_Hercules    = _("Asterisms in Hercules")
local text_Asterism19               = _("Keystone")
local text_Asterism20               = _("Hercules' Club")
local text_Asterism21               = _("Butterfly of Hercules")
-- Asterisms in Ursa Major
local text_Asterisms_In_Ursa_Major  = _("Asterisms in Ursa Major")
local text_Asterism22               = _("Horse and Rider")
local text_Asterism23               = _("Bier")
local text_Asterism24               = _("Big Dipper")
local text_Asterism25               = _("Pointers")
-- Asterisms in Aquarius
local text_Asterisms_In_Aquarius    = _("Asterisms in Aquarius")
local text_Asterism26               = _("Y of Aquarius")
local text_Asterism27               = _("Water Jar")
-- Other Asterisms
local text_Other_Asterisms          = _("Other Asterisms")

-- Personalize
local display_Constellations = Constellations_visible or false
local Show_Constellation_Labels = Constellation_Labels or true
local Constbutextoff =  Constellations_cbutextoff or {0.8, 0.9, 0.9, 0.8}     -- unactivated button text color
local Constbubordoff =  Constellations_cbubordoff or {0.2, 0.4 , 0.4, 0.9}    -- unactivated button border color
local Constsetbofill =  Constellations_csetbofill or {0.3, 0.5 , 0.5, 0.3}    -- setting box filling color
local display_Asterisms = false
local display_Orion_Asterisms = false
local display_UrsaMajor_Asterisms = false
local display_Aquarius_Asterisms = false
local shortcut = Constellations_shortcut or "/"

---------------------
-- local functions --
---------------------

local x_Constellations = function(number)
   ConstellationsCheck1.Text = ""
   ConstellationsCheck2.Text = ""
   ConstellationsCheck3.Text = ""
   ConstellationsCheck4.Text = ""
   ConstellationsCheck5.Text = ""
   ConstellationsCheck6.Text = ""
   ConstellationsCheck7.Text = ""
   ConstellationsCheck8.Text = ""
   ConstellationsCheck9.Text = ""
   ConstellationsCheck10.Text = ""
   ConstellationsCheck11.Text = ""
   ConstellationsCheck12.Text = ""
   if number == 1 then
      ConstellationsCheck1.Text = "x"
   elseif number == 2 then
      ConstellationsCheck2.Text = "x"
   elseif number == 3 then
      ConstellationsCheck3.Text = "x"
   elseif number == 4 then
      ConstellationsCheck4.Text = "x"
   elseif number == 5 then
      ConstellationsCheck5.Text = "x"
   elseif number == 6 then
      ConstellationsCheck6.Text = "x"
   elseif number == 7 then
      ConstellationsCheck7.Text = "x"
   elseif number == 8 then
      ConstellationsCheck8.Text = "x"
   elseif number == 9 then
      ConstellationsCheck9.Text = "x"
   elseif number == 10 then
      ConstellationsCheck10.Text = "x"
   elseif number == 11 then
      ConstellationsCheck11.Text = "x"
   elseif number == 12 then
      ConstellationsCheck12.Text = "x"
   end
end

local x_Asterisms = function(number)
   AsterismsCheck1.Text = ""
   AsterismsCheck2.Text = ""
   AsterismsCheck3.Text = ""
   AsterismsCheck4.Text = ""
   AsterismsCheck5.Text = ""
   AsterismsCheck6.Text = ""
   AsterismsCheck7.Text = ""
   AsterismsCheck8.Text = ""
   if number == 1 then
      AsterismsCheck1.Text = "x"
   elseif number == 2 then
      AsterismsCheck2.Text = "x"
   elseif number == 3 then
      AsterismsCheck3.Text = "x"
   elseif number == 4 then
      AsterismsCheck4.Text = "x"
   elseif number == 5 then
      AsterismsCheck5.Text = "x"
   elseif number == 6 then
      AsterismsCheck6.Text = "x"
   elseif number == 7 then
      AsterismsCheck7.Text = "x"
   elseif number == 8 then
      AsterismsCheck8.Text = "x"
   end
end

local x_Orion_Asterisms = function(number)
   OrionCheck1.Text = ""
   OrionCheck2.Text = ""
   OrionCheck3.Text = ""
   OrionCheck4.Text = ""
   OrionCheck5.Text = ""
   OrionCheck6.Text = ""
   if number == 1 then
      OrionCheck1.Text = "x"
   elseif number == 2 then
      OrionCheck2.Text = "x"
   elseif number == 3 then
      OrionCheck3.Text = "x"
   elseif number == 4 then
      OrionCheck4.Text = "x"
   elseif number == 5 then
      OrionCheck5.Text = "x"
   elseif number == 6 then
      OrionCheck6.Text = "x"
   end
end

local x_UrsaMajor_Asterisms = function(number)
   UrsaMajorCheck1.Text = ""
   UrsaMajorCheck2.Text = ""
   UrsaMajorCheck3.Text = ""
   UrsaMajorCheck4.Text = ""
   if number == 1 then
      UrsaMajorCheck1.Text = "x"
   elseif number == 2 then
      UrsaMajorCheck2.Text = "x"
   elseif number == 3 then
      UrsaMajorCheck3.Text = "x"
   elseif number == 4 then
      UrsaMajorCheck4.Text = "x"
   end
end

local x_Aquarius_Asterisms = function(number)
   AquariusCheck1.Text = ""
   AquariusCheck2.Text = ""
   if number == 1 then
      AquariusCheck1.Text = "x"
   elseif number == 2 then
      AquariusCheck2.Text = "x"
   end
end

local position_for_Asterism = function(asterism)
   -- Set frame of reference to "universal"
   local star
   local obs = celestia:getobserver()
   obs:setframe(celestia:newframe("universal"))
   local earth = celestia:find("Sol/Earth")
   local pos_earth = earth:getposition()
   if asterism == "Orion" then
      star = celestia:find("Alnilam")
   elseif asterism == "UrsaMajor" then
      star = celestia:find("Megrez")
   elseif asterism == "Aquarius" then
      star = celestia:find("55 Aqr")
   elseif asterism == "Hercules" then
      star = celestia:find("59 Her")
   else
      star = celestia:find("Sol")
   end
   local pos_towards = star:getposition()
   local vec = pos_towards - pos_earth
   local new_vec = 30000/9460730.4725808*vec:normalize()
   -- Define table and initialize table
   local parameters = { }
   parameters.duration = 0.0                                     -- Number of seconds the goto should take
   parameters.from = obs:getposition()                           -- Obtain current observer position
   parameters.to = pos_earth + new_vec                           -- Determine position to goto
   parameters.initialOrientation = obs:getorientation()          -- obtain current observer orientation
   -- Determine observer orientation from position to goto, towards the position of the Asterism
   parameters.finalOrientation = parameters.to:orientationto(pos_towards,celestia:newvector(0,1,0))
   parameters.startInterpolation = 0.0      -- Start adjusting the observer orientation from the beginning of the goto
   parameters.endInterpolation = 0.0        -- End adjusting the observer orientation at the end of the goto
   parameters.accelTime = 0.0               -- Use 0% of the time to accelarate and 0% of the time to decelarate 
   obs:goto(parameters)                     -- Perform the goto
   obs:follow(earth)                        -- Finally follow Earth
end

local x_Close_Boxes = function(x)
   if x == 1 then
      if lua_edu_tools then
         ConstellationsSwitch.Bordercolor=Constbubordoff
         ConstellationsSwitch.Fillcolor = nil
      end
      ConstellationsFrame.Visible = false
      display_Constellations = false
   end
   x_Constellations(0)
   x_Asterisms(0)
   x_Orion_Asterisms(0)
   x_UrsaMajor_Asterisms(0)
   x_Aquarius_Asterisms(0)
   AsterismsFrame.Visible = false
   OrionFrame.Visible = false
   UrsaMajorFrame.Visible = false
   AquariusFrame.Visible = false
   display_Asterisms = false
   display_Orion_Asterisms = false
   display_UrsaMajor_Asterisms = false
   display_Aquarius_Asterisms = false
end

local toggleConstellationsDisplay = function()
   if not (display_Asterisms or display_Orion_Asterisms or display_UrsaMajor_Asterisms or display_Aquarius_Asterisms) then
      display_Constellations = not display_Constellations
   end
   if display_Constellations then
      ConstellationsFrame.Visible = true
      ConstellationsFrame:orderfront() 
      position_for_Asterism("Sol")
   else
      ConstellationsFrame.Visible = false
   end
   x_Close_Boxes(0)
end

----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
ConstellationsBox = CXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
    :attach(screenBox, sxC, syC, 0, 0)

--
-- Box to show the Constellations series
--

ConstellationsFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text(text_Constellations)
    :movetext(-5,4)
    :fillcolor(Constsetbofill)
    :bordercolor(Constbubordoff)
    :movable(true)
    :clickable(false)
    :visible(display_Constellations)
    :attach(screenBox, posX1, syC-posT1-boxH1, sxC-boxW1-posX1, posT1)

-- Close button
ConstellationsFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text("x")
    :textpos("center")
    :movetext(0, 10)
    :bordercolor(Constbubordoff)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(ConstellationsFrame, boxW1-10, boxH1-10, 0, 0)
   
ConstellationsFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(Constbutextoff)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb+30,this.tb-lspace*2+2)
   textlayout:println("")
   textlayout:println(text_Constellation_series0)
   textlayout:println(text_Constellation_series1)
   textlayout:println(text_Constellation_series2)
   textlayout:println(text_Constellation_series3)
   textlayout:println(text_Constellation_series4)
   textlayout:println(text_Constellation_series7)
   textlayout:println(text_Constellation_series8)
   textlayout:println(text_Constellation_series9)
   textlayout:println(text_Constellation_series10)
   textlayout:println(text_Constellation_series11)
   textlayout:println(text_Constellation_series12)
   textlayout:println(text_Asterisms)
   -- Check changed screen dimensions and reposition the box if necessary
   oldsxC, oldsyC = sxC, syC
   sxC, syC = celestia:getscreendimension()
   if sxC ~= oldsxC or syC ~= oldsyC or posT1 ~= posT1a or posX1 ~= posX1a then
      -- 2 lines to force the box to stay in the celestia window
      if posT1 >= syC - boxH1 - 2 then posT1 = syC - boxH1 - 2 end
      if posX1 >= sxC - boxW1 - 2 then posX1 = sxC - boxW1 - 2 end
      ConstellationsFrame:attach(screenBox, posX1, syC-posT1-boxH1, sxC-boxW1-posX1, posT1)
   end
   posX1 = this.la
   posT1 = this.ta
   posX1a, posT1a = posX1, posT1
end

-- Close button
ConstellationsFrame4.Customdraw = function(this)
    ConstellationsFrame4:attach(ConstellationsFrame, boxW1-10, boxH1-10, 0, 0)
end

ConstellationsCheck1 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series + 0) + 4, boxW1-16, lspace*2 + 4)

ConstellationsCheck1.Customdraw = function(this)
    ConstellationsCheck1:attach(ConstellationsFrame, 6, lspace*(number_const_series + 0) + 4, boxW1-16, lspace*2 + 4)
end

ConstellationsCheck1.Action = (function()
        return
            function()
                x_Constellations(1)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Only show the default Constellations as distributed with Celestia.
                celestia:showconstellations{"Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpius", "Ophiuchus",
                                            "Serpens Cauda", "Serpens Caput", "Sagittarius", "Capricornus", "Aquarius", "Pisces", "Ara",
                                            "Andromeda", "Aquila", "Boötes", "Puppis", "Carina", "Vela", "Pyxis", "Sculptor", "Crater",
                                            "Cassiopeia", "Centaurus", "Cepheus", "Delphinus", "Draco", "Triangulum", "Columba", "Monoceros",
                                            "Orion", "Eridanus", "Phoenix", "Camelopardalis", "Dorado", "Caelum", "Ursa Major", "Canis Major",
                                            "Lepus", "Lacerta", "Hercules", "Coma Berenices", "Indus", "Pavo", "Tucana", "Canes Venatici",
                                            "Chamaeleon", "Ursa Minor", "Canis Minor", "Leo Minor", "Hydrus", "Grus", "Lyra", "Antlia", "Lynx",
                                            "Microscopium", "Reticulum", "Corona Borealis", "Corona Australis", "Octans", "Fornax", "Apus",
                                            "Circinus", "Pegasus", "Perseus", "Sagitta", "Corvus", "Scutum", "Pictor", "Sextans", "Hydra",
                                            "Horologium", "Mensa", "Telescopium", "Equuleus", "Musca", "Volans", "Auriga", "Vulpecula", "Cetus",
                                            "Norma", "Lupus", "Triangulum Australe", "Crux", "Cygnus", "Piscis Austrinus"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck2 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 1) + 4, boxW1-16, lspace*3 + 4)

ConstellationsCheck2.Customdraw = function(this)
    ConstellationsCheck2:attach(ConstellationsFrame, 6, lspace*(number_const_series - 1) + 4, boxW1-16, lspace*3 + 4)
end

ConstellationsCheck2.Action = (function()
        return
            function()
                x_Constellations(2)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Western (Wiki) Constellations, series #1
                celestia:showconstellations{"Aries1", "Taurus1", "Gemini1", "Cancer1", "Leo1", "Virgo1", "Libra1", "Scorpius1", "Ophiuchus1",
                                            "Sagittarius1", "Capricornus1", "Aquarius1", "Pisces1", "Ara1", "Andromeda1", "Aquila1", "Boötes1",
                                            "Pyxis1", "Sculptor1", "Crater1", "Cassiopeia1", "Centaurus1", "Cepheus1", "Delphinus1", "Draco1",
                                            "Triangulum1", "Columba1", "Monoceros1", "Orion1", "Eridanus1", "Phoenix1", "Camelopardalis1",
                                            "Dorado1", "Caelum1", "Ursa Major1", "Canis Major1", "Lepus1", "Lacerta1", "Hercules1",
                                            "Coma Berenices1", "Indus1", "Pavo1", "Tucana1", "Canes Venatici1", "Chamaeleon1", "Ursa Minor1",
                                            "Canis Minor1", "Leo Minor1", "Hydrus1", "Grus1", "Lyra1", "Antlia1", "Lynx1", "Microscopium1",
                                            "Reticulum1", "Corona Borealis1", "Corona Australis1", "Octans1", "Fornax1", "Apus1", "Circinus1",
                                            "Pegasus1", "Perseus1", "Sagitta1", "Corvus1", "Scutum1", "Pictor1", "Sextans1", "Hydra1",
                                            "Telescopium1", "Equuleus1", "Musca1", "Volans1", "Auriga1", "Vulpecula1", "Cetus1", "Norma1",
                                            "Lupus1", "Triangulum Australe1", "Crux1", "Cygnus1", "Piscis Austrinus1"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

ConstellationsCheck3 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 2) + 4, boxW1-16, lspace*4 + 4)

ConstellationsCheck3.Customdraw = function(this)
    ConstellationsCheck3:attach(ConstellationsFrame, 6, lspace*(number_const_series - 2) + 4, boxW1-16, lspace*4 + 4)
end

ConstellationsCheck3.Action = (function()
        return
            function()
                x_Constellations(3)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Francais (Wiki) Constellations, series #2
                celestia:showconstellations{"Aries2", "Taurus2", "Gemini2", "Cancer2", "Leo2", "Virgo2", "Libra2", "Scorpius2", "Ophiuchus2",
                                            "Serpens Cauda2", "Serpens Caput2", "Sagittarius2", "Capricornus2", "Aquarius2", "Pisces2", "Ara2",
                                            "Andromeda2", "Aquila2", "Boötes2", "Argo Navis2", "Cassiopeia2", "Centaurus2", "Cepheus2",
                                            "Delphinus2", "Draco2", "Columba2", "Orion2", "Eridanus2", "Phoenix2", "Dorado2", "Ursa Major2",
                                            "Canis Major2", "Lepus2", "Lacerta2", "Hercules2", "Coma Berenices2", "Pavo2", "Tucana2",
                                            "Canes Venatici2", "Ursa Minor2", "Canis Minor2", "Leo Minor2", "Hydrus2", "Grus2", "Lyra2", "Lynx2",
                                            "Reticulum2", "Corona Borealis2", "Corona Australis2", "Pegasus2", "Perseus2", "Sagitta2", "Corvus2",
                                            "Pictor2", "Hydra2", "Equuleus2", "Auriga2", "Vulpecula2", "Cetus2", "Lupus2", "Triangulum Australe2",
                                            "Crux2", "Cygnus2", "Piscis Austrinus2"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck4 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 3) + 4, boxW1-16, lspace*5 + 4)

ConstellationsCheck4.Customdraw = function(this)
    ConstellationsCheck4:attach(ConstellationsFrame, 6, lspace*(number_const_series - 3) + 4, boxW1-16, lspace*5 + 4)
end

ConstellationsCheck4.Action = (function()
        return
            function()
                x_Constellations(4)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Polski (Wiki) Constellations, series #3
                celestia:showconstellations{"Aries3", "Taurus3", "Gemini3", "Cancer3", "Leo3", "Virgo3", "Libra3", "Scorpius3", "Ophiuchus3",
                                            "Serpens Cauda3", "Serpens Caput3", "Sagittarius3", "Capricornus3", "Aquarius3", "Pisces3", "Ara3",
                                            "Andromeda3", "Aquila3", "Boötes3", "Puppis3", "Carina3", "Vela3", "Pyxis3", "Sculptor3", "Crater3",
                                            "Cassiopeia3", "Centaurus3", "Cepheus3", "Delphinus3", "Draco3", "Triangulum3", "Columba3",
                                            "Monoceros3", "Orion3", "Eridanus3", "Phoenix3", "Camelopardalis3", "Dorado3", "Caelum3",
                                            "Ursa Major3", "Canis Major3", "Lepus3", "Lacerta3", "Hercules3", "Coma Berenices3", "Indus3",
                                            "Pavo3", "Tucana3", "Canes Venatici3", "Chamaeleon3", "Ursa Minor3", "Canis Minor3", "Leo Minor3",
                                            "Hydrus3", "Grus3", "Lyra3", "Antlia3", "Lynx3", "Microscopium3", "Reticulum3", "Corona Borealis3",
                                            "Corona Australis3", "Octans3", "Fornax3", "Apus3", "Circinus3", "Pegasus3", "Perseus3", "Sagitta3",
                                            "Corvus3", "Scutum3", "Pictor3", "Sextans3", "Hydra3", "Horologium3", "Mensa3", "Telescopium3",
                                            "Equuleus3", "Musca3", "Volans3", "Auriga3", "Vulpecula3", "Cetus3", "Norma3", "Lupus3",
                                            "Triangulum Australe3", "Crux3", "Cygnus3", "Piscis Austrinus3"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck5 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 4) + 4, boxW1-16, lspace*6 + 4)

ConstellationsCheck5.Customdraw = function(this)
    ConstellationsCheck5:attach(ConstellationsFrame, 6, lspace*(number_const_series - 4) + 4, boxW1-16, lspace*6 + 4)
end

ConstellationsCheck5.Action = (function()
        return
            function()
                x_Constellations(5)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Chandra Constellations, series #4
                celestia:showconstellations{"Taurus4", "Gemini4", "Cancer4", "Virgo4", "Ophiuchus4", "Serpens Cauda4", "Serpens Caput4",
                                            "Sagittarius4", "Capricornus4", "Aquarius4", "Pisces4", "Ara4", "Andromeda4", "Aquila4", "Boötes4",
                                            "Carina4", "Vela4", "Sculptor4", "Crater4", "Cassiopeia4", "Centaurus4", "Cepheus4", "Draco4",
                                            "Monoceros4", "Orion4", "Dorado4", "Ursa Major4", "Canis Major4", "Hercules4", "Tucana4", "Canes Venatici4",
                                            "Hydrus4", "Corona Borealis4", "Fornax4", "Circinus4", "Pegasus4", "Perseus4", "Sagitta4",
                                            "Corvus4", "Scutum4", "Pictor4", "Hydra4", "Mensa4", "Cetus4", "Cygnus4", "Piscis Austrinus4"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck6 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 5) + 4, boxW1-16, lspace*7 + 4)

ConstellationsCheck6.Customdraw = function(this)
    ConstellationsCheck6:attach(ConstellationsFrame, 6, lspace*(number_const_series - 5) + 4, boxW1-16, lspace*7 + 4)
end

ConstellationsCheck6.Action = (function()
        return
            function()
                x_Constellations(6)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Chinese Constellations, series #7
                -- Azure Dragon
                celestia:showconstellations{"Horn 7", "Flat Road 7", "Celestial Farmland (AD) 7", "Recommending Virtuous Men 7",
                                            "Tripod of the ZHOU 7", "Celestial Gate (AD) 7", "Justice 7", "Arsenal 7",
                                            "Pillars (AD) 7", "Railings 7", "Southern Gate 7"}
                celestia:showconstellations{"Neck 7", "Great Horn 7", "Left Conductor 7", "Right Conductor 7", "Trials 7",
                                            "Gate of Yang 7", "Executions 7"}
                celestia:showconstellations{"Root 7", "Celestial Milk 7", "Twinkling Indicator 7", "Celestial Lance 7",
                                            "Mattress of the Emperor 7", "Boats and Lake 7", "Battle Chariots 7",
                                            "Imperial Guards 7", "Chariots and Cavalry 7", "Celestial Spokes 7",
                                            "Chariots and Cavalry General 7"}
                celestia:showconstellations{"Room 7", "Lock 7", "Door Bolt 7", "Punishment (AD) 7", "Eastern Door 7", 
                                            "Western Door 7", "Sun 7", "Retinue 7"}
                celestia:showconstellations{"Heart 7", "Group of Soldiers"}
                celestia:showconstellations{"Tail 7", "Changing Room 7", "Tortoise 7", "Celestial River (AD) 7", "FUYUE 7", "Fish 7"}
                celestia:showconstellations{"Winnowing Basket 7", "Chaff 7", "Pestle (AD) 7"}
                -- Vermilion Bird
                celestia:showconstellations{"Well 7", "Battle Axe 7", "South River 7", "North River 7", "Celestial Wine Cup 7",
                                            "Five Feudal Kings 7", "Accumulated Water 7", "Pile of Firewood 7", 
                                            "Irrigation Official 7", "Water Level 7", "Four Channels 7", "Market for Soldiers 7",
                                            "Wild Cockerel 7", "Grandfather 7", "Son 7", "Grandson 7", "Palace Gate 7",
                                            "Celestial Wolf 7",	"Bow and Arrow 7", "Old Man 7"}
                celestia:showconstellations{"Ghost 7", "Cumulative Corpses 7", "Beacon Fire 7", "Celestial Dog 7", "Outer Kitchen 7",
                                            "Celestial Earth God's Temple 7", "Judge to Estimate the Age of Animals 7"}
                celestia:showconstellations{"Willow 7", "Banner of a Wine Shop 7"}
                celestia:showconstellations{"Star 7", "Celestial Premier 7", "XUANYUAN 7", "Maids in Waiting (VB) 7", "High Judge 7"}
                -- ==>(NOT PRESENT)
                -- celestia:showconstellations{"Celestial Cereals 7"}
                celestia:showconstellations{"Extended Net 7"}
                -- ==>(NOT PRESENT)
                -- celestia:showconstellations{"Celestial Temple 7"}
                celestia:showconstellations{"Wings 7"}
                -- ==>(NOT PRESENT)
                -- celestia:showconstellations{"Dongou 7"}
                celestia:showconstellations{"Chariot 7", "Changsha 7", "Left Linchpin 7", "Right Linchpin 7", "Green Hill 7"}
                -- ==>(NOT PRESENT)
                -- celestia:showconstellations{"Military Gate 7", "Master of Constructions (VB) 7", "House for Musical Instruments 7"}
                --
                -- Black Tortoise
                celestia:showconstellations{"Dipper 7", "Establishment 7", "Market Officer 7", "River Turtle 7", "Celestial Cock 7",
                                            "Celestial Keyhole 7", "Dog Territory 7", "Celestial Spring 7", "Dog 7", "Peasant 7"}
                celestia:showconstellations{"Ox 7", "Celestial Farmland (BT) 7", "Nine Water Wells 7", "Drum at the River 7",
                                            "Weaving Girl 7", "Left Flag 7", "Right Flag 7",  "Celestial Drumstick 7",
                                            "Network of Dykes 7", "Clepsydra Terrace 7", "Imperial Passageway 7"}
                celestia:showconstellations{"Girl 7", "Twelve States 7", "Pearls on Ladies' Wear 7", "Rotten Gourd 7",
                                            "Good Gourd 7", "Celestial Ford 7", "Xi Zhong 7", "Basket for Mulberry Leaves 7"}
                celestia:showconstellations{"Emptiness 7", "Deified Judge of Life 7", "Deified Judge of Rank 7",
                                            "Deified Judge of Disaster and Good Fortune 7", "Deified Judge of Right and Wrong 7", "Crying 7",
                                            "Weeping 7", "Celestial Ramparts 7", "Decayed Mortar 7", "Jade Ornament on Ladies' Wear 7"}
                celestia:showconstellations{"Rooftop 7", "Tomb 7", "Humans 7", "Pestle (BT) 7", "Mortar 7", "Big Yard for Chariots 7",
                                            "Celestial Hook 7", "ZAOFU 7", "Roofing 7", "Temple 7", "Celestial Money 7"}
                celestia:showconstellations{"Encampment 7", "Resting Palace 7", "Thunder and Lightning 7", "Line of Ramparts 7",
                                            "Palace Guard 7", "Axe 7", "North Gate of the Military Camp 7", "Net for Catching Birds 7",
                                            "Materials for Making Tents 7", "Official for Materials Supply 7", "Flying Serpent 7"}
                celestia:showconstellations{"Wall 7", "Thunderbolt 7", "Cloud and Rain 7", "Celestial Stable 7", "Sickle (BT) 7",
                                            "Official for Earthworks and Buildings 7"}
                -- White Tiger
                celestia:showconstellations{"Legs 7", "Outer Fence 7", "Celestial Pigsty 7", "Master of Constructions (WT) 7",
                                            "Southern Military Gate 7", "Flying Corridor 7", "Auxiliary Road 7", "WANGLIANG 7", "Whip 7"}
                celestia:showconstellations{"Bond 7", "Official in Charge of the Forest 7", "Right hand Watch 7", "Square Celestial Granary 7",
                                            "Heaven's Temporary Granary 7", "Heaven's Great General 7"}
                celestia:showconstellations{"Stomach 7", "Celestial Foodstuff 7", "Circular Celestial Granary 7", "Mausoleum 7",
                                            "Celestial Boat 7", "Heap of Corpses 7", "Stored Water 7"}
                celestia:showconstellations{"Hairy Head 7", "Celestial River (WT) 7", "Moon 7", "Yin Force 7", "Hay 7", "Celestial Meadows 7",
                                            "Rolled Tongue 7", "Celestial Slander 7", "Whetstone 7"}
                celestia:showconstellations{"Net 7", "Whisper 7", "Celestial Street 7", "Celestial Tally 7", "Feudal Kings 7",
                                            "Celestial High Terrace 7", "Interpreters of Nine Dialects 7", "Five Chariots 7",
                                            "Pillars (WT) 7", "Celestial Pier 7", "Pool of Harmony 7", "Celestial Gate (WT) 7",
                                            "Banner of Three Stars 7", "Imperial Military Flag 7", "Celestial Orchard 7"}
                celestia:showconstellations{"Turtle Beak 7", "Deity in Charge of Monsters 7", "Seat Flags 7"}
                celestia:showconstellations{"Three Stars 7", "Punishment (WT) 7", "Jade Well 7", "Screen 7", "Military Well 7",
                                            "Toilet 7", "Excrement 7"}
                -- Purple Forbidden Enclosure
                celestia:showconstellations{"Left Wall (PF) 7", "Right Wall (PF) 7",
                                            "Northern Pole 7", "Four Advisors 7", "Celestial Great One 7", "First Great One 7",
                                            "Hidden Virtue 7", "Royal Secretary 7", "Female Protocol 7", "Official of Royal Archives 7",
                                            "Maids in Waiting (PF) 7", "Celestial Pillar 7", "Chief Judge 7", "Curved Array 7", "Six Jia 7",
                                            "Great Emperor of Heaven 7", "Interior Seats of the Five Emperors 7", "Canopy of the Emperor 7",
                                            "Canopy Support 7", "Guest House 7", "Inner Steps 7", "Celestial Kitchen 7",
                                            "Eight Kinds of Crops 7", "Celestial Flail 7", "Inner Kitchen 7", "Administrative Center 7",
                                            "Three Top Instructors 7", "Three Excellencies (PF) 7", "Celestial Bed 7", "Royals 7",
                                            "Celestial Prison 7", "Guard of the Sun 7", "Eunuch 7", "Prime Minister 7", "Sombre Lance 7",
                                            "Judge for Nobility 7", "Northern Dipper 7", "Assistant 7", "Celestial Spear 7"}
                -- Supreme Palace Enclosure
                celestia:showconstellations{"Left Wall (SP) 7", "Right Wall (SP) 7",
                                            "Usher to the Court 7", "Three Excellencies (SP) 7", "Nine Senior Officers 7",
                                            "Five Lords 7", "Inner Screen 7", "Seats of the Five Emperors 7", "Officer of Honour 7",
                                            "Crown Prince 7", "Retinue (SP) 7", "Captain of the Bodyguards 7", "Emperor's Bodyguard 7",
                                            "Imperial Guards (SP) 7", "Officers of the Imperial Guard 7", "The Hall of Glory 7",
                                            "Astronomical Observatory 7", "Junior Officers 7", "Long Wall 7", "Three Steps 7"}
                -- Heavenly Market Enclosure
                celestia:showconstellations{"Left Wall (HM) 7", "Right Wall (HM) 7",
                                            "Municipal Office 7", "Commodity Market 7", "Official for Royal Clan 7", "Official of Religious Ceremony 7",
                                            "Patriarchal Clan 7", "Textile Ruler 7", "Butcher's Shop 7", "Astrologer 7", "Emperor's Seat 7",
                                            "Eunuch Official 7", "Jewel Market 7", "Dipper for Liquids 7", "Dipper for Solids 7", "Coiled Thong 7",
                                            "Seven Excellencies 7", "Celestial Discipline 7", "Woman's Bed 7"}
                -- The Southern Asterisms
                celestia:showconstellations{"Sea and Mountain 7", "Cross 7", "Horse's Tail 7", "Horse's Abdomen 7", "Bee 7", "Triangle 7",
                                            "Exotic Bird 7", "Peacock 7", "Persia 7", "Snake's Tail 7", "Snake's Abdomen 7", "Snake's Head 7",
                                            "Bird's Beak 7", "Crane 7", "Firebird 7", "Crooked Running Water 7", "White Patched Nearby 7",
                                            "White Patches Attached 7", "Goldfish 7", "Sea Rock 7", "Flying Fish 7", "Southern Boat 7",
                                            "Little Dipper 7"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck7 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 6) + 4, boxW1-16, lspace*8 + 4)

ConstellationsCheck7.Customdraw = function(this)
    ConstellationsCheck7:attach(ConstellationsFrame, 6, lspace*(number_const_series - 6) + 4, boxW1-16, lspace*8 + 4)
end

ConstellationsCheck7.Action = (function()
        return
            function()
                x_Constellations(7)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Indigenous Brazilian Constellations, series #8
                celestia:showconstellations{"Emu 8", "Old Man 8", "Tapir of the North 8", "Deer 8" }
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck8 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 7) + 4, boxW1-16, lspace*9 + 4)

ConstellationsCheck8.Customdraw = function(this)
    ConstellationsCheck8:attach(ConstellationsFrame, 6, lspace*(number_const_series - 7) + 4, boxW1-16, lspace*9 + 4)
end

ConstellationsCheck8.Action = (function()
        return
            function()
                x_Constellations(8)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Sami Constellations, series #9
                celestia:showconstellations{"Sarvvis (Reindeer Bull) 9", "Boahji (Hunter with Bow) 9", "Favnnagagi (Favdna's Bow) 9",
                                            "Favdna (Hunter) 9", "Favnna gilvoolmmali (Competitor of Favdna) 9",
                                            "Gallabartnit (Galla's Sons / Famous Hunters) 9", "Boar Ahkku (Old Woman with Two Dogs) 9",
                                            "Boares Galla (Old Man) 9", "Chouggit (Two Skiers) 9", "Bismarra (Hunting Equipment) 9",
                                            "(Knife / Spear / Cauldron) 9", "(The Runner) 9"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck9 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 8) + 4, boxW1-16, lspace*10 + 4)

ConstellationsCheck9.Customdraw = function(this)
    ConstellationsCheck9:attach(ConstellationsFrame, 6, lspace*(number_const_series - 8) + 4, boxW1-16, lspace*10 + 4)
end

ConstellationsCheck9.Action = (function()
        return
            function()
                x_Constellations(9)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Norse Constellations, series #10
                celestia:showconstellations{"Aurvandil's Toe 10", "Wolf's Mouth 10", "The Fishermen 10", 
                                            "Woman's Cart 10", "Man's Cart 10", "The Asar Battlefield 10" }
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck10 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 9) + 4, boxW1-16, lspace*11 + 4)

ConstellationsCheck10.Customdraw = function(this)
    ConstellationsCheck10:attach(ConstellationsFrame, 6, lspace*(number_const_series - 9) + 4, boxW1-16, lspace*11 + 4)
end

ConstellationsCheck10.Action = (function()
        return
            function()
                x_Constellations(10)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- International Astronomical Union Constellations, series #11
                celestia:showconstellations{"Andromeda11", "Antlia11", "Apus11", "Aquarius11", "Aquila11", "Ara11", "Aries11",
                                            "Auriga11", "Boötes11", "Caelum11", "Camelopardalis11", "Capricornus11", "Carina11",
                                            "Cassiopeia11", "Centaurus11", "Cepheus11", "Cetus11", "Chamaeleon11", "Circinus11",
                                            "Canis Major11", "Canis Minor11", "Cancer11", "Columba11", "Coma Berenices11",
                                            "Corona Australis11", "Corona Borealis11", "Crater11", "Crux11", "Corvus11", "Canes Venatici11",
                                            "Cygnus11", "Delphinus11", "Dorado11", "Draco11", "Equuleus11", "Eridanus11", "Fornax11",
                                            "Gemini11", "Grus11", "Hercules11", "Horologium11", "Hydra11", "Hydrus11", "Indus11", "Lacerta11",
                                            "Leo11", "Lepus11", "Libra11", "Leo Minor11", "Lupus11", "Lynx11", "Lyra11", "Mensa11",
                                            "Microscopium11", "Monoceros11", "Musca11", "Norma11", "Octans11", "Ophiuchus11", "Orion11",
                                            "Pavo11", "Pegasus11", "Perseus11", "Phoenix11", "Pictor11", "Piscis Austrinus11", "Pisces11",
                                            "Puppis11", "Pyxis11", "Reticulum11", "Sculptor11", "Scorpius11", "Scutum11", "Serpens Cauda11",
                                            "Serpens Caput11", "Sextans11", "Sagitta11", "Sagittarius11", "Taurus11", "Telescopium11",
                                            "Triangulum Australe11", "Triangulum11", "Tucana11", "Ursa Major11", "Ursa Minor11", "Vela11",
                                            "Virgo11", "Volans11", "Vulpecula11" }
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck11 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 10) + 4, boxW1-16, lspace*12 + 4)

ConstellationsCheck11.Customdraw = function(this)
    ConstellationsCheck11:attach(ConstellationsFrame, 6, lspace*(number_const_series - 10) + 4, boxW1-16, lspace*12 + 4)
end

ConstellationsCheck11.Action = (function()
        return
            function()
                x_Constellations(11)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Hawaiian Starlines, series #12
                celestia:showconstellations{"Ke Ka o Makali'i (Bailer of Makali'i) 12", "Makali'i (Pleiades) 12", "Ke Hei-Hei o Na Keiki (The Cat's Cradle) 12",
                                            "Me'e (Voice of Joy) 12", "Na Hiku (The Seven) 12", "Ka Makau Nui o Maui (Big Fishhook of Maui) 12",
                                            "Huinakolu (Navigator's Triangle) 12", "Ka Lupe o Kawelo (Kite of Kawelo) 12", "Iwakeli'i (Chief Frigate Bird) 12",
                                            "Hanaiakamala (Cared for by the Moon) 12", "Nai'a (Dolphin) 12", "Kapuahi (Sacred fire) 12", "Hokule'a (Star of Gladness) 12",
                                            "Hikianalia (Star) 12", "Hokupa'a (Fixed star) 12", "Holopuni (To circle) 12", "Na Kuhikuhi (The Pointers) 12",
                                            "Kukalani'ehu (The Ram) 12", "Kukaniloko (Fomalhaut) 12", "Pi'ikea (Dipha) 12", "Kaikilani (Ankaa) 12",
                                            "Kalanikauleleiaiwi (Achernar) 12", "Maweke (Errai) 12"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();
        
ConstellationsCheck12 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ConstellationsFrame, 6, lspace*(number_const_series - 11) + 4, boxW1-16, lspace*13 + 4)

ConstellationsCheck12.Customdraw = function(this)
    ConstellationsCheck12:attach(ConstellationsFrame, 6, lspace*(number_const_series - 11) + 4, boxW1-16, lspace*13 + 4)
end

ConstellationsCheck12.Action = (function()
        return
            function()
                x_Constellations(0)
                ConstellationsFrame.Visible = false
                display_Constellations = false
                x_Asterisms(0)
                AsterismsFrame.Visible = true
                display_Asterisms = true
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
            end
        end) ();

--
-- Box to show the Asterisms
--

AsterismsFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text(text_Asterisms)
    :movetext(-5,4)
    :fillcolor(Constsetbofill)
    :bordercolor(Constbubordoff)
    :movable(true)
    :clickable(false)
    :visible(display_Asterisms)
    :attach(screenBox, posX1, syA-posT1-boxH2, sxA-boxW2-posX1, posT1)

-- Close button
AsterismsFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text("x")
    :textpos("center")
    :movetext(0, 10)
    :bordercolor(Constbubordoff)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(AsterismsFrame, boxW2-10, boxH2-10, 0, 0)
   
AsterismsFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(Constbutextoff)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb+30,this.tb-lspace*2+2)
   textlayout:println("")
   textlayout:println(text_Constellation_Aliases)
   textlayout:println(text_Large_Seasonal_Asterisms)
   textlayout:println(text_Asterisms_In_Orion)
   textlayout:println(text_Asterisms_In_Hercules)
   textlayout:println(text_Asterisms_In_Ursa_Major)
   textlayout:println(text_Asterisms_In_Aquarius)
   textlayout:println(text_Other_Asterisms)
   textlayout:println(text_Constellations)
   -- Check changed screen dimensions and reposition the box if necessary
   oldsxA, oldsyA = sxA, syA
   sxA, syA = celestia:getscreendimension()
   if sxA ~= oldsxA or syA ~= oldsyA or posT1 ~= posT2 or posX1 ~= posX2 then
      -- 2 lines to force the box to stay in the celestia window
      if posT1 >= syA - boxH2 - 2 then posT1 = syA - boxH2 - 2 end
      if posX1 >= sxA - boxW2 - 2 then posX1 = sxA - boxW2 - 2 end
      AsterismsFrame:attach(screenBox, posX1, syA-posT1-boxH2, sxA-boxW2-posX1, posT1)
   end
   -- recording the actual position
   posX1 = this.la
   posT1 = this.ta
   posX2, posT2 = posX1, posT1
end

-- Close button
AsterismsFrame4.Customdraw = function(this)
    AsterismsFrame4:attach(AsterismsFrame, boxW2-10, boxH2-10, 0, 0)
end

AsterismsCheck1 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 0) + 4, boxW2-16, lspace*2 + 4)

AsterismsCheck1.Customdraw = function(this)
    AsterismsCheck1:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 0) + 4, boxW2-16, lspace*2 + 4)
end

AsterismsCheck1.Action = (function()
        return
            function()
                x_Asterisms(1)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Constellation aliases
                celestia:showconstellations{"Little Dipper", "W of Cassiopeia", "Fish Hook", "Northern Cross", "Kite", "Three Patriarchs", "Sail", "Southern Cross"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
                position_for_Asterism("Sol")
            end
        end) ();
        
AsterismsCheck2 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 1) + 4, boxW2-16, lspace*3 + 4)

AsterismsCheck2.Customdraw = function(this)
    AsterismsCheck2:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 1) + 4, boxW2-16, lspace*3 + 4)
end

AsterismsCheck2.Action = (function()
        return
            function()
                x_Asterisms(2)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Large seasonal asterisms
                celestia:showconstellations{"Diamond of Virgo", "Square of Pegasus", "Summer Triangle", "Winter Hexagon", "Winter Triangle"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
                position_for_Asterism("Sol")
            end
        end) ();
        
AsterismsCheck3 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 2) + 4, boxW2-16, lspace*4 + 4)

AsterismsCheck3.Customdraw = function(this)
    AsterismsCheck3:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 2) + 4, boxW2-16, lspace*4 + 4)
end

AsterismsCheck3.Action = (function()
        return
            function()
                x_Asterisms(0)
                AsterismsFrame.Visible = false
                display_Asterisms = false
                x_Orion_Asterisms(0)
                OrionFrame.Visible = true
                display_Orion_Asterisms = true
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                position_for_Asterism("Orion")
            end
        end) ();
        
AsterismsCheck4 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 3) + 4, boxW2-16, lspace*5 + 4)

AsterismsCheck4.Customdraw = function(this)
    AsterismsCheck4:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 3) + 4, boxW2-16, lspace*5 + 4)
end

AsterismsCheck4.Action = (function()
        return
            function()
                x_Asterisms(4)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Asterisms in Hercules
                celestia:showconstellations{"Keystone", "Hercules' Club", "Butterfly of Hercules"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
                position_for_Asterism("Hercules")
            end
        end) ();
        
AsterismsCheck5 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 4) + 4, boxW2-16, lspace*6 + 4)

AsterismsCheck5.Customdraw = function(this)
    AsterismsCheck5:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 4) + 4, boxW2-16, lspace*6 + 4)
end

AsterismsCheck5.Action = (function()
        return
            function()
                x_Asterisms(0)
                AsterismsFrame.Visible = false
                display_Asterisms = false
                x_UrsaMajor_Asterisms(0)
                UrsaMajorFrame.Visible = true
                display_UrsaMajor_Asterisms = true
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                position_for_Asterism("UrsaMajor")
            end
        end) ();
        
AsterismsCheck6 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 5) + 4, boxW2-16, lspace*7 + 4)

AsterismsCheck6.Customdraw = function(this)
    AsterismsCheck6:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 5) + 4, boxW2-16, lspace*7 + 4)
end

AsterismsCheck6.Action = (function()
        return
            function()
                x_Asterisms(0)
                AsterismsFrame.Visible = false
                display_Asterisms = false
                x_Aquarius_Asterisms(0)
                AquariusFrame.Visible = true
                display_Aquarius_Asterisms = true
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                position_for_Asterism("Aquarius")
            end
        end) ();
        
AsterismsCheck7 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 6) + 4, boxW2-16, lspace*8 + 4)

AsterismsCheck7.Customdraw = function(this)
    AsterismsCheck7:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 6) + 4, boxW2-16, lspace*8 + 4)
end

AsterismsCheck7.Action = (function()
        return
            function()
                x_Asterisms(7)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- Other Asterisms
                celestia:showconstellations{"Sickle", "Teapot", "Circlet", "Asses and the Manger", "Taurus Poniatovii", "Hyades", "Head of Cetus", "Kids",
                                            "Seven Sisters", "Northern Fly", "Trapezoid", "Lozenge", "False Cross", "Fredrick's Glory", "Guardians of the Pole",
                                            "Job's Coffin", "Head of Hydra", "Segment of Perseus", "Y of Virgo", "Coat Hanger", "Family of Aquila", "Herman's Cross",
                                            "Diamond Cross", "Southern Pointers", "Egyptian X"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
                position_for_Asterism("Sol")
            end
        end) ();
        
AsterismsCheck8 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AsterismsFrame, 6, lspace*(number_asterism_series - 7) + 4, boxW2-16, lspace*9 + 4)

AsterismsCheck8.Customdraw = function(this)
    AsterismsCheck8:attach(AsterismsFrame, 6, lspace*(number_asterism_series - 7) + 4, boxW2-16, lspace*9 + 4)
end

AsterismsCheck8.Action = (function()
        return
            function()
                x_Constellations(0)
                ConstellationsFrame.Visible = true
                display_Constellations = true
                x_Asterisms(0)
                AsterismsFrame.Visible = false
                display_Asterisms = false
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                position_for_Asterism("Sol")
            end
        end) ();

--
-- Box to show the Orion Asterisms
--

OrionFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text(text_Asterisms_In_Orion)
    :movetext(-5,4)
    :fillcolor(Constsetbofill)
    :bordercolor(Constbubordoff)
    :movable(true)
    :clickable(false)
    :visible(display_Orion_Asterisms)
    :attach(screenBox, posX1, syO-posT1-boxH3, sxO-boxW3-posX1, posT1)

-- Close button
OrionFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text("x")
    :textpos("center")
    :movetext(0, 10)
    :bordercolor(Constbubordoff)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(OrionFrame, boxW3-10, boxH3-10, 0, 0)
   
OrionFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(Constbutextoff)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb+30,this.tb-lspace*2+2)
   textlayout:println("")
   textlayout:println(text_Asterism14)
   textlayout:println(text_Asterism15)
   textlayout:println(text_Asterism16)
   textlayout:println(text_Asterism17)
   textlayout:println(text_Asterism18)
   textlayout:println(text_Asterisms)
   -- Check changed screen dimensions and reposition the box if necessary
   oldsxO, oldsyO = sxO, syO
   sxO, syO = celestia:getscreendimension()
   if sxO ~= oldsxO or syO ~= oldsyO or posT1 ~= posT3 or posX1 ~= posX3 then
      -- 2 lines to force the box to stay in the celestia window
      if posT1 >= syO - boxH3 - 2 then posT1 = syO - boxH3 - 2 end
      if posX1 >= sxO - boxW3 - 2 then posX1 = sxO - boxW3 - 2 end
      OrionFrame:attach(screenBox, posX1, syO-posT1-boxH3, sxO-boxW3-posX1, posT1)
   end
   -- recording the actual position
   posX1 = this.la
   posT1 = this.ta
   posX3, posT3 = posX1, posT1
end

-- Close button
OrionFrame4.Customdraw = function(this)
    OrionFrame4:attach(OrionFrame, boxW3-10, boxH3-10, 0, 0)
end

OrionCheck1 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 0) + 4, boxW3-16, lspace*2 + 4)

OrionCheck1.Customdraw = function(this)
    OrionCheck1:attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 0) + 4, boxW3-16, lspace*2 + 4)
end

OrionCheck1.Action = (function()
        return
            function()
                x_Orion_Asterisms(1)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Sword of Orion" Asterisms in Orion
                celestia:showconstellations{"Sword of Orion"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

OrionCheck2 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 1) + 4, boxW3-16, lspace*3 + 4)

OrionCheck2.Customdraw = function(this)
    OrionCheck2:attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 1) + 4, boxW3-16, lspace*3 + 4)
end

OrionCheck2.Action = (function()
        return
            function()
                x_Orion_Asterisms(2)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Belt of Orion"Asterisms in Orion
                celestia:showconstellations{"Belt of Orion"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

OrionCheck3 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 2) + 4, boxW3-16, lspace*4 + 4)

OrionCheck3.Customdraw = function(this)
    OrionCheck3:attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 2) + 4, boxW3-16, lspace*4 + 4)
end

OrionCheck3.Action = (function()
        return
            function()
                x_Orion_Asterisms(3)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Butterfly of Orion" Asterisms in Orion
                celestia:showconstellations{"Butterfly of Orion"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

OrionCheck4 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 3) + 4, boxW3-16, lspace*5 + 4)

OrionCheck4.Customdraw = function(this)
    OrionCheck4:attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 3) + 4, boxW3-16, lspace*5 + 4)
end

OrionCheck4.Action = (function()
        return
            function()
                x_Orion_Asterisms(4)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Venus Mirror" Asterisms in Orion
                celestia:showconstellations{"Venus Mirror"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

OrionCheck5 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 4) + 4, boxW3-16, lspace*6 + 4)

OrionCheck5.Customdraw = function(this)
    OrionCheck5:attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 4) + 4, boxW3-16, lspace*6 + 4)
end

OrionCheck5.Action = (function()
        return
            function()
                x_Orion_Asterisms(5)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Heavenly G" Asterisms in Orion
                celestia:showconstellations{"Heavenly G"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

OrionCheck6 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 5) + 4, boxW3-16, lspace*7 + 4)

OrionCheck6.Customdraw = function(this)
    OrionCheck6:attach(OrionFrame, 6, lspace*(number_Orion_asterisms - 5) + 4, boxW3-16, lspace*7 + 4)
end

OrionCheck6.Action = (function()
        return
            function()
                x_Asterisms(0)
                AsterismsFrame.Visible = true
                display_Asterisms = true
                x_Orion_Asterisms(0)
                OrionFrame.Visible = false
                display_Orion_Asterisms = false
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
            end
        end) ();

--
-- Box to show the Ursa Major Asterisms
--

UrsaMajorFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text(text_Asterisms_In_Ursa_Major)
    :movetext(-5,4)
    :fillcolor(Constsetbofill)
    :bordercolor(Constbubordoff)
    :movable(true)
    :clickable(false)
    :visible(display_UrsaMajor_Asterisms)
    :attach(screenBox, posX1, syUM-posT1-boxH4, sxUM-boxW4-posX1, posT1)

-- Close button
UrsaMajorFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text("x")
    :textpos("center")
    :movetext(0, 10)
    :bordercolor(Constbubordoff)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(UrsaMajorFrame, boxW4-10, boxH4-10, 0, 0)
   
UrsaMajorFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(Constbutextoff)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb+30,this.tb-lspace*2+2)
   textlayout:println("")
   textlayout:println(text_Asterism22)
   textlayout:println(text_Asterism23)
   textlayout:println(text_Asterism24)
   textlayout:println(text_Asterism25)
   textlayout:println(text_Asterisms)
   -- Check changed screen dimensions and reposition the box if necessary
   oldsxUM, oldsyUM = sxUM, syUM
   sxUM, syUM = celestia:getscreendimension()
   if sxUM ~= oldsxUM or syUM ~= oldsyUM or posT1 ~= posT4 or posX1 ~= posX4 then
      -- 2 lines to force the box to stay in the celestia window
      if posT1 >= syUM - boxH4 - 2 then posT1 = syUM - boxH4 - 2 end
      if posX1 >= sxUM - boxW4 - 2 then posX1 = sxUM - boxW4 - 2 end
      UrsaMajorFrame:attach(screenBox, posX1, syUM-posT1-boxH4, sxUM-boxW4-posX1, posT1)
   end
   -- recording the actual position
   posX1 = this.la
   posT1 = this.ta
   posX4, posT4 = posX1, posT1
end

-- Close button
UrsaMajorFrame4.Customdraw = function(this)
    UrsaMajorFrame4:attach(UrsaMajorFrame, boxW4-10, boxH4-10, 0, 0)
end

UrsaMajorCheck1 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 0) + 4, boxW4-16, lspace*2 + 4)

UrsaMajorCheck1.Customdraw = function(this)
    UrsaMajorCheck1:attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 0) + 4, boxW4-16, lspace*2 + 4)
end

UrsaMajorCheck1.Action = (function()
        return
            function()
                x_UrsaMajor_Asterisms(1)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Horse and Rider" Asterisms in Ursa Major
                celestia:showconstellations{"Horse and Rider"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

UrsaMajorCheck2 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 1) + 4, boxW4-16, lspace*3 + 4)

UrsaMajorCheck2.Customdraw = function(this)
    UrsaMajorCheck2:attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 1) + 4, boxW4-16, lspace*3 + 4)
end

UrsaMajorCheck2.Action = (function()
        return
            function()
                x_UrsaMajor_Asterisms(2)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Bier" Asterisms in Ursa Major
                celestia:showconstellations{"Bier"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

UrsaMajorCheck3 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 2) + 4, boxW4-16, lspace*4 + 4)

UrsaMajorCheck3.Customdraw = function(this)
    UrsaMajorCheck3:attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 2) + 4, boxW4-16, lspace*4 + 4)
end

UrsaMajorCheck3.Action = (function()
        return
            function()
                x_UrsaMajor_Asterisms(3)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Big Dipper" Asterisms in Ursa Major
                celestia:showconstellations{"Big Dipper"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

UrsaMajorCheck4 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 3) + 4, boxW4-16, lspace*5 + 4)

UrsaMajorCheck4.Customdraw = function(this)
    UrsaMajorCheck4:attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 3) + 4, boxW4-16, lspace*5 + 4)
end

UrsaMajorCheck4.Action = (function()
        return
            function()
                x_UrsaMajor_Asterisms(4)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Pointers" Asterisms in Ursa Major
                celestia:showconstellations{"Pointers"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

UrsaMajorCheck5 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 4) + 4, boxW4-16, lspace*6 + 4)

UrsaMajorCheck5.Customdraw = function(this)
    UrsaMajorCheck5:attach(UrsaMajorFrame, 6, lspace*(number_UrsaMajor_asterisms - 4) + 4, boxW4-16, lspace*6 + 4)
end

UrsaMajorCheck5.Action = (function()
        return
            function()
                x_Asterisms(0)
                AsterismsFrame.Visible = true
                display_Asterisms = true
                x_UrsaMajor_Asterisms(0)
                UrsaMajorFrame.Visible = false
                display_UrsaMajor_Asterisms = false
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
            end
        end) ();

--
-- Box to show the Aquarius Asterisms
--

AquariusFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text(text_Asterisms_In_Aquarius)
    :movetext(-5,4)
    :fillcolor(Constsetbofill)
    :bordercolor(Constbubordoff)
    :movable(true)
    :clickable(false)
    :visible(display_Aquarius_Asterisms)
    :attach(screenBox, posX1, syAq-posT1-boxH5, sxAq-boxW5-posX1, posT1)

-- Close button
AquariusFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(Constbutextoff)
    :text("x")
    :textpos("center")
    :movetext(0, 10)
    :bordercolor(Constbubordoff)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(AquariusFrame, boxW5-10, boxH5-10, 0, 0)
   
AquariusFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(Constbutextoff)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb+30,this.tb-lspace*2+2)
   textlayout:println("")
   textlayout:println(text_Asterism26)
   textlayout:println(text_Asterism27)
   textlayout:println(text_Asterisms)
   -- Check changed screen dimensions and reposition the box if necessary
   oldsxAq, oldsyAq = sxAq, syAq
   sxAq, syAq = celestia:getscreendimension()
   if sxAq ~= oldsxAq or syAq ~= oldsyAq or posT1 ~= posT5 or posX1 ~= posX5 then
      -- 2 lines to force the box to stay in the celestia window
      if posT1 >= syAq - boxH5 - 2 then posT1 = syAq - boxH5 - 2 end
      if posX1 >= sxAq - boxW5 - 2 then posX1 = sxAq - boxW5 - 2 end
      AquariusFrame:attach(screenBox, posX1, syAq-posT1-boxH5, sxAq-boxW5-posX1, posT1)
   end
   -- recording the actual position
   posX1 = this.la
   posT1 = this.ta
   posX5, posT5 = posX1, posT1
end

-- Close button
AquariusFrame4.Customdraw = function(this)
    AquariusFrame4:attach(AquariusFrame, boxW5-10, boxH5-10, 0, 0)
end

AquariusCheck1 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AquariusFrame, 6, lspace*(number_Aquarius_asterisms - 0) + 4, boxW5-16, lspace*2 + 4)

AquariusCheck1.Customdraw = function(this)
    AquariusCheck1:attach(AquariusFrame, 6, lspace*(number_Aquarius_asterisms - 0) + 4, boxW5-16, lspace*2 + 4)
end

AquariusCheck1.Action = (function()
        return
            function()
                x_Aquarius_Asterisms(1)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Y of Aquarius" Asterisms in Aquarius
                celestia:showconstellations{"Y of Aquarius"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

AquariusCheck2 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AquariusFrame, 6, lspace*(number_Aquarius_asterisms - 1) + 4, boxW5-16, lspace*3 + 4)

AquariusCheck2.Customdraw = function(this)
    AquariusCheck2:attach(AquariusFrame, 6, lspace*(number_Aquarius_asterisms - 1) + 4, boxW5-16, lspace*3 + 4)
end

AquariusCheck2.Action = (function()
        return
            function()
                x_Aquarius_Asterisms(2)
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
                -- "Water Jar" Asterisms in Aquarius
                celestia:showconstellations{"Water Jar"}
                celestia:setrenderflags{constellations=true}
                celestia:setlabelflags{constellations = Show_Constellation_Labels}
            end
        end) ();

AquariusCheck3 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(Constbubordoff)
        :textfont(smallfont)
        :textcolor(Constbutextoff)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(AquariusFrame, 6, lspace*(number_Aquarius_asterisms - 2) + 4, boxW5-16, lspace*4 + 4)

AquariusCheck3.Customdraw = function(this)
    AquariusCheck3:attach(AquariusFrame, 6, lspace*(number_Aquarius_asterisms - 2) + 4, boxW5-16, lspace*4 + 4)
end

AquariusCheck3.Action = (function()
        return
            function()
                x_Asterisms(0)
                AsterismsFrame.Visible = true
                display_Asterisms = true
                x_Aquarius_Asterisms(0)
                AquariusFrame.Visible = false
                display_Aquarius_Asterisms = false
                -- Hide the additional Asterisms and alternative Constellations delivered with the Asterisms Add-on.
                celestia:hideconstellations()
            end
        end) ();
        
--
-- Box in the Toolkit of Lua_Edu_Tools to select/deselect the application (instead of [key shortcut]).
--

if lua_edu_tools then
   ConstellationsSwitch = CXBox:new()
       :init(0, 0, 0, 0)
       :bordercolor(Constbubordoff)
       :textfont(normalfont)
       :textcolor(Constbutextoff)
       :textpos("center")
       :movetext(0, 8)
       :text(text_Constellations)
       :movable(false)
       :active(true)
       :attach(ConstellationsBox, 8, 4, 8, 3)

   ConstellationsSwitch.Action = (function()
        return
            function()
                if not (display_Asterisms or display_Orion_Asterisms or display_UrsaMajor_Asterisms or display_Aquarius_Asterisms) then
                   display_Constellations = not display_Constellations
                end
                if display_Constellations then
                   ConstellationsSwitch.Bordercolor=cbubordon
                   ConstellationsSwitch.Fillcolor = {cbubordon[1]*2/3, cbubordon[2]*2/3, cbubordon[3]*2/3, cbubordon[4]/2}
                   ConstellationsFrame.Visible = true
                   ConstellationsFrame:orderfront() 
                   position_for_Asterism("Sol")
                else
                   ConstellationsSwitch.Bordercolor=Constbubordoff
                   ConstellationsSwitch.Fillcolor = nil
                   ConstellationsFrame.Visible = false
                end
                x_Close_Boxes(0)
            end
        end) ();
else
   keymap[shortcut] = toggleConstellationsDisplay
end

-- Close buttons
ConstellationsFrame4.Action = (function()
     return
         function()
             x_Close_Boxes(1)
         end
     end) ();

AsterismsFrame4.Action = (function()
     return
         function()
             x_Close_Boxes(1)
         end
     end) ();

OrionFrame4.Action = (function()
     return
         function()
             x_Close_Boxes(1)
         end
     end) ();

UrsaMajorFrame4.Action = (function()
     return
         function()
             x_Close_Boxes(1)
         end
     end) ();

AquariusFrame4.Action = (function()
     return
         function()
             x_Close_Boxes(1)
         end
     end) ();

celestia:log("-- Constellations Plugin loaded --")