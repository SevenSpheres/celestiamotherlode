----------------------------------------------
-- Set initial values
----------------------------------------------

if lua_edu_tools and lang ~= "en"
	then require "locale" 
	else require "ObjectsRiseSet_locale"
end

if pcall( function() require ("locale_ObjectsRiseSet_"..lang) end ) then
	for engl, transl in pairs(ObjectsRiseSet_loc_str) do
		loc_str[engl]=transl
	end
end

require "ObjectsRiseSet_config" 
   
--
--	Some constants, variables and useful unit conversions:
--

--Plug-in box dimensions and initial positions
local sx, sy = celestia:getscreendimension()
local sxA, syA = sx, sy
local oldsx, oldsy = 0, 0
local oldsxA, oldsyA = oldsx, oldsy
local lspace = normalfont:getheight() + 1
local boxW1 = 230                                          -- display width
local orig_boxW1 = boxW1
local prev_boxW1 = boxW1
local boxH1 = lspace * 13 + 8                              -- display height
local orig_boxH1 = boxH1                                   -- V2.2 added
local prev_boxH1 = boxH1                                   -- V2.2 added
local posX1, posT1 = sx/2 + 410 - boxW1, 2                 -- near the top, on the right half of the screen.
local boxW1F2 = 80                                         -- display width variables
local boxW1F3 = 80                                         -- display width of the script button
local number_objects = 11
local boxW2, boxH2 = 140, lspace*(number_objects+3)        -- display width, display height
local posX2, posT2 = sxA/2 - 260 - boxW2, 2                -- near the top, 250 pixels left of the middle of the screen.

-- Constants
local pi=math.rad(180)
local pi2=2*pi
local dr=pi/180
local k1=15*dr*1.00273790934
local zone0=0
local script_ObjectsRiseSet = false
local uly_to_km = 9460730.4725808
local Objects_number = 0
local PlRS_LOOK  = celestia:newvector(0,0,-1)
local PlRS_J2000Obliquity = 23.4392911 * math.pi / 180     -- Angle between J2000 mean equator and the ecliptic plane.

-- Main Solar System Objects
local PlRS_sun=celestia:find("Sol")
local PlRS_mercury=celestia:find("Sol/Mercury")
local PlRS_venus=celestia:find("Sol/Venus")
local PlRS_earth=celestia:find("Sol/Earth")
local PlRS_moon=celestia:find("Sol/Earth/Moon")
local PlRS_mars=celestia:find("Sol/Mars")
local PlRS_jupiter=celestia:find("Sol/Jupiter")
local PlRS_saturn=celestia:find("Sol/Saturn")
local PlRS_uranus=celestia:find("Sol/Uranus")
local PlRS_neptune=celestia:find("Sol/Neptune")
local PlRS_pluto=celestia:find("Sol/Pluto")
local PlRS_object, PlRS_object_name                        -- Other NON Main Solar System Objects with their name.

-- Internationalization strings
local text_Objectsname      = {}
local text_Objectstitle     = {}
local text_Objectsrise_at   = {}
local text_Objectsset_at    = {}
local text_Objectsdown      = {}
local text_Objectsup        = {}
local text_noObjectsrise    = {}
local text_noObjectsset     = {}
text_Objectsname[0]         = _("Sun")
text_Objectstitle[0]        = _("Sun Rise/Set")
text_Objectsrise_at[0]      = _("Sunrise at:")
text_Objectsset_at[0]       = _("Sunset at:")
text_Objectsdown[0]         = _("Sun DOWN all day.")
text_Objectsup[0]           = _("Sun UP all day.")
text_noObjectsrise[0]       = _("NO Sunrise this date.")
text_noObjectsset[0]        = _("NO Sunset this date.")
text_Objectsname[1]         = _("Mercury")
text_Objectstitle[1]        = _("Mercury Rise/Set")
text_Objectsrise_at[1]      = _("Mercury rise at:")
text_Objectsset_at[1]       = _("Mercury set at:")
text_Objectsdown[1]         = _("Mercury DOWN all day.")
text_Objectsup[1]           = _("Mercury UP all day.")
text_noObjectsrise[1]       = _("NO Mercury rise this date.")
text_noObjectsset[1]        = _("NO Mercury set this date.")
text_Objectsname[2]         = _("Venus")
text_Objectstitle[2]        = _("Venus Rise/Set")
text_Objectsrise_at[2]      = _("Venus rise at:")
text_Objectsset_at[2]       = _("Venus set at:")
text_Objectsdown[2]         = _("Venus DOWN all day.")
text_Objectsup[2]           = _("Venus UP all day.")
text_noObjectsrise[2]       = _("NO Venus rise this date.")
text_noObjectsset[2]        = _("NO Venus set this date.")
text_Objectsname[3]         = _("Moon")
text_Objectstitle[3]        = _("Moon Rise/Set")
text_Objectsrise_at[3]      = _("Moonrise at:")
text_Objectsset_at[3]       = _("Moonset at:")
text_Objectsdown[3]         = _("Moon DOWN all day.")
text_Objectsup[3]           = _("Moon UP all day.")
text_noObjectsrise[3]       = _("NO Moonrise this date.")
text_noObjectsset[3]        = _("NO Moonset this date.")
text_Objectsname[4]         = _("Mars")
text_Objectstitle[4]        = _("Mars Rise/Set")
text_Objectsrise_at[4]      = _("Mars rise at:")
text_Objectsset_at[4]       = _("Mars set at:")
text_Objectsdown[4]         = _("Mars DOWN all day.")
text_Objectsup[4]           = _("Mars UP all day.")
text_noObjectsrise[4]       = _("NO Mars rise this date.")
text_noObjectsset[4]        = _("NO Mars set this date.")
text_Objectsname[5]         = _("Jupiter")
text_Objectstitle[5]        = _("Jupiter Rise/Set")
text_Objectsrise_at[5]      = _("Jupiter rise at:")
text_Objectsset_at[5]       = _("Jupiter set at:")
text_Objectsdown[5]         = _("Jupiter DOWN all day.")
text_Objectsup[5]           = _("Jupiter UP all day.")
text_noObjectsrise[5]       = _("NO Jupiter rise this date.")
text_noObjectsset[5]        = _("NO Jupiter set this date.")
text_Objectsname[6]         = _("Saturn")
text_Objectstitle[6]        = _("Saturn Rise/Set")
text_Objectsrise_at[6]      = _("Saturn rise at:")
text_Objectsset_at[6]       = _("Saturn set at:")
text_Objectsdown[6]         = _("Saturn DOWN all day.")
text_Objectsup[6]           = _("Saturn UP all day.")
text_noObjectsrise[6]       = _("NO Saturn rise this date.")
text_noObjectsset[6]        = _("NO Saturn set this date.")
text_Objectsname[7]         = _("Uranus")
text_Objectstitle[7]        = _("Uranus Rise/Set")
text_Objectsrise_at[7]      = _("Uranus rise at:")
text_Objectsset_at[7]       = _("Uranus set at:")
text_Objectsdown[7]         = _("Uranus DOWN all day.")
text_Objectsup[7]           = _("Uranus UP all day.")
text_noObjectsrise[7]       = _("NO Uranus rise this date.")
text_noObjectsset[7]        = _("NO Uranus set this date.")
text_Objectsname[8]         = _("Neptune")
text_Objectstitle[8]        = _("Neptune Rise/Set")
text_Objectsrise_at[8]      = _("Neptune rise at:")
text_Objectsset_at[8]       = _("Neptune set at:")
text_Objectsdown[8]         = _("Neptune DOWN all day.")
text_Objectsup[8]           = _("Neptune UP all day.")
text_noObjectsrise[8]       = _("NO Neptune rise this date.")
text_noObjectsset[8]        = _("NO Neptune set this date.")
text_Objectsname[9]         = _("Pluto")
text_Objectstitle[9]        = _("Pluto Rise/Set")
text_Objectsrise_at[9]      = _("Pluto rise at:")
text_Objectsset_at[9]       = _("Pluto set at:")
text_Objectsdown[9]         = _("Pluto DOWN all day.")
text_Objectsup[9]           = _("Pluto UP all day.")
text_noObjectsrise[9]       = _("NO Pluto rise this date.")
text_noObjectsset[9]        = _("NO Pluto set this date.")
text_Objectsname[10]        = _("Selected Object")
text_Objectstitle[10]       = _(" Rise/Set")
text_Objectsrise_at[10]     = _(" rise at:")
text_Objectsset_at[10]      = _(" set at:")
text_Objectsdown[10]        = _(" DOWN all day.")
text_Objectsup[10]          = _(" UP all day.")
text_noObjectsrise[10]      = _(": NO rise this date.")
text_noObjectsset[10]       = _(": NO set this date.")
local text_longitude        = _("Longitude:")
local text_latitude         = _("Latitude:")
local text_date             = _("Date:")
local text_azimuth          = _("Azimuth:")
local text_invalid_location = _("Invalid location in config file.")
local text_month1           = _(" Jan ")
local text_month2           = _(" Feb ")
local text_month3           = _(" Mar ")
local text_month4           = _(" Apr ")
local text_month5           = _(" May ")
local text_month6           = _(" Jun ")
local text_month7           = _(" Jul ")
local text_month8           = _(" Aug ")
local text_month9           = _(" Sep ")
local text_month10          = _(" Oct ")
local text_month11          = _(" Nov ")
local text_month12          = _(" Dec ")
local text_script           = _("Animation")
local text_toolkit          = _("Objects Rise/Set")
local text_object           = _("Select Object")

local monthname={text_month1, text_month2,  text_month3,  text_month4,
                 text_month5, text_month6,  text_month7,  text_month8,
                 text_month9, text_month10, text_month11, text_month12}
local display1_text1a, display1_text2a, display1_text3a
local display1_text4a, display1_text5a, display1_text6a
local display1_text1b, display1_text2b, display1_text3b
local display1_text4b, display1_text5b, display1_text6b
local display2_text4a, display2_text5a, display2_text6a
local display2_text4b, display2_text5b, display2_text6b
--local display3_text4a, display3_text5a, display3_text6a  -- v2.2 added
--local display3_text4b, display3_text5b, display3_text6b  -- v2.2 added
local event3=false                                         -- v2.2 added
local PlRS_obs, PlRS_orig_ambient, PlRS_orig_renderflags, PlRS_static_date
local PlRS_tdb_juliandate, PlRS_static, Old_PlRS_long_earth, Old_PlRS_lat_earth
local PlRS_script, PlRS_obs_pos, PlRS_earth_pos, PlRS_obs_earth, PlRS_distance, actual_selection, parent_object, LookatEarth
local store_Objectsname10 = text_Objectsname[10]                               -- Remember original text string, to restore when it's changed by the actual selection.

-- Personalize, obtained from configuration file.
local display_ObjectsRiseSet = ObjectsRiseSet_visible or false

local text_color = ObjectsRiseSet_color or {0.9, 0.4, 0.2, 0.9}                -- Color of the text in the boxes.
local fill_color = ObjectsRiseSet_fillcolor or {0.2, 0.1, 0.1, 0.3}            -- Background color of the boxes.
local shortcut = ObjectsRiseSet_shortcut or "!"                                -- Activation / Deac tivation key for Lua_Plugins.

local PlRS_long_earth = PlRPlS_long_earth or nil                               -- Longitude in degrees.
local PlRS_lat_earth  = PlRPlS_lat_earth or nil                                -- Latitude in degrees.
local PlRS_location_name = PlRPlS_location_name or ""                          -- Fill in your own location name between the 2 quotes, belonging to your longlat position.

local PlRS_ObjectsRiseSet_Showlocation = ObjectsRiseSet_Showlocation or false  -- Determine if you want Celestia to display the location.
                                                                               -- for which the Sunnrise and Sunset will be calculated.

local PlRS_date_Year = PlRPlS_date_Year or nil                                 -- Year.
local PlRS_date_Month = PlRPlS_date_Month or nil                               -- Month.
local PlRS_date_Day = PlRPlS_date_Day or nil                                   -- Day.

local PlRS_ambient = ObjectsRiseSet_Ambient or 0.05

-- Save original values
PlRS_orig_renderflags = celestia:getrenderflags()
PlRS_orig_ambient=celestia:getambient()

-- Determine if a predefined date is used.
if PlRS_date_Year ~= nil and PlRS_date_Month ~= nil and PlRS_date_Day ~= nil then
   PlRS_static_date = true
   PlRS_tdb_juliandate = celestia:utctotdb(PlRS_date_Year, PlRS_date_Month, PlRS_date_Day, 12)
   if display_ObjectsRiseSet then
      celestia:settime(PlRS_tdb_juliandate)
   end
else
   PlRS_static_date = false
end

-- Determine if a static location is used.
if PlRS_long_earth ~= nil and PlRS_lat_earth ~= nil and PlRS_location_name ~= "" then
   PlRS_static = true
   -- Test/adjust Longitude and Latitude.
   if PlRS_lat_earth < -90 then
      PlRS_lat_earth = -90
   elseif PlRS_lat_earth > 90 then
      PlRS_lat_earth = 90
   end
   if PlRS_long_earth <= -360 or PlRS_long_earth>=360 then
      PlRS_long_earth = 0
   end
   if PlRS_long_earth<0 then
      PlRS_long_earth=PlRS_long_earth+360
   end
   if PlRS_long_earth>180 then
      PlRS_long_earth=PlRS_long_earth-360
   end
else
   PlRS_static = false
   Old_PlRS_long_earth = nil
   Old_PlRS_lat_earth = nil
end
																		
-- Test if valid loacal timezone, otherwise UTC will be used.
local PlRS_test = false
for PlRS_i, value in ipairs(PlRS_local_timezone_table) do
   if PlRS_local_timezone_table[PlRS_i] == PlRS_local_timezone then
      PlRS_test = true
   end
end
if not PlRS_test then
   PlRS_local_timezone="UTC"
end
local local_offset = PlRS_offset[PlRS_local_timezone]

---------------------
-- local functions --
---------------------

local x_Objects = function(number)
   -- Check/Uncheck the Objects boxes.
   -- Depending on the given sequence number, adjust text field 10.
   ObjectsCheck0.Text = ""
   ObjectsCheck1.Text = ""
   ObjectsCheck2.Text = ""
   ObjectsCheck3.Text = ""
   ObjectsCheck4.Text = ""
   ObjectsCheck5.Text = ""
   ObjectsCheck6.Text = ""
   ObjectsCheck7.Text = ""
   ObjectsCheck8.Text = ""
   ObjectsCheck9.Text = ""
   ObjectsCheck10.Text = ""
   if number == 10 then
      ObjectsCheck10.Text = "x"
      text_Objectsname[10] = PlRS_object_name
   else
      text_Objectsname[10] = store_Objectsname10
      if number == 0 then
         ObjectsCheck0.Text = "x"
      elseif number == 1 then
         ObjectsCheck1.Text = "x"
      elseif number == 2 then
         ObjectsCheck2.Text = "x"
      elseif number == 3 then
         ObjectsCheck3.Text = "x"
      elseif number == 4 then
         ObjectsCheck4.Text = "x"
      elseif number == 5 then
         ObjectsCheck5.Text = "x"
      elseif number == 6 then
         ObjectsCheck6.Text = "x"
      elseif number == 7 then
         ObjectsCheck7.Text = "x"
      elseif number == 8 then
         ObjectsCheck8.Text = "x"
      elseif number == 9 then
         ObjectsCheck9.Text = "x"
      else
         ObjectsCheck0.Text = "x"
      end
   end
end

local toggleObjectsRiseSetDisplay = function()
   -- Enable/Disable the Plug-in
   ObjectsRiseSetFrame.Visible = not ObjectsRiseSetFrame.Visible
   ObjectsFrame.Visible = ObjectsRiseSetFrame.Visible
   ObjectsRiseSetFrame:orderfront() 
   if ObjectsRiseSetFrame.Visible then
      celestia:print("ObjectsRiseSet plug-in enabled", 2, -1, -1, 2, 4)
      PlRS_orig_renderflags = celestia:getrenderflags()
      PlRS_orig_ambient=celestia:getambient()
      PlRS_obs = celestia:getobserver()
      celestia:setambient(PlRS_ambient)
      PlRS_earth:unmark()
      celestia:setrenderflags{markers=true}
      LookatEarth = true
      actual_selection = celestia:getselection()
      if actual_selection:name() == "Earth" then
         LookatEarth = false
      elseif actual_selection:type() == "location" then
         parent_object = actual_selection:getinfo().parent
         if parent_object:name() == "Earth" then
            LookatEarth = false
         end
      elseif PlRS_obs:getposition():distanceto(PlRS_earth:getposition()) < 200000 then
         LookatEarth = false
      end
      if not PlRS_ObjectsRiseSet_Showlocation and LookatEarth then
         PlRS_obs:gotodistance(PlRS_earth, 4*PlRS_earth:radius(), 0.0)
         PlRS_obs:synchronous(PlRS_earth)
      end
      if PlRS_static_date then
         celestia:settime(PlRS_tdb_juliandate)
      end
   else
      celestia:print("ObjectsRiseSet plug-in disabled", 2, -1, -1, 2, 4)
      PlRS_earth:unmark()
      celestia:setrenderflags{markers=PlRS_orig_renderflags.markers}
      celestia:setambient(PlRS_orig_ambient)
   end
end

local function sign(value)
   -- Returns the sign of the parameter value.
   -- Returns 1 if the value is greater than zero, zero if equal to zero and -1 if negative.
   if value > 0 then
      return 1
   elseif value < 0 then
      return -1
   else
      return 0
   end
end

local PlRS_get_long_lat = function (PlRS_get_long_lat_observer, PlRS_source)
   -- Return longitude and latitude for the observer on the PlRS_source object
   local f = PlRS_source:getinfo().oblateness
   if f == nil then
      f = 0
   end
   local u_pos = PlRS_get_long_lat_observer:getposition()
   local e_frame = celestia:newframe("bodyfixed", PlRS_source)
   local e_pos = e_frame:to(u_pos)
   local lambda = -math.atan2(e_pos.z, e_pos.x);
   local beta = math.pi / 2 - math.atan2(math.sqrt(e_pos.x * e_pos.x + e_pos.z * e_pos.z), e_pos.y)
   local phi = math.atan2(math.tan(beta), (1 - f))
   local long = math.deg(lambda)
   local lat = math.deg(phi)
   return long, lat
end

local PlRS_transform_xyz2rtp = function(x,y,z)
    -- Transform coordinates from cartesian to polar(?)
    local r = math.sqrt(x*x + y*y + z*z)
    local theta = math.atan(math.sqrt(x*x + y*y)/z)
    local phi
    if x < 0 then
        phi = math.atan(y/x) + math.pi
    elseif x > 0 then
        phi = math.atan(y/x)
    elseif y > 0 then
        phi = math.pi/2
    else
        phi = -math.pi/2
    end
    return r,theta,phi
end

local PlRS_rotation_transform = function(v, rotation)
    -- transform a vector by a rotation 
    -- Use native method if available (1.3.2pre8?)
    if rotation.transform ~= nil then
        return rotation:transform(v)
    end
    local matrix = { }
    local x = rotation.x
    local y = rotation.y
    local z = rotation.z
    local w = rotation.w
    local wx = w * x * 2
    local wy = w * y * 2
    local wz = w * z * 2
    local xx = x * x * 2
    local xy = x * y * 2
    local xz = x * z * 2
    local yy = y * y * 2
    local yz = y * z * 2
    local zz = z * z * 2
    matrix[0] = { x= 1 - yy - zz, y= xy - wz,     z= xz + wy }
    matrix[1] = { x= xy + wz,     y= 1 - xx - zz, z= yz - wx }
    matrix[2] = { x= xz - wy,     y= yz + wx,     z= 1 - xx - yy }
    local nx = (matrix[0].x * v.x + matrix[1].x * v.y + matrix[2].x * v.z)
    local ny = (matrix[0].y * v.x + matrix[1].y * v.y + matrix[2].y * v.z)
    local nz = (matrix[0].z * v.x + matrix[1].z * v.y + matrix[2].z * v.z)
    return celestia:newvector(nx, ny, nz)
end

local PlRS_get_ra_dec = function(sel, time)
    -- Return Equatorial Coordinates (Ra, Dec) for selection at given time
    local base_rot = celestia:newrotation(celestia:newvector(1,0,0), -PlRS_J2000Obliquity)
    local rot = PlRS_earth:getposition(time):orientationto(sel:getposition(time), PlRS_LOOK) * base_rot
    local look = (PlRS_rotation_transform(PlRS_LOOK, rot)):normalize()
    local r,theta,phi = PlRS_transform_xyz2rtp(look.x, look.z, look.y)
    local phi = math.mod(2*pi2 - phi, pi2)
    if theta > 0 then
       theta = pi/2 - theta
    else
       theta = (-pi/2 - theta)
    end
    return phi, theta
end

local function ObjectsRiseSet_location()
   -- Determine the Longutude and Latitude for a location on Earth.
   local PlRS_obs_temp=celestia:getobserver()
   actual_selection = celestia:getselection()
   if PlRS_static then
      -- Static location: Longitude and Latitude are given in the configuration file.
	   return true
   else
      -- Dynamic location.
      -- Determine if a specific location on Earth is selected.
      -- If so, determine the longitude and latitude of that location.
      -- Otherwise the longitude and latitude of the observer is taken.
      PlRS_location_name = ""
      local locationbased = false
      if actual_selection:type() == "location" then
         parent_object = actual_selection:getinfo().parent
         if parent_object:name() == "Earth" then
            PlRS_location_name = actual_selection:localname()
            if PlRS_location_name == "?" then
               PlRS_location_name = actual_selection:name()
            end
            PlRS_obs_temp:setframe(celestia:newframe("universal"))
            local now = celestia:gettime()
            local pos_actual_selection = actual_selection:getposition(now)
            local pos_earth = PlRS_earth:getposition(now)
            local u_pos = pos_earth + 4*(pos_actual_selection - pos_earth)
            local f = PlRS_earth:getinfo().oblateness
            if f == nil then
               f = 0
            end
            local e_frame = celestia:newframe("bodyfixed", PlRS_earth)
            local e_pos = e_frame:to(u_pos)
            local lambda = -math.atan2(e_pos.z, e_pos.x);
            local beta = math.pi / 2 - math.atan2(math.sqrt(e_pos.x * e_pos.x + e_pos.z * e_pos.z), e_pos.y)
            local phi = math.atan2(math.tan(beta), (1 - f))
            PlRS_long_earth = math.deg(lambda)
            PlRS_lat_earth = math.deg(phi)
            locationbased = true
         end
      end
      if not locationbased then
         PlRS_long_earth, PlRS_lat_earth = PlRS_get_long_lat(PlRS_obs_temp, PlRS_earth)
      end
      return true
   end
end

-- v2.2 by Massimo: function to precess J2000.0 equatorial coordinates for a given values in radiants
ObjectsRiseSet_Precess_Data_Eq = function(x, y)
   if (x and x ~= 0.0) or (y and y ~= 0.0) then
      local raJ2000 = x;
      local decJ2000 = y;
      -- reduction of positions from equinox J2000.0 to date
      -- modified for IAU 2000A_R06 precession, P03 solution
      local TDB = celestia:gettime();
      local T = (TDB - 2451545.0) / 36525; -- TDB century
      -- equatorial precession angles
      local zetaA = (2.650545
                    + 2306.083227 * T
                    + 0.2988499 * T^2
                    + 0.01801828 * T^3
                    - 0.000005971 * T^4
                    - 0.0000003173 * T^5);
            zetaA = math.rad(zetaA / 3600.0);
      local zA = (-2.650545 
                 + 2306.077181 * T
                 + 1.0927348 * T^2
                 + 0.01826837 * T^3
                 - 0.000028596 * T^4
                 - 0.0000002904 * T^5);
            zA = math.rad(zA / 3600.0);
      local thetaA = (2004.191903 * T
                     - 0.4294934 * T^2
                     - 0.04182264 * T^3
                     - 0.000007089 * T^4
                     - 0.0000001274 * T^5);
            thetaA = math.rad(thetaA / 3600.0);
      -- equatorial R.A. of the date (Meeus, A.A. 21.4)
      local EqxA = math.cos(decJ2000) * math.sin(raJ2000 + zetaA);
      local EqxB = math.cos(thetaA) * math.cos(decJ2000) * math.cos(raJ2000 + zetaA) - math.sin(thetaA) * math.sin(decJ2000);
      local ra_zA = math.atan2(EqxA , EqxB);
      local raEqx = ObjectsRiseSet_rangeRad(ra_zA + zA);
      -- equatorial Declination of the date (Meeus, A.A. 21.4)
      local decEqx = math.sin(thetaA) * math.cos(decJ2000) * math.cos(raJ2000 + zetaA) + math.cos(thetaA) * math.sin(decJ2000);
            decEqx = math.asin(decEqx);
      local ra, dec = raEqx, decEqx; 
      return ra, dec;
   else
      return 0.0, 0.0;
   end
end

-- v2.2 by Massimo: beloning to function to precess J2000.0 equatorial coordinates for a given values in radiants
ObjectsRiseSet_rangeRad = function(x)
   local PI2 = 2.0 * math.pi;
   local b = x / PI2;
   local a = PI2 * (b - math.floor(b));
   if a < 0 then
      a = PI2 + a;
   end
      return a;
end

local function ObjectsRiseSet_calculate()
   -- Routine to calculate the Rise and Set times on Earth of a Space Object for the actual date.
   local Z1, C, Z, M8, W8, A0, D0, test_PlRS_nr
   local C0, P, A, A2, B, D1, D2, C7, LL0, LL2, H0, H1, H2, H3, H7, V0, V1, V2, text, E, M3, T3, N7, AZ
   local HH_UTC_1st, MM_UTC_1st, AZ_1st, text_1st, HH_UTC_2nd, MM_UTC_2nd, AZ_2nd, text_2nd
   local tdb2, tdb2_local, local_dt, year_local_2nd, month_local_2nd, day_local_2nd, HH_local_2nd, MM_local_2nd
   local tdb1, tdb1_local, year_local_1st, month_local_1st, day_local_1st, HH_local_1st, MM_local_1st
   local HH_UTC_3rd, MM_UTC_3rd, AZ_3rd, text_3rd                                                       -- v2.2 added
   local tdb3, tdb3_local, year_local_3rd, month_local_3rd, day_local_3rd, HH_local_3rd, MM_local_3rd   -- v2.2 added
   local actual_tdbtime, year_UTC, month_UTC, day_UTC, g, d1, f, JD, s, a, j3, t, T, t0, S
   local ra_Objects1, dec_Objects1, ra_Objects2, dec_Objects2, ra_Objects3, dec_Objects3
   local moonpos, earthpos, distance, scaling, textwidth
   local today = {}
   local tomorrow = {}

   -- Get the Calendar date from Celestia --> JD
   actual_tdbtime = celestia:gettime()
   today = celestia:tdbtoutc(actual_tdbtime)
   year_UTC  = today.year
   month_UTC = today.month
   day_UTC   = today.day
   tomorrow = celestia:tdbtoutc(actual_tdbtime + 1)
   -- NO "1583: Calendar reform" issue in Celestia (according original BASIC program)
   d1=math.floor(day_UTC)
   f=day_UTC-d1-0.5
   JD=-math.floor(7*(math.floor((month_UTC+9)/12)+year_UTC)/4)
   s=sign(month_UTC-9)
   a=math.abs(month_UTC-9)
   j3=math.floor(year_UTC + s*math.floor(a/7))
   j3=-math.floor((math.floor(j3/100) + 1)*3/4)
   JD=JD + math.floor(275*month_UTC/9) + d1 + j3
   JD=JD + 1721029 + 367*year_UTC
   if f<0 then
      f=f+1
      JD=JD-1
   end
   -- Julianday 2451545 = 1-1-2000 12:00
   t=(JD-2451545) + f
   -- T = centuries from 1900.0
   T=t/36525 + 1
   -- t0 = Local Sidereal Time at 0h zone time
   t0=t/36525
   S=24110.5 + 8640184.813*t0
   S=S + 86636.6*zone0 + 86400*PlRS_long_earth/360
   S=S/86400
   S=S-math.floor(S)
   t0=S*360*dr
   t=t+zone0

   -- Determine 3 time points for this day for 3 point interpolation.
   time1 = celestia:utctotdb(today.year, today.month, today.day, 0, 0, 0)
   time2 = celestia:utctotdb(today.year, today.month, today.day, 12, 0, 0)
   time3 = celestia:utctotdb(tomorrow.year, tomorrow.month, tomorrow.day, 0, 0, 0)
   -- Determine the RA and DEC for the specified object on the given 3 time points.
   -- v2.2 by Massimo: Injected the precession into rise/set RA, Dec (at time1/time2/time3) 
   if Objects_number == 0 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_sun, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_sun, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_sun, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_sun, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_sun, time3)
       ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_sun, time3))
   elseif Objects_number == 1 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_mercury, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_mercury, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_mercury, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_mercury, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_mercury, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_mercury, time3))
   elseif Objects_number == 2 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_venus, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_venus, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_venus, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_venus, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_venus, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_venus, time3))
   elseif Objects_number == 3 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_moon, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_moon, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_moon, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_moon, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_moon, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_moon, time3))
   elseif Objects_number == 4 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_mars, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_mars, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_mars, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_mars, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_mars, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_mars, time3))
   elseif Objects_number == 5 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_jupiter, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_jupiter, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_jupiter, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_jupiter, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_jupiter, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_jupiter, time3))
   elseif Objects_number == 6 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_saturn, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_saturn, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_saturn, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_saturn, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_saturn, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_saturn, time3))
   elseif Objects_number == 7 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_uranus, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_uranus, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_uranus, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_uranus, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_uranus, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_uranus, time3))
   elseif Objects_number == 8 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_neptune, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_neptune, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_neptune, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_neptune, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_neptune, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_neptune, time3))
   elseif Objects_number == 9 then
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_pluto, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_pluto, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_pluto, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_pluto, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_pluto, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_pluto, time3))
   else
      --ra_Objects1, dec_Objects1 = PlRS_get_ra_dec(PlRS_object, time1)
      ra_Objects1, dec_Objects1 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_object, time1))
      --ra_Objects2, dec_Objects2 = PlRS_get_ra_dec(PlRS_object, time2)
      ra_Objects2, dec_Objects2 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_object, time2))
      --ra_Objects3, dec_Objects3 = PlRS_get_ra_dec(PlRS_object, time3)
      ra_Objects3, dec_Objects3 = ObjectsRiseSet_Precess_Data_Eq(PlRS_get_ra_dec(PlRS_object, time3))
   end
   -- Test if RA isn't resetting from 2*pi to zero during this date.
   -- If so, adjust the next values with 2*pi. 
   if math.abs (ra_Objects2 - ra_Objects1) > 6 then
      if ra_Objects2<=ra_Objects1 then
         ra_Objects2=ra_Objects2+pi2
      end
   end
   if math.abs (ra_Objects3 - ra_Objects2) > 6 then
      if ra_Objects3<=ra_Objects2 then
         ra_Objects3=ra_Objects3+pi2
      end
   end

   if Objects_number == 0 then
      -- Sunrise or Sunset is defined to occur when the geometric zenith distance of center of the Sun is 90.8333 degrees.
      -- That is, the center of the Sun is geometrically 50 arcminutes below a horizontal plane.
      -- The 50 arcminute geometric depression of the Sun's center used for the computations is obtained
      -- by adding the average apparent radius of the Sun (16 arcminutes)
      -- to the average amount of atmospheric refraction at the horizon (34 arcminutes).
      Z1=dr*90.833
   elseif Objects_number == 3 then
      -- Moonrise or Moonset is defined to occur when the geometric zenith distance of the center
      -- of the Moon = 0.5666 degrees + Moon's apparent angular radius - Moon's horizontal parallax.
      -- A constant of 34 arcminutes (0.5666 degree) is used to account for atmospheric refraction.
      -- The Moon's apparent radius varies from 15 to 17 arcminutes.
      -- The Moon's horizontal parallax varies from 54 to 61 arcminutes.
      moonpos = PlRS_moon:getposition(time2)
      earthpos = PlRS_earth:getposition(time2)
      distance = earthpos:distanceto(moonpos)
      scaling = 60.40974*distance/385301
      Z1=dr*(90.5666 - 41.685/scaling)
   else
      -- Objects rise or Objects set is defined to occur when the geometric zenith distance of the center
      -- of the Object = 0.5666 degrees, to account for atmospheric refraction (exception for the Sun and the Moon above).
      Z1=dr*90.5666
   end

   S=math.sin(PlRS_lat_earth*dr)
   C=math.cos(PlRS_lat_earth*dr)
   Z=math.cos(Z1)
   M8=0
   W8=0

   A0=ra_Objects1
   D0=dec_Objects1
   test_PlRS_nr=0
   boxW1=orig_boxW1
   boxH1=orig_boxH1   -- v2.2 added
   event3=false       -- v2.2 added
   -- Loop for each hour during this date.
   for C0=0,23 do
      P=(C0 + 1)/24
      -- 3-point interpolation of RA
      A=ra_Objects2 - ra_Objects1
      B=ra_Objects3 - ra_Objects2 - A
      A2=ra_Objects1 + P*(2*A + B*(2*P - 1))
      -- 3-point interpolation of DEC
      A=dec_Objects2 - dec_Objects1
      B=dec_Objects3 - dec_Objects2 - A
      D2=dec_Objects1 + P*(2*A + B*(2*P - 1))
      -- Test an hour for an event
      LL0=t0 + C0*k1
      LL2=LL0 + k1
      if A2<A0 and Objects_number ==3 then
         A2=A2 + 2*math.rad(180)
      end
      H0=LL0 - A0
      H2=LL2 - A2
      -- Hour angle
      H1=(H2 + H0)/2
      -- Declination, at half hour
      D1=(D2 + D0)/2
      if C0<=0 then
         -- Initial first loop
         V0=S*math.sin(D0) + C*math.cos(D0)*math.cos(H0) - Z
      end
      V2=S*math.sin(D2) + C*math.cos(D2)*math.cos(H2) - Z
      -- Test if change from under <--> above the horizon. If NOT, there was no Rise/Set during this hour.
      if sign(V0)<sign(V2) or sign(V0)>sign(V2) then
         V1=S*math.sin(D1) + C*math.cos(D1)*math.cos(H1) - Z
         A=2*V2 - 4*V1 + 2*V0
         B=4*V1 - 3*V0 - V2
         D=B*B - 4*A*V0
         if D>=0 then
            D=math.sqrt(D)
            if V0<0 and V2>0 then
               if Objects_number == 10 then
                  text=PlRS_object_name .. text_Objectsrise_at[10]
                  textwidth = normalfont:getwidth(text)
                  if textwidth > (boxW1 - boxW1F2 - 5) then
                     boxW1 = textwidth + boxW1F2 + 5
                  end
               else
                  text=text_Objectsrise_at[Objects_number]
               end
               M8=1
            end
            if V0>0 and V2<0 then
               if Objects_number == 10 then
                  text=PlRS_object_name .. text_Objectsset_at[10]
                  textwidth = normalfont:getwidth(text)
                  if textwidth > (boxW1 - boxW1F2 - 5) then
                     boxW1 = textwidth + boxW1F2 + 5
                  end
               else
                  text=text_Objectsset_at[Objects_number]
               end
               W8=1
            end
            E=(-B + D)/(2*A)
            if E>1 or E<0 then
               E=(-B - D)/(2*A)
            end
            T3=C0 + E + 1/120
		    -- Round off
            H3=math.floor(T3)
            M3=math.floor((T3 - H3)*60)
            if H3<0 and Objects_number > 0 then
               H3=H3+24
            end
            H7=H0 + E*(H2 - H0)
            N7=-math.cos(D1)*math.sin(H7)
            D7=C*math.sin(D1) - S*math.cos(D1)*math.cos(H7)
            AZ=math.atan(N7/D7)/dr
            if D7<0 then
               AZ=AZ + 180
            end
            if AZ<0 then
               AZ=AZ + 360
            end
            if AZ>360 then
               AZ=AZ - 360
            end
            -- v2.2 Added test for possible 3rd event on the same day
            if test_PlRS_nr==0 then
               HH_UTC_1st=H3
               MM_UTC_1st=M3
               AZ_1st=AZ
               text_1st=text
               test_PlRS_nr=1
            elseif test_PlRS_nr==2 then
               HH_UTC_3rd=H3
               MM_UTC_3rd=M3
               AZ_3rd=AZ
               text_3rd=text
               test_PlRS_nr=3
               boxH1=boxH1 + lspace * 4
               event3=true
            else
               HH_UTC_2nd=H3
               MM_UTC_2nd=M3
               AZ_2nd=AZ
               text_2nd=text
               test_PlRS_nr=2
            end
         end
      end
      A0=A2
      D0=D2
      V0=V2
   end

   -- Display values in text fields.
   if M8==0 and W8==0 then
      if V2<0 then
         display1_text1a = PlRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", PlRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", PlRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         if Objects_number == 10 then
            display1_text5a = PlRS_object_name .. text_Objectsdown[10]
            textwidth = normalfont:getwidth(display1_text5a)
            if textwidth > (boxW1 - 5) then
               boxW1 = textwidth + 5
            end
         else
            display1_text5a = text_Objectsdown[Objects_number]
         end
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = ""
         display2_text4b = ""
         display2_text5a = ""
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      end
      if V2>0 then
         display1_text1a = PlRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", PlRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", PlRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         if Objects_number == 10 then
            display1_text5a = PlRS_object_name .. text_Objectsup[10]
            textwidth = normalfont:getwidth(display1_text5a)
            if textwidth > (boxW1 - 5) then
               boxW1 = textwidth + 5
            end
         else
            display1_text5a = text_Objectsup[Objects_number]
         end
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = ""
         display2_text4b = ""
         display2_text5a = ""
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      end
   else
      if M8==0 then
         tdb2=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb2_local=tdb2+local_offset
         local_dt=celestia:tdbtoutc(tdb2_local)
         year_local_2nd=local_dt.year
         month_local_2nd=local_dt.month
         day_local_2nd=local_dt.day
         HH_local_2nd=local_dt.hour
         MM_local_2nd=local_dt.minute
         display1_text1a = PlRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", PlRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", PlRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         if Objects_number == 10 then
            display1_text5a = PlRS_object_name .. text_noObjectsrise[10]
            textwidth = normalfont:getwidth(display1_text5a)
            if textwidth > (boxW1 - 5) then
               boxW1 = textwidth + 5
            end
         else
            display1_text5a = text_noObjectsrise[Objects_number]
         end
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = text_date
         display2_text4b = day_local_2nd .. monthname[month_local_2nd] .. year_local_2nd
         display2_text5a = text_1st
         display2_text5b = string.format("%02i:%02i ", HH_local_2nd, MM_local_2nd) .. PlRS_local_timezone
         display2_text6a = text_azimuth
         display2_text6b = string.format("%5.2f°", AZ_1st)
      elseif W8==0 then
         tdb1=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb1_local=tdb1+local_offset
         local_dt=celestia:tdbtoutc(tdb1_local)
         year_local_1st=local_dt.year
         month_local_1st=local_dt.month
         day_local_1st=local_dt.day
         HH_local_1st=local_dt.hour
         MM_local_1st=local_dt.minute
         display1_text1a = PlRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", PlRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", PlRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_local_1st .. monthname[month_local_1st] .. year_local_1st
         display1_text5a = text_1st
         display1_text5b = string.format("%02i:%02i ", HH_local_1st, MM_local_1st) .. PlRS_local_timezone
         display1_text6a = text_azimuth
         display1_text6b = string.format("%5.2f°", AZ_1st)
         display2_text4a = text_date
         display2_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         if Objects_number == 10 then
            display2_text5a = PlRS_object_name .. text_noObjectsset[10]
            textwidth = normalfont:getwidth(display2_text5a)
            if textwidth > (boxW1 - 5) then
               boxW1 = textwidth + 5
            end
         else
            display2_text5a = text_noObjectsset[Objects_number]
         end
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      else
         tdb1=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb1_local=tdb1+local_offset
         local_dt=celestia:tdbtoutc(tdb1_local)
         year_local_1st=local_dt.year
         month_local_1st=local_dt.month
         day_local_1st=local_dt.day
         HH_local_1st=local_dt.hour
         MM_local_1st=local_dt.minute
         tdb2=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_2nd, MM_UTC_2nd)
         tdb2_local=tdb2+local_offset
         local_dt=celestia:tdbtoutc(tdb2_local)
         year_local_2nd=local_dt.year
         month_local_2nd=local_dt.month
         day_local_2nd=local_dt.day
         HH_local_2nd=local_dt.hour
         MM_local_2nd=local_dt.minute
         display1_text1a = PlRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", PlRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", PlRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_local_1st .. monthname[month_local_1st] .. year_local_1st
         display1_text5a = text_1st
         display1_text5b = string.format("%02i:%02i ", HH_local_1st, MM_local_1st) .. PlRS_local_timezone
         display1_text6a = text_azimuth
         display1_text6b = string.format("%5.2f°", AZ_1st)
         display2_text4a = text_date
         display2_text4b = day_local_2nd .. monthname[month_local_2nd] .. year_local_2nd
         display2_text5a = text_2nd
         display2_text5b = string.format("%02i:%02i ", HH_local_2nd, MM_local_2nd) .. PlRS_local_timezone
         display2_text6a = text_azimuth
         display2_text6b = string.format("%5.2f°", AZ_2nd)
         -- v2.2 Test if a 3rd event took place this day
         if event3 then
            tdb3=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_3rd, MM_UTC_3rd)
            tdb3_local=tdb3+local_offset
            local_dt=celestia:tdbtoutc(tdb3_local)
            year_local_3rd=local_dt.year
            month_local_3rd=local_dt.month
            day_local_3rd=local_dt.day
            HH_local_3rd=local_dt.hour
            MM_local_3rd=local_dt.minute
            display3_text4a = text_date
            display3_text4b = day_local_3rd .. monthname[month_local_3rd] .. year_local_3rd
            display3_text5a = text_3rd
            display3_text5b = string.format("%02i:%02i ", HH_local_3rd, MM_local_3rd) .. PlRS_local_timezone
            display3_text6a = text_azimuth
            display3_text6b = string.format("%5.2f°", AZ_3rd)
         end
      end
   end
end



----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
ObjectsRiseSetBox = CXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
    :attach(screenBox, sx, sy, 0, 0);

--
-- Box to show the Objects Rise/Set variables
--

ObjectsRiseSetFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("")
    :movetext(-5,4)
    :fillcolor(fill_color)
    :bordercolor(fill_color)
    :movable(true)
    :clickable(false)
    :visible(display_ObjectsRiseSet)
    :attach(screenBox, posX1, sy-posT1-boxH1, sx-boxW1-posX1, posT1)

-- Variable area
ObjectsRiseSetFrame2 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("")
    :movetext(-5,4)
    :movable(false)
    :clickable(true)
    :visible(true)
    :attach(ObjectsRiseSetFrame, boxW1-boxW1F2, 0, 0, 0)

-- Script button
ObjectsRiseSetFrame3 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text(text_script)
    :textpos("center")
    :fillcolor(fill_color)
    :movetext(0, 8)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(ObjectsRiseSetFrame, boxW1/2-boxW1F3/2, 2, boxW1/2-boxW1F3/2, boxH1-lspace-2)

-- Close button
ObjectsRiseSetFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("x")
    :textpos("center")
    :fillcolor(fill_color)
    :movetext(0, 10)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(ObjectsRiseSetFrame, boxW1-10, boxH1-10, 0, 0)

-- Title area
ObjectsRiseSetFrame5 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("")
    :movetext(-5,4)
    :movable(false)
    :clickable(true)
    :visible(true)
    :attach(ObjectsRiseSetFrame, 0, boxH1-lspace-2, 20, 0)
 
ObjectsRiseSetFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*2+2)
   PlRS_obs=celestia:getobserver()
   if Objects_number == 10 then
      actual_selection = celestia:getselection()
      -- Test if actual selection has changed, to adjust the text of the Object in the box.
      if actual_selection~=PlRS_object and actual_selection:type() ~= "null"  then
         PlRS_object=actual_selection
         if actual_selection:name() == "Sol" or actual_selection:name() == "Sun" then
            x_Objects(0)
            Objects_number = 0
         elseif actual_selection:name() == "Mercury" then
            x_Objects(1)
            Objects_number = 1
         elseif actual_selection:name() == "Venus" then
            x_Objects(2)
            Objects_number = 2
         elseif actual_selection:name() == "Moon" or actual_selection:name() == "Earth" then
            x_Objects(3)
            Objects_number = 3
         elseif actual_selection:name() == "Mars" then
            x_Objects(4)
            Objects_number = 4
         elseif actual_selection:name() == "Jupiter" then
            x_Objects(5)
            Objects_number = 5
         elseif actual_selection:name() == "saturn" then
            x_Objects(6)
            Objects_number = 6
         elseif actual_selection:name() == "Uranus" then
            x_Objects(7)
            Objects_number = 7
         elseif actual_selection:name() == "Neptune" then
            x_Objects(8)
            Objects_number = 8
         elseif actual_selection:name() == "Pluto" then
            x_Objects(9)
            Objects_number = 9
         elseif actual_selection:type() == "planet" or actual_selection:type() == "moon" or actual_selection:type() == "asteroid" or actual_selection:type() == "comet" or actual_selection:type() == "star"  or actual_selection:type() == "dwarfplanet" or actual_selection:type() == "minormoon" or actual_selection:type() == "galaxy" or actual_selection:type() == "nebula" or actual_selection:type() == "opencluster" or actual_selection:type() == "globular" then
            PlRS_object_name = PlRS_object:localname()
            if PlRS_object_name == "?" then
               PlRS_object_name = PlRS_object:name()
            end
            x_Objects(10)
            Objects_number = 10
         else
            x_Objects(0)
            Objects_number = 0
         end
      end
   end
   if ObjectsRiseSet_location() then
      -- Test possibility if script is running (by observer position) with different ambient light level.
      PlRS_obs_pos = PlRS_obs:getposition()
      PlRS_earth_pos = PlRS_earth:getposition()
      PlRS_obs_earth = PlRS_obs_pos - PlRS_earth_pos
      PlRS_distance = PlRS_obs_earth:length() * uly_to_km
      if PlRS_distance <= (PlRS_earth:radius() + 10) or (PlRS_distance >= 4.04 * PlRS_earth:radius() and PlRS_distance <= 4.06 * PlRS_earth:radius()) then
         PlRS_script = true
      else
         PlRS_script = false
      end
      -- Valid static location or dynamic calculation determined by Celestia.
      if not PlRS_script and PlRS_ObjectsRiseSet_Showlocation and (Old_PlRS_long_earth ~= PlRS_long_earth or Old_PlRS_lat_earth ~= PlRS_lat_earth or PlRS_static) then
         -- Display the location for which the Objectsrise and Objectsset will be calculated.
         Old_PlRS_long_earth = PlRS_long_earth
         Old_PlRS_lat_earth = PlRS_lat_earth
         PlRS_obs:gotolonglat(PlRS_earth, math.rad(PlRS_long_earth), math.rad(PlRS_lat_earth), 4*PlRS_earth:radius(), 0.0)
      end
      PlRS_obs:synchronous(PlRS_earth)
      -- Reset ambient light level if necessary, except when script is running.
      if math.abs(celestia:getambient() - PlRS_ambient) > 0.01 and not PlRS_script then
         PlRS_orig_ambient=celestia:getambient()
         celestia:setambient(PlRS_ambient)
      end
      -- Reset markers if turned off and mark location on Earth.
      local PlRS_renderflags = celestia:getrenderflags()
      if not PlRS_renderflags.markers then
         celestia:setrenderflags{markers=true}
      end
      PlRS_earth:unmark()
      if PlRS_ObjectsRiseSet_Showlocation then
         PlRS_earth:mark("red", "diamond", 10, 1, PlRS_location_name, false)
      else
         PlRS_earth:mark("yellow", "plus", 10, 1, "", false)
      end
      -- Calculate Objectsrise and Objectsset times for this date, including their Azimuth and show Title line items in the box.
      ObjectsRiseSet_calculate()
      textlayout:println(display1_text1a)
      textlayout:println(display1_text2a)
      textlayout:println(display1_text3a)
      textlayout:println(" ")
      textlayout:println(display1_text4a)
      textlayout:println(display1_text5a)
      textlayout:println(display1_text6a)
      textlayout:println(" ")
      textlayout:println(display2_text4a)
      textlayout:println(display2_text5a)
      textlayout:println(display2_text6a)
      if event3 then
         textlayout:println(" ")
         textlayout:println(display3_text4a)
         textlayout:println(display3_text5a)
         textlayout:println(display3_text6a)
      end
   else
      -- Invalid static location entered in the configuration file.
      textlayout:println(text_invalid_location)
   end  
   -- Check changed screen dimensions and reposition the box if necessary.
   oldsx, oldsy = sx, sy
   sx, sy = celestia:getscreendimension()
   -- v2.2 added check on box height, because it can change too now
   if sx ~= oldsx or sy ~= oldsy or boxW1 ~= prev_boxW1 or boxH1 ~= prev_boxH1 then
      -- 2 lines to force the box to stay in the celestia window
      if posT1 >= sy - boxH1 - 2 then posT1 = sy - boxH1 - 2 end
      if posX1 >= sx - boxW1 - 2 then posX1 = sx - boxW1 - 2 end
      ObjectsRiseSetFrame:attach(screenBox, posX1, sy-posT1-boxH1, sx-boxW1-posX1, posT1)
      prev_boxW1 = boxW1
      prev_boxH1 = boxH1
   end
   -- recording the actual position
   posX1 = this.la
   posT1 = this.ta
end

-- Show Calculated line items, all aligned in a separate box, attached to the primary box.
ObjectsRiseSetFrame2.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*2+2)
   textlayout:println(display1_text1b)
   textlayout:println(display1_text2b)
   textlayout:println(display1_text3b)
   textlayout:println(" ")
   textlayout:println(display1_text4b)
   textlayout:println(display1_text5b)
   textlayout:println(display1_text6b)
   textlayout:println(" ")
   textlayout:println(display2_text4b)
   textlayout:println(display2_text5b)
   textlayout:println(display2_text6b)
   if event3 then
      textlayout:println(" ")
      textlayout:println(display3_text4b)
      textlayout:println(display3_text5b)
      textlayout:println(display3_text6b)
   end
   ObjectsRiseSetFrame2:attach(ObjectsRiseSetFrame, boxW1-boxW1F2, 0, 0, 0)
end

-- Script button
ObjectsRiseSetFrame3.Customdraw = function(this)
    ObjectsRiseSetFrame3:attach(ObjectsRiseSetFrame, boxW1/2-boxW1F3/2, 2, boxW1/2-boxW1F3/2, boxH1-lspace-2)
end

-- Close button
ObjectsRiseSetFrame4.Customdraw = function(this)
    ObjectsRiseSetFrame4:attach(ObjectsRiseSetFrame, boxW1-10, boxH1-10, 0, 0)
end

-- Title area
ObjectsRiseSetFrame5.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*1+2)
   if Objects_number == 10 then
      textlayout:println(PlRS_object_name .. text_Objectstitle[10])
   else
      textlayout:println(text_Objectstitle[Objects_number])
   end
   ObjectsRiseSetFrame5:attach(ObjectsRiseSetFrame, 0, boxH1-lspace-2, 20, 0)
end

--
-- Box to show the Objects that can be selected.
--

ObjectsFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text(text_object)
    :movetext(-5,4)
    :fillcolor(fill_color)
    :bordercolor(fill_color)
    :movable(true)
    :clickable(false)
    :visible(display_ObjectsRiseSet)
    :attach(screenBox, posX2, syA-posT2-boxH2, sxA-boxW2-posX2, posT2)

-- Close button
ObjectsFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("x")
    :textpos("center")
    :movetext(0, 10)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(true)
    :attach(ObjectsFrame, boxW2-10, boxH2-10, 0, 0)
   
ObjectsFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb+30,this.tb-lspace*2+2)
   textlayout:println("")
   textlayout:println(text_Objectsname[0])
   textlayout:println(text_Objectsname[1])
   textlayout:println(text_Objectsname[2])
   textlayout:println(text_Objectsname[3])
   textlayout:println(text_Objectsname[4])
   textlayout:println(text_Objectsname[5])
   textlayout:println(text_Objectsname[6])
   textlayout:println(text_Objectsname[7])
   textlayout:println(text_Objectsname[8])
   textlayout:println(text_Objectsname[9])
   textlayout:println(text_Objectsname[10])
   -- Check changed screen dimensions and reposition the box if necessary.
   oldsxA, oldsyA = sxA, syA
   sxA, syA = celestia:getscreendimension()
   if sxA ~= oldsxA or syA ~= oldsyA then
      -- 2 lines to force the box to stay in the celestia window
      if posT2 >= sy - boxH2 - 2 then posT2 = sy - boxH2 - 2 end
      if posX2 >= sx - boxW2 - 2 then posX2 = sx - boxW2 - 2 end
      ObjectsFrame:attach(screenBox, posX2, syA-posT2-boxH2, sxA-boxW2-posX2, posT2)
   end
   -- recording the actual position
   posX2 = this.la
   posT2 = this.ta
end

-- Close button
ObjectsFrame4.Customdraw = function(this)
    ObjectsFrame4:attach(ObjectsFrame, boxW2-10, boxH2-10, 0, 0)
end

ObjectsCheck0 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("x")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 0), boxW2-16, lspace*2 + 4)

ObjectsCheck0.Customdraw = function(this)
    ObjectsCheck0:attach(ObjectsFrame, 6, lspace*(number_objects - 0), boxW2-16, lspace*2 + 4)
end

ObjectsCheck0.Action = (function()
        return
            function()
                x_Objects(0)
                Objects_number = 0
            end
        end) ();
        
ObjectsCheck1 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 1), boxW2-16, lspace*3 + 4)

ObjectsCheck1.Customdraw = function(this)
    ObjectsCheck1:attach(ObjectsFrame, 6, lspace*(number_objects - 1), boxW2-16, lspace*3 + 4)
end

ObjectsCheck1.Action = (function()
        return
            function()
                x_Objects(1)
                Objects_number = 1
            end
        end) ();
        
ObjectsCheck2 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 2), boxW2-16, lspace*4 + 4)

ObjectsCheck2.Customdraw = function(this)
    ObjectsCheck2:attach(ObjectsFrame, 6, lspace*(number_objects - 2), boxW2-16, lspace*4 + 4)
end

ObjectsCheck2.Action = (function()
        return
            function()
                x_Objects(2)
                Objects_number = 2
            end
        end) ();
        
ObjectsCheck3 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 3), boxW2-16, lspace*5 + 4)

ObjectsCheck3.Customdraw = function(this)
    ObjectsCheck3:attach(ObjectsFrame, 6, lspace*(number_objects - 3), boxW2-16, lspace*5 + 4)
end

ObjectsCheck3.Action = (function()
        return
            function()
                x_Objects(3)
                Objects_number = 3
            end
        end) ();
        
ObjectsCheck4 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 4), boxW2-16, lspace*6 + 4)

ObjectsCheck4.Customdraw = function(this)
    ObjectsCheck4:attach(ObjectsFrame, 6, lspace*(number_objects - 4), boxW2-16, lspace*6 + 4)
end

ObjectsCheck4.Action = (function()
        return
            function()
                x_Objects(4)
                Objects_number = 4
            end
        end) ();
        
ObjectsCheck5 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 5), boxW2-16, lspace*7 + 4)

ObjectsCheck5.Customdraw = function(this)
    ObjectsCheck5:attach(ObjectsFrame, 6, lspace*(number_objects - 5), boxW2-16, lspace*7 + 4)
end

ObjectsCheck5.Action = (function()
        return
            function()
                x_Objects(5)
                Objects_number = 5
            end
        end) ();
        
ObjectsCheck6 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 6), boxW2-16, lspace*8 + 4)

ObjectsCheck6.Customdraw = function(this)
    ObjectsCheck6:attach(ObjectsFrame, 6, lspace*(number_objects - 6), boxW2-16, lspace*8 + 4)
end

ObjectsCheck6.Action = (function()
        return
            function()
                x_Objects(6)
                Objects_number = 6
            end
        end) ();
        
ObjectsCheck7 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 7), boxW2-16, lspace*9 + 4)

ObjectsCheck7.Customdraw = function(this)
    ObjectsCheck7:attach(ObjectsFrame, 6, lspace*(number_objects - 7), boxW2-16, lspace*9 + 4)
end

ObjectsCheck7.Action = (function()
        return
            function()
                x_Objects(7)
                Objects_number = 7
           end
        end) ();
        
ObjectsCheck8 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 8), boxW2-16, lspace*10 + 4)

ObjectsCheck8.Customdraw = function(this)
    ObjectsCheck8:attach(ObjectsFrame, 6, lspace*(number_objects - 8), boxW2-16, lspace*10 + 4)
end

ObjectsCheck8.Action = (function()
        return
            function()
                x_Objects(8)
                Objects_number = 8
            end
        end) ();
        
ObjectsCheck9 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 9), boxW2-16, lspace*11 + 4)

ObjectsCheck9.Customdraw = function(this)
    ObjectsCheck9:attach(ObjectsFrame, 6, lspace*(number_objects - 9), boxW2-16, lspace*11 + 4)
end

ObjectsCheck9.Action = (function()
        return
            function()
                x_Objects(9)
                Objects_number = 9
            end
        end) ();
        
ObjectsCheck10 = CXBox:new()
        :init(0, 0, 0, 0)
        :bordercolor(text_color)
        :textfont(smallfont)
        :textcolor(text_color)
        :textpos("center")
        :movetext(0, 10)
        :text("")
        :movable(false)
        :active(true)
        :visible(true)
        :attach(ObjectsFrame, 6, lspace*(number_objects - 10), boxW2-16, lspace*12 + 4)

ObjectsCheck10.Customdraw = function(this)
    ObjectsCheck10:attach(ObjectsFrame, 6, lspace*(number_objects - 10), boxW2-16, lspace*12 + 4)
end

ObjectsCheck10.Action = (function()
        return
            function()
               actual_selection = celestia:getselection()
               if actual_selection:name() == "Sol" or actual_selection:name() == "Sun" then
                  x_Objects(0)
                  Objects_number = 0
               elseif actual_selection:name() == "Mercury" then
                  x_Objects(1)
                  Objects_number = 1
               elseif actual_selection:name() == "Venus" then
                  x_Objects(2)
                  Objects_number = 2
               elseif actual_selection:name() == "Moon" or actual_selection:name() == "Earth" then
                  x_Objects(3)
                  Objects_number = 3
               elseif actual_selection:name() == "Mars" then
                  x_Objects(4)
                  Objects_number = 4
               elseif actual_selection:name() == "Jupiter" then
                  x_Objects(5)
                  Objects_number = 5
               elseif actual_selection:name() == "saturn" then
                  x_Objects(6)
                  Objects_number = 6
               elseif actual_selection:name() == "Uranus" then
                  x_Objects(7)
                  Objects_number = 7
               elseif actual_selection:name() == "Neptune" then
                  x_Objects(8)
                  Objects_number = 8
               elseif actual_selection:name() == "Pluto" then
                  x_Objects(9)
                  Objects_number = 9
               elseif actual_selection:type() == "planet" or actual_selection:type() == "moon" or actual_selection:type() == "asteroid" or actual_selection:type() == "comet" or actual_selection:type() == "star"  or actual_selection:type() == "dwarfplanet" or actual_selection:type() == "minormoon" or actual_selection:type() == "galaxy" or actual_selection:type() == "nebula" or actual_selection:type() == "opencluster" or actual_selection:type() == "globular" then
                  PlRS_object=actual_selection
                  PlRS_object_name = PlRS_object:localname()
                  if PlRS_object_name == "?" then
                     PlRS_object_name = PlRS_object:name()
                  end
                  x_Objects(10)
                  Objects_number = 10
               else
                  x_Objects(0)
                  Objects_number = 0
               end
            end
        end) ();

--
-- Box in the Toolkit of Lua_Edu_Tools to select/deselect the application (instead of [key shortcut]).
--

if lua_edu_tools then
   ObjectsRiseSetSwitch = CXBox:new()
       :init(0, 0, 0, 0)
       :bordercolor(cbubordoff)
       :textfont(normalfont)
       :textcolor(cbutextoff)
       :textpos("center")
       :movetext(0, 8)
       :text(text_toolkit)
       :movable(false)
       :active(true)
       :attach(ObjectsRiseSetBox, 8, 4, 8, 3)

   ObjectsRiseSetSwitch.Action = (function()
        return
            function()
                display_ObjectsRiseSet = not display_ObjectsRiseSet;
                if display_ObjectsRiseSet then
                   celestia:print("ObjectsRiseSet plug-in enabled", 2, -1, -1, 2, 4)
                   ObjectsRiseSetSwitch.Bordercolor=cbubordon
                   ObjectsRiseSetSwitch.Fillcolor = {cbubordon[1]*2/3, cbubordon[2]*2/3, cbubordon[3]*2/3, cbubordon[4]/2}
                   PlRS_orig_renderflags = celestia:getrenderflags()
                   PlRS_orig_ambient=celestia:getambient()
                   PlRS_obs = celestia:getobserver()
                   celestia:setambient(PlRS_ambient)
                   PlRS_earth:unmark()
                   celestia:setrenderflags{markers=true}
                   LookatEarth = true
                   actual_selection = celestia:getselection()
                   if actual_selection:name() == "Earth" then
                      LookatEarth = false
                   elseif actual_selection:type() == "location" then
                      parent_object = actual_selection:getinfo().parent
                      if parent_object:name() == "Earth" then
                         LookatEarth = false
                      end
                   elseif PlRS_obs:getposition():distanceto(PlRS_earth:getposition()) < 200000 then
                      LookatEarth = false
                   end
                   if not PlRS_ObjectsRiseSet_Showlocation and LookatEarth then
                      PlRS_obs:gotodistance(PlRS_earth, 4*PlRS_earth:radius(), 0.0)
                      PlRS_obs:synchronous(PlRS_earth)
                   end
                   if PlRS_static_date then
                      celestia:settime(PlRS_tdb_juliandate)
                   end
                   ObjectsRiseSetFrame.Visible = true
                   ObjectsFrame.Visible = true
                   ObjectsRiseSetFrame:orderfront() 
                else
                   celestia:print("ObjectsRiseSet plug-in disabled", 2, -1, -1, 2, 4)
                   ObjectsRiseSetSwitch.Bordercolor=cbubordoff
                   ObjectsRiseSetSwitch.Fillcolor = nil
                   PlRS_earth:unmark()
                   celestia:setrenderflags{markers=PlRS_orig_renderflags.markers}
                   celestia:setambient(PlRS_orig_ambient)
                   ObjectsRiseSetFrame.Visible = false
                   ObjectsFrame.Visible = false
                end
            end
        end) ();
else
   keymap[shortcut] = toggleObjectsRiseSetDisplay
end

-- Script button
ObjectsRiseSetFrame3.Action = (function()
     return
         function()
             script_ObjectsRiseSet = not script_ObjectsRiseSet
             if script_ObjectsRiseSet then
                if Objects_number == 0 then
                   celestia:runscript("../../scripts/SunriseSunset_22.celx")
                elseif Objects_number == 1 then
                   celestia:runscript("../../scripts/MercuryriseMercuryset_22.celx")
                elseif Objects_number == 2 then
                   celestia:runscript("../../scripts/VenusriseVenusset_22.celx")
                elseif Objects_number == 3 then
                   celestia:runscript("../../scripts/MoonriseMoonset_22.celx")
                elseif Objects_number == 4 then
                   celestia:runscript("../../scripts/MarsriseMarsset_22.celx")
                elseif Objects_number == 5 then
                   celestia:runscript("../../scripts/JupiterriseJupiterset_22.celx")
                elseif Objects_number == 6 then
                   celestia:runscript("../../scripts/SaturnriseSaturnset_22.celx")
                elseif Objects_number == 7 then
                   celestia:runscript("../../scripts/UranusriseUranusset_22.celx")
                elseif Objects_number == 8 then
                   celestia:runscript("../../scripts/NeptuneriseNeptuneset_22.celx")
                elseif Objects_number == 9 then
                   celestia:runscript("../../scripts/PlutorisePlutoset_22.celx")
                elseif Objects_number == 10 then
                   celestia:runscript("../../scripts/ObjectriseObjectset_22.celx")
                end
             end
             script_ObjectsRiseSet = not script_ObjectsRiseSet
         end
     end) ();

-- Close button
ObjectsRiseSetFrame4.Action = (function()
     return
         function()
             if lua_edu_tools then
                ObjectsRiseSetSwitch.Bordercolor=cbubordoff
                ObjectsRiseSetSwitch.Fillcolor = nil
             end
             display_ObjectsRiseSet = not display_ObjectsRiseSet;
             PlRS_earth:unmark()
             celestia:setrenderflags{markers=PlRS_orig_renderflags.markers}
             celestia:setambient(PlRS_orig_ambient)
             ObjectsRiseSetFrame.Visible = false
             ObjectsFrame.Visible = false
             celestia:print("ObjectsRiseSet plug-in disabled", 2, -1, -1, 2, 4)
         end
     end) ();

-- Close button
ObjectsFrame4.Action = (function()
     return
         function()
             if lua_edu_tools then
                ObjectsRiseSetSwitch.Bordercolor=cbubordoff
                ObjectsRiseSetSwitch.Fillcolor = nil
             end
             display_ObjectsRiseSet = not display_ObjectsRiseSet;
             PlRS_earth:unmark()
             celestia:setrenderflags{markers=PlRS_orig_renderflags.markers}
             celestia:setambient(PlRS_orig_ambient)
             ObjectsRiseSetFrame.Visible = false
             ObjectsFrame.Visible = false
             celestia:print("ObjectsRiseSet plug-in disabled", 2, -1, -1, 2, 4)
         end
     end) ();

celestia:log("-- ObjectsRiseSet plug-in loaded --")