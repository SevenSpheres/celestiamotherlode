-------------------------------------------------------------
-- Configuration file for ObjectsRiseSet Plug-in addon.
-- Change the values to customize the tool.
-- If an item is not defined, a default value will be used.
-------------------------------------------------------------

-------------------------------------------------------------
-- Launching key with lua_plugins.
-- If not defined, the default is "shift+1".
-- No effect in lua_edu_tools.
-------------------------------------------------------------
ObjectsRiseSet_shortcut="!"

-------------------------------------------------------------
-- Indicate if the ObjectsRiseSet tool is visible at startup.
-- Comment / Uncomment one of the following two lines:
-------------------------------------------------------------
--ObjectsRiseSet_visible = true
ObjectsRiseSet_visible = false

-------------------------------------------------------------
-- ObjectsRiseSet display color (red, green, blue, transparency) and dsiplay width (pixels)
-------------------------------------------------------------
ObjectsRiseSet_color = {0.9, 0.4, 0.2, 0.9}
ObjectsRiseSet_fillcolor = {0.2, 0.1, 0.1, 0.3}

-------------------------------------------------------------
-- Determine if you want Celestia to display the location
-- for which the Objects rise and Objects set will be calculated.
-- Comment / Uncomment one of the following two lines:
-------------------------------------------------------------
--ObjectsRiseSet_Showlocation = true
ObjectsRiseSet_Showlocation = false

-------------------------------------------------------------
-- Determine the brightness level of ambient light,
-- when the plug-in is activated in Celestia.
-------------------------------------------------------------
ObjectsRiseSet_Ambient = 0.05

-------------------------------------------------------------
-- If you want to use a static location to be used for the Objects rise/set calculation:
-- 1) Uncomment the upcoming 3 lines for PlRPlS_long_earth, PlRPlS_lat_earth and PlRPlS_location_name,
--    (delete the -- characters on position 1 and 2 of each line).
-- 2) Set the Longitude and Latitude coordinates of that location on Earth (in degrees)
--    * Northern latitudes positive, Southern latitudes negative, -90  <= Latitude  <= 90,
--    * Eastern longitudes positive, Western longitudes negative, -360 <  Longitude < 360.
-- 3) Fill in your own location name.
-- If not supplied (the upcoming 3 lines stay commented), the location will be determined dynamically, based on:
--    A) The actual selection (which must be a location on Earth).
--       Only available for Main Solar System bodies (Sun, Moon, Pluto and the Planets).
--    B) The actual Longitude, Latitude coordinated of the observer
-------------------------------------------------------------
--PlRPlS_long_earth    = 6.016                 -- Longitude in degrees
--PlRPlS_lat_earth     = 52.213                -- Latitude in degrees
--PlRPlS_location_name = "Apeldoorn (NL)"      -- Fill in your own Location name between the 2 double quotes

-------------------------------------------------------------
-- If you want to use a static date to be used for the Object rise/set calculation:
-- 1) Uncomment the upcoming 3 lines for PlRPlS_date_Year, PlRPlS_date_Month and PlRPlS_date_Day,
--    (delete the -- characters on position 1 and 2 of each line).
-- 2) Set the Year, Month and Day in numerical format
-- If not supplied (the upcoming 3 lines stay commented), the date will be determined dynamically.
-------------------------------------------------------------
--PlRPlS_date_Year     = 2013                  -- Year
--PlRPlS_date_Month    = 10                    -- Month
--PlRPlS_date_Day      = 6                     -- Day

-------------------------------------------------------------
-- Local time zone, used to display local Object rise/set times.
-- Must be one of the time zone abbreviations in PlRS_local_timezone_table below,
-- otherwise "UTC" will be used. ==> Mind UPPERCASE/lowercase !!!
-------------------------------------------------------------
PlRS_local_timezone="UTC"

PlRS_local_timezone_table={}
PlRS_offset={}
--============================================================================================================
PlRS_local_timezone_table[1]  ="UTC"    PlRS_offset.UTC    =0         -- Coordinated Universal Time 0
PlRS_local_timezone_table[2]  ="ACDT"   PlRS_offset.ACDT   =0.4375    -- Australian Central Daylight Time (Australia) +10.5
PlRS_local_timezone_table[3]  ="ACST"   PlRS_offset.ACST   =0.39584   -- Australian Central Standard Time (Australia) +9.5
PlRS_local_timezone_table[4]  ="ACT"    PlRS_offset.ACT    =0.33333   -- ASEAN Common Time (Asia) +8
PlRS_local_timezone_table[5]  ="ADT"    PlRS_offset.ADT    =-0.125    -- Atlantic Daylight Time (North America & Atlantic) -3
PlRS_local_timezone_table[6]  ="AST_4"  PlRS_offset.AST_4  =-0.16667  -- Atlantic Standard Time (North America & Atlantic) -4
PlRS_local_timezone_table[7]  ="AEDT"   PlRS_offset.AEDT   =0.45833   -- Australian Eastern Daylight Time (Australia) +11
PlRS_local_timezone_table[8]  ="AEST"   PlRS_offset.AEST   =0.41667   -- Australian Eastern Standard Time (Australia) +10
PlRS_local_timezone_table[9]  ="AFT"    PlRS_offset.AFT    =0.1875    -- Afghanistan Time (Asia) +4.5
PlRS_local_timezone_table[10] ="AKDT"   PlRS_offset.AKDT   =-0.33333  -- Alaska Daylight Time (North America) -8
PlRS_local_timezone_table[11] ="AKST"   PlRS_offset.AKST   =-0.375    -- Alaska Standard Time (North America) -9
PlRS_local_timezone_table[12] ="ALMT"   PlRS_offset.ALMT   =0.25      -- Alma-Ata Time (Asia) +6
PlRS_local_timezone_table[13] ="AMST_1" PlRS_offset.AMST_1 =0.20833   -- Armenia Summer Time (Asia) +5
PlRS_local_timezone_table[14] ="AMT_1"  PlRS_offset.AMT_1  =0.16667   -- Armenia Time (Asia) +4
PlRS_local_timezone_table[15] ="AMST_2" PlRS_offset.AMST_2 =-0.125    -- Amazon Summer Time (South America) -3
PlRS_local_timezone_table[16] ="AMT_2"  PlRS_offset.AMT_2  =-0.16667  -- Amazon Time (South America) -4
PlRS_local_timezone_table[17] ="ANAST"  PlRS_offset.ANAST  =0.5       -- Anadyr Summer Time (Asia) +12
PlRS_local_timezone_table[18] ="ANAT"   PlRS_offset.ANAT   =0.5       -- Anadyr Time (Asia) +12
PlRS_local_timezone_table[19] ="AQTT"   PlRS_offset.AQTT   =0.20833   -- Aqtobe Time (Asia) +5
PlRS_local_timezone_table[20] ="ART"    PlRS_offset.ART    =-0.125    -- Argentina Time (South America) -3
PlRS_local_timezone_table[21] ="AST_1"  PlRS_offset.AST_1  =0.125     -- Arab Standard Time [Kuwait, Riyadh] (Asia) +3
PlRS_local_timezone_table[22] ="AST_2"  PlRS_offset.AST_2  =0.16667   -- Arabian Standard Time [Abu Dhabi, Muscat] (Asia) +4
PlRS_local_timezone_table[23] ="AST_3"  PlRS_offset.AST_3  =0.125     -- Arabic Standard Time [Baghdad] (Asia) +3
PlRS_local_timezone_table[24] ="AWDT"   PlRS_offset.AWDT   =0.375     -- Australian Western Daylight Time (Australia) +9
PlRS_local_timezone_table[25] ="AWST"   PlRS_offset.AWST   =0.33333   -- Australian Western Standard Time (Australia) +8
PlRS_local_timezone_table[26] ="AZOST"  PlRS_offset.AZOST  =0         -- Azores Summer Time (Atlantic) 0
PlRS_local_timezone_table[27] ="AZOT"   PlRS_offset.AZOT   =-0.04167  -- Azores Time (Atlantic) -1
PlRS_local_timezone_table[28] ="AZST"   PlRS_offset.AZST   =0.20833   -- Azerbaijan Summer Time (Asia) +5
PlRS_local_timezone_table[29] ="AZT"    PlRS_offset.AZT    =0.16667   -- Azerbaijan Time (Asia) +4
PlRS_local_timezone_table[30] ="BDT"    PlRS_offset.BDT    =0.33333   -- Brunei Darussalam Time (Asia) +8
PlRS_local_timezone_table[31] ="BNT"    PlRS_offset.BNT    =0.33333   -- Brunei Darussalam Time (Asia) +8
PlRS_local_timezone_table[32] ="BIOT"   PlRS_offset.BIOT   =0.25      -- British Indian Ocean Time (Indian Ocean) +6
PlRS_local_timezone_table[33] ="BIT"    PlRS_offset.BIT    =-0.5      -- Baker Island Time (Pacific Ocean) -12
PlRS_local_timezone_table[34] ="BOT"    PlRS_offset.BOT    =-0.16667  -- Bolivia Time (South America) -4
PlRS_local_timezone_table[35] ="BRST"   PlRS_offset.BRST   =-0.08333  -- Brasilia Summer Time (South America) -2
PlRS_local_timezone_table[36] ="BRT"    PlRS_offset.BRT    =-0.125    -- Brasilia Time (South America) -3
PlRS_local_timezone_table[37] ="BST_1"  PlRS_offset.BST_1  =0.25      -- Bangladesh Standard Time (Asia) +6
PlRS_local_timezone_table[38] ="BST_2"  PlRS_offset.BST_2  =0.04167   -- British Summer Time [British Standard Time from Feb 1968 to Oct 1971] (Europe) +1
PlRS_local_timezone_table[39] ="BTT"    PlRS_offset.BTT    =0.25      -- Bhutan Time (Asia) +6
PlRS_local_timezone_table[40] ="CAST"   PlRS_offset.CAST   =0.33333   -- Casey Time (Antarctica) +8
PlRS_local_timezone_table[41] ="CAT"    PlRS_offset.CAT    =0.08333   -- Central Africa Time (Africa) +2
PlRS_local_timezone_table[42] ="CCT"    PlRS_offset.CCT    =0.27084   -- Cocos Islands Time (Indian Ocean) +6.5
PlRS_local_timezone_table[43] ="CDT_1"  PlRS_offset.CDT_1  =0.4375    -- Central Daylight Time (Australia) +10.5
PlRS_local_timezone_table[44] ="CST_1"  PlRS_offset.CST_1  =0.39584   -- Central Standard Time (Australia) +9.5
PlRS_local_timezone_table[45] ="CDT_2"  PlRS_offset.CDT_2  =-0.16667  -- Cuba Daylight Time (Caribbean) -4
PlRS_local_timezone_table[46] ="CST_2"  PlRS_offset.CST_2  =-0.20833  -- Cuba Standard Time (Caribbean) -5
PlRS_local_timezone_table[47] ="CDT_3"  PlRS_offset.CDT_3  =-0.20833  -- Central Daylight Time (North America) -5
PlRS_local_timezone_table[48] ="CST_3"  PlRS_offset.CST_3  =-0.25     -- Central Standard Time (North America) -6
PlRS_local_timezone_table[49] ="CEDT"   PlRS_offset.CEDT   =0.08333   -- Central European Daylight Time (Europe) +2
PlRS_local_timezone_table[50] ="CEST"   PlRS_offset.CEST   =0.08333   -- Central European Summer Time (Europe) +2
PlRS_local_timezone_table[51] ="CET"    PlRS_offset.CET    =0.04167   -- Central European Time (Europe) +1
PlRS_local_timezone_table[52] ="CHADT"  PlRS_offset.CHADT  =0.57293   -- Chatham Island Daylight Time (Pacific) +13.75
PlRS_local_timezone_table[53] ="CHAST"  PlRS_offset.CHAST  =0.53125   -- Chatham Island Standard Time (Pacific) +12.75
PlRS_local_timezone_table[54] ="CIST"   PlRS_offset.CIST   =-0.33333  -- Clipperton Island Standard Time (Central America) -8
PlRS_local_timezone_table[55] ="CKT"    PlRS_offset.CKT    =-0.41667  -- Cook Island Time (Pacific) -10
PlRS_local_timezone_table[56] ="CLST"   PlRS_offset.CLST   =-0.125    -- Chile Summer Time (South America) -3
PlRS_local_timezone_table[57] ="CLT"    PlRS_offset.CLT    =-0.16667  -- Chile Standard Time (South America) -4
PlRS_local_timezone_table[58] ="COST"   PlRS_offset.COST   =-0.16667  -- Colombia Summer Time (South America) -4
PlRS_local_timezone_table[59] ="COT"    PlRS_offset.COT    =-0.20833  -- Colombia Time (South America) -5
PlRS_local_timezone_table[60] ="CST_4"  PlRS_offset.CST_4  =-0.25     -- Central Standard Time (Central America) -6
PlRS_local_timezone_table[61] ="CST_5"  PlRS_offset.CST_5  =0.33333   -- China Standard Time (Asia) +8
PlRS_local_timezone_table[62] ="CT"     PlRS_offset.CT     =0.33333   -- China Time (Asia) +8
PlRS_local_timezone_table[63] ="CVT"    PlRS_offset.CVT    =-0.04167  -- Cape Verde Time  (Africa) -1
PlRS_local_timezone_table[64] ="CXT"    PlRS_offset.CXT    =0.29167   -- Christmas Island Time (Australia) +7
PlRS_local_timezone_table[65] ="ChST"   PlRS_offset.ChST   =0.41667   -- Chamorro Standard Time (Pacific) +10
PlRS_local_timezone_table[66] ="DAVT"   PlRS_offset.DAVT   =0.29167   -- Davis Time (Antarctica) +7
PlRS_local_timezone_table[67] ="DFT"    PlRS_offset.DFT    =0.04167   -- AIX specific equivalent of Central European Time +1
PlRS_local_timezone_table[68] ="EASST"  PlRS_offset.EASST  =-0.20833  -- Easter Island Summer Time (Pacific) -5
PlRS_local_timezone_table[69] ="EAST"   PlRS_offset.EAST   =-0.25     -- Easter Island Standard Time (Pacific) -6
PlRS_local_timezone_table[70] ="EAT"    PlRS_offset.EAT    =0.125     -- East Africa Time (Africa) +3
PlRS_local_timezone_table[71] ="ECT_1"  PlRS_offset.ECT_1  =-0.16667  -- Eastern Caribbean Time (does not recognise DST) -4
PlRS_local_timezone_table[72] ="ECT_2"  PlRS_offset.ECT_2  =-0.20833  -- Ecuador Time (South America) -5
PlRS_local_timezone_table[73] ="EDT_1"  PlRS_offset.EDT_1  =-0.16667  -- Eastern Daylight Time (North America & Caribbean) -4
PlRS_local_timezone_table[74] ="EST_1"  PlRS_offset.EST_1  =-0.20833  -- Eastern Standard Time (North America & Caribbean & Central America) -5
PlRS_local_timezone_table[75] ="EDT_2"  PlRS_offset.EDT_2  =0.45833   -- Eastern Daylight Time (Australia & Pacific) +11
PlRS_local_timezone_table[76] ="EST_2"  PlRS_offset.EST_2  =0.41667   -- Eastern Standard Time (Australia) +10
PlRS_local_timezone_table[77] ="EEDT"   PlRS_offset.EEDT   =0.125     -- Eastern European Daylight Time (Europe & Asia & Africa) +3
PlRS_local_timezone_table[78] ="EEST"   PlRS_offset.EEST   =0.125     -- Eastern European Summer Time (Europe & Asia & Africa) +3
PlRS_local_timezone_table[79] ="EET"    PlRS_offset.EET    =0.08333   -- Eastern European Time (Europe & Asia & Africa) +2
PlRS_local_timezone_table[80] ="EGST"   PlRS_offset.EGST   =0         -- Eastern Greenland Summer Time (North America) 0
PlRS_local_timezone_table[81] ="EGT"    PlRS_offset.EGT    =-0.04167  -- Eastern Greenland Time (North America) -1
PlRS_local_timezone_table[82] ="ET"     PlRS_offset.ET     =-0.20833  -- Tiempo Del Este (North America & Caribbean & Central America) -5
PlRS_local_timezone_table[83] ="FJST"   PlRS_offset.FJST   =0.54168   -- Fiji Summer Time (Pacific) +13
PlRS_local_timezone_table[84] ="FJT"    PlRS_offset.FJT    =0.5       -- Fiji Time (Pacific) +12
PlRS_local_timezone_table[85] ="FKST"   PlRS_offset.FKST   =-0.125    -- Falkland Islands Summer Time (South America) -3
PlRS_local_timezone_table[86] ="FKT"    PlRS_offset.FKT    =-0.16667  -- Falkland Islands Time (South America) -4
PlRS_local_timezone_table[87] ="FNT"    PlRS_offset.FNT    =-0.08333  -- Fernando de Noronha Time (South America) -2
PlRS_local_timezone_table[88] ="GALT"   PlRS_offset.GALT   =-0.25     -- Galapagos Time (Pacific) -6
PlRS_local_timezone_table[89] ="GAMT"   PlRS_offset.GAMT   =-0.375    -- Gambier Time (Pacific) -9
PlRS_local_timezone_table[90] ="GET"    PlRS_offset.GET    =0.16667   -- Georgia Standard Time (Asia) +4
PlRS_local_timezone_table[91] ="GFT"    PlRS_offset.GFT    =-0.125    -- French Guiana Time (South America) -3
PlRS_local_timezone_table[92] ="GILT"   PlRS_offset.GILT   =0.5       -- Gilbert Island Time (Pacific) +12
PlRS_local_timezone_table[93] ="GIT"    PlRS_offset.GIT    =-0.375    -- Gambier Island Time (Pacific) -9
PlRS_local_timezone_table[94] ="GMT"    PlRS_offset.GMT    =0         -- Greenwich Mean Time (Europe & Africa) 0
PlRS_local_timezone_table[95] ="GST_1"  PlRS_offset.GST_1  =-0.08333  -- South Georgia and the South Sandwich Islands (Atlantic) -2
PlRS_local_timezone_table[96] ="GST_2"  PlRS_offset.GST_2  =0.16667   -- Gulf Standard Time (Asia) +4
PlRS_local_timezone_table[97] ="GYT"    PlRS_offset.GYT    =-0.16667  -- Guyana Time (South America) -4
PlRS_local_timezone_table[98] ="HAA"    PlRS_offset.HAA    =-0.125    -- Heure Avanc�e de l'Atlantique (North America & Atlantic) -3
PlRS_local_timezone_table[99] ="HAC"    PlRS_offset.HAC    =-0.20833  -- Heure Avanc�e du Centre (North America) -5
PlRS_local_timezone_table[100]="HADT"   PlRS_offset.HADT   =-0.375    -- Hawaii-Aleutian Daylight Time (North America) -9
PlRS_local_timezone_table[101]="HAST"   PlRS_offset.HAST   =-0.41667  -- Hawaii-Aleutian Standard Time (North America) -10
PlRS_local_timezone_table[102]="HAE"    PlRS_offset.HAE    =-0.16667  -- Heure Avanc�e de l'Est (North America & Caribbean) -4
PlRS_local_timezone_table[103]="HAP"    PlRS_offset.HAP    =-0.29167  -- Heure Avanc�e du Pacifique (North America) -7
PlRS_local_timezone_table[104]="HAR"    PlRS_offset.HAR    =-0.25     -- Heure Avanc�e des Rocheuses (North America) -6
PlRS_local_timezone_table[105]="HAT"    PlRS_offset.HAT    =-0.10418  -- Heure Avanc�e de Terre-Neuve (North America) -2.5
PlRS_local_timezone_table[106]="HAY"    PlRS_offset.HAY    =-0.33333  -- Heure Avanc�e du Yukon (North America) -8
PlRS_local_timezone_table[107]="HKT"    PlRS_offset.HKT    =0.33333   -- Hong Kong Time (Asia) +8
PlRS_local_timezone_table[108]="HLV"    PlRS_offset.HLV    =-0.18750  -- Hora Legal de Venezuela (South America) -4.5
PlRS_local_timezone_table[109]="HMT"    PlRS_offset.HMT    =0.20833   -- Heard and McDonald Islands Time (Antarctic) +5
PlRS_local_timezone_table[110]="HNA"    PlRS_offset.HNA    =-0.16667  -- Heure Normale de l'Atlantique (North America & Caribbean & Atlantic) -4
PlRS_local_timezone_table[111]="HNC"    PlRS_offset.HNC    =-0.25     -- Heure Normale du Centre (North America & Central America) -6
PlRS_local_timezone_table[112]="HNE"    PlRS_offset.HNE    =-0.20833  -- Heure Normale de l'Est (North America & Central America & Caribbean) -5
PlRS_local_timezone_table[113]="HNP"    PlRS_offset.HNP    =-0.33333  -- Heure Normale du Pacifique (North America) -8
PlRS_local_timezone_table[114]="HNR"    PlRS_offset.HNR    =-0.29167  -- Heure Normale des Rocheuses (North America) -7
PlRS_local_timezone_table[115]="HNT"    PlRS_offset.HNT    =-0.14584  -- Heure Normale de Terre-Neuve (North America) -3.5
PlRS_local_timezone_table[116]="HNY"    PlRS_offset.HNY    =-0.375    -- Heure Normale du Yukon (North America) -9
PlRS_local_timezone_table[117]="HOVT"   PlRS_offset.HOVT   =0.29167   -- Hovd Time (Asia) +7
PlRS_local_timezone_table[118]="HST"    PlRS_offset.HST    =-0.41667  -- Hawaii Standard Time (Pacific) -10
PlRS_local_timezone_table[119]="ICT"    PlRS_offset.ICT    =0.29167   -- Indochina Time (Asia) +7
PlRS_local_timezone_table[120]="IDT"    PlRS_offset.IDT    =0.125     -- Israeli Daylight Time (Asia) +3
PlRS_local_timezone_table[121]="IOT"    PlRS_offset.IOT    =0.25      -- Indian Chagos Time (Indian Ocean) +6
PlRS_local_timezone_table[122]="IRDT"   PlRS_offset.IRDT   =0.18750   -- Iran Daylight Time (Asia) +4.5
PlRS_local_timezone_table[123]="IRST"   PlRS_offset.IRST   =0.14584   -- Iran Standard Time (Asia) +3.5
PlRS_local_timezone_table[124]="IRKST"  PlRS_offset.IRKST  =0.375     -- Irkutsk Summer Time (Asia) +9
PlRS_local_timezone_table[125]="IRKT"   PlRS_offset.IRKT   =0.33333   -- Irkutsk Time (Asia) +8
PlRS_local_timezone_table[126]="IST_1"  PlRS_offset.IST_1  =0.22918   -- Indian Standard Time (Asia) +5.5
PlRS_local_timezone_table[127]="IST_2"  PlRS_offset.IST_2  =0.04167   -- Irish Summer Time (Europe) +1
PlRS_local_timezone_table[128]="IST_3"  PlRS_offset.IST_3  =0.08333   -- Israel Standard Time (Asia) +2
PlRS_local_timezone_table[129]="JST"    PlRS_offset.JST    =0.375     -- Japan Standard Time (Asia) +9
PlRS_local_timezone_table[130]="KGT"    PlRS_offset.KGT    =0.25      -- Kyrgyzstan Time (Asia) +6
PlRS_local_timezone_table[131]="KRAST"  PlRS_offset.KRAST  =0.33333   -- Krasnoyarsk Summer Time (Asia) +8
PlRS_local_timezone_table[132]="KRAT"   PlRS_offset.KRAT   =0.29167   -- Krasnoyarsk Time (Asia) +7
PlRS_local_timezone_table[133]="KST"    PlRS_offset.KST    =0.375     -- Korea Standard Time (Asia) +9
PlRS_local_timezone_table[134]="KUYT"   PlRS_offset.KUYT   =0.375     -- Kuybyshev Time (Europe) +4
PlRS_local_timezone_table[135]="LHDT"   PlRS_offset.LHDT   =0.45833   -- Lord Howe Daylight Time (Australia) +11
PlRS_local_timezone_table[136]="LHST"   PlRS_offset.LHST   =0.4375    -- Lord Howe Standard Time (Australia) +10.5
PlRS_local_timezone_table[137]="LINT"   PlRS_offset.LINT   =0.58334   -- Line Islands Time (Pacific) +14
PlRS_local_timezone_table[138]="MAGST"  PlRS_offset.MAGST  =0.5       -- Magadan Summer Time (Asia) +12
PlRS_local_timezone_table[139]="MAGT"   PlRS_offset.MAGT   =0.45833   -- Magadan Time (Asia) +11
PlRS_local_timezone_table[140]="MART"   PlRS_offset.MART   =-0.39584  -- Marquesas Time (Pacific) -9.5
PlRS_local_timezone_table[141]="MAWT"   PlRS_offset.MAWT   =0.20833   -- Mawson Time (Antarctica) +5
PlRS_local_timezone_table[142]="MDT"    PlRS_offset.MDT    =-0.25     -- Mountain Daylight Time (North America) -6
PlRS_local_timezone_table[143]="MST_1"  PlRS_offset.MST_1  =-0.29167  -- Mountain Standard Time (North America) -7
PlRS_local_timezone_table[144]="MHT"    PlRS_offset.MHT    =0.5       -- Marshall Islands Time (Pacific) +12
PlRS_local_timezone_table[145]="MIT"    PlRS_offset.MIT    =-0.39584  -- Marquesas Islands Time (Pacific) -9.5
PlRS_local_timezone_table[146]="MMT"    PlRS_offset.MMT    =0.27084   -- Myanmar Time (Asia) +6.5
PlRS_local_timezone_table[147]="MST_2"  PlRS_offset.MST_2  =0.27084   -- Myanmar Standard Time (Asia) +6.5
PlRS_local_timezone_table[148]="MSD"    PlRS_offset.MSD    =0.16667   -- Moscow Summer Time (Europe) +4
PlRS_local_timezone_table[149]="MSK"    PlRS_offset.MSK    =0.125     -- Moscow Standard Time (Europe) +3
PlRS_local_timezone_table[150]="MUT"    PlRS_offset.MUT    =0.16667   -- Mauritius Time (Africa) +4
PlRS_local_timezone_table[151]="MVT"    PlRS_offset.MVT    =0.20833   -- Maldives Time (Asia) +5
PlRS_local_timezone_table[152]="MYT"    PlRS_offset.MYT    =0.33333   -- Malaysia Time (Asia) +8
PlRS_local_timezone_table[153]="MST_3"  PlRS_offset.MST_3  =0.33333   -- Malaysian Standard Time (Asia) +8
PlRS_local_timezone_table[154]="NCT"    PlRS_offset.NCT    =0.45833   -- New Caledonia Time (Pacific) +11
PlRS_local_timezone_table[155]="NDT"    PlRS_offset.NDT    =-0.10418  -- Newfoundland Daylight Time (North America) -2.5
PlRS_local_timezone_table[156]="NST"    PlRS_offset.NST    =-0.14584  -- Newfoundland Standard Time (North America) -3.5
PlRS_local_timezone_table[157]="NT"     PlRS_offset.NT     =-0.14584  -- Newfoundland Time (North America) -3.5
PlRS_local_timezone_table[158]="NFT"    PlRS_offset.NFT    =0.47918   -- Norfolk Time (Australia) +11.5
PlRS_local_timezone_table[159]="NOVST"  PlRS_offset.NOVST  =0.29167   -- Novosibirsk Summer Time (Asia) +7
PlRS_local_timezone_table[160]="NOVT"   PlRS_offset.NOVT   =0.25      -- Novosibirsk Time (Asia) +6
PlRS_local_timezone_table[161]="NPT"    PlRS_offset.NPT    =0.23959   -- Nepal Time (Asia) +5.75
PlRS_local_timezone_table[162]="NUT"    PlRS_offset.NUT    =-0.45833  -- Niue  Time (Pacific) -11
PlRS_local_timezone_table[163]="NZDT"   PlRS_offset.NZDT   =0.54168   -- New Zealand Daylight Time (Pacific & Antarctica) +13
PlRS_local_timezone_table[164]="NZST"   PlRS_offset.NZST   =0.5       -- New Zealand Standard Time (Pacific & Antarctica) +12
PlRS_local_timezone_table[165]="OMSST"  PlRS_offset.OMSST  =0.29167   -- Omsk Summer Time (Asia) +7
PlRS_local_timezone_table[166]="OMST"   PlRS_offset.OMST   =0.25      -- Omsk Standard Time (Asia) +6
PlRS_local_timezone_table[167]="PDT"    PlRS_offset.PDT    =-0.29167  -- Pacific/Pitcairn Daylight Time (North America & Pacific) -7
PlRS_local_timezone_table[168]="PST_1"  PlRS_offset.PST_1  =-0.33333  -- Pacific/Pitcairn Standard Time (North America & Pacific) -8
PlRS_local_timezone_table[169]="PET"    PlRS_offset.PET    =-0.20833  -- Peru Time (South America) -5
PlRS_local_timezone_table[170]="PETST"  PlRS_offset.PETST  =0.5       -- Kamchatka Summer Time (Asia) +12
PlRS_local_timezone_table[171]="PETT"   PlRS_offset.PETT   =0.5       -- Kamchatka Time (Asia) +12
PlRS_local_timezone_table[172]="PGT"    PlRS_offset.PGT    =0.41667   -- Papua New Guinea Time (Pacific) +10
PlRS_local_timezone_table[173]="PHOT"   PlRS_offset.PHOT   =0.54168   -- Phoenix Island Time (Pacific) +13
PlRS_local_timezone_table[174]="PHT"    PlRS_offset.PHT    =0.33333   -- Philippine Time (Asia) +8
PlRS_local_timezone_table[175]="PST_2"  PlRS_offset.PST_2  =0.33333   -- Philippine Standard Time (Asia) +8
PlRS_local_timezone_table[176]="PKT"    PlRS_offset.PKT    =0.20833   -- Pakistan Standard Time (Asia) +5
PlRS_local_timezone_table[177]="PMDT"   PlRS_offset.PMDT   =-0.08333  -- Pierre & Miquelon Daylight Time (North America) -2
PlRS_local_timezone_table[178]="PMST"   PlRS_offset.PMST   =-0.125    -- Pierre & Miquelon Standard Time (North America) -3
PlRS_local_timezone_table[179]="PONT"   PlRS_offset.PONT   =0.45833   -- Pohnpei Standard Time (Pacific) +11
PlRS_local_timezone_table[180]="PT"     PlRS_offset.PT     =-0.33333  -- Tiempo del Pac�fico (North America) -8
PlRS_local_timezone_table[181]="PWT"    PlRS_offset.PWT    =0.375     -- Palau Time (Pacific) +9
PlRS_local_timezone_table[182]="PYST"   PlRS_offset.PYST   =-0.125    -- Paraguay Summer Time (South America) -3
PlRS_local_timezone_table[183]="PYT"    PlRS_offset.PYT    =-0.16667  -- Paraguay Time (South America) -4
PlRS_local_timezone_table[184]="RET"    PlRS_offset.RET    =0.16667   -- R�union Time (Africa) +4
PlRS_local_timezone_table[185]="SAMT"   PlRS_offset.SAMT   =0.16667   -- Samara Time (Europe) +4
PlRS_local_timezone_table[186]="SAST"   PlRS_offset.SAST   =0.08333   -- South African Standard Time (Africa) +2
PlRS_local_timezone_table[187]="SBT"    PlRS_offset.SBT    =0.45833   -- Solomon Islands Time (Pacific) +11
PlRS_local_timezone_table[188]="SCT"    PlRS_offset.SCT    =0.16667   -- Seychelles Time (Africa) +4
PlRS_local_timezone_table[189]="SGT"    PlRS_offset.SGT    =0.33333   -- Singapore Time (Asia) +8
PlRS_local_timezone_table[190]="SST_1"  PlRS_offset.SST_1  =0.33333   -- Singapore Standard Time (Asia) +8
PlRS_local_timezone_table[191]="SLT"    PlRS_offset.SLT    =0.22918   -- Sri Lanka Time (Indian Ocean) +5.5
PlRS_local_timezone_table[192]="SRT"    PlRS_offset.SRT    =-0.125    -- Suriname Time (South America) -3
PlRS_local_timezone_table[193]="SST_2"  PlRS_offset.SST_2  =-0.45833  -- Samoa Standard Time (Pacific) -11
PlRS_local_timezone_table[194]="TAHT"   PlRS_offset.TAHT   =-0.41667  -- Tahiti Time (Pacific) -10
PlRS_local_timezone_table[195]="TFT"    PlRS_offset.TFT    =0.20833   -- French Southern and Antarctic Time (Indian Ocean) +5
PlRS_local_timezone_table[196]="THA"    PlRS_offset.THA    =0.29167   -- Thailand Standard Time (Asia) +7
PlRS_local_timezone_table[197]="TJT"    PlRS_offset.TJT    =0.20833   -- Tajikistan Time (Asia) +5
PlRS_local_timezone_table[198]="TKT"    PlRS_offset.TKT    =-0.41667  -- Tokelau Time (Pacific) -10
PlRS_local_timezone_table[199]="TLT"    PlRS_offset.TLT    =0.375     -- East Timor Time (Asia) +9
PlRS_local_timezone_table[200]="TMT"    PlRS_offset.TMT    =0.20833   -- Turkmenistan Time (Asia) +5
PlRS_local_timezone_table[201]="TVT"    PlRS_offset.TVT    =0.5       -- Tuvalu Time (Pacific) +12
PlRS_local_timezone_table[202]="ULAT"   PlRS_offset.ULAT   =0.33333   -- Ulaanbaatar Time (Asia) +8
PlRS_local_timezone_table[203]="UYST"   PlRS_offset.UYST   =-0.08333  -- Uruguay Summer Time (South America) -2
PlRS_local_timezone_table[204]="UYT"    PlRS_offset.UYT    =-0.125    -- Uruguay Standard Time (South America) -3
PlRS_local_timezone_table[205]="UZT"    PlRS_offset.UZT    =0.20833   -- Uzbekistan Time (Asia) +5
PlRS_local_timezone_table[206]="VET"    PlRS_offset.VET    =-0.18750  -- Venezuelan Standard Time (South America) -4.5
PlRS_local_timezone_table[207]="VLAST"  PlRS_offset.VLAST  =0.45833   -- Vladivostok Summer Time (Asia) +11
PlRS_local_timezone_table[208]="VLAT"   PlRS_offset.VLAT   =0.41667   -- Vladivostok Time (Asia) +10
PlRS_local_timezone_table[209]="VUT"    PlRS_offset.VUT    =0.45833   -- Vanuatu Time (Pacific) +11
PlRS_local_timezone_table[210]="WAST"   PlRS_offset.WAST   =0.08333   -- West Africa Summer Time (Africa) +2
PlRS_local_timezone_table[211]="WAT"    PlRS_offset.WAT    =0.04167   -- West Africa Time (Africa) +1
PlRS_local_timezone_table[212]="WDT"    PlRS_offset.WDT    =0.375     -- Western Daylight Time (Australia) +9
PlRS_local_timezone_table[213]="WEDT"   PlRS_offset.WEDT   =0.04167   -- Western European Daylight Time (Europe & Africa) +1
PlRS_local_timezone_table[214]="WEST"   PlRS_offset.WEST   =0.04167   -- Western European Summer Time (Europe & Africa) +1
PlRS_local_timezone_table[215]="WET"    PlRS_offset.WET    =0         -- Western European Time (Europe & Africa) 0
PlRS_local_timezone_table[216]="WFT"    PlRS_offset.WFT    =0.5       -- Wallis and Futuna Time (Pacific) +12
PlRS_local_timezone_table[217]="WGST"   PlRS_offset.WGST   =-0.08333  -- Western Greenland Summer Time (North America) -2
PlRS_local_timezone_table[218]="WGT"    PlRS_offset.WGT    =-0.125    -- Western Greenland Time (North America) -3
PlRS_local_timezone_table[219]="WIB"    PlRS_offset.WIB    =0.29167   -- Western Indonesian Time (Asia) +7
PlRS_local_timezone_table[220]="WIT"    PlRS_offset.WIT    =0.375     -- Eastern Indonesian Time (Asia) +9
PlRS_local_timezone_table[221]="WITA"   PlRS_offset.WITA   =0.33333   -- Central Indonesian Time (Asia) +8
PlRS_local_timezone_table[222]="WST_1"  PlRS_offset.WST_1  =0.04167   -- Western Sahara Summer Time (Africa) +1
PlRS_local_timezone_table[223]="WT"     PlRS_offset.WT     =0         -- Western Sahara Standard Time (Africa) 0
PlRS_local_timezone_table[224]="WST_2"  PlRS_offset.WST_2  =0.33333   -- Western Standard Time (Australia) +8
PlRS_local_timezone_table[225]="WST_3"  PlRS_offset.WST_3  =-0.45833  -- West Samoa Time (Pacific) -11
PlRS_local_timezone_table[226]="YAKST"  PlRS_offset.YAKST  =0.41667   -- Yakutsk Summer Time (Asia) +10
PlRS_local_timezone_table[227]="YAKT"   PlRS_offset.YAKT   =0.375     -- Yakutsk Time (Asia) +9
PlRS_local_timezone_table[228]="YAPT"   PlRS_offset.YAPT   =0.41667   -- Yap Time (Pacific) +10
PlRS_local_timezone_table[229]="YEKST"  PlRS_offset.YEKST  =0.25      -- Yekaterinburg Summer Time (Asia) +6
PlRS_local_timezone_table[230]="YEKT"   PlRS_offset.YEKT   =0.20833   -- Yekaterinburg Time (Asia) +5
--============================================================================================================
