-------------------------------------------------------------
-- Configuration file for SunriseSunset script.
-- Change the values to customize the script.
-- If an item is not defined, a default value will be used
-------------------------------------------------------------

-------------------------------------------------------------
-- If your preferred display language is not English, and is one
-- of the currently supported locales, you can define it below:
-- (Currently supported locales are: de, fr, it, nl and en).
-------------------------------------------------------------
language = "en"

-------------------------------------------------------------
-- Determine the brightness level of ambient light for the script.
-------------------------------------------------------------
ambient = 0.25

-------------------------------------------------------------
-- If you want to use a static location to be used for the Sunrise and Sunset calculation:
-- 1) Uncomment the upcoming 3 lines for Longitude, Latitude and Location name
-- 2) Set the Longitude and Latitude coordinates of that location on Earth (in degrees)
--    * Northern latitudes positive, Southern latitudes negative, -90  <= Latitude  <= 90,
--    * Eastern longitudes positive, Western longitudes negative, -360 <  Longitude < 360.
-- 3) Fill in your own location name.
-- If not supplied (the upcoming 3 lines stay commented), the location will be determined dynamically, based on:
--    A) The actual selection (which must be a location on Earth)
--    B) The actual Longitude, Latitude coordinated of the observer
-------------------------------------------------------------
--longitude    = 6.016                 -- Longitude in degrees
--latitude     = 52.213                -- Latitude in degrees
--locationname = "Apeldoorn (NL)"      -- Fill in your own Location name between the 2 double quotes

-------------------------------------------------------------
-- If you want to use a static date to be used for the Sunrise and Sunset calculation:
-- 1) Uncomment the upcoming 3 lines for Year, Month and Day
-- 2) Set the Year, Month and Day in numerical format
-- If not supplied (the upcoming 3 lines stay commented), the date will be determined dynamically.
-------------------------------------------------------------
--date_Year     = 2013                 -- Year
--date_Month    = 10                   -- Month
--date_Day      = 6                    -- Day

-------------------------------------------------------------
-- Local time zone, used to display local Sunrise and Sunset times.
-- Must be one of the time zone abbreviations in local_timezone_table below,
-- otherwise "UTC" will be used. ==> Mind UPPERCASE/lowercase !!!
-------------------------------------------------------------
local_timezone="UTC"

local_timezone_table={}
offset={}
--============================================================================================================
local_timezone_table[1]  ="UTC"    offset.UTC    =0         -- Coordinated Universal Time 0
local_timezone_table[2]  ="ACDT"   offset.ACDT   =0.4375    -- Australian Central Daylight Time (Australia) +10.5
local_timezone_table[3]  ="ACST"   offset.ACST   =0.39584   -- Australian Central Standard Time (Australia) +9.5
local_timezone_table[4]  ="ACT"    offset.ACT    =0.33333   -- ASEAN Common Time (Asia) +8
local_timezone_table[5]  ="ADT"    offset.ADT    =-0.125    -- Atlantic Daylight Time (North America & Atlantic) -3
local_timezone_table[6]  ="AST_4"  offset.AST_4  =-0.16667  -- Atlantic Standard Time (North America & Atlantic) -4
local_timezone_table[7]  ="AEDT"   offset.AEDT   =0.45833   -- Australian Eastern Daylight Time (Australia) +11
local_timezone_table[8]  ="AEST"   offset.AEST   =0.41667   -- Australian Eastern Standard Time (Australia) +10
local_timezone_table[9]  ="AFT"    offset.AFT    =0.1875    -- Afghanistan Time (Asia) +4.5
local_timezone_table[10] ="AKDT"   offset.AKDT   =-0.33333  -- Alaska Daylight Time (North America) -8
local_timezone_table[11] ="AKST"   offset.AKST   =-0.375    -- Alaska Standard Time (North America) -9
local_timezone_table[12] ="ALMT"   offset.ALMT   =0.25      -- Alma-Ata Time (Asia) +6
local_timezone_table[13] ="AMST_1" offset.AMST_1 =0.20833   -- Armenia Summer Time (Asia) +5
local_timezone_table[14] ="AMT_1"  offset.AMT_1  =0.16667   -- Armenia Time (Asia) +4
local_timezone_table[15] ="AMST_2" offset.AMST_2 =-0.125    -- Amazon Summer Time (South America) -3
local_timezone_table[16] ="AMT_2"  offset.AMT_2  =-0.16667  -- Amazon Time (South America) -4
local_timezone_table[17] ="ANAST"  offset.ANAST  =0.5       -- Anadyr Summer Time (Asia) +12
local_timezone_table[18] ="ANAT"   offset.ANAT   =0.5       -- Anadyr Time (Asia) +12
local_timezone_table[19] ="AQTT"   offset.AQTT   =0.20833   -- Aqtobe Time (Asia) +5
local_timezone_table[20] ="ART"    offset.ART    =-0.125    -- Argentina Time (South America) -3
local_timezone_table[21] ="AST_1"  offset.AST_1  =0.125     -- Arab Standard Time [Kuwait, Riyadh] (Asia) +3
local_timezone_table[22] ="AST_2"  offset.AST_2  =0.16667   -- Arabian Standard Time [Abu Dhabi, Muscat] (Asia) +4
local_timezone_table[23] ="AST_3"  offset.AST_3  =0.125     -- Arabic Standard Time [Baghdad] (Asia) +3
local_timezone_table[24] ="AWDT"   offset.AWDT   =0.375     -- Australian Western Daylight Time (Australia) +9
local_timezone_table[25] ="AWST"   offset.AWST   =0.33333   -- Australian Western Standard Time (Australia) +8
local_timezone_table[26] ="AZOST"  offset.AZOST  =0         -- Azores Summer Time (Atlantic) 0
local_timezone_table[27] ="AZOT"   offset.AZOT   =-0.04167  -- Azores Time (Atlantic) -1
local_timezone_table[28] ="AZST"   offset.AZST   =0.20833   -- Azerbaijan Summer Time (Asia) +5
local_timezone_table[29] ="AZT"    offset.AZT    =0.16667   -- Azerbaijan Time (Asia) +4
local_timezone_table[30] ="BDT"    offset.BDT    =0.33333   -- Brunei Darussalam Time (Asia) +8
local_timezone_table[31] ="BNT"    offset.BNT    =0.33333   -- Brunei Darussalam Time (Asia) +8
local_timezone_table[32] ="BIOT"   offset.BIOT   =0.25      -- British Indian Ocean Time (Indian Ocean) +6
local_timezone_table[33] ="BIT"    offset.BIT    =-0.5      -- Baker Island Time (Pacific Ocean) -12
local_timezone_table[34] ="BOT"    offset.BOT    =-0.16667  -- Bolivia Time (South America) -4
local_timezone_table[35] ="BRST"   offset.BRST   =-0.08333  -- Brasilia Summer Time (South America) -2
local_timezone_table[36] ="BRT"    offset.BRT    =-0.125    -- Brasilia Time (South America) -3
local_timezone_table[37] ="BST_1"  offset.BST_1  =0.25      -- Bangladesh Standard Time (Asia) +6
local_timezone_table[38] ="BST_2"  offset.BST_2  =0.04167   -- British Summer Time [British Standard Time from Feb 1968 to Oct 1971] (Europe) +1
local_timezone_table[39] ="BTT"    offset.BTT    =0.25      -- Bhutan Time (Asia) +6
local_timezone_table[40] ="CAST"   offset.CAST   =0.33333   -- Casey Time (Antarctica) +8
local_timezone_table[41] ="CAT"    offset.CAT    =0.08333   -- Central Africa Time (Africa) +2
local_timezone_table[42] ="CCT"    offset.CCT    =0.27084   -- Cocos Islands Time (Indian Ocean) +6.5
local_timezone_table[43] ="CDT_1"  offset.CDT_1  =0.4375    -- Central Daylight Time (Australia) +10.5
local_timezone_table[44] ="CST_1"  offset.CST_1  =0.39584   -- Central Standard Time (Australia) +9.5
local_timezone_table[45] ="CDT_2"  offset.CDT_2  =-0.16667  -- Cuba Daylight Time (Caribbean) -4
local_timezone_table[46] ="CST_2"  offset.CST_2  =-0.20833  -- Cuba Standard Time (Caribbean) -5
local_timezone_table[47] ="CDT_3"  offset.CDT_3  =-0.20833  -- Central Daylight Time (North America) -5
local_timezone_table[48] ="CST_3"  offset.CST_3  =-0.25     -- Central Standard Time (North America) -6
local_timezone_table[49] ="CEDT"   offset.CEDT   =0.08333   -- Central European Daylight Time (Europe) +2
local_timezone_table[50] ="CEST"   offset.CEST   =0.08333   -- Central European Summer Time (Europe) +2
local_timezone_table[51] ="CET"    offset.CET    =0.04167   -- Central European Time (Europe) +1
local_timezone_table[52] ="CHADT"  offset.CHADT  =0.57293   -- Chatham Island Daylight Time (Pacific) +13.75
local_timezone_table[53] ="CHAST"  offset.CHAST  =0.53125   -- Chatham Island Standard Time (Pacific) +12.75
local_timezone_table[54] ="CIST"   offset.CIST   =-0.33333  -- Clipperton Island Standard Time (Central America) -8
local_timezone_table[55] ="CKT"    offset.CKT    =-0.41667  -- Cook Island Time (Pacific) -10
local_timezone_table[56] ="CLST"   offset.CLST   =-0.125    -- Chile Summer Time (South America) -3
local_timezone_table[57] ="CLT"    offset.CLT    =-0.16667  -- Chile Standard Time (South America) -4
local_timezone_table[58] ="COST"   offset.COST   =-0.16667  -- Colombia Summer Time (South America) -4
local_timezone_table[59] ="COT"    offset.COT    =-0.20833  -- Colombia Time (South America) -5
local_timezone_table[60] ="CST_4"  offset.CST_4  =-0.25     -- Central Standard Time (Central America) -6
local_timezone_table[61] ="CST_5"  offset.CST_5  =0.33333   -- China Standard Time (Asia) +8
local_timezone_table[62] ="CT"     offset.CT     =0.33333   -- China Time (Asia) +8
local_timezone_table[63] ="CVT"    offset.CVT    =-0.04167  -- Cape Verde Time  (Africa) -1
local_timezone_table[64] ="CXT"    offset.CXT    =0.29167   -- Christmas Island Time (Australia) +7
local_timezone_table[65] ="ChST"   offset.ChST   =0.41667   -- Chamorro Standard Time (Pacific) +10
local_timezone_table[66] ="DAVT"   offset.DAVT   =0.29167   -- Davis Time (Antarctica) +7
local_timezone_table[67] ="DFT"    offset.DFT    =0.04167   -- AIX specific equivalent of Central European Time +1
local_timezone_table[68] ="EASST"  offset.EASST  =-0.20833  -- Easter Island Summer Time (Pacific) -5
local_timezone_table[69] ="EAST"   offset.EAST   =-0.25     -- Easter Island Standard Time (Pacific) -6
local_timezone_table[70] ="EAT"    offset.EAT    =0.125     -- East Africa Time (Africa) +3
local_timezone_table[71] ="ECT_1"  offset.ECT_1  =-0.16667  -- Eastern Caribbean Time (does not recognise DST) -4
local_timezone_table[72] ="ECT_2"  offset.ECT_2  =-0.20833  -- Ecuador Time (South America) -5
local_timezone_table[73] ="EDT_1"  offset.EDT_1  =-0.16667  -- Eastern Daylight Time (North America & Caribbean) -4
local_timezone_table[74] ="EST_1"  offset.EST_1  =-0.20833  -- Eastern Standard Time (North America & Caribbean & Central America) -5
local_timezone_table[75] ="EDT_2"  offset.EDT_2  =0.45833   -- Eastern Daylight Time (Australia & Pacific) +11
local_timezone_table[76] ="EST_2"  offset.EST_2  =0.41667   -- Eastern Standard Time (Australia) +10
local_timezone_table[77] ="EEDT"   offset.EEDT   =0.125     -- Eastern European Daylight Time (Europe & Asia & Africa) +3
local_timezone_table[78] ="EEST"   offset.EEST   =0.125     -- Eastern European Summer Time (Europe & Asia & Africa) +3
local_timezone_table[79] ="EET"    offset.EET    =0.08333   -- Eastern European Time (Europe & Asia & Africa) +2
local_timezone_table[80] ="EGST"   offset.EGST   =0         -- Eastern Greenland Summer Time (North America) 0
local_timezone_table[81] ="EGT"    offset.EGT    =-0.04167  -- Eastern Greenland Time (North America) -1
local_timezone_table[82] ="ET"     offset.ET     =-0.20833  -- Tiempo Del Este (North America & Caribbean & Central America) -5
local_timezone_table[83] ="FJST"   offset.FJST   =0.54168   -- Fiji Summer Time (Pacific) +13
local_timezone_table[84] ="FJT"    offset.FJT    =0.5       -- Fiji Time (Pacific) +12
local_timezone_table[85] ="FKST"   offset.FKST   =-0.125    -- Falkland Islands Summer Time (South America) -3
local_timezone_table[86] ="FKT"    offset.FKT    =-0.16667  -- Falkland Islands Time (South America) -4
local_timezone_table[87] ="FNT"    offset.FNT    =-0.08333  -- Fernando de Noronha Time (South America) -2
local_timezone_table[88] ="GALT"   offset.GALT   =-0.25     -- Galapagos Time (Pacific) -6
local_timezone_table[89] ="GAMT"   offset.GAMT   =-0.375    -- Gambier Time (Pacific) -9
local_timezone_table[90] ="GET"    offset.GET    =0.16667   -- Georgia Standard Time (Asia) +4
local_timezone_table[91] ="GFT"    offset.GFT    =-0.125    -- French Guiana Time (South America) -3
local_timezone_table[92] ="GILT"   offset.GILT   =0.5       -- Gilbert Island Time (Pacific) +12
local_timezone_table[93] ="GIT"    offset.GIT    =-0.375    -- Gambier Island Time (Pacific) -9
local_timezone_table[94] ="GMT"    offset.GMT    =0         -- Greenwich Mean Time (Europe & Africa) 0
local_timezone_table[95] ="GST_1"  offset.GST_1  =-0.08333  -- South Georgia and the South Sandwich Islands (Atlantic) -2
local_timezone_table[96] ="GST_2"  offset.GST_2  =0.16667   -- Gulf Standard Time (Asia) +4
local_timezone_table[97] ="GYT"    offset.GYT    =-0.16667  -- Guyana Time (South America) -4
local_timezone_table[98] ="HAA"    offset.HAA    =-0.125    -- Heure Avancée de l'Atlantique (North America & Atlantic) -3
local_timezone_table[99] ="HAC"    offset.HAC    =-0.20833  -- Heure Avancée du Centre (North America) -5
local_timezone_table[100]="HADT"   offset.HADT   =-0.375    -- Hawaii-Aleutian Daylight Time (North America) -9
local_timezone_table[101]="HAST"   offset.HAST   =-0.41667  -- Hawaii-Aleutian Standard Time (North America) -10
local_timezone_table[102]="HAE"    offset.HAE    =-0.16667  -- Heure Avancée de l'Est (North America & Caribbean) -4
local_timezone_table[103]="HAP"    offset.HAP    =-0.29167  -- Heure Avancée du Pacifique (North America) -7
local_timezone_table[104]="HAR"    offset.HAR    =-0.25     -- Heure Avancée des Rocheuses (North America) -6
local_timezone_table[105]="HAT"    offset.HAT    =-0.10418  -- Heure Avancée de Terre-Neuve (North America) -2.5
local_timezone_table[106]="HAY"    offset.HAY    =-0.33333  -- Heure Avancée du Yukon (North America) -8
local_timezone_table[107]="HKT"    offset.HKT    =0.33333   -- Hong Kong Time (Asia) +8
local_timezone_table[108]="HLV"    offset.HLV    =-0.18750  -- Hora Legal de Venezuela (South America) -4.5
local_timezone_table[109]="HMT"    offset.HMT    =0.20833   -- Heard and McDonald Islands Time (Antarctic) +5
local_timezone_table[110]="HNA"    offset.HNA    =-0.16667  -- Heure Normale de l'Atlantique (North America & Caribbean & Atlantic) -4
local_timezone_table[111]="HNC"    offset.HNC    =-0.25     -- Heure Normale du Centre (North America & Central America) -6
local_timezone_table[112]="HNE"    offset.HNE    =-0.20833  -- Heure Normale de l'Est (North America & Central America & Caribbean) -5
local_timezone_table[113]="HNP"    offset.HNP    =-0.33333  -- Heure Normale du Pacifique (North America) -8
local_timezone_table[114]="HNR"    offset.HNR    =-0.29167  -- Heure Normale des Rocheuses (North America) -7
local_timezone_table[115]="HNT"    offset.HNT    =-0.14584  -- Heure Normale de Terre-Neuve (North America) -3.5
local_timezone_table[116]="HNY"    offset.HNY    =-0.375    -- Heure Normale du Yukon (North America) -9
local_timezone_table[117]="HOVT"   offset.HOVT   =0.29167   -- Hovd Time (Asia) +7
local_timezone_table[118]="HST"    offset.HST    =-0.41667  -- Hawaii Standard Time (Pacific) -10
local_timezone_table[119]="ICT"    offset.ICT    =0.29167   -- Indochina Time (Asia) +7
local_timezone_table[120]="IDT"    offset.IDT    =0.125     -- Israeli Daylight Time (Asia) +3
local_timezone_table[121]="IOT"    offset.IOT    =0.25      -- Indian Chagos Time (Indian Ocean) +6
local_timezone_table[122]="IRDT"   offset.IRDT   =0.18750   -- Iran Daylight Time (Asia) +4.5
local_timezone_table[123]="IRST"   offset.IRST   =0.14584   -- Iran Standard Time (Asia) +3.5
local_timezone_table[124]="IRKST"  offset.IRKST  =0.375     -- Irkutsk Summer Time (Asia) +9
local_timezone_table[125]="IRKT"   offset.IRKT   =0.33333   -- Irkutsk Time (Asia) +8
local_timezone_table[126]="IST_1"  offset.IST_1  =0.22918   -- Indian Standard Time (Asia) +5.5
local_timezone_table[127]="IST_2"  offset.IST_2  =0.04167   -- Irish Summer Time (Europe) +1
local_timezone_table[128]="IST_3"  offset.IST_3  =0.08333   -- Israel Standard Time (Asia) +2
local_timezone_table[129]="JST"    offset.JST    =0.375     -- Japan Standard Time (Asia) +9
local_timezone_table[130]="KGT"    offset.KGT    =0.25      -- Kyrgyzstan Time (Asia) +6
local_timezone_table[131]="KRAST"  offset.KRAST  =0.33333   -- Krasnoyarsk Summer Time (Asia) +8
local_timezone_table[132]="KRAT"   offset.KRAT   =0.29167   -- Krasnoyarsk Time (Asia) +7
local_timezone_table[133]="KST"    offset.KST    =0.375     -- Korea Standard Time (Asia) +9
local_timezone_table[134]="KUYT"   offset.KUYT   =0.375     -- Kuybyshev Time (Europe) +4
local_timezone_table[135]="LHDT"   offset.LHDT   =0.45833   -- Lord Howe Daylight Time (Australia) +11
local_timezone_table[136]="LHST"   offset.LHST   =0.4375    -- Lord Howe Standard Time (Australia) +10.5
local_timezone_table[137]="LINT"   offset.LINT   =0.58334   -- Line Islands Time (Pacific) +14
local_timezone_table[138]="MAGST"  offset.MAGST  =0.5       -- Magadan Summer Time (Asia) +12
local_timezone_table[139]="MAGT"   offset.MAGT   =0.45833   -- Magadan Time (Asia) +11
local_timezone_table[140]="MART"   offset.MART   =-0.39584  -- Marquesas Time (Pacific) -9.5
local_timezone_table[141]="MAWT"   offset.MAWT   =0.20833   -- Mawson Time (Antarctica) +5
local_timezone_table[142]="MDT"    offset.MDT    =-0.25     -- Mountain Daylight Time (North America) -6
local_timezone_table[143]="MST_1"  offset.MST_1  =-0.29167  -- Mountain Standard Time (North America) -7
local_timezone_table[144]="MHT"    offset.MHT    =0.5       -- Marshall Islands Time (Pacific) +12
local_timezone_table[145]="MIT"    offset.MIT    =-0.39584  -- Marquesas Islands Time (Pacific) -9.5
local_timezone_table[146]="MMT"    offset.MMT    =0.27084   -- Myanmar Time (Asia) +6.5
local_timezone_table[147]="MST_2"  offset.MST_2  =0.27084   -- Myanmar Standard Time (Asia) +6.5
local_timezone_table[148]="MSD"    offset.MSD    =0.16667   -- Moscow Summer Time (Europe) +4
local_timezone_table[149]="MSK"    offset.MSK    =0.125     -- Moscow Standard Time (Europe) +3
local_timezone_table[150]="MUT"    offset.MUT    =0.16667   -- Mauritius Time (Africa) +4
local_timezone_table[151]="MVT"    offset.MVT    =0.20833   -- Maldives Time (Asia) +5
local_timezone_table[152]="MYT"    offset.MYT    =0.33333   -- Malaysia Time (Asia) +8
local_timezone_table[153]="MST_3"  offset.MST_3  =0.33333   -- Malaysian Standard Time (Asia) +8
local_timezone_table[154]="NCT"    offset.NCT    =0.45833   -- New Caledonia Time (Pacific) +11
local_timezone_table[155]="NDT"    offset.NDT    =-0.10418  -- Newfoundland Daylight Time (North America) -2.5
local_timezone_table[156]="NST"    offset.NST    =-0.14584  -- Newfoundland Standard Time (North America) -3.5
local_timezone_table[157]="NT"     offset.NT     =-0.14584  -- Newfoundland Time (North America) -3.5
local_timezone_table[158]="NFT"    offset.NFT    =0.47918   -- Norfolk Time (Australia) +11.5
local_timezone_table[159]="NOVST"  offset.NOVST  =0.29167   -- Novosibirsk Summer Time (Asia) +7
local_timezone_table[160]="NOVT"   offset.NOVT   =0.25      -- Novosibirsk Time (Asia) +6
local_timezone_table[161]="NPT"    offset.NPT    =0.23959   -- Nepal Time (Asia) +5.75
local_timezone_table[162]="NUT"    offset.NUT    =-0.45833  -- Niue  Time (Pacific) -11
local_timezone_table[163]="NZDT"   offset.NZDT   =0.54168   -- New Zealand Daylight Time (Pacific & Antarctica) +13
local_timezone_table[164]="NZST"   offset.NZST   =0.5       -- New Zealand Standard Time (Pacific & Antarctica) +12
local_timezone_table[165]="OMSST"  offset.OMSST  =0.29167   -- Omsk Summer Time (Asia) +7
local_timezone_table[166]="OMST"   offset.OMST   =0.25      -- Omsk Standard Time (Asia) +6
local_timezone_table[167]="PDT"    offset.PDT    =-0.29167  -- Pacific/Pitcairn Daylight Time (North America & Pacific) -7
local_timezone_table[168]="PST_1"  offset.PST_1  =-0.33333  -- Pacific/Pitcairn Standard Time (North America & Pacific) -8
local_timezone_table[169]="PET"    offset.PET    =-0.20833  -- Peru Time (South America) -5
local_timezone_table[170]="PETST"  offset.PETST  =0.5       -- Kamchatka Summer Time (Asia) +12
local_timezone_table[171]="PETT"   offset.PETT   =0.5       -- Kamchatka Time (Asia) +12
local_timezone_table[172]="PGT"    offset.PGT    =0.41667   -- Papua New Guinea Time (Pacific) +10
local_timezone_table[173]="PHOT"   offset.PHOT   =0.54168   -- Phoenix Island Time (Pacific) +13
local_timezone_table[174]="PHT"    offset.PHT    =0.33333   -- Philippine Time (Asia) +8
local_timezone_table[175]="PST_2"  offset.PST_2  =0.33333   -- Philippine Standard Time (Asia) +8
local_timezone_table[176]="PKT"    offset.PKT    =0.20833   -- Pakistan Standard Time (Asia) +5
local_timezone_table[177]="PMDT"   offset.PMDT   =-0.08333  -- Pierre & Miquelon Daylight Time (North America) -2
local_timezone_table[178]="PMST"   offset.PMST   =-0.125    -- Pierre & Miquelon Standard Time (North America) -3
local_timezone_table[179]="PONT"   offset.PONT   =0.45833   -- Pohnpei Standard Time (Pacific) +11
local_timezone_table[180]="PT"     offset.PT     =-0.33333  -- Tiempo del Pacífico (North America) -8
local_timezone_table[181]="PWT"    offset.PWT    =0.375     -- Palau Time (Pacific) +9
local_timezone_table[182]="PYST"   offset.PYST   =-0.125    -- Paraguay Summer Time (South America) -3
local_timezone_table[183]="PYT"    offset.PYT    =-0.16667  -- Paraguay Time (South America) -4
local_timezone_table[184]="RET"    offset.RET    =0.16667   -- Réunion Time (Africa) +4
local_timezone_table[185]="SAMT"   offset.SAMT   =0.16667   -- Samara Time (Europe) +4
local_timezone_table[186]="SAST"   offset.SAST   =0.08333   -- South African Standard Time (Africa) +2
local_timezone_table[187]="SBT"    offset.SBT    =0.45833   -- Solomon Islands Time (Pacific) +11
local_timezone_table[188]="SCT"    offset.SCT    =0.16667   -- Seychelles Time (Africa) +4
local_timezone_table[189]="SGT"    offset.SGT    =0.33333   -- Singapore Time (Asia) +8
local_timezone_table[190]="SST_1"  offset.SST_1  =0.33333   -- Singapore Standard Time (Asia) +8
local_timezone_table[191]="SLT"    offset.SLT    =0.22918   -- Sri Lanka Time (Indian Ocean) +5.5
local_timezone_table[192]="SRT"    offset.SRT    =-0.125    -- Suriname Time (South America) -3
local_timezone_table[193]="SST_2"  offset.SST_2  =-0.45833  -- Samoa Standard Time (Pacific) -11
local_timezone_table[194]="TAHT"   offset.TAHT   =-0.41667  -- Tahiti Time (Pacific) -10
local_timezone_table[195]="TFT"    offset.TFT    =0.20833   -- French Southern and Antarctic Time (Indian Ocean) +5
local_timezone_table[196]="THA"    offset.THA    =0.29167   -- Thailand Standard Time (Asia) +7
local_timezone_table[197]="TJT"    offset.TJT    =0.20833   -- Tajikistan Time (Asia) +5
local_timezone_table[198]="TKT"    offset.TKT    =-0.41667  -- Tokelau Time (Pacific) -10
local_timezone_table[199]="TLT"    offset.TLT    =0.375     -- East Timor Time (Asia) +9
local_timezone_table[200]="TMT"    offset.TMT    =0.20833   -- Turkmenistan Time (Asia) +5
local_timezone_table[201]="TVT"    offset.TVT    =0.5       -- Tuvalu Time (Pacific) +12
local_timezone_table[202]="ULAT"   offset.ULAT   =0.33333   -- Ulaanbaatar Time (Asia) +8
local_timezone_table[203]="UYST"   offset.UYST   =-0.08333  -- Uruguay Summer Time (South America) -2
local_timezone_table[204]="UYT"    offset.UYT    =-0.125    -- Uruguay Standard Time (South America) -3
local_timezone_table[205]="UZT"    offset.UZT    =0.20833   -- Uzbekistan Time (Asia) +5
local_timezone_table[206]="VET"    offset.VET    =-0.18750  -- Venezuelan Standard Time (South America) -4.5
local_timezone_table[207]="VLAST"  offset.VLAST  =0.45833   -- Vladivostok Summer Time (Asia) +11
local_timezone_table[208]="VLAT"   offset.VLAT   =0.41667   -- Vladivostok Time (Asia) +10
local_timezone_table[209]="VUT"    offset.VUT    =0.45833   -- Vanuatu Time (Pacific) +11
local_timezone_table[210]="WAST"   offset.WAST   =0.08333   -- West Africa Summer Time (Africa) +2
local_timezone_table[211]="WAT"    offset.WAT    =0.04167   -- West Africa Time (Africa) +1
local_timezone_table[212]="WDT"    offset.WDT    =0.375     -- Western Daylight Time (Australia) +9
local_timezone_table[213]="WEDT"   offset.WEDT   =0.04167   -- Western European Daylight Time (Europe & Africa) +1
local_timezone_table[214]="WEST"   offset.WEST   =0.04167   -- Western European Summer Time (Europe & Africa) +1
local_timezone_table[215]="WET"    offset.WET    =0         -- Western European Time (Europe & Africa) 0
local_timezone_table[216]="WFT"    offset.WFT    =0.5       -- Wallis and Futuna Time (Pacific) +12
local_timezone_table[217]="WGST"   offset.WGST   =-0.08333  -- Western Greenland Summer Time (North America) -2
local_timezone_table[218]="WGT"    offset.WGT    =-0.125    -- WWestern Greenland Time (North America) -3
local_timezone_table[219]="WIB"    offset.WIB    =0.29167   -- Western Indonesian Time (Asia) +7
local_timezone_table[220]="WIT"    offset.WIT    =0.375     -- Eastern Indonesian Time (Asia) +9
local_timezone_table[221]="WITA"   offset.WITA   =0.33333   -- Central Indonesian Time (Asia) +8
local_timezone_table[222]="WST_1"  offset.WST_1  =0.04167   -- Western Sahara Summer Time (Africa) +1
local_timezone_table[223]="WT"     offset.WT     =0         -- Western Sahara Standard Time (Africa) 0
local_timezone_table[224]="WST_2"  offset.WST_2  =0.33333   -- Western Standard Time (Australia) +8
local_timezone_table[225]="WST_3"  offset.WST_3  =-0.45833  -- West Samoa Time (Pacific) -11
local_timezone_table[226]="YAKST"  offset.YAKST  =0.41667   -- Yakutsk Summer Time (Asia) +10
local_timezone_table[227]="YAKT"   offset.YAKT   =0.375     -- Yakutsk Time (Asia) +9
local_timezone_table[228]="YAPT"   offset.YAPT   =0.41667   -- Yap Time (Pacific) +10
local_timezone_table[229]="YEKST"  offset.YEKST  =0.25      -- Yekaterinburg Summer Time (Asia) +6
local_timezone_table[230]="YEKT"   offset.YEKT   =0.20833   -- Yekaterinburg Time (Asia) +5
--============================================================================================================
