----------------------------------------------
-- Set initial values
----------------------------------------------

if lua_edu_tools and lang ~= "en"
	then require "locale" 
	else require "SunRiseSet_locale"
end

if pcall( function() require ("locale_SunRiseSet_"..lang) end ) then
	for engl, transl in pairs(SunRiseSet_loc_str) do
		loc_str[engl]=transl
	end
end

require "SunRiseSet_config" 
   
--
--	Some constants, variables and useful unit conversions:
--

--Plug-in box dimension and initial position
local sx, sy = celestia:getscreendimension()
local oldsx, oldsy = 0, 0
local lspace = normalfont:getheight() + 1
local boxW1, boxH1 = 210, lspace * 10 + 8                  -- display width texts 210 pixels, display height = 10 lines + some margin
local posX1, posT1 = sx/2 - boxW1 - 220, 2                 -- near the top, 220 pixels left of the middle of the screen.
local boxW2 = 80                                           -- display width variables
local boxW3 = 80                                           -- display width of the script button

-- Constants
local p1=math.rad(180)
local p2=2*p1
local dr=p1/180
local k1=15*dr*1.0027379
local zone0=0
local script_SunRiseSet = false
local uly_to_km = 9460730.4725808

-- Internationalization strings
local text_sunriseset       = _("Sun Rise/Set")
local text_longitude        = _("Longitude:")
local text_latitude         = _("Latitude:")
local text_date             = _("Date:")
local text_azimuth          = _("Azimuth:")
local text_sunrise_at       = _("Sunrise at:")
local text_sunset_at        = _("Sunset at:")
local text_sundown          = _("Sun DOWN all day.")
local text_sunup            = _("Sun UP all day.")
local text_nosunrise        = _("NO Sunrise this date.")
local text_nosunset         = _("NO Sunset this date.")
local text_invalid_location = _("Invalid location in config file.")
local text_month1           = _(" Jan ")
local text_month2           = _(" Feb ")
local text_month3           = _(" Mar ")
local text_month4           = _(" Apr ")
local text_month5           = _(" May ")
local text_month6           = _(" Jun ")
local text_month7           = _(" Jul ")
local text_month8           = _(" Aug ")
local text_month9           = _(" Sep ")
local text_month10          = _(" Oct ")
local text_month11          = _(" Nov ")
local text_month12          = _(" Dec ")
local text_script           = _("Script")

local monthname={text_month1, text_month2,  text_month3,  text_month4,
                 text_month5, text_month6,  text_month7,  text_month8,
                 text_month9, text_month10, text_month11, text_month12}
local display1_text1a, display1_text2a, display1_text3a, display1_text4a, display1_text5a, display1_text6a, display2_text4a, display2_text5a, display2_text6a
local display1_text1b, display1_text2b, display1_text3b, display1_text4b, display1_text5b, display1_text6b, display2_text4b, display2_text5b, display2_text6b
local SRS_obs, SRS_earth, SRS_orig_ambient, SRS_orig_renderflags, SRS_static_date, SRS_tdb_juliandate, SRS_static, Old_SRS_long_earth, Old_SRS_lat_earth
local SRS_i, SRS_script, SRS_obs_pos, SRS_earth_pos, SRS_obs_earth, SRS_distance

-- Personalize
local display_SunRiseSet = SunRiseSet_visible or false
local text_color = SunRiseSet_color or {0.7, 0.7, 0.5, 0.9}
local fill_color = SunRiseSet_fillcolor or {0.2, 0.5, 0.1, 0.3}
local shortcut = SunRiseSet_shortcut or "Q"

local SRS_long_earth = SRSS_long_earth or nil                         -- Longitude in degrees
local SRS_lat_earth  = SRSS_lat_earth or nil                          -- Latitude in degrees
local SRS_location_name = SRSS_location_name or ""                    -- Fill in your own location name between the 2 quotes, belonging to your longlat position

local SRS_SunRiseSet_Showlocation = SunRiseSet_Showlocation or false  -- Determine if you want Celestia to display the location
                                                                      -- for which the Sunnrise and Sunset will be calculated.

local SRS_date_Year = SRSS_date_Year or nil                           -- Year
local SRS_date_Month = SRSS_date_Month or nil                         -- Month
local SRS_date_Day = SRSS_date_Day or nil                             -- Day

local SRS_ambient = SunRiseSet_Ambient or 0.05

-- Determine if a predefined date is used
if SRS_date_Year ~= nil and SRS_date_Month ~= nil and SRS_date_Day ~= nil then
   SRS_static_date = true
   SRS_tdb_juliandate = celestia:utctotdb(SRS_date_Year, SRS_date_Month, SRS_date_Day, 12)
else
   SRS_static_date = false
end

-- Determine if a static location is used
if SRS_long_earth ~= nil and SRS_lat_earth ~= nil and SRS_location_name ~= "" then
   SRS_static = true
   -- Test/adjust Longitude and Latitude
   if SRS_lat_earth < -90 then
      SRS_lat_earth = -90
   elseif SRS_lat_earth > 90 then
      SRS_lat_earth = 90
   end
   if SRS_long_earth <= -360 or SRS_long_earth>=360 then
      SRS_long_earth = 0
   end
   if SRS_long_earth<0 then
      SRS_long_earth=SRS_long_earth+360
   end
   if SRS_long_earth>180 then
      SRS_long_earth=SRS_long_earth-360
   end
else
   SRS_static = false
   Old_SRS_long_earth = nil
   Old_SRS_lat_earth = nil
end

-- Test if valid loacal timezone, otherwise UTC will be used.
local SRS_test = false
for SRS_i, value in ipairs(SRS_local_timezone_table) do
   if SRS_local_timezone_table[SRS_i] == SRS_local_timezone then
      SRS_test = true
   end
end
if not SRS_test then
   SRS_local_timezone="UTC"
end
local local_offset = SRS_offset[SRS_local_timezone]

---------------------
-- local functions --
---------------------

local toggleSunRiseSetDisplay = function()
   SunRiseSetFrame.Visible = not SunRiseSetFrame.Visible
   SunRiseSetFrame2.Visible = SunRiseSetFrame.Visible
   SunRiseSetFrame3.Visible = SunRiseSetFrame.Visible
   SunRiseSetFrame4.Visible = SunRiseSetFrame.Visible
   SunRiseSetFrame:orderfront() 
   if SunRiseSetFrame.Visible then
      SRS_orig_renderflags = celestia:getrenderflags()
      SRS_orig_ambient = celestia:getambient()
      SRS_obs = celestia:getobserver()
      SRS_earth = celestia:find("Sol/Earth")
      celestia:setambient(SRS_ambient)
      SRS_earth:unmark()
      celestia:setrenderflags{markers=true}
      if not SRS_SunRiseSet_Showlocation then
         SRS_obs:gotodistance(SRS_earth, 4*SRS_earth:radius(), 0.0)
         SRS_obs:synchronous(SRS_earth)
      end
      if SRS_static_date then
         celestia:settime(SRS_tdb_juliandate)
      end
   else
      SRS_earth:unmark()
      celestia:setrenderflags{markers=SRS_orig_renderflags.markers}
      celestia:setambient(SRS_orig_ambient)
   end
end

local function sign(value)
   -- Returns the sign of the parameter value.
   -- Returns 1 if the value is greater than zero, zero if equal to zero and -1 if negative.
   if value > 0 then
      return 1
   elseif value < 0 then
      return -1
   else
      return 0
   end
end

local SRS_get_long_lat = function (SRS_get_long_lat_observer, SRS_source)
   -- Return longitude and latitude for the observer on the SRS_source object
   local f = SRS_source:getinfo().oblateness
   if f == nil then
      f = 0
   end
   local u_pos = SRS_get_long_lat_observer:getposition()
   local e_frame = celestia:newframe("bodyfixed", SRS_source)
   local e_pos = e_frame:to(u_pos)
   local lambda = -math.atan2(e_pos.z, e_pos.x);
   local beta = math.pi / 2 - math.atan2(math.sqrt(e_pos.x * e_pos.x + e_pos.z * e_pos.z), e_pos.y)
   local phi = math.atan2(math.tan(beta), (1 - f))
   local long = math.deg(lambda)
   local lat = math.deg(phi)
   return long, lat
end

local function SunRiseSet_location()
   if SRS_static then
      -- Static location
	  return true
   else
      -- Dynamic location
      local actual_selection = celestia:getselection()
      SRS_location_name = ""
      local locationbased = false
      if actual_selection:type() == "location" then
         local parent_object = actual_selection:getinfo().parent
         if parent_object:name() == "Earth" then
            SRS_location_name = actual_selection:localname()
            if SRS_location_name == "?" then
               SRS_location_name = actual_selection:name()
            end
            SRS_obs:setframe(celestia:newframe("universal"))
            local now = celestia:gettime()
            local pos_actual_selection = actual_selection:getposition(now)
            local pos_earth = SRS_earth:getposition(now)
            local u_pos = pos_earth + 4*(pos_actual_selection - pos_earth)
            local f = SRS_earth:getinfo().oblateness
            if f == nil then
               f = 0
            end
            local e_frame = celestia:newframe("bodyfixed", SRS_earth)
            local e_pos = e_frame:to(u_pos)
            local lambda = -math.atan2(e_pos.z, e_pos.x);
            local beta = math.pi / 2 - math.atan2(math.sqrt(e_pos.x * e_pos.x + e_pos.z * e_pos.z), e_pos.y)
            local phi = math.atan2(math.tan(beta), (1 - f))
            SRS_long_earth = math.deg(lambda)
            SRS_lat_earth = math.deg(phi)
            locationbased = true
         end
      end
	   if not locationbased then
         SRS_long_earth, SRS_lat_earth = SRS_get_long_lat(SRS_obs, SRS_earth)
      end
      return true
   end
end

local function SunRiseSet_calculate()
   local i, L, v, u, w, A5, R5, z1, C, Z, M8, W8, A0, D0, DA, DD, test_SRS_nr
   local C0, P, A2, D1, D2, D7, L0, L2, H0, H1, H2, H3, H7, V0, V1, V2, A, B, D, E, M3, T3, N7, text, AZ
   local HH_UTC_1st, MM_UTC_1st, AZ_1st, text_1st, HH_UTC_2nd, MM_UTC_2nd, AZ_2nd, text_2nd
   local tdb2, tdb2_local, local_dt, year_local_2nd, month_local_2nd, day_local_2nd, HH_local_2nd, MM_local_2nd
   local tdb1, tdb1_local, year_local_1st, month_local_1st, day_local_1st, HH_local_1st, MM_local_1st
   local actual_tdbtime, ut = {}, year_UTC, month_UTC, day_UTC, g, d1, f, j, s, a, j3, t, tt, t0, S
   local ra_sun1, ra_sun2, dec_sun1, dec_sun2, dist1, dist2
   
   -- Get the Calendar date from Celestia --> JD
   actual_tdbtime = celestia:gettime()
   ut = celestia:tdbtoutc(actual_tdbtime)
   year_UTC  = ut.year
   month_UTC = ut.month
   day_UTC   = ut.day
   -- NO "1583: Calendar reform" issue in Celestia (according original BASIC program)
   d1=math.floor(day_UTC)
   f=day_UTC-d1-0.5
   j=-math.floor(7*(math.floor((month_UTC+9)/12)+year_UTC)/4)
   s=sign(month_UTC-9)
   a=math.abs(month_UTC-9)
   j3=math.floor(year_UTC + s*math.floor(a/7))
   j3=-math.floor((math.floor(j3/100) + 1)*3/4)
   j=j + math.floor(275*month_UTC/9) + d1 + j3
   j=j + 1721029 + 367*year_UTC
   if f<0 then
      f=f+1
      j=j-1
   end
   -- Julianday 2451545 = 1-1-2000 12:00
   t=(j-2451545) + f
   -- tt = centuries from 1900.0
   tt=t/36525 + 1
   -- Local Sidereal Time at 0h zone time
   t0=t/36525
   S=24110.5 + 8640184.813*t0
   S=S + 86636.6*zone0 + 86400*SRS_long_earth/360
   S=S/86400
   S=S-math.floor(S)
   t0=S*360*dr

   t=t+zone0
   -- Position loop
   for i=1,2 do
      -- Fundamental arguments (Van Flandern & Pulkkinen, 1979)
      L=0.779072 + 0.00273790931*t
      L=L-math.floor(L)
      L=L*p2
      g=0.993126 + 0.0027377785*t
      g=g-math.floor(g)
      g=g*p2
      v=0.39785*math.sin(L)
      v=v - 0.01000*math.sin(L - g)
      v=v + 0.00333*math.sin(L + g)
      v=v - 0.00021*tt*math.sin(L)
      u=1 - 0.03349*math.cos(g)
      u=u - 0.00014*math.cos(2*L)
      u=u + 0.00008*math.cos(L)
      w=-0.00010 - 0.04129*math.sin(2*L)
      w=w + 0.03211*math.sin(g)
      w=w + 0.00104*math.sin(2*L - g)
      w=w - 0.00035*math.sin(2*L + g)
      w=w - 0.00008*tt*math.sin(g)
      -- Compute Sun's RA and Dec
      S=w/math.sqrt(u - v*v)
      A5=L + math.atan(S/math.sqrt(1 - S*S))
      S=v/math.sqrt(u)
      D7=math.atan(S/math.sqrt(1 - S*S))
      R5=1.00021*math.sqrt(u)
      if i==1 then
         ra_sun1=A5
         dec_sun1=D7
         dist1=R5
      else
         ra_sun2=A5
         dec_sun2=D7
         dist2=R5
      end
      t=t+1
   end

   if ra_sun2<ra_sun1 then
      ra_sun2=ra_sun2+p2
   end

   -- Zenith dist.
   z1=dr*90.833
   S=math.sin(SRS_lat_earth*dr)
   C=math.cos(SRS_lat_earth*dr)
   Z=math.cos(z1)
   M8=0
   W8=0

   A0=ra_sun1
   D0=dec_sun1
   DA=ra_sun2-ra_sun1
   DD=dec_sun2-dec_sun1
   test_SRS_nr=0
   for C0=0,23 do
      P=(C0 + 1)/24
      A2=ra_sun1 + P*DA
      D2=dec_sun1 + P*DD
      -- Test an hour for an event
      L0=t0 + C0*k1
      L2=L0 + k1
      H0=L0 - A0
      H2=L2 - A2
      -- Hour angle,
      H1=(H2 + H0)/2
      -- declination, at half hour
      D1=(D2 + D0)/2
      if C0<=0 then
         V0=S*math.sin(D0) + C*math.cos(D0)*math.cos(H0) - Z
      end
      V2=S*math.sin(D2) + C*math.cos(D2)*math.cos(H2) - Z
      if sign(V0)<sign(V2) or sign(V0)>sign(V2) then
         V1=S*math.sin(D1) + C*math.cos(D1)*math.cos(H1) - Z
         A=2*V2 - 4*V1 + 2*V0
         B=4*V1 - 3*V0 - V2
         D=B*B - 4*A*V0
         if D>=0 then
            D=math.sqrt(D)
            if V0<0 and V2>0 then
               text=text_sunrise_at
               M8=1
            end
            if V0>0 and V2<0 then
               text=text_sunset_at
               W8=1
            end
            E=(-B + D)/(2*A)
            if E>1 or E<0 then
               E=(-B - D)/(2*A)
            end
            T3=C0 + E + 1/120
            -- Round off
            H3=math.floor(T3)
            M3=math.floor((T3 - H3)*60)
            H7=H0 + E*(H2 - H0)
            N7=-math.cos(D1)*math.sin(H7)
            D7=C*math.sin(D1) - S*math.cos(D1)*math.cos(H7)
            AZ=math.atan(N7/D7)/dr
            if D7<0 then
               AZ=AZ + 180
            end
            if AZ<0 then
               AZ=AZ + 360
            end
            if AZ>360 then
               AZ=AZ - 360
            end
            if test_SRS_nr==0 then
               HH_UTC_1st=H3
               MM_UTC_1st=M3
               AZ_1st=AZ
               text_1st=text
               test_SRS_nr=1
            else
               HH_UTC_2nd=H3
               MM_UTC_2nd=M3
               AZ_2nd=AZ
               text_2nd=text
               test_SRS_nr=2
            end
         end
      end
      A0=A2
      D0=D2
      V0=V2
   end

   -- Display
   if M8==0 and W8==0 then
      if V2<0 then
         display1_text1a = SRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", SRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", SRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display1_text5a = text_sundown
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = ""
         display2_text4b = ""
         display2_text5a = ""
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      end
      if V2>0 then
         display1_text1a = SRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", SRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", SRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display1_text5a = text_sunup
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = ""
         display2_text4b = ""
         display2_text5a = ""
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      end
   else
      if M8==0 then
         tdb2=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb2_local=tdb2+local_offset
         local_dt=celestia:tdbtoutc(tdb2_local)
         year_local_2nd=local_dt.year
         month_local_2nd=local_dt.month
         day_local_2nd=local_dt.day
         HH_local_2nd=local_dt.hour
         MM_local_2nd=local_dt.minute
         display1_text1a = SRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", SRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", SRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display1_text5a = text_nosunrise
         display1_text5b = ""
         display1_text6a = ""
         display1_text6b = ""
         display2_text4a = text_date
         display2_text4b = day_local_2nd .. monthname[month_local_2nd] .. year_local_2nd
         display2_text5a = text_1st
         display2_text5b = string.format("%02i:%02i ", HH_local_2nd, MM_local_2nd) .. SRS_local_timezone
         display2_text6a = text_azimuth
         display2_text6b = string.format("%5.2f°", AZ_1st)
      elseif W8==0 then
         tdb1=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb1_local=tdb1+local_offset
         local_dt=celestia:tdbtoutc(tdb1_local)
         year_local_1st=local_dt.year
         month_local_1st=local_dt.month
         day_local_1st=local_dt.day
         HH_local_1st=local_dt.hour
         MM_local_1st=local_dt.minute
         display1_text1a = SRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", SRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", SRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_local_1st .. monthname[month_local_1st] .. year_local_1st
         display1_text5a = text_1st
         display1_text5b = string.format("%02i:%02i ", HH_local_1st, MM_local_1st) .. SRS_local_timezone
         display1_text6a = text_azimuth
         display1_text6b = string.format("%5.2f°", AZ_1st)
         display2_text4a = text_date
         display2_text4b = day_UTC .. monthname[month_UTC] .. year_UTC
         display2_text5a = text_nosunset
         display2_text5b = ""
         display2_text6a = ""
         display2_text6b = ""
      else
         tdb1=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_1st, MM_UTC_1st)
         tdb1_local=tdb1+local_offset
         local_dt=celestia:tdbtoutc(tdb1_local)
         year_local_1st=local_dt.year
         month_local_1st=local_dt.month
         day_local_1st=local_dt.day
         HH_local_1st=local_dt.hour
         MM_local_1st=local_dt.minute
         tdb2=celestia:utctotdb(year_UTC, month_UTC, day_UTC, HH_UTC_2nd, MM_UTC_2nd)
         tdb2_local=tdb2+local_offset
         local_dt=celestia:tdbtoutc(tdb2_local)
         year_local_2nd=local_dt.year
         month_local_2nd=local_dt.month
         day_local_2nd=local_dt.day
         HH_local_2nd=local_dt.hour
         MM_local_2nd=local_dt.minute
         display1_text1a = SRS_location_name
         display1_text1b = ""
         display1_text2a = text_longitude
         display1_text2b = string.format("%5.2f°", SRS_long_earth)
         display1_text3a = text_latitude
         display1_text3b = string.format("%5.2f°", SRS_lat_earth)
         display1_text4a = text_date
         display1_text4b = day_local_1st .. monthname[month_local_1st] .. year_local_1st
         display1_text5a = text_1st
         display1_text5b = string.format("%02i:%02i ", HH_local_1st, MM_local_1st) .. SRS_local_timezone
         display1_text6a = text_azimuth
         display1_text6b = string.format("%5.2f°", AZ_1st)
         display2_text4a = text_date
         display2_text4b = day_local_2nd .. monthname[month_local_2nd] .. year_local_2nd
         display2_text5a = text_2nd
         display2_text5b = string.format("%02i:%02i ", HH_local_2nd, MM_local_2nd) .. SRS_local_timezone
         display2_text6a = text_azimuth
         display2_text6b = string.format("%5.2f°", AZ_2nd)
      end
   end
end



----------------------------------------------
-- Set up and Draw the boxes
----------------------------------------------
SunRiseSetBox = CXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
    :attach(screenBox, sx, sy, 0, 0);

--
-- Box to show the Sun Rise/Set variables
--

SunRiseSetFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text(text_sunriseset)
    :movetext(-5,4)
    :fillcolor(fill_color)
    :movable(true)
    :clickable(false)
    :visible(display_SunRiseSet)
    :attach(screenBox, posX1, sy-posT1-boxH1, sx-boxW1-posX1, posT1)

-- Variable area
SunRiseSetFrame2 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("")
    :movetext(-5,4)
    :movable(false)
    :clickable(true)
    :visible(display_SunRiseSet)
    :attach(SunRiseSetFrame, boxW1-boxW2, 0, 0, 0)

-- Script button
SunRiseSetFrame3 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text(text_script)
    :textpos("center")
    :fillcolor(fill_color)
    :movetext(0, 8)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(display_SunRiseSet)
    :attach(SunRiseSetFrame, boxW1/2-boxW3/2, 2, boxW1/2-boxW3/2, boxH1-lspace-2)

-- Close button
SunRiseSetFrame4 = CXBox:new()
    :init(0, 0, 0, 0)
    :textfont(normalfont)
    :textcolor(text_color)
    :text("x")
    :textpos("center")
    :fillcolor(fill_color)
    :movetext(0, 10)
    :bordercolor(text_color)
    :movable(false)
    :active(true)
    :visible(display_SunRiseSet)
    :attach(SunRiseSetFrame, boxW1-10, boxH1-10, 0, 0)
   
SunRiseSetFrame.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*2+2)
   SRS_obs=celestia:getobserver()
   if SunRiseSet_location() then
      -- Valid static location or dynamic calculation determined by Celestia
      if SRS_SunRiseSet_Showlocation and (Old_SRS_long_earth ~= SRS_long_earth or Old_SRS_lat_earth ~= SRS_lat_earth or SRS_static) then
         -- Display the location for which the Sunnrise and Sunset will be calculated.
         Old_SRS_long_earth = SRS_long_earth
         Old_SRS_lat_earth = SRS_lat_earth
         SRS_obs:gotolonglat(SRS_earth, math.rad(SRS_long_earth), math.rad(SRS_lat_earth), 4*SRS_earth:radius(), 0.0)
      end
      SRS_obs:synchronous(SRS_earth)
      -- Test possibility if script is running (by observer position) with different ambient light level.
      SRS_obs_pos = SRS_obs:getposition()
      SRS_earth_pos = SRS_earth:getposition()
      SRS_obs_earth = SRS_obs_pos - SRS_earth_pos
      SRS_distance = SRS_obs_earth:length() * uly_to_km
      if SRS_distance <= (SRS_earth:radius() + 10) or (SRS_distance >= 4.04 * SRS_earth:radius() and SRS_distance <= 4.06 * SRS_earth:radius()) then
         SRS_script = true
      else
         SRS_script = false
      end
      -- Reset ambient light level if necessary, except when script is running
      if math.abs(celestia:getambient() - SRS_ambient) > 0.01 and not SRS_script  then
         SRS_orig_ambient=celestia:getambient()
         celestia:setambient(SRS_ambient)
      end
      -- Reset markers if turned off and mark location on Earth
      local SRS_renderflags = celestia:getrenderflags()
      if not SRS_renderflags.markers then
         celestia:setrenderflags{markers=true}
      end
      SRS_earth:unmark()
      if SRS_SunRiseSet_Showlocation then
         SRS_earth:mark("red", "diamond", 10, 1, SRS_location_name, false)
      else
         SRS_earth:mark("yellow", "plus", 10, 1, "", false)
      end
      -- Calculate Sunrise and Sunset times for this date, including their Azimuth and show line items in the box.
      SunRiseSet_calculate()
      textlayout:println(display1_text1a)
      textlayout:println(display1_text2a)
      textlayout:println(display1_text3a)
      textlayout:println(display1_text4a)
      textlayout:println(display1_text5a)
      textlayout:println(display1_text6a)
      textlayout:println(display2_text5a)
      textlayout:println(display2_text6a)
   else
      -- Invalid static location entered in the configuration file.
      textlayout:println(text_invalid_location)
   end  
   -- Check changed screen dimensions and reposition the box if necessary
   oldsx, oldsy = sx, sy
   sx, sy = celestia:getscreendimension()
   if sx ~= oldsx or sy ~= oldsy then
      posX1, posT1 = sx/2 - boxW1 - 220, 2
      SunRiseSetFrame:attach(screenBox, posX1, sy-posT1-boxH1, sx-boxW1-posX1, posT1)
   end
end

-- Show Calculated line items, all aligned in a separate box, attached to the primary box.
SunRiseSetFrame2.Customdraw = function(this)
   textlayout:setfont(normalfont)
   textlayout:setfontcolor(text_color)
   textlayout:setlinespacing(lspace)
   textlayout:setpos(this.lb,this.tb-lspace*2+2)
   textlayout:println(display1_text1b)
   textlayout:println(display1_text2b)
   textlayout:println(display1_text3b)
   textlayout:println(display1_text4b)
   textlayout:println(display1_text5b)
   textlayout:println(display1_text6b)
   textlayout:println(display2_text5b)
   textlayout:println(display2_text6b)
   SunRiseSetFrame2:attach(SunRiseSetFrame, boxW1-boxW2, 0, 0, 0)
end

-- Script button
SunRiseSetFrame3.Customdraw = function(this)
    SunRiseSetFrame3:attach(SunRiseSetFrame, boxW1/2-boxW3/2, 3, boxW1/2-boxW3/2, boxH1-lspace-2)
end

-- Close button
SunRiseSetFrame4.Customdraw = function(this)
    SunRiseSetFrame4:attach(SunRiseSetFrame, boxW1-10, boxH1-10, 0, 0)
end

--
-- Box in the Toolkit of Lua_Edu_Tools to select/deselect the application (instead of [key shortcut]).
--

if lua_edu_tools then
   SunRiseSetSwitch = CXBox:new()
       :init(0, 0, 0, 0)
       :bordercolor(cbubordoff)
       :textfont(normalfont)
       :textcolor(cbutextoff)
       :textpos("center")
       :movetext(0, 8)
       :text(text_sunriseset)
       :movable(false)
       :active(true)
       :attach(SunRiseSetBox, 8, 4, 8, 3)

   SunRiseSetSwitch.Action = (function()
        return
            function()
                display_SunRiseSet = not display_SunRiseSet
                if display_SunRiseSet then
                   SunRiseSetSwitch.Bordercolor=cbubordon
                   SunRiseSetSwitch.Fillcolor = {cbubordon[1]*2/3, cbubordon[2]*2/3, cbubordon[3]*2/3, cbubordon[4]/2}
                   SRS_orig_renderflags = celestia:getrenderflags()
                   SRS_orig_ambient=celestia:getambient()
                   SRS_obs = celestia:getobserver()
                   SRS_earth = celestia:find("Sol/Earth")
                   celestia:setambient(SRS_ambient)
                   SRS_earth:unmark()
                   celestia:setrenderflags{markers=true}
                   if not SRS_SunRiseSet_Showlocation then
                      SRS_obs:gotodistance(SRS_earth, 4*SRS_earth:radius(), 0.0)
                      SRS_obs:synchronous(SRS_earth)
                   end
                   if SRS_static_date then
                      celestia:settime(SRS_tdb_juliandate)
                   end
                   SunRiseSetFrame.Visible = true
                   SunRiseSetFrame2.Visible = true
                   SunRiseSetFrame3.Visible = true
                   SunRiseSetFrame4.Visible = true
                   SunRiseSetFrame:orderfront() 
                else
                   SunRiseSetSwitch.Bordercolor=cbubordoff
                   SunRiseSetSwitch.Fillcolor = nil
                   SRS_earth:unmark()
                   celestia:setrenderflags{markers=SRS_orig_renderflags.markers}
                   celestia:setambient(SRS_orig_ambient)
                   SunRiseSetFrame.Visible = false
                   SunRiseSetFrame2.Visible = false
                   SunRiseSetFrame3.Visible = false
                   SunRiseSetFrame4.Visible = false
               end
            end
        end) ();
else
   keymap[shortcut] = toggleSunRiseSetDisplay
end

-- Script button
SunRiseSetFrame3.Action = (function()
     return
         function()
             script_SunRiseSet = not script_SunRiseSet
             if script_SunRiseSet then
                celestia:runscript("../../scripts/SunriseSunset_20.celx")
                script_SunRiseSet = not script_SunRiseSet
             end
         end
     end) ();

-- Close button
SunRiseSetFrame4.Action = (function()
     return
         function()
             if lua_edu_tools then
                SunRiseSetSwitch.Bordercolor=cbubordoff
                SunRiseSetSwitch.Fillcolor = nil
             end
             display_SunRiseSet = not display_SunRiseSet
             SRS_earth:unmark()
             celestia:setrenderflags{markers=SRS_orig_renderflags.markers}
             celestia:setambient(SRS_orig_ambient)
             SunRiseSetFrame.Visible = false
             SunRiseSetFrame2.Visible = false
             SunRiseSetFrame3.Visible = false
             SunRiseSetFrame4.Visible = false
         end
     end) ();
