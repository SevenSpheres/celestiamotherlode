-- Sun Rise/Set

SunRiseSet_loc_str = {
   ["Sun Rise/Set"] = "Zon Opkomst/Ondergang";
   ["Longitude:"] = "Lengtegraad:";
   ["Latitude:"] = "Breedtegraad:";
   ["Date:"] = "Datum:";
   ["Azimuth:"] = "Azimut:";
   ["Sunrise at:"] = "Zonsopkomst om:";
   ["Sunset at:"] = "Zonsondergang om:";
   ["Sun DOWN all day."] = "Zon is de hele dag ONDER.";
   ["Sun UP all day."] = "Zon is de hele dag OP.";
   ["NO Sunrise this date."] = "GEEN Zonsopkomst deze dag.";
   ["NO Sunset this date."] = "GEEN Zonsondergang deze dag.";
   ["Invalid location in config file."] = "Ongeldige locatie in config bestand.";
   [" Jan "] = " jan ";
   [" Feb "] = " feb ";
   [" Mar "] = " mrt ";
   [" Apr "] = " apr ";
   [" May "] = " mei ";
   [" Jun "] = " jun ";
   [" Jul "] = " jul ";
   [" Aug "] = " aug ";
   [" Sep "] = " sep ";
   [" Oct "] = " okt ";
   [" Nov "] = " nov ";
   [" Dec "] = " dec ";
   ["Script"] = "Script";
}
