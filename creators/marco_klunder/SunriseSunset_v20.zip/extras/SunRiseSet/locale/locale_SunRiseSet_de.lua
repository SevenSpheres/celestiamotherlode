-- Sun Rise/Set

SunRiseSet_loc_str = {
   ["Sun Rise/Set"] = "Sonne Aufgang/Untergang";
   ["Longitude:"] = "Längengrad:";
   ["Latitude:"] = "Breitengrad:";
   ["Date:"] = "Datum:";
   ["Azimuth:"] = "Azimut:";
   ["Sunrise at:"] = "Sonnenaufgang am:";
   ["Sunset at:"] = "Sonnenuntergang am:";
   ["Sun DOWN all day."] = "Sonne ganztägig UNTER Horizont.";
   ["Sun UP all day."] = "Sonne ganztägig ÜBER Horizont.";
   ["NO Sunrise this date."] = "KEIN Sonnenaufgang an diesem Datum.";
   ["NO Sunset this date."] = "KEIN Sonnenuntergang an diesem Datum.";
   ["Invalid location in config file."] = "Ungültiger Speicherort in Config-Datei.";
   [" Jan "] = " Jan ";
   [" Feb "] = " Feb ";
   [" Mar "] = " Mrz ";
   [" Apr "] = " Apr ";
   [" May "] = " Mai ";
   [" Jun "] = " Jun ";
   [" Jul "] = " Jul ";
   [" Aug "] = " Aug ";
   [" Sep "] = " Sep ";
   [" Oct "] = " Okt ";
   [" Nov "] = " Nov ";
   [" Dec "] = " Dez ";
   ["Script"] = "Skript";
}
