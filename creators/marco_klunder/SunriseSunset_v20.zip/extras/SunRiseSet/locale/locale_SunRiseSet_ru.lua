-- Sun Rise/Set

SunRiseSet_loc_str = {
   ["Sun Rise/Set"] = "Восходы/Закаты Солнца";
   ["Longitude:"] = "Долгота:";
   ["Latitude:"] = "Широта:";
   ["Date:"] = "Дата:";
   ["Azimuth:"] = "Азимут:";
   ["Sunrise at:"] = "Восход в:";
   ["Sunset at:"] = "Закат в:";
   ["Sun DOWN all day."] = "Солнца нет в небе весь день.";
   ["Sun UP all day."] = "Солнце в небе весь день.";
   ["NO Sunrise this date."] = "Восхода Солнца на эту дату не существует.";
   ["NO Sunset this date."] = "Заката Солнца на эту дату не существует.";
   ["Invalid location in config file."] = "Неверная локация в конфигурационном файле.";
   [" Jan "] = " Янв ";
   [" Feb "] = " Фев ";
   [" Mar "] = " Мар ";
   [" Apr "] = " Апр ";
   [" May "] = " Май ";
   [" Jun "] = " Июн ";
   [" Jul "] = " Июл ";
   [" Aug "] = " Авг ";
   [" Sep "] = " Сен ";
   [" Oct "] = " Окт ";
   [" Nov "] = " Ноя ";
   [" Dec "] = " Дек ";
   ["Script"] = "Сценарий";
}
