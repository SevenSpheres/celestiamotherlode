-- Sun Rise/Set

SunRiseSet_loc_str = {
   ["Sun Rise/Set"] = "Sun Rise/Set";
   ["Longitude:"] = "Longitude:";
   ["Latitude:"] = "Latitude:";
   ["Date:"] = "Date:";
   ["Azimuth:"] = "Azimuth:";
   ["Sunrise at:"] = "Sunrise at:";
   ["Sunset at:"] = "Sunset at:";
   ["Sun DOWN all day."] = "Sun DOWN all day.";
   ["Sun UP all day."] = "Sun UP all day.";
   ["NO Sunrise this date."] = "NO Sunrise this date.";
   ["NO Sunset this date."] = "NO Sunset this date.";
   ["Invalid location in config file."] = "Invalid location in config file.";
   [" Jan "] = " Jan ";
   [" Feb "] = " Feb ";
   [" Mar "] = " Mar ";
   [" Apr "] = " Apr ";
   [" May "] = " May ";
   [" Jun "] = " Jun ";
   [" Jul "] = " Jul ";
   [" Aug "] = " Aug ";
   [" Sep "] = " Sep ";
   [" Oct "] = " Oct ";
   [" Nov "] = " Nov ";
   [" Dec "] = " Dec ";
   ["Script"] = "Script";
}
