-- Sun Rise/Set

SunRiseSet_loc_str = {
   --["Sun Rise/Set"] = "Sorgere/Tramontare del Sole";
   ["Sun Rise/Set"] = "Sorgere/Tramon. del Sole";
   ["Longitude:"] = "Longitudine:";
   ["Latitude:"] = "Latitudine:";
   ["Date:"] = "Data:";
   ["Azimuth:"] = "Azimut:";
   ["Sunrise at:"] = "Il Sole sorge alle:";
   ["Sunset at:"] = "Il Sole tramonta alle:";
   ["Sun DOWN all day."] = "Il Sole è GIÙ tutto il giorno.";
   ["Sun UP all day."] = "Il Sole è SU tutto il giorno.";
   ["NO Sunrise this date."] = "Il Sole NON sorge.";
   ["NO Sunset this date."] = "Il Sole NON tramonta.";
   ["Invalid location in config file."] = "Percorso non valido nel file di config.";
   [" Jan "] = " Gen ";
   [" Feb "] = " Feb ";
   [" Mar "] = " Mar ";
   [" Apr "] = " Apr ";
   [" May "] = " Mag ";
   [" Jun "] = " Giu ";
   [" Jul "] = " Lug ";
   [" Aug "] = " Ago ";
   [" Sep "] = " Set ";
   [" Oct "] = " Ott ";
   [" Nov "] = " Nov ";
   [" Dec "] = " Dic ";
   ["Script"] = "Script";
}
