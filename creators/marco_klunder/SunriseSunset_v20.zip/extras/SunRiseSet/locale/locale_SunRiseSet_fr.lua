-- Sun Rise/Set

SunRiseSet_loc_str = {
   ["Sun Rise/Set"] = "Lever/Coucher du Soleil";
   ["Longitude:"] = "Longitude:";
   ["Latitude:"] = "Latitude:";
   ["Date:"] = "Date:";
   ["Azimuth:"] = "Azimut:";
   ["Sunrise at:"] = "Lever du Soleil à :";
   ["Sunset at:"] = "Coucher du Soleil à :";
   ["Sun DOWN all day."] = "Soleil COUCHÉ toute la journée.";
   ["Sun UP all day."] = "Soleil LEVÉ toute la journée.";
   ["NO Sunrise this date."] = "PAS de lever du Soleil cette date.";
   ["NO Sunset this date."] = "PAS de coucher du Soleil cette date.";
   ["Invalid location in config file."] = "Emplacement non valide dans le fichier de configuration.";
   [" Jan "] = " jan ";
   [" Feb "] = " fév ";
   [" Mar "] = " mar ";
   [" Apr "] = " avr ";
   [" May "] = " mai ";
   [" Jun "] = " juin ";
   [" Jul "] = " juil ";
   [" Aug "] = " août ";
   [" Sep "] = " sep ";
   [" Oct "] = " oct ";
   [" Nov "] = " nov ";
   [" Dec "] = " déc ";
   ["Script"] = "Script";
}
