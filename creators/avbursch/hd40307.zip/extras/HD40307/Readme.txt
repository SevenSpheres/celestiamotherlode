Installation :  extract the zip file and place into celestia -> extras -> addons


    This addon depicts the possible appearance and characteristics
of the three recently discovered "super-Earths" in the HD 40307
system. There is a possible fourth terrestrial world in the system
as well.


HD 40307  -- basic info
-----------------------------

Spectral Type  :  K2.5V
Surface Temperature  :  4730 K
Mass :  1.4547 x 10e30 kg  (766 Mjup)
Luminosity  (visual)         :   0.191 Lsun
Luminosity  (bolometric)     :   0.22 Lsun
Absolute Magnitude : 6.64 (visual), 6.49 (bolometric)
Diameter : 665970 miles (1071545 km)
Surface Gravity     :  1107.19 ft/s^2  (337.40 m/s^2)
Escape Velocity     :  373.57 miles/sec  (601.07 km/s)
Metallicity : ~55%
Habitability Zone : Innermost   --  35.749 million miles  (57.52 million km)
	            Central     --  43.597 million miles  (70.14 million km)
                    Outermost   --  54.932 million miles  (88.38 million km) 
Distance from Sun :  41.8 ly


The Planets


Lemnos (confirmed)
        Classification :  Terrestrial Planet (Epistellar)
        Diameter :  12524 miles (20151 km)
        Mass :  2.509 x 10e25 kg  (4.2 Me)
        Semi-Major Axis :  0.0474 au
        Orbital Period : 4.31 d

        Lemnos is a world of fire, with lakes and rivers of molten metal. The 
   planet keeps the same side facing the star at all times. The planet has a
   relatively thick atmosphere composed of carbon dioxide, nitrogen, silicon
   vapor, and iron vapor. The planet's surface temperature is around 1300 kelvin
   (1880 F) on the day side and 950 kelvin (1232 F) on the night side. The reddish
   glow of molten metal is clearly visible on the night side.
      

Thebes (confirmed)
        Classification :  Terrestrial Planet (Epistellar)
        Diameter :  14030 miles (22574 km)
        Mass :  4.0025 x 10e25 kg  (6.7 Me)
        Semi-Major Axis :  0.08089 au
        Orbital Period : 9.62 d

        Thebes is also an extremely hot planet with many patches of the 
   surface that glow red hot. Like Lemnos, the planet is tidally locked to
   the star. The planet has an extremely thick atmosphere that is mostly
   carbon dioxide and nitrogen, with a small amount of silicon vapor, iron
   vapor, and sulfuric acid. In spite of the extremely dense atmosphere, the
   atmosphere is too hot for clouds to form, so the planet's surface is
   clearly visible from space. The planet's temperature is uniformly hot at
   around 1100 kelvin (1520 F) on the surface, as the thick atmosphere
   distributes heat to the night side very efficiently. 

Samothrace (confirmed)
        Classification :  Terrestrial Planet (Cytherian)
        Diameter :  16488 miles (26529 km)
        Mass :  5.6155 x 10e25 kg  (9.4 Me)
        Semi-Major Axis :  0.13389 au
        Orbital Period : 20.45 d

        Samothrace is a Venus-like world and has a Venus-like atmosphere.
   Due to having 4 times the stellar insolation that Venus gets, as well as
   having a much thicker atmosphere, this world is substantially hotter than
   Venus is. The planet glows faintly on the night side. Unlike Lemnos and
   Thebes, Samothrace likely has a thick layer of clouds that cover the entire
   planet. This planet is tidally locked if older than 5.055 billion years. 

Naxos (possible 4th planet, projected location)
        Classification :  Terrestrial Planet (Pelagic)
        Diameter :  13664 miles (21985 km)
        Mass :  3.2916 x 10e25 kg  (5.51 Me)
        Semi-Major Axis :  0.422 au
        Orbital Period : 114.43 d

        At the projected distance of 0.422 au, this planet would be hotter
   than Earth, but cooler than Venus. The planet has an ocean of water that
   is kept liquid in spite of the surface temperature of 605 kelvin (630 F)
   because of the immemse atmospheric pressure. The planet has an extremely
   dense atmosphere that comsists of carbon dioxide, nitrogen, water vapor,
   and oxygen. 

        

        

Mass units
---------------

(Pluto Mass)     1 Mpl  = 1.305 x 10e22 kg
(Earth Mass)     1 Me   = 457.7 Mpl  =  5.974 x 10e24 kg
(Jupiter Mass)   1 Mjup = 317.9 Me   =  1.899 x 10e27 kg
(Solar Mass)     1 Msun = 1047 Mjup  =  1.9884 x 10e30 kg

(Critical Mass -- Dwarf Planet)    0.03831 Mpl  = 5.0 x 10e20 kg
(Critical Mass -- Planet)          0.5335 Mpl   = 6.989 x 10e21 kg
(Critical Mass -- Brown Dwarf)    13 Mjup       = 2.468 x 10e28 kg
(Critical Mass -- Star)           75 Mjup       = 1.424 x 10e29 kg

Disclaimers
----------------

This addon is freeware. The intended use of and/or any modifications of 
this addon are permitted for the Celestia program only.  

Creation date : 07-2008
Submission date : 08-2008
Created by : AVBursch 