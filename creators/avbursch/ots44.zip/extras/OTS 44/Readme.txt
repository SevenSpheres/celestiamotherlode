Installation :  extract the zip file and place into celestia -> extras -> addons


     This addon is the OTS 44 system. The brown dwarf OTS 44 is not in
Celestia. The planets are fictional, but the brown dwarf has a disk of gas
and dust around it, so there is a good chance that the brown dwarf has
a fully-developed planetary system. OTS 44 was discovered in 2005.
This addon works with both 1.5.0pre4 and 1.5.0pre5.

OTS 44  -- basic info
-----------------------------

Spectral Type  :  M9.5V
Surface Temperature  :  2040 K
Mass :  2.8668 x 10e28 kg  (15.1 Mjup)
Luminosity  (visual)         :   5.2882 x 10e-6 Lsun
Luminosity  (bolometric)     :   3.2694 x 10e-4 Lsun
Absolute Magnitude : 18.1 (visual), 13.55 (bolometric)
Diameter : 133500 miles (214800 km)
Surface Gravity     :  544.02 ft/s^2  (165.86 m/s^2)
Escape Velocity     :  117.21 miles/sec  (188.59 km/s)
Metallicity : ~91%
Habitability Zone : Innermost   --  1378100 miles  (2217400 km)
	            Central     --  1680700 miles  (2704200 km)
                    Outermost   --  2016800 miles  (3245000 km) 
Distance from Sun :  554 ly 

The Planets

OTS 44Alpha
        Classification :  Terrestrial Planet (Cerean)
        Diameter :  1530 miles (2461 km)
        Mass :  1.7356 x 10e22 kg  (1.33 Mpl)
        Semi-Major Axis :  0.0166 au
        Orbital Period : 6.504 d

OTS 44Beta
        Classification :  Ice Planet
        Diameter :  2444 miles (3932 km)
        Mass :  8.9135 x 10e22 kg  (6.83 Mpl)
        Semi-Major Axis :  0.0944 au
        Orbital Period : 88.201 d

OTS 44Gamma
        Classification :  Ice Planet
        Diameter :  4116 miles (6622 km)
        Mass :  3.4412 x 10e23 kg  (26.37 Mpl)
        Semi-Major Axis :  0.3331 au
        Orbital Period : 1.6005 yr

OTS 44Delta
        Classification :  Ice Planet
        Diameter :  3365 miles (5414 km)
        Mass :  1.4929 x 10e23 kg  (11.44 Mpl)
        Semi-Major Axis :  0.727 au
        Orbital Period : 5.1608 yr

OTS 44Epsilon
        Classification :  Ice Planet
        Diameter :  1285 miles (2067 km)
        Mass :  1.0048 x 10e22 kg  (0.77 Mpl)
        Semi-Major Axis :  1.4663 au
        Orbital Period : 14.782 yr

Mass units
---------------

(Pluto Mass)     1 Mpl  = 1.305 x 10e22 kg
(Earth Mass)     1 Me   = 457.7 Mpl  =  5.974 x 10e24 kg
(Jupiter Mass)   1 Mjup = 317.9 Me   =  1.899 x 10e27 kg
(Solar Mass)     1 Msun = 1047 Mjup  = 1.9884 x 10e30 kg

(Critical Mass -- Dwarf Planet)    0.03831 Mpl  = 5.0 x 10e20 kg
(Critical Mass -- Planet)          0.5335 Mpl   = 6.989 x 10e21 kg
(Critical Mass -- Brown Dwarf)    13 Mjup       =  2.468 x 10e28 kg
(Critical Mass -- Star)           75 Mjup       =  1.424 x 10e29 kg

Disclaimers
----------------

This addon is freeware. The intended use of and/or any modifications of 
this addon are permitted for the Celestia program only.  

Creation date : 11-2007
Submission date : 12-2007
Created by : AVBursch