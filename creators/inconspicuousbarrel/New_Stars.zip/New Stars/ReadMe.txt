Place in your extras or addons folder.

Dust disk texture taken from the Epsilon Aurigae addon available on the Motherlode.
Brown dwarf texture for AB Pic b is Praesepe's.