Jan-March 2010 Exoplanets:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains 19 new exoplanets discovered in early 2010. This add on also includes the stars for a few.

Included in this add-on:

47 Ursae Majoris d
COROT-9b
HAT-P-14
HD 4313 b
HD 9446 b
HD 9446 c
HD 86226 b
HD 95089 b
HD 129445 b
HD 136418 b
HD 152079 b
HD 156668 b
HD 164604 b
HD 175167 b
HD 180902 b
HD 181342 b
HD 206610 b
HD 212771 b
HIP 79431 b

Please note that information is still pending regarding these exoplanets.
I tried to keep the information the most accurate as possible, however with time it is bound to improve.
I am also aware that some exoplanets have not been made into add-ons for the year 2009 so I will be working on that when I have the time.
