61 Vir Exoplanets:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the three exoplanets orbiting 61 Vir.
Please refer to the link below. 
It will give you some basic information regarding the star and it's planets.


http://en.wikipedia.org/wiki/61_Virginis