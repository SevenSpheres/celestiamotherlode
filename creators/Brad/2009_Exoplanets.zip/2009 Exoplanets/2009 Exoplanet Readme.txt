2009 Exoplanets:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

-----------

This addon for Celestia contains 71 exoplanets all discovered in 2009. 
This add on also includes the stars for a few of them.
Please note that none of these were included in the Celestia program, which is why I made an add on for them.

Took me a few hours too do, and a few hours testing them.
I would include a list of all of them but after working so hard on this it would be too time consuming.
If you wish to know which ones I have put in here please refer to: http://en.wikipedia.org/wiki/Category:Exoplanets_discovered_in_2009
About 96% of the exoplanets came from that site's list.
Information is still pending regarding these exoplanets
.
I tried to keep the information the most accurate as possible, however with time it is bound to improve.
A few of these have been from a few of my seperate add ons but I decided to combine them all into one based on year of discovery.
Anyone is welcome to change the coding of this script if they wish and to make corrections or add additional information.
I am aware for most of them I used the HD designations. If you wish to change them go ahead.

Currently as of March 2010 there are 443 Exoplanets that have been discovered. 
If you combine the total of the exoplants that came with celestia 1.6V (333), and the ones included with my 2010 add-on (20) you will get a total of 424.
I have made six more add ons for a few discovered before 2009. That would put the total too 430. There are a few I have come across on Celestia Motherloade
So grand total should be around 437, I guess that covers most of them. ^^

Enjoy ^^

Regards,
		Bradley Kassian