WASP-17 & Exoplanet:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the star WASP-17 and it's exoplanet.
Please refer to the link below. 
It will give you some basic information regarding the star and it's planets.


http://en.wikipedia.org/wiki/WASP-17

Please note that this addon is not perfect and information is still pending.