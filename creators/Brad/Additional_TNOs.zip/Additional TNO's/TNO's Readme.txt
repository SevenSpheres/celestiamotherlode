Additional TNO's:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the Trans-Neptunian objects from the Kuiper belt and the Scatterd disk region. 
In total there are 8 Cubewenos, 4 plutinos, 6 SDO's. 
All of these have been considerd dwarf planet candiates. Some maybe reclassified as such in the future. 
If you downloaded my previous addon for (225088) 2007 OR10, you may delete it, as I have included it in this package as well. 
As always these are free to redistribute, or edit if your into scripting.

Please extract the folder to your Celestia addons folder in order for these to work. 

Cubewenos: 	2009 YE7
		(202421) 2005 UQ513
		(55565) 2002 AW197
		(79360) 1997 CS29
		(119951) 2002 KX14
		2003 QW90
		(35671) 1998 SN165
		(120347) 2004 SB60

Plutinos:		2003 UZ413
		2001 QF298
		(47171) 1999 TC36
		2007 JH43

SDO's:		(229762) 2007 UK126
		(42301) 2001 UR163
		2008 ST291
		(145451) 2005 RM43
		2005 QU182
		(225088) 2007 OR10