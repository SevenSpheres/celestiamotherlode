April-Oct 2010 Exoplanets:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains 38 new exoplanets discovered in April 2010-Oct 2010. This add on also includes the stars for a few.

Included in this add-on:

2MASS J04414489+2301513
CoRot-7 d
CoRot-8
CoRot-10
CoRot-11
Corot-12
CoRot-13
CoRot-14
Gliese 876 e
Gliese 581 g
HAT-P-15 b
HAT-P-17 b
HAT-P-20 b
HAT-P-21 b
HAT-P-22 b
HAT-P-23 b
HAT-P-24 b
HD 10180 b-h
HD 15082 b
HD 38801 b
HIP 104202 b & c
HD 109246 b
HD 145457 b
HIP 57050 b
WASP-21
WASP-22
WASP-24
WASP-25
WASP-26
WASP-28
WASP-29
Please note that information is still pending regarding these exoplanets.
I tried to keep the information the most accurate as possible, however with time it is bound to improve.
I am also aware that some exoplanets have not been made into add-ons for the year 2009 so I will be working on that when I have the time.
