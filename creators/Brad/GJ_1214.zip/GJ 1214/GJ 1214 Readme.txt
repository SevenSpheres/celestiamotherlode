GJ 1214 & Exoplanet:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the star GJ 1214 and it's exoplanet.
Please refer to the link below. 
It will give you some basic information regarding the star and it's planets.


http://en.wikipedia.org/wiki/GJ_1214

Please note that this addon is not perfect and information is still pending.
Also if anyone is interested in correcting some of the information let me know.
