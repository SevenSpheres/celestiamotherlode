HIP 107087 Exoplanet:

Compiled by Bradley Kassian
bkassian@gmail.com


Exoplanet Discovered in 2009. I do apologize for not including this in my 2009 exoplanet release. It must have evaded my radar ^.^ . Anyway enjoy :3




This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

Please note that this addon is not perfect and information is still pending.