Haumeids:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the Trans-Neptunian objects from the Kuiper belt.
In total there are 3 Haumeids. 
All of these have been considerd dwarf planet candiates. Some maybe reclassified as such in the future. 
