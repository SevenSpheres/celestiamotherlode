OGLE-2006-BLG-109L Star & Exoplanets:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the star OGLE-2006-BLG-109L and it's two known exoplanets.
Please refer to the link below. 
It will give you some basic information regarding the star and it's planets.


http://en.wikipedia.org/wiki/OGLE-2006-BLG-109L

Please note that this addon is not perfect and information is still pending.