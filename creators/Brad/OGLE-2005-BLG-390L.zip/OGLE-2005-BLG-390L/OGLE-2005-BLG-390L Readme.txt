OGLE-2005-BLG-390L Star & Exoplanet:

Compiled by Bradley Kassian
bkassian@gmail.com

This is an add-on for Celestia. The directory containing this
file should be placed in the extras folder of your Celestia
installation.

---

This addon for Celestia contains the star OGLE-2005-BLG-390L and it's known exoplanet.
Please refer to the link below. 
It will give you some basic information regarding the star and it's planets.


http://en.wikipedia.org/wiki/OGLE-2005-BLG-390L

Please note that this addon is not perfect and information is still pending.