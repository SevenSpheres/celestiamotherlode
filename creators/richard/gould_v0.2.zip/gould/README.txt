Gould Addon for Celestia
========================

Version 0.2 (5 Sep 2011)
Supports Celestia version 1.6.1 only.

Introduction
============

This addon provides Gould designations for southern stars as assigned by Benjamin Gould in his Uranometria Argentina of 1879. Other minor corrections (e.g. spelling of star names) have also been made. Obsolete and Chinese star names have been removed.

In addition, the following 22 southern constellations have been updated in further ways: Octans, Mensa, Hydrus, Chamaeleon, Apus, Pavo, Indus, Tucana, Volans, Carina, Musca, Circinus, Triangulum Australe, Dorado, Ara, Horologium, Reticulum, Pictor, Centaurus, Crux, Norma, Phoenix:

* Morton Wagman's "Lost Stars" has been consulted for additions and corrections to designations created by Bayer, Flamsteed, Lacaille, and Baily. A few additional historical designations close to the South Pole have been included. Primarily, those designations that are historically valid but dropped by Gould because the star didn't meet his magnitude cut-off limit, are reinstated.

* Many missing (but standard) Lacaille roman letter designations are restored.

Star Names
==========

The star names currently contained in Celestia are not always compatible with those in Simbad, includes some typos and rarely-used secondary names, as well as Chinese names (from Allen) of dubious authenticity. As this addon inserts several designations, the id list for each star can become long; therefore, the author has removed some obsolete names. For example, Alhabor (for Sirius) was judged obscure enough for removal. In the same vein, all Chinese star names (e.g. "Kin Yu", "Kaou Pih") have also been removed.

This is unlikely to break existing addons unless they refer to these obsolete names directly. However it is not impossible, and those using this addon should bear this in mind. The Gould addon makes changes to 4 data files (v0.1 only modified one) to attain consistency across the Celestia application.

This results in greater accurracy with current usage and a closer compatibility with Simbad; the same changes could easily be made to the main Celestia database in the future.

Installation Requirements
=========================

This Addon is designed for use with Celestia v 1.6.1. It is not compatible with previous versions.

If you are installing this on Windows 7, you will need to make changes as Administrator user if your Celestia installation is under C:\Program Files.

Installation Procedure
======================

Reminder for Windows 7 users: If Celestia is installed under c:\Program Files, you will need to perform all these operations as Administrator user, otherwise Celestia will ignore the newly-installed files.

1. Copy the zip file into the extras directory of your Celestia installation

2. Unzip it. This will create one subdirectory, gould, with four data files in it:
   * globulars.dsc
   * nearstars.stc
   * spectbins.stc
   * starnames.dat
   
   It also contains a new configuration file, which will be moved in step 4 below:

3. Make a backup copy of your celestia.cfg file, which is in your main Celestia directory (one up from extras).

   copy celestia.cfg celestia.cfg.orig

4. Copy the new celestia.cfg supplied in the addon into the main Celestia directory:

	copy extras\gould\celestia.cfg .\celestia.cfg

	This file file refers to the new data files contained in this addon.
  
Uninstallation Procedure
========================

1. Copy your backup copy of celestia.cfg into its original location:

   copy celestia.cfg.orig celestia.cfg

2. (optional)

Remove the directory extras/gould

Version History
===============

Version 0.1 (29 Jan 2011)

1. Those Gould designations already in Celestia masquerading as Flamsteed numbers (e.g. 82 Eridani, 41 Arae) are corrected. 

2. In addition, Morton Wagman's "Lost Stars" has been consulted for additions and corrections to designations created by Bayer, Flamsteed, Lacaille, and Baily. A few additional historical designations close to the South Pole have been included. Primarily, those designations that are historically valid but dropped by Gould because the star didn't meet his magnitude cut-off limit, are reinstated. Version 0.1 is updated for the following 9 constellations: 1. Octans; 2. Mensa; 3. Hydrus; 4. Chamaeleon; 5. Apus; 6. Pavo; 7. Indus; 8. Tucana; 9. Volans.

3. Other minor corrections (e.g. corrections of mispellings of star names) have also been made. Chinese names have been removed.

Copyright
=========

This Addon, and accompanying documents were created by Richard Pulley (richardontheweb @ gmail . com) for use with Celestia and are copyright � 2011. All rights reserved.

License
=======

This Addon may be freely redistributed for educational purposes so long as all of the provided files are included.

This Addon may not be used for any commercial or pecuniary benefit without explicit written permission from the author.

Email: richardontheweb @ gmail . com
www:   http://uranometria.blogspot.com/p/celestia.html
