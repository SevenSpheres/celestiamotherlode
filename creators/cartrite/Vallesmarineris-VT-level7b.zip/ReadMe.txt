This is a closeup VT which means you would need another full VT of Mars. I was using John van Vliet's VT of Mars
and the areas to the east and south match his VT. Also the Mars VT textures will have to be in png format.
That being said put the level7 in the texture folder were 
all the other levelx folders are for you Mars VT (hires/mars-png,medres/mars-png,etc.. When you are close enough in Celestia the VT
will be drawn. The Themis part is from NASA/JPL/ASU and is unaltered in color. IT WILL
NOT BLEND IN WITH ANY VT OF MARS THAT I KNOW OF. The areas to the east and south are from John van Vliet's Mars VT.
Image Credit: Themis part of the texture is from: NASA/JPL/ASU
              Background part of the texture is from John van Vliet's Mars VT.

The following is the data citation that came with the original Themis image.

Acknowledgement of the THEMIS site and its resources will help ensure the continuing support 
necessary for the validation, archiving, and distribution of THEMIS images.

For news media or educational purposes, please credit THEMIS images as: 
NASA/JPL/Arizona State University.

If you use THEMIS images or mosaics in a research work, 
please cite them by image ID or mosaic name in the caption 
and put the following in your references:

Christensen, P.R., N.S. Gorelick, G.L. Mehall, and K.C. Murray, THEMIS Public Data Releases, 
Planetary Data System node, Arizona State University, <http://themis-data.asu.edu>.

If you mention the THEMIS instrument in a research work, please cite it as follows in your references:

Christensen, P.R., B.M. Jakosky, H.H. Kieffer, M.C. Malin, H.Y. McSween, Jr., K. Nealson, G.L. Mehall, 
S.H. Silverman, S. Ferry, M. Caplinger, and M. Ravine, The Thermal Emission Imaging System (THEMIS) 
for the Mars 2001 Odyssey Mission, Space Science Reviews, 110, 85-130, 2004.

