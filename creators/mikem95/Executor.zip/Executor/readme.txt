This addon places the Executor in orbit over Earth.
Unzip to your extras folder

Model by Thomas Ganshorn at SciFi3D.com



http://www.scifi3d.com/author_details.asp?key=13