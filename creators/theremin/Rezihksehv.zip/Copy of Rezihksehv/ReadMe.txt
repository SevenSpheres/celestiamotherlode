(c)2009 Theremin

Original Map (c) Cyan Worlds

This is a map of the Pod Planet from Myst Online Uru Live (unofficially known as "Rezihksehv"). The rotation and axial tilt have been calculated to match elements present in the gameplay.

The star is speculatively a supergiant, to allow for a wider orbit and the rapid precession of the planet. Much of the positioning of the continents is also speculative, as the map is not specific in regards to these details.

More info: "http://en.mystlore.com/wiki/Pod#Pods"

urutheremin@gmail.com