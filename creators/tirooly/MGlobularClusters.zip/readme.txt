M ESSIERs
G LOBULAR
C LUSTERS pack - ver. 1.0 - 23 feb 05 - by Jean-Luc Vaucher


INSTALL NOTE :


- Place the entiere folder in "Celestia/extras/"

- Remove any conflictual file.
  For example, the file "messier_globular.dsc" who comes with 
  "110 Messier Objects" pack from Selden Ball

- Enjoy !



This package contain only but all Messier's Globular Clusters :
29x *.dsc, *.3ds (models/) and *.png (textures/medres/) file for

M2, 3, 4, 5, 9, 10, 12, 13, 14, 15, 19, 22, 28, 30, 53,
54, 55, 56, 62, 68, 69, 70, 71, 72, 75, 79, 80, 92 & 107

It's build as 256x256 bitmap pictures* projected on 3D crossing facet models.
So you should have a near real view of these gigant spheres of stars
as they look like tracked from earth but you can also turn around them 
-when targeted- and have a "3d look-like" extrapolated view.

Note that I'm novice and i can't explain why they appear well
when you turn around them near the "from-the-earth" view and why
they look bad around the opposite side. 
Please apologize for my wrong english too...


* source : web (NOAO & few others)