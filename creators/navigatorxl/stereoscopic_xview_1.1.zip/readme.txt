Creator / Date
--------------
navigatorXL / Oktober 2012


Licence
-------
Feel free to use the script for whatever you want.
Keep in mind the celestia licence model.


Celestia version
----------------
Developed under celestia v1.6.1


Installation
------------
Copy 'stereoscopic_xview.celx' to your Celestia scripts directory (usually <Celestia main directory>\scripts).


Summary
-------
This celestia celx script provides a 3D view of the sky.
This allows to get an impression of the depth relations and the shape of the viewed objects.
It shows a stereogram by means of a stereoscopic cross-eyed view, this provides a 3dimensional image of the currently viewed region.
For further information on this topic have a look at http://en.wikipedia.org/wiki/Stereoscopy.
Technically, this script creates two viewes in celestia, looking at the same direction, in which the observer positions are separated.


Usage
-----
1)	Move the object you want to see in 3D to the center of the screen.
	If viewed constallations it is recommended to stay in the solar system (in order to maintain the known constallation shape).
	For this, use "Left mouse button" (for viewing direction) and "Shift" + "Left mouse button" or "." / "," (for field of view) only.
	For other objects (planets, stars, space crafts) it is recommended to go to the object.
	Change orientation as required ("Arrow left" / "Arrow right")
2)	Start the script.
	If the object disappears, the movement distance to obtain the stereoscopic effect is to high. In this case press "a" (several times if
	required) to reduce the movement distance step size.
3)	Use the cross-eyed view to get a 3dimensional image of the region.
4)	Adjust the scale of the 3D effect by pressing "+" or "-".


Notes
-----
1)	You can also try the built in demo tour by pressing "d" repeated times after the script started.
2)	The initial <stepsize> value is 0.1 lightyears, so the observer positions are separated by 0.2ly after the script starts.
	This is good for viewing constellations but by far to much for planets and smaller objects.
	Decrease <stepsize> (by pressing "a" repeatedly) accordingly as required.
3)	The observer's distance is increased by 2x<stepsize> each time "+" is pressed.
	The observer's distance is decreased by 2x<stepsize> each time "-" is pressed.
	The <stepsize> parameter is multiplied by 100 each time "q" is pressed.
	The <stepsize> parameter is divided by 100 each time "a" is pressed.
4)	Fail safe guide for finding the right <stepsize>:
	- Reduce the stepsize (press "a" repeatedly) until your observed object (e.g. earth) appears on both screen parts.
	- Reduce the stepsize even further until the observed object isn't moving anymore.
	- Increase the stepsize (by pressing "q" repeatedly) until your observed object separate a bit in both screen parts.
	  Your observed object should jump a bit to the left side on the left screen part, and a bit to the right on the right screen part.
	- That's it. Now use the "+" and "-" keys to adjust the scale of the 3D effect.
	Good values for observer separation / <stepsize> are:
		Constellations				0.1 ly
		Stars						0.00001 ly
		Planets						1e-9 ly
		Spacecrafts					1e-15 ly
5)	In order to minimize irritations it is recommended to use the script in full screen mode.
	If you are bothered by the vertical separator bar at the screen center, switch it off in the celestia options.
6)	The script keeps the current frame (follow, lock, ...).
7)	The celestia time manipulation keys (j, k, l, c, !) work within the script.
8)	Do not use the arrow keys since they change the position of the primary observer (left window part) only.
9)	This script is my tribute to David Chandler's "Deep Space 3-D" which inspired me alot.
10)	Last but not least: Big "Thanks!" to the Celestia Team for the great work!


Script specific keys
--------------------
+/-			Increase / decrease the scale of the stereoscopic effect (i.e. observer distance by 2*<stepsize>)
d			Demo (several demonstration objects)
s			Save screenshot to the "ScriptScreenshotDirectory" parameter in the celestia.cfg (default: celestia main directory)
q/a			Multiply / divide <stepsize> by 100
e			Exit script

Versions
--------
v1.0	13. Okt. 2012	original release
v1.1	16. Okt. 2012	some bugfixing (switch off ecliptic during demo, time & time scale correctly restored after demo)
			added display duration as a parameter
			Andromeda added to demo tour