Texture for 2003 UB313 by Jamie A Peery (AKA Planet X on the Celestia Forums)

This file contains a texture for the newly discovered Kuiper Belt Object 2003 UB313, a mysterious body discovered to be orbiting the sun far beyond Pluto. It may eventually be labeled as the solar system's tenth planet.  Larger than Pluto, 2003 UB313 has a distinct greyish color.  This texture portrays a surface that is grey in color, but rather bright.

Installation: To install, simply unzip the file into Celestia's "extras" folder. If you don't have the SSC data for 2003 UB313, I have provided a SSC file you may use.  If you already have the data, simply edit the texture data on 2003 UB313 to tenthplanet.jpg or tenthplanet.*.

NOTE: This texture was created using Celestia Version 1.32, but should work on all versions of Celestia as well as all graphics cards.

Copyright: This 2003 UB313 texture is completely free of charge, no strings attatched, but ONLY for the Celestia program.  Any other desired use must be through explicit permission from me.  I can be contacted at: pioneerxtower@aol.com. Also, you might want to get permission from the main developers of Celestia to use this texture on other programs. Last but not least, enjoy the add-on!

J P