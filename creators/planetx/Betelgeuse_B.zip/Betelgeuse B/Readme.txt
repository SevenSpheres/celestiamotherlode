The Betelgeuse B System, aka The Planets of Astro Warrior, Version 1.7

Copyright�2006 by J P (Planet X)
e-mail: pioneerxtower@aol.com

System statistics:
The Betelgeuse B System consists of one star, three planets, and five moons.  Betelgeuse B is an L-Type red dwarf star that's
1/10th the size of our sun, with 1/30 our Sun's mass.  L-Type stars are intermediate between regular Red Dwarf stars and
Brown Dwarf "Super Jupiters."  The first planet is called Zanoni.  This world is three fourths the size and 40 percent the
mass of Earth.  Even though it is located at the liquid/ice line from the parent star, Zanoni is warm enough for it's surface
to be completely covered in liquid water.  This is due to tidal stress from the parent star and the second planet outward,
called Nebiros.  It is by far the largest planet in the Betelgeuse B System. Nebiros is a gas giant planet, two thirds the
size of Saturn.  It is slightly heavier than Saturn (100 times Earth's mass), however, due to a much higher density of 2.2
times that of water.  By far the most massive planet, Nebiros has tremendous control over every other body in this system,
including the parent star!  For one thing, the system's barycenter lies above the star's surface due to Nebiros's high mass
relative to Betelgeuse B.  Not only that, Nebiros's powerful gravitational field prevents any orbital inclination of it's
neighboring planets, as well as it's five moons.  Speaking of which, the largest moon, Haldar is a world that is intermediate
in size between Mercury and Mars.  Because it's density is 3.0 times that of water, however, Haldar is only slightly heavier
than Mercury.  Nonetheless, Haldar is large and massive enough to be regarded as part of a double-planet combination.
Nebiros's powerful gravity prevented the formation of other planets and other minor bodies nearby, but there is one other
world that did form and survive.  That world is Belzebul, the outermost planet of the Betelgeuse B System.  This world owes
it's survival to a special orbital resonance with Nebiros.  Belzebul orbits Betelgeuse B precisely 4 times further out than
Nebiros.  The result is an orbital period exactly 8 times longer than that of Nebiros, with an orbital slowness factor (OSF)
precisely 2 times that of Nebiros.  Belzebul is a frozen panthalassic planet that is 2.5 times the size and 7.6 times the
mass of Earth.  It is Triton-like in appearance, riddled with ice geysers/volcanoes due to tidal stress from Nebiros.


Instructions:
To use this addon, simply unzip the contents from the zip file into the celestia/extras/addons directory.  After that, open 
up Celestia.  Then, press enter and manually type either "Betelgeuse B" or "58 Ori B."  Finally, press enter again, followed 
by pressing "G" to go to the parent star.


This addon is freeware, meaning there are no strings attached, so to speak. The intended use of and/or any modifications of 
this addon are permitted for the Celestia program only.  Any other use of this texture requires explicit permission from 
the developers of the Celestia Program.

With that, I have a few important acknowledgements to make.  First, I would like to thank Tech Sgt. Chen for sharing his 
work on a variety of star textures.  It was his work that inspired me to create the "simple" texture for Betelgeuse B. 
Second, I owe thanks to Brian Mozier, a buddy of mine, for coming up with the clever name of Haldar for Nebiros's big moon.
Also, I give props to the Sega video game company for creating the unique video game that inspired me to create this system.  
Finally, I give much thanks to all the developers of Celestia for creating such a neat program that allows users to create 
addons like this in the first place!  All textures not previously mentioned are courtesy of Celestia and it's creators.  
Last but not least, enjoy the addon!

J P, aka. "Planet X"



Addon Revision History:
Version 1.0 - Innitial public release on 03/04/2006
Version 1.1 - Updated orbital data on the last two planets and large moon on 03/13/2006
Version 1.2 - Totally revamped the entire system and resubmitted addon on 05/14/2006
Version 1.3 - Reclassified Haldar as "planet" to reflect the double-planet relationship with Nebiros on 08/11/06
Version 1.4 - Added 4 additional moons orbiting Nebiros on 08/26/06
Version 1.5 - Rereleased addon to replace corrupt file on 02/14/2007
Version 1.6 - Adjusted parameters of Nebiros's rings to make them wider on 04-06-07
Version 1.7 - Changed atmospheric color parameters on Zanoni to give proper reddish color to sky on 09/27/07
Version 1.8 - Adjusted orbital parameters of all Nebiran moons to properly reflect Nebiros's mass on 10-03-07
Version 1.9 - Placed the orbits of Nebiros's three outermost moons further out on 11-30-07
Version 2.0 - Third release of addon to reflect all changes since version 1.5 on 12-12-07
