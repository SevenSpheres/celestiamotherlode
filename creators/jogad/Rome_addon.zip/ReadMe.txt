======================================== 
Virtual Textures: Rome and the Vatican 
======================================== 

Detailed view of Rome and its environs. 
Water bodies and the Tiber reflect light depending on the lighting. 

Accuracy is especially important as we approach the center of Rome. The Vatican in particular is represented with an accuracy of about 2.5m/pixel. 

In addition to the virtual texture you can see different places in Rome and surroundings. 
A script can also see whether the border of the Vatican. 

The textures of the virtual surface come with the format of 64K Jestr Earth Mark II maps (JMII). They are DXT3 *.DDS images with an alpha layer. The images size is 1024 x 1024 pixels.


Installation 
============ 

The installation assumes that the textures 64K Jestrai Earth Mark II (Level 0 to Level 5) are already installed.

- Unpack the archive "roma-files.zip"  IN THE MAIN DIRECTORY OF CELESTIA respecting the tree of directories.

If you use another Virtual Earth Texture, adapt the installation accordingly. Only the level 0 is really required, but the file format must be DDS and it is preferable that the image tile size is 1024 x 1024 pixel with a statement:
    BaseSplit 0 
    TileSize 512 
    TileType "dds" 
in the *.ctx file.


Uninstalling 
=============== 
When installing, a file "uninstall-roma.bat is copied in the main directory of Celestia. 
Double-clicking this file will completely uninstall the addon without disrupting the Jestr Earth Mark II textures .


Usage
=====
If you followed the recommendation to use these textures to complement the textures Jestr Earth Mark II, they will be defined in Celestia as alternatives surfaces. 
This means that in order to activate them you must right click on the Earth and choose "DDS JMII" in the list of alternative surfaces. 
To disable, simply click again on 'normal' in that list. 

* You can see the name of some places with the menu "Render->Locations..." by enabling: 
  - Cities         : towns nearby 
  - Montes         : The hills of Rome 
  - Other features : names of lakes and monuments 

* By default, the border the Vatican is disabled. You can enable or disable it with the script "Vatican border" that appears in the menu "File->Scripts" 


Keep in mind that these textures are large and use a lot of resources. It is therefore preferable to activate them only when necessary. 

Personally, I don't use the normal maps textures that come with JMII textures. On my machine it leads only to a slowdown without providing a real visual improvement. 

These textures are designed to be watched during the day with a well-lit scene. For a better view in Celestia, visit Rome during the summer days. 

Known Issues 
================ 
- To avoid a deadlock due to the texture size, it is preferable to activate the virtual texture and gradually approaching to allow the computer to load the texture. 

- It may be observed flickering of the names of places if you approach too close to perpendicular. The problem is solved by slightly tilting the view with the arrows up or down. 

- To avoid texture hops one can pause with the space key. 

- To activate or suppress the display of the border of the Vatican, Celestia should not be paused. Once the action performed, you may pause again if desired. 

 Rome and Vatican City are part of the standard version of Celestia and are not translated.

- The wording "Vatican City" is a little outside the boundaries of the Vatican. This is because the capitals description file provides only two digits after the decimal point for this location.
To remedy this I propose to increase the precision in the file "celestia\data\world-capitals.ssc" like this:

    Location "Vatican City" "Sol/Earth"
    {
    LongLat [12.4503 41.9043 0] # original: LongLat [12.45 41.9 0]
    Importance 7.07
    Type "City"
    }

Sources 
------- 
The maps are made from screenshots of various images freely available on the Internet. 
The original images can be viewed easily with Google Earth and come primarily from 

data
NASA, SIO, NOAA, US Navy, NGA, GEBCO

Images
�2009 European Space Imaging
�2009Cnes/SpotImage
�2009 Digital Globe
�2009 GeoEye
�2009 TerraMetrics

The screenshots were made with Google Earth(TM)

The outline of the Vatican's border comes from:
http://www.vaticanstate.va/NR/rdonlyres/31DF5DF3-9A59-4475-BDF7-C7F13139E9C9/2633/piantina_compressapdf.pdf


Other sources may be helpful: 
http://www.multimap.com/map 


LICENSE
-------
I made these textures for my personal use and they are provided only as an example, for information or for personal use. Any commercial use is prohibited. 


jogad
