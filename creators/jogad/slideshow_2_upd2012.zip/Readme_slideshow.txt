-----------------------------
-- Slideshow Version 2
-- August 2010 by Jogad
-- November 2012 by jldoreste
-----------------------------

Installation:

You must unzip the file slideshow_2.0.zip in the MAIN folder of Celestia
taking care to respect the subdirectories.

Then READ THE DOCs

There are 3 pdf files in the extras/slideshow folder
- slideshow_en_2.0.pdf (in English)
- diaporama_fr_2.0.pdf (in French)
- slideshow_nl_2.0.pdf (in Dutch) 


More explanations and details

http://www.shatters.net/forum/ (In English)


Versions
========

----------------------------------
November 2012: Always version 2 ;)
----------------------------------
Compatibility patch for GNU/Linux

-------------------------
Version 2 August 2010
-------------------------
Virtually all is new.
Even old things are new!

The most important new features are

- can launch HTML files
- can run celestia scripts (cel and celx)
- automatic run
- simplified usage
- lot of new tools for text and picture formatting
- magnetism
- alignment and resizing tool
- placement grid
- enhanced colors
- new font
- direct management of the slidewhows from Celestia
- unified behavior for texts and pictures :
    color and transparency for
    - foreground
    - background 
    - borders
- new deformables pictures
- possibility to uses "cliparts" whose color
  may be modified in real time.

- and "Edit mode" that allow to cut copy
  and edit the content of the slides.
- possibility to localize non only the plugin
  but also the slideshows.
- absolute or relative paths for images and files to launch
- management of the "time stopped" feature in the slides.
- Remember the last used slideshow and lauch it next time.



-------------------------
version 1.2 -- 04-17-2010
-------------------------
- supports individual transparency for pictures
- new palette tool to adjust text properties
  and image transparency
- the default palette has 32 colors
  these colors are editable
  and as many colors as needed can be added.
- minor other changes

-------------------------
Version 1.1 -- 04-05-2010
-------------------------
- text backgrounds and choice of fonts
- local config files support


-------------------------
Version 1.0 -- 03-30-2010
-------------------------
First release


------------
-- License 
------------
Just as lua plug-ins or Lua Edu Tools without which it could not operate, 
Slideshow can be freely used/copied/modified/distributed for non-commercial activities.


------------
-- Credits
------------
The original idea was inspired by Picture Box, one of the plug-ins distributed with the latest version of Lua plug-ins.
Cham and Vincent, thank you.

I shamelessly used the opportunity provided by the license of Lua plug-ins and Lua Edu Tools to copy and modify these addons.
Particularly the modules pCXBox.lua, plugins_locale.lua and _textlayout.lua are only slightly modified copies of the corresponding modules of lua plug-ins or Lua Edu Tools.

Incorporating sound files is an idea of Maximo (Fenerit)

GNU/Linux compatibility patch by jldoreste

Thanks for localization to 
	Marco Klunder : Dutch
	Fenerit : italian
	Adirondack : German
	J.L. Doreste : Spanish

