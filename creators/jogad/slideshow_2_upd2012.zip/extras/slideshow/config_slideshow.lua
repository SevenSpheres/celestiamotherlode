-- Slideshow configuration file

----------------------------------------
-- key shorcut to enable the slideshow
-- default key shortcut is "r"
----------------------------------------
slideshow_shortcut = "r"

------------------------------------
-- fast avance button
-- number of slides to go forward
-- default = 7
------------------------------------
SlideShowButtonFastStep = 5

---------------------------------------
-- control of automatic feed
---------------------------------------
slideshow_delay = 10  -- time in seconds, 0 to inactivate

----------------------------------
-- key for the hidden mode of the
-- control device
----------------------------------
device_visibility_key= "*" -- and reorder frames in design mode
forward_slide_key   = "+"
backward_slide_key = "-"
first_slide_key="<"   -- and decrease delay in auto mode
fast_slide_key= ">"  -- and increase delay in auto mode
-------------------------------------
-- Miscellaneaous
-------------------------------------
resize_square_visibility = 0.00  -- border visibility between 0 and 1
magnet_strength = 4 -- value from 1 to 10.  0 to inactivate

---------------------------------------
-- possible values :
--   "next_slide"  (default value)
--   "same_slide"
--   "random"
--   the number of the slide (without quotes)
---------------------------------------
resume_slideshow_at = "next_slide"

------------------------------------
-- custom color set
-- Three parameters separated by commas
-- and enclosed in curve brackets {}
-- parameters are R,G,B values (0-1)
-- number of colors is not limited
------------------------------------
slideTextColor =
{
{ 1.000 , 1.000 , 1.000 }, -- first color = default. Do not change
{ 1.000 , 1.000 , 0.000 },
{ 1.000 , 0.700 , 0.000 },
{ 1.000 , 0.400 , 0.000 },
{ 1.000 , 0.000 , 0.000 },
{ 1.000 , 0.000 , 0.700 },
{ 0.800 , 0.000 , 1.000 },
{ 0.500 , 0.000 , 1.000 },

{ 0.500 , 0.500 , 0.500 },
{ 0.667 , 1.000 , 0.000 },
{ 0.000 , 1.000 , 0.000 },
{ 0.000 , 1.000 , 1.000 },
{ 0.000 , 0.750 , 1.000 },
{ 0.000 , 0.500 , 1.000 },
{ 0.000 , 0.333 , 1.000 },
{ 0.251 , 0.000 , 1.000 },

{ 0.000 , 0.000 , 0.000 },
{ 0.000 , 0.302 , 0.150 },
{ 0.051 , 0.500 , 0.000 },
{ 0.000 , 0.500 , 0.500 },
{ 0.000 , 0.250 , 0.500 },
{ 0.000 , 0.000 , 0.500 },
{ 0.169 , 0.000 , 0.500 },
{ 0.302 , 0.000 , 0.400 },

{ 0.000 , 0.000 , 0.349 },
{ 0.000 , 0.161 , 0.251 },
{ 0.000 , 0.200 , 0.000 },
{ 0.165 , 0.251 , 0.000 },
{ 0.149 , 0.149 , 0.000 },
{ 0.165 , 0.000 , 0.000 },
{ 0.302 , 0.000 , 0.000 },
{ 0.500 , 0.000 , 0.000 },

{ 1.000 , 0.800 , 0.800 },
{ 1.000 , 1.000 , 0.800 },
{ 0.800 , 1.000 , 0.902 },
{ 0.800 , 0.800 , 1.000 },
{ 1.000 , 0.500 , 0.500 },
{ 1.000 , 1.000 , 0.650 },
{ 0.600 , 1.000 , 0.600 },
{ 0.600 , 0.600 , 1.000 },
}

------------------------------------
-- Available fonts ont files must be
-- in Celestia's fonts directory
------------------------------------

slideshowFonts =
{
	"sansbold20.txf", -- first font is default font
	"serif24.txf",
	"serifit24.txf",
	"serifit30.txf",
	"sansbold30.txf",
	"sansbold40.txf",
	"sans10.txf",
	"sans12.txf",
	"sans16.txf",
}

----------------------------------------
-- slides directory
-- a directory in extras/slideshow
-- default = last slideshow
---------------------------------------
--slideShowDirectory = "demo"

---------------------------------------------------
-- set to false if problems with some extensions
-- deactivate all extensions below (not only sound)
---------------------------------------------------
sound_available = true

------------------------------------
-- files extensions (not only sound)
-- add or remove depending on whether
-- they work or not on your system
------------------------------------
audioFileExt =
{ "wav", "mpg", "mp1", "mp2", "mp3", "mod", "ogg",
  "mov", "avi", "pdf",
  "htm", "html", "php",
  "cel","celx"}

------------------------------------------------------
-- command line to launch a file
-- which is associated with one of the above extensions
-- PLAYFILE will be automatically replaced
-- by the actual file. Keep this name (in uppercase)
-- You must adapt these lines to suit your OS
-- or to start files with other programs
------------------------------------------------------
running_OS = "Windows"
play_file_command = '"PLAYFILE"'
slide_edit_command = [[start "" "TEXTFILE"]]  -- launch with the default program
--slide_edit_command = [[start "" "d:\applic\notepad2\notepad2.exe" "TEXTFILE"]]
--slide_edit_command = [[start "" "c:\program files\notepad++\notepad++.exe" "TEXTFILE"]]

---------------------------------------------------------
-- If your OS is GNU/Linux un-comment the following lines
---------------------------------------------------------
--running_OS = "Linux"
--play_file_command = '"PLAYFILE"' -- Same as Windows
--slide_edit_command = [["kwrite" "TEXTFILE"]] -- running_OS = "Linux"

