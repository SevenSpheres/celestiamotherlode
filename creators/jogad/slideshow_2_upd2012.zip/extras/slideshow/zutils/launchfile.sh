#!/bin/sh 
# 
# 6 Nov. 2012

narg=$#
text_editor="kwrite"
img_viewer="gwenview"
html_viewer="firefox"
php_viewer="kwrite"
ogg_player="ogg123"     # A command-line audio player for ogg.
mp3_player="mpg123"     # A command-line audio player. but it only works with mp3.
#audio_player="kaffeine"
audio_player="kaffeine"
video_player="kaffeine"
#video_player="vlc"
#video_player="smplayer2"
pdf_viewer="okular"
open_doc="libreoffice3.6"

if [ $narg -eq 1 ] ; then
   filename=$1
   #echo "filename= $filename"
   if [ ! -f "$filename" ] ; then
      exit 1
   else
      # We need to know what type of file $filename is
      filetype=$(file -b --mime-type "$filename" | cut -d / -f 1)
      filetype2=$(file -b --mime-type "$filename" | cut -d / -f 2)
      #echo "filetype= $filetype"
      #echo "filetype2= $filetype2"
      # Let's do something with $filename'
      if [ $filetype == "image" ] ; then
         $img_viewer "$filename" &
      elif [ $filetype == "text" ] ; then
         if [ $filetype2 == "html" ] ; then
            $html_viewer "$filename" &
         elif [ $filetype2 == "x-php" ] ; then
            $php_viewer "$filename" &
         else
            $text_editor "$filename" &
         fi
      elif [ $filetype == "application" -a $filetype2 == "ogg" ] ; then 
         $ogg_player "$filename" &
      elif [ $filetype == "audio" ] ; then
         if [ $filetype2 == "mpeg" ] ; then
            $mp3_player "$filename" &
         else
            $audio_player "$filename" &
         fi
      elif [ $filetype == "application" -a $filetype2 == "ogg" ] ; then
         $video_player "$filename" &
      elif [ $filetype == "video" ] ; then
         $video_player "$filename" &
      elif [ $filetype == "application" -a $filetype2 == "pdf" ] ; then
         $pdf_viewer "$filename" &
      elif [ $filetype == "application" -a $filetype2 == "vnd.oasis.opendocument.text" ] ; then 
         $open_doc "$filename" &
      fi
   fi
else
   exit 1
fi
