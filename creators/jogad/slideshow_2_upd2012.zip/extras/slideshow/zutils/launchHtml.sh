#!/bin/sh 
# 
# 7 Nov. 2012

narg=$#
html_viewer="firefox"
#html_viewer="konqueror"

if [ $narg -eq 1 ] ; then
   filename=$1
   #echo "filename= $filename"
   $html_viewer "$filename"
else
   exit 1
fi
