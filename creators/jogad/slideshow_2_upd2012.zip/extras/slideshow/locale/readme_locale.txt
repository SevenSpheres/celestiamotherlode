Localization of Slideshow

You can bring your help by translating a few messages.
To do that

- open the file locale_slideshow_fr.lua
- replace the French translation by your own translation using an UTF-8 capable editor
- save as locale_slideshow_xx.lua, where xx are the two specific letters of your country.

If you do that, do not forget to share your work by posting the file on the Celestia addon forum so that I can add it to the pluging.

Thank you
Jogad