-- Spanish translation of Slideshow
-- Traducción de Presentación al español.

slideshow_loc_str =
{
	Slideshow = "Presentación";
	["slide #"] = "diapositiva #";
	["Missing image: "] = "No se encuentra la imagen: ";
	["NO SLIDE IN SLIDESHOW"] = "¡CATÁLOGO DE DIAPOSITIVAS VACÍO!";
	["This is the last slide..."] = "Última diapositiva...";
	["Slideshow catalog not open"] = "Error inesperado al abrir el catálogo";
	["Image"] = "Imagen";
	["Text"] = "Texto";
	["Background"] = "Fondo";
	["Border"] = "Borde";
	["Auto feed ON"] = "Avance automático ACTIVADO";
	["Auto feed OFF"] = "Avance automático DESACTIVADO";
	["default"] = "Por defecto";
	["Slide duration = "] = "Duración de la diapositiva = ";
	["Default slides duration = "] = "Duración por defecto de las diapositivas = ";
	["Slideshow ON: "] = "Presentación ACTIVADA: ";
	["Slideshow OFF"] = "Presentación DESACTIVADA";
	["Stealth mode"] = "Modo oculto";
	["Stealth mode OFF"] = "Modo oculto DESACTIVADO";
	["Stealth mode ON"]  = "Modo oculto ACTIVADO";
	["Celestia is paused"] = "Celestia en pausa";
	["Delay = "] = "Retraso = ";
	["Command tool hidden"] = "Herramienta de comandos oculta.";
	["press "] = "Pulsar ";
	[" to recover"] = " Verlo de nuevo";
	["Time is paused"] = "Tiempo en pausa";
	["Resume"] = "Resumen";
	["No slide to paste"] = "No hay diapositiva para añadir";
	["Slideshow catalog"] = "Catálogo de presentaciones";
	["New"] = "Nuevo";
	["Copy"] = "Copiar";
	["Cut"] = "Cortar";
	["Paste"] = "Pegar";
	["Edit"] = "Editar";
	["Cat."] = "Cat.";
	["OK"] = "OK";
	["Error in slide description"] = "Error en la descripción de la diapositiva";
	["(No slide defined)"] = "(No hay diapositiva definida)";
	["(More than one slide)"] = "(Más de una diapositiva)";
	["Slide is copied"] = "Diapositiva copiada";
	["Fail to create "] = "Fallo al crear ";
	[": this OS is not fully supported"] = ": this OS is not fully supported";

}
