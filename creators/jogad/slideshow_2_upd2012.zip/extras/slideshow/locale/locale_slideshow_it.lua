-- Italian translation of slideshow

slideshow_loc_str =
{
   Slideshow = "Diapositive";
   ["slide #"] = "diapositiva N°";
   ["Missing image: "] = "Immagine assente : ";
   ["NO SLIDE IN SLIDESHOW"] = "CATALOGO DIAPOSITIVE VUOTO!";
   ["This is the last slide..."] = "Questa è l'ultima diapositiva...";
   ["Slideshow catalog not open"] = "Errore nell'apertura del catalogo diapositive!";
   ["Text"] = "Testo";
   ["Background"] = "Sfondo";
   ["Image"] = "Immagine";
   ["Auto feed ON"] = "Avanzamento automatico attivo";
   ["Auto feed OFF"] = "Avanzamento automatico disattivo";
   ["default"] = "predefinito";
   ["Slide duration = "] = "Durata della diapositiva = ";
   ["Default slides duration = "] = "Durata predefinita della diaposiva= ";
   ["Slideshow ON: "] = "Catalogo diapositive attivato : ";
   ["Slideshow OFF"] = "Catalogo disattivato";
   ["Stealth mode"] = "Modo invisibile";
   ["Stealth mode OFF"] = "Modalità invisibile disattiva";
   ["Stealth mode ON"]  = "Modalità invisibile attiva";
   ["Celestia is paused"] = "Celestia è in pausa";
   ["Delay = "] = "Durata = ";
   ["Command tool hidden"] = "Barra degli strumenti nascosta.";
   ["press "] = "Premere ";
   [" to recover"] = " per mostrarla di nuovo";
   ["Time is paused"] = "Pausa ";
   ["Resume"] = "Riprendi";
   ["Border"] = "Bordo";
   ["No slide to paste"] = "Nessuna diapositiva da incollare";
   ["Slideshow catalog"] = "Catalogo diapositive";
   ["New"] = "Nuovo";
   ["Copy"] = "Copia";
   ["Cut"] = "Taglia";
   ["Paste"] = "Incolla";
   ["Edit"] = "Edita";
   ["Cat."] = "Cat.";
   ["OK"] = "OK";
   ["Error in slide description"] = "Errore nella descrizione";
   ["(No slide defined)"] = "(Nessuna diapositiva definita)";
   ["(More than one slide)"] = "(Serie di diapositive)";
   ["Slide is copied"] = "Diapositiva copiata";
   ["Fail to create "] = "Impossibile creare la dia. ";
   
}