-- English translation of Slideshow
--

slideshow_loc_str =
{
	Slideshow = "Slideshow";
	["slide #"] = "slide #";
	["Missing image: "] = "Missing image: ";
	["NO SLIDE IN SLIDESHOW"] = "SLIDE CATALOG IS EMPTY";
	["This is the last slide..."] = "This is the last slide...";
	["Slideshow catalog not open"] = "Unespected error when opening the catalog";
	["Image"] = "Image";
	["Text"] = "Text";
	["Background"] = "Background";
	["Border"] = "Border";
	["Auto feed ON"] = "Auto run ON";
	["Auto feed OFF"] = "Auto run OFF";
	["default"] = "default";
	["Slide duration = "] = "Slide duration = ";
	["Default slides duration = "] = "Default slides duration = ";
	["Slideshow ON: "] = "Active slideshow: ";
	["Slideshow OFF"] = "Slideshow OFF";
	["Stealth mode"] = "Stealth mode";
	["Stealth mode OFF"] = "Stealth mode OFF";
	["Stealth mode ON"]  = "Stealth mode ON";
	["Celestia is paused"] = "Celestia is paused";
	["Delay = "] = "Delay = ";
	["Command tool hidden"] = "The command tool is hidden.";
	["press "] = "Press ";
	[" to recover"] = " to see it again";
	["Time is paused"] = "Time is paused";
	["Resume"] = "Resume";
	["No slide to paste"] = "No slide to paste";
	["Slideshow catalog"] = "Slideshow catalog";
	["New"] = "New";
	["Copy"] = "Copy";
	["Cut"] = "Cut";
	["Paste"] = "Paste";
	["Edit"] = "Edit";
	["Cat."] = "Cat.";
	["OK"] = "OK";
	["Error in slide description"] = "Error in slide description";
	["(No slide defined)"] = "(No slide defined)";
	["(More than one slide)"] = "(More than one slide)";
	["Slide is copied"] = "Slide is copied";
	["Fail to create "] = "Fail to create ";
}
