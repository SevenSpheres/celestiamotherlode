-- Nederlandse vertaling van slideshow

slideshow_loc_str =
{
	Slideshow = "Diavoorstelling";
	["slide #"] = "Dianummer #";
	["Missing image: "] = "Ontbrekende afbeelding: ";
	["NO SLIDE IN SLIDESHOW"] = "GEEN DIA IN DIAVOORSTELLING";
	["This is the last slide..."] = "Dit is de laatste dia ...";
	["Slideshow catalog not open"] = "De catalogus van de diavoorstelling is niet geopend";
	["Image"] = "Afbeelding";
	["Text"] = "Tekst";
	["Background"] = "Achtergrond";
	["Border"] = "Rand";
	["Auto feed ON"] = "Automatisch opvolgen AAN";
	["Auto feed OFF"] = "Automatisch opvolgen UIT";
	["default"] = "standaard";
	["Slide duration = "] = "Looptijd van een dia = ";
	["Default slides duration = "] = "Standaard looptijd van dia's = ";
	["Slideshow ON: "] = "Slideshow AAN: ";
	["Slideshow OFF"] = "Slideshow UIT";
	["Stealth mode"] = "Verborgen mode";
	["Stealth mode OFF"] = "Verborgen mode UIT";
	["Stealth mode ON"]  = "Verborgen mode AAN";
	["Celestia is paused"] = "Celestia is gepauzeerd";
	["Delay = "] = "Vertraging = ";
	["Command tool hidden"] = "Opdracht hulpprogramma verborgen";
	["press "] = "druk op ";
	[" to recover"] = " te herstellen";
	["Time is paused"] = "Tijd is gepauzeerd";
	["Resume"] = "Vervolgen";
	["No slide to paste"] = "Geen dia om te plakken";
	["Slideshow catalog"] = "Slideshow catalogus";
	[": this OS is not fully supported"] = ": Dit OS wordt niet volledig ondersteund";
	["New"] = "Nieuw";
	["Copy"] = "Kopie";
	["Cut"] = "Knip";
	["Paste"] = "plak";
	["Edit"] = "Edit";
	["Cat."] = "Cat.";
	["OK"] = "OK";
	["Error in slide description"] = "Fout in dia beschrijving";
	["(No slide defined)"] = "(Geen dia gedefinieerd)";
	["(More than one slide)"] = "(Meer dan ��n dia)";
	["Slide is copied"] = "Dia is gekopieerd";
	["Fail to create "] = "Aanmaken mislukt van ";
}

