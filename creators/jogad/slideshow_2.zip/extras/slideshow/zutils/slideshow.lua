----------------------------------------------
-- Set initial values
----------------------------------------------
require "extras/slideshow/zutils/pCXBox"
require "extras/slideshow/zutils/_textlayout"
require "extras/slideshow/config_slideshow"

executeHTMLcmdFile=""
slideshowCommand = ""

-- lua_edu_tools compatibility and localization
if  lua_edu_tools and lang ~= "en"
	then require "extras/lua_edu_tools/locale/locale"
	else require "extras/slideshow/zutils/plugins_locale"
end
if pcall( function() require ("extras/slideshow/locale/locale_slideshow_"..lang) end ) then
	for engl, transl in pairs(slideshow_loc_str) do
		loc_str[engl]=transl
	end
end

local fonts= {}
slideshowFonts = slideshowFonts or {}
for i, f in ipairs(slideshowFonts) do
	fonts[i]=celestia:loadfont("fonts/"..f)
	if not fonts[i] then fonts[i]= celestia:gettitlefont() end
end
if not fonts[1] then fonts[1] = celestia:gettitlefont() end
local nbFonts = # fonts


local utilPath = "../zutils/"       -- id for buttons etc..
local exePath = "extras/slideshow/zutils/"
local sharedPath = "../commonPictures/"
local celestiaSharedPath = "extras/slideshow/commonPictures"

local slidesName = "demo"; -- default slideshow

if slideShowDirectory then
	slidesName = string.gsub(slideShowDirectory,"[\\/]","")
else
	local fic = io.open(exePath.."lastslideshow.txt","r")
	if fic then
		slidesName = fic:read()
		fic:close()
	end
end

local slidesPath =   "../"..slidesName.."/" -- zutils relative path for loadtexture
local celestiaSlidePath = "extras/slideshow/"..slidesName.."/"
local slideCatalog = celestiaSlidePath.."_slidecatalog.txt" --celestia path
if lang ~= "en" then
	local localCat = celestiaSlidePath.."_slidecatalog_"..lang..".txt"
	local fic = io.open(localCat,"r")
	if fic then
		fic:close()
		slideCatalog = localCat
	end
end

local diaporama = {}
local lastSlide = {["maxdia"]=0,["maxtxt"]=0}
local tempSlide = {["maxdia"]=0,["maxtxt"]=0}
local slideshowParams = {}
local diapoFrame={}
local textFrame ={}
local pictures = {}
local tele = {}
local palette = {}
local edit = {}
local key = {}
local diapo, text = {}, {}
local allowD, allowT = {}, {}
local display_diapo = false
local allow_urls = celestia.geturl
local designMode = false
local nbObjects, iObj = 0, 0
local width, height = celestia:getscreendimension()
local imgDefPosX, imgDefPosY = 0,0
local cr="\n"
local txtMarg = 5
local messages = ""
local nbdia, maxdia = 0, 0
local nbtxt, maxtxt = 0, 0
local img = 0 -- ref to the actual record of the displayed images 0 if no image
local lastImage = 0
local cslide = ctext
if not lua_edu_tools  then cslide={1, 1, 1, 0.9} end
local selFrame, refFrame
local selExt = 4
local biColor = {0.8, 0.8, 0.8, 0.4}
local beColor = {0.8, 0.8, 0.8, 0.8}
local selColor = {0, 1,   0, 0.5}
local refColor = {0, 0.5, 1, 0.6}
local inactiveColor = {0.5, 0.5,0.5,0.8}
local saveCoord = {}
local showSel, showRef = true, true
local oldTimeScale = 1

-- take values from config file.
play_file_command = play_file_command or '"PLAYFILE"'
local resumeAt = resume_slideshow_at
local sticky

if not slideTextColor or not slideTextColor[1] then
	slideTextColor ={}
	slideTextColor[1] = {1,1,1,1}
end
local nbColors = # slideTextColor

local fastStep = 7
if type(SlideShowButtonFastStep)=="number" then fastStep=SlideShowButtonFastStep end

-- auto feed feature
local slideshowDelay = tonumber(slideshow_delay) or 7
local slideDelay = slideshowDelay
local ready=true  -- allows new slide
local autotime, slideStart = 0, 0
local modifDelay, oldDelay = 0, 0
local soundAvailable = sound_available  -- from config file

--

local saveSsParams = function(name)
	slideshowParams[name] = {
		["slideshow_delay"] = slideshow_delay,
		["sound_available"] = sound_available,
		["resume_slideshow_at"] = resume_slideshow_at,
		["magnet_strength"] = magnet_strength,
		["slideTextColor"] = slideTextColor,
		["SlideShowButtonFastStep"] = SlideShowButtonFastStep,
		["slideTextColor"] = slideTextColor,
		}
end

saveSsParams("slideshow")

local readParameters = function(reread)
	local special_config = celestiaSlidePath.."config_"..slidesName
	if reread then
		for p,v in pairs(slideshowParams.slideshow) do _G[p] = v end
	end
	if slideshowParams[slidesName] then
		for p,v in pairs(slideshowParams[slidesName]) do _G[p] = v end
	else
		if pcall( function() require (special_config)end) then
			saveSsParams(slidesName)
		end
	end

	slideshowDelay = tonumber(slideshow_delay ) or 7
	slideDelay = slideshowDelay
	resumeAt = resume_slideshow_at
	soundAvailable = sound_available -- from config file

	if magnet_strength == nil then
		sticky = 4
	else
		sticky = tonumber(magnet_strength)
		if sticky then
			if sticky <1 or sticky >10 then sticky = nil end
		end
	end
	if not slideTextColor or not slideTextColor[1] then
		slideTextColor ={}
		slideTextColor[1] = {1,1,1,1}
	end
	nbColors = # slideTextColor

	if type(SlideShowButtonFastStep)=="number" then fastStep=SlideShowButtonFastStep end

	if running_OS == "Windows" then
		play_file_command = '"PLAYFILE"'
	end
end

readParameters()

-- telecommand description
local nbButtons = 7
local teleButton6Icon = {}
local btSize = 24 -- default size
local btMarg = btSize /2; -- space between buttons
local topbutmarg = math.max(btSize / 2, 16)
tele.height = btSize + topbutmarg + btMarg
tele.width = btSize * nbButtons + (nbButtons + 1)*btMarg


-- resize button
local resize = {}
	resize.square = 24
	resize.margin = 10
	resize.corner = resize.square+resize.margin
	resize.normalColor = {1,1,1,0}  -- invisible
	resize.normalBorder= {1,1,1,1} --  invisible
	resize.designColor = {0,0,0,0.5}
	resize.designBorder= {1,1,1,0.5}

if type(resize_square_visibility)=="number" then
	if resize_square_visibility >=0 and resize_square_visibility <=1 then
		resize.normalColor[4]=resize_square_visibility
		resize.normalBorder[4]=resize_square_visibility
	end
end
-- palette parameters
palette.nbMenuBut = 3
local colButSize = 24 -- total size with margin
local cmdButSize = 26
local colButMarg = 4
local closeButSize = 16
local cmdHeight = cmdButSize*2 + colButMarg + closeButSize
palette.totCursHeight = 36
palette.alignIcon = {}
palette.imgOrderIcon = {}
palette.magnetIcon = {}
palette.colRows = math.ceil(nbColors / 8)
palette.width = colButSize * 8 + colButMarg
palette.height = palette.totCursHeight + colButSize * palette.colRows + colButMarg + cmdHeight
palette.X = width-palette.width-200
palette.Y = height - palette.height -20
local colTarg = 0
local colTargText = {"Text","Background","Image","Background","Border"}


-- edit.frame tool description
edit.buttons = { "Copy", "Cut", "Paste", "New", "Edit", "Cat.", "OK",}
edit.operColor = {1,0.5,0,0.5}
edit.todoColor = {0,0.8,0,0.5}
edit.nBut = # edit.buttons
local btnEditWidth = 0
for i, v in ipairs(edit.buttons) do
	btnEditWidth = math.max(btnEditWidth, normalfont:getwidth(_(v).."  "))
end
btnEditWidth=btnEditWidth+colButMarg
edit.width = normalfont:getwidth(" -Xxxxxxxxxxxx- ")+btnEditWidth*edit.nBut+colButMarg
edit.height = cmdButSize + closeButSize + colButMarg
edit.X = palette.X - edit.width
edit.Y = palette.Y + palette.height - edit.height

key.verify = function(k,def)
	if type(k)=="string" and string.len(k)==1
		then return k
		elseif k=="" then return string.char(254) -- inaccessible key: inactivation
		else return def
	end
end
key.slideshowShortcut=key.verify(slideshow_shortcut,    "r")
key.deviceVisibility =key.verify(device_visibility_key, "*")
key.forward          =key.verify(forward_slide_key,     "+")
key.backward         =key.verify(backward_slide_key,    "-")
key.first            =key.verify(first_slide_key,       "<")
key.fast             =key.verify(fast_slide_key,        ">")


local function clearTab(tab)
	for i, v in pairs(tab) do
		if type(v)=="table" then clearTab(v) end
		v = nil
	end
end

local function copyTab(source,dest)
	for i,v in pairs(source) do
		if type(v) =="table" then
			dest[i]={}
			copyTab(v,dest[i])
		else
			dest[i] = v
		end
	end
end

---------------------------------
-- Files functions
---------------------------------
local copyfile=function(source,destin)
	local f1= io.open(source,"r")
	if f1 then
		local f2 = io.open(destin,"w")
		if f2 then
			local t = f1:read("*all")
			f2:write(t)
			f2:close()
		end
		f1:close()
	end
end

local setPathes=function(name)
	slidesName=name
	slidesPath =   "../"..slidesName .. "/" -- relative path to zutils for loadtexture
	celestiaSlidePath = "extras/slideshow/"..slidesName .. "/"
	slideCatalog = celestiaSlidePath.."_slideCatalog.txt" --celestia path
	if lang ~= "en" then
		local localCat = celestiaSlidePath.."_slidecatalog_"..lang..".txt"
		local fic = io.open(localCat,"r")
		if fic then
			fic:close()
			slideCatalog = localCat
		end
	end
end
---------------------------------
-- reads catalog
---------------------------------
local readsCatalog = function(catName,catTab, justOne)
	-- reinit
	clearTab(catTab)

	local fic = io.open(catName, "r")
	local iObj, nbObjects = 0, 0
	local dia, nbdia, maxdia = 1, 0, 0
	local txt, nbtxt, maxtxt = 1, 0, 0
	local sip, txip= true, false
	local nbcom = 0  -- comment lines before slide
	local nbltxt = 0

	local nextline = function()
		local isAudio = function(line)
			local result=false
			for _,ext in ipairs(audioFileExt) do
				result = result or string.find(line, "%."..ext.."$")
			end
			if string.lower(string.sub(line,1,7))=="http://" then result = true end
			return result
		end
		local ln = fic:read()
		local ln0 = ln
		local ltype = nil
		local X,Y,W,H,Z,C,CT,B,BT,P,M,PP,OR,Bd,BdT
		local nbr ="%s+(%-?%d+)"
		local nb = "%s+(%d+)"
		local np = "%s+(%-?[01])"
		if not ln then return nil, nil end
		ln = string.gsub(ln, "^%s*(.-)%s*$","%1") -- trim spaces before and behind
		ltype = "ltxt" -- if nothing else the line is text
		if ln=="" then
			ltype = "lempty"

		elseif string.sub(ln,1,1) == '"' or string.sub(ln,-1) == '"' then
			ltype = "ltxt"

		elseif string.sub(ln,1,2) == "--" or string.sub(ln,1,1) == "'" then
			ltype = "lcom"	-- comment
			ln = ln0

		elseif string.sub(ln,1,1) == "=" then
			ltype = "lseptxt"

		elseif string.sub(ln,1,2) == "# " then
			local i,j
			i,j,X,Y,W,H,Z,C = string.find(ln, "^#"..np..np..nbr..nbr.."%s+([012])"..nbr)
			if C then  -- compatibility version 1.0
				i,j,CT,B,BT,P,M,Bd,BdT = string.find(ln,"^"..nb..nb..nb..nb..nb..nb..nb,j+1)
				if not i then CT=100 B=1 BT=0 P=1 M=0 Bd=1 BdT=0 end
				ltype = "lptx"  -- text properties
			end

		elseif string.sub(ln,1,3) == "#D " then
			i,j,X = string.find(ln, "^#D%s*(%d+%.?%d*)")
			if X then
				ltype = "ldelay"
			end

		elseif string.sub(ln,1,6) == "cel://" then
			ltype = "lcel"

		elseif isAudio(ln) then
			ltype = "lsound"

		else -- is an image?
			local name
			local i,j
			local fc = "^([^%?<>|%*\"]+%." -- test & start capture file name  + "."
			i,j,name = string.find(string.lower(ln),fc.."jpe?g)")
			if not name then i,j,name = string.find(string.lower(ln),fc.."png)") end
			if not name then i,j,name = string.find(string.lower(ln),fc.."dds)") end
			if not name then i,j,name = string.find(ln,"^(~%w+)") end
			if name then -- this is an image file name
				ltype = "limg"
				name= string.sub(ln,i,j) -- precaution for linux: restore upper/lower case
				i,j,X,Y,W,H,Z=string.find(ln,"^"..nbr..nbr..nb..np..np,j+1)
				if Z then -- transparence V1.2
					i,j,C,CT,B,BT,P,PP,OR,Bd,BdT=string.find(ln,"^"
						..nb..nb..nb..nb..nb..nb..nb..nb..nb,j+1)
				end
				if not C then
					C=100;CT=0;B=1;BT=0;P=1;PP=0;OR=1;Bd=1;BdT=0
				end
				ln = name
			end
		end
		return  ln,ltype,X,Y,W,H,Z,C,CT,B,BT,P,M,PP,OR,Bd,BdT
	end

	local createNewSlide = function()
		iObj=iObj+1
		catTab[iObj]={}
		catTab[iObj].COM = {}; nbcom = 0
		catTab[iObj].desc = ""
		catTab[iObj].IMG = {}
		catTab[iObj].TXT = {}
		sip, txip = true, false  -- slide or text in progress
		dia=0 txt=0
	end

	-- begin readsCatalog
	if fic then
		os.setlocale("C", "numeric")
		local numligne = 0
		local line,lt,x,y,w,h,z,c,ct,b,bt,p,m,pp,Or,Bd,BdT = nextline()
		if lt ~="lempty" and lt~="lcom" then
			createNewSlide()
		end
		while line do
			numligne=numligne+1
			if justOne and lt == "lempty" and sip and numligne ~= 1 then lt = "lseptxt" end
			if lt=="lempty" or lt=="lcom" then
				if sip then createNewSlide() end
				if lt == "lcom" or catTab[iObj].desc ~= "" then
					nbcom=nbcom+1
					catTab[iObj].COM[nbcom]=line
					local desc = line  -- description line
					if lt=="lcom" then -- remove comment syntax
						desc = string.gsub(desc,"^%s*%-%-%s*","'")
						desc = string.gsub(desc,"^%s*'%s*","")
					end
					if desc ~= "" then catTab[iObj].desc = desc end
				end
				sip=false
			else
				nbcom = 0
				sip=true
				if lt ~= "ltxt" then
					txip = false
				end

				if lt =="lcel" then
					catTab[iObj].url=line

				elseif lt =="lsound" then
					catTab[iObj].sound=line

				elseif lt=="limg" then
					dia = dia + 1
					if dia > maxdia then maxdia = dia end
					catTab[iObj].IMG[dia]={}
					catTab[iObj].IMG[dia].file=line
					catTab[iObj].IMG[dia].X = tonumber(x)
					catTab[iObj].IMG[dia].Y = tonumber(y)
					catTab[iObj].IMG[dia].W = tonumber(w)
					catTab[iObj].IMG[dia].orX = tonumber(h)
					catTab[iObj].IMG[dia].orY = tonumber(z)
					catTab[iObj].IMG[dia].CT = tonumber(c)
					catTab[iObj].IMG[dia].R = tonumber(ct)
					catTab[iObj].IMG[dia].B = tonumber(b)
					catTab[iObj].IMG[dia].BT = tonumber(bt)
					catTab[iObj].IMG[dia].C = tonumber(p)
					catTab[iObj].IMG[dia].PP = tonumber(pp)
					catTab[iObj].IMG[dia].OR = tonumber(Or)
					catTab[iObj].IMG[dia].Bd = tonumber(Bd)
					catTab[iObj].IMG[dia].BdT = tonumber(BdT)

				elseif lt=="ltxt" then
					if not txip then ---- create new text in the current slide
						txt = txt + 1
						if txt > maxtxt then maxtxt = txt end
						nbltxt = 0
						catTab[iObj].TXT[txt] = {}
						catTab[iObj].TXT[txt].text = {}
						-- default values if no description found
						catTab[iObj].TXT[txt].orX = 0
						catTab[iObj].TXT[txt].orY = 0
						catTab[iObj].TXT[txt].H = 0
						catTab[iObj].TXT[txt].C = 1
						catTab[iObj].TXT[txt].CT = 100
						catTab[iObj].TXT[txt].B = 1
						catTab[iObj].TXT[txt].BT = 0
						catTab[iObj].TXT[txt].P = 1
						catTab[iObj].TXT[txt].Z = 0
						catTab[iObj].TXT[txt].M = 0
						catTab[iObj].TXT[txt].Bd = 1
						catTab[iObj].TXT[txt].BdT = 0
					end
					nbltxt = nbltxt + 1
					catTab[iObj].TXT[txt].text[nbltxt]=line
					catTab[iObj].TXT[txt].H = nbltxt
					txip = true
				elseif lt=="lptx" then
					if txt > 0 then
						catTab[iObj].TXT[txt].orX = tonumber(x)
						catTab[iObj].TXT[txt].orY = tonumber(y)
						catTab[iObj].TXT[txt].X = tonumber(w)
						catTab[iObj].TXT[txt].Y = tonumber(h)
						catTab[iObj].TXT[txt].Z = tonumber(z)
						catTab[iObj].TXT[txt].C = tonumber(c)
						catTab[iObj].TXT[txt].CT = tonumber(ct)
						catTab[iObj].TXT[txt].B = tonumber(b)
						catTab[iObj].TXT[txt].BT = tonumber(bt)
						catTab[iObj].TXT[txt].P = tonumber(p)
						catTab[iObj].TXT[txt].M = tonumber(m)
						catTab[iObj].TXT[txt].Bd = tonumber(Bd)
						catTab[iObj].TXT[txt].BdT = tonumber(BdT)
					end

				elseif lt=="ldelay" then
					catTab[iObj].delay = tonumber(x)

				--else lt == "lseptxt" nothing to do
				end
			end
			line,lt,x,y,w,h,z,c,ct,b,bt,p,m,pp,Or,Bd,BdT = nextline()
		end
		fic:close()
		os.setlocale("", "numeric")
	end -- reading caltalog fle

	nbObjects= iObj
	for i=iObj+1, # catTab do catTab[i]=nil end

	if nbObjects >0 then
		-- ignore trailing blank or comment lines but do not delete them
		if	catTab[nbObjects].IMG[1] == nil
			and catTab[nbObjects].TXT[1] == nil
			and catTab[nbObjects].url == nil
			and catTab[nbObjects].sound == nil
		then
			nbObjects = nbObjects - 1
		end
	end
	maxdia = math.max(maxdia, lastSlide.maxdia)
	maxtxt = math.max(maxtxt, lastSlide.maxtxt)
	lastSlide.maxdia = maxdia
	lastSlide.maxtxt = maxtxt
	return nbObjects,maxdia,maxtxt
end -- readsCatalog

nbObjects, maxdia, maxtxt = readsCatalog(slideCatalog,diaporama)
if nbObjects >0 then
	iObj = 1
end
if type(resumeAt) == "number" then
	resumeAt = math.max(1, resumeAt)
	resumeAt = math.min(nbObjects, resumeAt)
	iObj=resumeAt
elseif resumeAt == "random" then
	math.randomseed(os.time())
	for i=1,5 do iObj=math.random(1,nbObjects) end
elseif resumeAt ~= "same_slide" then
	resumeAt = "next_slide"
end


----------------------------------------------
-- Set up boxes
----------------------------------------------

slideshow = CXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
    :attach(screenBox, width, height, 0, 0)

if lua_edu_tools then
slideshowCheck = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 9)
	:text("")
	:movable(false)
	:active(true)
	:attach(slideshow, boxWidth - 40, 4, 29, 5)
end

slideControl = pCXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
	:clickable(true)
    :attach(screenBox, width, height, 0, 0)

tele.frame = pCXBox:new()
    :init(0, 0, 0, 0)
    :bordercolor(beColor)
	:fillcolor({0.35, 0.35, 0.5, 0.3})
	:textfont(normalfont)
	:textcolor(cslide)
	:movetext(8, 6)
	:text("")
    :movable(true)
    :active(false)
    :clickable(false)
    :visible(false)
    :attach(screenBox, 0, 0, 0, 0)

tele.frame.buttons = {}
tele.frame.imgBut = { {}, {}, {}, {}, }
tele.frame.iconState = {1,1,1,1,1,1,1} -- standard display mode

tele.frame.buttons[0] = pCXBox:new() -- x button
	:bordercolor(biColor)
	:textfont(smallfont)
	:textcolor(cslide)
	:textpos("center")
	:movetext(0, 7)
	:text("X")
	:visible(true)
	:movable(false)
	:active(true)
	:attach(tele.frame, tele.width - 14, tele.height - 14, 0,0)

tele.frame.buttons["sound"] = pCXBox:new()
	:bordercolor(biColor)
	:textfont(smallfont)
	:textcolor(cslide)
	:textpos("center")
	:movetext(0, 7)
	:text("O")
	:visible(true)
	:movable(false)
	:active(true)
	:attach(tele.frame, tele.width - 38, tele.height - 14, 24,0)

for i=1, nbButtons do
	tele.frame.buttons[i] =
		pCXBox:new()
		:bordercolor(biColor)
		:fillcolor({0,0,0,0.8})
		:movable(false)
		:active(true)
		:clickable(false)
		:visible(true)
		:attach(tele.frame,
			btMarg*i + btSize * (i-1),
			btMarg-4,
			tele.width -btMarg *i - btSize * i ,
			topbutmarg+4 )
end

-- palette setup

local createPaletteFrame = function()
	palette.colRows = math.ceil(nbColors / 8)
	palette.height = palette.totCursHeight + colButSize * palette.colRows + colButMarg + cmdHeight
	palette.X = width-palette.width-200
	palette.Y = height - palette.height -20

	palette.frame = pCXBox:new()
			:init(0, 0, 0, 0)
			:bordercolor(beColor)
			:fillcolor({0.3, 0.3, 0.3, 0.95})
			:movable(true)
			:active(false)
			:clickable(false)
			:visible(false)
			:attach(screenBox, 0, 0, 0, 0)

	palette.frame.colorIcon ={}

	local createColorIcon = function(n)
		local icol=slideTextColor[n]
		local coln = (n-1) % 8  -- (O to 7)
		local row = palette.colRows +1 -math.ceil(n / 8)
		return
			pCXBox:new()
				:fillcolor({icol[1],icol[2],icol[3],1})
				:movable(false)
				:active(true)
				:clickable(false)
				:visible(true)
				:attach(palette.frame,
					coln*colButSize+colButMarg,
					palette.totCursHeight+(row-1)*colButSize,
					palette.width - (coln*colButSize)+colButMarg - colButSize,
					palette.height - (palette.totCursHeight+(row-1)*colButSize) +colButMarg - colButSize)
	end


	for i=1, # slideTextColor do
		palette.frame.colorIcon[i]=createColorIcon(i)
		palette.frame.colorIcon[i].id = i
	end

	do
		local x=4 + math.floor(colButSize * 3/8 +0.5)
		local w = math.floor(colButSize *0.75+0.5)

		palette.frame.pFont=pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x= x + w

		palette.frame.nFont=pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x= 4

		palette.frame.rotSymLeft=pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(false)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x=x+w

		palette.frame.rotSym=pCXBox:new()
			--:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(false)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)
			palette.frame.rotSym.Mode = 1

		x=x+w

		palette.frame.rotSymRight=pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(false)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)


		x=x + w
		w = colButSize

		palette.frame.alignText=pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x=x+4

		palette.frame.imgOrder = pCXBox:new()
			:bordercolor(beColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(false)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x = x+w+6
		w = colButSize

		palette.frame.copyFormatr=pCXBox:new()
			:bordercolor(beColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x = x + w + 4
		w = palette.width - x - 4

		palette.frame.colorTarget=pCXBox:new()
			:bordercolor(biColor)
			:textfont(normalfont)
			:textcolor(cslide)
			:textpos("center")
			:movetext(0, 2)
			:text("")
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight + cmdButSize,
				palette.width - w -x,
				cmdHeight*0 - cmdButSize + colButMarg)

		x=4
		w= normalfont:getwidth(" 999")

		palette.frame.margin = pCXBox:new()
			:bordercolor(biColor)
			:fillcolor({0,1,1,0.3})
			:textfont(normalfont)
			:textcolor({1,1,1,1})
			:textpos("center")
			:movetext(0, 2)
			:text("---")
			:movable(false)
			:active(true)
			:editable(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)

		w= colButSize

		palette.frame.deform = pCXBox:new()
			:bordercolor(biColor)
			:textfont(titlefont)
			:textcolor(cslide)
			:textpos("center")
			:movetext(0, 0)
			:text("...")
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(false)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)

		x=x + w + 4

		palette.frame.magnet = pCXBox:new()
			:movable(false)
			:bordercolor(biColor)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)
			palette.frame.magnet.ON = true


		x=x + w + 12
		w = colButSize

		palette.frame.align = pCXBox:new()
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)
			palette.frame.align.Mode = 20

		x=x + w + 4

		palette.frame.horizontal = pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)

		x=x + w + 4

		palette.frame.vertical = pCXBox:new()
			:bordercolor(biColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)

		x = x + w + 14
		w = normalfont:getwidth(" Auto")

		palette.frame.delay = pCXBox:new()
			:bordercolor(biColor)
			:fillcolor({0,1,1,0.3})
			:textfont(normalfont)
			:textcolor({1,1,1,1})
			:textpos("center")
			:movetext(0, 2)
			:text("Auto")
			:movable(false)
			:active(true)
			:editable(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,
				x,
				palette.height-cmdHeight,
				palette.width - w -x,
				cmdHeight - cmdButSize + colButMarg)

		local alignMenu_ba = palette.height-cmdHeight - cmdButSize - colButMarg

		palette.frame.alignMenu = pCXBox:new()
			:bordercolor(biColor)
			:fillcolor({0.1,0.1,0.1,1})
			:movable(false)
			:active(false)
			:clickable(false)
			:visible(false)
			:attach(palette.frame,
				palette.width - 76 - palette.nbMenuBut*cmdButSize - colButMarg,
				alignMenu_ba,
				74,
				palette.height- alignMenu_ba - cmdButSize)
			palette.frame.alignMenu.button={}

		local createModeMenuButton = function(n)
			return
				pCXBox:new()
					:bordercolor(biColor)
					:movable(false)
					:active(true)
					:clickable(false)
					:visible(true)
					:attach(palette.frame.alignMenu,
						(n-1)*cmdButSize + colButMarg,
						2,
						(palette.nbMenuBut-n)*cmdButSize+colButMarg,
						2)
		end

		for i=1,palette.nbMenuBut do
			palette.frame.alignMenu.button[i] = createModeMenuButton(i)
			palette.frame.alignMenu.button[i].id = i
		end

		-- upper buttons

		palette.frame.close = pCXBox:new()
			:bordercolor(biColor)
			:textfont(normalfont)
			:textcolor(cslide)
			:textpos("center")
			:movetext(0, 5)
			:text("X")
			:visible(true)
			:movable(false)
			:active(true)
			:attach(palette.frame, palette.width - closeButSize, palette.height - closeButSize, 0,0)

		palette.frame.editBt = pCXBox:new()
			:bordercolor(biColor)
			:textfont(normalfont)
			:textcolor(cslide)
			:textpos("center")
			:movetext(0, 5)
			:text("E")
			:visible(true)
			:movable(false)
			:active(true)
			:attach(palette.frame, 0, palette.height - closeButSize, palette.width - closeButSize,0)

		-- transparency control Tools
		--local transpaW = 164 -- calculated values
		--local cursorW = 12   -- do not change

		palette.frame.transBox=pCXBox:new()
			:bordercolor(biColor)
			:textfont(normalfont)
			:textcolor(cslide)
			:textpos("center")
			:movetext(0, 3)
			:text("75")
			:editable(true)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,palette.width-30,5,4,palette.height-25)

		palette.frame.transFrame=pCXBox:new()
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame,0,5,32,palette.height-25)

		palette.frame.rail=pCXBox:new()
			:fillcolor({1,1,1,0.2})
			:bordercolor(beColor)
			:movable(false)
			:active(true)
			:clickable(false)
			:visible(true)
			:attach(palette.frame.transFrame,3,8,3,8)

		palette.frame.cursor=pCXBox:new()
			:fillcolor({0.8,1,1,0.7})
			:bordercolor({0,0,0,0.8})
			:movable(true)
			:active(false)
			:clickable(false)
			:visible(true)
			:attach(palette.frame.transFrame,3,3,164-3-12,3)

		palette.frame.rail.Masked = palette.frame.cursor
	end
end

createPaletteFrame()

--
-- edit tools
--

edit.frame = pCXBox:new()
    :init(0, 0, 0, 0)
    :bordercolor(beColor)
	:fillcolor({0.3, 0.3, 0.3, 0.95})
    :movable(true)
    :active(false)
    :clickable(false)
    :visible(false)
    :attach(screenBox, edit.X, edit.Y, width - edit.width -edit.X, height- edit.height - edit.Y)

 x=colButMarg / 2
 w= edit.width - edit.nBut*btnEditWidth - colButMarg

edit.frame.directory = pCXBox:new()
	:bordercolor(biColor)
	:textfont(normalfont)
	:textcolor(cslide)
	:textpos("center")
	:movetext(0, 2)
	:text(slidesName)
    :active(true)
    :clickable(false)
    :visible(true)
    :movable(false)
	:editable(true)
    :attach(edit.frame, x, 2, edit.width - w - x, edit.height - cmdButSize-2)


local nextEditButton = function(txt)
	x=x + w + colButMarg
	w = btnEditWidth - colButMarg
	return pCXBox:new()
		:bordercolor(biColor)
			:textfont(normalfont)
			:textcolor(cslide)
			:textpos("center")
			:movetext(0, 2)
			:text(txt)
		:movable(false)
		:active(true)
		:clickable(false)
		:editable(false)
		:visible(true)
		:attach(edit.frame, x, 2, edit.width - w - x, edit.height - cmdButSize-2)
end

for i,v in ipairs(edit.buttons) do
	edit.frame[edit.buttons[i]] = nextEditButton(_(v))
end

--
-- diapo and text frames --
--

local createDiapo = function()
	return
		pCXBox:new()
		:init(0, 0, 0, 0)
		:movable(true)
		:active(false)
		:clickable(false)
		:visible(false)
		:attach(screenBox, 0, 0, 0 ,0)
end

local createResizeBtn = function(diapoBox)
	return pCXBox:new()
		:bordercolor(resize.normalColor)
		:movable(true)
		:active(false)
		:clickable(false)
		:visible(true)
		:attach(diapoBox, 0,0,0,0)
end

local createText = function()
	return
		pCXBox:new()
		:init(0, 0, 0, 0)
		:movable(true)
		:active(false)
		:clickable(false)
		:visible(false)
		:attach(screenBox, 3,3,3,3)
end

local createDiapoFrame = function(id)
	local newDiapoFrame =createDiapo()
	newDiapoFrame.resizeDiapoFrame = createResizeBtn(newDiapoFrame)
	newDiapoFrame.id = id
	newDiapoFrame.Transp=1
	newDiapoFrame.OR = 1
	newDiapoFrame.r = 1;newDiapoFrame.g = 1;newDiapoFrame.b = 1;
	newDiapoFrame.isImage = true
	return newDiapoFrame
end

local createTextFrame = function(id)
	local newTextFrame= createText()
	newTextFrame.id = id
	return newTextFrame
end

for i=0, maxdia do diapoFrame[i] = createDiapoFrame(i) end
for i=1, maxtxt do textFrame[i]  = createTextFrame(i)  end

--
-- filling buttons with icons
--
local initTeleIcons = function()
	if tele.frame.imgBut[1][1] then return end
	tele.frame.imgBut = {
		{
		celestia:loadtexture(utilPath.."rondrouge.png"),
		celestia:loadtexture(utilPath.."startbutton.png"),
		celestia:loadtexture(utilPath.."leftbutton.png"),
		celestia:loadtexture(utilPath.."rightbutton.png"),
		celestia:loadtexture(utilPath.."fastbutton.png"),
		nil, -- special Customdraw for button#6
		celestia:loadtexture(utilPath.."bascule.png"),
		},{
		celestia:loadtexture(utilPath.."b23.png"),
		celestia:loadtexture(utilPath.."b24.png"),
		celestia:loadtexture(utilPath.."urli.png"),
		celestia:loadtexture(utilPath.."palette.png"),
		celestia:loadtexture(utilPath.."grid.png"),
		},{
		celestia:loadtexture(utilPath.."b33.png"),
		celestia:loadtexture(utilPath.."b34.png"),
		celestia:loadtexture(utilPath.."urla.png"),
		},{
		celestia:loadtexture(utilPath.."b43.png"),
		celestia:loadtexture(utilPath.."b44.png"),
		}
	}
	teleButton6Icon = {
		celestia:loadtexture(utilPath.."auto.png"),
		celestia:loadtexture(utilPath.."showselRef.png"),
		celestia:loadtexture(utilPath.."showSel.png"),
		celestia:loadtexture(utilPath.."shownoframe.png"),
	}

	tele.frame.buttons[6].Customdraw = function(this)
		if designMode then
			if showSel and showRef then this.Fillimage=teleButton6Icon[2]
			elseif showSel then this.Fillimage = teleButton6Icon[3]
			else this.Fillimage = teleButton6Icon[4] end
		else
			this.Fillimage = teleButton6Icon[1]
		end
	end

	tele.frame.buttons["sound"].Customdraw = function(this)
		if soundAvailable then
			this.Textcolor = {0,1,0,0.9}
		else
			this.Textcolor = {1,0.2,0,1}
		end
	end

	local createButtonCustomdraw = function(f)
		return
			function(this)
				this:fillimage(tele.frame.imgBut[tele.frame.iconState[f]][f])
			end
	end

	for i=1, nbButtons do
		if i~=6 then tele.frame.buttons[i].Customdraw = createButtonCustomdraw(i) end
	end
end

-----------------------
-- General functions
----------------------

local verifbounds=function(a,b) -- replace in screen if limite crossed
	local mg=3
	if a<mg then
		b= a+b-mg; a=mg
	elseif b<mg then
		a= a+b-mg; b=mg
	end
	return a, b
end

local getBounds = function(target)
	local lm, bm, rm, tm
	lm=	width*target.ox + target.X
	bm= height*target.oy + target.Y
	rm =width - lm - target.width
	tm =height - bm - target.height
	-- adjust position
	lm, rm = verifbounds(lm, rm)
	bm, tm = verifbounds(bm , tm)
	target.X=lm-width*target.ox
	target.Y=bm-height*target.oy
    return lm, bm, rm, tm
end

local nextRandom = function()
	if nbObjects>1 then
		local ob = iObj
		while ob == iObj do ob = math.random(1,nbObjects) end
		return ob
	else
		return 1
	end
end

local addMessage = function(msg)
	messages = messages .. cr .. msg
end

local printMessages = function(t)
	if not t then t=3 end
	local m,messageH = string.gsub(messages,cr,cr)
	celestia:print(messages,t,-1,-1,1,5+messageH)
	messages=""
end

local noSlide = function()
	addMessage(_"NO SLIDE IN SLIDESHOW")
end

--------------------------
-- text and keys functions
--------------------------

local calcTextSize = function(t)
	text[t].charH = fonts[text[t].P]:getheight()
	text[t].height = diaporama[iObj].TXT[t].H * text[t].charH + 2*text[t].M
	text[t].width  = 0
	local w = 0
	for i,v in ipairs(text[t].tx) do
		w=fonts[text[t].P]:getwidth(text[t].tx[i].line )
		text[t].width = math.max(text[t].width, w)
	end
	text[t].width = text[t].width + 2*text[t].M
	for i,v in ipairs(diaporama[iObj].TXT[t].text) do
		text[t].tx[i].indent = (text[t].width -2*text[t].M - fonts[text[t].P]:getwidth(text[t].tx[i].line)) * text[t].J
	end
end

local printText=function(t)
	if text[t].width+5 > width or text[t].height+5> height then
			allowT[t] = false
	elseif display_diapo then
		textFrame[t]:attach(screenBox, getBounds(text[t]))
		textFrame[t]:getbounds()
		textFrame[t]:orderfront()
		allowT[t] = true
	end
end

local initTexts = function()
	if nbObjects >0 then
		nbtxt = # diaporama[iObj].TXT
	else
		nbtxt = 0
	end
	allowT = {}
	local shiftText = 0
	for t=1, nbtxt do
		text[t]={}
		if not diaporama[iObj].TXT[t].X or not diaporama[iObj].TXT[t].Y then
			shiftText = shiftText + 40
			diaporama[iObj].TXT[t].X = -math.floor(width/2 - shiftText)
			diaporama[iObj].TXT[t].Y = -math.floor(height/2 - shiftText)
		end
		text[t].orX = diaporama[iObj].TXT[t].orX
		text[t].orY = diaporama[iObj].TXT[t].orY
		text[t].ox = (text[t].orX + 1)/2
		text[t].oy = (text[t].orY + 1)/2
		text[t].savox = text[t].ox
		text[t].savoy = text[t].oy
		text[t].X = diaporama[iObj].TXT[t].X
		text[t].Y = diaporama[iObj].TXT[t].Y
		text[t].J = diaporama[iObj].TXT[t].Z / 2

		text[t].C = diaporama[iObj].TXT[t].C
		if text[t].C > nbColors then text[t].C=1 end -- default color
		text[t].CT= diaporama[iObj].TXT[t].CT

		text[t].B = diaporama[iObj].TXT[t].B
		if text[t].B > nbColors or text[t].B <1 then text[t].B=1 end -- default color
		text[t].BT= diaporama[iObj].TXT[t].BT

		text[t].P= diaporama[iObj].TXT[t].P
		if text[t].P > nbFonts then text[t].P=1 end -- default font

		text[t].M= diaporama[iObj].TXT[t].M

		text[t].Bd = diaporama[iObj].TXT[t].Bd
		if text[t].Bd > nbColors or text[t].Bd <1 then text[t].Bd=1 end -- default color
		text[t].BdT= diaporama[iObj].TXT[t].BdT

		text[t].color={}
		text[t].bgCol = {}
		text[t].border = {}

		for i=1,3 do
			text[t].color[i]  = slideTextColor[text[t].C][i]
			text[t].bgCol[i]  = slideTextColor[text[t].B][i]
			text[t].border[i] = slideTextColor[text[t].Bd][i]
		end
		text[t].color[4]  = text[t].CT / 100
		text[t].bgCol[4]  = text[t].BT / 100
		text[t].border[4] = text[t].BdT / 100

		text[t].tx={}
		for i,v in ipairs(diaporama[iObj].TXT[t].text) do
			text[t].tx[i] = {}
			v= string.gsub(v,"^\"","")
			v= string.gsub(v,"\"$","")
			text[t].tx[i].line = v
		end
		calcTextSize(t)

		if text[t].BT > 0 then
			textFrame[t].Fillcolor=text[t].bgCol
		else
			textFrame[t].Fillcolor = nil
		end
		if text[t].BdT > 0 then
			textFrame[t].Bordercolor=text[t].border
		else
			textFrame[t].Bordercolor=nil
		end
		allowT[t]=true
		printText(t)
	end
end

local toggleJustif = function()
	if not selFrame or selFrame.isImage then return end
	local thisText = text[selFrame.id]
	thisText.J = ((thisText.J*2 + 1) % 3)/2
	for i,_ in ipairs(thisText.tx) do
		thisText.tx[i].indent =
			(thisText.width -2*thisText.M - fonts[thisText.P]:getwidth(thisText.tx[i].line)) * thisText.J
	end
end


local toggleFont = function(dc)
	if not selFrame or selFrame.isImage then return end
	local thisText = text[selFrame.id]
	thisText.P = thisText.P + dc
	if thisText.P > nbFonts then thisText.P = 1 end
	if thisText.P < 1 then thisText.P = nbFonts end
	calcTextSize(selFrame.id)
	printText(selFrame.id)
end

local delayAdjust = function(dt)
	if designMode then
		if modifDelay == 0 then modifDelay=slideshowDelay end
		modifDelay = math.max(modifDelay + dt,0)
		local msg
		if modifDelay <= 0
			then msg = _("default")
			else msg = tostring(modifDelay).."s"
		end
		msg = _("delay = ")..msg
		addMessage(msg)
	elseif autotime>0 then
		slideshowDelay = math.max(slideshowDelay+dt,2)
		addMessage(_("Default slides duration = ")..slideshowDelay.."s")
	end
end

local delayMinus = function() delayAdjust(-1) end
local delayPlus  = function() delayAdjust(1)  end

-----------------------------
-- local functions for slides
-----------------------------

local reorderFrames=function(pp)
	for d=1,nbdia do diapoFrame[d]:orderfront() end
	for t=1, nbtxt do printText(t) end
	if pp then
		for d=1,nbdia do
			if diapo[d] and diapo[d].pp then diapoFrame[d]:orderfront() end
		end
	end
	palette.frame:orderfront()
	edit.frame:orderfront()
	tele.frame:orderfront()
end

local replaceDiapo=function(d)
	if not allowD[d] then return end
	local margin2 = 6
	if diapo[d].width+5 >= width then
		diapo[d].width = width - margin2
		diapo[d].height= diapo[d].width / diapo[d].imageRatio
		diapo[d].X=2-width*diapo[d].ox
	end
	if diapo[d].height+5 >= height then
		diapo[d].height = height - margin2
		diapo[d].width = diapo[d].height * diapo[d].imageRatio
		diapo[d].Y=2-height*diapo[d].oy
	end
	diapoFrame[d]:attach(screenBox, getBounds(diapo[d]))
	diapoFrame[d]:getbounds()
	diapoFrame[d].resizeDiapoFrame:attach(diapoFrame[d],
		width - diapoFrame[d].ra - diapoFrame[d].la -resize.corner,
		height - diapoFrame[d].ta - diapoFrame[d].ba -resize.corner,
		resize.margin,resize.margin)
end

local replaceTool=function(tool)
	if (tool.width+6 <= width) and (tool.height+6 <= height) then
		tool.allow = true
		if tool.X < 3 then tool.X = 3 end
		if tool.X + tool.width + 3 > width then tool.X = width - tool.width -3 end
		if tool.Y < 3 then tool.Y = 3 end
		if tool.Y + tool.height + 3 > height then tool.Y = height - tool.height -3 end
		tool.frame:attach(screenBox, tool.X, tool.Y,
			width - tool.width - tool.X, height - tool.height - tool.Y)
		if tool == tele then tool.frame:orderfront() end
	else
		tool.allow = false
	end
end

local toggleEdit= function()
	edit.display = not edit.display
	if edit.oper ~= "Cut" and edit.oper ~= "Copy" then edit.oper = nil end
	if edit.display then
		edit.X = palette.X - edit.width
		edit.Y = palette.Y + palette.height - edit.height
		replaceTool(edit)
		edit.frame:orderfront()
	end
end

local toggleRuler=function()
	if nbObjects<1 then return end
	diapoFrame[0].Visible = not diapoFrame[0].Visible
	if diapoFrame[0].Visible then
		replaceDiapo(0)
		diapoFrame[0]:orderfront()
		refFrame = selFrame
		selFrame = diapoFrame[0]
	else
		if diapoFrame[0] == refFrame then
			refFrame = nil
		elseif diapoFrame[0] == selFrame then
			selFrame = refFrame
		end
	end
	colTarg = 0
end

local savePosOrg=function(d)
	diapo[d].posOrg.X=diapo[d].X
	diapo[d].posOrg.Y=diapo[d].Y
	diapo[d].posOrg.height=diapo[d].height
	diapo[d].posOrg.width=diapo[d].width
	diapo[d].posOrg.imageRatio=diapo[d].imageRatio
	diapo[d].posOrg.OR = diapo[d].OR
end

local invertSides = function(d)
	diapo[d].width, diapo[d].height = diapo[d].height, diapo[d].width
	diapo[d].imageRatio = diapo[d].width / diapo[d].height
	replaceDiapo(d)
end

local shiftImg
local loadImage= function(d,ig)
	local filename
	if diaporama[ig].IMG[d] then
		filename = diaporama[ig].IMG[d].file
	else
		return
	end
	local deform = string.sub(filename,1,1) == "~"
	local special = not string.find(filename,"%.")
	if deform then filename = string.sub(filename,2) end
	filename = string.gsub(filename,"\\","/")
	local absPath,j, let,dp,nm = string.find(filename, "^(%a?)(:?)(/.+)")
	local image = special
	if not special then
		local fileindex
		if absPath then
			fileindex= filename
			if not pictures[fileindex] then
				if let == "" then
					pictures[fileindex]= celestia:loadtexture("../../../../../../.."..filename)
				else
					local fic = io.open(let..":/loadpicture.lua","w")
					if fic then
						fic:write('return celestia:loadtexture("' .. string.sub(nm,2)  ..'")')
						fic:close()
					end
					local f = loadfile(let..":/loadpicture.lua")
					if f then
						pictures[fileindex] = f()
					end
				end
			end
		else
			fileindex = slidesName..string.gsub(filename,"%.","_")
			if not pictures[fileindex] and fileindex ~= slidesName.."no_jpg"  then
				pictures[fileindex]= celestia:loadtexture(slidesPath..filename)
					or celestia:loadtexture(sharedPath..filename)
			end
		end
		image = pictures[fileindex]
	end
	nbdia = nbdia +1
	local missing = not image
	if filename ~= "no.jpg"  then
		img=ig
		lastImage = d
		diapo[d] = {}
		diapo[d].posOrg = {}
		if display_diapo then allowD[d]=true end
		diapo[d].file = diaporama[ig].IMG[d].file
		local imageWidth  = 200
		local imageHeight = 200
		if not special and not missing then
			imageWidth  = image:getwidth()
			imageHeight = image:getheight()
			diapo[d].orgRatio = imageWidth / imageHeight
		end
		if diaporama[ig].IMG[d].R ~= 0 and deform
			then diapo[d].imageRatio = diaporama[ig].IMG[d].R /1e6
			else diapo[d].imageRatio  = imageWidth / imageHeight
		end
		diapo[d].special = special
		diapo[d].deform = deform
		if diaporama[ig].IMG[d].W then
			if diapo[d].imageRatio>1 then
				diapo[d].width=diaporama[ig].IMG[d].W
				diapo[d].height= diapo[d].width / diapo[d].imageRatio
			else
				diapo[d].height = diaporama[ig].IMG[d].W
				diapo[d].width = diapo[d].height * diapo[d].imageRatio
			end
			diapo[d].X = diaporama[ig].IMG[d].X
			diapo[d].Y = diaporama[ig].IMG[d].Y
			diapo[d].orX = diaporama[ig].IMG[d].orX
			diapo[d].orY = diaporama[ig].IMG[d].orY
			diapo[d].CT  = diaporama[ig].IMG[d].CT
			diapo[d].B  = diaporama[ig].IMG[d].B
			if diapo[d].B > nbColors or diapo[d].B <1 then diapo[d].B = 1 end
			diapo[d].BT = diaporama[ig].IMG[d].BT
			diapo[d].C = diaporama[ig].IMG[d].C
			if diapo[d].C > nbColors or diapo[d].C <1 then diapo[d].C = 1 end
			diapo[d].OR = diaporama[ig].IMG[d].OR
			if diapo[d].OR <1 or diapo[d].OR>8 then diapo[d].OR = 1 end
			diapo[d].pp = diaporama[ig].IMG[d].PP == 1
			diapo[d].Bd  = diaporama[ig].IMG[d].Bd
			if diapo[d].Bd > nbColors or diapo[d].Bd <1 then diapo[d].Bd = 1 end
			diapo[d].BdT = diaporama[ig].IMG[d].BdT
			diapo[d].ox= (diapo[d].orX+1)/2
			diapo[d].oy= (diapo[d].orY+1)/2
			if diapo[d].OR % 2 == 0 and not diapo[d].deform then
				invertSides(d)
			end
		else
			-- default values
			shiftImg = shiftImg + 50
			diapo[d].orX = imgDefPosX
			diapo[d].orY = imgDefPosY
			diapo[d].ox= (diapo[d].orX+1)/2
			diapo[d].oy= (diapo[d].orY+1)/2
			diapo[d].width  = imageWidth
			diapo[d].height = imageHeight
			diapo[d].X = width * diapo[d].ox -imageWidth- shiftImg
			diapo[d].Y = -height*diapo[d].oy + shiftImg
			diapo[d].CT = 100
			diapo[d].C = 1
			diapo[d].B = 1
			diapo[d].pp = false
			diapo[d].OR = 1
			diapo[d].Bd = 1
			diapo[d].BdT = 0
			if special
				then diapo[d].BT = 50
				else diapo[d].BT = 0
			end
		end
		diapoFrame[d].r = slideTextColor[diapo[d].C][1]
		diapoFrame[d].g = slideTextColor[diapo[d].C][2]
		diapoFrame[d].b = slideTextColor[diapo[d].C][3]
		diapoFrame[d].Transp = diaporama[ig].IMG[d].CT /100
		diapoFrame[d].OR = diapo[d].OR
		diapo[d].bgCol={}
		diapo[d].border={}
		for i=1,3 do
			diapo[d].bgCol[i] = slideTextColor[diapo[d].B][i]
			diapo[d].border[i] = slideTextColor[diapo[d].Bd][i]
		end
		diapo[d].bgCol[4]=diapo[d].BT / 100
		diapo[d].border[4]=diapo[d].BdT / 100

		if special then image = nil end
		diapoFrame[d].Fillimage=image
		if diapo[d].BT > 0 then
			diapoFrame[d].Fillcolor=diapo[d].bgCol
		else
			diapoFrame[d].Fillcolor = nil
		end
		if diapo[d].BdT > 0 then
			diapoFrame[d].Bordercolor=diapo[d].border
		else
			diapoFrame[d].Bordercolor=nil
		end

		if missing then
			diapoFrame[d].Text = {_("Missing image: "),filename }
			diapoFrame[d].Textcolor = {1,0.2,0.2,1}
			diapoFrame[d].Textfont = normalfont
		else
			diapoFrame[d].Text = nil
		end

		savePosOrg(d)
		replaceDiapo(d)
	end
end

local urlState=function()
	if iObj>0 and diaporama[iObj].url then return 3 else return 2 end
end

-------------------------
-- Display selected slide
-------------------------
local activateObj = function(j, autoChange) -- line j of diaporama
	if not ready then return end
	ready = false
	if nbObjects>0 then iObj=j else iObj=0 end
	colTarg = 0
	nbdia=0; lastImage = 0
	nbtxt=0
	refFrame, selFrame = nil, nil
	diapo = { [0]= diapo[0] }
	img=0
	allowD={}; allowD[0]=true
	text = {}
	allowT={}
	if nbObjects > 0 then
		while iObj > nbObjects do iObj=iObj-nbObjects end
		while iObj < 1 do iObj = iObj + nbObjects end
		local obj = diaporama[iObj]
		slideDelay = obj.delay or slideshowDelay
		modifDelay = obj.delay or 0
		if autotime > 0 then autotime = slideDelay end
		if display_diapo and nbObjects>0 then
			if obj.url and allow_urls then
				if autoChange then
					celURLstring = string.gsub(obj.url,"&p=1","&p=0")
				else
					celURLstring = obj.url
				end
				os.setlocale("C", "numeric")
				celestia:seturl(celURLstring)
				os.setlocale("", "numeric")
			end
			if  obj.sound and soundAvailable then
				local x,y,ext = string.find(obj.sound,"%.(%w%w%w)%w?$")
				if ext == "cel" then
					slideshowCommand = "../"..slidesName.."/"..obj.sound
					celestia:runscript(slideshowCommand)
				elseif running_OS == "Windows" then
					if (ext == "htm" or ext == "php" or string.lower(string.sub(obj.sound,1,7))=="http://") and autotime == 0 then
						if string.find(obj.sound,"://") then
							executeHTMLcmdFile = [[cmd /C "start "" extras\slideshow\zutils\launchHtml.bat ]]..'"'.. obj.sound ..'""'
						else
							local file = celestiaSlidePath..obj.sound
							executeHTMLcmdFile = [[cmd /C "start "" extras\slideshow\zutils\launchHtml.bat ]]..'"'..file..'""'
						end
						executeHTMLcmdFile = string.gsub(executeHTMLcmdFile,"&","^&")
						os.execute(executeHTMLcmdFile)

					elseif ext ~= "htm" then
						if string.find(obj.sound,":[/\\]") then
							slideshowCommand = string.gsub(play_file_command,"PLAYFILE",obj.sound)
						else
							slideshowCommand = string.gsub(play_file_command,"PLAYFILE",celestiaSlidePath..obj.sound)
						end
						os.execute("extras\\slideshow\\zutils\\launchfile.bat "..slideshowCommand)
					end
				else
					slideshowCommand = string.gsub(play_file_command,"PLAYFILE",celestiaSlidePath..obj.sound)
					os.execute(slideshowCommand)
				end
			end
		end
		local ig = iObj
		if nbObjects <1 then ig = 0 end

		while ig>0 and not diaporama[ig].IMG[1] do ig = ig - 1 end
		if ig>0 then
			shiftImg = 0
			for i=1,maxdia do loadImage(i,ig) end
		end
		initTexts()
		for d=1,nbdia do
			if diapo[d] and diapo[d].pp then diapoFrame[d]:orderfront() end
		end
		if not display_diapo then
			if diaporama[iObj].desc ~= "" then
				addMessage(diaporama[iObj].desc)
			end
			if obj.delay then addMessage(_("Delay = ")..slideDelay.."s") end
			addMessage(_("slide #")..iObj.."/"..nbObjects)
		end
	end
	tele.frame:orderfront()
	if designMode then
		tele.frame.iconState = {3,3,urlState(),2,2,2,1}
		palette.frame:orderfront()
	end
	slideStart=celestia:getscripttime()
	if edit.oper ~= "Cut" and edit.oper ~= "Copy" then edit.oper = nil end
	ready = true
end

local writeSlide=function(fic,obj,short,numSlide)
	local al=true  -- cosmetic: don't add a separator at slide's begining

	if not short and numSlide ~=1 then fic:write(cr..cr) end
	for _,com in ipairs(obj.COM) do
		fic:write(com..cr)
	end

	if obj.delay and not short then
		fic:write("#D "..obj.delay .. cr)
		al=false
	end

	for d=1, # obj.IMG do
		fic:write(obj.IMG[d].file)
		if obj.IMG[d].Y and not short then fic:write(
			" ".. math.floor(obj.IMG[d].X) ..
			" ".. math.floor(obj.IMG[d].Y) ..
			" ".. math.floor(obj.IMG[d].W) ..
			" ".. obj.IMG[d].orX ..
			" ".. obj.IMG[d].orY ..
			" ".. obj.IMG[d].CT ..
			" ".. obj.IMG[d].R ..
			" ".. obj.IMG[d].B ..
			" ".. obj.IMG[d].BT ..
			" ".. obj.IMG[d].C ..
			" ".. obj.IMG[d].PP ..
			" ".. obj.IMG[d].OR ..
			" ".. obj.IMG[d].Bd ..
			" ".. obj.IMG[d].BdT
			)
		end
		fic:write(cr)
		al=false
	end

	if obj.sound then fic:write(obj.sound .. cr) al=false end
	if obj.url and not short then fic:write(obj.url .. cr) al=false end
	for t=1, # obj.TXT do
		local septext = "=="
		if short then septext = "" end
		if t>1 or not al then fic:write(septext..cr) end
		for _,line in ipairs(obj.TXT[t].text) do
			fic:write(line ..cr)
		end
		if not short and obj.TXT[t].X then
			fic:write(
				"# "..obj.TXT[t].orX ..
				" ".. obj.TXT[t].orY ..
				" ".. math.floor(obj.TXT[t].X) ..
				" ".. math.floor(obj.TXT[t].Y) ..
				" ".. obj.TXT[t].Z ..
				" ".. obj.TXT[t].C ..
				" ".. obj.TXT[t].CT ..
				" ".. obj.TXT[t].B ..
				" ".. obj.TXT[t].BT ..
				" ".. obj.TXT[t].P ..
				" ".. obj.TXT[t].M ..
				" ".. obj.TXT[t].Bd ..
				" ".. obj.TXT[t].BdT ..
				cr)
		end
	end
end

local saveCurrentSlide = function()
	local fic = io.open(exePath.."slide_description.txt", "w")
	if fic then
		obj = diaporama[iObj]
		writeSlide(fic,obj,true,1)
		fic:close()
	else
		addMessage(_"Fail to create ".."slide_description.txt")
	end
end

local function SaveSlideshow(bis)
	local fic = io.open(slideCatalog, "w")
	if fic then
		for i,obj in ipairs(diaporama) do
			writeSlide(fic,obj,false,i)
		end
		fic:close()
	else
		os.execute('mkdir "extras/slideshow/'..slidesName..'"')
		if not bis then
			SaveSlideshow(true)
		else
			addMessage(_"Fail to create "..slidesName)
		end
	end
end

local SaveSettings=function()
	if nbObjects <1 then return end
	for d=1,nbdia do
		if diapo[d] then
			diaporama[img].IMG[d].file = diapo[d].file
			diaporama[img].IMG[d].W = math.max(diapo[d].width, diapo[d].height)
			diaporama[img].IMG[d].X =   diapo[d].X
			diaporama[img].IMG[d].Y =   diapo[d].Y
			diaporama[img].IMG[d].orX = diapo[d].orX
			diaporama[img].IMG[d].orY = diapo[d].orY
			diaporama[img].IMG[d].CT = diapo[d].CT
			if diapo[d].deform
				then diaporama[img].IMG[d].R = math.floor(diapo[d].imageRatio * 1e6)
				else diaporama[img].IMG[d].R = 0
			end
			diaporama[img].IMG[d].B = diapo[d].B
			diaporama[img].IMG[d].BT = diapo[d].BT
			diaporama[img].IMG[d].C = diapo[d].C
			if diapo[d].pp
				then diaporama[img].IMG[d].PP = 1
				else diaporama[img].IMG[d].PP = 0
			end
			diaporama[img].IMG[d].OR = diapo[d].OR
			diaporama[img].IMG[d].Bd = diapo[d].Bd
			diaporama[img].IMG[d].BdT = diapo[d].BdT
			savePosOrg(d)  -- new values are now original values
		end
	end

	if allow_urls then
		if tele.frame.iconState[3]==3
			then diaporama[iObj].url = celestia:geturl()
			else diaporama[iObj].url = nil
		end
	end
	for t=1, nbtxt do
		diaporama[iObj].TXT[t].orX = text[t].orX
		diaporama[iObj].TXT[t].orY = text[t].orY
		diaporama[iObj].TXT[t].X = text[t].X
		diaporama[iObj].TXT[t].Y = text[t].Y
		diaporama[iObj].TXT[t].Z = text[t].J * 2
		diaporama[iObj].TXT[t].C = text[t].C
		diaporama[iObj].TXT[t].CT = text[t].CT
		diaporama[iObj].TXT[t].B = text[t].B
		diaporama[iObj].TXT[t].BT = text[t].BT
		diaporama[iObj].TXT[t].P = text[t].P
		diaporama[iObj].TXT[t].M = text[t].M
		diaporama[iObj].TXT[t].Bd = text[t].Bd
		diaporama[iObj].TXT[t].BdT = text[t].BdT
	end
	if modifDelay>0 then
		diaporama[iObj].delay = modifDelay
	else
		diaporama[iObj].delay = nil
	end
end


local setAuto=function(ON)
	if ON and slideshowDelay>0 then
		if autotime==0 then
			addMessage(_("Auto feed ON"))
			tele.frame.Text = "-->"
			slideStart=celestia:getscripttime()
		end
		autotime = slideDelay
	else
		if autotime > 0 then
			addMessage(_("Auto feed OFF"))
			tele.frame.Text = ""
		end
		autotime=0
	end
end

local firstSlide = function()
	if autotime>0 then
		delayMinus()
	else
		activateObj(1, autotime>0)
	end
end

local previousSlide = function()
	activateObj(iObj-1, autotime>0)
end

local nextSlide = function(mouse)
	if nbObjects>0 then
		if mouse and iObj == nbObjects then
			addMessage(_("This is the last slide..."))
		else
			activateObj(iObj+1, autotime>0)
		end
	end
end

local fastAdvance = function()
	if autotime>0 then
		delayPlus()
	else
		iObj = iObj+ fastStep
		if iObj > nbObjects then iObj= nbObjects end
		activateObj(iObj, autotime>0)
	end
end

local toggleTeleHidden = function()
	if tele.display then
		tele.hidden=not tele.hidden
		if tele.hidden then
			keymap[key.forward]= nextSlide
			keymap[key.backward]= previousSlide
			keymap[key.first]= firstSlide
			keymap[key.fast]= fastAdvance
		else
			keymap[key.forward]= nil
			keymap[key.backward]= nil
			keymap[key.first]= nil
			keymap[key.fast]= nil
		end
		if display_diapo then
			reorderFrames(true)
		end
	end
end

local hideSlides = function()
	setAuto(false)
	display_diapo = not display_diapo
	if display_diapo then
		addMessage(_("Stealth mode OFF")..cr)
		keymap[key.deviceVisibility] = toggleTeleHidden
		tele.frame.Text = ""
	else
		addMessage(_("Stealth mode ON")..cr)
		keymap[key.deviceVisibility] = nil
		tele.frame.Text = _("Stealth mode")
	end
	activateObj(iObj)
end

local pause = function()
	local setpause = function()
		local url = string.gsub(celestia:geturl(),"&p=0","&p=1")
		celestia:seturl(url)
		addMessage(_("Time is paused"))
	end

	if autotime == 0 then
		if celestia:ispaused() then
			local url = string.gsub(celestia:geturl(),"&p=1","&p=0")
			celestia:seturl(url)
			addMessage(_("Resume"))
		else
			if celestia:gettimescale() == 0 then
				if designMode then
					celestia:settimescale(oldTimeScale)
					setpause()
				else
					celestia:settimescale(1)
				end
			else
				if designMode then
					oldTimeScale = celestia:gettimescale()
					celestia:settimescale(0)
				else
					setpause()
				end
			end
		end
	else
		setAuto(false)
		if tele.hidden then toggleTeleHidden() end
	end
end

local toggleAuto=function()
	local ok =true
	if autotime == 0 then
		display_diapo = true
		activateObj(iObj,true)
		if celestia:ispaused() then
			if allow_urls then
				pause()
			else
				addMessage(_("Time is paused"))
				ok = false
			end
		end
		tele.frame.Text = ""
		keymap[key.deviceVisibility] = toggleTeleHidden
	else
		ok = false
	end
	if ok then
		setAuto(true)
		if not tele.hidden then toggleTeleHidden() end
	else
		setAuto(false)
		if tele.hidden then toggleTeleHidden() end
	end
end

local resetTele = function() -- switches to normal display
	designMode = false
	diapoFrame[0].Visible = false
	palette.display = false
	edit.display = false
	keymap[key.forward]= nil
	keymap[key.backward]= nil
	keymap[key.first]= nil
	keymap[key.fast]= nil
	keymap[key.deviceVisibility]=toggleTeleHidden
	tele.hidden = false
	selFrame, refFrame = nil, nil
	tele.frame.Text = ""
	tele.frame.iconState={1,1,1,1,1,1,1}
	reorderFrames(true)
end

local escape = function() -- quit design mode without saving
	resetTele()
	activateObj(iObj)
end

---------------------------------------
-- Images and text frame functions
---------------------------------------
local rotLeft  = {2,3,4,1,6,7,8,5}
local rotRight = {4,1,2,3,8,5,6,7}
local horizontalFlip = {5,8,7,6,1,4,3,2}
local verticalFlip   = {7,6,5,8,3,2,1,4}

local getSel = function()
	if selFrame then
		if selFrame.isImage
			then return diapo[selFrame.id]
			else return text[selFrame.id]
		end
	end
end

local getframes = function()
	local source = nil
	local target = getSel()
	if refFrame then
		if refFrame.isImage
			then source = diapo[refFrame.id]
			else source = text[refFrame.id]
		end
	end
	return target, source
end

local saveAxes = function()
	local frame
	if selFrame.isImage
		then frame=diapo[selFrame.id]
		else frame= text[selFrame.id]
	end
	saveCoord.ox = frame.ox
	saveCoord.oy = frame.oy
	saveCoord.orX = frame.orX
	saveCoord.orY = frame.orY
end

local restoreAxes = function()
	local frame
	if selFrame.isImage
		then frame=diapo[selFrame.id]
		else frame= text[selFrame.id]
	end
	frame.ox = saveCoord.ox
	frame.oy = saveCoord.oy
	frame.orX = saveCoord.orX
	frame.orY = saveCoord.orY
end

local stick = function()
-- only called if selFrame and refFrame exist
	local target, source
	local free = true

	local stickIt = function()
		free=false
		selFrame:attach(screenBox, getBounds(target))
	end

	if selFrame.isImage
		then target = diapo[selFrame.id]
		else target = text[selFrame.id]
	end
	if refFrame.isImage
		then source = diapo[refFrame.id]
		else source = text[refFrame.id]
	end

	local d1 = math.abs(selFrame.la - refFrame.la)
	local d2 = math.abs((selFrame.la + target.width/2) - (refFrame.la + source.width/2))
	local d3 = math.abs(selFrame.ra - refFrame.ra)
	local dx = math.min(d1,d2,d3)
	if dx < sticky and dx >0.5 then
		target.ox = source.ox; target.orX = source.orX
		if dx == d1 then -- align left
			target.X = refFrame.la - width* target.ox
		elseif dx == d2 then -- center
			target.X = refFrame.la  +  (source.width -target.width)/2 - width* target.ox
		else  --  align right
			target.X = refFrame.la + source.width - target.width - width* target.ox
		end
		stickIt()
	end

	d1 = math.abs(selFrame.ba - refFrame.ba)
	d2 = math.abs( (selFrame.ba + target.height/2) - (refFrame.ba + source.height/2) )
	d3 = math.abs(selFrame.ta - refFrame.ta)
	local dy = math.min(d1,d2,d3)
	if dy < sticky and dy > 0.5 then
		target.oy = source.oy; target.orY = source.orY
		if dy == d1 then
			target.Y = refFrame.ba - height* target.oy
		elseif dy == d2 then
			target.Y = refFrame.ba  +  source.height/2  -target.height/2 - height* target.oy
		else
			target.Y = refFrame.ba + source.height - target.height - height* target.oy
		end
		stickIt()
	end

	if free then restoreAxes() end
end

----------------------------------------------
-- boxes and frames functions
----------------------------------------------

slideshow.Customdraw = function(this)
	if lua_edu_tools then
		textlayout:setfont(normalfont);
		textlayout:setfontcolor(cslide);
		textlayout:setpos(this.lb+25, this.tb-14);
		textlayout:println(_("Slideshow"));
	end
end

slideControl.Customdraw = function(this)
	if tele.display then
		local oldwidth, oldheight = width, height
		width, height = celestia:getscreendimension()
		if oldwidth ~= width or oldheight ~= height then
			if not designMode then -- restore recorded position
				for i=1, nbdia do
					if diapo[i] then
						if diapo[i].OR %2 ~= diapo[i].posOrg.OR % 2 then
							invertSides(i)
						end
						for m,v in pairs(diapo[i].posOrg) do diapo[i][m]=v end
					end
				end
				for i=1, nbtxt do
					text[i].X = diaporama[iObj].TXT[i].X
					text[i].Y = diaporama[iObj].TXT[i].Y
				end
			end
			replaceTool(tele)
			for i=1, nbdia do replaceDiapo(i) end
			for i=1,nbtxt do printText(i) end
			if not designMode then
				for d=1,nbdia do
					if diapo[d] and diapo[d].pp then diapoFrame[d]:orderfront() end
				end
			end
			if palette.display then replaceTool(palette) end
			if edit.display then replaceTool(edit) end
			if diapoFrame[0].Visible then replaceDiapo(0) end
		end
		if autotime > 0 then
			if celestia:ispaused() then
				addMessage(_("Time is paused"))
				if tele.hidden then toggleTeleHidden() end
				setAuto(false)
			else
				if celestia:getscripttime() - slideStart > autotime then
					activateObj(iObj+1,true)
				end
			end
		end
		tele.frame.Visible = tele.display and tele.allow and (not tele.hidden)
		palette.frame.Visible = palette.display and palette.allow
		edit.frame.Visible = edit.display and edit.allow
		for d=1,maxdia do diapoFrame[d].Visible = display_diapo and allowD[d] end
		for t=1,maxtxt do textFrame[t].Visible  = display_diapo and allowT[t] end
		if messages ~= "" then printMessages(3) end
	end
end

local cadre = function(frame, col, ext)
	gl.Color(unpack(col));
	gl.Disable(gl.TEXTURE_2D)
	gl.Begin(gl.LINE_LOOP)
	gl.Vertex(frame.rb+ext, frame.bb-ext)
	gl.Vertex(frame.rb+ext, frame.tb+ext)
	gl.Vertex(frame.lb-ext, frame.tb+ext)
	gl.Vertex(frame.lb-ext, frame.bb-ext)
	gl.End()
end

local diapoFrameCustomdraw = function(this)
	local id = this.id
	if not allowD[id] then return end
	local freeX = this.ra - 2
	local freeY = this.ta - 2
	local dx =resize.margin - this.resizeDiapoFrame.ra
	local dy =resize.margin - this.resizeDiapoFrame.ta
	local resized = false
	if diapo[id].deform then
		if dx ~=0 or dy ~=0 then
			if dx> freeX then dx = freeX end
			if dy> freeY then dy = freeY end
			local maxdx =diapo[id].width  - resize.margin - resize.square-3
			if -dx > maxdx then dx = - maxdx end
			local maxdy =diapo[id].height  - resize.margin - resize.square-3
			if -dy > maxdy then dy = - maxdy end
			diapo[id].width = width - this.ra - this.la + dx
			diapo[id].height = height - this.ta - this.ba + dy
			diapo[id].imageRatio = diapo[id].width / diapo[id].height
			this:attach(screenBox,
				this.la, this.ba,
				width - this.la - diapo[id].width,
				height - this.ba - diapo[id].height)
			resized = true
		end
	else
		if diapo[id].imageRatio > 1 then -- always resize the largest side for precision
			if dx+dy ~= 0  and (this.ta >2 or dx<0) then
				if freeY < freeX then freeX = freeY end
				if math.abs(dy) > math.abs(dx) then dx, dy = dy, dx end
				if dx*dy >0 then dx = dx + dy end
				local maxdx =diapo[id].height  - resize.margin - resize.square-3
				if -dx > maxdx then dx = - maxdx end
				if dx>freeX then dx = freeX end
				diapo[id].width = width - this.ra - this.la + dx
				diapo[id].height = diapo[id].width / diapo[id].imageRatio
				this:attach(screenBox,
					this.la, this.ba, this.ra - dx, height - this.ba - diapo[id].height)
				resized=true
			end
		else
			if dy+dx ~= 0 and (this.ra >2 or dy<0)then
				if freeX < freeY then freeY = freeX end
				if math.abs(dx) > math.abs(dy) then dy, dx = dx, dy end
				if dx*dy >0 then dy = dy + dx end
				local maxdy =diapo[id].width  - resize.margin - resize.square-3
				if -dy > maxdy then dy = - maxdy end
				if dy>freeY then dy = freeY end
				diapo[id].height = height - this.ta - this.ba + dy
				diapo[id].width = diapo[id].height * diapo[id].imageRatio
				this:attach(screenBox,
					this.la, this.ba,width - this.la - diapo[id].width, this.ta - dy)
				resized=true
			end
		end
	end
	if resized then
		this.resizeDiapoFrame:attach(this,
			width - this.ra - this.la -resize.corner,
			height - this.ta - this.ba -resize.corner,
			resize.margin,resize.margin)
	end
	diapo[id].X = this.la - width* diapo[id].ox
	diapo[id].Y = this.ba - height*diapo[id].oy
	if designMode then
		if this.Move or this.resizeDiapoFrame.Move then
			if this ~= selFrame then
				refFrame = selFrame
				selFrame = this
				this.resizeDiapoFrame.Fillcolor=resize.normalColor
				colTarg = 0
				saveAxes()
				if refFrame and palette.frame.align.Mode < 20 then
					palette.frame.align.Mode = refFrame.alMode or 10
				end
			elseif palette.frame.magnet.ON and not this.resizeDiapoFrame.Move and refFrame then
				stick()
			end
		end
		if this == selFrame then
			this.resizeDiapoFrame.Fillcolor=resize.designColor
			this.resizeDiapoFrame.Bordercolor= resize.designBorder
			if showSel then cadre(this, selColor, selExt) end
		else
			this.resizeDiapoFrame.Fillcolor = nil
			this.resizeDiapoFrame.Bordercolor = nil
			if this == refFrame and showRef then
				cadre(this, refColor, selExt)
			end
		end
	else
		this.resizeDiapoFrame.Fillcolor=nil --resize.normalColor
		this.resizeDiapoFrame.Bordercolor= resize.normalBorder
	end
	if this.Text and not this.Bordercolor  then
		cadre(this, {1,0,0,0.8} ,0)
	end
end

local textFrameCustomdraw = function(this)
	local id=this.id
	if not allowT[id] then return end
	_textlayout:setpos(this.la + text[id].M , this.ba - text[id].M
		+ text[id].height  - text[id].charH + text[id].charH /5) -- /5 is good for arial like font
	_textlayout:setfont(fonts[text[id].P]);
	_textlayout:setlinespacing(text[id].charH + 0);
	_textlayout:setfontcolor(text[id].color);
	for i,t in ipairs(text[id].tx) do
		_textlayout.xpos = _textlayout.xpos + t.indent
		_textlayout:println(t.line)
	end
	text[id].X = this.la - width* text[id].ox
	text[id].Y = this.ba - height*text[id].oy
	if designMode then
		if this.Move then
			if this ~= selFrame then
				refFrame = selFrame
				selFrame = this
				colTarg = 0
				saveAxes()
				if refFrame and  palette.frame.align.Mode < 20 then
					palette.frame.align.Mode = refFrame.alMode or 10
				end
			elseif palette.frame.magnet.ON and refFrame then
				stick()
			end
		end
		if this == selFrame then
			if showSel then cadre(this,selColor,selExt) end
		elseif this == refFrame then
			if showRef then cadre(this,refColor,selExt) end
		end
	end
end

for i=0, maxdia do diapoFrame[i].Customdraw = diapoFrameCustomdraw end
for i=1, maxtxt do textFrame[i].Customdraw =  textFrameCustomdraw  end


--
-- Palette functions
--

createPaletteFunctions=function()
	local rotate = function(direction)
		if selFrame then
			local target = getSel()
			target.X = target.X - (target.height - target.width) / 2
			target.Y = target.Y + (target.height - target.width) / 2
			target.OR = direction[target.OR]
			invertSides(selFrame.id)
			selFrame.OR = target.OR
		end
	end

	palette.frame.nFont.Action = function() toggleFont(1) end
	palette.frame.pFont.Action = function() toggleFont(-1) end
	palette.frame.alignText.Action = toggleJustif


	palette.frame.rotSymLeft.Action = function()
		if selFrame then
			local target = getSel()
			if palette.frame.rotSym.Mode == 1 then
				rotate(rotLeft)
			else
				target.OR = horizontalFlip[target.OR]
				selFrame.OR = target.OR
			end
		end
	end

	palette.frame.rotSymRight.Action = function()
		if selFrame then
			local target = getSel()
			if palette.frame.rotSym.Mode == 1 then
				rotate(rotRight)
			else
				target.OR = verticalFlip[target.OR]
				selFrame.OR = target.OR
			end
		end
	end

	palette.frame.rotSym.Action = function(this)
		this.Mode = 3 - this.Mode
		if this.Mode == 1 then
			palette.frame.rotSymLeft.Fillimage = palette.rotSymIcon[1]
			palette.frame.rotSymRight.Fillimage = palette.rotSymIcon[2]
		else
			palette.frame.rotSymLeft.Fillimage = palette.rotSymIcon[3]
			palette.frame.rotSymRight.Fillimage = palette.rotSymIcon[4]
			this.Mode = 2
		end
	end

	palette.frame.imgOrder.Customdraw = function(this)
		if selFrame then
			if diapo[selFrame.id].pp then
				this.Fillimage = palette.imgOrderIcon[2]
			else
				this.Fillimage = palette.imgOrderIcon[1]
			end
		end
	end

	palette.frame.imgOrder.Action = function()
		if selFrame then
			diapo[selFrame.id].pp = not diapo[selFrame.id].pp
			reorderFrames(diapo[selFrame.id].pp)
		end
	end

	palette.frame.copyFormatr.Action = function()
		if refFrame and (refFrame.isImage == selFrame.isImage) then
			local target, source = getframes()
			target.C = source.C
			target.CT = source.CT
			target.B = source.B
			target.BT = source.BT
			target.Bd = source.Bd
			target.BdT = source.BdT
			for i=1,3 do target.bgCol[i] = slideTextColor[target.B][i] end
			target.bgCol[4] = target.BT / 100
			for i=1,3 do target.border[i] = slideTextColor[target.Bd][i] end
			target.border[4] = target.BdT / 100
			if target.BT>0 then
				selFrame.Fillcolor=target.bgCol
			else
				selFrame.Fillcolor = nil
			end
			if target.BdT>0 then
				selFrame.Bordercolor=target.border
			else
				selFrame.Bordercolor = nil
			end
			if selFrame.isImage then
				selFrame.r = slideTextColor[target.C][1]
				selFrame.g = slideTextColor[target.C][2]
				selFrame.b = slideTextColor[target.C][3]
				selFrame.Transp= target.CT/100
			else
				target.P = source.P
				target.M = source.M
				target.J = source.J
				for i=1,3 do target.color[i] = slideTextColor[target.C][i] end
				target.color[4] = target.CT / 100
				calcTextSize(selFrame.id)
				printText(selFrame.id)
			end
		end
	end

	palette.frame.colorTarget.Action = function(this)
		if not selFrame then return end
		if selFrame.isImage then
			if colTarg == 3 then
				colTarg = 4
			elseif colTarg == 4 then
				colTarg = 5
			elseif colTarg == 5 then
				if not diapo[selFrame.id].special then
					colTarg = 3
				else
					colTarg = 4
				end
			end
		else
			if colTarg == 1 then
				colTarg = 2
			elseif colTarg == 2 then
				colTarg = 5
			elseif colTarg == 5 then
				colTarg = 1
			end
		end
	end

	palette.frame.colorTarget.Customdraw=function(this)
		if selFrame then
			if colTarg ~= 5 then
				if selFrame.isImage then
					if colTarg <3 then
						if diapo[selFrame.id].special
							then colTarg = 4
							else colTarg = 3
						end
					end
				elseif colTarg <1 or colTarg >2 then
					colTarg = 1
				end
			end
		else
			colTarg = 0
		end
		if colTarg > 0 then
			this:text(_(colTargText[colTarg]))
		else
			this:text("- - - -")
		end
	end

	palette.frame.margin.Customdraw=function(this)
		if selFrame then
			if this.Highlight then
				if tonumber(this.Text) then
					local target = text[selFrame.id]
					target.M = tonumber(this.Text)
					if target.M < 1 and (target.BT~=0 or target.BdT ~=0) then
						target.M = 1
					end
				end
				calcTextSize(selFrame.id)
				printText(selFrame.id)
			else
				if selFrame and not selFrame.isImage then
					this.Text = tostring(text[selFrame.id].M)
				else
					this.Text = "---"
				end
				this.Editable = true
			end
		else
			this.Editable = false
			this.Text = "---"
		end
	end

	palette.frame.margin.Action = function(this)
		if selFrame and not selFrame.isImage then  this.Text = "" end
	end

	palette.frame.deform.Customdraw = function(this)
		if selFrame and selFrame.isImage then
			if diapo[selFrame.id].deform then
				this.Text = "~"
			else
				this.Text = "="
			end
		else
			this.Text = "..."
		end
	end

	palette.frame.deform.Action = function(this)
		if selFrame then
			thisDiapo = diapo[selFrame.id]
			if not thisDiapo.special then
				thisDiapo.deform = not thisDiapo.deform
				if thisDiapo.deform then
					thisDiapo.file = "~"..thisDiapo.file
				else
					thisDiapo.file = string.sub(thisDiapo.file,2)
					if thisDiapo.OR % 2 == 0 then
						thisDiapo.height = thisDiapo.width * thisDiapo.orgRatio
					else
						thisDiapo.width = thisDiapo.height * thisDiapo.orgRatio
					end
					thisDiapo.imageRatio = thisDiapo.width / thisDiapo.height
					replaceDiapo(selFrame.id)
				end
			end
		end
	end

	palette.frame.magnet.Action = function(this)
		this.ON = not this.ON
		if this.ON then
			this:fillimage(palette.magnetIcon[1])
		else
			this:fillimage(palette.magnetIcon[2])
		end
	end

	palette.frame.align.Customdraw = function(this)
		this.Fillimage=palette.alignIcon[math.floor(this.Mode / 10)]
	end

	palette.frame.align.Action = function(this)
		palette.frame.alignMenu.Visible = not palette.frame.alignMenu.Visible
	end

	local modeButtonAction=function(this)
		palette.frame.align.Mode = this.id *10
		palette.frame.alignMenu.Visible=false
	end

	for i=1,palette.nbMenuBut do
		palette.frame.alignMenu.button[i].Action = modeButtonAction
	end


	palette.frame.horizontal.Action = function()
		if selFrame then
			local target, source = getframes()
			if palette.frame.align.Mode == 20 then
				target.orX = 0; target.ox = 1/2
				target.X = -target.width /2
				saveAxes()

			elseif refFrame then
				if palette.frame.align.Mode == 30 then
					if selFrame.isImage then
						target.width = source.width
						if target.deform then
							target.imageRatio = target.width / target.height
						else
							target.height = target.width/target.imageRatio
						end
					elseif target.BT>0 or target.BdT > 0 then
						if source.width > target.width - 2*target.M then
							target.M = math.floor((source.width - (target.width - 2*target.M))/2)
						else
							target.M = 1
						end
						calcTextSize(selFrame.id)
						printText(selFrame.id)
					end
				else
					target.orX = source.orX; target.ox = source.ox
					saveAxes()
					if palette.frame.align.Mode == 10 then
						target.X = source.X
					elseif palette.frame.align.Mode == 11 then
						target.X = source.X + (source.width - target.width )/2
					elseif palette.frame.align.Mode == 12 then
						target.X = source.X + source.width - target.width
					end
					selFrame.alMode = palette.frame.align.Mode
					palette.frame.align.Mode = palette.frame.align.Mode + 1
					if palette.frame.align.Mode > 12 then palette.frame.align.Mode = 10 end
				end
			end
			if selFrame.isImage then replaceDiapo(selFrame.id) else printText(selFrame.id) end
		end
		palette.frame.alignMenu.Visible=false
	end

	palette.frame.vertical.Action = function()
		if selFrame then
			local target, source = getframes()
			if palette.frame.align.Mode == 20 then
				target.orY = 0; target.oy = 1/2
				target.Y = -target.height /2
				saveAxes()

			elseif refFrame then
				if palette.frame.align.Mode == 30 then
					if selFrame.isImage then
						target.height = source.height
						if target.deform then
							target.imageRatio = target.width / target.height
						else
							target.width = target.height*target.imageRatio
						end
					elseif target.BT>0 or target.BdT > 0 then
						if source.height > target.height - 2*target.M then
							target.M = math.floor((source.height - (target.height - 2*target.M))/2)
						else
							target.M = 1
						end
						calcTextSize(selFrame.id)
						printText(selFrame.id)
					end
				else
					target.orY = source.orY; target.oy = source.oy
					saveAxes()
					if palette.frame.align.Mode == 10 then
						target.Y = source.Y
					elseif palette.frame.align.Mode == 11 then
						target.Y = source.Y + (source.height - target.height )/2
					elseif palette.frame.align.Mode == 12 then
						target.Y = source.Y + source.height - target.height
					end
					selFrame.alMode = palette.frame.align.Mode
					palette.frame.align.Mode = palette.frame.align.Mode + 1
					if palette.frame.align.Mode > 12 then palette.frame.align.Mode = 10 end
				end
			end
			if selFrame.isImage then replaceDiapo(selFrame.id) else printText(selFrame.id) end
		end
		palette.frame.alignMenu.Visible=false
	end

	palette.frame.delay.Customdraw = function(this)
		if this.Highlight then
			modifDelay = tonumber(this.Text) or 0
			oldDelay=-1
		elseif modifDelay ~= oldDelay then
			oldDelay = modifDelay
			if modifDelay >0 then
				this.Text = tostring(modifDelay)
			else
				this.Text = "Auto"
			end
		end
	end

	palette.frame.delay.Action = function(this)
		this.Text = ""
	end

	local colorIconCustomdraw=function(this)
		if not selFrame then
			this.Bordercolor=nil
		else
			local color
			if        colTarg == 2 then color = text[selFrame.id].B
			   elseif colTarg == 1 then color = text[selFrame.id].C
			   elseif colTarg == 4 then color = diapo[selFrame.id].B
			   elseif colTarg == 3 then color = diapo[selFrame.id].C
			   elseif colTarg == 5 then
				if selFrame.isImage
					then color = diapo[selFrame.id].Bd
					else color = text[selFrame.id].Bd
				end
			end
			if color == this.id
				then this.Bordercolor={1,1,1,1}
				else this.Bordercolor=nil
			end
		end
	end

	local colorIconAction = function(this)
		if selFrame then
			local target = getSel()
			if colTarg == 1 then
				target.C = this.id
				for i=1,3 do target.color[i] = slideTextColor[target.C][i] end

			elseif colTarg == 2 then  -- fond de texte
				if target.B == this.id and target.BT > 0 then
					target.BT = 0
					target.bgCol[4] = 0
				else
					target.B = this.id
					for i=1,3 do target.bgCol[i] = slideTextColor[target.B][i] end
					if target.bgCol[4] ==0 then
						target.bgCol[4]=0.3
						target.BT = 30
					end
				end
				if target.BT > 0 then
					selFrame.Fillcolor= target.bgCol
				else
					selFrame.Fillcolor = nil
				end

			elseif colTarg == 3 then
				target.C = this.id
				selFrame.r = slideTextColor[this.id][1]
				selFrame.g = slideTextColor[this.id][2]
				selFrame.b = slideTextColor[this.id][3]

			elseif colTarg == 4 then -- fond d'image
				if target.B == this.id and target.BT > 0 then
					target.BT = 0
					target.bgCol[4] = 0
				else
					target.B= this.id
					for i=1,3 do target.bgCol[i] = slideTextColor[target.B][i] end
				end
				if target.BT ~= 0 then
					selFrame.Fillcolor=target.bgCol
				else
					selFrame.Fillcolor=nil
				end

			elseif colTarg == 5 then
				local target = getSel()
				if target.Bd == this.id and target.BdT >0 then
					target.BdT = 0
					target.border[4] = 0
				else
					target.Bd= this.id
					for i=1,3 do target.border[i] = slideTextColor[target.Bd][i] end
					if target.border[4]==0 then
						target.border[4]=1
						target.BdT = 100
					end
				end
				if target.BdT ~= 0 then
					selFrame.Bordercolor=target.border
				else
					selFrame.Bordercolor=nil
				end
			end
		end
	end

	for i=1, # slideTextColor do
		palette.frame.colorIcon[i].Action = colorIconAction
		palette.frame.colorIcon[i].Customdraw = colorIconCustomdraw
	end

	palette.frame.transBox.Customdraw=function(this)
		local transp = 100
		if selFrame then
			local id = selFrame.id
			if palette.frame.cursor.Move or this.Highlight then
				transp= math.floor((palette.frame.cursor.la-3)/146*100+0.5)
				if this.Highlight then
					transp = tonumber(this.Text) or transp
					if transp<0 then
						transp = 0
					elseif transp > 100 then
						transp = 100
					end
				end
				if colTarg == 1 then
					text[id].CT = transp
					text[id].color[4] = transp / 100
				elseif colTarg == 2 then
					text[id].BT = transp
					text[id].bgCol[4] = transp /100
					if transp > 0 then
						selFrame.Fillcolor= text[id].bgCol
					else
						selFrame.Fillcolor = nil
					end
				elseif colTarg == 3 then
					diapoFrame[id].Transp= transp/100
					diapo[id].CT = transp
				elseif colTarg == 4 then
					diapo[id].BT = transp
					diapo[id].bgCol[4] = transp / 100
					if transp > 0 then
						diapoFrame[id]:fillcolor(diapo[id].bgCol)
					else
						diapoFrame[id].Fillcolor = nil
					end
				elseif colTarg == 5 then
					local target = getSel()
					target.BdT = transp
					target.border[4] = transp / 100
					if transp > 0 then
						selFrame.Bordercolor= target.border
					else
						selFrame.Bordercolor = nil
					end
				end
			else
				if  colTarg == 1 then
					transp = text[id].CT
				elseif colTarg == 2 then
					transp = text[id].BT
				elseif colTarg == 3 then
					transp = diapo[id].CT
				elseif colTarg == 4 then
					transp = diapo[id].BT
				elseif colTarg == 5 then
					if selFrame.isImage
						then transp = diapo[id].BdT
						else transp = text[id].BdT
					end
				end
			end
			if not this.Highlight then this.Text=tostring(transp) end
		else
			transp= 100
			this.Text="---"
		end

		local mg = transp*146/100+3
		if mg ~= palette.frame.cursor.la then
			palette.frame.cursor:attach(palette.frame.transFrame,mg,3,164-mg-12,3)
		end
	end

	palette.frame.transBox.Action = function(this)
		if selFrame then
			this.Text = ""
		end
	end

	palette.frame.editBt.Action = function()
		toggleEdit()
	end

	palette.frame.Customdraw=function(this)
		palette.X=this.la
		palette.Y=this.ba
		if selFrame then
			palette.frame.margin.Visible = not selFrame.isImage
			palette.frame.deform.Visible = selFrame.isImage
			palette.frame.pFont.Visible = not selFrame.isImage
			palette.frame.rotSymLeft.Visible = selFrame.isImage
			palette.frame.rotSym.Visible = selFrame.isImage
			palette.frame.nFont.Visible = not selFrame.isImage
			palette.frame.rotSymRight.Visible = selFrame.isImage
			palette.frame.alignText.Visible = not selFrame.isImage
			palette.frame.imgOrder.Visible = selFrame.isImage
		end
	end
end

local loadPaletteIcons =function()
	if not palette.frame then
		createPaletteFrame()
		createPaletteFunctions()
	end
	if not palette.frame.pFont.Fillimage then -- only once
		if not palette.pFont then
			palette.pFont=celestia:loadtexture(utilPath.."prevfont.png")
			palette.nFont=celestia:loadtexture(utilPath.."nextfont.png")
			palette.rotSym=celestia:loadtexture(utilPath.."rondjaune.png")
			palette.alignText=celestia:loadtexture(utilPath.."justicon.png")
			palette.copyFormatr=celestia:loadtexture(utilPath.."copyformat.png")
			palette.rotSymIcon={
				celestia:loadtexture(utilPath.."rotl.png"),
				celestia:loadtexture(utilPath.."rotr.png"),
				celestia:loadtexture(utilPath.."symHor.png"),
				celestia:loadtexture(utilPath.."symVer.png"),
			}
			palette.alignIcon = {
				celestia:loadtexture(utilPath.."align.png"),
				celestia:loadtexture(utilPath.."screen.png"),
				celestia:loadtexture(utilPath.."resize.png"),
			}
			palette.vertical=celestia:loadtexture(utilPath.."vertical.png")
			palette.horizontal=celestia:loadtexture(utilPath.."horizontal.png")
			palette.imgOrderIcon={
				celestia:loadtexture(utilPath.."txtonimg.png"),
				celestia:loadtexture(utilPath.."imgontxt.png"),
			}
			palette.magnetIcon={
				celestia:loadtexture(utilPath.."activemagnet.png"),
				celestia:loadtexture(utilPath.."inactivemagnet.png"),
			}
		end
		palette.frame.pFont:fillimage(palette.pFont)
		palette.frame.nFont:fillimage(palette.nFont)
		palette.frame.rotSymLeft:fillimage(palette.rotSymIcon[1])
		palette.frame.rotSymRight:fillimage(palette.rotSymIcon[2])
		palette.frame.rotSym:fillimage(palette.rotSym)
		palette.frame.alignText:fillimage(palette.alignText)
		palette.frame.copyFormatr:fillimage(palette.copyFormatr)
		palette.frame.vertical:fillimage(palette.vertical)
		palette.frame.horizontal:fillimage(palette.horizontal)
		palette.frame.magnet:fillimage(palette.magnetIcon[1])
		for i=1,palette.nbMenuBut do palette.frame.alignMenu.button[i].Fillimage= palette.alignIcon[i] end

		-- diapoFrame[0] is ruler tool
		diapoFrame[0]:fillimage(celestia:loadtexture(utilPath.."regle.png"))
		diapo[0] = {}
		diapo[0].deform = true
		diapo[0].special = true
		diapo[0].width = 300
		diapo[0].height = 200
		diapo[0].X = -300
		diapo[0].Y = -200
		diapo[0].orX = 0
		diapo[0].orY = 0
		diapo[0].B = 1
		diapo[0].BT = 0
		diapo[0].Bd = 1
		diapo[0].BdT = 0
		diapo[0].CT = 100
		diapo[0].imageRatio = diapo[0].width / diapo[0].height
		diapo[0].ox = (diapo[0].orX+1)/2
		diapo[0].oy = (diapo[0].orY+1)/2
		diapo[0].bgCol = {0,0,0,0}
		diapo[0].border = {1,0,0,1}
	end
end

local togglePalette=function()
	palette.display = not palette.display
	if palette.display then
		loadPaletteIcons()
		replaceTool(palette)
		palette.frame:orderfront()
	else
		edit.display=false
		reorderFrames(true)
	end
	showSel = palette.display
	showRef = palette.display
end

--
-- telecommand functions
--

tele.frame.Customdraw = function(this)
	tele.X=tele.frame.la
	tele.Y=tele.frame.ba
	if designMode then
		if selFrame then
			if selFrame.isImage then
				tele.frame.iconState[1] = diapo[selFrame.id].orX + 3
				tele.frame.iconState[2] = diapo[selFrame.id].orY + 3
			else
				local target=text[selFrame.id]
				tele.frame.iconState[1] = target.orX + 3
				tele.frame.iconState[2] = target.orY + 3

				-- adjust text margin
				if target.M ~=0 and target.BT == 0 and target.BdT ==0 then
					target.M = 0
					calcTextSize(selFrame.id)
					printText(selFrame.id)
				elseif target.M == 0 and ( target.BT ~=0 or target.BdT ~= 0) then
					target.M = txtMarg
					calcTextSize(selFrame.id)
					printText(selFrame.id)
				end
			end
		end
	end
	this.buttons[0].Visible = display_diapo
	this.buttons["sound"].Visible = display_diapo
end

tele.frame.buttons[0].Action = function()
	if designMode then
		escape()
	else
		toggleTeleHidden()
		addMessage(_("Command tool hidden"))
		addMessage(_("press ").."'"..key.deviceVisibility.."'".._(" to recover"))
	end
end

tele.frame.buttons["sound"].Action = function()
	soundAvailable = (not soundAvailable) and sound_available
end

tele.frame.buttons[1].Action = (function()
    return
        function()
			if designMode then -- horizontal mode
				if selFrame then
					local cible
					if selFrame.isImage
						then cible = diapo[selFrame.id]
						else cible = text[selFrame.id]
					end
					tele.frame.iconState[1] = (tele.frame.iconState[1]-1)%3 + 2
					cible.orX = tele.frame.iconState[1]-3
					cible.ox = (cible.orX+1)/2
					cible.savox = cible.ox
					cible.X = selFrame.la- width *cible.ox
					saveAxes()
				end
			else -- normal mode
				hideSlides()
			end
		end
    end) ()

tele.frame.buttons[2].Action = (function()
    return
        function()
			if designMode then -- vertical mode
				if selFrame then
					local cible
					if selFrame.isImage
						then cible = diapo[selFrame.id]
						else cible = text[selFrame.id]
					end
					tele.frame.iconState[2] = (tele.frame.iconState[2]-1)%3 + 2
					cible.orY = tele.frame.iconState[2] -3
					cible.oy = (cible.orY +1 ) /2
					cible.savoy = cible.oy
					cible.Y = selFrame.ba - height*cible.oy
					saveAxes()
				end
			else -- normal mode
				firstSlide()
			end
		end
    end) ()

tele.frame.buttons[3].Action = (function()
    return
		function()
			if designMode then -- image horizontal button
				if allow_urls then-- cel:\\url function
					tele.frame.iconState[3] = 5-tele.frame.iconState[3]
				end
			else
				previousSlide()
			end
		end
    end) ()

tele.frame.buttons[4].Action = function(this)
	if designMode then --
		togglePalette()
	else
		nextSlide(true)
	end
end


tele.frame.buttons[5].Action = function()
	if designMode then
		toggleRuler()
	else

		fastAdvance()
	end
end


tele.frame.buttons[6].Action = function()
	if designMode then -- frames order
		if  showSel and showRef then showRef=false
			elseif showSel then showSel = false
			else showSel=true; showRef = true
		end
		reorderFrames(true)
	else
		toggleAuto()
	end
end

tele.frame.buttons[7].Action = function() -- change command set
	local initSelection = function()
		if lastImage + nbtxt == 1 then
			if lastImage == 1 then
				selFrame= diapoFrame[1]
			elseif nbtxt == 1 then
				selFrame=textFrame[1]
			end
		end
		if selFrame then saveAxes() end
	end

	local saveSlideFw = function()
		SaveSettings(); SaveSlideshow()
		activateObj(iObj+1)
		initSelection()
	end

	local saveSlideBw = function()
		SaveSettings(); SaveSlideshow()
		activateObj(iObj-1)
		initSelection()
	end

	setAuto(false)
	if not display_diapo then tele.frame.buttons[1].Action() end
	designMode = not designMode
	if designMode then
		keymap[key.forward]  = saveSlideFw
		keymap[key.backward] = saveSlideBw
		keymap[key.deviceVisibility] = (function()
			local order = false
			return function()
				reorderFrames(order)
				order = not order
			end
		end)()
		tele.frame.iconState = {3,3,urlState(),2, 2, 2,1}
		initSelection()
		togglePalette()
	else
		SaveSettings(); SaveSlideshow()
		resetTele()
	end
end

createPaletteFunctions()
palette.frame.close.Action = togglePalette


------- compatibility fix
local no_compass = not lua_compass_available
local freeze_compass = false
local compassInitState
-------
local toggleteleDisplay = function ()
	initTeleIcons()
	setAuto(false)
	tele.display = not tele.display;
	display_diapo = tele.display
	if tele.display then
		if no_compass and compassFrame then
			compassFrame.Visible=false
			compassFrameBox.Text = ""
			if compassCheck then
				if compassInitState == nil then
					compassInitState = compassCheck.Text
					compassCheck.Text = ""
				end
			end
		end
		messages=""
		tele.X = (width - tele.width)/2
		tele.Y = 2
		nbdia, nbtxt = 0, 0
		resetTele()
		replaceTool(tele)
		activateObj(iObj)
		if allow_urls then keymap[" "]=pause end
		addMessage(_("Slideshow ON: ")..slidesName)
		if nbObjects <1 then
			noSlide()
		end
	else
		if not designMode then
			if resumeAt == "next_slide" then
				iObj = iObj + 1
				if iObj > nbObjects then iObj = 1 end
			elseif type(resumeAt) == "number" then
				iObj = math.max(resumeAt,1)
				iObj = math.min(iObj,nbObjects)
			elseif resumeAt == "random" then
				iObj = nextRandom()
			end
		end
		resetTele()
		tele.frame.Visible = false
		palette.frame.Visible = false
		edit.frame.Visible = false
		keymap[key.deviceVisibility]=nil
		keymap[" "]=nil
		allowT = {}
		allowD = {}
		img=0
		for d=1,maxdia do diapoFrame[d].Visible = false end
		for t=1,maxtxt do textFrame[t].Visible  = false end
		if no_compass and compassFrame and not freeze_compass then
			if compassCheck then
				compassFrame:visible(enable_compass)
				compassCheck.Text = compassInitState
				compassInitState = nil
			else
				compassFrame:visible(true)
			end
		end
		celestia:print("  ".._"Slideshow OFF",3)
	end

end

if lua_edu_tools then
	slideshowCheck.Action = function()
		toggleteleDisplay()
		if tele.display then
			slideshowCheck.Text = "x"
		else
			slideshowCheck.Text = ""
		end
	end
end

-- edit functions
local backup = function()
	local slideCatBk = string.gsub(slideCatalog,"%.txt","%.bak")
	copyfile(slideCatalog,slideCatBk)
end

local copySlide = function()
	SaveSettings(); SaveSlideshow()
	lastSlide.slide = diaporama[iObj]
	lastSlide.maxdia = maxdia
	lastSlide.maxtxt = maxtxt
end

local rereadCatalog=function()
	freeze_compass = true
	toggleteleDisplay()
	setPathes(edit.frame.directory.Text)
	readParameters(true)
	diapoFrame={}
	textFrame ={}
	nbObjects, maxdia, maxtxt = readsCatalog(slideCatalog,diaporama)
	if nbObjects==0 then
		iObj=0
	else
		iObj = 1
	end
	for i=0, maxdia do diapoFrame[i] = createDiapoFrame(i) end
	for i=1, maxtxt do textFrame[i]  = createTextFrame(i)  end
	for i=0, maxdia do diapoFrame[i].Customdraw = diapoFrameCustomdraw end
	for i=1, maxtxt do textFrame[i].Customdraw =  textFrameCustomdraw  end
	createPaletteFrame()
	createPaletteFunctions()
	palette.frame.close.Action = togglePalette
	toggleteleDisplay()
	freeze_compass=false
	local fic=io.open(exePath.."lastslideshow.txt","w")
	if fic then
		fic:write(slidesName)
		fic:close()
	end
end

local backup = function()
	local slideCatBk = string.gsub(slideCatalog,"%.txt","%.bak")
	copyfile(slideCatalog,slideCatBk)
end

local restoreCatalog = function()
	local slideCatBk = string.gsub(slideCatalog,"%.txt","%.bak")
	local temp = string.gsub(slideCatalog,"%.txt","%.tmp")
	local bk = os.rename(slideCatBk,temp)
	if bk then
		os.rename(slideCatalog,slideCatBk)
		os.rename(temp, slideCatalog)
	end
	local posObj, nobj = iObj, nbObjects
	rereadCatalog()
	if nbObjects == nobj then
		activateObj(posObj)
	end
end



edit.frame.Customdraw=function(this)
	edit.X=this.la
	edit.Y=this.ba
	if not edit.oper then
		lastSlide.slide = nil
	end
end

edit.frame.directory.Action = function(this)
	this.oldText = this.Text
	this.Text = ""
end

edit.frame.directory.Customdraw = function(this)
	this.Textcolor = cslide
	if not this.Highlight then
		this.Text = string.gsub(this.Text, "^%s*(.-)%s*$","%1")
		if this.Text == "" then
			this.Text = slidesName
		end
		if this.Text == "<" then
			this.Text = slidesName
			restoreCatalog()
		elseif this.Text ~= slidesName then
			local exist = os.rename("extras/slideshow/"..this.Text, "extras/slideshow/"..this.Text)
			if this.oldText == this.Text then
				if not exist then
					os.execute('mkdir "extras/slideshow/'..this.Text..'"')
				end
				rereadCatalog()
			else
				if exist then
					rereadCatalog()
				else
					this.Textcolor = {1,0.3,0,1}
				end
			end
		end
	else
		celestia:getobserver():setspeed(0)
	end
end


edit.frame.Copy.Action = function(this)
	if edit.oper == "Cat." then return end
	if edit.oper == "Copy" then
		edit.oper = nil
	else
		if nbObjects>0 then
			copySlide()
			addMessage(_"Slide is copied")
			edit.oper="Copy"
		else
			edit.oper = nil
			noSlide()
		end
	end
end

edit.frame.Copy.Customdraw = function(this)
	if edit.oper == "Copy" then
		this.Fillcolor = edit.operColor
	else
		this.Fillcolor = nil
	end
end

edit.frame.Cut.Action = function(this)
	if edit.oper == "Cat." then return end
	if edit.oper == "Cut" then
		edit.oper = nil
	else
		if nbObjects>0 then
			copySlide()
			table.remove(diaporama,iObj)
			nbObjects=nbObjects-1
			iObj=iObj-1
			if iObj <1 and nbObjects>0 then iObj=1 end
			SaveSlideshow()
			activateObj(iObj)
			edit.oper = "Cut"
		else
			edit.oper = nil
			noSlide()
		end
	end
end

edit.frame.Cut.Customdraw = function(this)
	if edit.oper == "Cut" then
		this.Fillcolor = edit.operColor
	else
		this.Fillcolor = nil
	end
end

edit.frame.Paste.Action = function(this)
	if edit.oper == "Cat." then return end
	if lastSlide.slide then
		SaveSettings();SaveSlideshow()
		local copiedSlide = {}
		if edit.oper == "Copy" then
			copyTab(lastSlide.slide, copiedSlide)
			table.insert(diaporama,iObj+1,copiedSlide)
		else -- oper == "Cut"
			table.insert(diaporama,iObj+1,lastSlide.slide)
		end
		nbObjects=nbObjects+1
		iObj=iObj+1
		SaveSlideshow()
		activateObj(iObj)
	else
		addMessage(_("No slide to paste"))
	end
	if edit.oper then edit.frame[edit.oper].Fillcolor = nil end
	edit.oper=nil
end

edit.frame.Paste.Customdraw = function(this)
	if edit.oper == "Copy" or edit.oper == "Cut" then
		this.Fillcolor = edit.todoColor
	else
		this.Fillcolor = nil
	end
end

edit.frame.New.Action = function(this)
	if edit.oper == "Cat." then return end
	if edit.oper == "New" then
		edit.oper = nil
	else
		lastSlide = {["maxdia"]=maxdia,["maxtxt"]=maxtxt}
		local fic = io.open(exePath.."slide_description.txt", "w")
		if fic then
			fic:close()
			slideEditCommand = string.gsub(slide_edit_command,"TEXTFILE",
				exePath.."slide_description.txt")
			os.execute(slideEditCommand)
			edit.oper="New"
		else
			addMessage(_"Fail to create ".."slide_description.txt")
		end
	end
end

edit.frame.New.Customdraw = function(this)
	if edit.oper == "New" then
		this.Fillcolor = edit.operColor
	else
		this.Fillcolor = nil
	end
end


edit.frame.Edit.Action = function(this)
	if edit.oper == "Cat." then return end
	if edit.oper == "Edit" then
		edit.oper = nil
	else
		lastSlide = {["maxdia"]=maxdia,["maxtxt"]=maxtxt}
		if nbObjects>0 then
			backup()
			SaveSettings()
			saveCurrentSlide()
			slideEditCommand = string.gsub(slide_edit_command,"TEXTFILE",
				exePath.."slide_description.txt")
			os.execute(slideEditCommand)
			edit.oper="Edit"
		else
			noSlide()
		end
	end
end

edit.frame.Edit.Customdraw = function(this)
	if edit.oper == "Edit" then
		this.Fillcolor = edit.operColor
	else
		this.Fillcolor = nil
	end
end

edit.frame["Cat."].Action = function(this)
	if edit.oper == "Cat." then
		edit.oper = nil
		return
	else
		lastSlide = {["maxdia"]=maxdia,["maxtxt"]=maxtxt}
		backup()
		SaveSlideshow()
		if nbObjects <1 then
			if running_OS == "Windows" then
				slideshowCommand = 'extras\\slideshow\\zutils\\createCatalog.bat "' .. slidesName .. '"'
				os.execute(slideshowCommand)
			--else
				--to be completed
			end
		end
		slideEditCommand = string.gsub(slide_edit_command,"TEXTFILE",slideCatalog)
		os.execute(slideEditCommand)
		edit.oper="Cat."
	end
end

edit.frame["Cat."].Customdraw = function(this)
	if edit.oper == "Cat." then
		this.Fillcolor = edit.operColor
	else
		this.Fillcolor = nil
	end
end

edit.frame.OK.Action = function(this)

	local errorSlideDescription = function(nbo)
		addMessage(_"Error in slide description")
		if nbo == 0
			then addMessage(_"(No slide defined)")
			else addMessage(_"(More than one slide)")
		end
	end

	local readOneSlide = function()
		local nbo , maxd, maxt = readsCatalog(exePath.."slide_description.txt", tempSlide, true)
		if nbo == 1 then
			if maxd > maxdia then
				for i=maxdia+1, maxd do
					diapoFrame[i] = createDiapoFrame(i)
					diapoFrame[i].Customdraw = diapoFrameCustomdraw
				end
				maxdia = maxd
			end
			if maxt > maxtxt then
				for i=maxtxt+1, maxt do
					textFrame[i] = createTextFrame(i)
					textFrame[i].Customdraw = textFrameCustomdraw
				end
				maxtxt = maxt
			end
		end
		return nbo
	end

	if edit.oper == "Copy" or edit.oper == "Cut" then return end

	if edit.oper == "Edit" then
		SaveSettings();SaveSlideshow()
		local nbo = readOneSlide()
		if nbo == 1 then
			tempSlide[1].url = diaporama[iObj].url
			tempSlide[1].delay = diaporama[iObj].delay
			for i,v in pairs(diaporama[iObj].IMG) do
				for it,vt in pairs(tempSlide[1].IMG) do
					if v.file == vt.file and not vt.done then
						for x,p in pairs(v) do
							vt[x] = p
						end
						vt.done = true
						break
					end
				end
			end
			for i,v in pairs(diaporama[iObj].TXT) do
				for it,vt in pairs(tempSlide[1].TXT) do
					if table.concat(v.text) == table.concat(vt.text) and not vt.done then
						for x,p in pairs(v) do
							vt[x] = p
						end
						vt.done = true
						break
					end
				end
			end
			diaporama[iObj] = tempSlide[1]
			SaveSlideshow()
			activateObj(iObj)
		else
			errorSlideDescription(nbo)
		end

	elseif edit.oper=="New" then
		local nbo = readOneSlide()
		if nbo == 1 then
			lastSlide.slide = tempSlide[1]
			edit.frame.Paste.Action()
		else
			errorSlideDescription(nbo)
		end
	else -- Cat. or no action
		local action = edit.oper
		if action == "New" or action == "Edit" or action == "Cat." then
			local posObj, nobj = iObj, nbObjects
			rereadCatalog()
			if nbObjects == nobj then
				activateObj(posObj)
			end
		end
	end
	edit.oper=nil
	reorderFrames(true)
end

edit.frame.OK.Customdraw = function(this)
	if edit.oper == "New" or edit.oper == "Edit" or edit.oper == "Cat." then
		this.Fillcolor = edit.todoColor
	else
		this.Fillcolor = nil
	end
end

----------------------------------------------

if lua_edu_tools then
	keymap[key.slideshowShortcut] = slideshowCheck.Action
else
	keymap[key.slideshowShortcut] = toggleteleDisplay
end

celestia:log("-- diaporama v2 --")
