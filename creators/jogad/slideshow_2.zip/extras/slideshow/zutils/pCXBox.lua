-- pCXBox.lua

require "CXClass"
require "CXBox"
----------------------------------------------------------------
local orient = {
	{0,1,1,1,1,0,0,0},
	{0,0,0,1,1,1,1,0},
	{1,0,0,0,0,1,1,1},
	{1,1,1,0,0,0,0,1},
	{1,1,0,1,0,0,1,0},
	{1,0,1,1,0,1,0,0},
	{0,0,1,0,1,1,0,1},
	{0,1,0,0,1,0,1,1},
}

pCXBox =
    Class {
    classname = "pCXBox";
    superclass = CXBox;
    init =
        function(this,x,y,w,h)
            this.Parent = nil;
            this.la = x;
            this.ba = y;
            this.ra = w;
            this.ta = h;
            this:updatebounds();
            this.Visible = true;
            this.Movable = true;
            this.Editable = false;
            return this;
        end;

----------------------------------------------------------------
-- attachment methods

attach =
    function(this,parent,la,ba,ra,ta)
        if this.Parent ~= parent then
            if this.Parent then
                for i,v in pairs(this.Parent.attatchments) do
                    if v == this then
                        table.remove(this.Parent.attatchments,i);
                        break;
                    end;
                end;
            end;
            if parent then
                if not parent.attachments then
                    parent.attachments = {};
                end;
                table.insert(parent.attachments,this);
            end;
        end;
        this.Parent,this.la,this.ba,this.ra,this.ta = parent,la,ba,ra,ta;
        --[[ this:updatebounds(); ]]
        return this;
    end;

detach =
    function(this)
        if this.parent then
            table.remove(parent.attatchments);
            this.parent = nil;
        end
        --[[ TODO: adjust attachment values to screen? ]]
    end;

----------------------------------------------------------------
-- drawing methods

drawtexture =
    function(this, r, g, b, T, OR)
        gl.Enable(gl.TEXTURE_2D);
        gl.Begin(gl.QUADS);
        gl.Color(r, g, b, T);
        gl.TexCoord(orient[OR][1],orient[OR][2]);
        gl.Vertex(this.lb, this.bb);
        gl.TexCoord(orient[OR][3],orient[OR][4]);
        gl.Vertex(this.rb, this.bb);
        gl.TexCoord(orient[OR][5],orient[OR][6]);
        gl.Vertex(this.rb, this.tb);
        gl.TexCoord(orient[OR][7],orient[OR][8]);
        gl.Vertex(this.lb, this.tb);
        gl.End();
        gl.Disable(gl.TEXTURE_2D);
    end;

drawrect =
    function(this)
        gl.Begin(gl.LINE_LOOP);
        gl.Vertex(this.rb, this.bb);
        gl.Vertex(this.rb, this.tb);
        gl.Vertex(this.lb, this.tb);
        gl.Vertex(this.lb,this.bb);
        gl.End();
    end;

drawmaskedrect =
    function(this, box)
        gl.Begin(gl.LINE_LOOP);
        gl.Vertex(box.rb, this.bb);
        gl.Vertex(this.rb, this.bb);
        gl.Vertex(this.rb, this.tb);
        gl.Vertex(box.rb, this.tb);
        gl.End();
        gl.Begin(gl.LINE_LOOP);
        gl.Vertex(box.lb, this.tb);
        gl.Vertex(this.lb,this.tb);
        gl.Vertex(this.lb, this.bb);
        gl.Vertex(box.lb, this.bb);
        gl.End();
    end;

draw =
    function(this)
        if this.Fillcolor or this.Editable then
			local fco= this.Fillcolor
			if this.Editable and this.Highlight then
				fco = {0,0,0,0.5}
			end
			if fco then
				gl.Color(unpack(fco));
				gl.Disable(gl.TEXTURE_2D);
				gl.Begin(gl.POLYGON);
				this:drawrect();
			end
        end
        if this.Fillimage then
            this.Fillimage:bind();
			if this.isImage and this.OR then
				this:drawtexture(this.r, this.g, this.b, this.Transp, this.OR)
			else
				this:drawtexture(1,1,1,1,1)
			end
        end
        if this.Bordercolor then
            local bco = this.Bordercolor;
            gl.Color(unpack(bco));
            gl.Disable(gl.TEXTURE_2D);
            if this.Masked then
                this:drawmaskedrect(this.Masked);
            else
                this:drawrect();
            end
        end;
        if this.Text and this.Textfont then
			local msg ={}
			if this.Text[1] then
				msg = { unpack(this.Text) }
			else
				msg = { this.Text }
			end
			local h=this.Textfont:getheight()
			for i=1, table.getn(msg) do
				gl.MatrixMode(gl.MODELVIEW);
				gl.PushMatrix();
				gl.LoadIdentity();
				gl.Enable(gl.TEXTURE_2D);
				gl.Enable(gl.BLEND);
				gl.BlendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
				if not(this.dx) then this.dx = 0 end;
				if not(this.dy) then this.dy = 0 end;
				if this.Textcolor then
					local tco = this.Textcolor;
					gl.Color(unpack(tco));
				else
					local tco = this.Bordercolor;
					gl.Color(unpack(tco));
				end
				if this.Textpos == "center" then
					local textwidth = this.Textfont:getwidth(msg[i]);
					local boxwidth, boxheight = this:size();
					this.dx = math.floor((boxwidth - textwidth) / 2) - 5;
				end
				local xpos = math.floor(this.lb + 5 + this.dx);
				local ypos = math.floor(this.tb - 18 + this.dy)-(i-1)*h;
				gl.Translate(xpos + 0.125, ypos + 0.125);
				this.Textfont:bind();
				this.Textfont:render(msg[i]);
				gl.PopMatrix();
				gl.Disable(gl.TEXTURE_2D);
			end
        end;
        if this.Fittotext and this.Textfont and this.Text and this.Parent and this.ba and this.ta then
            local textwidth = this.Textfont:getwidth(this.Text);
            local parent = this.Parent;
            local parentwidth, parentheight = parent:size();
            local xoffset = this.Fittotext;
            local lbb, rbb = (parentwidth-10-textwidth)/2+xoffset, (parentwidth-10-textwidth)/2-xoffset;
            this:attach(parent, lbb, this.ba, rbb, this.ta);
        end;
    end;

drawall =
    function(this)
        if not(this.Visible) then
            return;
        end
        -- We start drawing the box on the second tick in order to
        -- hide a possible uggly resizing of the box during the first tick.
        if this.FirstTickDone then
            this:draw();
        else
            this.FirstTickDone = true;
        end
        if this.Customdraw then
            this:Customdraw();
        end
        if this.attachments then
            for i,v in ipairs(this.attachments) do
                v:drawall();
            end;
        end;
    end;
-----------------------------------------------------------------
-- field editing methods

beginedit =
    function(this)
        eventeater = this;
        this.Highlight = true;
    end;

quitedit =
    function(this)
        this.Highlight = nil;
        eventeater = nil;
        return true;
    end;

endedit =
    function(this)
        this.Highlight = nil;
        eventeater = nil;
        if this.NextField then
            this.NextField:beginedit();
        end;
        return true;
    end;

-----------------------------------------------------------------
-- event processing methods

findcontainer =
    function(this,x,y)
        if not this.Visible then return nil end;
        local r;
        if this.attachments then
            for i = table.getn(this.attachments),1,-1 do
                v = this.attachments[i];
                r = v:findcontainer(x,y);
                if r then
                    return r;
                end;
            end;
        end;
        if this:contains(x or -1,y or -1) then
            return this;
        else
            return nil;
        end;
    end;

charentered =
    function(this,ch)
		if not this.Text then return end
        if  ch == "C-m"  then  -- return
            return this:endedit();
        elseif ch == "C-h" then  -- backspace
            len = string.len(this.Text)-1;
            if len < 0 then return true end;
            this.Text = string.sub(this.Text,1,len);
			return true;
        elseif ch == "C-i" then  -- Tab
            return this:endedit();
        else
            this.Text = this.Text..ch;
            return true;
        end;
        return true;
    end;


mousebuttondown =
    function(this,x,y,b)
        if this:contains(x,y) then
            if not(this.Clickable) then
                eventeater = this;
            end
            if this.Toplevel then
                return;
            end;
            if this.Active then
                this:Action();
                this:orderfront();
                this.Highlight = true;
            end;
            if this.Movable then
                this:orderfront();
                this.Move = true;
            end;
            return true;
        else
            this:quitedit();
            return false;
        end;
    end;

mousebuttonmove =
    function(this,dx,dy)
        if eventeater ~= this then return false end;
        if this.Movable then
            this:moveby(dx,dy);
            return true;
        end;
        if this.Active then
            return true;
        end;
        return false;
    end;

mousebuttonup =
    function(this,x,y,b)
        if eventeater ~= this then return false end;
        eventeater = nil;
        this.Highlight = nil;
        this.Move = false;
        if this:contains(x,y) then
            if this.Editable then
                this.Highlight = true;
                eventeater = this;
                return true;
            end;
        end;
        return true;
    end;

-----------------------------------------------------------------

print =
    function(this)
        print(
            "Box { ",
                this.la," , ",
                this.ba," , ",
                this.ra," , ",
                this.ta,
            " }" );
        end;
    }

pCXBox.__tostring =
    function(this)
        return "Box { "..
            (this:text() or "?").." "..
            this.la.." , "..
            this.ba.." , "..
            this.ra.." , "..
            this.ta..
        " }";
    end;

