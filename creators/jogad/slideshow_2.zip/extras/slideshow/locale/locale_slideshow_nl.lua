-- Nederlandse vertaling voor slideshow v2.0
-- Vertaald door Marco Klunder

slideshow_loc_str =
{
	Slideshow = "Diavoorstelling";
	["slide #"] = "Dianummer ";
	["Missing image: "] = "Ontbrekende afbeelding: ";
	["NO SLIDE IN SLIDESHOW"] = "GEEN DIA IN DIAVOORSTELLING";
	["This is the last slide..."] = "Dit is de laatste dia ...";
	["Slideshow catalog not open"] = "De catalogus van de diavoorstelling is niet geopend";
	["Text"] = "Tekst";
	["Background"] = "Achtergrond";
	["Image"] = "Afbeelding";
	["Auto feed ON"] = "Automatisch dia's doorlopen AAN";
	["Auto feed OFF"] = "Automatisch dia's doorlopen UIT";
	["default"] = "standaard";
	["Slide duration = "] = "Weergavetijd van de dia = ";
	["Default slides duration = "] = "Standaard weergavetijd van de dia's = ";
	["Slideshow ON: "] = "Diavoorstelling AAN: ";
	["Slideshow OFF"] = "Diavoorstelling UIT";
	["Stealth mode"] = "Verbergen";
	["Stealth mode OFF"] = "Verbergen UIT";
	["Stealth mode ON"]  = "Verbergen AAN";
	["Celestia is paused"] = "Celestia is gepauzeerd";
	["Delay = "] = "Vertraging = ";
	["Command tool hidden"] = "Opdracht menu verborgen";
	["press "] = "Druk op de ";
	[" to recover"] = " toets om te herstellen";
	["Time is paused"] = "Tijd is gepauzeerd";
	["Resume"] = "Doorgaan";
	["Border"] = "Rand";
	["No slide to paste"] = "Geen dia die kan worden geplakt";
	["Slideshow catalog"] = "Catalogus van diavoorstellingen";
	["New"] = "Nieuw";
	["Copy"] = "Kopieer";
	["Cut"] = "Knippen";
	["Paste"] = "Plakken";
	["Edit"] = "Bewerken";
	["Cat."] = "Cat.";
	["OK"] = "OK";
	["Error in slide description"] = "Fout in de dia beschrijving";
	["(No slide defined)"] = "(Er is geen dia gedefinieerd)";
	["(More than one slide)"] = "(Definitie van meer dan één dia)";
	["Slide is copied"] = "De dia is gekopieerd";
	["Fail to create "] = "Mislukte aanmaak van ";
}
