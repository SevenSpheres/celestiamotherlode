-- French translation of slideshow
-- Traduction française pour Diaporama

slideshow_loc_str =
{
	Slideshow = "Diaporama";
	["slide #"] = "diapo N°";
	["Missing image: "] = "image absente : ";
	["NO SLIDE IN SLIDESHOW"] = "LE DIAPORAMA EST VIDE !";
	["This is the last slide..."] = "C'est la dernière diapo...";
	["Slideshow catalog not open"] = "Erreur à l'ouverture du catalogue de diapos";
	["Image"] = "Image";
	["Text"] = "Texte";
	["Background"] = "Arrière-plan";
	["Border"] = "Bordure";
	["Auto feed ON"] = "Avance automatique activée";
	["Auto feed OFF"] = "Avance automatique désactivée";
	["default"] = "par défaut";
	["Slide duration = "] = "Durée de la diapo = ";
	["Default slides duration = "] = "Durée par défaut des diapos = ";
	["Slideshow ON: "] = "Diaporama actif : ";
	["Slideshow OFF"] = "Diaporama désactivé";
	["Stealth mode"] = "Mode furtif";
	["Stealth mode OFF"] = "Mode furtif désactivé";
	["Stealth mode ON"]  = "Mode furtif activé";
	["Celestia is paused"] = "Celestia est en pause";
	["Delay = "] = "Durée = ";
	["Command tool hidden"] = "La télécommande est cachée.";
	["press "] = "Appuyez sur ";
	[" to recover"] = " pour la retrouver";
	["Time is paused"] = "Temps en pause";
	["Resume"] = "Reprendre";
	["No slide to paste"] = "Il n'y a rien à recopier";
	["Slideshow catalog"] = "Description du diaporama";
	["New"] = "Nouv.";
	["Copy"] = "Copier";
	["Cut"] = "Couper";
	["Paste"] = "Coller";
	["Edit"] = "Modif.";
	["Cat."] = "Cat.";
	["OK"] = "OK";
	["Error in slide description"] = "Erreur dans la description de la diapo";
	["(No slide defined)"] = "(aucune diapo définie)";
	["(More than one slide)"] = "(Définition de plus d'une diapo)";
	["Slide is copied"] = "La diapo est copiée";
	["Fail to create "] = "Echec à la création de ";
}

