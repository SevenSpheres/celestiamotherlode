====================================
Virtual textures: The French Riviera
====================================

Detailed view of the French Riviera

The French Riviera or Cote d'Azur in French with its pleasant climate and its luxury attracts celebrities from around the world.
Cities are represented very accurately from Th�oule-sur-Mer to Menton on the Italian border. Among them Cannes with its well known film festival, Antibes Juan-les-Pins, Nice and the Principality of Monaco.
The coast is represented with an accuracy of about 5m/px with places like Cannes or Monaco, where it reached 2.5 m/px

The file "locs-cote-d-azur.ssc" allows the French Riviera's localities to be displayed with Celestia.

This addon completes and updates France textures for the region of the French Riviera. 
If you use the virtural textures of France, replace the files at levels 6 and 7 with those of the archive. You'll have a better accuracy for the this region. 

The textures of the virtual surface come with the format of 64K Jestr Earth Mark II maps (JMII). They are DXT3 *.DDS images with an alpha layer. The images size is 1024 x 1024 pixels.



Installation 
============ 

The installation assumes that the textures 64K Jestrai Earth Mark II (Level 0 to Level 5) are already installed.

It is also recommended (yet not mandatory) to have the textures of France installed.

- Unpack the archive with the files in the directory 
   Celestia/extras
   respecting the tree of directories.

- If you already use textures for France, the computer will ask you to replace files in the directories level6 and Level7. This is an update for the textures of France. Answer yes if the file is more recent. 

- If you do not have the textures for France, and that you intend to install, install them first and then install the textures of this add-on. 

If you use another Virtual Earth Texture, adapt the installation accordingly. Only the level 0 is really required, but the file format must be DDS and it is preferable that the image tile size is 1024 x 1024 pixel with a statement:
    BaseSplit 0 
    TileSize 512 
    TileType "dds" 
in the *.ctx file.

Usage
=====
If you followed the recommendation to use these textures to complement the textures Jestr Earth Mark II, they will be defined in Celestia as alternatives surfaces. 
This means that in order to activate them you must right click on the Earth and choose "DDS JMII" in the list of alternative surfaces. 
To disable, simply click again on 'normal' in that list. 

Place names can be displayed in Celestia by activating the city names in Celestia.

Keep in mind that these textures are large and use a lot of resources. It is therefore preferable to activate them only when necessary. 

Personally, I don't use the normal maps textures that come with JMII textures. On my machine it leads only to a slowdown without providing a real visual improvement. 

These textures are designed to be watched during the day with a well-lit scene. For a better view in Celestia, visit la C�te d'Azur during the summer days. 


Sources 
------- 
The maps are made from screenshots of various images freely available on the Internet. 
The original images can be viewed easily with Google Earth and come primarily from 
NASA, SIO, NOAA, U.S. Navy, NGA, GEBCO 
Digital Globe 
CNES SpotImage 
GeoContent 
Aerodata International Surveys 
Infoterra & Bluesky 
The screenshots were made with Google Earth(TM)

Other sources may be helpful: 
http://www.multimap.com/map 

LICENSE
I made these textures for my personal use and they are provided only as an example, for information or for personal use. Any commercial use is prohibited. 


jogad
