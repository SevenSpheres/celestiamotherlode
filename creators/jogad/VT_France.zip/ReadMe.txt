TEXTURES FOR FRANCE 

The level of details of these texture is  6 and 7. They cover the whole of France (except overseas) with a resolution of approximately 150 meters per pixel. 
They can serve as a basis for future regional more detailed textures. 

The general tone is clearer than the map of Jest. I think it's nicer for a closer view. This should not be awkward because the texture appears only when when it is close enough. If you want that the texture appears even closer, delete the files in the level6 directory and keep only those of the Level7 Directory.

Installation 
------------ 
- It is necessary to have first installed a complete set of Earth Virtual Textures (level 0 to 5). 
I recommend the textures 64K Jestr Earth Mark II. These textures were the basis for my textures of France. In particular with regard to the color of the sea .

- Unpack the textFrance.zip file in the directory:
   Celestia / extras / JMII DDS / textures / hires / JMMI DDS 
   respecting the tree. 

Sources 
------- 
The maps are made from screenshots of various images freely available on the Internet. 
The original images can be viewed easily with Google Earth and come primarily from 
NASA, SIO, NOAA, U.S. Navy, NGA, GEBCO 
Digital Globe 
CNES SpotImage 
GeoContent 
Aerodata International Surveys 
Infoterra & Bluesky 

Other sources may be helpful: 
http://www.multimap.com/map 

LICENSE
I do not know much about licenses. 
I made these textures for my personal use and they are provided only as an example, for information or for personal use. Any commercial use is prohibited. 


jogad
