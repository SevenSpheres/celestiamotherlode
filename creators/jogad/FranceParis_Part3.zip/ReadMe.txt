================================== 
 TEXTURES FOR THE REGION OF PARIS 
==================================

This document is an almost original translation by translate.google of the French file lisez-moi.txt. This may explain some obscure points (but not all) of this translation. 

This is a set of textures covering Paris and the Paris region with a level of detail that can reach 10 meters per pixel or even up to 2.5 meters per pixel in some places. 

It is not absolutely mandatory, but it is highly recommended to use these textures with my textures for France to have a continuous transition from one level of detail to the next. 

The textures of the virtual surface come with the format of 64K Jestr Earth Mark II maps (JMII). They are DXT3 *.DDS images with an alpha layer that was used to shine lakes and rivers (the Seine) in the sun. The images size is 1024 x 1024px up to levels Level11 and 2048 x 2048 for level level12. 

The file is large and was divided into four parts: 

- Part #1 
---------- 
Paris and the Paris region with a level of detail of 10 meters per pixel. 
This section provides the basis for Parts #2, #3 and #4. 
Unlike the more detailed sections, it can be used alone if your computer is not powerful enough to display the large files of the most accurate maps. 


Very detailed parts 
===================
* Parts #2, #3 and #4 provide a higher level of detail for certain locations. You can even see cars, boats or aircraft. 
It is essential to use them with the part #1. 

There is not a 13th level of detail in Celestia (superstition?). Therefore, at this level, image tiles are 2048 x 2048 instead of 1024x1024 (four times bigger than those of other levels of the VT). This was necessary to achieve the precision I wanted. 

If you want, you can resize to 1024 x 1024. You lose a level of detail (5 m/px instead of 2.5), but you gain in fluidity. 

- Part #2 
------------ 
Detailed view of much of Paris. 
At that point (up to 2.5 m / pixel), we can see boats on the Seine illuminated by the Sun while the Eiffel Tower casts its shadow on the river. 
If you move to the 'Stade de France' (not in Paris but in Saint-Denis) you will see the cars on the roads around it. 

- Part #3 
---------- 
Detailed view of the gardens of Versailles and of Orly airport. 
Take a look at the plane that brought you to Paris and go to fly over the magnificent gardens of the 'Ch�teau de Versailles' a little further west. 


- Part #4 
---------- 
Detailed View of Charles de Gaulle Airport in Roissy en France. 
The largest airport of Paris. 
Enjoy the complexity of the airport and do not miss the three aircraft aligned on the runway 09R. 


Installation 
============ 
- As for the textures of France, the installation requires that the texture 64K Jestr Earth Mark II (Level 0 to Level 5) are first installed. 
In all cases, a complete set of virtual textures of the Earth must exist on your machine. 

- Unpack the archive you downloaded in the directory 
   Celestia/extras/JMII DDS/textures/hires/DDS JMII
   respecting the tree of directories.
- He computer may ask you if you want to replace a file in the directory Level7 and another in the directory Level8. These are updated textures for France. Answer yes. 

If you use another Virtual Earth Texture, adapt the installation accordingly. Only the level 0 is really required, but the file format must be DDS and it is preferable that the image tile size is 1024 x 1024 pixel with a statement:
    BaseSplit 0 
    TileSize 512 
    TileType "dds" 
in the *.ctx file.

Usage
=====
If you followed the recommendation to use these textures to complement the textures Jestr Earth Mark II, they will be defined in Celestia as alternatives surfaces. 
This means that in order to activate them you must right click on the Earth and choose "DDS JMII" in the list of alternative surfaces. 
To disable, simply click again on 'normal' in that list. 

Keep in mind that these textures are large and use a lot of resources. It is therefore preferable to activate them only when necessary. 

Before loading parts #2, #3 and #4, first try with only part #1 to make sure it works well. 
With a good graphics card and enough memory everything should work smoothly once the textures are loaded into memory. 

Personally, I don't use the normal maps textures that come with JMII textures. On my machine it leads only to a slowdown without providing a real visual improvement. 

At the latitude of Paris, Celestia shows the night textures in winter even with the sun above the horizon. These textures are designed to be viewed in daylight. For a better view in Celestia visit Paris during the summer days. 


Sources 
------- 
The maps are made from screenshots of various images freely available on the Internet. 
The original images can be viewed easily with Google Earth and come primarily from 
NASA, SIO, NOAA, U.S. Navy, NGA, GEBCO 
Digital Globe 
CNES SpotImage 
GeoContent 
Aerodata International Surveys 
Infoterra & Bluesky 

Other sources may be helpful: 
http://www.multimap.com/map 

LICENSE
I do not know much about licenses. 
I made these textures for my personal use and they are provided only as an example, for information or for personal use. Any commercial use is prohibited. 


jogad
