Capitais do Mundo em Portugu�s v.2

O que h� de novo:
- Descobri como colocar acentos nos nomes do Celestia; escrever as palavras com acento nos arquivos gera erro nos nomes, ent�o eu fu�ei e descobri essa tabela:

�  \u00e1	�  \u00c1
�  \u00e9	�  \u00c9
�  ------	�  ------
�  \u00f3	�  \u00d3
�  ------	�  ------
		
�  \u00e2	�  \u00c2
�  ------	�  ------
�  \u00f4	�  \u00d4

�  \u00e3	�  \u00c3
�  \u00f5	�  \u00d5
		
�  \u00e7	�  ------

E para botar nos nomes � simples; para escrever [�rion], � soh substituir pelo c�digo, assim: [\u00d3rion]

Alguns eu n�o consegui, e a falta do � me doeu quando eu escrevi Bras�lia... Se algu�m descobrir como fazer, por favor me avise. =]

Para ativar, coloque o arquivo anexo world-capital.ssc na pasta DATA do Celestia. Sugiro tamb�m que voc� salve o antigo em outra pasta. Precau��o nunca � demais. (sei l� neh?)

PS: Tamb�m revisei os nomes e refiz alguns, cujas tradu��es estavam meio confusas. Agora t� beleza.



Constela��es em Portugu�s

Eu descobri a hist�ria dos c�digos pros acentos observando uma constela��o; Bo�tes, O Pastor. Olha o � com trema nele. Quando eu vi, eu pensei: 'E porque eu nao posso botar acentos nas outras coisas?'
Fu�ei, mexi, e deu no que deu: Traduzi as constela��es tamb�m.
Mas eu deixei o nome original naquelas desconhecidas, para aqueles que v�o procurar informa��es em outros lugares. As mais comuns, como as do zod�aco, est�o no comum em portugu�s.

Para ativar, coloque o arquivo anexo asterisms.dat na pasta DATA do Celestia. De novo, sugiro salvar o antigo em outra pasta.



World Capitals in Portuguese v.2

The names have been checked and re-written, to accept the portuguese simbols such as [�] and [�]. Celestia does not recognize them if you simply write them on the files; it creates an error. Then I came up with the chart you can see above, where special letters have codes. To write [�rion], for instance, one must only write the code in the right place, no spaces needed: [\u00d3rion]

To replace, just paste the anexed file world-capitals.ssc to the DATA folder in your Celestia folder. I suggest copying the old file into another folder, only for precaution. =]

Constelation in Portuguese

Using the same codes, I translated the constelation names, leaving both the original, latin name, and the portuguese translation. It is not a surprise that portuguese names hold great similarity to the ancient latin words.

To replace, just paste the anexed file asterisms.dat to the DATA folder in your Celestia folder. I suggest copying the old file into another folder, only for precaution. =]



Traduzido por
Translated by

Tanketai

tanketai@hotmail.com

Sem direitos reservados / Fa�a o que bem entender =]
No copyright / Do as you please =]