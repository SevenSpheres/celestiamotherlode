---------------------------
51 Pegasi/b
---------------------------

A new kind of texture for 51Pegasi/b. It's the first discovered exoplanet orbiting a sun-like star. Discovered by M. Mayor and D. Queloz (Observatoire de Gen�ve). 

-----------------------------------------------------

More details:
Evaporation: http://exoplanet.eu/papers/queues6.JPG

The Geneva Extrasolar Planet Search Programmes: http://obswww.unige.ch/~udry/planet/planet.html

http://wapedia.mobi/en/51_Pegasi_b

http://www.obs-hp.fr/www/nouvelles/51-peg.html

-----------------------------------------------------

---------------------------
HOW TO INSTALL
---------------------------

Unzip this WinZip file into your celestia/extras directory. Start Celestia. Then "Enter", type "51 Pegasi/b", "Enter", "G"...

Enjoy!

-----------------------------------------------------

=> There are three different opengl2 renderings available in the "51pegasi.ssc" file. (Please see picture "density.jpg"). With more or less "atmospheric" density.
It's a question of taste which values you like to choose...

=> If you own an older computer it's better to leave the second cloud layer. Type "#" before this line in the "51pegasi.ssc" file: "" "HD 217014" (it's easy to find if you open the "51pegasi.ssc" file with a text editor.)

-----------------------------------------------------

Credits:

thanks to John Van Vliet; without his help, expertise and tutorials (and patience) I couldn't realize this project.
Hungry4info, thanks for the information about the "wind-speeds". (http://www.eso.org/public/news/eso1026/)
thanks Massimo (Fenerit). He notified me about the colour of 51 Pegasi/b. (http://www.planetary.org/exoplanets/list.php?exo=51+Pegasi+b)

-----------------------------------------------------

Only free to use for non-commercial purpose

� MiR

-----------------------------------------------------




