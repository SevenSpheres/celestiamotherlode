-------------------------
Mars Dust Storm
-------------------------
A very simple add-on. For collectors only.
But i hope you like it. :-)

-----------------------------------------------------------------------------------------------------------------------------------------------------

This small addon shows a cosmic event in 2001 happened on Mars. A global dust storm. For further informations please read:

InfoUrl: http://science.nasa.gov/headlines/y2001/ast11oct_2.htm
InfoUrl: http://mars.jpl.nasa.gov/gallery/duststorms/20020508a_b.html
InfoUrl: http://www.msss.com/mars_images/moc/10_11_01_dust_storm/index.html
InfoUrl: http://mars.jpl.nasa.gov/gallery/duststorms/index.html

-----------------------------------------------------------------------------------------------------------------------------------------------------

Copyright information

The base map of Mars is from this site:
http://sos.noaa.gov/datasets/copyright.html

---------------------------
HOW TO INSTALL
---------------------------

Unzip this WinZip file into your celestia/extras directory.

---------------------------
Only free for non-commercial use
------------------------------------------------
Regards
MiR














