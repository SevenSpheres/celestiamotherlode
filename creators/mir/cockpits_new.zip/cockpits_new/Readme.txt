

-----------------------------
APOLLO COCKPIT
-----------------------------


This package contains some overlay textures from the Apollo missions.

-cockpitBox.lua [(c)  by Vincent Giangiulio]
-cockpit_apollo11.png
-cockpit_Apollo11_wide.png
-cockpit_luke.png
-cockpit_luna_lander.png
-cockpit_luna_lander_wide.png
-config_lua.jpg
-toolbox_lua.jpg
-cockpits.jpg
-this file

---------------------------
HOW TO INSTALL
---------------------------

-First you have to install the LUA EDU TOOLS [(c) by Vincent Giangiulio  and Hank Ramsey]
-Rename the file "cockpit.png" in the folder "Celestia\extras\lua_edu_tools\images" [e.g. cockpit_origin.png]
-Unzip and paste  the file "cockpits_new.zip" into a folder of your choice and put the "*.png" files inside the folder "images" of the "lua_edu_tools".
-Rename one of them to "cockpit.png"
-Start Celestia and choose "Cockpit" in the lua-tools area

-enjoy-

----------------------------------------------------------------------------------------
IMPORTANT: 
if you could not find a file "cockpit.png" in your folder "...\lua_edu_tools\images" and/or a "Cockpit" selection box isn't available in your Lua-Edu-Tools
----------------------------------------------------------------------------------------

-put the file "cockpitBox.lua" into "...\lua_edu_tools\tools"
-open the file "config.lua" within the folder "...\lua_edu_tools" and add the lines as described in picture "config_lua.jpg"
-open the file "toolBox.lua" inside the folder "...\lua_edu_tools\utils" and add the line as described in picture "toolBox_lua.jpg"
-put all the "*.png" images into "...lua_edu_tools\images" and rename one of them to "cockpit.png"

----------------------------------------------------------------------------------------
CREDITS
----------------------------------------------------------------------------------------

-the original author of the file "cockpitBox.lua" is Vincent Giangiulio (Thanks for your permission).
-the original image of "cockpit_luna_lander.png" was found at:
 http://commons.wikimedia.org/wiki/File:Apollo_Lunar_Module_Inside_View.jpg. The owner of the picture is Tyler Rubach.
-All other images are courtesy of NASA [nasa.gov]
-the "cockpit-layer-images" are modified to use with Celestia 
 by Michael Reinert (MiR) [m.reinert@sunshinepro.de] (c) 2009
Free to use only for non-commercial activities.

-----------------------------------------------------------------------------------------
