Note: This CELX script was written originally by Don Goyette. It has been modified after
some discussion on the Shatters Net Celestia Forum in order to provide functionality with
all of the new versions of Celestia. Modifications were provided by Vincent, and were
then packaged for this add-on by Old Brain-Dead Bob.

Simply extract this script to your Celestia\scripts directory prior to use.