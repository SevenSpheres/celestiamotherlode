This is Jupiter texture. It is an unusual view,and to make sure that this image shows how really Jupiter looks from space,I included an image from Voyager at close range.

Unzip into your Celestia root directory \Celestia\textures\medres

Don't forget to make a back-up of the original texture because it will be removed!!!