==Krypton & Rao==
by MistaGuitarMasta


This addon will add Superman's homeworld of Krypton and its red sun, Rao, to Celestia. 
In 2007, it was discovered that an Earth-like planet was orbiting the star Gliese 581.
This planet, known as 'b' in Celestia, has been hailed as the real-life planet Krypton.
Inspired by this, I created this addon to turn Gliese 581 and 'b' into Rao and Krypton as
seen in the 2006 film "Superman Returns". The texture for Rao was created from an actual
screenshot taken from "Superman Returns", and the texture for Krypton was created in Adobe
Photoshop using the texture for Jupiter's moon Europa. 

To install, simply unzip the files directly into your Celestia directory (For Windows users, that's
"C:\Program Files\Celestia" and for Mac users it's "Macintosh HD\Applications\Celestia Resources")

Enjoy!

Faster than a speeding bullet! More powerful than a locomotive! Able to leap tall buildings
in a single bound! Look! Up in the sky! It's a bird! It's a plane! IT'S SUPERMAN!Yes, it's
Superman: strange visitor from another planet who possesses powers and abilities far beyond
those of mortal men. Superman, who can change the course of mighty rivers, bend steel in his
bare hands, and who, disguised as Clark Kent, mild-mannered reporter for a great metropolitan
newspaper, fights a never-ending battle for truth, justice and the American way!