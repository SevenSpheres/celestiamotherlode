HYPOTHETICAL PLANETS
By Michael Rinschler, Sept. 2005

The original inspiration for this addon was Paolo Maffei's "I mostri del cielo" (as translated by Mirella and Riccardo Giacconi), specifically chapter 2.

I took specific orbital and size information from Paul Schlyter's "Hypothetical Planets" page (http://seds.lpl.arizona.edu/nineplanets/nineplanets/hypo.html) and several Wikipedia articles.  Because many of these had different theories of their orbits, sizes, compositions, etc., I had to choose (often arbitrarily, although I strove to take as much from one person as possible for each) the ones I felt worked best.

Perhaps the one with the greatest number of variations in the theory would be Planet X.  There were several tempting options.  I eventually settled on Brady's prediction, as it was the one mentioned by Maffei.  I may soon get around to making an addon with all the hypothetical "Planet X's" (including Brady's) as well.

The texture for Vulcan is a recolored asteroid.jpg; all the others use textures which come with Celestia.