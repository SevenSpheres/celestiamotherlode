mimas textures and bump map
both 512 x 256, in png format
make sure that the mimas part of solarsys.ssc looks like this:

"Mimas" "Sol/Saturn"
{
	Texture "mimas.*"
	BumpMap "mimas-bump.*"
	BumpHeight 10.0
	Color [ 0.65 0.60 0.55 ]
	BlendTexture true
	Radius    198.6

	CustomOrbit "mimas"
	EllipticalOrbit
	{
	Period         0.9424218
	SemiMajorAxis  185520
	Eccentricity   0.0202
	Inclination    1.53
	MeanAnomaly    23
	}

	Obliquity		  1.5 #J2000.0
	EquatorAscendingNode	137.8 #J2000.0
	RotationOffset		190.7 #J2000.0

	Albedo         0.1
}