Summary: The Avatar System 2.0 is a next improved version of my fictional solar system made based on James Cameron's movie Avatar. System have many objects to explore.

Description: This add-on contains high-quality textures. Some were found on the internet with no credits at all, and were remade for some other purpose. In this better version u can find, more moons around gas giant Polyphemus, some new textures for better look  and changed system location in Universe. The star Avatar was created by modifying Runar Thorvaldsen's star textures.

Instalation: All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.

!License!: Creative Commons License. See the following link: http://creativecommons.org/licenses/by-nc-sa/3.0  

Enjoy!


