Updated 06/20/06

This is a catalog of 3,840 NEAs (Near Earth Asteroids) for use with the Celestia
space simulator.

To use, simply copy the NEA.ssc file to your Celestia\extras folder.  The next
time you run the simulation, the universe should be populated with these
objects.

Disclaimer and notes:

For entertainment/educational use only.  While I believe the data to be
reasonably accurate, it should not be used to absolutely determine past or
future planetary encounters or long-term trajectories.

For example, gravity from a planetary encounter can significantly alter the
orbit of an object.  Therefore, running the simulation and going backward or
forward a number of years will produce different results from what actually
occured or will occur at that moment in time.  However, the simulations I ran
on numerous objects have been close enough to be entertaining/educational.  :)

At this time, the data file I use does not contain much physical data on these
objects.  In fact, a lot of this data is not known anyway.  Thus, some of these
characteristics are assumed (geometric albedo=.154), some are estimated (radius,
estimated from the absolute magnitude), and some are pulled out of my arse
(rotation period=random).  ;)  Feel free to add this data or change it in any
way you like, as the orbits are unaffected by such.

If there's sufficient interest, I'd be happy to keep this file up-to-date and/or
generate files with additional objects.

Feel free to contact me at:
owen_mcq@yahoo.com

Thanks to:

The creators of Celestia - http://www.shatters.net/celestia/
The MPC Orbit (MPCORB) database - http://cfa-www.harvard.edu/iau/MPCORB.html
The Celestia Motherlode - http://www.celestiamotherlode.net/
Arlene Ducao (whose scripts I used for the basis of making my own)
