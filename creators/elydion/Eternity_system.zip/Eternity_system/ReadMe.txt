This is the Chronos/Eternity System
It contains 6 planets, of which 2 are double-planets.
if you are afraid of this star ruining your perfect sky, dont worry.
Chronos is placed some 100 lightyears from earth and is placed behind the sirius system.
this way, you can't see it directly from earth.
-
INSTALL:
copy this folder into your "celestia/extra" folder
and unzip it (or the other way around; doesn't really matter)
-
I hope you like it
-
If you wish to comment on this solar system, please do as it is my first and i'd love to hear some critics (good or bad) on my work
-
This add-on may only be used with celestia software and is free to disribute.
If you wish to use this add-on in any other way than using celestia; please contact me:
Joen_meloen@hotmail.com
(no spam please!!!!)