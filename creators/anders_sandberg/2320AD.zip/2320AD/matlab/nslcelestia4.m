% Produce Celestia files from revised near starmap file
% Anders Sandberg 2008

rand('seed',2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Load near star map %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[GDWGlieseNumber,X,Y,Z,Name,AlternativeName,GameName,KaferName,TypeAndClass,SpectroscopicBinary,AbsoluteMagnitude,Remarks,Errata,ExtrasolarSystem,GlieseNumber,HIP]=textread('nslhipp3.dat','%f%f%f%f%q%q%q%q%q%q%f%q%q%q%f%d');

N=size(X,1);

% Create names
name=Name;
for i=1:N
   if (strcmp(AlternativeName(i),'')==0)
      name(i)=strcat(name(i),':',AlternativeName(i));
   end
   
   if (strcmp(KaferName(i),'')==0)
      name(i)=strcat(name(i),':',KaferName(i));
   end
   
   if (strcmp(GameName(i),'')==0)
      name(i)=strcat(name(i),':',GameName(i));
   end
   if (name{i}(1)==':') name{i}(1)=''; end
end

% Star types
type=char(TypeAndClass(:,1));
type(find(strcmp(type,'B')))='.';

% is it a white dwarf?
kind=ones(N,1)*5;
for i=1:N
   if (~isempty(findstr(char(type(i,:)),'vii')))
      kind(i)=7;
   end
end

SpectroscopicBinary=strcmp(SpectroscopicBinary,'SB');

% Calculate luminosity and estimate its mass
luminosity=10.^(4.83-AbsoluteMagnitude);
mass=(luminosity>1).*luminosity.^0.25+(luminosity<=1).*luminosity.^(1/2.8);
mass=mass.*(kind==5)+(kind==7)*1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% find links and multiples %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
link=sparse(N);
dists=zeros(N);
multiple=cell(N,1);
ismultiple=zeros(N,1);
for i=1:N
   dx=X(i)-X;
   dy=Y(i)-Y;
   dz=Z(i)-Z;
   d=sqrt(dx.^2+dy.^2+dz.^2);
   f=find(d<=7.7);
   link(i,f)=1;
   dists(i,:)=d';
   f=find(d<0.01);
   if (length(f)>1)
      multiple{min(f)}=f;
      ismultiple(f)=min(f);
   end
end

%%%%%%%%%%%%%%%%%%%%%% Produce the barycenters and orbits of multiple star systems %%%%%%%%%%%%%%%%%%%%
multiplicityfixed=zeros(N,1);
orbits=zeros(N,1);
baryc=1;
firststar=[];
Period=zeros(N,1);
SemiMajorAxis=zeros(N,1);
Eccentricity=zeros(N,1);
Inclination=zeros(N,1);
AscendingNode=zeros(N,1);
LongOfPericenter=zeros(N,1);
MeanLongitude=zeros(N,1);

% data for barycenters
NN=sum(ismultiple>0);
bPeriod=zeros(NN,1);
bSemiMajorAxis=zeros(NN,1);
bEccentricity=zeros(NN,1);
bInclination=zeros(NN,1);
bAscendingNode=zeros(NN,1);
bLongOfPericenter=zeros(NN,1);
bMeanLongitude=zeros(NN,1);

% Is the barycenter internal to a system or in interstellar space?
internal=[];

for i=1:N
   if (multiplicityfixed(i)==0 & ismultiple(i)>0)
      set=multiple{i};
      
      % Double stars
      if length(set)==2
         orbits(set)=baryc;
         multiplicityfixed(set)=1;
         firststar=[firststar i];
         baryc=baryc+1;
         internal=[internal 0];
         
         Eccentricity(set)=rand;
         Period(set)=14*exp(randn);
         
         % Fudge to add Tirane right
         if (i==99 | i==100)
            Eccentricity(set)=0.52;
            Period(set)=80;
            % sa should be 23
         end
         
         sa=((mass(set(1))+mass(set(2)))*Period(set(1))^2)^(1/3);
         % Hardwired fix for Aurore
         if (i==530 | i==531)
            sa=1.43;
         end
         
         SemiMajorAxis(set(2))=sa/((1+Eccentricity(set(1)))*(1+mass(set(2))/mass(set(1))));
         SemiMajorAxis(set(1))=SemiMajorAxis(set(2))*mass(set(2))/mass(set(1));
         Inclination(set(1))=0*rand;
         Inclination(set(2))=Inclination(set(1));
         AscendingNode(set(1))=0*rand;
         AscendingNode(set(2))=AscendingNode(set(1));
         LongOfPericenter(set(1))=0;
         LongOfPericenter(set(2))=180;
         MeanLongitude(set(1))=0;
         MeanLongitude(set(2))=180;
      end
      
      % Ternary systems
      if length(set)==3;
         [mm,in]=sort(-mass(set));
         set=set(in);
         
         multiplicityfixed(set)=1;
         ecc=sort([rand rand]);
         per=-14*sort(-exp([randn randn]));
         while (per(1)<7*per(2))
            per=-14*sort(-exp([randn randn]));
         end
         
         % A orbits baryc1, BC orbits baryc2 which orbits baryc1
         firststar=[firststar i];
         orbits(set(1))=baryc;
         internal=[internal 0]; 
         baryc=baryc+1;
         orbits(set(2))=baryc;
         orbits(set(3))=baryc;
         firststar=[firststar -baryc];
         parent(baryc)=baryc-1;
         internal=[internal 1]; % this is an internal barycenter
         baryc=baryc+1;
         
         massab=mass(set(2))+mass(set(3));
         
         Eccentricity(set(1))=ecc(1);
         bEccentricity(baryc-1)=ecc(1);
         Period(set(1))=per(1);
         bPeriod(baryc-1)=per(1);
         sa=((mass(set(1))+massab)*per(1)^2)^(1/3);
         bSemiMajorAxis(baryc-1)=sa/((1+Eccentricity(set(1)))*(1+massab/mass(set(1))));
         SemiMajorAxis(set(1))=bSemiMajorAxis(baryc-1)*massab/mass(set(1));
         Inclination(set(1))=0*rand;
         bInclination(baryc-1)=0*rand;
         AscendingNode(set(1))=0*rand;
         bAscendingNode(baryc-1)=0*rand;
         LongOfPericenter(set(1))=0;
         bLongOfPericenter(baryc-1)=180;
         MeanLongitude(set(1))=0;
         bMeanLongitude(baryc-1)=180;
         
         Eccentricity(set(2))=ecc(2);
         Eccentricity(set(3))=ecc(2);
         Period(set(2))=per(2);
         Period(set(3))=per(2);
         sa=((mass(set(2))+mass(set(3)))*per(2)^2)^(1/3);
         SemiMajorAxis(set(3))=sa/((1+Eccentricity(set(2)))*(1+mass(3)/mass(set(2))));
         SemiMajorAxis(set(2))=SemiMajorAxis(set(3))*mass(set(3))/mass(set(2));
         Inclination(set(3))=0*rand;
         Inclination(set(2))=0*rand;
         AscendingNode(set(3))=0*rand;
         AscendingNode(set(2))=0*rand;
         LongOfPericenter(set(3))=0;
         LongOfPericenter(set(2))=180;
         MeanLongitude(set(3))=0;
         MeanLongitude(set(2))=180;
      end
      
      % Quarternary systems
      if length(set)==4;
         [mm,in]=sort(-mass(set));
         set=set(in);
         
         % Hardwired fix for Kie Yuma
         if (sum(set==757)>0)
            set=[757 758 759 760];
            kieyuma=1;
         else
            kieyuma=0;
         end
         
         multiplicityfixed(set)=1;
         ecc=sort([rand rand rand]);
         per=-14*sort(-exp([randn randn rand]));
         while (per(1)<7*per(2) & per(1)<7*per(3))
            per=-14*sort(-exp([randn randn rand]));
         end
         
         mass13=mass(set(1))+mass(set(3));
         mass24=mass(set(2))+mass(set(4));
         sa=((mass13+mass24)*per(1)^2)^(1/3);
         
         % Hardwired fix for Kie Yuma
         if (kieyuma)
            sa=12.118;
            per(1)=sqrt((sa^3)/(mass13+mass24));
            per(2)=rand;
            per(3)=rand; 
         end
         
         % Star 1,3 orbits baryc2, Star 2,4 orbits baryc3
         % baryc2,3 orbits baryc1
         firststar=[firststar i];
         internal=[internal 0]; 
         baryc=baryc+1;
         
         orbits(set(1))=baryc;
         orbits(set(3))=baryc;
         firststar=[firststar -baryc];
         parent(baryc)=baryc-1;
         internal=[internal 1]; % this is an internal barycenter
         baryc=baryc+1;
         
         bEccentricity(baryc-1)=ecc(1);
         bPeriod(baryc-1)=per(1);
         bSemiMajorAxis(baryc-1)=sa/((1+ecc(1))*(1+mass13/mass24));
         bInclination(baryc-1)=0*rand;
         bAscendingNode(baryc-1)=0*rand;
         bLongOfPericenter(baryc-1)=0;
         bMeanLongitude(baryc-1)=0;       
         
         orbits(set(2))=baryc;
         orbits(set(4))=baryc;
         firststar=[firststar -baryc];
         parent(baryc)=baryc-2;
         internal=[internal 1]; % this is an internal barycenter
         baryc=baryc+1;
         
         bEccentricity(baryc-1)=ecc(1);
         bPeriod(baryc-1)=per(1);
         bSemiMajorAxis(baryc-1)=bSemiMajorAxis(baryc-2)*mass13/mass24;
         bInclination(baryc-1)=0*rand;
         bAscendingNode(baryc-1)=0*rand;
         bLongOfPericenter(baryc-1)=180;
         bMeanLongitude(baryc-1)=180;  
         
         
         Eccentricity(set(1))=ecc(2);
         Eccentricity(set(3))=ecc(2);
         Period(set(1))=per(2);
         Period(set(3))=per(2);
         sa=((mass(set(1))+mass(set(3)))*per(2)^2)^(1/3);
         SemiMajorAxis(set(3))=sa/((1+Eccentricity(set(1)))*(1+mass(set(3))/mass(set(1))));
         SemiMajorAxis(set(1))=SemiMajorAxis(set(3))*mass(set(3))/mass(set(1));
         Inclination(set(1))=0*rand;
         Inclination(set(3))=0*rand;
         AscendingNode(set(1))=0*rand;
         AscendingNode(set(3))=0*rand;
         LongOfPericenter(set(1))=0;
         LongOfPericenter(set(3))=180;
         MeanLongitude(set(1))=0;
         MeanLongitude(set(3))=180;
         
         Eccentricity(set(2))=ecc(3);
         Eccentricity(set(4))=ecc(3);
         Period(set(2))=per(3);
         Period(set(4))=per(3);
         sa=((mass(set(2))+mass(set(4)))*per(3)^2)^(1/3);
         SemiMajorAxis(set(4))=sa/((1+Eccentricity(set(2)))*(1+mass(set(4))/mass(set(2))));
         SemiMajorAxis(set(2))=SemiMajorAxis(set(4))*mass(set(4))/mass(set(2));
         Inclination(set(2))=0*rand;
         Inclination(set(4))=0*rand;
         AscendingNode(set(2))=0*rand;
         AscendingNode(set(4))=0*rand;
         LongOfPericenter(set(2))=0;
         LongOfPericenter(set(4))=180;
         MeanLongitude(set(2))=0;
         MeanLongitude(set(4))=180;      
      end     
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% Calculate stutterwarp links %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
reachable=zeros(N,1);
reachable(24)=1; % the sun
%reachable(30)=1; % 61 Cygni

while(sum(reachable==1))
   for i=1:N
      if (reachable(i)==1)
         reachable(i)=2;
         neighbours=find(link(i,:));
         for j=1:size(neighbours,2)
            if (reachable(neighbours(j))==0)
               reachable(neighbours(j))=1;
            end
         end
      end
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%% Save stc file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

RA=180-180*atan2(X,Y)/pi-90;
Dec=180*atan2(Z,sqrt(X.^2+Y.^2))/pi;
dist=sqrt(X.^2+Y.^2+Z.^2)

fid=fopen('2320ad.stc','w');
% List barycenters
for i=1:(baryc-1)
   id=i+5.5e5;
   j=firststar(i);
   if (j>0)
      fprintf(fid,'Barycenter %d "%d bary" {\n RA %f\nDec %f\nDistance %f\n}\n',id,i,RA(j), Dec(j), dist(j));
   else
      bar=-j;
      fprintf(fid,'Barycenter %d "%d bary" {\n OrbitBarycenter "%d bary" EllipticalOrbit { Period %f SemiMajorAxis %f Eccentricity %f Inclination %f AscendingNode %f LongOfPericenter %f MeanLongitude %f } \n}\n', id,i,parent(bar),bPeriod(bar),bSemiMajorAxis(bar),bEccentricity(bar),bInclination(bar),bAscendingNode(bar),bLongOfPericenter(bar),bMeanLongitude(bar));
   end
end

% List stars
for i=1:N
   if (HIP(i)<0)
      id=5e5+i;
   else
      id=HIP(i);
   end
   
   if (HIP(i)~=-2)
      absmag=AbsoluteMagnitude(i);
      
      if (orbits(i)==0)
         fprintf(fid,'%d "%s" {\n RA %f\nDec %f\nDistance %f\nSpectralType "%s"\nAbsMag %f\n}\n', id, char(name(i)), RA(i), Dec(i), dist(i), upper(char(TypeAndClass(i))), absmag);
      else
         fprintf(fid,'%d "%s" {\n OrbitBarycenter "%d bary"\nSpectralType "%s"\nAbsMag %f EllipticalOrbit { Period %f SemiMajorAxis %f Eccentricity %f Inclination %f AscendingNode %f LongOfPericenter %f MeanLongitude %f } \n}\n', id, char(name(i)), orbits(i), upper(char(TypeAndClass(i))), absmag, Period(i),SemiMajorAxis(i),Eccentricity(i),Inclination(i),AscendingNode(i),LongOfPericenter(i),MeanLongitude(i));
      end      
   end
end
fclose(fid);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Save pathways %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M=sum(reachable);
csubdiv=5; % Pentagonal prisms
R=0.1; % 1/10th ly across

% Rotate everything into celestia coordinates

YY=Y;
Y=Z;
Z=-YY;

angle=pi*23.44/180; % Earth axis tilt
YY=cos(angle)*Y+sin(angle)*Z;
Z=-sin(angle)*Y+cos(angle)*Z;
Y=YY;

% Save cmod file 
fid=fopen('2320ad.cmod','w');
fprintf(fid,'#celmodel__ascii\n');
fprintf(fid,'material\n diffuse 0.3 0.3 1.0 opacity 0.75 texture0 "hyperlink.png" emissivemap "hyperlink.png" end_material\n\n');
fprintf(fid,'mesh\n vertexdesc position f3 normal f3 texcoord0 f2\n end_vertexdesc\n\n');

verts=[];
tris=[];
currvert=0;
nvertices=0;

for ii=1:N
   if (reachable(ii)==2)
      neighbours=find(link(ii,:));
      for j=1:size(neighbours,2)
         if (neighbours(j)>ii)
            k=neighbours(j);
            
            x1=[X(ii) Y(ii) Z(ii)];
            x2=[X(k) Y(k) Z(k)];
            
            delta=x2-x1;
            distt=norm(delta);
            if (distt>0.01)  % Only plot between systems more than 0.01 ly away
               delta=delta/distt;
               right=cross([1 0 0],delta);
               if (norm(right>0))
                  right=right/norm(right);
               else
                  right=cross([0 1 0],delta);
                  right=right/norm(right);
               end
               
               up=cross(delta,right);
               up=up/norm(up);
               
               nvertices=nvertices+csubdiv*2;
               for i=0:(csubdiv-1)
                  theta=2*pi*i/csubdiv;
                  x=x1+R*(cos(theta)*right+sin(theta)*up);
                  n=cos(theta)*right+sin(theta)*up;
                  u=i/(csubdiv-1);
                  v=0;   
                  verts=[verts; x(1),x(2),x(3),n(1),n(2),n(3),u,v];
               end
               for i=0:(csubdiv-1)
                  theta=2*pi*i/csubdiv;
                  x=x2+R*(cos(theta)*right+sin(theta)*up);
                  n=cos(theta)*right+sin(theta)*up;
                  u=i/(csubdiv-1);
                  v=1;
                  verts=[verts; x(1),x(2),x(3),n(1),n(2),n(3),u,v];
               end      
               
               for i=0:(csubdiv-2)
                  tris=[tris; currvert+i,currvert+(i+1),currvert+(i+csubdiv), currvert+i+1,currvert+(i+1+csubdiv),currvert+(i+csubdiv)];
               end
               tris=[tris; currvert+i,currvert+0,currvert+(i+csubdiv), currvert+0,currvert+(csubdiv),currvert+(i+csubdiv)];
               
               currvert=currvert+csubdiv*2;          
            end
         end
      end
   end
end

% Add octahedron of vertices to ensure proper scaling
nvertices=nvertices+6+1;
oct=[1 0 0  1 0 0  0 0];
oct=[oct; -1 0 0  -1 0 0  0 0];
oct=[oct; 0 1 0   0 1 0  0 0];
oct=[oct; 0 -1 0   0 -1 0  0 0];
oct=[oct; 0 0 1  0 0 1  0 0];
oct=[oct; 0 0 -1  0 0 -1  0 0];
oct=[oct; 0 0 0 0 1 0 0 0];
oct=oct*200;
verts=[verts; oct];


fprintf(fid,'vertices %d\n',nvertices);
for i=1:nvertices
   fprintf(fid,'%f %f %f  %f %f %f  %f %f\n',verts(i,1),verts(i,2),verts(i,3),verts(i,4),verts(i,5),verts(i,6),verts(i,7),verts(i,8));
end

for i=1:size(tris,1)
   fprintf(fid,'trilist 0 6\n');
   fprintf(fid,'%d %d %d\n%d %d %d\n',tris(i,1),tris(i,2),tris(i,3),tris(i,4),tris(i,5),tris(i,6));
end

fprintf(fid,'end_mesh\n'); 
fclose(fid);

%%%%%%%%%%%%%%%%%%%%%%%%%%% Save planets %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid=fopen('2320ad.ssc','w');
[pname, parentname, orbit, diameter, ptype, optiontype1, optionvalue1,optiontype2, optionvalue2,optiontype3, optionvalue3]=textread('planets.csv','%s%s%f%f%s%s%f%s%f%s%f','delimiter',',');
for i=1:length(pname)
   
   % Fudged periods, not based on actual parent body data
   if (orbit(i)<1000) % Planet
      msun = 1; % Assumes all stars to be sunlike
      period = sqrt(orbit(i)^3/msun);
   else
      % Moon
      period = (29.530588)*sqrt((orbit(i)/384399)^3);
   end
   %%%% Add options options
   texture=char(ptype(i));
   
   % Calculate random inclination and ascension for orbit
   oo=orbit(i)/50;
   if (50*oo>1000) oo=oo/1e6; end
   inc=20*randn*(1-exp(-oo));
   asc=360*rand;
   
   %%%%%%%%%% Parse options
   
   ringstr='';
   orbitstr='';
   
   if strcmp(optiontype1(i),'Ring')
      inner = diameter(i)*(0.5+0.5*rand); 
      outer = diameter(i)*(1+rand*2);
      ringstr=sprintf('Rings { Inner %f Outer %f Texture "Ring%d.png" }', inner, outer, optionvalue1(i));
   end
   if strcmp(optiontype2(i),'Ring')
      inner = diameter(i)*(0.5+0.5*rand); 
      outer = diameter(i)*(1+rand*2);
      ringstr=sprintf('%s Rings { Inner %f Outer %f Texture "Ring%d.png" }', ringstr, inner, outer, optionvalue2(i));
   end   
   if strcmp(optiontype3(i),'Ring')
      inner = diameter(i)*(0.5+0.5*rand); 
      outer = diameter(i)*(1+rand*2);
      ringstr=sprintf('%s Rings { Inner %f Outer %f Texture "Ring%d.png" }', ringstr, inner, outer, optionvalue3(i));
   end   
   
   for option=1:3
      optiontype=optiontype1(i); optionvalue=optionvalue1(i);
      if (option==2) optiontype=optiontype2(i); optionvalue=optionvalue2(i); end
      if (option==3) optiontype=optiontype3(i); optionvalue=optionvalue3(i); end
      
      if strcmp(optiontype,'Rotation')
         ringstr=sprintf('%s RotationPeriod %f', ringstr, optionvalue);
      end
      
      if strcmp(optiontype,'Tilt')
         ringstr=sprintf('%s Obliquity %f', ringstr, optionvalue);
      end   
      
      if strcmp(optiontype,'Eccentricity')
         orbitstr=sprintf('%s Eccentricity %f ', orbitstr, optionvalue);
      end
      
      if strcmp(optiontype,'Inclination')
         inc = optionvalue;
      end
      
      if strcmp(optiontype,'MeanLongitude')
         orbitstr=sprintf('%s MeanLongitude %f ', orbitstr, optionvalue);
      end
      
      if strcmp(optiontype,'Period')
         period = optionvalue;
      end  
   end
   
   %%%%%%%%
   
   if (diameter(i)<1000)
      ringstr=sprintf('%s Mesh "roughsphere.cms"', ringstr);
   end
   
   if strcmp(ptype(i),'Bary')
      fprintf(fid,'"%s" "%s"\n{ Mesh "empty.3ds" Color [ 0 0 0 ] Radius 100000  EllipticalOrbit { Period %f SemiMajorAxis %f Inclination %f AscendingNode %f } }\n', char(pname(i)),char(parentname(i)), period, orbit(i), inc, asc);
   else
      fprintf(fid,'"%s" "%s"\n{Radius %f Texture "%s.jpg" EllipticalOrbit { Period %f SemiMajorAxis %f Inclination %f AscendingNode %f %s } %s }\n', char(pname(i)),char(parentname(i)),diameter(i)/2,texture, period, orbit(i), inc, asc, orbitstr, ringstr);
   end
end

fclose(fid);
