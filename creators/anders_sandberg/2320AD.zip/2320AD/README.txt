2300AD/2320AD Universe 1.0
by Anders Sandberg, asa@nada.kth.se


DESCRIPTION

This addon represents the universe of the 2300AD and 2320AD
roleplaying games. The setting is the stars within ~60 ly from the sun
(originally based on the Gliese catalogue).

In the game the FTL drive (the main fudge in terms of physics) has a
distance limit of 7.7 ly before it must be discharged in a sizeable
gravity well. This makes only some routes possible, leading to "arms"
of expansion and various political and military complications. The
addon displays the arms using a green "nebula" depicting possible
paths.

There is also a yellow network corresponding to the "61 Cygni
cluster", an arm that may become available due to recent technical
developments; this is as yet (2320) unexplored.

When the original game was written in 1989 the second edition Gliese
catalogue was used. Since then better parallax measurements have been
done, new stars have been discovered and some objects have
disappeared. Since the map is sensitive to such changes the game must
retain the old coordinates rather than use modern ones. It is not just
an alternate timeline (since the Twilight War did not occur in the
1990s) but an alternate cosmography. As far as possible this addon
moves stars to the game coordinates rather than their current best
estimated (see below for some of the issues with this). The locations
are based on Andy Brick's Near Star List II.

My generation software generates orbits for multiple star
systems. This is done randomly, with orbit periods distributed
lognormally with mean of 14 years and masses estimated from the
mass-luminosity relation of main sequence stars. 

Planets and systems are primarily based on descriptions in 2300AD
Colonial Atlas, the 2320AD book and Dan Schirren's non-canon list of
planets (available from http://stalexone.tripod.com/gg2/map-info.htm )
Wherever possible I have used 2320 data, then 2300 data, then Dan's
list and finally made up information that seems plausible. This has
mainly been done for planet diameters, which were generated based on
the planet type and the 2300AD random planet generation system (i.e. I
generated a large set of planets and then selected one randomly
depending on type).

Note that this addon is not suitable for planning any interstellar or
interplanetary excursions. For accurate navigational data, please
consult the current 2320 IAU Object Catalogue, the ESA Carte
Astronomique Database (Annex IV and upwards) or the full AECA
Atlas. The author is in no way responsible for navigational hazards,
loss of PC lives or equipment damages due to this addon. The addon
does not make any statements about the colonizability of different
worlds.


INSTALLATION

Place the 2320AD folder in the Celestia extras folder.

It includes a models subfolder (the pathways cmod model, the 61 cygni
cluster and an empty model), a textures folder and dsc, ssc and stc
files. 

Also included are a Matlab script to generate these files from a star
database file and a planet list. 



INCLUDED SYSTEMS

Augereau, Aurore, Austin's World, Avalon, Beowulf, Berthier,
Bessieres, Beta Canum Venaticorum, Botany Bay, Chengdu (buggy), Cold
Mountain, Daikoku, Doris, Dukou, Dunkelheim, Ellis, Eriksson,
Freiland, Haifeng, Heidelsheimat, Henry's Star, Hermes, Hochbaden,
Joi, Kie-Yuma, Kimanjano, King, Kingsland, Kormoran, Kwantung,
Lightfall, Montana, Neubayern, Nous Voila, Nyotekundu, Paulo, Proxima
Centauri, Ross 128, Ross 614, Sans Souci, Stark, Syuhulahm, Tirane,
Vogelheim


KNOWN ISSUES

This addon tries to override the existing star database, but is not
entirely successful. Epsilon Indi appears in two places, and Epsilon
Eridani suffers from having the real exoplanets show up among the game
ones.

Multiple star systems are all in same plane. The subsystems ought to
have different inclinations. Systems with canon distances and periods
are in most cases not looking like they should yet.

Orbits are not necessarily collision free.

The solar system browser appears to get confused by planets in
multiple star systems and only show some of the planets.

Periods of planets and moons are not correct, since they are all based
on the assumption of 1 solar mass stars or 1 earth mass planets.

There should be many more moons in the systems, but I have not
generated them. Moons in the canon have been added.

Not all outposts have been added yet. Ditto for Kafer space worlds. 

Gas giants generated using the 2300AD system tend to be far too
small. Occasionally they snowball the absurdly large sizes; due to
degeneracy pressure they are not likely to become much larger than
~150,000 km diameter.

Currently garden worlds have just the same earth placeholder texture
rather than canon maps. Ideally the textures should be improved
radically.

Since Octave to my knowledge does not have textread (and may have
trouble with my use of cell arrays) the Matlab script would need a
rewrite to function under that program.  In which case a porting to,
say, Python would make much more sense anyway.


CREDITS

This package makes use of:

Grant's empty object for Celestia,
http://www.lns.cornell.edu/~seb/celestia/hutchison/empty.html

The kimanjano map is based on an original by Laurent Esmiol.

Thanks to Beech on the Citizens of the Imperium forum for suggesting
the idea in the first place.
