The asteroid 2011 AG5

by Enrico Spada, March 2012

This add-on contains the file with the orbital parameters of the asteroid 2011 AG5 which will perform a flyby on February 5, 2040.
The flyby occurs around the Julian date 2466189.60883.
The orbital parameters were taken from the page: http://ssd.jpl.nasa.gov/sbdb.cgi?sstr=2011AG5; cad = 1; orb = 0; cov = 0, log = 0 # elem

INSTALLATION:
extract 2011 AG5.ssc  to your Celestia \ extras folder.