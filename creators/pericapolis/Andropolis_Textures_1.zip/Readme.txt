Thanks for downloading this addon:
First, my english is not perfect but I will try to explain the instructions.

If you have donwloaded this add on with cashing please contact immediately with the creator of the add on.

FILES:
Extras- Andropolissystem, Andropoliscomets.
Textures- Medres- Andropolisspecular, asteroidfire, asteroidfirenight, CCO, CCOspecular, desertfire, desertfirenight, ero, eroo,
jupiterclouds2, lantera, lanteraspecular, likegas, likegas2, likejupiterpink, likejupiterpinknight, likemoon, likemoonnight,
likemoonspecular, asteroidstorm, triniom, triniomspecular, tritiumrings, waterplanet. waterplanetspecular.

Instructions:
Copy all the files into the folders with the same name.

Dedicated to my friend CCO.

Created by: Pericapolis
For contact with the creator please write to Pericapolis@hotmail.com