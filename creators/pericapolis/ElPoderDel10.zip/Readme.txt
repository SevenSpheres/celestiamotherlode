Thanks for downloading my spanish traduction, thanks to the Clestiamotherlode page for put it on the page,
and thanks to the creator of the original version of the script.

INSTRUCTIONS:
It's very easy to install, you only have to descompress the archive and put it in the Celestia folder, if you have made a
folder for scripts and demos you should put the archive ElPoderDel10 in that folder.

As you can see my english is not perfect but I hope that you have understood the instructions.
Enjoy this script.
Thanks for reading the instructions.