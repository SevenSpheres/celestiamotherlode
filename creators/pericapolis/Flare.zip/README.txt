First of all, I would like to thank you by choosing my textures for your celestia program.


Installation:
Select the best image of the adjunted ones.
Copy and paste, or move it with the mouse, to the folder TEXTURES cointained in the CELESTIA folder.
Replace the texture called FLARE wich should be on that folder with the one you have choosen.
Finally run the program.

Some textures will not be as good as they should be because of the screen contrast configuration.


MORE AND DETAILED INFORMTAION IN THE LEAME.TXT FILE (SPNISH)



questions, doubts, ...:    Pericapolis@hotmail.com


Is not confirmed that mails that are not in SPANISH will be responded.