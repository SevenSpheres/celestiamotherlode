
INSTRUCTIONS:
My english is not perfect but I think is easy to understand the instructions.
Thanks for downloading these flares with reflection, you should put the files
into the textures folder of Celestia, you shoud select one of the images and change the name to "flare".
If the positions of the flare aren't in the correct position you can move the image with a photography program.

Dedicated to my friend CCO.

For questions please write to Pericapolis@hotmail.com
If you find a problem please contact me.