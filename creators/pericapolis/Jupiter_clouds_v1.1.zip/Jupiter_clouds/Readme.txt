This add-on has been modified by Adirondack (March 2013):
-) fixed error and added modify-command in ssc file
-) modification of directory structure for a simple use

INSTRUCTIONS:
Thanks for downloading these files, this is a texture for Jupiters clouds. To use it, you have to put
all contents of the zip file to the \extras\ directory of your Celestia installation. 
Restart Celestia and you are done.