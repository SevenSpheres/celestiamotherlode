INSTRUCTIONS:
Thanks for downloading these files, this is a texture for Jupiter clouds, for use it, you should put the texture files into
the texture -> medres, and then copy the information of the file IMPORTANT into the solarsys archive DON'T COPY DIRECTLY THE
ARCHIVE, OPEN IT AND THEN COPY THE JUPITER INFORMATION.