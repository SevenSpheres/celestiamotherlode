
Simply unzip this zip file into your extras or Addons directory.

This add-on contains data of a model of the quadruple star system KIC 4862625, 
and a relevant circumbinary exoplanet PH1, orbiting around the Aa and Ab stars.

Rev. 1.0 - 21/10/2012
First release.

References:
- http://archive.stsci.edu/kepler/kepler_fov/search.php
- "Planet Hunters: A Transiting Circumbinary Planet in a Quadruple Star System", 
  Megan E. Schwamb et al., Cornell University, http://arxiv.org/abs/1210.3612v1
- "A Gas Giant Circumbinary Planet Transiting an Evolved F Star Primary of the 
  Eclipsing Binary Star KIC 4862625 and the Independent Discovery and 
  Characterization of the two transiting planets in the Kepler-47 System", 
  V. B. Kostov et al., Cornell University, http://arxiv.org/abs/1210.3850v1

Luigi C.
