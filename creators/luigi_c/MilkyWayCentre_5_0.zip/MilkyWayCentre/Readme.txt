
Simply unzip this zip file into your extras or Addons directory.  

This add-on contains the following stellar objects, related to the Milky Way centre:
- "Milky Way black hole:Sagittarius A*:Sgr A*" the supermassive black hole at the centre of our Galaxy
- S-stars orbiting around the supermassive black hole.

Rev. 5.0 - 19/09/2012
The model of the black hole has been taken from my Cygnus X-1 add-on; this model has been adapted to the supermassive Galaxy 
centre black hole.

References:
- http://it.wikipedia.org/wiki/Centro_della_Via_Lattea
- http://it.wikipedia.org/wiki/Sagittarius_A
- http://it.wikipedia.org/wiki/Sagittarius_A*
- http://it.wikipedia.org/wiki/S2_(astronomia)
- A. M. Ghez et al., "Stellar orbits around the galactic center black hole", The Astrophysical Journal, 620:744�757, 2005 February 20
- A. M. Ghez et al., "Measuring distance and properties of the Milky Way�s central supermassive black hole with stellar orbits", The Astrophysical Journal, 689:1044Y1062, 2008 December 20
- S. Gillessen et al., "Monitoring stellar orbits around the massive black hole in the galactic center", The Astrophysical Journal, 692:1075�1109, 2009 February 20
- S. Gillessen et al., "The orbit of the star S2 around Sgr A* from very large telescope and Keck data", The Astrophysical Journal, 707:L114�L117, 2009 December 20
- Greg Howes, "S-Stars in the Galactic Center", March 31, 2006 (http://astro.berkeley.edu/~pchang/sstars_gc.pdf)
- Parameters Describing Elliptical Orbits (http://www.lns.cornell.edu/~seb/celestia/orbital-parameters.html)


Luigi C.
