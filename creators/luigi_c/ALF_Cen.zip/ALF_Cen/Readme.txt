
Simply unzip this zip file into your extras or Addons directory.

This add-on contains data of a model of the recently discovered exoplanet ALF 
Cen Bb, orbiting around the star B of the Alpha Centauri system.

Rev. 1.0 - 24/10/2012
First revision.

References:
- en.wikipedia.org/wiki/Alpha_Centauri_Bb

Luigi C.
