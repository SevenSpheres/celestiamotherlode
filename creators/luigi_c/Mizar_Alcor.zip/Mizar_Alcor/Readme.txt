
Simply unzip this zip file into your extras or Addons directory.

This add-on contains data of a model of Mizar-Alcor sextuple system.
Remove or comment lines related to Mizar and Alcor in spectbins.stc.

Rev. 1.0 - 18/07/2012
First issue

References:
- http://en.wikipedia.org/wiki/Mizar_and_Alcor
- http://it.wikipedia.org/wiki/Mizar
- http://it.wikipedia.org/wiki/Alcor
- http://www.leosondra.cz/en/mizar/

Luigi C.
