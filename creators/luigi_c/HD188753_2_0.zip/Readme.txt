
Simply unzip this zip file into your extras or Addons directory.

This is a zip file containing the following stars and relevant transiting exoplanets candidates announced in the 2005 by the Polish astronomer working in the United States, Dr. Maciej Konacki:
HD 188753 A
	HD 188753 Ab
HD 188753 B
HD 188753 C

My work is based on the data contained in the following pages:
- http://it.wikipedia.org/wiki/HD_188753
- http://en.wikipedia.org/wiki/HD_188753
- http://www.extrasolar.net/startour.asp?StarCatId=&StarId=257
- http://www.extrasolar.net/startour.asp?StarCatId=&StarId=258
- http://www.extrasolar.net/startour.asp?StarCatId=&StarId=259
- http://www.extrasolar.net/planettour.asp?StarCatId=&PlanetId=305 .

Luigi C.
