
Simply unzip this zip file into your extras or Addons directory.  

This is a zip file containing the following stars and relevant transiting exoplanets candidates discovered by the Kepler mission:
Kepler-4
	Kepler-4b
Kepler-5
	Kepler-5b
Kepler-6
	Kepler-6b
Kepler-7
	Kepler-7b
Kepler-8
	Kepler-8b
Kepler-9
	Kepler-9b
	Kepler-9c
	Kepler-9d
Kepler-10
	Kepler-10b
	Kepler-10c
Kepler-11
	Kepler-11b
	Kepler-11c
	Kepler-11d
	Kepler-11e
	Kepler-11f
	Kepler-11g

My work is based on the Edasich work and the data provided by the Kepler researchers, see the page http://kepler.nasa.gov/Mission/discoveries/ .

The stellar distances of Kepler-5, Kepler-6 and Kepler-7 have not been provided and these are inferred from apparent magnitude estimated by Kepler researchers.

The planet Kepler-10c is not reported in the Kepler list of the confirmed planets, but the relevant data has been taken from http://exoplanet.eu/planet.php?p1=Kepler-10&p2=c .

The textures provided in the folder textures\medres are the Edasich's original ones, I have not added, deleted or edited anything. 

Thanks to Edasich for his precious work.

Luigi C.
