
Simply unzip this zip file into your extras or Addons directory.  

This is a zip file containing a fix/update for the "Crab Nebula" add-on. The Messier identifier "M1" has been added, some data has been corrected for the nebula and the related pulsar PSR B0531+21.
The pulsar correction is related to the "atnf_pulsars_v2" add-on.
Models and textures are the "Crab Nebula" add-on original ones, I did not add, delete or change anything.
A simple model for a hypothesized planetary companion of the pulsar is provided, to explain certain variations observed in pulsar timing.
In the file "M1 Crab Nebula.dsc" of the "Crab Nebula" add-on the following objects should be deleted or commented (char #):
- Nebula "Crab Nebula".
In the file "pulsars_atnf_v2.stc" of the "atnf_pulsars_v2" add-on the following objects should be deleted or commented (char #):
- 900089 "PSR B0531+21".


References:
- http://simbad.u-strasbg.fr/simbad/sim-basic?Ident=M1&submit=SIMBAD+search
- http://en.wikipedia.org/wiki/Crab_Nebula
- http://en.wikipedia.org/wiki/Crab_Pulsar
- http://seds.org/messier/m/m001.html


Luigi C.
