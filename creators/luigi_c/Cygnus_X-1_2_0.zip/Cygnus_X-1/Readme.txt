
Simply unzip this zip file into your extras or Addons directory.

This is a zip file containing an add-on to fix the data of the star HD 226868 (HIP 98298) and add the data of the compact companion Cygnus X-1. Cygnus X-1 (abbreviated Cyg X-1) is a well known galactic X-ray source in the constellation Cygnus. It was
discovered in 1964 during a rocket flight and is one of the strongest X-ray sources seen from Earth.
Cygnus X-1 was the first X-ray source widely accepted to be a black hole candidate. It is now estimated to have a mass about 8.7 times the mass of the Sun, and has been shown to be too compact to be any known kind of normal star or other likely object besides a black hole.

Rev. 2.0 - 26/03/2011
The binary system data are taken from actual estimates and calculation results, but the black hole is shown by means of a fictitious 3D model.
The black hole model has been taken from the "CygnusX1" add-on, by Martin Charest (Cham).
Textures and models are those of Cham's add-on.

References:
- http://en.wikipedia.org/wiki/Cygnus_X-1

Luigi C.
