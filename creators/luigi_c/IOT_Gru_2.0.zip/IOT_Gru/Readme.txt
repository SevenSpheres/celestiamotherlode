
Simply unzip this zip file into your extras or Addons directory.  

This is a zip file containing an add-on for the IOT Gru binary star system. This add-on replaces the default definition of the IOT Gru (HIP 114421) star, and fixes the barycenter coordinates and some stellar parameters of the IOT Gru system defined inside the "Stellar Degenerates" add-on.

If the "Stellar Degenerates" add-on has been previously installed, then its definitions of the following objects should be deleted or commented (char #):
- Barycenter 114421 "IOT Gru"
- IOT Gru A
- IOT Gru B.

Rev. 2.0 - 21/03/2011

References:
- http://cdsweb.u-strasbg.fr/cgi-bin/bibobj?2003A%26A...398.1163P&114421
- http://astropc8.ulb.ac.be/~pourbaix/Papers/aa3073.pdf
- http://adsabs.harvard.edu/abs/2005A%26A...442..365J
- http://server1.wikisky.org/starview?object_type=1&object_id=670&object_name=HIP+114421&locale=EN
- http://adsabs.harvard.edu/full/2001BaltA..10..481B


Luigi C.
