
Simply unzip this zip file into your extras or Addons directory.

This add-on contains data of a model of the sextuple stellar system of Gamma 
Velorum, also called Regor.
Mass and radius of C, D, E components have been estimated on the basis of the 
known parameters.
C and D components are supposed to be luminosity class V.
E component is supposed to be spectral class K0V.

Rev. 1.0 - 28/07/2012
First issue

References:
- http://it.wikipedia.org/wiki/Gamma_Velorum
- http://en.wikipedia.org/wiki/Gamma_Velorum
- http://stars.astro.illinois.edu/sow/regor.html
- J. R. North, P. G. Tuthill, W. J. Tango and J. Davis, "Gamma2 Velorum: 
  Orbital Solution and Fundamental Parameter Determination with SUSI"
  http://arxiv.org/abs/astro-ph/0702375v1

Luigi C.
