
Simply unzip this zip file into your extras or Addons directory.

This add-on contains orbital data of some recently discovered object of the 
Solar System.

Rev. 3.0 - 12/02/2013
Corrected the parameters of the P4 and P5 orbits.

Rev. 2.0 - 11/07/2012
Added the satellite P5 of planet Pluto.

Rev. 1.0 - 21/07/2011
First release. Added the satellite P4 of planet Pluto.

References:
- http://en.wikipedia.org/wiki/Moons_of_Pluto
- http://it.wikipedia.org/wiki/Satelliti_naturali_di_Plutone
- http://en.wikipedia.org/wiki/S/2011_P_1
- http://en.wikipedia.org/wiki/S/2012_P_1
- http://www.nasa.gov/mission_pages/hubble/science/pluto-moon.html

Luigi C.
