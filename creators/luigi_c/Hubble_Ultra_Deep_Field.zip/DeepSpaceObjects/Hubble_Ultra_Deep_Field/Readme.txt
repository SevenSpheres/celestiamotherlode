
Simply unzip this zip file into your extras or Addons directory.  

This is a zip file containing an add-on for some galaxies of the Hubble Ultra Deep Field:
- UDFj-39546284: this is a compact galaxy of blue stars that existed as we see it 13.2 billion years ago, around 480 million years after the Big Bang. It is the oldest galaxy found as of 26 January 2011.
- UDFy-38135539: this is a galaxy which has been calculated (as of October 2010) to have a light travel time of 13.1 billion years with a present comoving distance of around 30 billion light-years. UDFy-38135539 is still the most distant object spectroscopically confirmed.

References:

- http://en.wikipedia.org/wiki/UDFj-39546284
- http://en.wikipedia.org/wiki/UDFy-38135539


Luigi C.
