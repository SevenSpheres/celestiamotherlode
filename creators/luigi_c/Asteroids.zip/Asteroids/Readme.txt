
Simply unzip this zip file into your extras or Addons directory.

This add-on contains the orbital elements for some asteroids:
- 99942 Apophis (2004 MN4)
- 518 Halawe (1903 MO).
Updated on June 1, 2011, orbital elements at Epoch 2455713.500000000 = A.D. 2011-Jun-01 00:00:00.0000 (CT).

Rev. 1.0 - 01/06/2011
First revision.

References:
- http://ssd.jpl.nasa.gov

Luigi C.
