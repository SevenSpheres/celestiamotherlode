
Simply unzip this zip file into your extras or Addons directory.

This add-on is an update of the Gamma Leonis star system. Gamma Leonis is a 
binary star system in the constellation Leo. It has the traditional name Algieba 
or Al Gieba.

Rev. 1.0 - 08/05/2011
The Gamma Leonis star system has been updated to a binary system.
The "A" star data have been updated.
The "b" exoplanet data have been updated.
The files "Gamma1 Leonis b.ssc" and "Gamma1 Leonis c.ssc" of the add-on 
"2009 Exoplanets" have to be moved away or deleted.

References:
- http://exoplanet.eu/catalog-all.php
- http://en.wikipedia.org/wiki/Gamma_Leonis
- http://stars.astro.illinois.edu/sow/algieba.html
- "Detection of a Planetary Companion around the giant star gamma1 Leo", Inwoo 
  Han et al., Astronomy & Astrophysics manuscript no. 12536tex, ESO 2009, 
  November 5, 2009

Luigi C.
