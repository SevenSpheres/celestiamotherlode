
Simply unzip this zip file into your extras or Addons directory.  

This is a zip file containing a fix for the following objects:
- OGLE-2005-BLG-390L and the related exoplanet OGLE-2005-BLG-390Lb
- OGLE-2007-BLG-368 and the related exoplanet OGLE-2007-BLG-368Lb

The following add-on files, if previously installed, should be deleted or moved away from the extras or Addons directory:
- OGLE-2005-BLG-390L.stc
- OGLE-2005-BLG-390Lb.ssc
- OGLE-2007-BLG-368.stc
- OGLE-2007-BLG-368Lb.ssc

References:

- http://en.wikipedia.org/wiki/OGLE-2005-BLG-390L
- http://en.wikipedia.org/wiki/OGLE-2007-BLG-368L
- http://en.wikipedia.org/wiki/OGLE-2007-BLG-368Lb


Luigi C.
