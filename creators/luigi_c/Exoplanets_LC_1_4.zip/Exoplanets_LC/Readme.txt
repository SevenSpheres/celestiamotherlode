
Simply unzip this zip file into your extras or Addons directory.  

This add-on contains data for some stars and related exoplanets; this is an 
integration to other Celestia add-ons which have been already published on 
Celestia Motherlode.
WARNING: the following add-ons are supposed to have been previously installed: 
"HR 8799", "T_Tauri_Stars".
WARNING: if an already installed older add-on provides the same planets then 
the old planets definitions have to be removed in order to avoid duplication.

Rev. 1.4 - 26/05/2011
Updated data according to http://exoplanet.eu/catalog.php, 26/05/2011.

References:
- http://exoplanet.eu/catalog-all.php
- http://exoplanet.eu/catalog-contro.php
- http://en.wikipedia.org
- http://simbad.u-strasbg.fr
- http://www.pd.astro.it/new_sites/ESP/stella%20planetaryr.htm
- http://iopscience.iop.org/0004-637X/729/2/139
- http://arxiv.org/abs/1104.2823v1
- http://arxiv.org/abs/1104.2827v1
- http://iopscience.iop.org/0004-637X/654/1/570/
- http://solstation.com/stars2/wd0806-6.htm
- http://adsabs.harvard.edu/abs/2009AJ....137.4547S


Luigi C.
