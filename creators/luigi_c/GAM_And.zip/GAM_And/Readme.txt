
Simply unzip this zip file into your extras or Addons directory.

This add-on is a replacement for the GAM And model given with the Celestia 
1.6.1 distribution; it provides data for all four components of the star 
system.

Rev. 1.0 - 01/01/2012

References:
- Sixth Catalog of Orbits of Visual Binary Stars (http://ad.usno.navy.mil/wds/orb6.html)
- http://en.wikipedia.org/wiki/Gamma_Andromedae
- http://it.wikipedia.org/wiki/Gamma_Andromedae

Luigi C.
