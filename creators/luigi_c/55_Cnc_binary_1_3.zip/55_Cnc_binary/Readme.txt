
Simply unzip this zip file into your extras or Addons directory.  

This add-on contains data to update the Celestia default Rho1 Cnc system to a binary system:
RHO1 Cnc A
RHO1 Cnc B

The definition of the barycenter RHO1 Cnc replaces the old star definition.
The definitions of the RHO1 Cnc exoplanets now refer to the A star.
The values of mass and radius of the planet 'e' have been corrected.

Rev. 1.3 - 08/06/2011
Updated data according to http://exoplanet.eu/catalog.php, 08/06/2011.

References:
- http://en.wikipedia.org/wiki/55_Cancri
- http://stars.astro.illinois.edu/sow/55cnc.html
- http://exoplanet.eu/catalog-all.php .


Luigi C.
