Extract in "../extras/" folder.
If you have the "Earth_Geology" add-on, you can collect the textures under its "../MAPS/" folder.

For advanced graphic cards, the pack has also the 8k png layers.
You can copy/paste the "st_8k.png" over YOUR favorite 8k Earth' texture and 
then save it as "st.png". 

--------------------------------------------------------------------------------------------------
How to merge the ST 8k normalmap together with YOUR favorite 8k Earth's normalmap:
 
- Open in a graphic editor the 2 textures and copy/paste YOUR Earth's 8k normalmap within the 
  8k sediment thickness normalmap ("st_normal_8k.png");
- Shift the 8k Earth's normalmap layer below the ST 8k normalmap
- Set the 8k ST normalmap layer with the propriety "lighten" or "overlay"
- Make an unique layer (background) and save the image as "st_normal.png"
 
 -------------------------------------------------------------------------------------------------
 The dataset on which the textures are built comes from here:
 http://www.ngdc.noaa.gov/mgg/sedthick/sedthick.html
 
 Colors have been assigned through discrete steps of the legend's numeric subdivisions.
 White areas are not available data (NaN)