There are "fake" models made for showing both locations (volcanoes, etopo and minerals for the commons scripts)
and for the featured users' pictures through either the LUA PLUGINS or the LUA EDU TOOLS (earth_geology).
Pictures script isn't available in celx default method.

When the geologic's image button is pressed, its name will be displayed in the HUD and the pictureBox's
plug-in will shows the image(s). In the case you have the LUATOOLS instead, will be
activated the use of the moreInfo checkbox.

Note that for what concern the images, the LUA PLUGINS and the LUA EDU TOOLS extensions are mutually elusive.
For this purpose the ways to follow in setting the images are differents.

---------------------------------------------------------------------------------------------------
LUA PLUGINS case (default):

1) extract the file "images.zip" (there is one image in the pack, just for "ready to start") 
onto the "../lua_plugins/images/" folder;
2) backup the file "pictureBox.lua" within the "../lua_plugins/celxx/" folder and move in it the
new "pictureBox.lua" which you find in the zip. This file is the same of the default one with only
two modifications:
- the entry of the "earth_geology" as "objectname";
- the change of the image's extension from ".jpg" to ".png". This changing prevent the JPG images
to be displayed unless converted. 

---------------------------------------------------------------------------------------------------
LUA EDU TOOLS case (most easy to achieve):

1) do comment the line: require "pictureBox"; within the "config_geo_tools" as:
 
-- require "pictureBox"; (note the two hypens)

2) extract the "images.zip" onto the "../lua_edu_tools/images/" folder;
3) open the file "infoImage.lua" (it is within the "../lua_edu_tools/infos/" folder) with an editor and add 
the strings below, relevant to your custom geologic images:

infoImage =
{
    -- Image filenames for the geologic add-on:
    
	Earth_Geology = -- this name must be the same of the .SSC for the "fake" model  
    {
	  
        "../images/earth_geology/earth_geology_1.png";
        "../images/earth_geology/earth_geology_2.png";
        "../images/earth_geology/earth_geology_3.png";
        "../images/earth_geology/earth_geology_4.png";
		
		--
		--
		
    };


