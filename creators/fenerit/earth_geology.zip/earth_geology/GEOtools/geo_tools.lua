require "config_geo_tools";
require "geo_func";

local geo_function = {}

-----------------------------------------------------------
-- GEOtools interface
-- functions called by the tool buttons must be:
-- geo_function[1], geo_function[2] etc...
-- you can also require other tools...
-----------------------------------------------------------

-- button 1 function
geo_function[1] = function() -- get volcanoes from geo_func.lua

	get_volcanoes(obs);
	
end

-- button 2 function
geo_function[2] = function() -- get earthquakes from geo_func.lua

	get_earthquakes(obs);
	
end

-- button 3 function
geo_function[3] = function() -- get earthquakes from geo_func.lua

	get_seismic_hazard(obs);
	
end

-- button 4 function
geo_function[4] = function() -- get tectonic plates - ridges - trenches from geo_func.lua

	get_tectonics(obs);
	
end

-- button 5 function
geo_function[5] = function() -- get LIPs from geo_func.lua

	get_lips(obs);

end

-- button 6 function
geo_function[6] = function() -- get geologic provinces from geo_func.lua

	get_gp(obs);

end

-- button 7 function
geo_function[7] = function() -- get isocrons from geo_func.lua

	get_isochrons(obs);

end

-- button 8 function
geo_function[8] = function() -- get etopo from geo_func.lua

	get_etopo(obs);

end

-- button 9 function
geo_function[9] = function() -- get minerals from geo_func.lua

	get_minerals(obs);

end

-- button 10 function
geo_function[10] = function() -- get minerals from geo_func.lua

	get_world_countries(obs);

end

-- button 11 function
geo_function[11] = function() -- get pictures from geo_func.lua

	get_pictures(obs);

end

----------------------------------------------
--  GEOtools initialization
----------------------------------------------
local display_geo_tools = false -- whatever enable_plugin["geo_tools"] is
local allow_geo_tools =  false
local width, height = celestia:getscreendimension()
local oldwidth, oldheight
local geo_toolX, geo_toolY
--local cslide = {0.2, 0.2, 0.2, 1}

-- command tool description
local nbButtons = # geo_function
local biColor = {0.52, 0.52, 0.52, 0.0} -- button's color
local beColor = {0.7, 0.7, 1.0, 0.0} -- tool's border color
local btSize = 24 -- default size
if type(RemoteControlButtonSize) == "number" then btSize=RemoteControlButtonSize end

local btMarg = btSize / 16; -- space between buttons
local topbutmarg = math.max(btSize / 16)
local geo_toolHeight = btSize + topbutmarg + btMarg
local geo_toolWidth = btSize * nbButtons + (nbButtons + 6) * btMarg -- 6 = margin for catching the tools

----------------------------------------------
-- Set up main boxes
----------------------------------------------
geo_tools = CXBox:new()
    :init(0, 0, 0, 0)
    :movable(false)
    :attach(screenBox, width, height, 0, 0)

if lua_edu_tools then
	geo_toolsCheck = CXBox:new()
	:init(0, 0, 0, 0)
	:bordercolor(cbubordoff)
	:textfont(normalfont)
	:textcolor(cbutextoff)
	:textpos("center")
	:movetext(0, 9)
	:text("")
	:movable(false)
	:active(true)
	:attach(geo_tools, boxWidth - 40, 4, 29, 5)
end

geo_toolFrame = CXBox:new()
    :init(0, 0, 0, 0)
    :bordercolor(beColor)
--	:fillcolor({0.7, 0.7, 1.0, 0.1}) -- tool's inner color
	:movable(true)
    :active(false)
    :clickable(false)
    :visible(display_geo_tools)
    :attach(screenBox, 0, 0, 0, 0)

local replace_geoTool = function()
	if (geo_toolWidth + 6 <= width) and (geo_toolHeight + 6 <= height) then
		allow_geo_tools = true
		if geo_toolX < 3 then geo_toolX = 3 end
		if geo_toolX + geo_toolWidth + 3 > width then geo_toolX = width - geo_toolWidth - 3 end
		if geo_toolY < 3 then geo_toolY = 3 end
		if geo_toolY + geo_toolHeight + 3 > height then geo_toolY = height - geo_toolHeight - 3 end
		geo_toolFrame:attach(screenBox, geo_toolX, geo_toolY,
			width - geo_toolWidth - geo_toolX, height - geo_toolHeight - geo_toolY)
		geo_toolFrame:orderfront()
	else
		allow_geo_tools = false
	end
end

local toggleDisplay = function ()
	if nbButtons > 0 then
		display_geo_tools = not display_geo_tools;
		if display_geo_tools then
			geo_toolX = (width - geo_toolWidth) / 2
			geo_toolY = 2	
			replace_geoTool()
		end
	else
		celestia:print("You must define at least one function", 5)
	end
end

----------------------------------------------
-- boxes functions
----------------------------------------------

geo_tools.Customdraw = function(this)
	if lua_edu_tools then
		textlayout:setfont(normalfont);
		textlayout:setfontcolor(ctext); -- default LUATOOLS white text color
	--	textlayout:setfontcolor(cslide);
		textlayout:setpos(this.lb + 25, this.tb - 14);
		textlayout:println("GEO tools");
	end
	if display_geo_tools then
		oldwidth, oldheight = width, height
		width, height = celestia:getscreendimension()
		if oldwidth ~= width or oldheight ~= height then
			replace_geoTool()
		end
	end
	geo_toolFrame.Visible = display_geo_tools and allow_geo_tools
end

if lua_edu_tools then
	geo_toolsCheck.Action = function()
	toggleDisplay()
		if display_geo_tools then
			geo_toolsCheck.Text = "x"
		else
			geo_toolsCheck.Text = ""
		end
	end
end

geo_toolFrame.Customdraw = function(this)
	geo_toolX = geo_toolFrame.la
	geo_toolY = geo_toolFrame.ba
end

-- tool command buttons
local buttons = {}
local imgbut = {}

for i = 1, nbButtons do
	if geotool_buttons_icons[i] then
		imgbut[i] = celestia:loadtexture("icons/"..geotool_buttons_icons[i])
	end
end

local createButton = function(order)
	return
		CXBox:new()
		--:fillimage(imgbut[order])
		:bordercolor(biColor)
		:movable(false)
		:active(true)
		:clickable(false)
		:visible(true)
		:attach(geo_toolFrame,
			btMarg * order + btSize * (order - 1),
			btMarg,
			geo_toolWidth - btMarg * order - btSize * order ,
			topbutmarg )
end

for i = 1, nbButtons do
	buttons[i] = createButton(i)
	if imgbut[i] then
		buttons[i]:fillimage(imgbut[i])
	end
		if  geo_function[i] then
			buttons[i].Action = geo_function[i]
		else
			buttons[i].Action = function()
		return
			celestia:print("You must define geo_function["..i.."]", 5)
		end
	end
end

local shortcut = geo_tools_shortcut or "x"
	if lua_edu_tools then
		keymap[shortcut] = geo_toolsCheck.Action
	else
		keymap[shortcut] = toggleDisplay
	end
celestia:log("-- geo_tools --")
