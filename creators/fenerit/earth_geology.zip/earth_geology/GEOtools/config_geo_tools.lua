-- GEOtools configuration file

----------------------------------------
-- UNCOMMENT below whether you have the LUA_PLUGINS installed
-- COMMENT below whether you have the LUA_EDU_TOOLS installed
----------------------------------------
require "pictureBox";

----------------------------------------
-- key shorcut to enable the GEOtools
-- default key shorcut is "z"
----------------------------------------
geo_tools_shortcut = "z"

-------------------------------------
-- tool device
-------------------------------------
RemoteControlButtonSize = 32

------------------------------------------
-- definitions of images for the GEOtools device
-- if more images than functions(buttons),
-- the last images will be ignored
-- if less images than buttons, some buttons
-- will have no icon but will work anyway
-------------------------------------------

geotool_buttons_icons = {
	"volc.png",
	"eq.png",
	"sh.png",
	"tp.png",
	"lips.png",
	"gp.png",
	"ic.png",
	"elev.png",
	"min.png",
	"wc.png",
	"img.png",
	"b10.png",
	"b11.png",
	"b12.png",
		
}
