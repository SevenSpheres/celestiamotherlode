-- GEOtools functions
-- Put here your private variables and functions for the tool buttons
-- in order to run friendly with other plug-ins
-- YOUR variables and functions must be declared as "local"
-----------------------------------------------------------

 celestia:setlabelflags{locations = true}

-----------------------------------------------------------
--	function for volcanoes
-----------------------------------------------------------
get_volcanoes = function(obs)

	local volcanoes = {"Sol/Earth/Volcanoes"} -- fake model

	local obs = celestia:getobserver()
	
	for k, object in pairs(volcanoes) do
		obj_volcanoes = celestia:find(object)
		obj_volcanoes:setvisible(not obj_volcanoes:visible()) 
	end
	
	if obj_volcanoes:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
		obs:setlocationflags{mons = true, mare = true}
	else
		obs:setlocationflags{mons = false, mare = false}
	end
end

-----------------------------------------------------------
--	function for earthquakes
-----------------------------------------------------------
get_earthquakes = function(obs)

	local earthquakes = {
	
		"Sol/Earth/Earthquakes (0-70 km)",
		"Sol/Earth/Earthquakes (71-300 km)",
		"Sol/Earth/Earthquakes (301-700 km)"
	
	}

	local obs = celestia:getobserver()
	
	for k, object in pairs(earthquakes) do
		obj_earthquakes = celestia:find(object)
		obj_earthquakes:setvisible(not obj_earthquakes:visible()) 
	end
	
	if obj_earthquakes:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
	end
end

-----------------------------------------------------------
--	function for seismic hazard
-----------------------------------------------------------
get_seismic_hazard = function(obs)

	local sh = {"Sol/Earth/Seismic hazard"}
	
	local obs = celestia:getobserver()
	
	for k, object in pairs(sh) do
		obj_sh = celestia:find(object)
		obj_sh:setvisible(not obj_sh:visible()) 
	end
	
	local gp = {"Sol/Earth/Geologic Provinces"}
	
	for k, object in pairs(gp) do
		obj_gp = celestia:find(object)
		obj_gp:setvisible(false) 
	end
	
	local isochrons = {"Sol/Earth/Isochrons"}
	
	for k, object in pairs(isochrons) do
		obj_isochrons = celestia:find(object)
		obj_isochrons:setvisible(false) 
	end
	
	if obj_sh:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:getobserver():setsurface("Seismic hazard")
		celestia:setminfeaturesize(20)
		obs:setlocationflags{reticulum = false}
		obs:setlocationflags{tessera = false}
	else
		celestia:getobserver():setsurface("")
	end
end

-----------------------------------------------------------
--	function for tectonic plates - ridges - trenches
-----------------------------------------------------------
get_tectonics = function(obs)

	local tectonics = {
	
		"Sol/Earth/Plates",
		"Sol/Earth/Faults",
		"Sol/Earth/Trenches",
		"Sol/Earth/Extinct ridges"
			
	}

	local obs = celestia:getobserver()
	
	for k, object in pairs(tectonics) do
		obj_tectonics = celestia:find(object)
		obj_tectonics:setvisible(not obj_tectonics:visible()) 
	end
	
	if obj_tectonics:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
		obs:setlocationflags{dorsum = true,	fossa = true}
	else
		obs:setlocationflags{dorsum = false, fossa = false}
	end
end

-----------------------------------------------------------
--	function for LIPs (Large Igneous Provinces)
-----------------------------------------------------------
get_lips = function(obs)

	local lips = {"Sol/Earth/Lips"}

	local obs = celestia:getobserver()
	
	for k, object in pairs(lips) do
		obj_lips = celestia:find(object)
		obj_lips:setvisible(not obj_lips:visible()) 
	end
	
	if obj_lips:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
		obs:setlocationflags{planum = true}
	else
		obs:setlocationflags{planum = false}
	end
end

-----------------------------------------------------------
--	function for geologic provinces
-----------------------------------------------------------
get_gp = function(obs)

	local gp = {"Sol/Earth/Geologic Provinces"}
	
	local obs = celestia:getobserver()
	
	for k, object in pairs(gp) do
		obj_gp = celestia:find(object)
		obj_gp:setvisible(not obj_gp:visible()) 
	end
	
	local sh = {"Sol/Earth/Seismic hazard"}
	
	for k, object in pairs(sh) do
		obj_sh = celestia:find(object)
		obj_sh:setvisible(false) 
	end
	
	local isochrons = {"Sol/Earth/Isochrons"}
	
	for k, object in pairs(isochrons) do
		obj_isochrons = celestia:find(object)
		obj_isochrons:setvisible(false) 
	end
	
	if obj_gp:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:getobserver():setsurface("wpa")
		celestia:setminfeaturesize(20)
		obs:setlocationflags{reticulum = false}
		obs:setlocationflags{tessera = true}
	else
		celestia:getobserver():setsurface("")
		obs:setlocationflags{tessera = false}
	end
end

-----------------------------------------------------------
--	function for isochrons
-----------------------------------------------------------
get_isochrons = function(obs)

	local isochrons = {"Sol/Earth/Isochrons"}

	local obs = celestia:getobserver()
	
	for k, object in pairs(isochrons) do
		obj_isochrons = celestia:find(object)
		obj_isochrons:setvisible(not obj_isochrons:visible()) 
	end
	
	local sh = {"Sol/Earth/Seismic hazard"}
	
	for k, object in pairs(sh) do
		obj_sh = celestia:find(object)
		obj_sh:setvisible(false) 
	end
	
	local gp = {"Sol/Earth/Geologic Provinces"}
	
	for k, object in pairs(gp) do
		obj_gp = celestia:find(object)
		obj_gp:setvisible(false) 
	end
	
	local wc = {"Sol/Earth/World countries","Sol/Earth/Rivers"}
	
	for k, object in pairs(wc) do
		obj_wc = celestia:find(object)
		obj_wc:setvisible(false) 
	end
	
	if obj_isochrons:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:getobserver():setsurface("Isochrons")
		celestia:setminfeaturesize(20)
		obs:setlocationflags{tessera = false}
		obs:setlocationflags{terra = false}
		obs:setlocationflags{reticulum = true}
	else
		celestia:getobserver():setsurface("")
		obs:setlocationflags{reticulum = false}
	end
end

-----------------------------------------------------------
--	function for ETOPO (elevations)
-----------------------------------------------------------
get_etopo = function(obs)

	local etopo = {"Sol/Earth/Etopo"} -- fake model
	
	local obs = celestia:getobserver()
	
	for k, object in pairs(etopo) do
		obj_etopo = celestia:find(object)
		obj_etopo:setvisible(not obj_etopo:visible()) 
	end
	
	if obj_etopo:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
		obs:setlocationflags{linea = true}
		celestia:print("Elevations enabled", 0.9)
	else
		obs:setlocationflags{linea = false}
		celestia:print("Elevations disabled", 0.9)
	end
end

-----------------------------------------------------------
--	function for minerals
-----------------------------------------------------------
get_minerals = function(obs)

	local minerals = {"Sol/Earth/Minerals"} -- fake model
	
	local obs = celestia:getobserver()
	
	for k, object in pairs(minerals) do
		obj_minerals = celestia:find(object)
		obj_minerals:setvisible(not obj_minerals:visible()) 
	end
	
	if obj_minerals:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
		obs:setlocationflags{rupes = true}
		celestia:print("Minerals enabled", 0.9)
	else
		obs:setlocationflags{rupes = false}
		celestia:print("Minerals disabled", 0.9)
	end
end

-----------------------------------------------------------
--	function for world countries
-----------------------------------------------------------
get_world_countries = function(obs)

	local wc = {"Sol/Earth/World countries","Sol/Earth/Rivers"}
		
	local obs = celestia:getobserver()

	for k, object in pairs(wc) do
		obj_wc = celestia:find(object)
		obj_wc:setvisible(not obj_wc:visible()) 
	end
	
	local isochrons = {"Sol/Earth/Isochrons"}

	for k, object in pairs(isochrons) do
		obj_isochrons = celestia:find(object)
		obj_isochrons:setvisible(false) 
	end
	
	if obj_wc:visible() then
		celestia:setrenderflags{cloudmaps = false}
		celestia:setminfeaturesize(20)
		celestia:getobserver():setsurface("World countries")
		obs:setlocationflags{reticulum = false}
		obs:setlocationflags{terra = true}
	else
		celestia:getobserver():setsurface("")
		obs:setlocationflags{terra = false}
	end
end

-----------------------------------------------------------
--	function for pictures display
-----------------------------------------------------------
get_pictures = function(obs)

	local pictures = {"Sol/Earth/Earth_Geology"} -- fake model for images
	
	local obs = celestia:getobserver()
	
	for k, object in pairs(pictures) do
		obj_pictures = celestia:find(object)
		obj_pictures:setvisible(not obj_pictures:visible()) 
	end
	
-- 	check whether LUA EDU TOOLS are in the system and allow the use of moreInfo
	if lua_edu_tools then 	
		celestia:print("Pictures enabled", 0.9)
		local earth_geology = celestia:find("Sol/Earth/Earth_Geology")
		local earth_geology_select = celestia:select(earth_geology)
		obj_pictures:visible()
-- 	check whether LUA PLUG-INS are in the system and load the pictureBox plug-in
	else 					
		if	obj_pictures:visible() then
			local earth_geology = celestia:find("Sol/Earth/Earth_Geology")
			local earth_geology_select = celestia:select(earth_geology)
			pictureFrame.Visible = true;
		else
			pictureFrame.Visible = false;
			local earth = celestia:find("Sol/Earth")
			local earth_select = celestia:select(earth)
		end
	end
end
