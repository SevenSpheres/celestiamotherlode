Apart the features's layers, the textures specified with the "earth_geology_" prefix can be and MUST be replaced
with the your favorite ones. Note that, in deal with altsurface maps, isn't required to copy/move here your textures
from the Celestia's textures folder. These PNG layers can be "intermixed/overlaid" as you wish.
Note that the "OverlayTexture" directive doesn't allow the use of the "NightTexture".

8k layers are for graphic cards which support it.
 