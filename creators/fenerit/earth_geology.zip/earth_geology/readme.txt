Earth's Geology add-on ver. 1.2 for Celestia 1.6.1 - Author: Fenerit <fenerit@interfree.it>

HOW TO INSTALL (standard use):
- Remove the former version if any;
- Extract the zip onto the Celestia's "../extras" folder
- In the "../earth_geology/scripts/" folder there are several CELX scripts for
	activating/deactivating the features.

This add-on can be managed through celx scripts as well as through a LUA toolbar (GEOtools).
Users which doesn't have the LUA hook installed, simply can ignore the GEOtools.
As it is the add-on is fully functional through scripts and doesn't require user's settings.
Instead, for LUATOOLS/LUA PLUGINS users, some manual intervenings are necessary (see futher).  

CHANGES FROM 1.1
- collected plates, faults, trenches and extinct ridges under the same folder ("../earth_geology/tectonics")
- changed colors to the hotspots and to the LIPs' locations text;
- added world's seismic hazard (CMOD and map);
- added world's geologic provinces with petroleum assessment (CMOD and map);
- added world countries with major rivers (CMOD and map)
- refined and improved isochrons (CMOD, locations and map)

All textures and layers are 4k in size but for these latters there are also the 8k version.

-------------------------------------------------------------------------------------------
LUA PLUGINS and LUA EDU TOOLS USERS:
-------------------------------------------------------------------------------------------
- The folder "../earth_geology/GEOtools/" contains an icon bar as plug-in for managing the add-on.
- Lua_plugins users must add to the "config.lua" of the plug-ins:

	plugins =
    {
		"compassBox",
		"KeplerParamBox",
		"coordinateBox",
		"pictureBox",
		"HRBox",
		"slideshow",
		"cmod_tracer", 	
		"geo_tools", -- string to add
		-- ephemerides group
		"ephemerisBox",
		"moonBox",
		"sunposBox",
		"constBox",
		"meteorBox",
   }

- Lua_edu_tools users must add to the "config.lua" of the lua_edu_tools:

	toolset =
    {
    	"timeBox",
       	"lightBox",
       	"magnitudeBox",
       	"galaxyLightBox",
       	"renderBox",
       	"obsModeBox",
       	"solarSystemBox",
       	"fovBox",
       	"addsBox",
       	"infoBox",
       	"coordinatesBox",
       	"distanceBox",
       	"magnificationBox",
       	"HRBox",
       	"KeplerParamBox",
      	"virtualPadBox",
		"cmod_tracer",	
		"geo_tools", -- string to add
        "compassBox",
    }

The presence of the GEOtools doesn't interfere with the standard use.

------------------------------------------------------------------------------------------------------
There are "fake" models made for showing both locations (volcanoes, etopo and minerals) for the scripts
and for the featured users' pictures through either the LUA PLUGINS or the LUA EDU TOOLS (earth_geology).

When the geologic's image button is pressed, the name of the add-on will be selected in the HUD 
and the pictureBox's plug-in will show the image(s). In the case you have the LUATOOLS instead, will be
activated the use of the moreInfo.

Note that for what concern the images, the LUA PLUGINS and the LUA EDU TOOLS extensions are mutually elusive.
For this purpose the ways to follow in setting the images are differents.

---------------------------------------------------------------------------------------------------
LUA PLUGINS case (default):

1) extract the file "images.zip" (there is one image in the pack, but you can add your customs) 
onto the "../lua_plugins/images/" folder - be sure to respect the shipped path "Earth_Geology";

2) backup the file "pictureBox.lua" within the "../lua_plugins/celxx/" folder and move in it the
new "pictureBox.lua" which is within the zip. This file is the same of the default one with only
two modifications:
- the entry of the "earth_geology" as "objectname_t";
- the change of the image's extension from ".jpg" to ".png". Note that this changing will prevent
the JPG images to be displayed unless converted in PNG. 

---------------------------------------------------------------------------------------------------
LUA EDU TOOLS case (more easy to achieve):

1) do comment the line: require "pictureBox"; within the "config_geo_tools" as:
 
-- require "pictureBox";

2) extract the "images.zip" onto the "../lua_edu_tools/images/" folder;
3) delete or backup the file "pictureBox.lua" which is in the zip;
4) open the file "infoImage.lua" (within the "../lua_edu_tools/infos/" folder) in an editor and add 
the strings below, relevant to your custom geologic images:


    -- Image filenames for the geologic add-on:
    
	Earth_Geology = -- this name is the same of the .SSC's directive for the "fake" model  
    {
	  
        "../images/Earth_Geology/earth_geology_1.png";
        "../images/Earth_Geology/earth_geology_2.png";
        "../images/Earth_Geology/earth_geology_3.png";
        "../images/Earth_Geology/earth_geology_4.png";
		
		--
		--
		
    };

---------------------------------------------------------------------------------------------------

In both methods (celx scripting and LUA hook) features are interactive. Users can customize their
behaviours through functions.

WEB LINKS:
USGS geologic provinces and world petroleum assessment: 
http://energy.cr.usgs.gov/oilgas/wep/products/dds60/export.htm

ocean floor isochrones and extinted ridges:
http://www.earthbyte.org/Research/Current/digit_isochrons.html#anchorFTP

World countries, LIPs and hotspots:
http://www.ig.utexas.edu/research/projects/lips/index.htm

3.6 ages(2008), error and spreading rates:
http://www.ngdc.noaa.gov/mgg/ocean_age/ocean_age_2008.html

1964-2010 earthquakes:
http://www.isc.ac.uk/EHB/index.html
http://earthquake.usgs.gov/research/data/iss_summ.php

plate's velocity (long,lat,height) in mm/y:
http://sideshow.jpl.nasa.gov/mbh/series.html

World's settlements:
http://sedac.ciesin.columbia.edu/gpw/global.jsp#

other data:
http://geodata.grid.unep.ch/

ACKNOWLEDGEMENTS:

Jogad, for its "devtool" template on which the GEOtools is based upon;
Cham, for its "tectonic plates" model, volcanoes and political borders' locations files;
Maxim, for its "subsea structure" locations file.










