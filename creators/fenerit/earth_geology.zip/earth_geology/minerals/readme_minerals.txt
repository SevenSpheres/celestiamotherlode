Earth's minerals/industries add-on. USGS dataset.

SYMBOLS:
Au/Ag (yellow) = precious elements;
PGE (cyan) = Platinum Group Elements, also referrings as PGM, Platinum Group Metals (Pt/Pd/Os/Ir/Rh/Ru);
U (magenta) = fissionables;
REE (maroon) = Rare Earths Elements (La/Ce/Pr/Nd/Pm/Sm/Eu/Gd/Tb/Dy/Ho/Er/Tm/Yb/Lu);
C (gray) = graphite;

Ax (white) = amethyst;
Dx (white) = diamond;
Ex (white) = emerald;
Jx (white) = jade;
Sx (white) = sapphire;
Rx (white) = ruby;
Tq (white) = turquoise;
Tx (white) = topaz;

gems (white) = other precious/semiprecious gemstone;
Qz (white) = quarz;

* (yellow) = Au/Ag occurrences;
* (cyan) = Pt/PGE occurrences;
* (magenta) = fissionables occurrences;
* (maroon) = REE occurrences;
* (white) = gems occurrences;
* (gray) = graphite occurrences;

Al = producer, mine (all types), first produced commodity;
Al-Mn = producer, mine (all types), either first or first-second produced commodity;
Al-Mn-Fe = producer, mine (all types), either first or first-second-third produced commodity;
Al<Se> = producer, mine (all types), first-<n-commodity>, very secondary produced commodity;
<Se> = producer, mine (all types), very secondary produced commodity;

(Al) = producer, mine/plant, plant (all types), first produced commodity;
(Al-Mn) = producer, mine/plant, plant (all types), either first or first-second produced commodity;
(Al-Mn-Fe) = producer, mine/plant, plant (all types), either first or first-second-third produced commodity;
(Al<Se>) = producer, mine/plant, plant (all types), first-<n-commodity>, very secondary produced commodity;
(<Se>) = producer, mine/plant, plant (all types), very secondary produced commodity;

[Al] = plant, processing plant only (all types), first processed commodity;
[Al-Mn] = plant, processing plant only (all types), either first or first-second processed commodity;
[Al-Mn-Fe] = plant, processing plant only (all types), either first or first-second-third processed commodity;
[Al<Se>] = plant, processing plant only (all types), first-<n-commodity>, very secondary processed commodity;
[<Se>] = plant, processing plant only (all types), very secondary processed commodity;

--------------------------------------------------------------------------------------------------------------------------------------------------
ADVANTAGES:
- Fast and smooth, no performances reduction.

LIMITATIONS:
- Periodic table fashioned, no compounds;
- Many commodities are absents (no enough symbols: stone(?), crushed stone(?), limestone(?) cement(?), etc.)
- No prospect sites;
- No past-productions;
- Several countries lacks of actual data, just either past-productions or occurrences;
- Cote d'Ivoire seem "censored"; a threatening warning appear when one try to download the dataset; 

----------------------------------------------------------------------------------------------------------------

