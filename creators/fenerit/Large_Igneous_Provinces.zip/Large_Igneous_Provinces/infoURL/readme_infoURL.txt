Note for infoURLs

Put your PDF document here and add the following line within the lips.ssc file:

 InfoURL "/infoURL/name_of_your_document.pdf" 