How to assign to the image the same diaporama position of other Fenerit's images :

left margin = cretaceous 	(do not move text layer left or right)
right margin = temporal... 	(do not move text layer left or right)
top margin = correlation... 	( do not move text layer up or down)
bottom margin = % extinction...	( do not move text layer up or down)

translate texts

unify all layers but background (remove or hide)

main layer > select all > copy > new (2048x2048px transparent) > paste > save as *.png