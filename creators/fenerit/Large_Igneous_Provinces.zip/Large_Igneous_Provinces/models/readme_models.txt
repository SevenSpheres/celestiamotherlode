Models are in binary format.

In order to change colors, models must be converted in ASCII format.

1 Start 3dstoCMOD utility
2 select one model  
3 select "Fix" radiobutton
4 select Output as ASCII
5 press Process Model button

Repeat the steps (1-5) above for all models. 

Now models are text editable within a notepad. 
Change colors and/or transparency, save, repeat the steps 1-3 above, select Output as Binary and press Process Model Button. 
Now your file has been converted in binary again (binary is more fast to load and light in size).

Repeat the procedure for all models.
Be sure of to be text errors free and DO NOT select others Fixing Parameters.   

#######################################################################

From command line:

cmodfix [options] [input cmod file [output cmod file]]

Example BIN to ASCII:
cmodfix -a your_BIN_file.cmod your_ASCII_file.cmod 

Example ASCII to BIN:
cmodfix -b your_ASCII_file.cmod your_BIN_file.cmod 

For further options see LicenseInfo.txt

########################################################################
