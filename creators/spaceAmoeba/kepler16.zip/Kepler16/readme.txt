Kepler-16 binary system with circumbinary exoplanet.

Description: Binary system includes two main sequence stars (K and M class) and an exoplanet with mass similar to Saturn. Parameters used for simulation are based on available data and educated guesses except where noted in comments (e.g. rotation of planet is made up).

Installation: Unpack directory into "extras" folder of "celestia" folder.

Source: "Kepler-16: A Transiting Circumbinary Planet", Doyle et al.

Justin Lowry (SpaceAmoeba)
justin@scientist.com
