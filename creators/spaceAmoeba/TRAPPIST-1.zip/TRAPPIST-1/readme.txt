TRAPPIST-1 system with seven Earth-sized exoplanets.

Description: TRAPPIST-1 is an ultracool dwarf (M8V spectral type) with seven exoplanets in very small orbits (all <<1 AU from the star). Three of the exoplanets (e, f, and g) have effective temperatures that place them in the habitable zone. 

Installation: Unpack directory into "extras" folder of "celestia" folder.

Notes: All seven exoplanets are presented tidally-locked in this add-on as is expected (but not known for certain). The ascending node was arbitrarily chosen since it remains unknown, therefore the exact orientation of the system is likely incorrect (though the inclination of the system should be correct). Also, obviously albedos and textures are purely imagined.

This add-on is free for any use with attribution.

Justin Lowry (SpaceAmoeba)
justin@cosmographer.net
