This package is based on the Transhuman Space hard science fiction role-playing game from Steve Jackson Games. (See http://www.sjgames.com/transhuman/) It was created around 2003 by Larry Lade, and updated for Celestia 1.4 in March 2007.

Requirements: A system that can run Celestia 1.4.1, and an OpenGL accelerator that supports DDS textures. (i.e. Nvidia GeForce) My setup is pretty ancient now, so this should work on all modern hardware. I have only tested this setup on Windows. (I'm hoping to make it Linux-friendly, but my Linux version of Celestia seems less friendly to custom content than Windows.)

Install this package to THE BASE DIRECTORY of a fresh installation of Celestia 1.4.1. Due to the changes made, it is not simply a modular add-on. It must overwrite a number of the basic Celestia files with fictitious data. So make a back-up copy of your existing Celestia folder!

I recommend you press "shift-R" right away to enjoy the high-res Mars textures.

This work is incomplete. There is a lot left to do to portray all the spaceborne bodies described in the Transhuman Space books. See the TODO file in the extras\addons\Transhuman folder for details. If you'd like to contribute, contact me at <larry.p.lade@gmail.com>!

Also, while much of this is my own work, I have forgotten the sources I used for some of the data. If you see your textures or orbital elements, please contact me so I can give you credit!

Credits:
*Celestia team (of course!)
*Steve Jackson Games (David Pulver et al.) - Transhuman Space setting
*NASA JPL HORIZONS database for orbital elements data
*??? for the high-res Mars altitude map, used to create the bumpmap and to  "flood" the bodies of water
*??? for the high-res Mars texture, used to create my Mars textures
*??? for the gravity-adjusted Jovian Trojan orbital elements
*Thomas Guilpain for the space elevator files (not yet implemented)

Larry Lade
2007-03-15