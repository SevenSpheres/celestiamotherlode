4k relastic Jupiter from speedyspacebike
Copy (or move) the folder called 4k J to your extras folder
NOTE:This addon may not work with all computers.
Recomended for computers that have a high resolution graphic card.
Texture in jpg

Have Fun:-))))