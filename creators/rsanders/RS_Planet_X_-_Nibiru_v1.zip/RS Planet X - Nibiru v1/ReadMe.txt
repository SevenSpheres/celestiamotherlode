ROB SANDERS PRODUCTIONS � 2008 by Rob Sanders. All Rights reserved.

RS Planet X - Nibiru System version 1.

Name:

RS Planet X - Nibiru v1.zip

Description:

Hypothetical planet orbiting our sun. (Planet X, Nibiru, Planet of the Crossing.)

Requirements:

Celestia version 1.5.0 or higher.

Installation:

Unzip the files and place the RS Planet X - Nibiru folder in your celestia extra folder.
Start Celestia go to the solarsystem browser and select Planet X to view the system.

Note: 

These files are fictional, and do not represent the real Planet X and/or Nibiru.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/