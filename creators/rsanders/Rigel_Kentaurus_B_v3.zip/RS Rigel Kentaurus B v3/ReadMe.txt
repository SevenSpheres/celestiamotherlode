ROB SANDERS PRODUCTIONS � 2005 by Rob Sanders. All Rights reserved.

RS Rigel Kentaurus B System version 3.

Name:

RS Rigel Kentaurus B v3.zip

Description:

Fictional planetary system for Celestia based around Rigel Kentaurus B aka Alpha Centauri B.

Requirements:

Celestia version 1.3.2 or higher.

Installation:

Unzip the files and place the RS Rigel Kentaurus B folder in your celestia extra folder.
Start Celestia go to the star browser and select Rigel Kentaurus B to view the system.

Note: 

These files are fictional, and do not represent the real Rigel Kentaurus B System.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Changelog:

Rigel Kentaurus B Version 3.

- Complete rebuild of the planet Hawking.
- Added specular texture for the planet Witten.
- Some minor .ssc improvements.

Rigel Kentaurus B Version 2.

- Added new textures and bumpmap for the planet Daniken.
- Added new textures and bumpmap for the moon Newton.
- Complete rebuild of the planet Neumann.
- Complete rebuild of the planet Einstein and its moons.
- Added atmosphere to the planet Darwin.
- Added a small moon orbiting the planet Witten.
- Added two small moons orbiting the planet Einstein.
- Fixed planets obliquity settings.
- Added new celurl`s.
- Some minor texture improvements.
- Some minor .ssc improvements.

Rigel Kentaurus B Version 1.

- Release version.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/