ROB SANDERS PRODUCTIONS � 2005 by Rob Sanders. All Rights reserved.

RS Beta Hydri System version 2.

Name:

RS Beta Hydri v2.zip

Description:

Fictional Solarsystem for Celestia based around Beta Hydri.

Requirements:

Celestia version 1.3.2 or higher.

Installation:

Unzip the files and place the RS Beta Hydri folder in your celestia extra folder.
Start Celestia go to the star browser and select Beta Hydri to view the system.

Note: 

These files are fictional, and do not represent the real Beta Hydri System.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Changelog:

Beta Hydri Version 2.

- Added a small moon orbiting the planet Marduk.
- Added atmosphere for the moon Yukatan.
- Complete rebuild of the moon Ninurta.
- New texture and bumpmap added for planet Veleda.
- Fixed planets obliquity settings.
- Added new celurl`s.
- Some minor texture improvements.
- Some minor .ssc improvements.

Beta Hydri Version 1.

- Release version.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/