ROB SANDERS PRODUCTIONS � 2005 by Rob Sanders. All Rights reserved.

RS Rigel Kentaurus A System version 3.

Name:

RS Rigel Kentaurus A v3.zip

Description:

Fictional planetary system for Celestia, based around Rigel Kentaurus A aka Alpha Centauri A.

Requirements:

Celestia version 1.3.2 or higher.

Installation:

Unzip the files and place the RS Rigel Kentaurus A folder in your celestia extra folder.
Start Celestia go to the star browser and select Rigel Kentaurus A to view the system.

Note: 

These files are fictional, and do not represent the real Rigel Kentaurus A System.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Changelog:

Rigel Kentaurus A Version 3.

- Complete rebuild of the planet Vanaheim.
- Added a moon orbiting planet Vanaheim.
- Some minor texture improvements.
- Some minor .ssc improvements.

Rigel Kentaurus A Version 2.

- Complete rebuild of the planet Jotunheim and its moons.
- Added a specular texture for the planet Midgard.
- New model and texture for the moon Yggdrasil.
- Added a small moon orbiting planet Muspelheim.
- Added atmosphere to the planet Vanaheim.
- Added new texture and bumpmap to the planet Svartalheim.
- Added new texture and bumpmap to the planet Heimdal.
- Added nighttexture and atmosphere for the planet Hel.
- Fixed planets obliquity settings.
- Added new celurl`s.
- Some minor texture improvements.
- Some minor .ssc improvements.

Rigel Kentaurus B Version 1.

- Release version.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/