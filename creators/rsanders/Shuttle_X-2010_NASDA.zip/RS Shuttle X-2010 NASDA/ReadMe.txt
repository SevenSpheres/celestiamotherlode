ROB SANDERS PRODUCTIONS � 2005 by Rob Sanders. All Rights reserved.

RS Shuttle X-2010 NASDA.

Name:

RS Shuttle X-2010 NASDA.zip

Description:

Experimental shuttle model with NASDA paint scheme.

Requirements:

Celestia version 1.3.2 or higher.

Installation:

Unzip the files and place the RS Shuttle X-2010 NASDA folder in your celestia extra folder.
The spacecraft is placed in orbit around the earth and venus.

Note: 

These files are fictional, and do not represent a real spacecraft.
The original spacecraft model was obtained from the internet, the original author is unknown.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/