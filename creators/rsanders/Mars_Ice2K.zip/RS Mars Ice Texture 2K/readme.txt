ROB SANDERS PRODUCTIONS � 2004 by Rob Sanders. All rights reserved.

RS Ice Mars Texture.

Name:

RS Ice Mars Texture.zip

Type:

2K Surface map texture for celestia.

Requirements:

Celestia version 1.3.1-1 or higher.

Note:

This texture is fictional and does not represent the planet mars as it is.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/

