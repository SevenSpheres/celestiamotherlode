ROB SANDERS PRODUCTIONS � 2005 by Rob Sanders. All Rights reserved.

RS Kappa Ceti System.

Name:

RS Kappa Ceti.zip

Description:

Fictional planetary system for Celestia, based around Kappa Ceti.

Requirements:

Celestia version 1.3.2 or higher.

Installation:

Unzip the files and place the RS Kappa Ceti folder in your celestia extra folder.
Start Celestia go to the star browser and select Kappa Ceti to view the system.

Note: 

These files are fictional, and do not represent the real Kappa Ceti System.

Disclaimer:

Neither the author nor any party involved in creating, producing, or delivering
this product shall be liable for any direct, incidental, consequential, indirect or
punitive damages or any damages whatsoever arising out of your acces, use, or inability
to use this product, or any other errors or omissions in the content thereof.
It is your responsibility to take precautions to protect yourself from trojan horses,
viruses, worms or other items of a destructive nature.

Author:

Rob Sanders

Nick:

RHAS

E-mail:

rhas@chello.nl

Homepage:

http://members.chello.nl/r.sanders20/productions/