INSTALLING INSTRUCTIONS: Installation is different from other add-ons. Move the hoags.png image to the "models" section, and move the rest of the add-on to the "extras" section of your Celestia package.

INFO: This add-on adds Hoag's Object, an unusual ring galaxy in Serpens Caput. It is a ring galaxy, and from Earth it appears nearly face-on. It is very symmetrical for a ring galaxy, unlike other galaxies like Arp 147.

SOURCES: CustomTemplate is taken from http://hubblesite.org/newscenter/archive/releases/2002/21/image/a/ and is public domain;
DSC is from https://en.wikipedia.org/wiki/Hoag%27s_Object
and http://leda.univ-lyon1.fr/ledacat.cgi?o=PGC+2249
and http://leda.univ-lyon1.fr/ledacat.cgi?o=PGC+2252

LICENSE: CustomTemplate is taken from http://hubblesite.org/newscenter/archive/releases/2002/21/image/a/ and is public domain. Everything else is also public domain.