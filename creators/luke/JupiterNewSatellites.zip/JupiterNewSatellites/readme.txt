INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

Additionally, some moons already in the default version of Celestia have been assigned Roman numerals since then. So, go into the numberedmoons.ssc file in your "data" folder, and rename the following lines:

"2003 J 18" "Sol/Jupiter" -> "2003 J 18:Jupiter LV" "Sol/Jupiter"
"2003 J 5" "Sol/Jupiter" -> "2003 J 5:Jupiter LVII" "Sol/Jupiter"
"2003 J 15" "Sol/Jupiter" -> "2003 J 15:Jupiter LVIII" "Sol/Jupiter"
"2003 J 3" "Sol/Jupiter" -> "2003 J 15:Jupiter LX" "Sol/Jupiter"

INFO: This add-on adds 17 new satellites of Jupiter, not included in the minormoons.ssc or numberedmoons.ssc files. They are:

Dia - S/2000 J 11
S/2010 J 1
S/2010 J 2
S/2011 J 1
S/2011 J 2
S/2016 J 1
S/2016 J 2
S/2017 J 1
S/2017 J 2
S/2017 J 3
S/2017 J 4
S/2017 J 5
S/2017 J 6
S/2017 J 7
S/2017 J 8
S/2017 J 9
S/2018 J 1

SOURCES: SSC from http://ssd.jpl.nasa.gov/?sat_elem#jupiter
and https://en.wikipedia.org/wiki/
and https://www.minorplanetcenter.net
and https://sites.google.com/carnegiescience.edu/sheppard/moons/jupitermoons

LICENSE: Public domain.