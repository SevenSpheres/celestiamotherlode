INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This add-on is a supplement to FarGetaNik's "Pluto System" add-on, which fixes the Pluto system with maps from the New Horizon flyby. After the New Horizons flyby of the Pluto system, many craters, valleys, etc. were given names - often with cultural references (e.g. Tardis Chasma and Skywalker Crater). This add-on adds Locations for features on Pluto and Charon.

As of August 2019, many unofficial names exist for geological features. Also, many feature names have been made official by the IAU. Currently, both types are included in this add-on, marked "approved" if they are approved by the IAU. For one feature, Kiladze, the official name replaces an unofficial name in the same spot, Pulfrich. The sizes of the features are either estimated from the texture maps, or taken from the Gazetteer of Planetary Nomenclature website.

I also included a map for Charon, as the map for Charon provided by FarGetaNik is of low resolution.

SOURCES: SSC from https://planetarynames.wr.usgs.gov/SearchResults?target=PLUTO
and https://planetarynames.wr.usgs.gov/Page/CHARON/target
and https://commons.wikimedia.org/wiki/File:Pluto-Map-Annotated.jpg
and https://commons.wikimedia.org/wiki/File:Charon-Map-Annotated.jpg
The map was not my work, it is a modified version of Snowfall-The-Cat's Charon Map, which is from http://snowfall-the-cat.deviantart.com/art/Charon-Map-2015-Nov-07-546620055
License for it is "you can use this however you like!"

LICENSE: The image is from Snowfall-The-Cat, and the license is "you can use this however you like!" Everything else is public domain.