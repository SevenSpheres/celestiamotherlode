INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This add-on adds all stars known to be over 1000 solar radii, according to Wikipedia. Most of them are red hypergiants or supergiants, and some of them have smaller companions that I added as well. For a size comparison, try visiting those stars at a distance of 5 radii, and then going to the Sun at the same distance. The stars I've included (or fixed) are:

UY Scuti
WOH G64
RW Cephei
Westerlund 1-26
V354 Cephei
VY Canis Majoris
KY Cygni
AH Scorpii
VX Sagittarii
V766 Centauri A
SMC 18136
Mu Cephei
HV 11423
IRC -10414
PZ Cassiopeiae
NML Cygni
EV Carinae
RT Carinae
V396 Centauri
CK Carinae
VV Cephei A
V602 Carinae
KW Sagittarii

The stars are listed in order of size, and you'll notice something: VY Canis Majoris is not on the top! VY Canis Majoris is now thought to have a radius 1420 times the sun, as opposed to 2000 times the sun. Also, if you have Splinterfrag's "VY Canis Majoris and R136a1" addon installed, delete the VY CMa file to prevent duplicates.

Orbital data has been taken from Wikipedia and converted to Celestia's ecliptic system using Grant Hutchinson's "starorbs" Excel spreadsheet.

SOURCES: STC data from https://en.wikipedia.org/wiki/
and http://simbad.u-strasbg.fr/simbad/
Excel spreadsheet from https://www.classe.cornell.edu/~seb/celestia/hutchison/spreadsheets.html#2

LICENSE: Public domain.