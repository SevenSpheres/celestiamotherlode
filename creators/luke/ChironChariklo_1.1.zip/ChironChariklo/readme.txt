INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This add-on adds 10199 Chariklo, a large asteroid. Since it orbits between Jupiter and Neptune, it is known as a centaur. Chariklo is also the only known asteroid known to have rings; the rings were discovered in 2013. I used Saturn's rings, because they sort of look like Chariklo's rings.

It's suspected that the centaur 2060 Chiron also has rings, so I've modified Chiron so it also has them.

SOURCES: Based on an addon by Ian Musgrave at http://astroblogger.blogspot.com.au/2014/04/south-african-astronomers-chance-to.html
SSC from https://en.wikipedia.org/wiki/10199_Chariklo
and https://en.wikipedia.org/wiki/2060_Chiron
and http://ssd.jpl.nasa.gov/sbdb.cgi?sstr=10199
and http://ssd.jpl.nasa.gov/sbdb.cgi?sstr=2060
and http://adsabs.harvard.edu/abs/2014Natur.508...72B

LICENSE: Public domain.