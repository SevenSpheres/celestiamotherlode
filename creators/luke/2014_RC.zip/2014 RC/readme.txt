INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This add-on adds 2014 RC, a small Apollo asteroid that flew past Earth at a distance of 39900 km (24800 mi) on September 7, 2014. The asteroid uses an .xyz file obtained from JPL's Horizons utility (along with a timeline that makes the orbit extend past the sampled orbit). Also, 2014 RC is the fastest spinning asteroid known, with a rotation period of only 15.8 seconds.

SOURCES: SSC from http://ssd.jpl.nasa.gov/sbdb.cgi?sstr=2014+RC
and https://en.wikipedia.org/wiki/2014_RC
XYZ from JPL's Horizons Ephemeris System

LICENSE: Public domain.