This is a catalogue of binary stars for Celestia. When stars form, they are very commonly found in binary or multiple star systems that orbit each other. Celestia provides elliptical Keplerian orbits for some of the most well-known binaries, such as Alpha Centauri and Sirius, but many other famous binaries like Algol are not. This catalogue was intended to increase the population of binary stars in Celestia.
		
catalog.txt
Column	Header	Description		
1	no.	The number of the system
2	HIP	Hipparcos designation
3	HD	Henry Draper Catalogue designation
4	Name	Proper or other name of the system
5	mult	Multiplicity (letters) of the pair
6	BAY	Bayer designation (letter)
7	FLA	Flamsteed designation (number)
8	cstl	Constellation designation (may not be the actual constellation)
9	RA	J2000 right ascension, from SIMBAD
10	Dec	J2000 declination, from SIMBAD
11	π	Parallax, in milliarcseconds, from SIMBAD
12	π ±	Parallax error in milliarcseconds
13	D	Distance (if derived from other methods), in parsecs
14	D ±	Distance error
15	V A	Magnitude of component A
16	V B	Magnitude of component B
17	V type	Type of magnitude, either apparent visual (mV), absolute visual (MV), apparent red (mR), or bolometric (MB)
18	SpT A	Spectral type of A
19	SpT B	Spectral type of B
20	M☉ A	Mass of A, in solar units
21	M☉ A ±	Mass of A error
22	M☉ B	Mass of B, in solar units
23	M☉ B ±	Mass of B error
24	R☉ A	Radius of A, in solar units
25	R☉ A ±	Radius of A error
26	R☉ B	Radius of B, in solar units
27	R☉ B ±	Radius of B error
28	L☉ A	Luminosity of A
29	L☉ A ±	Luminosity of A error
30	L☉ B	Luminosity of B
31	L☉ B ±	Luminosity of B error
32	L log?	If L is given as a logarithm, then this column will say log
33	Teff A	Effective temperature of A, in kelvins
34	T A ±	Effective temperature of A error
35	Teff B	Effective temperature of B, in kelvins
36	T B ±	Effective temperature of B error
37	P	Orbital period
38	±	Orbital period error
39		Units of orbital period, either d (days) or y (years)
40	a	Semi-major axis
41	±	Semi-major axis error
42		Units of semi-major axis, either m (milliarseconds), s (arcseconds), r (solar radii), or a (astronomical units)
43	e	Orbital eccentricity
44	±	Orbital eccentricity error
45	i	Inclination, in degrees
46	±	Inclination error
47	Ω	Position angle of the ascending node, in degrees
48	±	Position angle of the ascending node error
49	ω	Argument of pericenter, in degrees
50	±	Argument of pericenter error
51	T_0	Periastron epoch
52	±	Periastron epoch error
53		Units of periastron epoch, either JD (Julian date) or B (Besselian years)
		
refs.txt
Column	Header	Description		
1	no.	The number of the system
2	DIST	Source of distance, or parallax if not from Hipparcos
3	V of A	Source of magnitude of A
4	V of B	Source of magnitude of B
5	SpT A	Source of spectral type of A
6	SpT B	Source of spectral type of B
7	Mass A	Source of mass of A
8	Mass B	Source of mass of B
9	Rad A	Source of radius of A
10	Rad B	Source of radius of B
11	Lum A	Source of luminosity of A
12	Lum B	Source of luminosity of B
13	Teff A	Source of effective temperature of A
14	Teff B	Source of effective temperature of B
15	orbit	Source(s) of orbit
16	notes	Additional notes

bibcodes.txt
Column	Header	Description
1	n/a	Source abbreviation
2	n/a	Bibcode of source

Note: Sources are given as abbreviations modeled after the WDS catalogues, for example Tor2002. Any source present in the Sixth Orbit Catalog's Reference list, it shares the source's abbreviation. Any author with an abbreviation in the Reference list has an abbreviation with that three-character part, but a different year (e.g. 2002b).

There are a few exceptions:

sb9 = Ninth Catalogue of Spectroscopic Binary Orbits, HR = Bright Star Catalogue, MSC = Tokovinin's Multiple Star Catalogue and orb6 = Sixth Catalog of Orbits of Visual Binary Stars.