INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This is a large add-on, and modifies about 130 binary systems. In the default version of Celestia, these are rendered as single stars or two stars not orbiting each other, but these have been modified so that they orbit each other. In cases where there are multiple stars, as many stars that have data have been added.

Knowledge on binary stars and their parameters is very incomplete, so many times I had to estimate or calculate parameters from existing ones. For example, some tables include estimates for mass, absolute magnitude, luminosity, etc. based on spectral type. Alternatively, there are formulae that calculate one based on another.

For this add-on, all of the orbital parameters have to be known, specifically the position angle of the ascending node (Ω). This ensures that the binary star has been resolved. Some binaries in the system do not have an ascending node that is known, but they are included anyway because they are part of a larger system where all the parameters are known.

SOURCES: This add-on makes use of tables of stellar properties and formulae, like these:

http://www.isthe.com/chongo/tech/astro/HR-temp-mass-table-byhrclass.html
https://sites.uni.edu/morgans/astro/course/Notes/section2/spectralmasses.html
http://adsabs.harvard.edu/abs/2007MNRAS.382.1073M

The orbits and parameters themselves are in another catalog I compiled, in the "catalog" folder in this addon.

Note that the orbital elements given in sites like http://ad.usno.navy.mil/wds/orb6/orb6orbits.html are to the plane of sky, and this is different from the elements used in Celestia. To convert them, I used Grant Hutchinson's starorbs.xls file, which can be downloaded here:

https://www.classe.cornell.edu/~seb/celestia/hutchison/spreadsheets.html#2

LICENSE: Public domain.