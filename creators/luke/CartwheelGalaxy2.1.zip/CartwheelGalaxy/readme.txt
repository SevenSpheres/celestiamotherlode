INSTALLING INSTRUCTIONS: Installation is different from other add-ons. Move the cartwheel.png image to the "models" section, and move the rest of the add-on to the "extras" section of your Celestia package.

INFO: This add-on adds the Cartwheel Galaxy, an unusual ring galaxy in Sculptor. It is a ring galaxy (and a lenticular galaxy), and from Earth it appears nearly face-on. Its shape is unusual in that it looks an (elliptical) wheel, with its "spokes" and its center; the shape came from it interacting with another galaxy about 200 million years ago.

The two other galaxies included are PGC 2249 and ESO-LV 350-0402, which can be seen in the Hubble photo and interacted with the Cartwheel Galaxy before.

SOURCES: CustomTemplate from http://www.spacetelescope.org/images/potw1036a/ and is public domain;
DSC from https://en.wikipedia.org/wiki/Cartwheel_Galaxy
and http://simbad.u-strasbg.fr/simbad/
and http://leda.univ-lyon1.fr

LICENSE: CustomTemplate is public domain. Everything else is also public domain.