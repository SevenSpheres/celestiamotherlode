INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This add-on adds about 15600 stars in the Large Magellanic Cloud and about 13600 stars in the Small Magellanic Cloud. These stars are real, and the data is from SIMBAD - see http://simbad.u-strasbg.fr/simbad/. Specifically, the coordinates and names of the stars are real, and the spectral types (if known) have been included. For stars whose spectral types are not known, I used the variable type to fill in random spectral types; for example, Mira-type variable stars would mostly be M-type or C-type stars. Because the distance of these stars aren't known, I've used special formulae to come up with random (but realistic) distances for each of the stars.

I've made a few modifications; for some stars I added TYC or HD catalogue designations. I've fixed names of some stars, like N 160A-IR. A few stars are known to be binaries, so I wrote binary definitions for those - of course, very little orbital data is known so the orbits are mostly fictional, except for a few well-studied objects.

For the Large Magellanic Cloud, there are some open clusters that have been made using stars. They are:

NGC 1786 (visit OGLE LMC-RRLYR-2743)
NGC 1846 (visit 2MASS J05073370-6728045)
NGC 1754 (visit OGLE LMC-RRLYR-1722)
NGC 1835 (visit OGLE LMC-CEP-320)
NGC 1898 (visit OGLE LMC-SC8 192755)
NGC 1943 (visit EROS2-star lm001-6m-8390)
NGC 2005 (visit OGLE LMC-LPV-63269)
NGC 2019 (visit OGLE LMC-RRLYR-18293)

Bonus: This add-on now includes 10 globular clusters that are located in the Magellanic Clouds! Unfortunately little information is known about them so the renderings are not perfect.

SOURCES: STC from http://simbad.u-strasbg.fr/simbad/sim-id?Ident=NAME+LMC&NbIdent=query_hlinks&Coord=05+23+34.6-69+45+22&children=42578&submit=children&siblings=103&hlinksdisplay=h_90
and
http://simbad.u-strasbg.fr/simbad/sim-id?Ident=NGC%20%20%20292&NbIdent=query_hlinks&Coord=00%2052%2038.0-72%2048%2001&children=353&submit=children&siblings=103&hlinksdisplay=h_90
Orbital information is listed within the .stc files

LICENSE: Public domain.