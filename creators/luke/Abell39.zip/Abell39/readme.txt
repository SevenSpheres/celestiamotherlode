INSTALLING INSTRUCTIONS: Just move the whole add-on to your "extras" folder in your Celestia package.

INFO: This add-on adds a realistic, fully 3D model of the planetary nebula Abell 39. Abell 39 is one of the simplest planetary nebulae known, and deviates very little from a perfectly spherical shell.

To recreate the fuzzy shape, I used a point sprite, called 27px.png. This png was made very simply with Microsoft Word, by creating a 1 inch by 1 inch white circle, and setting the soft edges to 27px. The central star, a white dwarf, is also included.

SOURCES: DSC and STC data from http://simbad.u-strasbg.fr/simbad/sim-id?Ident=PN+A66+39
and https://iopscience.iop.org/article/10.1086/322489

LICENSE: Public domain.