#
#
#            CELESTIA   APOLLO 10   ADDON 
#
#  (c) 2005  Diane Neisus (~Medusa) - diane_va@yahoo.com
#
#    This addon is free software. See file COPYING or
#            http://fsf.org for details.
#
#


1. Installation
2. Data Sources 
3. A Spaceship called "Snoopy"
4. References



1. Installation
---------------

Unzip the package, then drop the "apollo10" folder to your Celestia 
"extras" folder or any other place you use for addons.



2. Data Sources 
---------------

Most of the data used to create this addon I got via internet from
the NASA websites [1,2]. About man-made objects in solar orbit, there
are directories elsewhere also [3,4]. From these I took the orbit data 
of the S-IVB booster, some additional orbit elements I calculated or
adjusted on my own. I have the strong desire that my addon shows the 
S-IVB at least in the vincinity of the moon on May 21, 1969.

The Apollo 10 Command Module is on exhibition in the Science Museum, 
London (South Kensington) [5]. So there is no elliptical orbit for it,
just a "LongLat" in the .ssc file.

A little bit more complicated was the matter about the Lunar Module
orbit. All sources I found noted an object called "LM 4" or "Apollo 
10 LM Snoopy" or "1969-43D" as "in heliocentric orbit" but no elements 
were given.
So I had to calculate an orbit by my own (see next section).

The .3ds data was taken from an addon for the spaceflight simulator
"Orbiter". Markus Joachim's addon, named NASSP [6], is Open-Source/
GPL'ed. I took the meshes for S-IVB stage, LM ascent stage and CM from 
it. The file format was adapted to Celestia by a two-stage process:
(1) with the help of "blender" [7] and the Orbiter .msh import script 
    of Philipp Kutin [8] I converted the data files to Wavefront .obj 
    format. (Note there is an 3ds export script for blender but it didn't 
    work error-free).
(2) The .obj files I imported to "anim8or" [9] from which it was possible 
    to export them as proper .3ds files. (Anim8or runs under Linux also 
    by help of the "wine" Windows emulator.)



3. A Spaceship called "Snoopy"
------------------------------

Apollo 10's Lunar Module, called "LM 4" or "Snoopy", is quite remarkable
but nearly always forgotten against the much more glamourous Apollo 11
"Eagle". Despite of that, "Snoopy" is quite fascinating in its own way:
(1) it is the only one of the real flown Apollo LM's which still is some-
    where out in space. All else LM's burned up in earth's atmosphere 
    (Apollo 6, 9, 13) or were crashed into the moon, whether intended 
    (Apollo 12, 14-17) or not (Apollo 11).
(2) LM 4 "Snoopy" up to now is the only spacecraft ever launched from 
    moon orbit towards a sun orbit.
(3) "Snoopy" up to now is farthest out in space of all (former) manned 
    spacecraft. In its heliocentric orbit it is as far as 2 AU from earth 
    (during earth opposition)
(4) Apollo 10 and Apollo 12 share the record of the biggest number of real 
    flight hardware objects left over by any of the Apollo missions (three 
    major objects). Apollo 10's are LM "Snoopy", CM "Charlie Brown" and 
    S-IVB 505.  (As with most of the LM's, the S-IVB's of Apollo 13-17 
    were crashed into the moon; the S-IVB's of Apollo 8-12 are the only 
    ones sent to solar orbit. BTW, Apollo 12's S-IVB came back in 2002 as 
    object "J002E3").
So, Snoopy really is a quite lonesome record-holder.

The computation of the actual orbit elements of LM 4 was done in a three-
step process. From technical references about the Apollo program there is 
enough information to calculate the delta v of the LM. "Snoopy" didn't 
land on the moon, so most of the propellant of the ascent engine wasn't 
yet needed when Mission Control fired it at May 23, 1969 at 6:07 UT. The 
engine ran until burnout. Delta v can be calculated to 1150 m/s.
(1) Under the assumption the LM accelerated parallel to the orbital
    tangent, the delta v adds to the circular velocity of Apollo around 
    the moon (note the Apollo orbits were retrograd). By this, an escape 
    hyperbola and its asymptotic velocity and angle can be calculated. 
    Snoopy left the moon's gravity well at 1336 m/s and an angle of 58.5 
    deg against the orbit tangent/moon center.
(2) By a vector addition of the moon's orbital speed one gets the LM's
    trajectory in a geocentric coordinate system, and doing the same 
    procedure as above for earth again one has the LM's velocity vector 
    with respect to sun center.
(3) Now I had a point in space (vincinity of the moon) and a velocity 
    vector at a certain time (May 23, 1969, 6:00). It was now possible to 
    calculate the elements of a sun orbit by means of common formulas of 
    celestial mechanics [10].
Nevertheless some fine adjustments in the .ssc file had to be done - I 
also desire the LM to be in the vincinity of the moon on May 23, 1969 but
obviously some of the assumptions I made were only rough approximations of 
what really happened. 
So please note the calculated orbit is only a rough approximation of where 
"Snoopy" would be located really today - despite of any bugs in the 
calculation I might have done.

December 6, 2005                     ~Diane Neisius.



4. References
-------------

[1]  Orloff, R.: Apollo by the Numbers, NASA SP-4029, 
     http://history.nasa.gov/SP-4029/Apollo_00a_Cover.htm
[2]  NSSDC Master Catalog entry for Apollo 10,
     http://nssdc.gsfc.nasa.gov/database/MasterCatalog?sc=1969-043A
[3]  RAE catalog of 1969, http://www.satlist.nl/RAE/RAE1969.doc
[4]  http://planet4589.org/space/logs/deep/hco
[5]  Science Museum website, http://www.sciencemuseum.co.uk
[6]  Markus Joachim's Apollo addon for the Orbiter spaceflight simulator, 
     http://sourceforge.net/projects/nassp
[7]  Blender website, http://www.blender3d.org
[8]  Kutin, P.: Orbiter .msh import python script, 
     contact: p <at> kutin.de
[9]  Anim8or website, http://www.anim8or.com
[10] Geyling, F., Westerman, H. R.: Introduction to Orbital Mechanics, 
     Addison-Wesley, London 1971.
