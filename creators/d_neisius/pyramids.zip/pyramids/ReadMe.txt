#
#   Celestia Pyramid Addon
#
#    10/7 2006
#    Diane Neisius aka Medusa
#

Just drop the unzipped folder in your "extras" folder.

License is GPL.

Description:
A little addon which gives a quite simple but nice display 
of the three great pyramids at Gizeh / Egypt. 
I set it up when playing around with the hires texture 
files of Egypt which are available at the Celestia 
Motherlode. 
The tiny .3ds file was created using Anim8tor.

To fit the hires texture, I had to change the correct 
coordinates of the pyramids a little bit. (Source was 
Wikipedia.)
If you want to get correct values back for use with other 
textures, they are still available in the .ssc file - 
just uncommented them.

Wuppertal, Germany, Oct. 7, 2006

~Diane Neisius.