#
#
#  Celestia Impactors 1.1 Add-On -- About the data sources used
#
#

0. Preface
1. Tunguska event of 1908
2. Sikhote Alin Meteoroide of 1947
3. Jackson Lake Bolide of 1972
4. Shoemaker-Levy 9 and Jupiter 1994
5. Additional information
6. Acknowledgements



0. Preface
----------

The intention of this add-on was to give some *qualitative* models of catastrophic encounters 
between a planet and a minor celestial body. I chose what in my view were the most impressive 
events of the 20th century. In particular we have examples for the following:

-straight crash of a small body into a planet (Sikhote-Alin)
-nearly miss resulting in a very small horizon angle of impacting body (Tunguska)
-small body misses planet but pierces through atmosphere (Jackson-Lake)
-body misses (at first try) but was torn apart by gravitational forces of planet (Shoemaker-Levy)

Note that I had to do some modifications of the original data (which in no case was accurate 
enough) to hit the right point in space and time. I feel satisfied if the body hits +/- 1 hour 
and +/- 100 km which is enough to show the overall view. This sounds much but is a *very* close 
hit with respect to the dimensions of the solar system.




1. Tunguska event of 1908
-------------------------

The data of a possible Tunguska impactor is taken from the paper of Farinella et al, Astronomy
& Astrophysics 337(2001) p. 1081 (No. 444 in the notation of the paper). It is not a body of 
the group the authors state to be the most probable origin of Tunguska. I made this particular 
choice for two reasons.

1. I don't see why the authors take so much 3 deg horizon angle samples into their survey. Most 
other authors give 15 deg, some up to 30 deg (which were not included as samples). However, if we 
drop all of the low-angle samples, the chance of the body's origin asteroid vs. comet still 
is 2:1. But most of the remaining trajectories are quite similar (highly excentric).

2. *I* am convinced the body was an asteroid but maybe you're a fan of the cometary hypothesis.
So the orbit data should fit to both possibilities, which is well done by object No. 444 of the
S4 group of the cited paper. Its bodies have an equal chance to come from the Jupiter Family 
of Comets as well as from the outer asteroid belt.

As an addition, I put in an "Atmosphere" (presently uncommented, remove the #'s in "tunguska.ssc" 
if you want to use it) which can serve as the faint coma of a nearly exhausted comet if desired.
Note some people reported problems about it, maybe it will not work for you.
I certainly overstressed Celestia's "Atmosphere" feature; a proper simulation atmosphere never 
will be that extended compared to the main body's circumference. Nevertheless one can argue that 
a comet's coma physically *is* a very thin and transient atmosphere from an academic point of view. 
:)



2. Sikhote Alin Meteoroide of 1947
----------------------------------

There are a number of papers about the Sikhote-Alin meteroroide, I took the data from 
Fesenkov, Meteoritika 9(1951) p.27. It has been noted elsewhere (see the articles of R. Gallant
in Sky & Telescope) that today's estimate of the impact velocity is somewhat lower which would 
make the orbit less excentric. Sadly I could not find an example of this newer orbit data so I 
used the older Fesenkov values.



3. Jackson Lake Bolide of 1972
------------------------------

The orbit of the Jackson Lake Bolide has been calculated by Ceplecha, Astronomy & Astrophysics
283(1994) p.287. However, there are some difficulties.
It is next to impossible to fit its pre- and post-encounter orbits together (remember we talk 
about an accuracy in the meters range here - in a coordinate system that deals with AU's!) so 
I had to decide which of the orbits I put in. Doing it for both, it showed up that the 
pre-encounter data of the paper caused the body to impact into (or scratch above) the pacific 
area. Obviously earth's gravitation has "bent" the real trajectory substantially. Celestia 
cannot simulate gravitation in a direct way (that means, it doesn't calculate a numerical 
solution of the N-body problem earth/sun/meteoroide). Despite of the possibily to use some 
.xyz data to splice pre-encounter and post-encounter orbits there would be additional problems 
from other physical sources: the body has been substatially decelerated by earth's atmosphere 
friction. I have no idea how to model that in a .ssc file or how to get .xyz data for it.
Fortunately both orbits aren't that distinct (they differ mainly in the orbital inclination) 
so I decided to blend the data of post-encounter with pre-encounter inclination. This made a 
good fit. It also leaves the possibility to watch the close encounter to earth in 1997, for 
which inclination plays a minor role. 
For "cosmetics" I set up a texture file for post-encounter which has a badly burned front face 
showing some rhegmaglyphic structures. 




4. Shoemaker-Levy 9 and Jupiter 1994
------------------------------------

It was not my intention to replace one of the existing SL9 packages for Celestia. If you're 
interested in exact models of impact phenomena, the work of Jack Higgins (see forum) may be more 
suitable for you; if you want to have highly precise final orbits of all 21 fragments, Seldens's
package (at http://www.lns.cornell.edu/~seb/celestia/index.html#3.3) is the better choice.
I wanted to have a *qualitative* simple model of the last three orbits of the body before and 
after its breakup. For this, I had to simplify the data provided by Selden substantially.
However, the motions of a body like SL9 cannot be described in a simple way (again, it's a 
N-body problem which has no analytical solution). Moreover, it seems if there are two groups 
of authors, some describe SL9 to be caught by Jupiter from a heliocentric orbit immediately 
before impact, some other state it should have been in an (irregular) orbit around Jupiter for 
at least some decades before (I believe in the latter). So all "orbits" are only partial 
approximations. To get an overall view, a trajectory has to be fitted from such orbit pieces if 
you're not able to get or calculate .xyz data somewhere (which I'm not).
It is possible to fit a set of orbit ellipses of same orientation in a plane by variation of 
semimajor axis and excentricity only. So I took the SL9-L fragment trajectory out of Selden's data 
set as a reference and set up two other orbits which touch it at apocenter (where the distortions 
of the orbit(s) by sun's gravitation are strongest). By sort of variation I was able to get orbits for 
12 other fragments which all touch my orbit at the point of pericenter (where breakup occured). In 
terms of space navigation, one can view this as a kind of a "Hohmann transfer orbit" for each 
fragment.
By a mathematical analysis all orbits can be made precisely fitting. That means, in Celestia you can 
sit at the SL9 mother body approaching its last pericenter and see it literally break apart under 
your feet - and none of the fragments does a step or hop when the orbit is switched.
Of course this has a cost. Keeping most of the orbital parameters fixed, I had to set another 
parameter free to adjust time. This was done by orbital period. By the standpoint of physics, 
it's not correct but the derivation is not that big -- all orbits are similar extremely elliptic 
with semimajor axes of approx 26 Mio. km.
For the last trajectory segment I adjusted by this trick the impact time as close as possible to 
the observed values.

A note about some "cosmetics": I put faint coma's to all bodies by the "Atmosphere" trick mentioned 
above. Celestia's comet feature isn't satisfying for me to model such small exhausted comets - the 
tail is by far too large and can't be adjusted in size (maybe a request for a future version?). 
Moreover, in my Celestia 1.3.2 installation the tail of a comet orbiting a planet points away from 
the *planet* not the sun.




5. Additional information
-------------------------

Additional information at least about the Tunguska impact and Sikhote Alin I have put on my 
homepage:

http://www.geocities.com/diane_va/sikhote-alin    (german)
http://www.geocities.com/diane_va/tunguska

http://www.geocities.com/diane_va/sikhote-alin/index_E.html   (english)
http://www.geocities.com/diane_va/tunguska/index_E.html



6. Acknowledgements
-------------------

Thanks to Selden and Terrier for the discussion at the Celestia Forum about the Jackson Lake trajectory
and the chances to put (or not to put) it in a right way into Celestia. 



October 9, 2004   /  reviewed October 24, 2005   Diane Neisius (~Medusa)
