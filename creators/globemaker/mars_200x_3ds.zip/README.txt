This is the README.txt file for the mars_200x.3ds model of Mars. 
The creator was Alan C. Folmsbee. 
The model file mars_200x.3ds is not copyrighted. It is in the 
public domain. Dated February 26, 2006. Jestr edited the file to enable
texture mapping.

To install the files for Celestia, use the celestia/extras/Addons directory to hold the files.
There are four files that should be in the following directories after unzipping the .zip 
file in the celestia/extras/Addons directory : 

celestia/extras/Addons/mars_200x_3ds/solarsys_mars200x.ssc
celestia/extras/Addons/mars_200x_3ds/models/mars_200x.3ds
celestia/extras/Addons/mars_200x_3ds/textures/lores/rusty.jpg
celestia/extras/Addons/mars_200x_3ds/textures/medres/mars.jpg

In Celestia, you can go to the model using the Navigation menu and the 
Solar System Browser choice.

______________________________________________________________________
See the Celestia forum at: 
http://www.shatters.net/forum/viewtopic.php?t=8778&sid=9e7d638faba727eef50eb61debdd182c

Announcing a model of Mars with 200 times vertical exaggeration of topography.
The 2.6 megabyte file is in the .3ds format. It is not copyrighted.
There are 129,000 triangles making the 3 dimensional surface of Mars.
It being donated to
Celestia with no limits. No credit needs to be given to me,
Alan Folmsbee, the designer of the model. Please feel free to copy,
modify, and distribute the model with no limits. It can be used without
textures, so the shape of Mars can be better appreciated. Or even better,
just color it with a uniform rust orange to let the shapes and normals
produce scientifically descriptive shadings. That texture is called
texture/lores/rusty.jpg
Or use a more complicated texture called texture/medres/mars.jpg
The alignment of this texture mapping is not exactly correct. At the poles,
the misalignment is visible. Sorry.

The .3ds model was made using the Mars Global Surveyor, Mars Orbiter Laser Altimeter
(MGS MOLA) data file that you can examine at:
http://pds-geosciences.wustl.edu/geodata/mgs-m-mola-5-megdr-l3-v1/mgsl_300x/meg004/
The file is called megt90n000cb.img . Here is a description from PDS, the Planetary
Data System :

"PRODUCER_ID = MGS_MOLA_TEAM
PRODUCER_FULL_NAME = "DAVID E. SMITH"
PRODUCER_INSTITUTION_NAME = "GODDARD SPACE FLIGHT CENTER"
DESCRIPTION = "This data product is a topographic
map of Mars at a resolution of 0.25 (1/4) by 0.25 degrees, based on
altimetry data acquired by the Mars Global Surveyor MOLA instrument
and accumulated over the course of the primary and extended
mission. The MOLA Precision Experiment Data Records (PEDRs) are the
source for this data set. The map is in the form of a binary table
with one row for each 0.25-degree latitude. "

But not all of the data was used. To keep the Celestia frame rate at 60 FPS on my system,
only 1/4 of the data was used. Data points occur every 1 degree of latitude and longitude.
There are about 65,000 data points used. Data points are closer to each other
near the poles.
__________________________________________________________________________

Alan Folmsbee, Founder
The Relief Globe Company
13266 Hwy 9 Unit D
Boulder Creek, CA 95006

www.reliefglobe.com

webmaster@reliefglobe.com