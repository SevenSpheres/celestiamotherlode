This is the README.txt file for the earth_200x.3ds model of earth 
with seafloor shown as well as land. The creator was Alan C. Folmsbee. 
The model file earth_200x.3ds is not copyrighted. It is in the 
public domain. Dated February 26, 2006. Jestr edited the file to enable
texture mapping.

To install the files for Celestia, use the celestia/extras/Addons directory to hold the files.
There are four files that you should be in the following directories after unzipping the .zip 
file in the celestia/extras/Addons directory : 

celestia/extras/Addons/earth_200x_3ds/solarsys_earth200x.ssc
celestia/extras/Addons/earth_200x_3ds/models/earth_200x.3ds
celestia/extras/Addons/earth_200x_3ds/textures/lores/rusty.jpg
celestia/extras/Addons/earth_200x_3ds/textures/medres/earth.jpg


______________________________________________________________________
See the Celestia forum at:
http://www.shatters.net/forum/viewtopic.php?t=8778&sid=6b8b41cec28305213ad671ad3bf49f89

Announcing a model of Earth with 200 times exaggeration of topographical
land heights.
The 2.6 megabyte file is in the .3ds format. It is not copyrighted.
There are 129,000 triangles making the surface of Earth.
It being donated to
Celestia with no limits. No credit needs to be given to me,
Alan Folmsbee, the designer of the model. Please feel free to copy,
modify, and distribute the model with no limits. It can be used without
textures, so the shape of Earth can be better appreciated. Or a uniform
rust colored texture can be applied, so only the
shapes and normals are seen, with complicated colors obscuring the
mesh shape. Or use earth.jpg for more realistic colors.

The .3ds model was made using the land data from
the ETOPO2 database that has the elevation data from the GLOBE project.
Here is a list of the contributors to the GLOBE project :

Germany : German Remote Sensing Data Center of DLR in Oberpfaffenhofen

Japan : Geographical Survey Institute in Tsukuba

Australia : Australian Surveying and Land Information Group in Canberra

United Kingdom : University College London in London

United States of America :
National Imagery and Mapping Agency in Fairfax, Virginia (Name is now 
National Geospatial-Intelligence Agency)
Jet Propulsion Laboratory in Pasadena, California
National Geophysical Data Center in Boulder, Colorado
Earth Resources Observation Systems Data Center in Sioux Falls, South Dakota

The GLOBE Project is an internationally designed, developed, and independently 
peer-reviewed digital elevation model, at a latitude-longitude grid spacing 
of 1/120 of a degree. That is about a half mile at the equator, and finer 
near the poles. (The earth_200x.3ds uses a grid of about 60 miles near the 
equator, so most of the data from the GLOBE Project was skipped between 
grid points). The GLOBE Task Team was established by the Committee on Earth 
Observation Satellites. It is part of Focus I of the Geosphere-Biosphere 
Programme. The ETOPO2 database was collected during or after the year 2000,
 and then a CD ROM was sold for $50 so the public could read and use the global
 elevations. The GLOBE project was started in Germany in 1990 by Gunter Schreier of DLR.

The earth_200x.3ds model has the depth data of all the oceans. Here are the 
organizations that contributed to that database :

Scripps Institution of Oceanography contributed the Smith/Sandwell report that used 
satellite radar altimetry to record gravity anomolies. This covers the oceans, 
except for the polar seas. Their grid was 2 minutes. It was published in 1978. 
The Institution is part of the University of California.

US Naval Oceanographic Office provided two Digital Bathymetric Databases. One is 
from the 1980's. They are called DBDBV and DBDV5 for the Variable resolution and 
the 5 minute resolution grids for the Antarctic seas. Their names are The Digital
 Bathymetric Data Base, Variable-resolution, and The Digital Bathymetric Data Base
 5 minute. The USA Naval office is in Annapolis, Maryland in The United States of 
America.

The following nations provided the International Bathymetric Chart of the Arctic 
Ocean : Russia, Sweden, USA, Iceland, Canada, Norway, Germany, and Denmark. Also,
 France and Monaco are headquarters for international organizations that helped 
with IBCAO. Those are the Intergovernmental Oceanographic Commission and the 
International Hydrographic Bureau.

The topography data file (111 megabytes) can be obtained from :
http://www.ngdc.noaa.gov/mgg/image/2minrelief.html
But not all of the data was used. To keep the Celestia frame rate at 6- FPS on 
my system,
only 1/300 of the data was used. One data point per degree of latitude and 
longitude. There are about 65,000 data points used. Data points are closer 
to each other near the poles.

__________________________________________________________________________

Alan Folmsbee, Founder
The Relief Globe Company
13266 Hwy 9 Unit D
Boulder Creek, CA 95006

webmaster@reliefglobe.com