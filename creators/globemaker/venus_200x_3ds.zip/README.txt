This is the README.txt file for the venus_200x.3ds model of venus .
The creator was Alan C. Folmsbee. 
The model file venus_200x.3ds is not copyrighted. It is in the 
public domain. Dated February 26, 2006. Jestr edited the file to enable
texture mapping.

To install the files for Celestia, use the celestia/extras/Addons directory to hold the files.
There are four files that should be in the following directories after unzipping the .zip 
file in the celestia/extras/Addons directory : 

celestia/extras/Addons/venus_200x_3ds/solarsys_venus200x.ssc
celestia/extras/Addons/venus_200x_3ds/models/venus_200x.3ds
celestia/extras/Addons/venus_200x_3ds/textures/lores/rusty.jpg
celestia/extras/Addons/venus_200x_3ds/textures/medres/venussurface.jpg

In Celestia, use the Navigation menu and the Solar System Browser to go to
this model.

______________________________________________________________________
See the Celestia forum at:
http://www.shatters.net/forum/viewtopic.php?t=8778&sid=2d787c94cfc3940f85aa7525e1a34e2f

Announcing a model of Venus with 200 times exaggeration of topography.
The 2.6 megabyte file is in the .3ds format. It is not copyrighted.
There are 129,000 triangles making the surface of Venus.
It being donated to
Celestia with no limits. No credit needs to be given to me,
Alan Folmsbee, the designer of the model. Please feel free to copy,
modify, and distribute the model with no limits. It can be used without
textures, so the shape of Venus can be better appreciated. Jestr enabled 
texture mapping. The model rotates in a reverse direction compared to Earth,
because that is what Venus does. A uniform rust color texture file
is included in the textures/lores directory, so the
shapes and normals are seen, without complicated colors obscuring the
mesh shape. Also, a realistic texture is provided in the medres directory.


The .3ds model was made using the data
from the Magellan Project of NASA. The spacecraft entered an orbit around 
Venus in 1990. This paragraph acknowledeges the Principal Investigator, 
Dr. Gordon H. Pettengill, the Astrological Branch of the United States 
Geological Survey, the Magellan Project, and the Planetary Data System. 
During 1991 the land height data was published with preparations by 
Peter G. Ford of the Center for Space Research at the Massachusetts Institute 
of Technology. One document is called 
"Altimetric and Radiometric Global Data Records".

Dr. Gordon H. Pettengill first came into prominence for his discovery in 
1965 of the unexpected 2/3 spin/orbital period resonance of the planet 
Mercury, using radar astronomical techniques, although his name is also 
closely linked to much of the development of radar astronomy since its 
early years in the late 1950's. Beginning with the first application of 
coherent earth-based radar to studies of the Moon in 1959, his observations 
have embraced Mercury, Venus, Mars, several asteroids and comets, the 
Galilean satellites of Jupiter and the rings of Saturn. He was the 
Principal Investigator for the Radar Mapper Experiment carried out on the 
Pioneer Venus Orbiter from 1978 through 1981, providing for the first time 
a comprehensive view of the global surface of Venus. Since then he has been 
the Principal (scientific radar) Investigator for the Magellan 
(Venus-radar-mapping) Mission that was launched in May, 1989, and has since 
mapped nearly the entire Venus surface at a resolution of a few hundred 
meters.

The topography data file is from :
http://pds-geosciences.wustl.edu/geodata/mgn-v-gxdr-v1/mg_3002/gtdr/sinus/

But not all of the data was used. To keep the Celestia frame rate at 60 FPS 
on my system, only 1/22 of the 
sinusoidal projection data was used. There is one data point 
per degree of latitude and longitude from Magellan, except where high 
resolution sinusoidal projection NASA Magellan data is not available, 
and then, 1 degree data 
is used, which is from Venera, Magellan, and Pioneer-Venus Orbiter spacecraft. 
The Venera spacecraft was launched by the Soviet Union. The other two 
spacecraft were launched by the USA. There are about 65,000 data points used. 
Data points are closer to each other near the poles.

__________________________________________________________________________

Alan Folmsbee, Founder
The Relief Globe Company
13266 Hwy 9 Unit D
Boulder Creek, CA 95006

www.reliefglobe.com

webmaster@reliefglobe.com