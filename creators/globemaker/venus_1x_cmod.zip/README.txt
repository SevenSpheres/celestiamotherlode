This is the README.txt file for the venus_to_scale.cmod model of venus
The creator was Alan C. Folmsbee. The model file venus_to_scale.cmod is not copyrighted.
It is in the public domain. Dated February 26, 2006.

To install the files for Celestia, use the celestia/extras/Addons directory to hold the files.
There are three files that should be in the following directories after unzipping the .zip 
file in the celestia/extras/Addons directory : 

celestia/extras/Addons/venus_1x_cmod/solarsys_venus1x.ssc
celestia/extras/Addons/venus_1x_cmod/models/venus_to_scale.cmod
celestia/extras/Addons/venus_1x_cmod/textures/lores/rusty.jpg

______________________________________________________________________
Here is an excerpt from the Celestia forum at:
http://www.shatters.net/forum/viewtopic.php?t=8914&sid=6b6eae02297121cc880864d6cbf99bbc

Announcing a model of Venus with no exaggeration of topography.
The 17.6 megabyte file is in the .cmod format. It is not copyrighted.
There are 516,242 triangles making the surface of Venus.
It being donated to
Celestia with no limits. No credit needs to be given to me,
Alan Folmsbee, the designer of the model. Please feel free to copy,
modify, and distribute the model with no limits. It can be used without
textures, so the shape of Venus can be better appreciated. Texture mapping is
not enabled on this first version. Jestr edited the model to add texture mapping.

The rusty color is uniform so only the
shapes and normals are seen, without complicated colors obscuring the
mesh shape.


The .cmod model was made using the data
from the Magellan Project of NASA. The spacecraft entered an orbit around 
Venus in 1990. This paragraph acknowledeges the Principal Investigator, 
Dr. Gordon H. Pettengill, the Astrological Branch of the United States 
Geological Survey, the Magellan Project, and the Planetary Data System. 
During 1991 the land height data was published with preparations by 
Peter G. Ford of the Center for Space Research at the Massachusetts 
Institute of Technology. One document is called "Altimetric and 
Radiometric Global Data Records".

Dr. Gordon H. Pettengill first came into prominence for his discovery in 
1965 of the unexpected 2/3 spin/orbital period resonance of the planet Mercury, 
using radar astronomical techniques, although his name is also closely linked 
to much of the development of radar astronomy since its early years in the 
late 1950's. Beginning with the first application of coherent earth-based 
radar to studies of the Moon in 1959, his observations have embraced Mercury, 
Venus, Mars, several asteroids and comets, the Galilean satellites of Jupiter 
and the rings of Saturn. He was the Principal Investigator for the Radar 
Mapper Experiment carried out on the Pioneer Venus Orbiter from 1978 through 
1981, providing for the first time a comprehensive view of the global surface 
of Venus. Since then he has been the Principal (scientific radar) Investigator 
for the Magellan (Venus-radar-mapping) Mission that was launched in May, 1989,
 and has since mapped nearly the entire Venus surface at a resolution of a few
 hundred meters.

The topography data file is from :
http://pds-geosciences.wustl.edu/geodata/mgn-v-gxdr-v1/mg_3002/gtdr/sinus/

But not all of the data was used. To keep the Celestia frame rate at 5 FPS on my system,
only 1/11 of the data was used.

There are two data points per degree of latitude and longitude, except where high 
resolution sinusoidal projection NASA Magellan data is not available, and then 
coarse 1 degree data is used, which is from Magellan, Venera, and Pioneer-Venus Orbiter 
spacecraft. The Venera spacecraft was launched by the Soviet Union.
There are about 258,000 data points used. Data points are closer to each other
near the poles.
__________________________________________________________________________

Alan Folmsbee, Founder
The Relief Globe Company
13266 Hwy 9 Unit D
Boulder Creek, CA 95006

webmaster@reliefglobe.com