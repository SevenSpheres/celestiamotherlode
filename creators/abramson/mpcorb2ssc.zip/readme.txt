# MPCORB2SSC 
# Author: Guillermo Abramson 
# Email: abramson@cab.cnea.gov.ar    Web: cabfst28.cnea.gov.ar/~abramson
# Revision date: February 2009
#*******************************************************************************
# This Perl script reads MPCORB.DAT, the file with Minor Planets Orbital 
# Elements published by the Minor Planets Center of the IAU [1], and writes a 
# file in .ssc format to be read by Celestia, the free space simulator [2]. It 
# also saves two scripts in .celx format, one to mark the selected asteroids 
# in Celestia, the other to unmark them.
# Several extraction criteria can be used: 
#    1. Designation (e.g. 6109, K08A00Y).
#    2. Name (e.g. Ceres, 2000 VT33). Accepts Perl regular expressions.
#    3. A range of asteroids from MPCORB.DAT.
#    4. Belonging to a class (Trojans, Plutinos, etc).
#    5. With specific parameters (semiaxis, eccentricity, radius, etc).
#    (Criteria 4 and 5 can be combined with AND, which is useful.)
# Read the Usage notes below, and the Important Notes as well.
#*******************************************************************************
# INPUT: MPCORB.DAT and user choices
#*******************************************************************************
# OUTPUT: mpc_XXX.ssc, mark_XXX.celx, unmark_XXX.celx (XXX depends on results)
#*******************************************************************************
# USAGE 
#
# 1. Copy this script into a folder (directory) containing MPCORB.DAT. 
# 2. Run it from a console (cmd in Windows) with your Perl interpreter and 
# follow the simple instructions. New files are created (or overwritten if
# they existed): mpc_X.ssc, mark_X.celx, unmark_X.celx (where X depends on
# your search criteria,  for easy identification of your paramenters). If your 
# search ends up with too many asteroids (which may make Celestia sluggish), you
# will be warned and offered to "prune" the set, creating additional appropriate
# ssc and celx files. Use your own criterion and keep only the files you prefer,
# to avoid double definitions of some asteroids.
# 3. Copy the ssc and celx files of your choice into the extras folder of your 
# installation of Celestia. If the folder you used in step 1 is already inside
# Celestia's extras folder, you may skip this step.
# 4. Run Celestia. The new asteroids will be automatically loaded. If you want 
# to mark them with a custom symbol, run mark_XXX.celx from within Celestia 
# (menu: File/Open Script...). Markers will be turned on by the script.
# If you wish to unmark them, run the script unmark_X.celx. 
# 5. The names of the generated files are tailored to the search criteria in an 
# easy way (mpc_X.ssc, mark_X.celx and unmark_X.celx, where X denotes all the 
# parameter used and their values). For example, if you searched for all the 
# Trojans with inclinations between 0 and 1 degree, the data file will be:
# mpc_trojans_inc=0-1.ssc. The names of the scripts also contain the color of 
# choice. The prunned ones contain the prunning criterion. All will be
# overwritten if files with the same name already exist. 
#
# USER INPUT: It is *not* thoroughly checked. Be careful when using and check 
# the results.
#
# PERL: On Linux, it's most probable that Perl is already in your system. Run
# the script with: perl mpcorb2ssc.pl, or make the script executable (chmod +x
# mpcorb2ssc.pl) and run it with its name, or maybe ./mpcorb2ssc.pl. If you get
# something unexpected, check the first line of the script (It may be that 
# #!/usr/local/bin/perl works in your system). 
# On Windows, you may need to install a Perl interpreter (for example 
# ActivePerl, which is free [4]).
# Then run the script from a console with: perl mpcorb2ssc (to avoid the nasty
# self-closing of the console if you just double-click its icon!).
#
# MPCORB.DAT: The original name of this file is in capital letters. In Windows 
# this is irrelevant, but on Linux, check this if you get a "Can't open 
# MPCORB.DAT" message.
#
#*******************************************************************************
# IMPORTANT NOTES
#
# 1. BEWARE: Celestia default installation contains a file asteroids.ssc, with 
# its own definitions of some asteroids. You may end up with double definitions.
# 2. BEWARE ALSO: MPCORB.DAT contains nowadays more than 350,000 asteroids. The 
# extraction of ALL of them to use in Celestia is useless with today computers.
# Be sensible and use the script to extract some of them according to criteria: 
# this is the true purpose of the script. If your search ends up with too many
# asteroids, you will be warned and offered to "decimate" the set.
# 3. ASTEROID SIZE: This important parameter is only estimated by this script. 
# MPCORB.DAT only provides the objects's absolute magnitude, even for asteroids 
# of known size. Its radius is then calculated from it and a guessed $albedo 
# (MPCORB.DAT does not contain known albedos, also). Of course, this gives only 
# approximate results. For example, with an albedo of 0.15 Ceres's radius 
# becomes 368.5 km instead of the known 487.5 km. The estimation is based on [3].
# 4. ASTEROID SHAPE: Two parameters are used, $big and $medium, to define 
# typical asteroid shapes in Celestia:
#               $radius <= $medium, use asteroid.cms mesh (typical potato),
#    $medium <  $radius <  $big,    use roughsphere.cms mesh,
#       $big <= $radius,            use a sphere.
# 5. ASTEROID COLOR: [1.000 0.945 0.881], which is Ceres's color in Celestia, is 
# used for all asteroids.
# 6. ASTEROID TEXTURE: asteroid.jpg (Celestia's default) used for all asteroids.
# 7. PLUTO: Pluto is there, as asteroid D4340. Its radius turns out exaggerated 
# if typical asteroid albedos are used. So are the radii of other TNOs.
# 8. ASTEROID CLASS: MPCORB.DAT provides a class identifier for some asteroidal
# orbital families (Trojans, Atens, etc). I believe this identification is 
# incomplete. For example, the asteroids identified as "Other resonant TNO" do
# not include a single Neptune trojan, which are not identified otherwise. I 
# really do not know what it identifies. Neptune trojans are in the list, though,
# and can be extracted by their names. Orbital parameters can be used to find
# families not covered by these classes. See [5].
# 9. BLANK LINES: There are a couple of blank lines in MPCORB.DAT, dividing it 
# in sections (see its header). This does not affect the script (gives 2 extra
# asteroid counts, though...)
# 10. MPCORB.DAT HEADER: The script reads the header until it reaches a "-----"
# line. This is the standard header. If you change it, watch out.
# 11. ACCURACY: MPCORB provides accurate data for an epoch which is no more 
# than 100 days from its creation date. Their use in Celestia at dates in the 
# past or future from that epoch gets increasingly inaccurate. That's unavoidable 
# for these objects.
# 12. FAMILIES: Asteroid families found from MPCORB elements are only approximate.
# Precise results need the use of proper orbital elements instead of osculating 
# ones. A good source seems to be AstDys [6].
# 13. ASTORB: Another source of asteroid orbital elements is ASTORB.DAT, 
# prepared daily by E. Bowell from Lowell Observatory [7]. MPCORB has several 
# advantages over ASTORB. MPCORB contains currently visible objects; ASTORB 
# contains a lot of objects that were observed briefly, long ago, and which are 
# essentially "lost" now. MPCORB tends to be slightly more up to date 
# (understandably, since ASTORB is based on waiting for MPC data to arrive) [8]. 
# Astorb provides, though, IRAS sizes for some asteroids. I wouldn't rule out 
# its use in principle. Future versions of this script may offer to use one or 
# the other databases.
# 14. DEFAULTS: You can change default parameters in the Initializations section.
#*******************************************************************************
# REFERENCES
# [1] Minor Planet Center of the IAU Webpage: www.cfa.harvard.edu/iau/MPCORB.html
#     New versions of MPCORB.DAT, updated on a daily basis, are available at:
#     ftp://cfa-ftp.harvard.edu/pub/MPCORB/MPCORB.DAT and mirrors.
#     Each object's elements are stored on a single line, the format of which is 
#     described at: www.cfa.harvard.edu/iau/info/MPOrbitFormat.html .
# [2] Celestia, created by Chris Laurel, is a free open source space simulator 
#     avaliable for many operating systems. Webpage: shatters.com/celestia . 
# [3] Quantifying the Risk Posed by Potential Earth Impacts, Chesley et al., 
#     Icarus 159, 423-432 (2002). A table for the same purpose is at the MPC: 
#     www.cfa.harvard.edu/iau/lists/Sizes.html .
# [4] ActivePerl: www.activestate.com/Products/activeperl/ .  
# [5] Wikipedia defines the main asteroid families at: 
#     en.wikipedia.org/wiki/Asteroid_family, and more are listed at:
#     en.wikipedia.org/wiki/Category:Asteroid_groups_and_families
# [6] AstDys (University of Pisa, Italy):
#     hamilton.dm.unipi.it/cgi-bin/astdys/astibo?proper_elements:0;main .
# [7] ASTORB: ftp://ftp.lowell.edu/pub/elgb/astorb.html .
# [8] Project Pluto: www.projectpluto.com/mpcorb.htm .
#*******************************************************************************
# (c) 2008, Guillermo Abramson
# You may use, modify, redistribute at will. Due recognition will be appreciated.
#*******************************************************************************

Changes log:
2009-02-19: v. 1.1  CORRECTED: A bug that made the celx file for size prunned
                    catalogs lack some asteroids.
2008-10-07: v. 1.0  CHANGED: Prunning by size is now actually implemented
                    (instead of prunning by catalog order, as before). 
                    It keeps the N biggest asteroids according to estimated radius.
                    CHANGED: If no asteroids are found, no output files are left 
                    behind.
2008-10-06: v. 0.99 NEW: In the ssc file, the asteroids are identified by all 
                    their designations as provided by MPCORB.DAT: name, number 
                    or provisional designation, and readable designation. (The
                    name is part of the readable designation, and the number
                    can be also part of it, so there may be some repetition. But 
                    there is no uniform nomenclature, especially for recently 
                    found objects, so it's reasonable as it is.). 
                    NOTE: This nomenclature works only in Celestia 1.6+, where 
                    Solar System objects may have alternative names.
                    CORRECTED: Choice by name produced ssc files with duplicate 
                    extension .ssc.ssc.
2008-02-26: v. 0.9. NEW: If too many asteroids are found, it runs or offers to 
                    run two prunning algorithms, with a choice of the fraction
                    of asteroids to keep. First prunning is at random, second 
                    one keeps the firstmost asteroids of the set (approx. the 
                    biggest ones). Filenames of new ssc and celx are self-
                    explaining. If more than 10000 asteroids are found, it just 
                    runs the prunning. If more than 2000 but less than 10000
                    are found, it offer the user to run them or not.
                    CHANGED: The names of the generated files are tailored to the 
                    search criteria in an easy way (mpc_X.ssc, mark_X.celx and 
                    unmark_X.celx, where X denotes all the parameter used and 
                    their values). The names of the scripts also contain the 
                    color of choice. The prunned ones contain the prunning 
                    criterion. 
                    CHANGED: wait() is written every 200 asteroids. Slower but
                    safer in lower end machines.
                    CHANGED: Some details rewritten (e.g. writing subroutines,
                    messages, scripts show some text on Celestia screen, names
                    can contain spaces--which are ignored).
2008-01-23: v. 0.7. NEW: Search by name accepts partial names and Perl regular 
                    expressions.
                    NEW: writes out a second .celx, to unmark the asteroids.
2008-01-23: v. 0.6. NEW: selection by class and selection by parameters can 
                    be combined (wit an AND).
2008-01-18: v. 0.4. NEW: Default color with ENTER.
                    Windows executable available, packed with TinyPerl.
                    Show version on title.
                    Output to .celx file in new subroutine.
2008-01-17: v. 0.3. NEW: User chooses marker color.
                    ISSUE: Celestia requires a wait(0) every thousand marks, 
                    to avoid a timeout.
2008-01-17: v. 0.2. NEW: write .celx that marks filtered asteroids.
2008-01-16: v. 0.1. First public version (in Celestia forum).
