#!/usr/bin/perl
$version = 1.1;
# MPCORB2SSC 
# Author: Guillermo Abramson 
# Email: abramson@cab.cnea.gov.ar    Web: cabfst28.cnea.gov.ar/~abramson
# Revision date: October 2008
#*******************************************************************************
# This Perl script reads MPCORB.DAT, the file with Minor Planets Orbital 
# Elements published by the Minor Planets Center of the IAU [1], and writes a 
# file in .ssc format to be read by Celestia, the free space simulator [2]. It 
# also saves two scripts in .celx format, one to mark the selected asteroids 
# in Celestia, the other to unmark them.
# Several extraction criteria can be used: 
#    1. Designation (e.g. 6109, K08A00Y).
#    2. Name (e.g. Ceres, 2000 VT33). Accepts Perl regular expressions.
#    3. A range of asteroids from MPCORB.DAT.
#    4. Belonging to a class (Trojans, Plutinos, etc).
#    5. With specific parameters (semiaxis, eccentricity, radius, etc).
#    (Criteria 4 and 5 can be combined with AND, which is useful.)
# Read the Usage notes below, and the Important Notes as well.
#*******************************************************************************
# INPUT: MPCORB.DAT and user choices
#*******************************************************************************
# OUTPUT: mpc_XXX.ssc, mark_XXX.celx, unmark_XXX.celx (XXX depends on results)
#*******************************************************************************
# USAGE 
#
# 1. Copy this script into a folder (directory) containing MPCORB.DAT. 
# 2. Run it from a console (cmd in Windows) with your Perl interpreter and 
# follow the simple instructions. New files are created (or overwritten if
# they existed): mpc_X.ssc, mark_X.celx, unmark_X.celx (where X depends on
# your search criteria,  for easy identification of your paramenters). If your 
# search ends up with too many asteroids (which may make Celestia sluggish), you
# will be warned and offered to "prune" the set, creating additional appropriate
# ssc and celx files. Use your own criterion and keep only the files you prefer,
# to avoid double definitions of some asteroids.
# 3. Copy the ssc and celx files of your choice into the extras folder of your 
# installation of Celestia. If the folder you used in step 1 is already inside
# Celestia's extras folder, you may skip this step.
# 4. Run Celestia. The new asteroids will be automatically loaded. If you want 
# to mark them with a custom symbol, run mark_XXX.celx from within Celestia 
# (menu: File/Open Script...). Markers will be turned on by the script.
# If you wish to unmark them, run the script unmark_X.celx. 
# 5. The names of the generated files are tailored to the search criteria in an 
# easy way (mpc_X.ssc, mark_X.celx and unmark_X.celx, where X denotes all the 
# parameter used and their values). For example, if you searched for all the 
# Trojans with inclinations between 0 and 1 degree, the data file will be:
# mpc_trojans_inc=0-1.ssc. The names of the scripts also contain the color of 
# choice. The prunned ones contain the prunning criterion. All will be
# overwritten if files with the same name already exist. 
#
# USER INPUT: It is *not* thoroughly checked. Be careful when using and check 
# the results.
#
# PERL: On Linux, it's most probable that Perl is already in your system. Run
# the script with: perl mpcorb2ssc.pl, or make the script executable (chmod +x
# mpcorb2ssc.pl) and run it with its name, or maybe ./mpcorb2ssc.pl. If you get
# something unexpected, check the first line of the script (It may be that 
# #!/usr/local/bin/perl works in your system). 
# On Windows, you may need to install a Perl interpreter (for example 
# ActivePerl, which is free [4]).
# Then run the script from a console with: perl mpcorb2ssc (to avoid the nasty
# self-closing of the console if you just double-click its icon!).
#
# MPCORB.DAT: The original name of this file is in capital letters. In Windows 
# this is irrelevant, but on Linux, check this if you get a "Can't open 
# MPCORB.DAT" message.
#
#*******************************************************************************
# IMPORTANT NOTES
#
# 1. BEWARE: Celestia default installation contains a file asteroids.ssc, with 
# its own definitions of some asteroids. You may end up with double definitions.
# 2. BEWARE ALSO: MPCORB.DAT contains nowadays more than 350,000 asteroids. The 
# extraction of ALL of them to use in Celestia is useless with today computers.
# Be sensible and use the script to extract some of them according to criteria: 
# this is the true purpose of the script. If your search ends up with too many
# asteroids, you will be warned and offered to "decimate" the set.
# 3. ASTEROID SIZE: This important parameter is only estimated by this script. 
# MPCORB.DAT only provides the objects's absolute magnitude, even for asteroids 
# of known size. Its radius is then calculated from it and a guessed $albedo 
# (MPCORB.DAT does not contain known albedos, also). Of course, this gives only 
# approximate results. For example, with an albedo of 0.15 Ceres's radius 
# becomes 368.5 km instead of the known 487.5 km. The estimation is based on [3].
# 4. ASTEROID SHAPE: Two parameters are used, $big and $medium, to define 
# typical asteroid shapes in Celestia:
#               $radius <= $medium, use asteroid.cms mesh (typical potato),
#    $medium <  $radius <  $big,    use roughsphere.cms mesh,
#       $big <= $radius,            use a sphere.
# 5. ASTEROID COLOR: [1.000 0.945 0.881], which is Ceres's color in Celestia, is 
# used for all asteroids.
# 6. ASTEROID TEXTURE: asteroid.jpg (Celestia's default) used for all asteroids.
# 7. PLUTO: Pluto is there, as asteroid D4340. Its radius turns out exaggerated 
# if typical asteroid albedos are used. So are the radii of other TNOs.
# 8. ASTEROID CLASS: MPCORB.DAT provides a class identifier for some asteroidal
# orbital families (Trojans, Atens, etc). I believe this identification is 
# incomplete. For example, the asteroids identified as "Other resonant TNO" do
# not include a single Neptune trojan, which are not identified otherwise. I 
# really do not know what it identifies. Neptune trojans are in the list, though,
# and can be extracted by their names. Orbital parameters can be used to find
# families not covered by these classes. See [5].
# 9. BLANK LINES: There are a couple of blank lines in MPCORB.DAT, dividing it 
# in sections (see its header). This does not affect the script (gives 2 extra
# asteroid counts, though...)
# 10. MPCORB.DAT HEADER: The script reads the header until it reaches a "-----"
# line. This is the standard header. If you change it, watch out.
# 11. ACCURACY: MPCORB provides accurate data for an epoch which is no more 
# than 100 days from its creation date. Their use in Celestia at dates in the 
# past or future from that epoch gets increasingly inaccurate. That's unavoidable 
# for these objects.
# 12. FAMILIES: Asteroid families found from MPCORB elements are only approximate.
# Precise results need the use of proper orbital elements instead of osculating 
# ones. A good source seems to be AstDys [6].
# 13. ASTORB: Another source of asteroid orbital elements is ASTORB.DAT, 
# prepared daily by E. Bowell from Lowell Observatory [7]. MPCORB has several 
# advantages over ASTORB. MPCORB contains currently visible objects; ASTORB 
# contains a lot of objects that were observed briefly, long ago, and which are 
# essentially "lost" now. MPCORB tends to be slightly more up to date 
# (understandably, since ASTORB is based on waiting for MPC data to arrive) [8]. 
# Astorb provides, though, IRAS sizes for some asteroids. I wouldn't rule out 
# its use in principle. Future versions of this script may offer to use one or 
# the other databases.
# 14. DEFAULTS: You can change default parameters in the Initializations section.
#*******************************************************************************
# REFERENCES
# [1] Minor Planet Center of the IAU Webpage: www.cfa.harvard.edu/iau/MPCORB.html
#     New versions of MPCORB.DAT, updated on a daily basis, are available at:
#     ftp://cfa-ftp.harvard.edu/pub/MPCORB/MPCORB.DAT and mirrors.
#     Each object's elements are stored on a single line, the format of which is 
#     described at: www.cfa.harvard.edu/iau/info/MPOrbitFormat.html .
# [2] Celestia, created by Chris Laurel, is a free open source space simulator 
#     avaliable for many operating systems. Webpage: shatters.com/celestia . 
# [3] Quantifying the Risk Posed by Potential Earth Impacts, Chesley et al., 
#     Icarus 159, 423-432 (2002). A table for the same purpose is at the MPC: 
#     www.cfa.harvard.edu/iau/lists/Sizes.html .
# [4] ActivePerl: www.activestate.com/Products/activeperl/ .  
# [5] Wikipedia defines the main asteroid families at: 
#     en.wikipedia.org/wiki/Asteroid_family, and more are listed at:
#     en.wikipedia.org/wiki/Category:Asteroid_groups_and_families
# [6] AstDys (University of Pisa, Italy):
#     hamilton.dm.unipi.it/cgi-bin/astdys/astibo?proper_elements:0;main .
# [7] ASTORB: ftp://ftp.lowell.edu/pub/elgb/astorb.html .
# [8] Project Pluto: www.projectpluto.com/mpcorb.htm .
#*******************************************************************************
# (c) 2008, Guillermo Abramson
# You may use, modify, redistribute at will. Due recognition will be appreciated.
#*******************************************************************************

{# Initializations
$filein    = 'MPCORB.DAT';
$sscbase   = 'mpc';
$celxbase1 = 'mark';
$celxbase2 = 'unmark';
$found = 0;
$astnumber = 0;
$class = 9999;
$param = 9999;    # default choice of parameters for criterion 5
@sma = (0,9999);  # default range of semimajor axes for criterion 5
@ecc = (0,1);     # default eccentricities for criterion 5
@inc = (0,180);   # default inclinations for criterion 5
@rad = (0,9999);  # default radii for criterion 5
$albedo = 0.15;   # Guess. Main belt asteroids have albedos in the range 0.05 to 0.25.
$big = 150;       # Asteroids bigger that $big km in radius will be spherical
$medium = 50;     # Asteroids between $medium and $big will be roughsphere.cms. 
                  # Smaller than $medium will be asteroid.cms (potatoes).
$color = "[1.000 0.945 0.881]"; # This is Ceres color in Celestia

$defaultcolor = 'yellow'; # These parameters define the symbols used in 
$symboltype   = 'disk';   # markasteroids.celx. 
$symbolsize   = 5;        # 5 is OK, even though disks tend to appear as squares.
$symbolalpha  = 0.5;      # Some transparency gives depth...(1 is opaque)
$maxast = 10000;   # Number of asteroids that triggers the prunning 
$medast = 2000;    # Number of asteroids that triggers offer to prune
$pdef   = 0.1;     # Default probability of prunning

open(MPCORB,$filein) or die "Can't open $filein (check case?).\n";
}

{# Input
print "\n\n";
print "*****************************************************************\n"; 
print "* MPCORB2SSC $version: Asteroids orbital elements format conversion *\n";
print "*****************************************************************\n"; 
print "* (c) 2008, Guillermo Abramson  (abramson\@cab.cnea.gov.ar)      *\n";
print "*****************************************************************\n"; 
print "* This script reads MPCORB.DAT and writes an SSC file to be     *\n";
print "* used by Celestia. Follow the menues...                        *\n";
print "* MPCORB.DAT: www.cfa.harvard.edu/iau/MPCORB.html               *\n";
print "* Celestia: shatters.net/celestia                               *\n";
print "*****************************************************************\n"; 

until ($sel == 1 || $sel == 2 || $sel == 3 || $sel == 4 || $sel == 5) {
  print "\n";
  print "1. Select an asteroid by designation (Examples: 6109, K08A00Y)\n";
  print "2. Select an asteroid by name (Examples: Ceres, 2000 VT33)\n";
  print "3. Select a range of asteroids from the list\n";
  print "4. Select asteroids belonging to a class (Example: Trojans)\n";
  print "5. Select asteroids with specific parameters (Ex: radius < 1km)\n";
  print "\n(Selections 4 and 5 can be combined with AND)\n";
  print "\n";
  print "Your choice: ";
  chomp($sel=<STDIN>);
}

{# See input selection subs at the end of the file
if    ($sel == 1) { # Select designation
  &choose_designation;
  $sscbase   = "$sscbase\_des=$ast";
  $celxbase1 = "$celxbase1\_des=$ast";
  $celxbase2 = "$celxbase2\_des=$ast";
}
elsif ($sel == 2) { # Select name
  &choose_name;
  $sscbase   = "$sscbase\_name=$ast";
  $celxbase1 = "$celxbase1\_name=$ast";
  $celxbase2 = "$celxbase2\_name=$ast";
  $sscbase   =~ s/[\/\\\:\*\?\"\<\>\|]/-/g; # Replace invalid characters in filenane with -
  $celxbase1 =~ s/[\/\\\:\*\?\"\<\>\|]/-/g; # Replace invalid characters in filenane with -
  $celxbase2 =~ s/[\/\\\:\*\?\"\<\>\|]/-/g; # Replace invalid characters in filenane with -
}
elsif ($sel == 3) { # Select range
  &choose_range;
  $sscbase   = "$sscbase\_range=$ast";
  $celxbase1 = "$celxbase1\_range=$ast";
  $celxbase2 = "$celxbase2\_range=$ast";
}
elsif ($sel == 4) { # Select class
  &choose_class;
  if    ($class ==  2) {$classname = "\_atens"}
  elsif ($class ==  3) {$classname = "\_apollos"}
  elsif ($class ==  4) {$classname = "\_amors"}
  elsif ($class ==  5) {$classname = "\_q1\.381"}
  elsif ($class ==  6) {$classname = "\_q1\.523"}
  elsif ($class ==  7) {$classname = "\_q1\.665"}
  elsif ($class ==  8) {$classname = "\_hildas"}
  elsif ($class ==  9) {$classname = "\_trojans"}
  elsif ($class == 10) {$classname = "\_centaurs"}
  elsif ($class == 14) {$classname = "\_plutinos"}
  elsif ($class == 15) {$classname = "\_resonantTNOs"}
  elsif ($class == 16) {$classname = "\_cubewanos"}
  elsif ($class == 17) {$classname = "\_scattereddisk"}
  $sscbase   = "$sscbase$classname";
  $celxbase1 = "$celxbase1$classname";
  $celxbase2 = "$celxbase2$classname";

  print "\n*****************************************************************\n";
  print   "* You can combine this choice with the parameters filter (AND)  *\n";
  print   "*****************************************************************";
  until ($param == 0) {
    &choose_parameters;
    if    ($param == 1) {$par = "sma=$sma"}
    elsif ($param == 2) {$par = "ecc=$ecc"}
    elsif ($param == 3) {$par = "inc=$inc"}
    elsif ($param == 4) {$par = "rad=$rad"}
	elsif ($param == 0) {last;}
    $sscbase = "$sscbase\_$par";
    $celxbase1 = "$celxbase1\_$par";
    $celxbase2 = "$celxbase2\_$par";
	$param = 9999;
  }	

}  
elsif ($sel == 5) { # Select parameters
  until ($param == 0) {
    &choose_parameters;
    if    ($param == 1) {$par = "sma=$sma"}
    elsif ($param == 2) {$par = "ecc=$ecc"}
    elsif ($param == 3) {$par = "inc=$inc"}
    elsif ($param == 4) {$par = "rad=$rad"}
	elsif ($param == 0) {last;}
    $sscbase = "$sscbase\_$par";
    $celxbase1 = "$celxbase1\_$par";
    $celxbase2 = "$celxbase2\_$par";
	$param = 9999;
  }	

  print "\n*****************************************************************\n";
  print   "* You can combine this choice with the classes filter (AND)     *\n";
  print   "*****************************************************************";
  &choose_class;
  if    ($class ==  2) {$classname = "\_atens"}
  elsif ($class ==  3) {$classname = "\_apollos"}
  elsif ($class ==  4) {$classname = "\_amors"}
  elsif ($class ==  5) {$classname = "\_q1\.381"}
  elsif ($class ==  6) {$classname = "\_q1\.523"}
  elsif ($class ==  7) {$classname = "\_q1\.665"}
  elsif ($class ==  8) {$classname = "\_hildas"}
  elsif ($class ==  9) {$classname = "\_trojans"}
  elsif ($class == 10) {$classname = "\_centaurs"}
  elsif ($class == 14) {$classname = "\_plutinos"}
  elsif ($class == 15) {$classname = "\_resonantTNOs"}
  elsif ($class == 16) {$classname = "\_cubewanos"}
  elsif ($class == 17) {$classname = "\_scattereddisk"}
  $sscbase   = "$sscbase$classname";
  $celxbase1 = "$celxbase1$classname";
  $celxbase2 = "$celxbase2$classname";
}
}

print "\nChoose a color for the markers (ENTER=$defaultcolor)\n";
print "(Use color names, or HTML-style colors, e.g. #00ff00 for green): ";
chomp($symbolcolor = <STDIN>);
if ($symbolcolor eq '') {$symbolcolor = $defaultcolor; }
}

$celxbase1 = "$celxbase1\_col=$symbolcolor";
$celxbase2 = "$celxbase2\_col=$symbolcolor";
$sscfile = "$sscbase\.ssc";
$celxfile1 = "$celxbase1\.celx";
$celxfile2 = "$celxbase2\.celx";

{ # Open output files
open(SSC, "+>$sscfile"); # +> opens for: Read, Write, not Append, Create if not exists.
open(MARK, ">$celxfile1");
# print CELX "celestia:unmarkall()\n"; # not desirable if several marking scripts will be used
print MARK "celestia:flash(\"Marking asteroids...\",2)\n";
print MARK "celestia:show(\"markers\")\n";
open(UNMARK, ">$celxfile2");
print UNMARK "celestia:show(\"markers\")\n";
}

# Skip header
until (substr($line,0,5) eq "-----") {
  $line = <MPCORB>;
}
# Read data
print "\nSearching...\n\n";
while (<MPCORB>) { # Read whole lines and look up for asteroids
    $astnumber = $astnumber + 1; # Count the asteroids, just for curiosity...
    $line = $_; 
{# Analyze the line of data according to MPCORB format    
    $designation  = substr($_,0,7);    # Designation
    $H            = substr($_,8,5);    # Absolute magnitude
    $G            = substr($_,14,5);   # Slope parameter
    $epoch        = substr($_,20,5);   # Epoch
    $anomaly      = substr($_,26,9);   # Mean anomaly at the epoch (deg)
    $perihelion   = substr($_,37,9);   # Argument of perihelion (deg)
    $node         = substr($_,48,9);   # Longitude of ascending node (deg)
    $inclination  = substr($_,59,9);   # Inclination to the ecliptic,J2000.0 (degrees)
    $e            = substr($_,70,9);   # Orbital eccentricity
    $motion       = substr($_,80,11);  # Mean daily motion (degrees per day)
    $semiaxis     = substr($_,92,11);  # Semimajor axis (AU)
    $U            = substr($_,106,1);  # Uncertainty parameter
    $ref          = substr($_,107,10); # Reference
    $obs          = substr($_,117,5);  # Number of observations
    $opp          = substr($_,123,3);  # Number of oppositions
    $observations = substr($_,127,9);  # Observations (multiple oppositions/single oppositions)
    $rms          = substr($_,137,4);  # r.m.s. residual
    $coarsepert   = substr($_,142,3);  # Coarse indicator of perturbers
    $precisepert  = substr($_,146,3);  # Precise indicator of perturbers
    $computer     = substr($_,150,10); # Computer name
    $flag         = substr($_,161,4);  # Additional information (coded)
    $rdesignation = substr($_,166,27); # Readable designation
    $name         = substr($_,175,18); # Name (part of readable designation)
    $last         = substr($_,194,8);  # Date of last observation
}
{# Some processing on the read data
    $designation =~ s/^\s+//;  # Replace leading whitespace with nothing
    $designation =~ s/\s+$//;  # Replace trailing whitespace with nothing
    $designation =~ s/^0*//;   # Remove leading zeros

    $rdesignation =~ s/^\s+//;  # Replace leading whitespace with nothing
    $rdesignation =~ s/\s+$//;  # Replace trailing whitespace with nothing

    $name =~ s/^\s+//;  # Replace leading whitespace with nothing
    $name =~ s/\s+$//;  # Replace trailing whitespace with nothing
    
    &epoch($epoch);  # Unpack epoch
    $julianepoch = &jdn(@epoch)-0.5; # -0.5 since jdn calculates Julian Day at noon
      
    $period = $semiaxis ** 1.5; # Orbital period
      
    $f = hex("0x$flag");  # Flag with additional information
    $type = &type($f);    # Get the type from lower 6 bits of this flag

    $diameter = 1329/sqrt($albedo)*10**(-0.2*$H); # Estimation. See Notes above.
    $radius = $diameter/2;
}
{# Use criteria to find asteroids    
    if    ($sel == 1) {             # Selection by designation
      if ($designation eq $ast) {
        print "Found: $designation ($name).\n";
        $found = $found + 1;
        &outssc;
		&outcelx($name,$found);
		&finish;
      }
    }    
    elsif ($sel == 2) {             # Selection by name
      $lcname = $name;
      $lcname =~ tr/A-Z/a-z/;   # Lower case for the comparison
      $lcname =~ s/\s//;        # Delete spaces, for the comparison
      if ($lcname =~ m/$ast/) { # Match the input against the name
        print "Found: $designation ($name).\n";
        $found = $found + 1;
        &outssc;
		&outcelx($name,$found);
		$names[$found]=$name;
      }
    }
    elsif ($sel == 3) {             # Selection by order in the list
      if ($astnumber >= $ast[0] && $astnumber <= $ast[1]) {
        $found = $found + 1;
        &outssc;
		&outcelx($name,$found);
		$names[$found]=$name;
      }
      elsif ($astnumber > $ast[1]) {
        &finish;
      }
    }
    elsif ($sel ==4 || $sel == 5) { # Selection by type and parameters
      if ( ( $type == $class || $class == 0 ) && # $class == 0 matches all (default)
           ( ( $semiaxis >= $sma[0] && $semiaxis <= $sma[1] ) &&
           ( $e >= $ecc[0] && $e <= $ecc[1] ) &&
           ( $inclination >= $inc[0] && $inclination <= $inc[1] ) &&
           ( $radius >= $rad[0] && $radius <= $rad[1]) )
          ) {
        $found = $found + 1;
        &outssc;
		&outcelx($name,$found);
		$names[$found]=$name;
      }
    }
}
} # close file reading block

# Some output when search comes to the end of the list
print "$astnumber asteroids in the list. Last asteroid is $rdesignation.\n";
&finish;

#*********************************************************************************
sub finish {
  if ($found eq 0) {
    close SSC; close MARK; close UNMARK;
    unlink "$sscfile","$celxfile1","$celxfile2";   # Remove empty output files
    print "\n**************************** RESULTS ****************************\n";
    print "Found 0 asteroids.\n";\
    print "Consider reviewing your search criteria.\n";
    print "*****************************************************************\n";
	exit; 
  }	
  print "\n**************************** RESULTS ****************************\n";
  print "Found $found asteroids matching your criterion.\n";\
  print MARK "celestia:flash(\"Finished marking $found asteroids.\",3)\n";
  print UNMARK "celestia:flash(\"Finished unmarking $found asteroids.\",3)\n";
  close MARK; close UNMARK;
  print "Output written to:\n";
  print "  Data file: $sscfile\n";
  print "  Script to mark them in $symbolcolor: $celxfile1\n";
  print "  Script to unmark them: $celxfile2\n";
  if ($found >= $maxast) { 
    print "\n**************************** WARNING ****************************\n";
    print "Your search found too many asteroids!\nCelestia may become unresponsive or cluttered.\n\nI will write additional ssc and celx files to load/mark/unmark \njust some of them, both randomly chosen and the biggest ones.\n\n";
    print "What fraction of the whole $found asteroids do you want to keep?\n(defaults to 0.1, i.e. 10% of the asteroids): ";
    chomp($p = <STDIN>);
    if ($p eq '') {$p = $pdef; }
    $some = int($p * $found);
    &prunernd;  # prune at random with probability $p
    &prunebig;  # prune by keeping the $some biggest asteroids
  }
  elsif ($found >= $medast) {
    print "\n**************************** WARNING ****************************\n";
    print "Your search found many asteroids! Celestia may become cluttered.\n\nWould you like me to write additional ssc and celx files to \nload/mark/unmark just some of them? (Random and biggest ones).\n\n";
	print "Your choice (yes/y/no/n, defaults to no): ";
	chomp($prune = <STDIN>);
	if ($prune eq "yes" || $prune eq "y" ){
      print "\nWhat fraction of the whole $found asteroids do you want to keep?\n(defaults to 0.1, i.e. 10% of the asteroids): ";
	  chomp($p = <STDIN>);
      if ($p eq '') {$p = $pdef; }
      $some = int($p * $found);
      &prunernd;  # prune at random with probability $p
      &prunebig;  # prune by keeping the $some biggest asteroids
    }
  }
  print "\n**************************** DONE!!! ****************************\n\n";
  print "**************************** WARNING ****************************\n";
  print "* Beware: if you have run this script from within Celestia's    *\n";
  print "* Extras folder, please keep just one of the ssc files, or you  *\n";
  print "* will end up with multiple declarations for the same asteroid  *\n";
  print "* or with an unresponsive Celestia.                             *\n";
  print "*****************************************************************\n";
  exit 0;
}
    
#*********************************************************************************
sub prunernd { # Prune at random with probability $p
# (Random prunning tends to favor the over-represented tiny asteroids in families, 
# and the main objects get lost.)
  seek (SSC,0,0); # Reposition at beginning of ssc file to read it
  $_ = $sscfile;    s/\.ssc/_prune=$p\.ssc/;
  $ssc2 = $_;
  $_ = $celxfile1;  s/\.celx/_prune=$p\.celx/;
  $celx1 = $_;
  $_ = $celxfile2;  s/\.celx/_prune=$p\.celx/;
  $celx2 = $_;
  open (SSC2, ">$ssc2");
  open (MARK, ">$celx1");
  open (UNMARK, ">$celx2");
  print MARK "celestia:flash(\"Marking $some asteroids...\",2)\n";
  print MARK "celestia:show(\"markers\")\n";
  $k = 0; # Kept asteroid counter
  for ($j=1;$j<=$found;$j++) {
  $z = rand $found;
  if ($z <= $some) {      # With probability $p keep this asteroid
    $k++; # Kept asteroid counter
    while (<SSC>) {
      $line = $_;   
      if ($line ne "}\n") {     # Detect the end of current asteroid declaration
        print SSC2 "$line";
		if ("$line" =~ m/^"/) { # Detect first line of each asteroid declaration
		  @line = split /:/, $line; # Extract asteroid name form that line
 	      $line[0]=~s/\"//;
	      $name = $line[0];
		  &outcelx($name,$k); 
		}
      }
	  else {  # This will print out the closing of the declaration and a blank line
        print SSC2 "$line";
        $line = <SSC>;              
        print SSC2 "$line";
	    last; # Done with current asteroid, move on to next one
	  }
    }	
  }
  else {                        # With probability 1-$p skip this asteroid
    while (<SSC>) {
      $line = $_;              
      if ($line ne "}\n")	{    }
	  else {
        $line = <SSC>;              
	    last;
	  }
    }
  }

  }
  print MARK "celestia:flash(\"Finished marking $some asteroids.\",3)\n";
  print UNMARK "celestia:flash(\"Finished unmarking $some asteroids.\",3)\n";
  close SSC2; close MARK; close UNMARK;
  print "\n************************ RANDOM PRUNNING ************************\n";
  print "$some asteroids have been kept.\n";
  print "Output written to:\n";
  print "  Data file: $ssc2\n";
  print "  Script to mark them in $symbolcolor: $celx1\n";
  print "  Script to unmark them: $celx2\n";
}

#*********************************************************************************
sub prunebig { #prune by keeping the biggest asteroids
  seek (SSC,0,0); # Reposition at beginning of ssc file to read it 2nd time
  $_ = $sscfile;    s/\.ssc/_N=$some\.ssc/;
  $ssc2 = $_;
  $_ = $celxfile1;  s/\.celx/_N=$some\.celx/;
  $celx1 = $_;
  $_ = $celxfile2;  s/\.celx/_N=$some\.celx/;
  $celx2 = $_;
  open (SSC2, ">$ssc2");
  open (MARK, ">$celx1");
  open (UNMARK, ">$celx2");
  print MARK "celestia:flash(\"Marking $some asteroids...\",2)\n";
  print MARK "celestia:show(\"markers\")\n";

  while (<SSC>) {
    if (m/Radius/) {		# Detect the Radius line
      chomp;
	  s/Radius//;			# Remove the word (keep the number)
	  push @radius , $_;	# Add to the array
    }
  }


  @sorted_index = sort { $radius[$a] <=> $radius[$b] } 0..$#radius; # Sort the radii, return the index 
                                                                  # of the sorted in the original array.
  @sorted_index = reverse(@sorted_index);			# From large to small
  $cutoff = sprintf "%.3f", @radius[@sorted_index[$some-1]];		# Cutoff radius
  @pruned_index = splice @sorted_index, 0, $some;	# Prune to $some biggest

  seek (SSC,0,0); # Reposition at beginning of ssc file to read it again

  $k=0;										# Asteroid index in file
  while ($k<=$found) {
    if (grep {$_ eq $k} @pruned_index) {	# See if index is in the prunned list
	  $line=<SSC>;							# Read first line (with asteroid name)
	  print SSC2 "$line";					# Write it to prunned file
	  @line = split /:/, $line; 			# Extract asteroid name form that line
	  $line[0]=~s/\"//;
	  $name = $line[0];
	  &outcelx($name,$j); 
	  for ($l=2;$l<=23;$l++) {				# Each Asteroid definition has 23 lines
	    $line=<SSC>;						# Read them
		print SSC2 "$line";					# Write them to prunned file
		}
	  $k++;
	} else {
 	  for ($l=1;$l<=23;$l++) {$line=<SSC>}	# Else, just read lines to advance to next asteroid
      $k++;
    }
  }	
  print MARK "celestia:flash(\"Finished marking $some asteroids.\",3)\n";
  print UNMARK "celestia:flash(\"Finished unmarking $some asteroids.\",3)\n";
  close SSC2; close MARK; close UNMARK;
  print "\n************************* SIZE PRUNNING *************************\n";
  print "$some asteroids have been kept. Cutoff radius: $cutoff km.\n";
  print "Output written to:\n";
  print "  Data file: $ssc2\n";
  print "  Script to mark them in $symbolcolor: $celx1\n";
  print "  Script to unmark them: $celx2\n";
}

#*********************************************************************************
sub outssc { # Output data in Celestia SSC format
# Heading
    if ($name eq $rdesignation) {
	  $celname="$name:$designation:$rdesignation";
	} else {
	  $celname="$name:$designation:$rdesignation";
	}  
    print SSC "\"$celname\" \"Sol\"\n\{\n\tClass \"asteroid\"\n\tTexture \"asteroid.jpg\"\n\tColor $color\n\tBlendTexture true\n";
# Radius
    if ($radius < $big && $radius > $medium) {
      print SSC "\tMesh \"roughsphere.cms\"\n";
    }  
    elsif ($radius <= $medium) {
      print SSC "\tMesh \"asteroid.cms\"\n";
    }  
	else {
	  print SSC "# No mesh (spherical)\n";
	}  
    print SSC "\tRadius          $radius\n";
# Orbit    
    print SSC "\n\tEllipticalOrbit\n\t\{\n";
    print SSC "\tEpoch           $julianepoch\n";
    print SSC "\tPeriod          $period\n";
    print SSC "\tSemiMajorAxis   $semiaxis\n";
    print SSC "\tEccentricity    $e\n";
    print SSC "\tInclination     $inclination\n";
    print SSC "\tAscendingNode   $node\n";
    print SSC "\tArgOfPericenter $perihelion\n";
    print SSC "\tMeanAnomaly     $anomaly\n";
    print SSC "\t\}\n\n";
    print SSC "\}\n\n";
}

#*********************************************************************************
sub outcelx { # Output markers in Celestia CELX format. 1st argument is name, 2nd is order number (for writing wait()).
    my ($name,$order) = @_;
    print MARK "asteroid = celestia:find(\"Sol/$name\")\n";
    print MARK "asteroid:mark(\"$symbolcolor\",\"$symboltype\",$symbolsize,$symbolalpha)\n";
    print UNMARK "asteroid = celestia:find(\"Sol/$name\")\n";
    print UNMARK "asteroid:unmark()\n";
	if ($order % 200 == 0) { # print a wait() every 500 asteroids to avoid timeout
	  print MARK "wait()\n";
      print MARK "celestia:flash(\"Marked $order asteroids...\",1)\n";
	  print UNMARK "wait()\n";
	}  
}

#*******************************************************************************
# Epoch is weirdly packed in MPCORB.DAT, to save bytes (!!). 
# @_ is a single value argument, $epoch, in the format CYYMD: century, year,
# month, day (see the code). 
sub epoch { # Unpack epoch
	$century = substr $_[0],0,1;
	$year = substr $_[0],1,2;
	$month = substr $_[0],3,1;
	$day = substr $_[0],4,1;

	if    ($century eq "I") {$cent="18";}
	elsif ($century eq "J") {$cent="19";}
	elsif ($century eq "K") {$cent="20";}
	$year = "$cent$year";

	if    ($month eq "1") {$mon="01";}
	elsif ($month eq "2") {$mon="02";}
	elsif ($month eq "3") {$mon="03";}
	elsif ($month eq "4") {$mon="04";}
	elsif ($month eq "5") {$mon="05";}
	elsif ($month eq "6") {$mon="06";}
	elsif ($month eq "7") {$mon="07";}
	elsif ($month eq "8") {$mon="08";}
	elsif ($month eq "9") {$mon="09";}
	elsif ($month eq "A") {$mon="10";}
	elsif ($month eq "B") {$mon="11";}
	elsif ($month eq "C") {$mon="12";}

	if    ($day eq "1") {$d="01";}
	elsif ($day eq "2") {$d="02";}
	elsif ($day eq "3") {$d="03";}
	elsif ($day eq "4") {$d="04";}
	elsif ($day eq "5") {$d="05";}
	elsif ($day eq "6") {$d="06";}
	elsif ($day eq "7") {$d="07";}
	elsif ($day eq "8") {$d="08";}
	elsif ($day eq "9") {$d="09";}
	elsif ($day eq "A") {$d="10";}
	elsif ($day eq "B") {$d="11";}
	elsif ($day eq "C") {$d="12";}
	elsif ($day eq "D") {$d="13";}
	elsif ($day eq "E") {$d="14";}
	elsif ($day eq "F") {$d="15";}
	elsif ($day eq "G") {$d="16";}
	elsif ($day eq "H") {$d="17";}
	elsif ($day eq "I") {$d="18";}
	elsif ($day eq "J") {$d="19";}
	elsif ($day eq "K") {$d="20";}
	elsif ($day eq "L") {$d="21";}
	elsif ($day eq "M") {$d="22";}
	elsif ($day eq "N") {$d="23";}
	elsif ($day eq "O") {$d="24";}
	elsif ($day eq "P") {$d="25";}
	elsif ($day eq "Q") {$d="26";}
	elsif ($day eq "R") {$d="27";}
	elsif ($day eq "S") {$d="28";}
	elsif ($day eq "T") {$d="29";}
	elsif ($day eq "U") {$d="30";}
	elsif ($day eq "V") {$d="31";}

	return @epoch = ($year,$mon,$d);
}
    
#*******************************************************************************
# Given the argument (year,month,day) calculates the Julian Day at noon of that 
# day (http://en.wikipedia.org/wiki/Julian_day).
sub jdn { # Julian day calculation
    $year = $_[0];
    $month = $_[1];
    $day = $_[2];
    $a = int((14-$month)/12);
    $y = $year + 4800 - $a;
    $m = $month + 12*$a - 3;
    return $jdn = $day + int((153*$m+2)/5)+365*$y+int($y/4)-int($y/100)+int($y/400)-32045;
}    

#*******************************************************************************
sub dec2bin { # Convert a number to binary digits
    my $str = unpack("B32", pack("N", shift));
#    $str =~ s/^0+(?=\d)//;   # removes leading zeros (not necessary here)
    return $str;
}

#********************************************************************************
sub bin2dec { # Convert a string of bits to a 32 bits integer
    return unpack("N", pack("B32", substr("0" x 32 . shift, -32)));
}

#********************************************************************************
# MPCORB.DAT contains 4 hex digits with additional information. Asteroid type 
# is coded in the lower 6 bits. This gets those.
sub type { # Decode MPCORB asteroid type
    my $f = $_[0];
    my $binstr=dec2bin($f);
    $binstr = substr($binstr,26,6); 
    return $type = bin2dec($binstr); # Type is coded in the lower 6 bits 
}

#********************************************************************************
#********************************************************************************
# INPUT SELECTION ROUTINES
#********************************************************************************
{ # selection routines
sub choose_designation {
  print "Enter asteroid designation: ";
  chomp($ast = <STDIN>);
  $ast =~ s/^0*//;   # Remove leading zeros
}
#********************************************************************************
sub choose_name {
  print "\nAsteroid names are capricious.\n";
  print "You may use partial names and Perl regular expressions.\n";
  print "The search is insensitive to case and spaces.\n";
  print "Ex: BuenosAires and buenosaires will find 7850 (Buenos Aires).\n";
  print "Ex: Buenos Aires or buenos aires will also find 7850 (Buenos Aires).\n";
  print "Ex: plata will find 1029 (La Plata) and 9309 (Platanus).\n";
  print "Ex: ^plata will find only 9309 (Platanus).\n";
  print "Ex: ^1996 will find all 1996 asteroids that do not have a proper name, \n    like (85389) Rosenauer.\n";
  print "Ex: lennon|mccartney|starr\$|^harrison will find The Beatles.\n";
  print "\nEnter asteroid name (case insensitive, spaces insensitive): ";
  chomp($ast = <STDIN>);
  $ast =~ tr/A-Z/a-z/;  # lower case for searching
  $ast =~ s/ //g;       # remove spaces
}
#********************************************************************************
sub choose_range {
  print "Enter a range in the form: first-last: ";
  chomp($ast = <STDIN>);
  @ast = split(/-/,$ast);
}
#********************************************************************************
sub choose_class {
  print "\nMPCORB.DAT provides some orbital classes of asteroids. \n(I believe it's incomplete; see readme.txt.)\n";
  print "Available classes:\n";
  print " 2. Aten (Near Earth asteroids, semi-major axis < 1 AU)\n";
  print " 3. Apollo (Near Earth asteroids, semi-major axis > 1 AU, q < 1.017 AU)\n";
  print " 4. Amor (Near Earth asteroids, do not cross Earth orbit)\n";
  print " 5. Object with q < 1.381 AU (q = perihelion distance)\n";
  print " 6. Object with q < 1.523 AU\n";
  print " 7. Object with q < 1.665 AU\n";
  print " 8. Hilda (2:3 orbital resonance with Jupiter, triangle)\n";
  print " 9. Jupiter Trojan (At Jupiter's L4 and L5 Lagrangian points)\n";
  print "10. Centaur (Orbits between Jupiter and Neptune, icy and comet-like)\n";
  print "14. Plutino (Trans Neptunian Objects in 2:3 resonance with Neptune)\n";
  print "15. Other resonant TNO (not clear what this means; see readme.txt)\n";
  print "16. Cubewano (Kuiper Belt not in resonance with Neptune. Named after 1992 QB1)\n";
  print "17. Scattered disk (Distant TNOs, beyond the Kuiper Belt)\n";
  print " 0. Continue (Defaults to all asteroids)\n";
  until ($class==2 ||$class==3 ||$class==4 ||$class==5 ||$class==6 ||$class==7 ||$class==8 ||$class==9 ||$class==10 ||$class==14 ||$class==15 ||$class==16 ||$class==17 || $class==0) {
  print "\nEnter your choice (ENTER=Continue): ";
  chomp($class = <STDIN>);
  }
}
#********************************************************************************
sub choose_parameters {
  until ($param == 1 ||$param==2 ||$param==3 ||$param==4 ||$param==0) {
    print "\nAvailable parameters:\n";
    print "1. Semimajor axis\n";
    print "2. Orbit eccentricity\n";
    print "3. Orbit inclination\n";
    print "4. Radius (very coarse calculation; see readme.txt)\n";
    print "0. Continue (defaults to full range for unchosen parameters)\n";
    print "\n";
    print "Your choice (ENTER=Continue): ";
    chomp($param = <STDIN>);
    
    if    ($param == 1) { # Input semimajor axis
      print "Enter a range of semimajor axes (in AU) in the form Rmin-Rmax: ";
      chomp($sma = <STDIN>);
      @sma=split(/-/,$sma); # get r1 as $sma[0] and r2 as $sma[1]    
      print "\nNow you can choose additional parameters or continue...";
    }
    elsif ($param == 2){ # Input eccentricity
      print "Enter a range of eccentricities (0 to 1) in the form emin-emax: ";
      chomp($ecc = <STDIN>);
      @ecc=split(/-/,$ecc); # get e1 as $ecc[0] and e2 as $ecc[1]    
      print "\nNow you can choose additional parameters or continue...";
    }
    elsif ($param == 3){ # Input inclination
      print "Enter a range of inclinations (0 to 180 deg) in the form imin-imax: ";
      chomp($inc = <STDIN>);
      @inc=split(/-/,$inc); # get i1 as $inc[0] and i2 as $inc[1]    
      print "\nNow you can choose additional parameters or continue...";
    }
    elsif ($param == 4){ # Input radius
      print "Enter a range of radii (in km) in the form rmin-rmax: ";
      chomp($rad = <STDIN>);
      @rad=split(/-/,$rad); # get r1 as $rad[0] and r2 as $rad[1]    
      print "\nNow you can choose additional parameters or continue...";
    }
  }
 } 
#********************************************************************************
# END INPUT SELECTION ROUTINES
#********************************************************************************
}