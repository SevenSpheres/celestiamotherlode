
DIONE FROM CASSINI IMAGES

This is a high resolution surface texture of Saturn's moon Dione, based on the map released on 20 May 2008 by Ciclops (http://ciclops.org). See Map of Dione - Ciclops.txt for details about the map, which is based on Cassini and Voyager images. Follow the url file to visit Ciclops release.

INSTALLATION
Unzip the contents of the zip file inside the Extras folder of Celestia. You may use a subfolder of Extras, also (e.g. Extras/SolarSystem/Saturn/Dione). Celestia will find it.

USAGE
On Celestia, go to Dione. Right click and select Alternate Surfaces, and choose Dione (Ciclops). Celestia will choose either the 4k, the 2k or the 1k versions, depending on your current resolution setting (change with r and R).

ALTERNATIVE USAGE
If you prefer to replace Dione default surface with this one, edit dione-ciclops.ssc and uncomment (remove the #) from the line with the Modify directive, and comment (add a #) in front of the AltSurface one. 

CREDITS
This texture is Ciclops' map of Dione as of 20th May 2008. Adapted for Celestia by Guillermo Abramson (http://cabfst28.cnea.gov.ar). 
Find about Celestia at http://shatters.net/celestia.  