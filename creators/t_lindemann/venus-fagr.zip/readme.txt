Copy the <venus-graf> file to the lores folder and add contents of .ssc file in your <venus-surfaces.ssc> file.

Cheers,

Ton Lindemann
Netherlands