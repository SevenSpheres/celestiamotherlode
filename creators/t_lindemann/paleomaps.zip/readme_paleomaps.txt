Paleographic maps

This set contains from 850 million of years to present paleographic maps in steps of 25 mill of years. The green bounderies are representing the positions of the current coastlines, while the blue lines represents the continental plates. The position of the deep sea ridges are only known for the last 100 mill of years.

Maps are generated with Plate Tracker from Scot Scotese and are free for use for non commercial purposes. Copy the maps in your medres folder and place the earth_altmaps.ssc files into the extra folder.

Heave fun to view and check out the continental drift in Celesia from the Precambrium to the present day.

Cheers,

Ton Lindemann
lindemann.ton@hccnet.nl