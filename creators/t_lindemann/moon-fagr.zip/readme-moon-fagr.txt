Copy and paste the next lines into the <moon-altmaps.ssc> file, or create a new one and copy the moon-topo file into the medres folder:

AltSurface "Gravity" "Sol/earth/moon"
{
	Texture "moon-fagr.*"
}

Source: http://webgis.wr.usgs.gov

Ton Lindemann
Netherlands
