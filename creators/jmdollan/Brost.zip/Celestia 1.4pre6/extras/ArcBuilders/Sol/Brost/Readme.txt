ASTEROID BROST for the ARCBUILDER UNIVERSE
============================================
Version 1.0
copyright John M. Dollan
j.dollan@bresnan.net
http://j.dollan.home.bresnan.net/ARCindex.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2005.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folders "/ArcBuilder Universe" and "/Sol" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer the "ArcBuilder Universe" folder to the new installation, and you'll be set.

Also, this add-on and all future ones that go within the "/Sol" sub-folder should not conflict with anything that comes in Celestia's default "solarsys.ssc" file.

This add-on was designed using Celestia 1.4.0 pre6.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 4
	*  png cloud maps = 0
	*  png ring textures = 0
	*  3DS models = 1
	*  CMOD models = 0
	*  SSC files = 1
	*  STC files = 0
	*  TXT files = 1, being this readme file.

III.  Creation Process Notes
======================
Brost:  The texture for this asteroid began with a generic asteroid texture that I found on the 'Net.  I then added some elements from a colorized version of the Deimos texture, and shrunk the whole thing down to 1k in size.  Brost itself was named for a good friend of mine who went to college with me.  She was my partner in crime more than once!

Dutchmann Memorial Outpost:  A friend of mine, Steve Bowers, created a model of the AMT _Dutchmann_ for me, one thing lead to another, and he very kindly created a model of the outpost, complete with an eroded version of the _Dutchmann_ inside.  His efforts, appreciated beyond measure, are definitely superior to my own!  Thus was born version 1.0 of this add-on.  Steve also created an updated version of the asteroid Brost in 3DS format, replacing an older CMOD version that I had found in an old folder on my computer.  Also included in this model is a Human figure, provided for scale, added by Steve and modified from a freeware version originally by Anthony Baldwin.

IV.  System Information, Fact and Fiction
================================
The asteroid Brost is a completely fictional body, and is a member of a fictional (so far) class of asteroids.  It will play a pivotol role in a future short story set in the ArcBuilder Universe.  A brief synopsis of  Brost can be found at the following website:  http://j.dollan.home.bresnan.net/ARCWorldsSolBrost01.html

V.  Acknowledgments
=================
A very big thanks to Selden and Jestr for helping me to work through placing a model on the surface of the asteroid.  I could have been running in little circles until I exploded before I figured it out!

A definite huge thanks to Steve Bowers, who recreated this entire add-on for me, using Anim8tor.  His efforts have turned this add-on from a simple and very amateurish representation by myself to a most worthy add-on that adds much to the ArcBuilder Universe.

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

---------------

Addendum
New Brost model by Steve Bowers
Human model modified from a freeware original by Anthony Baldwin