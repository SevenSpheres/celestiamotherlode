Original Mercury texture taken from john van Vliet's 4k Mercury texture, located at http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=243

