ASTEROID 22 KALLIOPE for the ARCBUILDER UNIVERSE
============================================
Version 0.1
copyright John M. Dollan
j.dollan@bresnan.net
http://j.dollan.home.bresnan.net/ARCindex.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2005.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folders "/ArcBuilder Universe" and "/Sol" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer the "ArcBuilder Universe" folder to the new installation, and you'll be set.

Also, this add-on and all future ones that go within the "/Sol" sub-folder should not conflict with anything that comes in Celestia's default "solarsys.ssc" file.

This add-on was designed using Celestia 1.4.0 pre6.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 2
	*  png cloud maps = 0
	*  png ring textures = 0
	*  3DS models = 0
	*  CMOD models = 0
	*  SSC files = 1
	*  STC files = 0
	*  TXT files = 1, being this readme file.

III.  Creation Process Notes
======================
Kalliope:  Kalliope began as a generic texture for darker asteroids, and it will likely remain that way.  I had started trying to import 3DS models onto the surface in order to show the remains of the old mining outpost there, but being low on patience I settled for simply painting them onto the surface by utilizing various images of fictional moonbases found on the 'Net.

Linus:  Linus is a slightly modified map of Dactyl, with the remains of an administration center painted onto its surface.  Like the case with Kalliope, I simply didn't have the patience to try and get a 3DS model to properly work on the surface.  After some minor color correction, I called it good.

IV.  System Information, Fact and Fiction
================================
Kalliope is a real asteroid, discovered in 2001 to possess a small companion moon.  I chose it pretty much at random as an example for Metallic Class asteroids in the PCL ( http://j.dollan.home.bresnan.net/ARCPCLIndex4edMetallic.html ), and later gave it its own page, in context with the ArcBuilder Universe, located at http://j.dollan.home.bresnan.net/ARCWorldsSol22Kalliope01.html .

V.  Acknowledgments
=================
As always, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.