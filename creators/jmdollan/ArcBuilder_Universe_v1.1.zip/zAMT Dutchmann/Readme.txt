AMT DUTCHMANN for the ARCBUILDER UNIVERSE
============================================
Version 0.1
copyright John M. Dollan
j.dollan@bresnan.net
http://j.dollan.home.bresnan.net/ARCindex.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2005.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folders "/ArcBuilder Universe" and "/Sol" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer the "ArcBuilder Universe" folder to the new installation, and you'll be set.

Also, this add-on and all future ones that go within the "/Sol" sub-folder should not conflict with anything that comes in Celestia's default "solarsys.ssc" file.

This add-on was designed using Celestia 1.4.0 pre6.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

NOTE!!  The folder for this add-on MUST have the "z" prefix, or it will not display in Celestia.  Also, you *must* download the Asteroid Brost add-on, located at 

http://www.celestiamotherlode.net/creators/jmdollan/Brost.zip

At least, you must download it if you wish it to orbit Brost.  You can, of course, modify the ssc file so that the ship appears where ever you would like!

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 3
	*  png cloud maps = 0
	*  png ring textures = 0
	*  3DS models = 1
	*  CMOD models = 0
	*  SSC files = 1
	*  STC files = 0
	*  TXT files = 1, being this readme file.

III.  Creation Process Notes
======================
AMT Dutchmann:  The model for this spacecraft was created by Steve Bowers using Anim8tor, based on a sketch that I had done for the ship.  The sketch was a simple drawing meant to convey a smallish vessel, and one that was designed specifically for travel within the orbit of Mercury.  Steve, turning it into a full-fledged model, was a remarkable feat!  Suggestions given by Selden were also taken into consideration, and eventually lead to the finished version of the model.

IV.  System Information, Fact and Fiction
================================
The AMT _Dutchmann_ is, of course, a fictional craft set within my ArcBuilder Universe setting.  I have the vessel orbiting the asteroid Brost.  However, in the setting, the ship actually landed on Brost and remained there, after its automated systems continued to function after the death of the crew.  But I didn't want to create an xyz file for it, and so simply placed the ship in a highly eccentric orbit about the asteroid.  If you travel to the asteroid, you will see the Dutchmann Memorial Outpost, within which is the remains of the _Dutchmann_, highly eroded by the near solar environment.  So don't be confused!  They are both representing the same ship, but at two vastly different times.

At the present time (July, 2005) I have no specific page dedicated to the _Dutchmann_ on my site.  However, there is a brief blurb located here:

http://j.dollan.home.bresnan.net/ARCPCLIndex4edVulcanian.html

Keep checking at my site, though.  Eventually there will be a site dedicated to the AMT _Dutchmann_, but that probably won't be reflected in this readme file.

V.  Acknowledgments
=================
A definite huge thanks to Steve Bowers, who recreated this model for me, using Anim8tor.  His efforts go beyond what a simple thank you could convey.

Further thanks to Selden for his suggestions on the appearance and functionality of the _Dutchmann_.  They've added to the realism of the project.

Much of the discussion for this add-on took place on Steve Bower's OA Celestia list, located at http://groups.yahoo.com/group/OA-Celestia/

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

---------------