AMT ALMUCANTAR for the ARCBUILDER UNIVERSE
============================================
Version 0.1
copyright John M. Dollan
j.dollan@bresnan.net
http://j.dollan.home.bresnan.net/ARCindex.html
3DS model by Steve Bowers

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2005.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folders "/ArcBuilder Universe" and "/Sol" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer the "ArcBuilder Universe" folder to the new installation, and you'll be set.

Also, this add-on and all future ones that go within the "/Sol" sub-folder should not conflict with anything that comes in Celestia's default "solarsys.ssc" file.

This add-on was designed using Celestia 1.4.0 pre6.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 4
	*  png cloud maps = 0
	*  png ring textures = 0
	*  3DS models = 1
	*  CMOD models = 0
	*  SSC files = 1
	*  STC files = 0
	*  TXT files = 1, being this readme file.

III.  Creation Process Notes
======================
AMT Almucantar:  The model for this spacecraft was created by Steve Bowers using Anim8tor, based on a sketch that I had done for the ship.  The sketch was a simple drawing meant to convey an asteroid ore/cargo vessel to be used by my wife, Margo, in a story that she is currently (as of July 2005) working on.  Steve turned it into a full-fledged model, which was a remarkable feat!  I then placed the model in an orbit that is meant to convey a sense of just what kind of journey might have been typical for this ship, and others of its class.  In the actual ArcBuilder setting, the Almucantar would travel from an asteroid in the Belt, to Mars, then to Luna, and back out to the Belt after all of its cargo had been unloaded.  However, there is no practical way to do this in Celestia, at least not without creating an XYZ file for a specific time in the far future, something that I want to avoid with these add-ons.

IV.  System Information, Fact and Fiction
================================
The AMT _Almucantar_ is, of course, a fictional craft set within my ArcBuilder Universe setting.  The name was thought up by my wife, and refers to a type of instrument used to take star sightings (at least, before the advent of modern sea navigation).

At the present time (July, 2005) I have no specific page dedicated to the _Almucantar_ on my site.  However, there is a brief blurb located here:

http://j.dollan.home.bresnan.net/ARCVesselindex.html

Keep checking at my site, though.  Eventually there will be a site dedicated to the AMT _Almucantar_, but that probably won't be reflected in this readme file.

V.  Acknowledgments
=================
A definite huge thanks to Steve Bowers, who created this model for me, using Anim8tor.  His efforts go beyond what a simple thank you could convey.

Much of the discussion for this add-on took place on Steve Bower's OA Celestia list, located at http://groups.yahoo.com/group/OA-Celestia/

And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.

---------------