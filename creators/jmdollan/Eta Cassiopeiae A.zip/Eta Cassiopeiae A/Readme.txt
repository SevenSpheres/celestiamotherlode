ETA CASSIOPEIAE A for the ARCBUILDER UNIVERSE
============================================
Version 1.0
copyright John M. Dollan
Designed using Celestia 1.5.0 pre2
maastrichian@bresnan.net
http://arcbuilder.home.bresnan.net/Index01.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2007.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folders "/ArcBuilder Universe" and "/Eta Cassiopeiae A" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer the "ArcBuilder Universe" folder to the new installation, and you'll be set.

This add-on was designed using Celestia 1.5.0 pre2.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = xx
	*  png textures = xx
	*  3DS models = xx
	*  CMOD models = xx
	*  SSC files = xx
	*  STC files = xx
	*  TXT files = xx

III.  Notes
=================
*A haze function is not used with this add-on, due to my inability to see that particular feature with my current computer.  Hopefully, in the future, I will get a better video card and will be able to impliment that function.

IV.  Acknowledgments
=================
*Some planetary information generated with the online version of Stargen, located at http://eldacur.dyndns.org/StarGen/RunStarGen.html
*Aid with particular planetary characteristics for barnstable and its moons provided by Neal Aaron and Matthew Johnson.
* A lot of help with some of the planetary parameters courtesy David Bellomy.
*Atmosphere's created with Rassilon's Atmosphere Gauge v1.0
*And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.