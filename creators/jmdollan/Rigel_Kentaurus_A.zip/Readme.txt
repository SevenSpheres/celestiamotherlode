ALPHA CENTAURI A for the ARCBUILDER UNIVERSE
============================================
Version 1.1
copyright John M. Dollan
j.dollan@bresnan.net
http://j.dollan.home.bresnan.net/ARCindex.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2005.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folders "/ArcBuilder Universe" and "/Alpha Centauri A" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer the "ArcBuilder Universe" folder to the new installation, and you'll be set.

This add-on was designed using Celestia 1.4.0 pre6.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 24
	*  png cloud maps = 3
	*  png ring textures = None
	*  3DS models = None
	*  CMOD models = None (all models provided with default Celestia installaltion)
	*  SSC files = 2, one for the system, one for the asteroid belt.
	*  STC files = None
	*  TXT files = 1, being this readme file.

III.  Creation Process Notes
======================
Vulcan Asteroid Belt:  Currently, the models and textures are the default items provided with Cormoran's asteroid belt generator.  I did have some plans to go through and rename everything, and then make at least a few more unique textures, but my heart just wasn't in it.  That will have to come later.  The models themselves actually come with the default installation of Celestia, and so are NOT included with this installation.  however, if you want to add some different models, or even provide your own, I've included a "models" folder for conveniance, which installs within the "/Alpha Centauri A" folder.

Asbolos:  I used a 2k map of Mercury and a 2k map of Enceladus and slowly combined features from the icy moon to that of the planet.  Later I added a few semi- to solid selections from the Moon as well.  All of this to give the planet a "different" feel;  if you think it is an alien world, then so much the better!  Finally I adjusted the color of the entire planet to a russet brown or so;  color can often mask familiarity.

Polyphonte:  Here I used a 2k texture of Tatooine (as far as I can tell, free for public use;  it's been on the 'Net forever, and I've never found its oriignal author), and a high resolution image of the central Sahara Desert.  I slowly combined these two, and then modified the over all color to instill that "alienness".  I then tinkered about with the color levels to produce a night map simulating the dull red glow of the active volcanic expanses.

Orius:  For this moon of Polyphonte, I found a wonderful Selenian-style map on the 'Net, although I have no idea who the original author is.  I did some very minor tweaking, added a few small deep crater maria, and called it good.

Agrios:  Simply a heavily modified map of the Moon, originally 4k in size, but reduced to 2k.

Ghellhonus:  Ghellhonus had already been put together by myself some time past, using, if I recall, central Afghanistan as a primary clone source, although I also used several elements from his resolution global maps.  For this version 1.0, I upgraded some lower resolution-looking land masses.  They're still a little "flat" looking, but not quite as bad as before.  The cloud map for Ghellhonus was taken from Don Edward's site at http://www.shatters.net/~impulse/Earth_Central/Main.html.

Amycos:  Amycos is another heavily modified map of the Moon, which was originally 4k and then shrunk down to 2k. 

Teleboas:  This began as a satellite image of somewhere in Africa, which I stretched and cylindrical-ized.  After a few minor tweaks, I then ran it through a topography filter and fiddled a bit more with it.  What I've come up with shows something of a rocky world, but hints at a dry and sandy surface.  It may not be totally realistic, but I tend to like the effect that it portrays.

IV.  System Information, Fact and Fiction
================================
Obviously, as of this date, we have no idea what might be orbiting Alpha Centauri A.  Papers have been published, which work out the limits of stable orbits, the maxmum mass that any planets could have, and whether or not worlds could even form here.  To be truthful, while this is probably my favorite star system and I fervently hope that even a hot Jupiter might someday be found here, I really have my doubts as to whether or not planets might form.  Being in a stable orbit is one thing, but contending with the gravitational interference of the companion star during formation and being able to actually form a full-fledged planet or two is quite another.  Therefore, you should take this system add-on in the manner that it was intended and with a grain of salt.  Maybe someday telescopes and other instruments will detect the signature of a small, rocky world.  Or maybe they will find only evidence of a massive asteroid belt, mute evidence that planets tried to form and failed.  But for the ArcBuilder Universe setting, there ARE planets here, and they are very similar to those we already know.

I made this star system a virtual twin to our own Solar System's inner regions on purpose.  I wanted the first star that Humans reached for colonization purposes to be quite Earthlike, to make the transition easier, and to lull the rest of the folks back on Earth into a false sense of ease.  If the first colony had it so good, then surely the other planned colonies would as well!

V.  Acknowledgments
=================
Thanks to Cormoran from the Celestia forum at shatters.net for his aid in the construction of the Vulcan Asteroid Belt.
Thanks to Don Edwards for permission to use his Northern Summer Southern Winter cloud map.
Thanks to Evil Doctor Ganymede for his suggestions and critiques.  I didn't follow all of his advice, but all of his advice was invaluable nonetheless.
And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.