ALPHA CENTAURI SYSTEM
========================================
An Orion's Arm Universe Add-on
JMD-v0.1
Construction Begun October 22, 2006
Construction Completed October 30, 2006
v0.1 Updated on October 30, 2006
========================================
This add-on is intended for use with other Orions Arm add-ons.  When used in combination with non-OA add-ons, undesirable side effects may be detected, such as texture problems, contradictory data, etc., especially if you use other fictional add-ons that utilize this same star system.

This add-on was created by John M. Dollan, utilizing all available data regarding the Alpha Centauri System which could be found at the Orion's Arm web site.  Development notes follow (see the Reference section following these notes for corresponding reference links):

1) The Nauri/Nuri/Nari page references "Long Range telescopes in orbit and on the Moon had already detected a number of terrestrial class planets and several microjovians, and this, along with the presence of several asteroid belts, was confirmed by the new Long Range Deep Space Array."  Also, "...carbonacious chondrites in the inner A Centauri belt."  Also, "...several Venusian and Arean Type Planets, or on any of Europan Type moons around the microjovians..."  By the First Federation, there were "...numerous von neumann robots, sentient autofactories, and extensive megastructures."

2) The Enyclopedia Galactica entry for Proxima Centauri references "Habitats in the icy belts around Proxima Centauri."

3) As of October, 2006, the OA Complete Package Add-on has no information regarding this triple system.  This leaves the board wide open for interpretation and new Celestia add-on construction.

4) In the ssc file, after the entry for the Class of the body being defined, there will be a reference to the NolWocs classification scheme.  Look below for the webpage dealing with NolWocs.

5) Some aspects of this system's physical parameters were created by using the StarGen generator.

6) Atmopshere work was achieved through the use of Rassilon's most excellent online tool.

7) The asteroid belts were generated using Asteroid Maker v1.6, by Bruce Mills.

8) Portions of the Proxima Centauri system were generated utilizing Star Generator v2.0.

---------------------------------------------------------------
References
   1) http://www.orionsarm.com/clades/Naurinumes.html
   2) http://www.orionsarm.com/eg/p/Pp-Pr.html#Proxima_Centauri
   3) http://www.celestiamotherlode.net/catalog/show_addon_details.php?addon_id=582
   4) http://www.orionsarm.com/science/Non-luminary_World_Classifications.html
   5) http://eldacur.dyndns.org/StarGen/RunStarGen.html
   6) http://www.celestialvisions.net/~rassilon/atmosphere.php
   7) There is no website available for the procurement of this Asteroid Maker, unfortunately.  I recomend going to the Celestia Forum at shatters.net and asking about.
   8) http://www.lemoneyes-radio.com/stargen/
---------------------------------------------------------------
For questions or commentspertaining to this add-on, please email John at maastrichian@bresnen.net
Visit Orion's Arm at http://www.orionsarm.com/main.html