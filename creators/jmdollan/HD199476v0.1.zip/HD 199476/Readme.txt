To reach this system, simply type in "HD 199476".

This system is based on one designed by Mike Parisi.

Asteroid Belt generated with ASTEROID MAKER VERSION 1.6 Created by Bruce Mills

Some planetary information generated using Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html

This add-on is intended for use with other ArcBuilder Universe add-ons.  However, you are free to use this add-on any way that you wish.  Changes or distribution with other add-ons requires permission from the author at j.dollan@bresnan.net