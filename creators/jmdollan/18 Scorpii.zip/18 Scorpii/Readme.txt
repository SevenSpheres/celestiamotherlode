18 SCORPII for the ARCBUILDER UNIVERSE
================++++=================
Version 0.1
copyright John M. Dollan
Designed using Celestia 1.5.0 pre2
maastrichian@bresnan.net
http://arcbuilder.home.bresnan.net/Index01.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2007.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folder "/18 Scorpii" will be created.  It's as simple as that.

This add-on was designed using Celestia 1.5.0 pre2.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 6
	*  png textures = 5
	*  3DS models = 0
	*  CMOD models = 0
	*  SSC files = 1
	*  STC files = 0
	*  TXT files = 1

III.  Notes
=================
* Please note that this add-on contains only the relevant worlds of the System; that is, only the worlds which have been mentioned or which would be of immediate interest to the literary setting have been included.  Future updates could include new system bodies, if needed.
*A haze function is not used with this add-on, due to my inability to see that particular feature with my current computer.  However, the new atmospheric declarations have been used to simulate the haze effect.
* Future updates will include the Human impact to this system, including cities, spacecraft, and other signs of civilization.

IV.  Updates
==========
Version 0.1:  This is the first version for Celestia for this system, with no previous versions existing.

V.  Acknowledgments
=================
* Some textures were found, uncredited, in random Internet searches.  If these textures are protected by copyright, please let me know!
* Some planetary parameters generated with Stargen at http://eldacur.dyndns.org/StarGen/RunStarGen.html
* Atmospheres created with Rassilon's Atmosphere Gauge v1.0
* And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.