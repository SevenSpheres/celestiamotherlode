Based on an Orion's Arm write up, "Enigma Four" located at http://www.orionsarm.com/topics/Enigma_Four.html

Helix Nebula provided by JLL (see associated readme file).  Many thanks!

This add-on is intended to be used with other Orions Arm Universe add-ons.  However, general non-commercial use is granted.

Planetary Textures by John Dollan; space stations and craft by Steve Bowers.