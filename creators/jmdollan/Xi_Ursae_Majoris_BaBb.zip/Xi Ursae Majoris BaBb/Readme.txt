XI URSAE MAJORIS BaBb for the ARCBUILDER UNIVERSE
=======================++++++++=====================
Version 1.0
copyright John M. Dollan
Designed using Celestia 1.5.0 pre2
maastrichian@bresnan.net
http://arcbuilder.home.bresnan.net/Index01.html

The ArcBuilder Universe is � John M. and Margo L. Dollan 2002-2007.  All materials contained herein are copyrighted unless otherwise noted in this readme file.  You are free to use this add-on as you wish, so long as the copyrighted materials are not used for other projects and publications without prior permission, and reference is given to me using both my name and my email address.  This add-on is meant to be used either as a stand-alone or in concert with other ArcBuilder add-ons.  The author assumes no responsibility for conflicts or problems that arise if used outside of these parameters.  None should occur, but one can never be certain....

I.  Installation
===========
All materials for this add-on are self-contained and need not be removed from the folders and sub-folders provided.  Simply unzip this package into your extras directory.  The folder "/Xi Ursae Majoris BaBb" will be created.  It's as simple as that.  Hopefully, then, when the next release of Celestia comes out, all you'll need to do is transfer this folder to the new installation, and you'll be set.

HOWEVER and IMPORTANT:  In order for this add-on to display correctly for the ArcBuilder setting, it was neccessary to create a new Xi Ursae Majoris stc file, which is included with this add-on.  This neccessitated the deletion of the pre-existing entry for this star from the nearstars.stc file, located in the Data directory of Celestia.  You must either do this yourself, or you can simply copy the enclosed nearstars.stc file, that I have provided, into the Data folder.  The deletion of Xi Ursae Majoris from the enclosed file IS THE ONLY CHANGE IN THAT FILE, and as of January of 2007 there should be no other changes to worry about.

I recomend that you change the original file yourself, though, as future versions of Celstia may have significant other differences within its nearstars.stc file, and the file provided with this add-on could well be woefully out of date.

This add-on was designed using Celestia 1.5.0 pre2.  Unless future versions of Celestia are greatly different, it should not be neccessary to change anything if you do upgrade.

II.  Add-On Contents
================
The following is a breakdown of the files contained within this add-on.  This is meant to give a quick idea as to what is to be found within.

	*  jpg textures = 18
	*  png textures = 2
	*  3DS models = 1
	*  CMOD models = 2
	*  SSC files = 1
	*  STC files = 2
	*  TXT files = 1

III.  Notes
=================
*A haze declaration is not used with this add-on, due to my inability to see that particular feature with my current computer.  Hopefully, in the future, I will get a better video card and will be able to impliment that function.

IV.  Acknowledgments
=================
* Planetary system and stellar dynamics courtesy David Bellomy and his Moon and Planet Maker spreadsheets.
*Atmosphere's created with Rassilon's Atmosphere Gauge v1.0
*The moons Primum, Medius, and Extremus models and textures courtesy of Cham, offered for free at http://shatters.net/forum/viewtopic.php?t=8045&postdays=0&postorder=asc&highlight=asteroid+pack&start=30
*And, of course, thanks to the creators and maintainers of the Celestia program, located at http://shatters.net/celestia/ , the Celestia forum located at http://www.shatters.net/forum/ , and the Celestia Motherlode, located at http://www.celestiamotherlode.net/index.html .  Without any of these places and people, this project would never have happened, period.